﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using C1.Win.C1TrueDBGrid;
using C1.Win.C1FlexGrid;

namespace FTIL.Match.AuditTrail.Forms
{
    public partial class frmAuditTrailNew : Form
    {
        public DataSet dsDetails;
        public int nPageHeight { get; set;}
        public int nPageWidth { get; set; }
        public int nTabHeight { get; set; }
        public int nTabWidth  { get; set; }

        public int nPageTop { get; set; }
        public int nPageLeft { get; set; }

        public string s_CDDApp { get; set; }
        public string sDisplayName { get; set; }
        private string sTabName;
        object[] objGrid;
        public frmAuditTrailNew(DataSet p_dsDetails)
        {
            InitializeComponent();
            this.KeyPreview = true;
            objGrid = new object[p_dsDetails.Tables.Count - 1];
            this.dsDetails = p_dsDetails;

            
        }

        private void frmAuditTrailNew_Load(object sender, EventArgs e)
        {
            if (nPageHeight != 0 && this.nPageWidth != 0)
            {
                this.Height = this.nPageHeight;
                this.Width = this.nPageWidth;
                tabChildEntities.Height = this.nTabHeight;
                tabChildEntities.Width = this.nTabWidth;
            }

            if (nPageHeight == 0 && nTabHeight != 0 && nTabWidth != 0)
            {
                tabChildEntities.Height = this.nTabHeight;
                tabChildEntities.Width = this.nTabWidth;
            }

            if (nPageTop != 0 && this.nPageLeft != 0)
            {
                this.Top = this.nPageTop;
                this.Left = this.nPageLeft;
            }

            if (sDisplayName != null && sDisplayName != "")
                this.Text = sDisplayName;

            IntilizeGrid(dsDetails);
        }

        void IntilizeGrid(DataSet dsDetails)
        {
            try
            {
                tabChildEntities.TabPages.Clear();

                DataTable dtTabCaptions = dsDetails.Tables[dsDetails.Tables.Count - 1];
                for (int i = 0; i < (dsDetails.Tables.Count - 1); i++)
                {
                    DataTable dt = dsDetails.Tables[i];
                    if (dtTabCaptions.Rows.Count < (i + 1))
                        break;
                    TabPage tabPage = new TabPage();
                    tabPage.Text = dtTabCaptions.Rows[i][0].ToString();
                    sTabName = dtTabCaptions.Rows[i][0].ToString();
                    //---------------------------------------------------------------------------------------
                    MatchCommon.CustomControls.FTTrueDBGrid C1TrueDBGrid = new MatchCommon.CustomControls.FTTrueDBGrid();
                    C1TrueDBGrid.Visible = true;
                    C1TrueDBGrid.AllowDelete = false;
                    C1TrueDBGrid.AllowUpdate = false;
                    C1TrueDBGrid.AllowDrop = false;
                    C1TrueDBGrid.AllowDrag = false;

                    C1TrueDBGrid.Location = new System.Drawing.Point(0, 0);
                    C1TrueDBGrid.MarqueeStyle = C1.Win.C1TrueDBGrid.MarqueeEnum.HighlightRow;
                    C1TrueDBGrid.PreviewInfo.Location = new System.Drawing.Point(0, 0);
                    C1TrueDBGrid.PreviewInfo.Size = new System.Drawing.Size(0, 0);
                    C1TrueDBGrid.PreviewInfo.ZoomFactor = 75D;
                    C1TrueDBGrid.RowHeight = 20;
                    sTabName = sTabName.Replace(" ", "");
                    C1TrueDBGrid.Name = "dg" + sTabName;
                    C1TrueDBGrid.Dock = DockStyle.Fill;
                    tabChildEntities.TabPages.Add(tabPage);
                    tabPage.Controls.Add(C1TrueDBGrid);
                    createGrid(dt, C1TrueDBGrid);

                    objGrid[i] = C1TrueDBGrid;
                   
                    //---------------------------------------------------------------------------------------


                    //-------------------------------------------------------------------------------------------
                    //C1FlexGrid c1FlexGrid = new C1FlexGrid();
                    //c1FlexGrid.AllowDragging = AllowDraggingEnum.Columns;
                    //c1FlexGrid.AllowEditing = false;
                    //c1FlexGrid.AllowDelete = false;
                    //c1FlexGrid.AllowAddNew = false;
                    //c1FlexGrid.AllowFreezing = AllowFreezingEnum.None;
                    //c1FlexGrid.AllowSorting = AllowSortingEnum.None;
                    //c1FlexGrid.Dock = DockStyle.Fill;
                    //C1.Win.C1FlexGrid.CellStyle s = c1FlexGrid.Styles.Add("OldValues");
                    //s.BackColor = Color.Yellow;
                    //s.Font = new Font(Font, FontStyle.Bold);
                    //createGrid(dt, c1FlexGrid);
                    //tabPage.Controls.Add(c1FlexGrid);
                    //tabChildEntities.TabPages.Add(tabPage);
                    //-------------------------------------------------------------------------------------------


                //createGrid(dt, dgvMasterData);
                 
                }
            } 
            catch (Exception ex)
            { 
                if (ex.Message =="")
                {
                    return;
                }
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void createGrid(DataTable dtDetails, C1TrueDBGrid TrueDBGrid)
        {
            
            BindingSource bs = new BindingSource();
            bs.DataSource = dtDetails;
            TrueDBGrid.DataSource = bs;
            TrueDBGrid.RecordSelectors = false;

            if (s_CDDApp == "Yes")
            {
                TrueDBGrid.Splits[0].DisplayColumns["s_ChangeNature"].Visible = false;
                TrueDBGrid.Splits[0].DisplayColumns["RecordType"].Visible = false;
                TrueDBGrid.Splits[0].DisplayColumns["d_ChangeDateTime"].DataColumn.Caption = "Modified DateTime";
                TrueDBGrid.Splits[0].DisplayColumns["ClientNo"].Visible = false;
                TrueDBGrid.Splits[0].DisplayColumns["ClientCode"].Visible = false;
                if (sTabName == "Account")
                {
                    TrueDBGrid.Splits[0].DisplayColumns["Place of Incorporation"].Visible = false;
                    TrueDBGrid.Splits[0].DisplayColumns["CorporateId No"].Visible = false;
                    TrueDBGrid.Splits[0].DisplayColumns["Comm Of Business"].Visible = false;
                    TrueDBGrid.Splits[0].DisplayColumns["PanNo"].Visible = false;
                    TrueDBGrid.Splits[0].DisplayColumns["DOB"].DataColumn.Caption = "DOB";
                    TrueDBGrid.Splits[0].DisplayColumns["ParentAccountDetails"].Visible = false;
                    TrueDBGrid.Splits[0].DisplayColumns["IsParentAccount"].Visible = false;

                }
            
            }
            else if (s_CDDApp == "YesN")
            {
                TrueDBGrid.Splits[0].DisplayColumns["s_ChangeNature"].Visible = false;
                TrueDBGrid.Splits[0].DisplayColumns["RecordType"].Visible = false;
                TrueDBGrid.Splits[0].DisplayColumns["d_ChangeDateTime"].DataColumn.Caption = "Modified DateTime";
                TrueDBGrid.Splits[0].DisplayColumns["ClientNo"].Visible = false;
                TrueDBGrid.Splits[0].DisplayColumns["ClientCode"].Visible = false;
                if (sTabName == "Account")
                {
                    TrueDBGrid.Splits[0].DisplayColumns["Gender"].Visible = false;
                    TrueDBGrid.Splits[0].DisplayColumns["Marital Status"].Visible = false;
                    TrueDBGrid.Splits[0].DisplayColumns["Nationality"].Visible = false;
                    TrueDBGrid.Splits[0].DisplayColumns["Nationality Other"].Visible = false;
                    TrueDBGrid.Splits[0].DisplayColumns["DOB"].DataColumn.Caption = "DOI";
                }
            }
     
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
           
            int iIdx;
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            iIdx = tabChildEntities.SelectedIndex;
            saveFileDialog.Filter = "xls files (*.xls)|*.xls";

            saveFileDialog.FileName = "AuditTrail_" + tabChildEntities.SelectedTab.Text + ".xls";

            DialogResult result = saveFileDialog.ShowDialog();

            if (result != DialogResult.OK)
            {
                return;

            }
            try
            {
                this.Cursor = Cursors.WaitCursor;
               //objGridTest.ExportToExcel(saveFileDialog.FileName);
                ((C1TrueDBGrid)objGrid[iIdx]).ExportToExcel(saveFileDialog.FileName);

                this.Cursor = Cursors.Default;
              
            }
            catch (Exception)
            {
                MessageBox.Show("Unable to export Data. ", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Cursor = Cursors.Default;
            }
        }
       
    }
}
