﻿namespace FTIL.Match.AuditTrail.Forms
{
    partial class frmAuditTrailNew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAuditTrailNew));
            this.tabChildEntities = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dgvMasterData = new MatchCommon.CustomControls.FTTrueDBGrid();
            this.btnExport = new MatchCommon.CustomControls.FTButton();
            this.tabChildEntities.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMasterData)).BeginInit();
            this.SuspendLayout();
            // 
            // tabChildEntities
            // 
            this.tabChildEntities.Controls.Add(this.tabPage1);
            this.tabChildEntities.Location = new System.Drawing.Point(1, -1);
            this.tabChildEntities.Name = "tabChildEntities";
            this.tabChildEntities.SelectedIndex = 0;
            this.tabChildEntities.Size = new System.Drawing.Size(1022, 626);
            this.tabChildEntities.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1014, 600);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dgvMasterData
            // 
            this.dgvMasterData.AlternatingRows = true;
            this.dgvMasterData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvMasterData.BackColor = System.Drawing.Color.White;
            this.dgvMasterData.FilterBar = true;
            this.dgvMasterData.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvMasterData.Images.Add(((System.Drawing.Image)(resources.GetObject("dgvMasterData.Images"))));
            this.dgvMasterData.Location = new System.Drawing.Point(0, 0);
            this.dgvMasterData.MarqueeStyle = C1.Win.C1TrueDBGrid.MarqueeEnum.HighlightRow;
            this.dgvMasterData.Name = "dgvMasterData";
            this.dgvMasterData.PreviewInfo.Location = new System.Drawing.Point(0, 0);
            this.dgvMasterData.PreviewInfo.Size = new System.Drawing.Size(0, 0);
            this.dgvMasterData.PreviewInfo.ZoomFactor = 75D;
            this.dgvMasterData.PrintInfo.PageSettings = ((System.Drawing.Printing.PageSettings)(resources.GetObject("dgvMasterData.PrintInfo.PageSettings")));
            this.dgvMasterData.RowHeight = 20;
            this.dgvMasterData.Size = new System.Drawing.Size(1030, 530);
            this.dgvMasterData.TabIndex = 0;
            this.dgvMasterData.Text = "UserMaster";
            // 
            // btnExport
            // 
            this.btnExport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExport.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnExport.Image = ((System.Drawing.Image)(resources.GetObject("btnExport.Image")));
            this.btnExport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExport.Location = new System.Drawing.Point(931, 629);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(84, 25);
            this.btnExport.TabIndex = 5;
            this.btnExport.Text = "&Export      ";
            this.btnExport.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // frmAuditTrailNew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1021, 659);
            this.Controls.Add(this.btnExport);
            this.Controls.Add(this.tabChildEntities);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmAuditTrailNew";
            this.Text = "Audit Trail";
            this.Load += new System.EventHandler(this.frmAuditTrailNew_Load);
            this.tabChildEntities.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMasterData)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabChildEntities;
        private System.Windows.Forms.TabPage tabPage1;
        private MatchCommon.CustomControls.FTTrueDBGrid dgvMasterData;
        protected MatchCommon.CustomControls.FTButton btnExport;

    }
}