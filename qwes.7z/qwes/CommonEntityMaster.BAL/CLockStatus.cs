﻿using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace FTIL.Match.CDD.BAL
{
    public class CLockStatus
    {
        public MethodExecResult LockStatus(string s_Mode, string n_EntityNo, string s_LockStatus, ref DataSet dsdata, string s_LockedBy)
        {
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_KYC_LockStatus");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, s_Mode);
                objdbwork.AddParameter("@pn_EntityNo", SqlDbType.VarChar, n_EntityNo);
                objdbwork.AddParameter("@ps_LockStatus", SqlDbType.VarChar, s_LockStatus);
                objdbwork.AddParameter("@pn_UserNo", SqlDbType.VarChar, s_LockedBy);


                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    dsdata = objdbwork.Result as DataSet;
                    if (s_Mode == "S" && ((dsdata == null) || (dsdata.Tables.Count == 0)))
                    {
                        return new MethodExecResult(-1, null, "No recordset returned from database.", null);
                    }
                    return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, string.Empty, null);
                }
                else
                {
                    Logger.Instance.WriteLog(typeof(CLockStatus), objdbwork.ExecutionStatus);
                    return objdbwork.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CLockStatus), ex.Message, ex);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }
        }

    }
}
