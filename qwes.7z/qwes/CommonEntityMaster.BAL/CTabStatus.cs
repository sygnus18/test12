﻿using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace FTIL.Match.CDD.BAL
{
    public class CTabStatus
    {
        public MethodExecResult TabStatus(string s_Mode, string n_EntityNo, ref DataSet dsdata, string n_DetailStage = null)
        { 
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_GetTabStatus");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, s_Mode);
                objdbwork.AddParameter("@pn_EntityNo", SqlDbType.VarChar, n_EntityNo); 
                objdbwork.AddParameter("@pn_DetailStage", SqlDbType.VarChar, n_DetailStage);

                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {

                    dsdata = objdbwork.Result as DataSet;
                    if (s_Mode == "S" && ((dsdata == null) || (dsdata.Tables.Count == 0)))
                    {
                        return new MethodExecResult(-1, null, "No recordset returned from database.", null);
                    }

                    return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, string.Empty, null);
                }
                else
                {
                    Logger.Instance.WriteLog(typeof(CTabStatus), objdbwork.ExecutionStatus);
                    return objdbwork.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CTabStatus), ex.Message, ex);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }
        }

    }
}
