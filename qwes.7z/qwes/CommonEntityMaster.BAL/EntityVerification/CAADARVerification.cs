﻿using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace FTIL.Match.CDD.BAL
{
    public class CAADARVerification
    {
        #region Properties

        public string uid { get; set; }
        public string Poi_name { get; set; }
        public string Poi_dob { get; set; }
        public string Poi_gender { get; set; }
        public string Poi_phone { get; set; }
        public string Poi_email { get; set; }

        public string Poa_co { get; set; }
        public string Poa_house { get; set; }
        public string Poa_street { get; set; }
        public string Poa_lm { get; set; }
        public string Poa_loc { get; set; }
        public string Poa_vtc { get; set; }
        public string Poa_subdist { get; set; }
        public string Poa_dist { get; set; }
        public string Poa_state { get; set; }
        public string Poa_pc { get; set; }
        public string Poa_po { get; set; }
        public string Poa_Pht { get; set; }

        #endregion





        public CAADARVerification(DataSet ds)
        {
            DataTable dtPOI = new DataTable();
            DataTable dtPOA = new DataTable();

            dtPOI = ds.Tables["dtPOI"];
            dtPOA = ds.Tables["dtPOA"];

            uid = dtPOI.Columns.Contains("uid") ? dtPOI.Rows[0]["uid"].ToString() : string.Empty;
            Poi_name = dtPOI.Columns.Contains("name") ? dtPOI.Rows[0]["name"].ToString() : string.Empty;
            Poi_dob = dtPOI.Columns.Contains("dob") ? dtPOI.Rows[0]["dob"].ToString() : string.Empty;
            Poi_gender = dtPOI.Columns.Contains("gender") ? dtPOI.Rows[0]["gender"].ToString() : string.Empty;
            Poi_phone = dtPOI.Columns.Contains("phone") ? dtPOI.Rows[0]["phone"].ToString() : string.Empty;
            Poi_email = dtPOI.Columns.Contains("email") ? dtPOI.Rows[0]["email"].ToString() : string.Empty;
            
            Poa_co = dtPOA.Columns.Contains("co") ? dtPOA.Rows[0]["co"].ToString() : string.Empty;
            Poa_house = dtPOA.Columns.Contains("house") ? dtPOA.Rows[0]["house"].ToString() : string.Empty;
            Poa_street = dtPOA.Columns.Contains("street") ? dtPOA.Rows[0]["street"].ToString() : string.Empty;
            Poa_lm = dtPOA.Columns.Contains("lm") ? dtPOA.Rows[0]["lm"].ToString() : string.Empty;
            Poa_loc = dtPOA.Columns.Contains("loc") ? dtPOA.Rows[0]["loc"].ToString() : string.Empty;
            Poa_vtc = dtPOA.Columns.Contains("vtc") ? dtPOA.Rows[0]["vtc"].ToString() : string.Empty;
            Poa_subdist = dtPOA.Columns.Contains("subdist") ? dtPOA.Rows[0]["subdist"].ToString() : string.Empty;
            Poa_dist = dtPOA.Columns.Contains("dist") ? dtPOA.Rows[0]["dist"].ToString() : string.Empty;
            Poa_state = dtPOA.Columns.Contains("state") ? dtPOA.Rows[0]["state"].ToString() : string.Empty;
            Poa_pc = dtPOA.Columns.Contains("pc") ? dtPOA.Rows[0]["pc"].ToString() : string.Empty;
            Poa_po = dtPOA.Columns.Contains("po") ? dtPOA.Rows[0]["po"].ToString() : string.Empty;
            Poa_Pht = dtPOA.Columns.Contains("Pht") ? dtPOA.Rows[0]["Pht"].ToString() : string.Empty;
        }


        public EntityDetails FillEntityMasterProperties()
        {
            CEntityMaster objEntityMaster = new CEntityMaster();
            EntityDetails details = new EntityDetails();
            Address objCorAddress = new Address();
            Address objPerAddress = new Address();
            MethodExecResult objMER = new MethodExecResult(-1);


            objPerAddress.AddressNo = string.Empty;
            objPerAddress.Address_Line1 = Poa_house + Poa_street + Poa_lm;
            objPerAddress.City = Poa_vtc;
            objPerAddress.State_Others = Poa_state;
            objPerAddress.PIN_Code = Poa_pc;
            objPerAddress.StateCode = Poa_state;
            objPerAddress.Mobile_No = Poi_phone;
            objPerAddress.Email_ID = Poi_email;
             
            
            details.KYCFormNo = string.Empty;
            details.ClientNo = 0;
            details.Applicant_Name = Poi_name;  
            details.Short_Code = string.Empty;
            details.Gender = Poi_gender;
            details.DOB_OR_DOI = string.IsNullOrEmpty(Poi_dob) ? details.DOB_OR_DOI :  Convert.ToDateTime(Poi_dob);
            details.CorrespondenceAddress = objCorAddress;
            details.PermanentAddress = objPerAddress;
            details.FristName = Poi_name;
            details.SameCorrPermAdd = "N";
                
            return details;

        }


    }
}