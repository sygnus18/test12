﻿using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;

namespace FTIL.Match.CDD.BAL
{
    public class CNDML
    {
        public string Address { get; set; }
        public Int32 ReqNo { get; set; }

        public string RES_APP_NAME { get; set; }
        public string RES_APP_STATUS { get; set; }
        public string RES_APP_PAN_NO { get; set; }
        public string RES_APP_DOB { get; set; }

        public string RES_APP_CORR_ADDRESS { get; set; }

        public string RES_APP_REQ_NO { get; set; }
        public string RES_APP_RES_NO { get; set; }
        public string RES_ERROR { get; set; }

        public CNDML()
        {
            Random objrand = new Random();
            ReqNo = objrand.Next(0000000001, 999999999);
        }

        public CNDML(DataSet ds)
        {
            DataTable dtNDML = new DataTable();
            dtNDML = ds.Tables["dtNDML"];
        }

        public EntityDetails FillEntityMasterProperties()
        {
            CEntityMaster objEntityMaster = new CEntityMaster();
            EntityDetails details = new EntityDetails();
            Address objCorAddress = new Address();
            Address objPerAddress = new Address();
            MethodExecResult objMER = new MethodExecResult(-1);
            string s_FirstName = string.Empty;
            string s_MiddleName = string.Empty;
            string s_LastName = string.Empty;


            //----------------For Corresponding Address --------------------------------------------

            objCorAddress.AddressNo = string.Empty;
            objCorAddress.Address_Line1 = RES_APP_CORR_ADDRESS;

            string[] l_splittedaddress = RES_APP_CORR_ADDRESS.Split(' ');
            int length = l_splittedaddress.Length;

            if (length > 5)
            {

                objCorAddress.Country = l_splittedaddress[length - 1];
                objCorAddress.StateCode = l_splittedaddress[length - 2];

                int result = -3;
                bool rslt = int.TryParse(l_splittedaddress[length - 3], out result);
                if (rslt)
                {
                    objCorAddress.PIN_Code = l_splittedaddress[length - 3];
                    objCorAddress.City = l_splittedaddress[length - 4];
                }
                else
                {
                    objCorAddress.StateCode += l_splittedaddress[length - 3];
                    objCorAddress.PIN_Code = l_splittedaddress[length - 4];
                    objCorAddress.City = l_splittedaddress[length - 5];
                }

                //objCorAddress.PIN_Code = l_splittedaddress[length - 3];
                //objCorAddress.City = l_splittedaddress[length - 4];
            }

            StringBuilder l_AddressLine1 = new StringBuilder();
            StringBuilder l_AddressLine2 = new StringBuilder();
            StringBuilder l_AddressLine3 = new StringBuilder();

            for (int i = 0; i <= l_splittedaddress.Length - 4; i++)
            {
                if (l_AddressLine1.Length < 50)
                    l_AddressLine1.Append(l_splittedaddress[i] + " ");
                else if (l_AddressLine2.Length < 50)
                    l_AddressLine2.Append(l_splittedaddress[i] + " ");
                else
                    l_AddressLine3.Append(l_splittedaddress[i] + " ");
            }

            objCorAddress.Address_Line1 = l_AddressLine1.ToString();
            if (!string.IsNullOrEmpty(l_AddressLine2.ToString()))
            {
                objCorAddress.Address_Line2 = l_AddressLine2.ToString();
            }
            else
            {
                objCorAddress.Address_Line2 = "";
            }
            if (!string.IsNullOrEmpty(l_AddressLine3.ToString()))
            {
                objCorAddress.Address_Line3 = l_AddressLine3.ToString();
            }
            else
            {
                objCorAddress.Address_Line3 = "";
            }

            //---------------------End Corresponding Address------------------------------

            //---------------------For Permaent Address-----------------------------------

            //objPerAddress.AddressNo = string.Empty;
            //objPerAddress.Address_Line1 = objCorAddress.Address_Line1;
            //objPerAddress.Address_Line2 = objCorAddress.Address_Line2;
            //objPerAddress.Address_Line3 = objCorAddress.Address_Line3;
            //objPerAddress.City = objCorAddress.City;
            ////objPerAddress.State_Others = objCorAddress.StateCode;
            //objPerAddress.PIN_Code = objCorAddress.PIN_Code;
            //objPerAddress.StateCode = objCorAddress.StateCode;
            ////objPerAddress.Mobile_No = Poi_phone;
            ////objPerAddress.Email_ID = Poi_email;

            //---------------------------------------------------------------------------
            //-------Finding Middle Name-------

            string[] SplitName;

            SplitName = RES_APP_NAME.Split(' ');
            if (SplitName.Length > 1)
            {
                if (SplitName.Length == 3)
                {
                    s_FirstName = SplitName[0];
                    s_MiddleName = SplitName[1];
                    s_LastName = SplitName[2];
                }
                else if (SplitName.Length == 2)
                {
                    s_FirstName = SplitName[0];
                    s_LastName = SplitName[1];
                }
            }
            else
            {
                s_FirstName = SplitName[0];
            }

            details.Father_sHusbands_Name = s_MiddleName == null || s_MiddleName == "" ? " " : s_MiddleName;
            //--------------------------------------


            //objPerAddress.AddressNo = string.Empty; 
            //details.KYCFormNo = string.Empty;
            //details.ClientNo = 0;
            details.Applicant_Name = RES_APP_NAME;
            //details.Short_Code = string.Empty; 
            details.CorrespondenceAddress = objCorAddress;
            details.PermanentAddress = objPerAddress;
            details.SameCorrPermAdd = "Y";

            //details.DOB_OR_DOI = string.IsNullOrEmpty(RES_APP_DOB) ? details.DOB_OR_DOI : Convert.ToDateTime(RES_APP_DOB).ToString("dd/MM/yyyy");
            details.DOB_OR_DOI = DateTime.ParseExact(RES_APP_DOB, "ddMMyyyy", null);

            return details;

        }


        public string SensSMS()
        {
            return callviaHttpWebRequest();
        }

        private string callviaHttpWebRequest()
        {
            string resp = string.Empty;
            string l_smsURL = "http://mysmsapp.in/api/push.json?apikey=5730337ef01a4&sender=SMSAPP&mobileno=7208390875&text=Hi";

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(l_smsURL);
            request.Method = "GET";
            try
            {
                WebResponse webResponse = request.GetResponse();
                Stream webStream = webResponse.GetResponseStream();
                StreamReader responseReader = new StreamReader(webStream);
                resp = responseReader.ReadToEnd();
                responseReader.Close();
            }
            catch (WebException) { }
            return resp;
        }
    }
}
