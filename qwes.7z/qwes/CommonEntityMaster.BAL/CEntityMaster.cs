﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FTIL.Match.Common;
using System.Data;
using FTIL.Match.Common.Db;
using FTIL.Match.CDD.BAL.DataClasses;
using UCC.Class;
using FTIL.Match.Common.Log;
using UCC;
using System.Data.SqlClient;
using FTIL.Match.CDD.BAL.DataClasses.CKYC;
using FTIL.Match.CDD.BAL.DataStore;


namespace FTIL.Match.CDD.BAL
{
    /// <summary>
    /// Business class for Entity manupulation
    /// </summary>
    /// <author>Naveen S</author>
    /// <created>20/2/2015</created>
    public class CEntityMaster
    {

        public CEntityMaster()
        {
            EntityDetailsInstance = new EntityDetails();

            //Only for Intilize collection
            var iIntilizer = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.NATIONALTY];
            iIntilizer = null;
        }

        #region Constants

        public const string CLIENTNO = "n_ClientNo";
        public const string ROWNO = "n_RowNo";
        public const string ENTITYPHOTODOCNO = "n_EntityPhotoDocNo";


        public const string CLIENTCODE = "s_ClientCode";
        public const string CLIENTNAME = "s_ClientName";
        public const string PANNO = "s_PANNo";
        public const string GENDER = "s_Gender";
        public const string GUARDIANNAME = "s_GuardianName";
        public const string MARITALSTATUS = "s_MaritalStatus";
        public const string NATIONALITY = "n_Nationality";
        public const string NATIONALITYTEXT = "s_Nationality";

        public const string NATIONALITYOTHER = "s_NationalityOther";
        public const string PANEXEMPT = "s_PanExempt";
        public const string CORPORATEIDNO = "s_CorporateIdNo";
        public const string DOB = "d_DOB";
        public const string CREATIONDATE = "d_CreationDate";
        public const string NETWORTH = "n_NetWorth";
        public const string NETWORTHASONDATE = "d_NetWorthAsOnDate";
        public const string GRANNINCRANGE = "n_GrAnnIncRange";
        public const string GRANNINCASONDATE = "d_GrAnnIncAsOnDate";
        public const string PEP = "n_PEP";
        public const string PLACEOFINCORPORATION = "s_PlaceofIncorporation";
        public const string OCCUPATION = "n_Occupation";
        public const string OCCUPATIONTEXT = "s_OccupationText";

        public const string OCCUPATIONOTHERS = "s_OccupationOthers";
        public const string COMMOFBUSINESS = "d_CommOfBusiness";
        public const string CINEXEMPT = "s_CINExempt";
        public const string TYPEOFFACILITY = "s_TypeofFacility";
        public const string CLIENTTYPECORPORATE = "s_ClientTypeCorporate";
        public const string LASTUSERNO = "n_LastUserNo";
        public const string LASTMODIFIEDDATETIME = "d_LastModifiedDateTime";
        public const string ISPENDINGAUTH = "s_IsPendingAuth";
        public const string MAKERUSER = "n_MakerUser";
        public const string GENDERTEXT = "s_GenderText";
        public const string MARITALSTATUSTEXT = "s_MaritalStatusText";
        public const string AUTHORIZEDSTATUS = "s_AuthorizedStatus";
        public const string AUTHORIZATIONREMARKS = "s_AuthorizationRemarks";
        public const string DEFAULTIDDETAILS = "s_DefaultIDDetails";

        public const string n_Solutation = "n_Solutation";
        public const string SelfAuth = "SelfAuth";
        public const string sTaxDeductionStatus = "sTaxDeductionStatus";
        public const string SEBIRegistration = "SEBIRegistration";
        public const string StandingInstruction = "StandingInstruction";
        public const string SubType = "SubType";

        public const string ShortCode = "ShortCode";
        public const string Branch = "Branch";
        public const string ParentAccNo = "ParentAccNo";
        public const string IsParentAccount = "IsParentAccount";


        public const string CLIENTTYPE = "s_ClientType";
        public const string CLIENTTYPETEXT = "s_ClientTypeText";
        public const string PEPDESC = "s_PEPDesc";
        public const string USERID = "s_UserId";
        public const string CUSTID = "s_CustId";
        public const string KYCFORMREFCODE = "s_KYCFormRefCode";
        public const string KYCREFCODE = "s_KYCRefCode";
        private const string LastUpdatedUserNo = "n_LastUserNo";





        // Address fields
        public const string ADDRESSNO = "n_AddressNo";
        public const string ADDRESSLINE1 = "s_AddressLine1";
        public const string ADDRESSLINE2 = "s_AddressLine2";
        public const string ADDRESSLINE3 = "s_AddressLine3";
        public const string ADDRESSLINE4 = "s_AddressLine4";
        public const string CITYSTATECODE = "n_CityStateCode";
        public const string CITY = "s_City";
        public const string PINCODE = "s_PinCode";
        public const string STATENUMBER = "n_StateNumber";
        public const string STATEOTHER = "s_StateOther";
        public const string COUNTRYCODE = "n_CountryCode";
        public const string TELNOISDCODE = "s_TelNoISDCode";
        public const string TELNOSTDCODE = "s_TelNoSTDCode";
        public const string TELNO1 = "s_TelNo1";
        public const string TELNOOFFICEISDCODE = "s_TelNoOfficeISDCode";
        public const string TELNOOFFICESTDCODE = "s_TelNoOfficeSTDCode";
        public const string TELNOOFFICE = "s_TelNoOffice";
        public const string MOBILE1 = "s_Mobile1";
        public const string MOBILE2 = "s_Mobile2";
        public const string FAXNOISDCODE = "s_FaxNoISDCode";
        public const string FAXNOSTDCODE = "s_FaxNoSTDCode";
        public const string FAXNO = "s_FaxNo";
        public const string EMAILID = "s_EMailId";
        public const string SAMECORRPERMADD = "s_SameCorrPermAdd";
        public const string PERADDRESSNO = "n_PerAddressNo";
        public const string PERADDRESSLINE1 = "s_PerAddressLine1";
        public const string PERADDRESSLINE2 = "s_PerAddressLine2";
        public const string PERADDRESSLINE3 = "s_PerAddressLine3";
        public const string PERADDRESSLINE4 = "s_PerAddressLine4";
        public const string PERCITYSTATECODE = "n_PerCityStateCode";
        public const string PERCITY = "s_PerCity";
        public const string PERPINCODE = "s_PerPinCode";
        public const string PERSTATENUMBER = "n_PerStateNumber";
        public const string PERSTATEOTHER = "s_PerStateOther";
        public const string PERCOUNTRYCODE = "n_PerCountryCode";
        public const string PERTELNOISDCODE = "s_PerTelNoISDCode";
        public const string PERTELNOSTDCODE = "s_PerTelNoSTDCode";
        public const string PERTELNO1 = "s_PerTelNo1";
        public const string PERTELNOOFFICEISDCODE = "s_PerTelNoOfficeISDCode";
        public const string PERTELNOOFFICESTDCODE = "s_PerTelNoOfficeSTDCode";
        public const string PERTELNOOFFICE = "s_PerTelNoOffice";
        public const string PERMOBILE1 = "s_PerMobile1";
        public const string PERMOBILE2 = "s_PerMobile2";
        public const string PERFAXNOISDCODE = "s_PerFaxNoISDCode";
        public const string PERFAXNOSTDCODE = "s_PerFaxNoSTDCode";
        public const string PERFAXNO = "s_PerFaxNo";
        public const string PEREMAILID = "s_PerEMailId";
        public const string STATUSCODE = "n_Status";
        public const string STATUSTEXT = "s_StatusText";
        public const string STATUSOTHER = "s_StatusOther";
        public const string STATEMENTPERIODICITY = "n_StatementPeriodicity";
        

        #endregion

        #region Properties

        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public DateTime? dLastModifiedDate { get; set; }
        public string EntityType { get; set; }
        public string AuthType { get; set; }
        public string Code { get; set; }
        public int ClientNo { get; set; }
        public int ErrorNo { get; set; }
        public string ErrorMsg { get; set; }
        public string CallingType { get; set; }

        public EntityDetails EntityDetailsInstance { get; set; }

        public DataTable EntityDataTable { get; set; }
        public DataTable EntityAddressDataTable { get; set; }


        #endregion

        #region GetAllEntities
        /// <summary>
        /// Get Entities for Database as per filter provided
        /// </summary>
        /// <param name="dtResult">Entity DataTable</param>
        /// <returns>Execution Status</returns>
        public MethodExecResult GetAllEntities(ref DataTable dtResult)
        {

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_RetrieveEntitiesData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            if (FromDate.HasValue)
                l_objDbWorkItem.AddParameter("@pd_FromDate", SqlDbType.DateTime, FromDate.Value.Date);

            if (ToDate.HasValue)
                l_objDbWorkItem.AddParameter("@pd_ToDate", SqlDbType.DateTime, ToDate.Value.Date);


            l_objDbWorkItem.AddParameter("@ps_EntityType", SqlDbType.VarChar, EntityType);

            l_objDbWorkItem.AddParameter("@ps_AuthType", SqlDbType.VarChar, AuthType);


            l_objDbWorkItem.AddParameter("@ps_Code", SqlDbType.VarChar, Code);

            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                    return new MethodExecResult(1, "No data found", "stp_RetrieveEntitiesData. Database returned no data. UserNo. " +
                        AppEnvironment.AppUser.UserNo.ToString(), null);
                else
                {
                    dtResult = l_dsReturnData.Tables[0];
                    EntityAddressDataTable = l_dsReturnData.Tables[1];
                    EntityDataTable = dtResult;
                    ProcessDataTable();
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        }
        #endregion


        #region GetEntitybyClientNo
        /// <summary>
        /// Get Entity details by ClientNo
        /// </summary>
        /// <param name="ClientNo">ClientNo</param>
        /// <param name="dtResultEntity">EntityDetails DataTable</param>
        /// <param name="dtAddress">Entity Address Detail DataTable</param>
        /// <returns>Execution Status</returns>
        public static MethodExecResult GetEntitybyClientNo(int ClientNo, ref DataTable dtResultEntity, ref DataTable dtAddress)
        {

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_RetrieveEntitiesData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@pd_ClientNo", SqlDbType.Int, ClientNo);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);


            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                    return new MethodExecResult(1, "No data found", "stp_RetrieveEntitiesData. Database returned no data. UserNo. " +
                        AppEnvironment.AppUser.UserNo.ToString(), null);
                else
                {
                    dtResultEntity = l_dsReturnData.Tables[0];
                    dtAddress = l_dsReturnData.Tables[1];

                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        }
        #endregion


        #region GetEntitybyClientNo
        /// <summary>
        /// Get Parent Entity details by ClientNo
        /// </summary>
        /// <param name="ClientNo">ClientNo</param>
        /// <param name="dtResultEntity">EntityDetails DataTable</param>
        /// <param name="dtAddress">Entity Address Detail DataTable</param>
        /// <returns>Execution Status</returns>
        public static MethodExecResult GetParentEntitybyClientNo(int ClientNo, ref DataTable dtResultEntity)
        {

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_RetrieveParentEntitiesData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@pd_ClientNo", SqlDbType.Int, ClientNo);
            //l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);


            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                    return new MethodExecResult(1, "No data found", "stp_RetrieveParentEntitiesData. Database returned no data. UserNo. " +
                        AppEnvironment.AppUser.UserNo.ToString(), null);
                else
                {
                    dtResultEntity = l_dsReturnData.Tables[0];
                  

                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        }
        #endregion



        /// <summary>
        /// Updates current instance changes to database
        /// </summary>
        /// <returns>Method Execution Result</returns>
        #region Update
        public MethodExecResult Update(EntityDetails details, string operationFlag,
            bool updateEntityDetail, bool updateCorrAddress, bool updatePerAddress)
        {


            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_CCMUpdateEntityData");


            
            //SqlConnection conn=new SqlConnection("Data Source=FTCPU2617\SQL2008R2;Initial Catalog=eKYC_Dev;User Id=sa;Password=Hotmail123;Application Name=FTIL.Match.Common;Workstation Id=FTCPU3222");
            //conn.Open();
            //SqlCommand cmd = new SqlCommand("stp_CCMUpdateEntityData", conn);
            //cmd.CommandType = System.Data.CommandType.StoredProcedure;
            //SqlParameter[] l_objDbWorkItem=new SqlParameter[10];

            l_objDbWorkItem.ResultType = QueryType.DataSet;

            SqlParameter outParam = new SqlParameter("@pn_NewClientNo", SqlDbType.Int, 8);
            outParam.Direction = ParameterDirection.Output;
            l_objDbWorkItem.AddParameter(outParam);

            SqlParameter outParamClientDoc = new SqlParameter("@pn_NewClientDocNo", SqlDbType.Int, 8);
            outParamClientDoc.Direction = ParameterDirection.Output;
            l_objDbWorkItem.AddParameter(outParamClientDoc);

            SqlParameter outParamErrNo = new SqlParameter("@pn_ErrorNo", SqlDbType.Int, 8);
            outParamErrNo.Direction = ParameterDirection.Output;
            l_objDbWorkItem.AddParameter(outParamErrNo);

            SqlParameter outParamErrMsg = new SqlParameter("@ps_ErrorMsg", SqlDbType.VarChar, 100);
            outParamErrMsg.Direction = ParameterDirection.Output;
            l_objDbWorkItem.AddParameter(outParamErrMsg);

            if (details.ClientNo > 0)
            {
                operationFlag = "M";
            }

            l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, operationFlag);

            l_objDbWorkItem.AddParameter("@pb_UpdateEntityDetails", SqlDbType.Bit, updateEntityDetail);
            l_objDbWorkItem.AddParameter("@pb_UpdateCorrAddress", SqlDbType.Bit, updateCorrAddress);
            l_objDbWorkItem.AddParameter("@pb_UpdatePerAddress", SqlDbType.Bit, updatePerAddress);


            l_objDbWorkItem.AddParameter("@ps_KYCFormRefCode", SqlDbType.VarChar, details.KYCFormNo);
            l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, details.ClientNo);
            l_objDbWorkItem.AddParameter("@ps_ClientName", SqlDbType.VarChar, details.Applicant_Name);
            l_objDbWorkItem.AddParameter("@ps_GuardianName", SqlDbType.VarChar, details.Father_sHusbands_Name);
            l_objDbWorkItem.AddParameter("@ps_PANNo", SqlDbType.VarChar, details.PAN);

            //Changes as per CDD Phase 2
            l_objDbWorkItem.AddParameter("@ps_Branch", SqlDbType.VarChar, details.Branch);
            l_objDbWorkItem.AddParameter("@ps_ShortCode", SqlDbType.VarChar, details.Short_Code);
            l_objDbWorkItem.AddParameter("@pn_ParentAccNo", SqlDbType.Int, details.Parent_Account_No);
            l_objDbWorkItem.AddParameter("@ps_IsParentAccount", SqlDbType.Char, details.IS_Parent_Accont);




            l_objDbWorkItem.AddParameter("@Ps_EntityType", SqlDbType.VarChar, this.EntityType);
            l_objDbWorkItem.AddParameter("@ps_Gender", SqlDbType.VarChar, details.Gender);
            l_objDbWorkItem.AddParameter("@pn_GuardianClientNo", SqlDbType.Int, details.GuardianClientNo);
            l_objDbWorkItem.AddParameter("@ps_MaritalStatus", SqlDbType.VarChar, details.Marital_status);

            l_objDbWorkItem.AddParameter("@Pn_Status", SqlDbType.Int, details.StatusNonIndVal);
            l_objDbWorkItem.AddParameter("@Ps_StatusOther", SqlDbType.VarChar, details.StatusText);



            l_objDbWorkItem.AddParameter("@pn_Nationality", SqlDbType.Int, details.Nationality);

            l_objDbWorkItem.AddParameter("@ps_NationalityOther", SqlDbType.VarChar, details.NationalityOther);

            l_objDbWorkItem.AddParameter("@ps_CorporateIdNo", SqlDbType.VarChar, details.CIN);

            if (IsValidDate(details.DOB_OR_DOI))
                l_objDbWorkItem.AddParameter("@pd_DOB", SqlDbType.DateTime, details.DOB_OR_DOI);

            l_objDbWorkItem.AddParameter("@pn_GrAnnIncRange", SqlDbType.Int, details.AnnualIncome);

            if (IsValidDate(details.AnnualIncomeDate))
                l_objDbWorkItem.AddParameter("@pd_GrAnnIncAsOnDate", SqlDbType.DateTime, details.AnnualIncomeDate.Value.Date);

            l_objDbWorkItem.AddParameter("@pn_NetWorth", SqlDbType.Decimal, details.Networth);
            if (IsValidDate(details.NetworthDate))
                l_objDbWorkItem.AddParameter("@pd_NetWorthAsOnDate", SqlDbType.DateTime, details.NetworthDate.Value.Date);


            l_objDbWorkItem.AddParameter("@pn_PEP", SqlDbType.Int, details.PEP);
            l_objDbWorkItem.AddParameter("@ps_PEPDesc", SqlDbType.VarChar, details.PEPDesc);
            l_objDbWorkItem.AddParameter("@ps_UserId", SqlDbType.VarChar, details.UserId);
            l_objDbWorkItem.AddParameter("@ps_PanExempt", SqlDbType.Char, details.PANExempt);

            l_objDbWorkItem.AddParameter("@ps_SelfAuth", SqlDbType.VarChar, details.SelfAuth);
            l_objDbWorkItem.AddParameter("@ps_TaxDeductionStatus", SqlDbType.VarChar, details.TaxDeductionStatus);
            l_objDbWorkItem.AddParameter("@ps_SEBIRegistration", SqlDbType.VarChar, details.SEBIRegistration);
            l_objDbWorkItem.AddParameter("@ps_StandingInstruction", SqlDbType.VarChar, details.StandingInstruction);
            l_objDbWorkItem.AddParameter("@pn_Solutation", SqlDbType.Int, details.n_Solutation);

            if (details.sSubType != "")
                l_objDbWorkItem.AddParameter("@ps_SubType", SqlDbType.SmallInt, Convert.ToInt32(details.sSubType));

            l_objDbWorkItem.AddParameter("@ps_PlaceofIncorporation", SqlDbType.VarChar, details.PlaceOfIncorpration);
            l_objDbWorkItem.AddParameter("@pn_Occupation", SqlDbType.Int, details.Occupation);
            l_objDbWorkItem.AddParameter("@ps_OccupationOthers", SqlDbType.VarChar, details.OccupationOther);

            if (IsValidDate(details.DateOfBusinessComm))
                l_objDbWorkItem.AddParameter("@pd_CommOfBusiness", SqlDbType.DateTime, details.DateOfBusinessComm);
            // l_objDbWorkItem.AddParameter("@ps_CINExempt", SqlDbType.VarChar, this.CINExempt);
            l_objDbWorkItem.AddParameter("@ps_TypeofFacility", SqlDbType.VarChar, details.FacilityType);
            l_objDbWorkItem.AddParameter("@pd_dLastModifiedDate", SqlDbType.DateTime, dLastModifiedDate);


            if (details.CorrespondenceAddress != null)
            {
                l_objDbWorkItem.AddParameter("@pn_AddressNo", SqlDbType.Int, details.CorrespondenceAddress.AddressNo == "" ? null : details.CorrespondenceAddress.AddressNo);
                l_objDbWorkItem.AddParameter("@ps_AddressLine1", SqlDbType.VarChar, details.CorrespondenceAddress.Address_Line1);
                l_objDbWorkItem.AddParameter("@ps_AddressLine2", SqlDbType.VarChar, details.CorrespondenceAddress.Address_Line2);
                l_objDbWorkItem.AddParameter("@ps_AddressLine3", SqlDbType.VarChar, details.CorrespondenceAddress.Address_Line3);
                l_objDbWorkItem.AddParameter("@pn_CityStateCode", SqlDbType.VarChar, details.CorrespondenceAddress.City);
                l_objDbWorkItem.AddParameter("@ps_StateOther", SqlDbType.VarChar, details.CorrespondenceAddress.State_Others);
                l_objDbWorkItem.AddParameter("@pn_CountryCode", SqlDbType.VarChar, details.CorrespondenceAddress.Country);
                l_objDbWorkItem.AddParameter("@ps_PinCode", SqlDbType.VarChar, details.CorrespondenceAddress.PIN_Code);
                l_objDbWorkItem.AddParameter("@ps_TelNo1", SqlDbType.VarChar, details.CorrespondenceAddress.Tel_Res);
                l_objDbWorkItem.AddParameter("@ps_TelNoOffice", SqlDbType.VarChar, details.CorrespondenceAddress.Tel_Work);
                l_objDbWorkItem.AddParameter("@ps_FaxNo", SqlDbType.VarChar, details.CorrespondenceAddress.Fax_No);
                l_objDbWorkItem.AddParameter("@ps_City", SqlDbType.VarChar, details.CorrespondenceAddress.City);
                l_objDbWorkItem.AddParameter("@pn_StateNumber", SqlDbType.VarChar, details.CorrespondenceAddress.StateCode);
                l_objDbWorkItem.AddParameter("@ps_EMailId", SqlDbType.VarChar, details.CorrespondenceAddress.Email_ID);

                l_objDbWorkItem.AddParameter("@ps_Mobile1", SqlDbType.VarChar, details.CorrespondenceAddress.Mobile_No);
                l_objDbWorkItem.AddParameter("@ps_Mobile2", SqlDbType.VarChar, details.CorrespondenceAddress.Mobile_NoWork);
            }

            l_objDbWorkItem.AddParameter("@ps_SameCorrPermAdd", SqlDbType.VarChar, details.SameCorrPermAdd);


            if (details.SameCorrPermAdd != "Y" && details.PermanentAddress != null)
            {
                l_objDbWorkItem.AddParameter("@pn_PerAddressNo", SqlDbType.Int, details.PermanentAddress.AddressNo == "" ? null : details.PermanentAddress.AddressNo);
                l_objDbWorkItem.AddParameter("@ps_PerAddressLine1", SqlDbType.VarChar, details.PermanentAddress.Address_Line1);
                l_objDbWorkItem.AddParameter("@ps_PerAddressLine2", SqlDbType.VarChar, details.PermanentAddress.Address_Line2);
                l_objDbWorkItem.AddParameter("@ps_PerAddressLine3", SqlDbType.VarChar, details.PermanentAddress.Address_Line3);
                l_objDbWorkItem.AddParameter("@pn_PerCityStateCode", SqlDbType.VarChar, details.PermanentAddress.City);
                l_objDbWorkItem.AddParameter("@ps_PerStateOther", SqlDbType.VarChar, details.PermanentAddress.State_Others);
                l_objDbWorkItem.AddParameter("@pn_PerCountryCode", SqlDbType.VarChar, details.PermanentAddress.Country);
                l_objDbWorkItem.AddParameter("@ps_PerPinCode", SqlDbType.VarChar, details.PermanentAddress.PIN_Code);
                l_objDbWorkItem.AddParameter("@ps_PerTelNo1", SqlDbType.VarChar, details.PermanentAddress.Tel_Res);
                l_objDbWorkItem.AddParameter("@ps_PerCity", SqlDbType.VarChar, details.PermanentAddress.City);
                l_objDbWorkItem.AddParameter("@pn_PerStateNumber", SqlDbType.VarChar, details.PermanentAddress.StateCode);
                l_objDbWorkItem.AddParameter("@ps_PerTelNoOffice", SqlDbType.VarChar, details.PermanentAddress.Tel_Work);
                l_objDbWorkItem.AddParameter("@ps_PerFaxNo", SqlDbType.VarChar, details.PermanentAddress.Fax_No);
                l_objDbWorkItem.AddParameter("@ps_PerMobile1", SqlDbType.VarChar, details.PermanentAddress.Mobile_No);
                l_objDbWorkItem.AddParameter("@ps_PerMobile2", SqlDbType.VarChar, details.PermanentAddress.Mobile_NoWork);
                l_objDbWorkItem.AddParameter("@ps_PerEMailId", SqlDbType.VarChar, details.PermanentAddress.Email_ID);

            }


            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            l_objDbWorkItem.AddParameter("@ps_FristName", SqlDbType.VarChar, details.FristName);
            l_objDbWorkItem.AddParameter("@ps_MiddleName", SqlDbType.VarChar, details.MiddleName);
            l_objDbWorkItem.AddParameter("@ps_LastName", SqlDbType.VarChar, details.LastName);
            l_objDbWorkItem.AddParameter("@ps_SkypeId", SqlDbType.VarChar, details.SkypeId);
            l_objDbWorkItem.AddParameter("@ps_Title", SqlDbType.VarChar, details.Title);
            l_objDbWorkItem.AddParameter("@ps_CallingType", SqlDbType.VarChar, details.CallingType);
            l_objDbWorkItem.AddParameter("@ps_ContractNote_Mode", SqlDbType.Int, details.ContractNote_Mode == "" ? null : details.ContractNote_Mode);
            l_objDbWorkItem.AddParameter("@ps_Education", SqlDbType.Int, details.Education == "" ? null : details.Education);
            l_objDbWorkItem.AddParameter("@ps_VerificationMode", SqlDbType.VarChar, details.VerificationMode);
            l_objDbWorkItem.AddParameter("@ps_Title2", SqlDbType.VarChar, details.Title2);
            l_objDbWorkItem.AddParameter("@ps_MotherName", SqlDbType.VarChar, details.MotherName);
            l_objDbWorkItem.AddParameter("@ps_MaidenName", SqlDbType.VarChar, details.MaidenName);
            l_objDbWorkItem.AddParameter("@pn_StatementPeriodicity", SqlDbType.Int, details.StatementPeriodicity);
            

            if (ErrorMsg == "Y")
                l_objDbWorkItem.AddParameter("@ps_Process", SqlDbType.Char, "P");
            else
                l_objDbWorkItem.AddParameter("@ps_Process", SqlDbType.Char, "A");
            try
            {

                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

                ClientNo = Convert.ToInt32(l_objDbWorkItem.parameters[0].Value);

                ErrorNo = Convert.ToInt32(l_objDbWorkItem.parameters[2].Value);
                if (ErrorNo == 101)
                {
                    ErrorMsg = Convert.ToString(l_objDbWorkItem.parameters[3].Value);
                }
                //To Trap bussiness error for web 
                if (ErrorNo != 0)
                {
                    return new MethodExecResult(ErrorNo, ErrorMsg, "CEntityMaster", null);
                }

                if (ClientNo > 0)
                    details.ClientNo = ClientNo;
                else
                    ClientNo = details.ClientNo;

                int OutPutParamValueDocNo = Convert.ToInt32(l_objDbWorkItem.parameters[1].Value);

                if (OutPutParamValueDocNo > 0)
                    details.EntityPhotoDocNo = OutPutParamValueDocNo;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex);
                return new MethodExecResult(-1, ex.Message, "CEntityMaster", ex);
            }

            return l_objDbWorkItem.ExecutionStatus;
        }
        #endregion

        public DataSet GetBankDetails(string IFSC,string MICR)
        {
            DataSet res = new DataSet();
            DbWorkItem l_objDbWorkItem = new DbWorkItem("sp_GetBankDetail");

            l_objDbWorkItem.ResultType = QueryType.DataSet;



            l_objDbWorkItem.AddParameter("@ps_IFSC", SqlDbType.VarChar, IFSC);
            l_objDbWorkItem.AddParameter("@pn_MICR", SqlDbType.VarChar, MICR);
           
            try
            {
                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
               
                res.Tables.Add(((DataSet)l_objDbWorkItem.Result).Tables[0].Copy());
               
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex);
                //return new MethodExecResult(-1, ex.Message, "CEntityMaster", ex);
            }

            //return l_objDbWorkItem.ExecutionStatus;
            return res;
        }

        #region Withness
        public MethodExecResult UpdateWitness(CWitness details)
        {

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetSetWitnessDetails");

            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, "U");
            l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, details.ClientNo);

            l_objDbWorkItem.AddParameter("@ps_FirstWitnessClientName", SqlDbType.VarChar, details.FirstWitnessName);
            l_objDbWorkItem.AddParameter("@ps_FirstWitnessAddressLine1", SqlDbType.VarChar, details.FirstWithnessAddressLine1);
            l_objDbWorkItem.AddParameter("@ps_FirstWitnessAddressLine2", SqlDbType.VarChar, details.FirstWithnessAddressLine2);
            l_objDbWorkItem.AddParameter("@ps_FirstWitnessAddressLine3", SqlDbType.VarChar, details.FirstWithnessAddressLine3);
            l_objDbWorkItem.AddParameter("@ps_FirstWitnessEMailId", SqlDbType.VarChar, details.FirstWithnessEMailId);
            l_objDbWorkItem.AddParameter("@ps_FirstWitnessMobile", SqlDbType.VarChar, details.FirstWithnessMobile);

            l_objDbWorkItem.AddParameter("@ps_SecondWitnessClientName", SqlDbType.VarChar, details.SecondWitnessName);
            l_objDbWorkItem.AddParameter("@ps_SecondWitnessAddressLine1", SqlDbType.VarChar, details.SecondWithnessAddressLine1);
            l_objDbWorkItem.AddParameter("@ps_SecondWitnessAddressLine2", SqlDbType.VarChar, details.SecondWithnessAddressLine2);
            l_objDbWorkItem.AddParameter("@ps_SecondWitnessAddressLine3", SqlDbType.VarChar, details.SecondWithnessAddressLine3);
            l_objDbWorkItem.AddParameter("@ps_SecondWitnessEMailId", SqlDbType.VarChar, details.SecondWithnessEMailId);
            l_objDbWorkItem.AddParameter("@ps_SecondWitnessMobile", SqlDbType.VarChar, details.SecondWithnessMobile);

             l_objDbWorkItem.AddParameter("@ps_WitnessRequired", SqlDbType.VarChar, details.RequiredWitness);
             l_objDbWorkItem.AddParameter("@pn_WitnessNo", SqlDbType.Int, details.WitnessNo);
            try
            {
                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex);
                return new MethodExecResult(-1, ex.Message, "CEntityMaster", ex);
            }

            return l_objDbWorkItem.ExecutionStatus;
        }

        public static MethodExecResult GetWitnessDetails(int ClientNo, ref DataSet dtResultEntity)
        {

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetSetWitnessDetails");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, ClientNo);
            l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, "S");

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                dtResultEntity = l_objDbWorkItem.Result as DataSet;
                if ((dtResultEntity == null) || (dtResultEntity.Tables.Count == 0))
                    return new MethodExecResult(1, "No data found", "stp_GetSetWitnessDetails. Database returned no data. UserNo. " +
                        AppEnvironment.AppUser.UserNo.ToString(), null);
                else
                {
                    //dtResultEntity = l_dsReturnData.Tables[0];

                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        }


        public static MethodExecResult GetTradingDetails(int ClientNo, ref DataSet dtResultEntity)
        {

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_CCMMasterEntityTradingDtls");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, ClientNo);
            l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, "S");

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                dtResultEntity = l_objDbWorkItem.Result as DataSet;
                if ((dtResultEntity == null) || (dtResultEntity.Tables.Count == 0))
                    return new MethodExecResult(1, "No data found", "stp_CCMMasterEntityTradingDtls. Database returned no data. UserNo. " +
                        AppEnvironment.AppUser.UserNo.ToString(), null);
                else
                {
                    //dtResultEntity = l_dsReturnData.Tables[0];

                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        }

        public static MethodExecResult GetDealingThroughDetail(int ClientNo, ref DataSet dtResultEntity)
        {

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_CCMMasterEntityDealingThroughDtls");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, ClientNo);
            l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, "S");

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                dtResultEntity = l_objDbWorkItem.Result as DataSet;
                if ((dtResultEntity == null) || (dtResultEntity.Tables.Count == 0))
                    return new MethodExecResult(1, "No data found", "stp_CCMMasterEntityDealingThroughDtls. Database returned no data. UserNo. " +
                        AppEnvironment.AppUser.UserNo.ToString(), null);
                else
                {
                    //dtResultEntity = l_dsReturnData.Tables[0];

                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        }
        #endregion

        //public string CheckModified()
        //{

        //    DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_CCMCheckModified");
        //    l_objDbWorkItem.ResultType = QueryType.DataSet;

        //    SqlParameter outParam = new SqlParameter("@pn_NewClientNo", SqlDbType.Int, 8);
        //    outParam.Direction = ParameterDirection.Output;
        //    l_objDbWorkItem.AddParameter(outParam);

        //    return "";
        //}


        /// <summary>
        /// Updates current instance changes to database
        /// </summary>
        /// <returns>Method Execution Result</returns>
        #region Update
        public MethodExecResult UpdateGuardian(EntityDetails details, string operationFlag,
            bool updateEntityDetail, bool updateCorrAddress, bool updatePerAddress)
        {


            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_CCMUpdateEntityGuardian");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            SqlParameter outParam = new SqlParameter("@pn_NewClientNo", SqlDbType.Int, 8);
            outParam.Direction = ParameterDirection.Output;
            l_objDbWorkItem.AddParameter(outParam);

            if (details.ClientNo > 0)
            {
                operationFlag = "M";

            }

            l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.Char, operationFlag);

            l_objDbWorkItem.AddParameter("@pb_UpdateEntityDetails", SqlDbType.Bit, updateEntityDetail);
            l_objDbWorkItem.AddParameter("@pb_UpdateCorrAddress", SqlDbType.Bit, updateCorrAddress);
            l_objDbWorkItem.AddParameter("@pb_UpdatePerAddress", SqlDbType.Bit, updatePerAddress);

            l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, details.ClientNo);
            l_objDbWorkItem.AddParameter("@ps_GuardianName", SqlDbType.VarChar, details.Guardian_Name);
            l_objDbWorkItem.AddParameter("@ps_SpouseName", SqlDbType.VarChar, details.Father_sHusbands_Name);
            l_objDbWorkItem.AddParameter("@ps_Gender", SqlDbType.VarChar, details.Gender);
            l_objDbWorkItem.AddParameter("@pn_Nationality", SqlDbType.Int, details.Nationality);
            l_objDbWorkItem.AddParameter("@ps_NationalityOther", SqlDbType.VarChar, details.NationalityOther);

            if (IsValidDate(details.DOB_OR_DOI))
                l_objDbWorkItem.AddParameter("@pd_DOB", SqlDbType.DateTime, details.DOB_OR_DOI);


            if (details.CorrespondenceAddress != null)
            {
                l_objDbWorkItem.AddParameter("@pn_AddressNo", SqlDbType.Int, details.CorrespondenceAddress.AddressNo);
                l_objDbWorkItem.AddParameter("@ps_AddressLine1", SqlDbType.VarChar, details.CorrespondenceAddress.Address_Line1);
                l_objDbWorkItem.AddParameter("@ps_AddressLine2", SqlDbType.VarChar, details.CorrespondenceAddress.Address_Line2);
                l_objDbWorkItem.AddParameter("@ps_AddressLine3", SqlDbType.VarChar, details.CorrespondenceAddress.Address_Line3);
                l_objDbWorkItem.AddParameter("@pn_CityStateCode", SqlDbType.Int, details.CorrespondenceAddress.City);
                l_objDbWorkItem.AddParameter("@ps_StateOther", SqlDbType.VarChar, details.CorrespondenceAddress.State_Others);
                l_objDbWorkItem.AddParameter("@pn_CountryCode", SqlDbType.Int, details.CorrespondenceAddress.Country);
                l_objDbWorkItem.AddParameter("@ps_PinCode", SqlDbType.VarChar, details.CorrespondenceAddress.PIN_Code);
                l_objDbWorkItem.AddParameter("@ps_TelNo1", SqlDbType.VarChar, details.CorrespondenceAddress.Tel_Res);
                l_objDbWorkItem.AddParameter("@ps_TelNoOffice", SqlDbType.VarChar, details.CorrespondenceAddress.Tel_Work);
                l_objDbWorkItem.AddParameter("@ps_FaxNo", SqlDbType.VarChar, details.CorrespondenceAddress.Fax_No);
                l_objDbWorkItem.AddParameter("@ps_City", SqlDbType.VarChar, details.CorrespondenceAddress.City);
                l_objDbWorkItem.AddParameter("@pn_StateNumber", SqlDbType.Int, details.CorrespondenceAddress.StateCode);
                l_objDbWorkItem.AddParameter("@ps_EMailId", SqlDbType.VarChar, details.CorrespondenceAddress.Email_ID);

                l_objDbWorkItem.AddParameter("@ps_Mobile1", SqlDbType.VarChar, details.CorrespondenceAddress.Mobile_No);
                l_objDbWorkItem.AddParameter("@ps_Mobile2", SqlDbType.VarChar, details.CorrespondenceAddress.Mobile_NoWork);
            }

            l_objDbWorkItem.AddParameter("@ps_SameCorrPermAdd", SqlDbType.VarChar, details.SameCorrPermAdd);


            if (details.SameCorrPermAdd != "Y" && details.PermanentAddress != null)
            {
                l_objDbWorkItem.AddParameter("@pn_PerAddressNo", SqlDbType.Int, details.PermanentAddress.AddressNo);
                l_objDbWorkItem.AddParameter("@ps_PerAddressLine1", SqlDbType.VarChar, details.PermanentAddress.Address_Line1);
                l_objDbWorkItem.AddParameter("@ps_PerAddressLine2", SqlDbType.VarChar, details.PermanentAddress.Address_Line2);
                l_objDbWorkItem.AddParameter("@ps_PerAddressLine3", SqlDbType.VarChar, details.PermanentAddress.Address_Line3);
                l_objDbWorkItem.AddParameter("@pn_PerCityStateCode", SqlDbType.Int, details.PermanentAddress.StateCode);

                l_objDbWorkItem.AddParameter("@ps_PerStateOther", SqlDbType.VarChar, details.PermanentAddress.State_Others);
                l_objDbWorkItem.AddParameter("@pn_PerCountryCode", SqlDbType.Int, details.PermanentAddress.Country);
                l_objDbWorkItem.AddParameter("@ps_PerPinCode", SqlDbType.VarChar, details.PermanentAddress.PIN_Code);
                l_objDbWorkItem.AddParameter("@ps_PerTelNo1", SqlDbType.VarChar, details.PermanentAddress.Tel_Res);
                l_objDbWorkItem.AddParameter("@ps_PerCity", SqlDbType.VarChar, details.PermanentAddress.City);
                l_objDbWorkItem.AddParameter("@pn_PerStateNumber", SqlDbType.Int, details.PermanentAddress.StateCode);
                l_objDbWorkItem.AddParameter("@ps_PerTelNoOffice", SqlDbType.VarChar, details.PermanentAddress.Tel_Work);
                l_objDbWorkItem.AddParameter("@ps_PerFaxNo", SqlDbType.VarChar, details.PermanentAddress.Fax_No);
                l_objDbWorkItem.AddParameter("@ps_PerMobile1", SqlDbType.VarChar, details.PermanentAddress.Mobile_No);
                l_objDbWorkItem.AddParameter("@ps_PerMobile2", SqlDbType.VarChar, details.PermanentAddress.Mobile_NoWork);
                l_objDbWorkItem.AddParameter("@ps_PerEMailId", SqlDbType.VarChar, details.PermanentAddress.Email_ID);

            }

            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

            ClientNo = Convert.ToInt32(l_objDbWorkItem.parameters[0].Value);
            details.ClientNo = ClientNo;

            return l_objDbWorkItem.ExecutionStatus;
        }



        public MethodExecResult UpdateClientPreferences(string operationFlag, int ClientNo, COperationPreference Preference)
        { 
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_CCMUpdateClientPreferences");
            l_objDbWorkItem.ResultType = QueryType.DataSet; 

            l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, operationFlag);
            l_objDbWorkItem.AddParameter("@pn_PreferenceNo", SqlDbType.Int, Preference.PreferenceNo);
            l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, Preference.ClientNo);
            l_objDbWorkItem.AddParameter("@ps_G3", SqlDbType.VarChar, Preference.G3);
            l_objDbWorkItem.AddParameter("@ps_FmlyGroupCode", SqlDbType.VarChar, Preference.FmlyGroupCode);
            l_objDbWorkItem.AddParameter("@ps_PreferenceCode", SqlDbType.VarChar, Preference.PreferenceCode);
            l_objDbWorkItem.AddParameter("@ps_Charge", SqlDbType.VarChar, Preference.Charge);
            l_objDbWorkItem.AddParameter("@ps_BrokMethod", SqlDbType.VarChar, Preference.BrokMethod);
            l_objDbWorkItem.AddParameter("@ps_BrokSlab", SqlDbType.VarChar, Preference.BrokSlab);
            l_objDbWorkItem.AddParameter("@ps_AllowtoBrok", SqlDbType.VarChar, Preference.AllowtoBrok);
            l_objDbWorkItem.AddParameter("@ps_IntRate", SqlDbType.Money, Preference.IntRate);
            l_objDbWorkItem.AddParameter("@ps_POA", SqlDbType.VarChar, Preference.POA);
            l_objDbWorkItem.AddParameter("@ps_RunningClient", SqlDbType.VarChar, Preference.RunningClient);
            l_objDbWorkItem.AddParameter("@ps_TradeClub", SqlDbType.VarChar, Preference.TradeClub);
            l_objDbWorkItem.AddParameter("@ps_PaymentMode", SqlDbType.VarChar, Preference.PaymentMode);
            l_objDbWorkItem.AddParameter("@ps_GlobalPreference", SqlDbType.VarChar, Preference.GlobalPreference);
            l_objDbWorkItem.AddParameter("@ps_IncludeSTinBrok", SqlDbType.VarChar, Preference.IncludeSTinBrok);
            l_objDbWorkItem.AddParameter("@ps_IncludeTOInBrok", SqlDbType.VarChar, Preference.IncludeTOInBrok);
            l_objDbWorkItem.AddParameter("@ps_IncludeSTTinBrok", SqlDbType.VarChar, Preference.IncludeSTTinBrok);
            l_objDbWorkItem.AddParameter("@ps_IncludeSDinBrok", SqlDbType.VarChar, Preference.IncludeSDinBrok);
            l_objDbWorkItem.AddParameter("@ps_IncludeSEBIInBrok", SqlDbType.VarChar, Preference.IncludeSEBIInBrok);
            l_objDbWorkItem.AddParameter("@ps_IncludeCFinBrok", SqlDbType.VarChar, Preference.IncludeCFinBrok);
            l_objDbWorkItem.AddParameter("@ps_IncludeCCinBrok", SqlDbType.VarChar, Preference.IncludeCCinBrok);
            l_objDbWorkItem.AddParameter("@ps_IncludeAuctionPenalInBrkg", SqlDbType.Char, Preference.IncludeAuctionPenalInBrkg);
            l_objDbWorkItem.AddParameter("@ps_ServProvider", SqlDbType.VarChar, Preference.ServProvider);
            l_objDbWorkItem.AddParameter("@ps_FlatISO", SqlDbType.VarChar, Preference.FlatISO);
            l_objDbWorkItem.AddParameter("@ps_Format", SqlDbType.VarChar, Preference.Format);
            l_objDbWorkItem.AddParameter("@ps_DownloadFor", SqlDbType.VarChar, Preference.DownloadFor);
            l_objDbWorkItem.AddParameter("@ps_ContractNoGen", SqlDbType.VarChar, Preference.ContractNoGen);
            l_objDbWorkItem.AddParameter("@ps_ContractFormType", SqlDbType.VarChar, Preference.ContractFormType); 
            l_objDbWorkItem.AddParameter("@ps_StockTransfer", SqlDbType.VarChar, Preference.StockTransfer);
            l_objDbWorkItem.AddParameter("@ps_ChargeDeliveryCharges", SqlDbType.VarChar, Preference.ChargeDeliveryCharges);
            l_objDbWorkItem.AddParameter("@ps_RegionMapping", SqlDbType.VarChar, Preference.RegionMapping);
            l_objDbWorkItem.AddParameter("@ps_BeforePayinFunds", SqlDbType.VarChar, Preference.BeforePayinFunds);
            l_objDbWorkItem.AddParameter("@ps_BeforePayinSecurities", SqlDbType.VarChar, Preference.BeforePayinSecurities);
            l_objDbWorkItem.AddParameter("@ps_AfterPayoutFunds", SqlDbType.VarChar, Preference.AfterPayoutFunds);
            l_objDbWorkItem.AddParameter("@ps_AfterPayoutSecurities", SqlDbType.VarChar, Preference.AfterPayoutSecurities);
            l_objDbWorkItem.AddParameter("@ps_SettlementOn", SqlDbType.VarChar, Preference.SettlementOn);
            l_objDbWorkItem.AddParameter("@ps_BillGeneration", SqlDbType.VarChar, Preference.BillGeneration);
            l_objDbWorkItem.AddParameter("@ps_BillNoGen", SqlDbType.VarChar, Preference.BillNoGen);
            l_objDbWorkItem.AddParameter("@ps_SettDateOnContract", SqlDbType.VarChar, Preference.SettDateOnContract);
            l_objDbWorkItem.AddParameter("@ps_Bills", SqlDbType.VarChar, Preference.Bills);
            l_objDbWorkItem.AddParameter("@ps_Contracts", SqlDbType.VarChar, Preference.Contracts);

            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
             
            return l_objDbWorkItem.ExecutionStatus;
        }


        #endregion

        /// <summary>
        /// Get EntityDetails Object by filtering DataTable
        /// </summary>
        /// <param name="IdentifierNo">Entity/Row No</param>
        /// <param name="ByRowNo">If search by RowNo</param>
        /// <returns>EntityDetails object</returns>
        public EntityDetails GetEntityDetailsByNo(int IdentifierNo, bool ByRowNo)
        {
            int nRowNo = 0;
            int nClientNo;
            DataTable dtEntity = new DataTable();
            DataTable dtAdd = new DataTable();
            DataRow[] filteredRow = null;

            DataRow[] filteredAddressRow = null;
            EntityDetails entityDetailsObj;
            try
            {
                string sSelectColum = ByRowNo == true ? ROWNO : CLIENTNO;



                if ((EntityDataTable != null))
                {

                    filteredRow = EntityDataTable
                    .Select(sSelectColum + "=" + IdentifierNo);

                    if (ByRowNo == false)
                    {
                        nRowNo = Convert.ToInt32(Utility.GetValueFromDataRow(filteredRow[0], ROWNO));
                        nClientNo = IdentifierNo;
                    }
                    else
                    {
                        nClientNo = Convert.ToInt32(Utility.GetValueFromDataRow(filteredRow[0], CLIENTNO));
                        nRowNo = IdentifierNo;
                    }

                    MethodExecResult objMethodExecResult = GetEntitybyClientNo(nClientNo, ref dtEntity, ref dtAdd);


                    if (objMethodExecResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
                    {
                        string sErrorMessage = "Unable to fetch data." + Environment.NewLine + objMethodExecResult.ErrorMessage;
                        Logger.Instance.WriteLog(this, sErrorMessage);

                        throw new Exception(sErrorMessage);
                    }


                    for (int iCnt = 0; iCnt <= dtAdd.Rows.Count - 1; iCnt++)
                        dtAdd.Rows[iCnt]["n_RowNo"] = nRowNo;


                    EntityAddressDataTable = dtAdd;


                    if (dtEntity.Rows.Count > 0 && nRowNo != 0)
                    {
                        //EntityDataTable.Rows[nRowNo - 1]["n_ClientNo"] = dtEntity.Rows[0]["n_ClientNo"];
                        //EntityDataTable.Rows[nRowNo - 1]["s_CustId"] = dtEntity.Rows[0]["s_CustId"];
                        //EntityDataTable.Rows[nRowNo - 1]["s_KYCRefCode"] = dtEntity.Rows[0]["s_KYCRefCode"];
                        EntityDataTable.Rows[nRowNo - 1]["s_KYCFormRefCode"] = dtEntity.Rows[0]["s_KYCFormRefCode"];
                        EntityDataTable.Rows[nRowNo - 1]["s_ClientType"] = dtEntity.Rows[0]["s_ClientType"];
                        EntityDataTable.Rows[nRowNo - 1]["s_ClientCode"] = dtEntity.Rows[0]["s_ClientCode"];
                        EntityDataTable.Rows[nRowNo - 1]["s_ClientTypeText"] = dtEntity.Rows[0]["s_ClientTypeText"];
                        EntityDataTable.Rows[nRowNo - 1]["s_ClientName"] = dtEntity.Rows[0]["s_ClientName"];
                        EntityDataTable.Rows[nRowNo - 1]["s_PANNo"] = dtEntity.Rows[0]["s_PANNo"];
                        EntityDataTable.Rows[nRowNo - 1]["s_Gender"] = dtEntity.Rows[0]["s_Gender"];
                        EntityDataTable.Rows[nRowNo - 1]["s_GenderText"] = CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.GENDER, dtEntity.Rows[0]["s_Gender"].ToString());//dtEntity.Rows[0]["s_Gender"].ToString() == "M" ? "Male" : "Female";//dtEntity.Rows[0]["s_GenderText"];
                        EntityDataTable.Rows[nRowNo - 1]["s_GuardianName"] = dtEntity.Rows[0]["s_GuardianName"];
                        EntityDataTable.Rows[nRowNo - 1]["s_MaritalStatus"] = dtEntity.Rows[0]["s_MaritalStatus"];
                        EntityDataTable.Rows[nRowNo - 1]["s_MaritalStatusText"] = dtEntity.Rows[0]["s_MaritalStatusText"];
                        EntityDataTable.Rows[nRowNo - 1]["n_Nationality"] = dtEntity.Rows[0]["n_Nationality"];
                        EntityDataTable.Rows[nRowNo - 1]["s_Nationality"] = dtEntity.Rows[0]["s_Nationality"];
                        EntityDataTable.Rows[nRowNo - 1]["s_NationalityOther"] = dtEntity.Rows[0]["s_NationalityOther"];
                        EntityDataTable.Rows[nRowNo - 1]["s_PanExempt"] = dtEntity.Rows[0]["s_PanExempt"];
                        EntityDataTable.Rows[nRowNo - 1]["s_CorporateIdNo"] = dtEntity.Rows[0]["s_CorporateIdNo"];
                        EntityDataTable.Rows[nRowNo - 1]["d_DOB"] = dtEntity.Rows[0]["d_DOB"];
                        EntityDataTable.Rows[nRowNo - 1]["d_CreationDate"] = dtEntity.Rows[0]["d_CreationDate"];
                        EntityDataTable.Rows[nRowNo - 1]["n_NetWorth"] = dtEntity.Rows[0]["n_NetWorth"];
                        EntityDataTable.Rows[nRowNo - 1]["d_NetWorthAsOnDate"] = dtEntity.Rows[0]["d_NetWorthAsOnDate"];
                        EntityDataTable.Rows[nRowNo - 1]["n_GrAnnIncRange"] = dtEntity.Rows[0]["n_GrAnnIncRange"];
                        EntityDataTable.Rows[nRowNo - 1]["d_GrAnnIncAsOnDate"] = dtEntity.Rows[0]["d_GrAnnIncAsOnDate"];
                        EntityDataTable.Rows[nRowNo - 1]["n_PEP"] = dtEntity.Rows[0]["n_PEP"];
                        EntityDataTable.Rows[nRowNo - 1]["s_PlaceofIncorporation"] = dtEntity.Rows[0]["s_PlaceofIncorporation"];
                        EntityDataTable.Rows[nRowNo - 1]["n_Occupation"] = dtEntity.Rows[0]["n_Occupation"];
                        EntityDataTable.Rows[nRowNo - 1]["s_OccupationText"] = dtEntity.Rows[0]["s_OccupationText"];
                        EntityDataTable.Rows[nRowNo - 1]["s_OccupationOthers"] = dtEntity.Rows[0]["s_OccupationOthers"];
                        EntityDataTable.Rows[nRowNo - 1]["d_CommOfBusiness"] = dtEntity.Rows[0]["d_CommOfBusiness"];
                        EntityDataTable.Rows[nRowNo - 1]["s_CINExempt"] = dtEntity.Rows[0]["s_CINExempt"];
                        EntityDataTable.Rows[nRowNo - 1]["s_TypeofFacility"] = dtEntity.Rows[0]["s_TypeofFacility"];
                        EntityDataTable.Rows[nRowNo - 1]["n_LastUserNo"] = dtEntity.Rows[0]["n_LastUserNo"];
                        EntityDataTable.Rows[nRowNo - 1]["d_LastModifiedDateTime"] = dtEntity.Rows[0]["d_LastModifiedDateTime"];
                        EntityDataTable.Rows[nRowNo - 1]["n_MakerUser"] = dtEntity.Rows[0]["n_MakerUser"];
                        EntityDataTable.Rows[nRowNo - 1]["s_AuthorizedStatus"] = dtEntity.Rows[0]["s_AuthorizedStatus"];
                        EntityDataTable.Rows[nRowNo - 1]["s_SameCorrPermAdd"] = dtEntity.Rows[0]["s_SameCorrPermAdd"];
                        EntityDataTable.Rows[nRowNo - 1]["n_Status"] = dtEntity.Rows[0]["n_Status"];
                        EntityDataTable.Rows[nRowNo - 1]["s_StatusOther"] = dtEntity.Rows[0]["s_StatusOther"];
                        EntityDataTable.Rows[nRowNo - 1]["s_PEPDesc"] = dtEntity.Rows[0]["s_PEPDesc"];
                        EntityDataTable.Rows[nRowNo - 1]["s_UserId"] = dtEntity.Rows[0]["s_UserId"];
                        EntityDataTable.Rows[nRowNo - 1]["s_AuthorizationRemarks"] = dtEntity.Rows[0]["s_AuthorizationRemarks"];
                        EntityDataTable.Rows[nRowNo - 1][DEFAULTIDDETAILS] = dtEntity.Rows[0][DEFAULTIDDETAILS];

                        EntityDataTable.Rows[nRowNo - 1]["n_EntityPhotoDocNo"] = dtEntity.Rows[0]["n_EntityPhotoDocNo"];

                        dLastModifiedDate = Convert.ToDateTime(dtEntity.Rows[0]["d_LastModifiedDateTime"]);

                        EntityDataTable.Rows[nRowNo - 1]["n_Solutation"] = dtEntity.Rows[0]["n_Solutation"];
                        EntityDataTable.Rows[nRowNo - 1]["SelfAuth"] = dtEntity.Rows[0]["SelfAuth"];
                        EntityDataTable.Rows[nRowNo - 1]["sTaxDeductionStatus"] = dtEntity.Rows[0]["sTaxDeductionStatus"];
                        EntityDataTable.Rows[nRowNo - 1]["SEBIRegistration"] = dtEntity.Rows[0]["SEBIRegistration"];
                        EntityDataTable.Rows[nRowNo - 1]["StandingInstruction"] = dtEntity.Rows[0]["StandingInstruction"];
                        EntityDataTable.Rows[nRowNo - 1]["SubType"] = dtEntity.Rows[0]["SubType"];

                        EntityDataTable.Rows[nRowNo - 1]["Branch"] = dtEntity.Rows[0]["Branch"];
                        EntityDataTable.Rows[nRowNo - 1]["ShortCode"] = dtEntity.Rows[0]["ShortCode"];
                        EntityDataTable.Rows[nRowNo - 1]["ParentAccNo"] = dtEntity.Rows[0]["ParentAccNo"];
                        EntityDataTable.Rows[nRowNo - 1]["IsParentAccount"] = dtEntity.Rows[0]["IsParentAccount"];
                        EntityDataTable.Rows[nRowNo - 1]["n_StatementPeriodicity"] = dtEntity.Rows[0]["n_StatementPeriodicity"];
                    }
                }


                if ((EntityAddressDataTable != null))
                {
                    filteredAddressRow = EntityAddressDataTable
                    .Select(sSelectColum + "=" + IdentifierNo);

                    if (dtAdd.Rows.Count > 0 && nRowNo != 0)
                    {
                        //////EntityAddressDataTable.Rows[nRowNo - 1]["n_ClientNo"] = dtAdd.Rows[0]["n_ClientNo"];
                        //////EntityAddressDataTable.Rows[nRowNo - 1]["n_AddressNo"] = dtAdd.Rows[0]["n_AddressNo"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_AddressLine1"] = dtAdd.Rows[0]["s_AddressLine1"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_AddressLine2"] = dtAdd.Rows[0]["s_AddressLine2"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_AddressLine3"] = dtAdd.Rows[0]["s_AddressLine3"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_AddressLine4"] = dtAdd.Rows[0]["s_AddressLine4"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["n_CityStateCode"] = dtAdd.Rows[0]["n_CityStateCode"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_City"] = dtAdd.Rows[0]["s_City"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_PinCode"] = dtAdd.Rows[0]["s_PinCode"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["n_StateNumber"] = dtAdd.Rows[0]["n_StateNumber"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_StateOther"] = dtAdd.Rows[0]["s_StateOther"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["n_CountryCode"] = dtAdd.Rows[0]["n_CountryCode"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_TelNoISDCode"] = dtAdd.Rows[0]["s_TelNoISDCode"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_TelNoSTDCode"] = dtAdd.Rows[0]["s_TelNoSTDCode"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_TelNo1"] = dtAdd.Rows[0]["s_TelNo1"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_TelNoOfficeISDCode"] = dtAdd.Rows[0]["s_TelNoOfficeISDCode"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_TelNoOfficeSTDCode"] = dtAdd.Rows[0]["s_TelNoOfficeSTDCode"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_TelNoOffice"] = dtAdd.Rows[0]["s_TelNoOffice"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_Mobile1"] = dtAdd.Rows[0]["s_Mobile1"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_Mobile2"] = dtAdd.Rows[0]["s_Mobile2"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_FaxNoISDCode"] = dtAdd.Rows[0]["s_FaxNoISDCode"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_FaxNoSTDCode"] = dtAdd.Rows[0]["s_FaxNoSTDCode"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_FaxNo"] = dtAdd.Rows[0]["s_FaxNo"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_EMailId"] = dtAdd.Rows[0]["s_EMailId"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["n_PerAddressNo"] = dtAdd.Rows[0]["n_PerAddressNo"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_PerAddressLine1"] = dtAdd.Rows[0]["s_PerAddressLine1"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_PerAddressLine2"] = dtAdd.Rows[0]["s_PerAddressLine2"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_PerAddressLine3"] = dtAdd.Rows[0]["s_PerAddressLine3"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_PerAddressLine4"] = dtAdd.Rows[0]["s_PerAddressLine4"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["n_PerCityStateCode"] = dtAdd.Rows[0]["n_PerCityStateCode"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_PerCity"] = dtAdd.Rows[0]["s_PerCity"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_PerPinCode"] = dtAdd.Rows[0]["s_PerPinCode"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["n_PerStateNumber"] = dtAdd.Rows[0]["n_PerStateNumber"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_PerStateOther"] = dtAdd.Rows[0]["s_PerStateOther"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["n_PerCountryCode"] = dtAdd.Rows[0]["n_PerCountryCode"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_PerTelNoISDCode"] = dtAdd.Rows[0]["s_PerTelNoISDCode"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_PerTelNoSTDCode"] = dtAdd.Rows[0]["s_PerTelNoSTDCode"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_PerTelNo1"] = dtAdd.Rows[0]["s_PerTelNo1"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_PerTelNoOfficeISDCode"] = dtAdd.Rows[0]["s_PerTelNoOfficeISDCode"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_PerTelNoOfficeSTDCode"] = dtAdd.Rows[0]["s_PerTelNoOfficeSTDCode"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_PerTelNoOffice"] = dtAdd.Rows[0]["s_PerTelNoOffice"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_PerMobile1"] = dtAdd.Rows[0]["s_PerMobile1"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_PerMobile2"] = dtAdd.Rows[0]["s_PerMobile2"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_PerFaxNoISDCode"] = dtAdd.Rows[0]["s_PerFaxNoISDCode"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_PerFaxNoSTDCode"] = dtAdd.Rows[0]["s_PerFaxNoSTDCode"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_PerFaxNo"] = dtAdd.Rows[0]["s_PerFaxNo"];
                        ////EntityAddressDataTable.Rows[nRowNo - 1]["s_PerEMailId"] = dtAdd.Rows[0]["s_PerEMailId"];
                    }
                }
                if (filteredRow.Length == 0) return null;
                entityDetailsObj = GetEntityDetailsByDataRow(filteredRow[0], filteredAddressRow[0]);
                return entityDetailsObj;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                entityDetailsObj = new EntityDetails();
                entityDetailsObj.sErrorMsg = ex.Message;
                return entityDetailsObj;
            }

        }


        /// <summary>
        /// Get EntityDetails object by provided datarow
        /// </summary>
        /// <param name="rowEntity">Entity DataRow</param>
        /// <param name="rowAddress">Address Details datarow</param>
        /// <returns>Entity object</returns>
        public static EntityDetails GetEntityDetailsByDataRow(DataRow rowEntity, DataRow rowAddress)
        {
            if (rowEntity == null) return null;

            EntityDetails entityDetailsObj = new EntityDetails();
            try
            {
                entityDetailsObj.RowNo = Convert.ToInt32(Utility.GetValueFromDataRow(rowEntity, ROWNO));

                entityDetailsObj.ClientNo = Convert.ToInt32(Utility.GetValueFromDataRow(rowEntity, CLIENTNO));
                entityDetailsObj.EntityPhotoDocNo = Convert.ToInt32(Utility.GetValueFromDataRow(rowEntity, ENTITYPHOTODOCNO));


                entityDetailsObj.Applicant_Name = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, CLIENTNAME));
                entityDetailsObj.CIN = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, CORPORATEIDNO));
                entityDetailsObj.KYCCode = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, KYCREFCODE));
                entityDetailsObj.EntityId = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, CLIENTCODE));
                entityDetailsObj.EntityType = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, CLIENTTYPE));
                entityDetailsObj.Father_sHusbands_Name = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, GUARDIANNAME));
                entityDetailsObj.Gender = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, GENDER));
                entityDetailsObj.Marital_status = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, MARITALSTATUS));
                entityDetailsObj.Nationality = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, NATIONALITY));
                entityDetailsObj.NationalityOther = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, NATIONALITYOTHER));
                entityDetailsObj.Occupation = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, OCCUPATION));
                entityDetailsObj.OccupationOther = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, OCCUPATIONOTHERS));
                entityDetailsObj.PAN = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, PANNO));
                entityDetailsObj.AnnualIncome = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, GRANNINCRANGE));
                entityDetailsObj.AnnualIncomeDate = Convert.ToDateTime(Utility.GetValueFromDataRow(rowEntity, GRANNINCASONDATE));
                entityDetailsObj.NetworthDate = Convert.ToDateTime(Utility.GetValueFromDataRow(rowEntity, NETWORTHASONDATE));
                entityDetailsObj.Networth = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, NETWORTH));
                entityDetailsObj.PEP = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, PEP));
                entityDetailsObj.PEPDesc = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, PEPDESC));
                entityDetailsObj.UserId = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, USERID));
                entityDetailsObj.FacilityType = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, TYPEOFFACILITY));
                entityDetailsObj.KYCFormNo = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, KYCFORMREFCODE));
                entityDetailsObj.CustomerID = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, CUSTID));


                entityDetailsObj.PlaceOfIncorpration = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, PLACEOFINCORPORATION));

                entityDetailsObj.StatusText = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, STATUSOTHER));
                entityDetailsObj.StatusNonIndVal = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, STATUSCODE));
                entityDetailsObj.DateOfBusinessComm = Convert.ToDateTime(Utility.GetValueFromDataRow(rowEntity, COMMOFBUSINESS));



                entityDetailsObj.DOB_OR_DOI = Convert.ToDateTime(Utility.GetValueFromDataRow(rowEntity, DOB));
                entityDetailsObj.DateOfCreation = Convert.ToDateTime(Utility.GetValueFromDataRow(rowEntity, CREATIONDATE));

                entityDetailsObj.SameCorrPermAdd = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, SAMECORRPERMADD));

                entityDetailsObj.AuthrizationStatus = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, AUTHORIZEDSTATUS));
                entityDetailsObj.AuthRemarks = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, AUTHORIZATIONREMARKS));
                entityDetailsObj.MakerUserNo = Convert.ToInt32((Utility.GetValueFromDataRow(rowEntity, MAKERUSER)));
                entityDetailsObj.DefaultIDDetails = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, DEFAULTIDDETAILS));
                entityDetailsObj.PANExempt = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, PANEXEMPT));

                entityDetailsObj.n_Solutation = Convert.ToInt32((Utility.GetValueFromDataRow(rowEntity, n_Solutation)));
                entityDetailsObj.SelfAuth = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, SelfAuth));
                entityDetailsObj.TaxDeductionStatus = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, sTaxDeductionStatus));
                entityDetailsObj.SEBIRegistration = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, SEBIRegistration));
                entityDetailsObj.StandingInstruction = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, StandingInstruction));
                entityDetailsObj.sSubType = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, SubType));
                entityDetailsObj.LastUpdatedUserNo = Convert.ToInt32(Utility.GetValueFromDataRow(rowEntity, LastUpdatedUserNo));
                entityDetailsObj.StatementPeriodicity = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, STATEMENTPERIODICITY));

                if (entityDetailsObj.sSubType != null && entityDetailsObj.sSubType != "")
                {
                    entityDetailsObj.sSubType = Convert.ToInt32(entityDetailsObj.sSubType) < 10 ? "0" + entityDetailsObj.sSubType : entityDetailsObj.sSubType;
                }

                //Changes as per CDD Phase 2
                entityDetailsObj.Branch = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, Branch));
                entityDetailsObj.Short_Code = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, ShortCode));
                entityDetailsObj.Parent_Account_No = Convert.ToInt32(Utility.GetValueFromDataRow(rowEntity, ParentAccNo));
                entityDetailsObj.IS_Parent_Accont = Convert.ToString(Utility.GetValueFromDataRow(rowEntity, IsParentAccount));




                Address addrCorrsponde = new Address();

                addrCorrsponde.Address_Line1 = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, ADDRESSLINE1));
                addrCorrsponde.Address_Line2 = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, ADDRESSLINE2));
                addrCorrsponde.Address_Line3 = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, ADDRESSLINE3));

                addrCorrsponde.City = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, CITYSTATECODE));
                addrCorrsponde.Country = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, COUNTRYCODE));
                addrCorrsponde.Email_ID = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, EMAILID));
                addrCorrsponde.Fax_No = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, FAXNO));
                addrCorrsponde.Mobile_No = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, MOBILE1));
                addrCorrsponde.Mobile_NoWork = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, MOBILE2));
                addrCorrsponde.Tel_Res = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, TELNO1));
                addrCorrsponde.Tel_Work = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, TELNOOFFICE));


                addrCorrsponde.PIN_Code = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, PINCODE));
                addrCorrsponde.State_Others = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, STATEOTHER));
                addrCorrsponde.StateCode = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, STATENUMBER));

                entityDetailsObj.CorrespondenceAddress = addrCorrsponde;

                if (entityDetailsObj.SameCorrPermAdd != "Y")
                {

                    Address perAdd = new Address();

                    perAdd.Address_Line1 = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, PERADDRESSLINE1));
                    perAdd.Address_Line2 = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, PERADDRESSLINE2));
                    perAdd.Address_Line3 = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, PERADDRESSLINE3));

                    perAdd.City = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, PERCITYSTATECODE));
                    perAdd.Country = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, PERCOUNTRYCODE));
                    perAdd.Email_ID = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, PEREMAILID));
                    perAdd.Fax_No = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, PERFAXNO));
                    perAdd.Mobile_No = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, PERMOBILE1));
                    perAdd.Mobile_NoWork = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, PERMOBILE2));
                    perAdd.PIN_Code = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, PERPINCODE));
                    perAdd.State_Others = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, PERSTATEOTHER));
                    perAdd.StateCode = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, PERSTATENUMBER));
                    perAdd.Tel_Res = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, PERTELNO1));
                    perAdd.Tel_Work = Convert.ToString(Utility.GetValueFromDataRow(rowAddress, PERTELNOOFFICE));

                    entityDetailsObj.PermanentAddress = perAdd;
                }
                else
                {
                    entityDetailsObj.PermanentAddress = addrCorrsponde;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return entityDetailsObj;
            }

            return entityDetailsObj;
        }


        /// <summary>
        /// Get Entity Gaurdian Details
        /// </summary>
        /// <param name="nClientNo">ClientNo</param>
        /// <returns>EntityDetails</returns>
        public EntityDetails GetEntityGaurdianDetails(int nClientNo)
        {
            DataTable dtGuardianDtls;
            dtGuardianDtls = new DataTable();
            EntityDetails objEntityGuardianDtl = new EntityDetails();
            try
            {
                GetRemoveEntityGuardianDetails(nClientNo, "S", ref dtGuardianDtls);

                DataRow[] filteredRow = null;
                DataRow[] filteredAddressRow = null;
                string sSelectColum = CLIENTNO;

                if ((dtGuardianDtls != null))
                {
                    filteredRow = dtGuardianDtls.Select(sSelectColum + "=" + nClientNo);
                }

                if ((dtGuardianDtls != null))
                {
                    filteredAddressRow = dtGuardianDtls.Select(sSelectColum + "=" + nClientNo);
                }

                if (filteredRow.Length == 0) return null;


                objEntityGuardianDtl.ClientNo = Convert.ToInt32(Utility.GetValueFromDataRow(filteredRow[0], CLIENTNO));
                objEntityGuardianDtl.Applicant_Name = Convert.ToString(Utility.GetValueFromDataRow(filteredRow[0], CLIENTNAME));

                objEntityGuardianDtl.Father_sHusbands_Name = Convert.ToString(Utility.GetValueFromDataRow(filteredRow[0], GUARDIANNAME));
                objEntityGuardianDtl.Gender = Convert.ToString(Utility.GetValueFromDataRow(filteredRow[0], GENDER));
                objEntityGuardianDtl.Nationality = Convert.ToString(Utility.GetValueFromDataRow(filteredRow[0], NATIONALITY));
                objEntityGuardianDtl.NationalityOther = Convert.ToString(Utility.GetValueFromDataRow(filteredRow[0], NATIONALITYOTHER));

                objEntityGuardianDtl.DOB_OR_DOI = Convert.ToDateTime(Utility.GetValueFromDataRow(filteredRow[0], DOB));
                objEntityGuardianDtl.SameCorrPermAdd = Convert.ToString(Utility.GetValueFromDataRow(filteredRow[0], SAMECORRPERMADD));

                Address addrCorrsponde = new Address();
                addrCorrsponde.Address_Line1 = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], ADDRESSLINE1));
                addrCorrsponde.Address_Line2 = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], ADDRESSLINE2));
                addrCorrsponde.Address_Line3 = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], ADDRESSLINE3));

                addrCorrsponde.City = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], CITY));
                addrCorrsponde.Country = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], COUNTRYCODE));
                addrCorrsponde.Email_ID = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], EMAILID));
                addrCorrsponde.Fax_No = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], FAXNO));
                addrCorrsponde.Mobile_No = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], MOBILE1));
                addrCorrsponde.Mobile_NoWork = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], MOBILE2));
                addrCorrsponde.Tel_Res = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], TELNO1));
                addrCorrsponde.Tel_Work = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], TELNOOFFICE));

                addrCorrsponde.PIN_Code = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], PINCODE));
                addrCorrsponde.State_Others = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], STATEOTHER));
                addrCorrsponde.StateCode = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], STATENUMBER));

                objEntityGuardianDtl.CorrespondenceAddress = addrCorrsponde;

                if (objEntityGuardianDtl.SameCorrPermAdd != "Y")
                {

                    Address perAdd = new Address();

                    perAdd.Address_Line1 = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], PERADDRESSLINE1));
                    perAdd.Address_Line2 = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], PERADDRESSLINE2));
                    perAdd.Address_Line3 = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], PERADDRESSLINE3));

                    perAdd.City = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], PERCITY));
                    perAdd.Country = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], PERCOUNTRYCODE));
                    perAdd.Email_ID = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], PEREMAILID));
                    perAdd.Fax_No = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], PERFAXNO));
                    perAdd.Mobile_No = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], PERMOBILE1));
                    perAdd.Mobile_NoWork = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], PERMOBILE2));
                    perAdd.PIN_Code = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], PERPINCODE));
                    perAdd.State_Others = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], PERSTATEOTHER));
                    perAdd.StateCode = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], PERSTATENUMBER));
                    perAdd.Tel_Res = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], PERTELNO1));
                    perAdd.Tel_Work = Convert.ToString(Utility.GetValueFromDataRow(filteredAddressRow[0], PERTELNOOFFICE));

                    objEntityGuardianDtl.PermanentAddress = perAdd;
                }
                else
                {
                    objEntityGuardianDtl.PermanentAddress = addrCorrsponde;
                }

                return objEntityGuardianDtl;

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return objEntityGuardianDtl;
            }
        }
        /// <summary>
        /// Assign Display text from ReferenceCode
        /// </summary>
        private void ProcessDataTable()
        {
            if (EntityDataTable == null) return;

            for (int i = 0; i < EntityDataTable.Rows.Count; i++)
            {
                string NationalityRefCode = Convert.ToString(EntityDataTable.Rows[i][NATIONALITY]);

                if (NationalityRefCode == CUCCConstants.Instance.OTHER_NATIONALITY_CODE)
                    EntityDataTable.Rows[i][NATIONALITYTEXT] = Convert.ToString(EntityDataTable.Rows[i][NATIONALITYOTHER]);
                else
                    EntityDataTable.Rows[i][NATIONALITYTEXT] = CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.NATIONALTY, NationalityRefCode);


                string GenderText = Convert.ToString(EntityDataTable.Rows[i][GENDER]);

                EntityDataTable.Rows[i][GENDERTEXT] =
                  CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.GENDER, GenderText);


                string MariStatus = Convert.ToString(EntityDataTable.Rows[i][MARITALSTATUS]);

                EntityDataTable.Rows[i][MARITALSTATUSTEXT] =
                  CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.MARITALST, MariStatus);


                string OccupationRefCode = Convert.ToString(EntityDataTable.Rows[i][OCCUPATION]);

                if (OccupationRefCode == CUCCConstants.Instance.OTHER_OCCUPATION_REFNO)
                    EntityDataTable.Rows[i][OCCUPATIONTEXT] = Convert.ToString(EntityDataTable.Rows[i][OCCUPATIONOTHERS]);
                else
                    EntityDataTable.Rows[i][OCCUPATIONTEXT] = CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.OCCUPATION, OccupationRefCode);

                string RefType = Convert.ToString(EntityDataTable.Rows[i][STATUSCODE]);
                EntityDataTable.Rows[i][STATUSTEXT] =
                  CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.CDDTYPE_NI, RefType);


            }

        }



        #region GetEntityDocDetails
        /// <summary>
        /// Get Entity Document details
        /// </summary>
        /// <param name="nClientNo">ClientNo</param>
        /// <param name="dsResult">Entity Doc. details DataTable</param>
        /// <returns>Method Execution result</returns>
        public static MethodExecResult GetEntityDocDetails(int nClientNo, string sCallingFrom, ref DataSet dsResult, string sType = "")
        {

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_CCMMasterEntityDocDetails");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, "S");
            l_objDbWorkItem.AddParameter("@Ps_CallingFrom", SqlDbType.VarChar, sCallingFrom);
            l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, nClientNo);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            //if(sType != "")
            //l_objDbWorkItem.AddParameter("@Ps_Type", SqlDbType.Int, sType);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                    return new MethodExecResult(1, "No data found", "stp_CCMMasterEntityDocDetails. Database returned no data. UserNo. " +
                        AppEnvironment.AppUser.UserNo.ToString(), null);
                else
                {
                    dsResult = l_dsReturnData;
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        }
        #endregion

        #region GetEntityDocDetails


        //public static MethodExecResult GetEntityBankDetails(int nClientNo, ref DataTable dtBankResult)
        //{

        //    dtBankResult = new DataTable();
        //    DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_CCMMasterEntityBankDtls");
        //    l_objDbWorkItem.ResultType = QueryType.DataSet;

        //    l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, "S");
        //    l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, nClientNo);
        //    l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

        //    DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

        //    if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
        //    {
        //        DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
        //        if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
        //            return new MethodExecResult(1, "No data found", "stp_CCMMasterEntityBankDtls. Database returned no data. UserNo. " +
        //                AppEnvironment.AppUser.UserNo.ToString(), null);
        //        else
        //        {
        //            dtBankResult = l_dsReturnData.Tables[0];
        //            return l_objDbWorkItem.ExecutionStatus;
        //        }
        //    }
        //    else
        //    {
        //        return l_objDbWorkItem.ExecutionStatus;
        //    }
        //}

        /// <summary>
        /// Get Entity Bank details
        /// </summary>
        /// <param name="nClientNo">ClientNo</param>
        /// <param name="dtResult">Entity Bank details DataTable</param>
        /// <returns>Method Execution result</returns>
        public static MethodExecResult GetEntityBankDetails(int nClientNo, ref DataTable dtBankResult, int nUserNo, ref DataTable dtBankMaster)
        {

            dtBankResult = new DataTable();
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_CCMMasterEntityBankDtls");
            try
            {
                l_objDbWorkItem.ResultType = QueryType.DataSet;

                l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, "S");

                l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, nClientNo);
                l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, nUserNo);
                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
                if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                    if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_CCMMasterEntityDocDetails. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        dtBankResult = l_dsReturnData.Tables[0];
                        dtBankMaster = l_dsReturnData.Tables[1];
                        return l_objDbWorkItem.ExecutionStatus;
                    }
                }
                else
                {
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }
        }


        /// <summary>
        /// Get Entity Dealing Through details
        /// </summary>
        /// <param name="nClientNo">ClientNo</param>
        /// <param name="dtResult">Entity Dealing Through details DataTable</param>
        /// <returns>Method Execution result</returns>
        public static MethodExecResult GetEntityDealingThroughDetails(int nClientNo, ref DataTable dtDealingThroughResult, int nUserNo)
        {

            dtDealingThroughResult = new DataTable();
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_CCMMasterEntityDealingThroughDtls");
            try
            {
                l_objDbWorkItem.ResultType = QueryType.DataSet;

                l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, "S");

                l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, nClientNo);
                l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, nUserNo);
                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
                if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                    if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_CCMMasterEntityDealingThroughDtls. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        dtDealingThroughResult = l_dsReturnData.Tables[0];
                        return l_objDbWorkItem.ExecutionStatus;
                    }
                }
                else
                {
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }
        }


        /// <summary>
        /// Get Entity Trading details
        /// </summary>
        /// <param name="nClientNo">ClientNo</param>
        /// <param name="dtResult">Entity Dealing Through details DataTable</param>
        /// <returns>Method Execution result</returns>
        public static MethodExecResult GetEntityTradingDetails(int nClientNo, ref DataTable dtTradingResult, int nUserNo)
        {

            dtTradingResult = new DataTable();
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_CCMMasterEntityTradingDtls");
            try
            {
                l_objDbWorkItem.ResultType = QueryType.DataSet;

                l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, "S");

                l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, nClientNo);
                l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, nUserNo);
                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
                if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                    if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_CCMMasterEntityTradingDtls. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        dtTradingResult = l_dsReturnData.Tables[0];
                        return l_objDbWorkItem.ExecutionStatus;
                    }
                }
                else
                {
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }
        }

        /// <summary>
        /// Get Entity Fatca details
        /// </summary>
        /// <param name="nClientNo">ClientNo</param>
        /// <param name="dtResult">Entity Fatca details DataTable</param>
        /// <returns>Method Execution result</returns>
        public static MethodExecResult GetEntityFatcaDetails(int nClientNo, ref DataTable dtFatcaResult, int nUserNo)
        {

            dtFatcaResult = new DataTable();
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_CCMMasterEntityFatcaDtls");
            try
            {
                l_objDbWorkItem.ResultType = QueryType.DataSet;

                l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, "S");

                l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, nClientNo);
                l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, nUserNo);
                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
                if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                    if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_CCMMasterEntityFatcaDtls. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        dtFatcaResult = l_dsReturnData.Tables[0];
                        return l_objDbWorkItem.ExecutionStatus;
                    }
                }
                else
                {
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }
        }



        public static MethodExecResult GetEntityIntroducerDetails(int nClientNo, ref DataTable dtFatcaResult)
        {

            dtFatcaResult = new DataTable();
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetEntityIntAndAuthDtls");
            try
            {
                l_objDbWorkItem.ResultType = QueryType.DataSet;

                l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, "SI");
                l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, nClientNo);                
                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
                if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                    if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_GetEntityIntAndAuthDtls. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        dtFatcaResult = l_dsReturnData.Tables[0];
                        return l_objDbWorkItem.ExecutionStatus;
                    }
                }
                else
                {
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }
        }

        public static MethodExecResult GetEntityAuthorizerDetails(int nClientNo, ref DataTable dtFatcaResult)
        {

            dtFatcaResult = new DataTable();
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetEntityIntAndAuthDtls");
            try
            {
                l_objDbWorkItem.ResultType = QueryType.DataSet;

                l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, "SA");
                l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, nClientNo);
                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
                if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                    if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_GetEntityIntAndAuthDtls. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        dtFatcaResult = l_dsReturnData.Tables[0];
                        return l_objDbWorkItem.ExecutionStatus;
                    }
                }
                else
                {
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }
        }

        #endregion

        public static MethodExecResult GetEntityIPVDetails(int nClientNo, ref DataTable dtIPVResult, int nUserNo)
        {

            dtIPVResult = new DataTable();
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_KYC_OnlineIPVClient");
            try
            {
                l_objDbWorkItem.ResultType = QueryType.DataSet;
                l_objDbWorkItem.AddParameter("@ps_ClientNo", SqlDbType.Int, nClientNo);
                l_objDbWorkItem.AddParameter("@pc_Mode", SqlDbType.VarChar, "S");
                l_objDbWorkItem.AddParameter("@ps_IpvType", SqlDbType.VarChar, "WIZIQ");
                l_objDbWorkItem.AddParameter("@ps_CallType", SqlDbType.VarChar, "SD");

                SqlParameter n_ReturnCodeO = new SqlParameter();
                n_ReturnCodeO.ParameterName = "@pn_ReturnCode";
                n_ReturnCodeO.SqlDbType = SqlDbType.Int;
                //outparam.Size = 100;
                n_ReturnCodeO.Direction = ParameterDirection.Output;
                l_objDbWorkItem.AddParameter(n_ReturnCodeO);

                SqlParameter s_ReturnMsgO = new SqlParameter();
                s_ReturnMsgO.ParameterName = "@ps_ReturnMsg";
                s_ReturnMsgO.SqlDbType = SqlDbType.VarChar;
                s_ReturnMsgO.Size = 500;
                s_ReturnMsgO.Direction = ParameterDirection.Output;
                l_objDbWorkItem.AddParameter(s_ReturnMsgO);


                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
                if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                    if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_KYC_OnlineIPVClient. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        dtIPVResult = l_dsReturnData.Tables[0];
                        return l_objDbWorkItem.ExecutionStatus;
                    }
                }
                else
                {
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }
        }

        //public static MethodExecResult GetEntitySLOTIPVDetails(int nClientNo, ref DataTable dtIPVResult, int nUserNo)
        //{

        //    dtIPVResult = new DataTable();
        //    DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_KYC_OnlineIPVClient");
        //    try
        //    {
        //        l_objDbWorkItem.ResultType = QueryType.DataSet;
        //        l_objDbWorkItem.AddParameter("@ps_ClientNo", SqlDbType.Int, nClientNo);
        //        l_objDbWorkItem.AddParameter("@pc_Mode", SqlDbType.VarChar, "S");
        //        l_objDbWorkItem.AddParameter("@ps_IpvType", SqlDbType.VarChar, "WIZIQ");
        //        l_objDbWorkItem.AddParameter("@ps_CallType", SqlDbType.VarChar, "SLOT");

        //        SqlParameter n_ReturnCodeO = new SqlParameter();
        //        n_ReturnCodeO.ParameterName = "@pn_ReturnCode";
        //        n_ReturnCodeO.SqlDbType = SqlDbType.Int;
        //        //outparam.Size = 100;
        //        n_ReturnCodeO.Direction = ParameterDirection.Output;
        //        l_objDbWorkItem.AddParameter(n_ReturnCodeO);

        //        SqlParameter s_ReturnMsgO = new SqlParameter();
        //        s_ReturnMsgO.ParameterName = "@ps_ReturnMsg";
        //        s_ReturnMsgO.SqlDbType = SqlDbType.VarChar;
        //        s_ReturnMsgO.Size = 500;
        //        s_ReturnMsgO.Direction = ParameterDirection.Output;
        //        l_objDbWorkItem.AddParameter(s_ReturnMsgO);


        //        DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
        //        if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
        //        {
        //            DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
        //            if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
        //                return new MethodExecResult(1, "No data found", "stp_KYC_OnlineIPVClient. Database returned no data. UserNo. " +
        //                    AppEnvironment.AppUser.UserNo.ToString(), null);
        //            else
        //            {
        //                dtIPVResult = l_dsReturnData.Tables[0];
        //                return l_objDbWorkItem.ExecutionStatus;
        //            }
        //        }
        //        else
        //        {
        //            return l_objDbWorkItem.ExecutionStatus;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
        //        return new MethodExecResult(-1, null, ex.Message, null);
        //    }
        //}


        public static MethodExecResult GetEntitySLOTIPVDetails(int nClientNo, ref DataTable dtIPVResult, ref DataTable dtIPVSlots)
        {

            dtIPVResult = new DataTable();
            dtIPVSlots = new DataTable();

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_KYC_OnlineIPVClient");
            try
            {
                l_objDbWorkItem.ResultType = QueryType.DataSet;
                l_objDbWorkItem.AddParameter("@ps_ClientNo", SqlDbType.Int, nClientNo);
                l_objDbWorkItem.AddParameter("@pc_Mode", SqlDbType.VarChar, "S");
                l_objDbWorkItem.AddParameter("@ps_IpvType", SqlDbType.VarChar, "WIZIQ");
                l_objDbWorkItem.AddParameter("@ps_CallType", SqlDbType.VarChar, "SLOT");

                SqlParameter n_ReturnCodeO = new SqlParameter();
                n_ReturnCodeO.ParameterName = "@pn_ReturnCode";
                n_ReturnCodeO.SqlDbType = SqlDbType.Int;
                //outparam.Size = 100;
                n_ReturnCodeO.Direction = ParameterDirection.Output;
                l_objDbWorkItem.AddParameter(n_ReturnCodeO);

                SqlParameter s_ReturnMsgO = new SqlParameter();
                s_ReturnMsgO.ParameterName = "@ps_ReturnMsg";
                s_ReturnMsgO.SqlDbType = SqlDbType.VarChar;
                s_ReturnMsgO.Size = 500;
                s_ReturnMsgO.Direction = ParameterDirection.Output;
                l_objDbWorkItem.AddParameter(s_ReturnMsgO);


                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
                if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                    if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_KYC_OnlineIPVClient. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        dtIPVResult = l_dsReturnData.Tables[0];
                        dtIPVSlots = l_dsReturnData.Tables[1];
                        return l_objDbWorkItem.ExecutionStatus;
                    }
                }
                else
                {
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }
        }



        #region GetRemoveEntityGuardianDetails
        public static MethodExecResult GetRemoveEntityGuardianDetails(int nClientNo, string operationFlag, ref DataTable dtResult)
        {

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_CCMRetriveDeleteGuardianDtls");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, operationFlag);
            l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, nClientNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                    return new MethodExecResult(1, "No data found", "stp_CCMMasterEntityDocDetails. Database returned no data. UserNo. " +
                        AppEnvironment.AppUser.UserNo.ToString(), null);
                else
                {
                    dtResult = l_dsReturnData.Tables[0];
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        }
        #endregion

        #region GetEntityCustodianDetails
        /// <summary>
        /// Get Entity Custodian details
        /// </summary>
        /// <param name="nClientNo">ClientNo</param>
        /// <param name="dtResult">Entity Custodian details DataTable</param>
        /// <returns>Method Execution result</returns>
        public static MethodExecResult GetCustodianDetails(int nClientNo, ref DataTable dtCustodianResult, int nUserNo, ref DataTable dtCustodianMaster)
        {

            dtCustodianResult = new DataTable();
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_CCMMasterEntityCustodianDtls");
            try
            {
                l_objDbWorkItem.ResultType = QueryType.DataSet;

                l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, "S");
                l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, nClientNo);
                l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, nUserNo);
                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
                if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                    if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_CCMMasterEntityCustodianDtls. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        dtCustodianResult = l_dsReturnData.Tables[0];
                        dtCustodianMaster = l_dsReturnData.Tables[1];
                        return l_objDbWorkItem.ExecutionStatus;
                    }
                }
                else
                {
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }
        }
#endregion

        public int RemoveGuardianDetails(int nClientId)
        {
            int iResult;
            DataTable dt = new DataTable();
            GetRemoveEntityGuardianDetails(nClientId, "D", ref dt);
            iResult = Convert.ToInt32(dt.Rows[0]["Result"].ToString());
            return iResult;
        }


        /// <summary>
        /// Bulk Update Entity document details
        /// </summary>
        /// <param name="nClientNo">EntityNo</param>
        /// <param name="p_vdsTempTableData">Source DataTable - to be update in database</param>
        /// <returns>Method execution result</returns>
        public MethodExecResult UpdateEntityDocDetails(int nClientNo, DataTable p_vdsTempTableData, DateTime? p_dLastUpdatedDate = null)
        {
            DbWorkItem objdbwork = new DbWorkItem("stp_CCMMasterEntityDocDetails");
            try
            {
                DataSet l_dsFileData = new DataSet();

                DataTable dtUpdated = p_vdsTempTableData.Copy();


                dtUpdated.TableName = "#tb_ClientDocDetails";


                dtUpdated.Columns["n_ClientDocNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_ClientDocNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["n_Type"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_Type"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["s_Details"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_Details"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdated.Columns["d_DateOfIssue"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["d_DateOfIssue"].ExtendedProperties.Add(DbManager.ColLengthAttr, "20");

                dtUpdated.Columns["d_DateOfExpiry"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["d_DateOfExpiry"].ExtendedProperties.Add(DbManager.ColLengthAttr, "20");

                dtUpdated.Columns["s_IssuedPlace"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_IssuedPlace"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdated.Columns["s_ProofProvided"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_ProofProvided"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["s_HasChanged"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_HasChanged"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");



                l_dsFileData.Tables.Add(dtUpdated);


                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.InputData = l_dsFileData;
                SqlParameter outParamErrNo = new SqlParameter("@pn_ErrorNo", SqlDbType.Int, 8);
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outParamErrMsg = new SqlParameter("@ps_ErrorMsg", SqlDbType.VarChar, 100);
                outParamErrMsg.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrMsg);

                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "U");
                objdbwork.AddParameter("@pn_ClientNo", SqlDbType.Int, nClientNo);
                objdbwork.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);
                objdbwork.AddParameter("@pd_dLastModifiedDate", SqlDbType.DateTime, p_dLastUpdatedDate);
                objdbwork.AddParameter("@ps_CallingType", SqlDbType.VarChar, "W");
                //CAll TYpe added for identifying Call From Web	

                if (ErrorMsg == "Y")
                    objdbwork.AddParameter("@ps_Process", SqlDbType.Char, "P");
                else
                    objdbwork.AddParameter("@ps_Process", SqlDbType.Char, "A");

                DbManager.Instance.ExecuteDbTask(objdbwork);

                ErrorNo = Convert.ToInt32(objdbwork.parameters[0].Value);
                if (ErrorNo == 101)
                    ErrorMsg = Convert.ToString(objdbwork.parameters[1].Value);

                //To Trap bussiness error for web 
                if (ErrorNo != 0)
                {
                    return new MethodExecResult(ErrorNo, ErrorMsg, "CEntityMaster", null);
                }

                return objdbwork.ExecutionStatus;


            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, ex.Message, "CEntityMaster", ex);
            }

        }

        /// <summary>
        /// Bulk Update Entity document details fro web call
        /// </summary>
        /// <param name="nClientNo"></param>
        /// <param name="p_vdsTempTableData"></param>
        /// <param name="dtDocNo"></param>
        /// <param name="p_dLastUpdatedDate"></param>
        /// <returns></returns>
        public MethodExecResult UpdateEntityDocDetails(int nClientNo, DataTable p_vdsTempTableData, ref DataTable dtDocNo, DateTime? p_dLastUpdatedDate = null)
        {
            DbWorkItem objdbwork = new DbWorkItem("stp_CCMMasterEntityDocDetails");
            try
            {
                DataSet l_dsFileData = new DataSet();

                DataTable dtUpdated = p_vdsTempTableData.Copy();


                dtUpdated.TableName = "#tb_ClientDocDetails";


                dtUpdated.Columns["n_ClientDocNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_ClientDocNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["n_Type"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_Type"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["s_Details"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_Details"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdated.Columns["d_DateOfIssue"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["d_DateOfIssue"].ExtendedProperties.Add(DbManager.ColLengthAttr, "20");

                dtUpdated.Columns["d_DateOfExpiry"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["d_DateOfExpiry"].ExtendedProperties.Add(DbManager.ColLengthAttr, "20");

                dtUpdated.Columns["s_IssuedPlace"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_IssuedPlace"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdated.Columns["s_ProofProvided"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_ProofProvided"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["s_HasChanged"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_HasChanged"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                l_dsFileData.Tables.Add(dtUpdated);


                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.InputData = l_dsFileData;
                SqlParameter outParamErrNo = new SqlParameter("@pn_ErrorNo", SqlDbType.Int, 8);
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outParamErrMsg = new SqlParameter("@ps_ErrorMsg", SqlDbType.VarChar, 100);
                outParamErrMsg.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrMsg);

                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "U");
                objdbwork.AddParameter("@pn_ClientNo", SqlDbType.Int, nClientNo);
                objdbwork.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);
                objdbwork.AddParameter("@pd_dLastModifiedDate", SqlDbType.DateTime, p_dLastUpdatedDate);
                objdbwork.AddParameter("@ps_CallingType", SqlDbType.VarChar, "W");
                //CAll TYpe added for identifying Call From Web	

                if (ErrorMsg == "Y")
                    objdbwork.AddParameter("@ps_Process", SqlDbType.Char, "P");
                else
                    objdbwork.AddParameter("@ps_Process", SqlDbType.Char, "A");

                DbManager.Instance.ExecuteDbTask(objdbwork);

                ErrorNo = Convert.ToInt32(objdbwork.parameters[0].Value);
                if (ErrorNo == 101)
                    ErrorMsg = Convert.ToString(objdbwork.parameters[1].Value);

                //To Trap bussiness error for web 
                if (ErrorNo != 0)
                {
                    return new MethodExecResult(ErrorNo, ErrorMsg, "CEntityMaster", null);
                }
                DataSet dsDocno = (DataSet)objdbwork.Result;
                dtDocNo = dsDocno.Tables[0]; 

                return objdbwork.ExecutionStatus;


            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, ex.Message, "CEntityMaster", ex);
            }

        }


        /// <summary>
        /// Bulk Update Entity bank details
        /// </summary>
        /// <param name="nClientNo">EntityNo</param>
        /// <param name="p_vdsTempTableData">Source DataTable - to be update in database</param>
        /// <returns>Method execution result</returns>
        public MethodExecResult UpdateEntityBankDetails(int nClientNo, DataTable p_vdsTempTableData, DateTime? p_dLastUpdatedDate)
        {
            DbWorkItem objdbwork = new DbWorkItem("stp_CCMMasterEntityBankDtls");
            try
            {
                DataSet l_dsFileData = new DataSet();

                DataTable dtUpdated = p_vdsTempTableData.Copy();


                dtUpdated.TableName = "#tb_UCCBank";


                dtUpdated.Columns["n_ClientBankNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_ClientBankNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["s_BankCode"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_BankCode"].ExtendedProperties.Add(DbManager.ColLengthAttr, "16");

                dtUpdated.Columns["s_BankName"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_BankName"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["s_MICRCode"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_MICRCode"].ExtendedProperties.Add(DbManager.ColLengthAttr, "20");

                dtUpdated.Columns["s_Branch"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_Branch"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdated.Columns["n_AccountTypeVal"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_AccountTypeVal"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["s_AccountType"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_AccountType"].ExtendedProperties.Add(DbManager.ColLengthAttr, "20");

                dtUpdated.Columns["s_AccountNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_AccountNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "25");

                dtUpdated.Columns["s_CustomerID"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_CustomerID"].ExtendedProperties.Add(DbManager.ColLengthAttr, "20");

                dtUpdated.Columns["s_IFSCCode"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_IFSCCode"].ExtendedProperties.Add(DbManager.ColLengthAttr, "20");

                dtUpdated.Columns["s_NameOnCheque"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_NameOnCheque"].ExtendedProperties.Add(DbManager.ColLengthAttr, "200");

                dtUpdated.Columns["s_Default"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_Default"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["s_HasChanged"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_HasChanged"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["s_Others"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_Others"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");
                
                l_dsFileData.Tables.Add(dtUpdated);
                                
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.InputData = l_dsFileData;
                SqlParameter outParamErrNo = new SqlParameter("@pn_ErrorNo", SqlDbType.Int, 8);
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outParamErrMsg = new SqlParameter("@ps_ErrorMsg", SqlDbType.VarChar, 100);
                outParamErrMsg.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrMsg);

                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "U");
                objdbwork.AddParameter("@pn_ClientNo", SqlDbType.Int, nClientNo);
                objdbwork.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

                objdbwork.AddParameter("@pd_dLastModifiedDate", SqlDbType.DateTime, p_dLastUpdatedDate);

                objdbwork.AddParameter("@ps_CallingType", SqlDbType.VarChar, "W");
                //CAll TYpe added for identifying Call From Web	


                if (ErrorMsg == "Y")
                    objdbwork.AddParameter("@ps_Process", SqlDbType.Char, "P");
                else
                    objdbwork.AddParameter("@ps_Process", SqlDbType.Char, "A");
                DbManager.Instance.ExecuteDbTask(objdbwork);

                ErrorNo = Convert.ToInt32(objdbwork.parameters[0].Value);
                if (ErrorNo == 101)
                    ErrorMsg = Convert.ToString(objdbwork.parameters[1].Value);
                
                //To Trap bussiness error for web 
                if (ErrorNo != 0)
                {
                    return new MethodExecResult(ErrorNo, ErrorMsg, "CEntityMaster", null);
                }

                return objdbwork.ExecutionStatus;
                
            }
            catch (Exception ex)
            {
                ErrorNo = 0;
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, ex.Message,"CEntityMaster", ex);;
            }

        }

        /// <summary>
        /// Bulk Update Entity Dealing Through details
        /// </summary>
        /// <param name="nClientNo">EntityNo</param>
        /// <param name="p_vdsTempTableData">Source DataTable - to be update in database</param>
        /// <returns>Method execution result</returns>
        public MethodExecResult UpdateEntityDealingThroughDetails(int nClientNo, DataTable p_vdsTempTableData, DateTime? p_dLastUpdatedDate)
        {
            DbWorkItem objdbwork = new DbWorkItem("stp_CCMMasterEntityDealingThroughDtls");
            try
            {
                DataSet l_dsFileData = new DataSet();

                DataTable dtUpdated = p_vdsTempTableData.Copy();


                dtUpdated.TableName = "#tb_UCCDealingThrough";


                dtUpdated.Columns["n_ClientDealingThroughNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_ClientDealingThroughNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["n_Flag"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["n_Flag"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["s_SubBrokerName"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_SubBrokerName"].ExtendedProperties.Add(DbManager.ColLengthAttr, "250");

                dtUpdated.Columns["s_ExchangeName"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_ExchangeName"].ExtendedProperties.Add(DbManager.ColLengthAttr, "250");

                dtUpdated.Columns["s_ClientCode"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_ClientCode"].ExtendedProperties.Add(DbManager.ColLengthAttr, "25");

                dtUpdated.Columns["s_SebiRegNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["s_SebiRegNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["n_Ammount"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["n_Ammount"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["s_Remarks"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_Remarks"].ExtendedProperties.Add(DbManager.ColLengthAttr, "255");

                dtUpdated.Columns["s_HasChanged"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_HasChanged"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                l_dsFileData.Tables.Add(dtUpdated);

                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.InputData = l_dsFileData;
                SqlParameter outParamErrNo = new SqlParameter("@pn_ErrorNo", SqlDbType.Int, 8);
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outParamErrMsg = new SqlParameter("@ps_ErrorMsg", SqlDbType.VarChar, 100);
                outParamErrMsg.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrMsg);

                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "U");
                objdbwork.AddParameter("@pn_ClientNo", SqlDbType.Int, nClientNo);
                objdbwork.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

                objdbwork.AddParameter("@pd_dLastModifiedDate", SqlDbType.DateTime, p_dLastUpdatedDate);

                objdbwork.AddParameter("@ps_CallingType", SqlDbType.VarChar, "W");
                //CAll TYpe added for identifying Call From Web	


                if (ErrorMsg == "Y")
                    objdbwork.AddParameter("@ps_Process", SqlDbType.Char, "P");
                else
                    objdbwork.AddParameter("@ps_Process", SqlDbType.Char, "A");
                DbManager.Instance.ExecuteDbTask(objdbwork);

                ErrorNo = Convert.ToInt32(objdbwork.parameters[0].Value);
                if (ErrorNo == 101)
                    ErrorMsg = Convert.ToString(objdbwork.parameters[1].Value);

                //To Trap bussiness error for web 
                if (ErrorNo != 0)
                {
                    return new MethodExecResult(ErrorNo, ErrorMsg, "CEntityMaster", null);
                }

                return objdbwork.ExecutionStatus;

            }
            catch (Exception ex)
            {
                ErrorNo = 0;
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, ex.Message, "CEntityMaster", ex); ;
            }

        }


        /// <summary>
        /// Bulk Update Entity Trading Details
        /// </summary>
        /// <param name="nClientNo">EntityNo</param>
        /// <param name="p_vdsTempTableData">Source DataTable - to be update in database</param>
        /// <returns>Method execution result</returns>
        public MethodExecResult UpdateEntityTradingDetails(int nClientNo, DataTable p_vdsTempTableData, DateTime? p_dLastUpdatedDate)
        {
            DbWorkItem objdbwork = new DbWorkItem("stp_CCMMasterEntityTradingDtls");
            try
            {
                DataSet l_dsFileData = new DataSet();

                DataTable dtUpdated = p_vdsTempTableData.Copy();


                dtUpdated.TableName = "#tb_UCCTradingDetails";


                dtUpdated.Columns["n_TradingDetailNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_TradingDetailNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["n_PastAction"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["n_PastAction"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["s_PastAction"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_PastAction"].ExtendedProperties.Add(DbManager.ColLengthAttr, "255");

                dtUpdated.Columns["n_TradingPurpose"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["n_TradingPurpose"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["s_TradingPurpose"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_TradingPurpose"].ExtendedProperties.Add(DbManager.ColLengthAttr, "255");

                dtUpdated.Columns["n_TradingExpFlag"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_TradingExpFlag"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["n_TradingExp"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["n_TradingExp"].ExtendedProperties.Add(DbManager.ColLengthAttr, "5,2");

                dtUpdated.Columns["n_OtherExpFlag"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["n_OtherExpFlag"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["n_OtherExp"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["n_OtherExp"].ExtendedProperties.Add(DbManager.ColLengthAttr, "5,2");

                dtUpdated.Columns["s_HasChanged"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_HasChanged"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                l_dsFileData.Tables.Add(dtUpdated);

                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.InputData = l_dsFileData;
                SqlParameter outParamErrNo = new SqlParameter("@pn_ErrorNo", SqlDbType.Int, 8);
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outParamErrMsg = new SqlParameter("@ps_ErrorMsg", SqlDbType.VarChar, 100);
                outParamErrMsg.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrMsg);

                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "U");
                objdbwork.AddParameter("@pn_ClientNo", SqlDbType.Int, nClientNo);
                objdbwork.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

                objdbwork.AddParameter("@pd_dLastModifiedDate", SqlDbType.DateTime, p_dLastUpdatedDate);

                objdbwork.AddParameter("@ps_CallingType", SqlDbType.VarChar, "W");
                //CAll TYpe added for identifying Call From Web	


                if (ErrorMsg == "Y")
                    objdbwork.AddParameter("@ps_Process", SqlDbType.Char, "P");
                else
                    objdbwork.AddParameter("@ps_Process", SqlDbType.Char, "A");
                DbManager.Instance.ExecuteDbTask(objdbwork);

                ErrorNo = Convert.ToInt32(objdbwork.parameters[0].Value);
                if (ErrorNo == 101)
                    ErrorMsg = Convert.ToString(objdbwork.parameters[1].Value);

                //To Trap bussiness error for web 
                if (ErrorNo != 0)
                {
                    return new MethodExecResult(ErrorNo, ErrorMsg, "CEntityMaster", null);
                }

                return objdbwork.ExecutionStatus;

            }
            catch (Exception ex)
            {
                ErrorNo = 0;
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, ex.Message, "CEntityMaster", ex); ;
            }

        }
        //resultDataTable
        public MethodExecResult ClientUpload(DataTable p_vdsTempTableData, ref  DataSet l_dsReturnData)
        {

            DbWorkItem objdbwork = new DbWorkItem("stp_CCMMasterClientImportDtls");
            try
            {
                DataSet l_dsFileData = new DataSet();
               // DataSet l_dsReturnData = new DataSet();
                DataTable dtUpdated = p_vdsTempTableData.Copy();

                dtUpdated.TableName = "#tb_KYCClientImportDetails";

                //dtUpdated.Columns["n_EntityNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                //dtUpdated.Columns["n_EntityNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "16");

                //dtUpdated.Columns["s_EntityName"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                //dtUpdated.Columns["s_EntityName"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                //dtUpdated.Columns["s_PANNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                //dtUpdated.Columns["s_PANNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "16");

                dtUpdated.Columns["Mode"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["Mode"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                //dtUpdated.Columns["ClientNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                //dtUpdated.Columns["ClientNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "16");

                dtUpdated.Columns["ClientCode"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["ClientCode"].ExtendedProperties.Add(DbManager.ColLengthAttr, "12");

                dtUpdated.Columns["ClientName"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["ClientName"].ExtendedProperties.Add(DbManager.ColLengthAttr, "150");

                dtUpdated.Columns["NSEEQ"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["NSEEQ"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["NSEFO"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["NSEFO"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["NSECR"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["NSECR"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["BSEEQ"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["BSEEQ"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["BSEFO"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["BSEFO"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["BSECR"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["BSECR"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["MSEIEQ"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["MSEIEQ"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["MSEIFO"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["MSEIFO"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["MSEICR"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["MSEICR"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["NCDEX"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["NCDEX"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["MCX"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["MCX"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["NMCE"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["NMCE"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["IPO"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["IPO"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["MF"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["MF"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["Category"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["Category"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["PAN"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["PAN"].ExtendedProperties.Add(DbManager.ColLengthAttr, "10");

                dtUpdated.Columns["Gender"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["Gender"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["FathersName"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["FathersName"].ExtendedProperties.Add(DbManager.ColLengthAttr, "150");

                dtUpdated.Columns["MothersName"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["MothersName"].ExtendedProperties.Add(DbManager.ColLengthAttr, "150");

                dtUpdated.Columns["Maritalstatus"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["Maritalstatus"].ExtendedProperties.Add(DbManager.ColLengthAttr, "2");

                dtUpdated.Columns["Nationality"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["Nationality"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["NationalityOther"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["NationalityOther"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["ClientEmailId"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["ClientEmailId"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["CorCliAdd1"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["CorCliAdd1"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdated.Columns["CorCliAdd2"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["CorCliAdd2"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdated.Columns["CorCliAdd3"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["CorCliAdd3"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdated.Columns["CorCliCity"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["CorCliCity"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["CorCliState"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["CorCliState"].ExtendedProperties.Add(DbManager.ColLengthAttr, "10");

                dtUpdated.Columns["CorCliStateOth"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["CorCliStateOth"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["CorCliCountry"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["CorCliCountry"].ExtendedProperties.Add(DbManager.ColLengthAttr, "5");

                dtUpdated.Columns["CorCliPincode"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["CorCliPincode"].ExtendedProperties.Add(DbManager.ColLengthAttr, "6");

                dtUpdated.Columns["AddFlag"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["AddFlag"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["PerCliAdd1"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["PerCliAdd1"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdated.Columns["PerCliAdd2"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["PerCliAdd2"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdated.Columns["PerCliAdd3"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["PerCliAdd3"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdated.Columns["PerCliCity"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["PerCliCity"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["PerCliState"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["PerCliState"].ExtendedProperties.Add(DbManager.ColLengthAttr, "10");

                dtUpdated.Columns["PerCliStateOth"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["PerCliStateOth"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["PerCliCountry"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["PerCliCountry"].ExtendedProperties.Add(DbManager.ColLengthAttr, "5");

                dtUpdated.Columns["PerCliPincode"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["PerCliPincode"].ExtendedProperties.Add(DbManager.ColLengthAttr, "6");

                dtUpdated.Columns["ISDcodeResidence"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["ISDcodeResidence"].ExtendedProperties.Add(DbManager.ColLengthAttr, "5");

                dtUpdated.Columns["STDcodeResidence"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["STDcodeResidence"].ExtendedProperties.Add(DbManager.ColLengthAttr, "5");

                dtUpdated.Columns["MobNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["MobNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "10");

                dtUpdated.Columns["DOB"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["DOB"].ExtendedProperties.Add(DbManager.ColLengthAttr, "16");

                dtUpdated.Columns["UIDNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["UIDNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "25");

                dtUpdated.Columns["BankName1"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["BankName1"].ExtendedProperties.Add(DbManager.ColLengthAttr, "150");

                dtUpdated.Columns["BankBranch1"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["BankBranch1"].ExtendedProperties.Add(DbManager.ColLengthAttr, "150");

                dtUpdated.Columns["BankAccNo1"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["BankAccNo1"].ExtendedProperties.Add(DbManager.ColLengthAttr, "20");

                dtUpdated.Columns["BankAccType1"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["BankAccType1"].ExtendedProperties.Add(DbManager.ColLengthAttr, "2");

                dtUpdated.Columns["Depository"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["Depository"].ExtendedProperties.Add(DbManager.ColLengthAttr, "4");

                dtUpdated.Columns["DepositoryID1"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["DepositoryID1"].ExtendedProperties.Add(DbManager.ColLengthAttr, "16");

                dtUpdated.Columns["BenOwnAccNo1"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["BenOwnAccNo1"].ExtendedProperties.Add(DbManager.ColLengthAttr, "16");

                dtUpdated.Columns["GroAnnIncRange"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["GroAnnIncRange"].ExtendedProperties.Add(DbManager.ColLengthAttr, "16");

                dtUpdated.Columns["GroAnnIncAsOnDate"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["GroAnnIncAsOnDate"].ExtendedProperties.Add(DbManager.ColLengthAttr, "16");

                dtUpdated.Columns["NetWorth"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["NetWorth"].ExtendedProperties.Add(DbManager.ColLengthAttr, "20,2");

                dtUpdated.Columns["NetWorAsOnDate"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["NetWorAsOnDate"].ExtendedProperties.Add(DbManager.ColLengthAttr, "16");

                dtUpdated.Columns["PEP"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["PEP"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["OccDetails"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["OccDetails"].ExtendedProperties.Add(DbManager.ColLengthAttr, "2");

                dtUpdated.Columns["OccDetOthers"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["OccDetOthers"].ExtendedProperties.Add(DbManager.ColLengthAttr, "75");

                dtUpdated.Columns["IPV"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["IPV"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["CliAgmntDate"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["CliAgmntDate"].ExtendedProperties.Add(DbManager.ColLengthAttr, "16");

                dtUpdated.Columns["UCC"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["UCC"].ExtendedProperties.Add(DbManager.ColLengthAttr, "12");

                dtUpdated.Columns["UpdationFlag"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["UpdationFlag"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["TypeOfFacility"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["TypeOfFacility"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["ClientStatus"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["ClientStatus"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1"); 		

                dtUpdated.Columns["n_Flag"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_Flag"].ExtendedProperties.Add(DbManager.ColLengthAttr, "16");


                l_dsFileData.Tables.Add(dtUpdated);

                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.InputData = l_dsFileData;

                SqlParameter outParamErrNo = new SqlParameter("@pn_ErrorNo", SqlDbType.Int, 8);
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outParamErrMsg = new SqlParameter("@ps_ErrorMsg", SqlDbType.VarChar, 100);
                outParamErrMsg.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrMsg);

                SqlParameter outParamImportRowsCount = new SqlParameter("@pn_ImportRows", SqlDbType.Int, 8);
                outParamImportRowsCount.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamImportRowsCount);

                SqlParameter outParamErrorRowsCount = new SqlParameter("@pn_ErrorRows", SqlDbType.Int, 8);
                outParamErrorRowsCount.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrorRowsCount);


                DbManager.Instance.ExecuteDbTask(objdbwork);

                //DataSet l_dsReturnData = objdbwork.Result as DataSet;

                l_dsReturnData.Tables.Add(createStatusTable((string)objdbwork.parameters[objdbwork.parameters.Count - 4].Value.ToString(), (string)objdbwork.parameters[objdbwork.parameters.Count - 3].Value.ToString()));
                l_dsReturnData.Tables[0].TableName = "Status";
                //Add column in datatable
                System.Data.DataColumn ImportRowsCount = new System.Data.DataColumn("ImportRowsCount", typeof(System.Int32));
                ImportRowsCount.DefaultValue = Convert.ToInt32(objdbwork.parameters[2].Value);
                l_dsReturnData.Tables["Status"].Columns.Add(ImportRowsCount);

                System.Data.DataColumn DuplicateRowsCount = new System.Data.DataColumn("n_ErrorRows", typeof(System.Int32));
                DuplicateRowsCount.DefaultValue = Convert.ToInt32(objdbwork.parameters[3].Value);
                l_dsReturnData.Tables["Status"].Columns.Add(DuplicateRowsCount);

                int errCode = (int)objdbwork.parameters[objdbwork.parameters.Count - 4].Value;
                if (errCode == 0 || errCode == 1)
                {
                    //res[1] = ((DataSet)objdbwork.Result).Tables[0];

                    l_dsReturnData.Tables.Add(((DataSet)objdbwork.Result).Tables[0].Copy());
                    l_dsReturnData.Tables.Add(((DataSet)objdbwork.Result).Tables[1].Copy());

                }
                else
                {
                    //res[1] = new DataTable();
                    l_dsReturnData.Tables.Add(new DataTable());
                }
                l_dsReturnData.Tables[1].TableName = "D1";
                l_dsReturnData.Tables[2].TableName = "D2";


                ErrorNo = Convert.ToInt32(objdbwork.parameters[0].Value);
                if (ErrorNo == 101)
                    ErrorMsg = Convert.ToString(objdbwork.parameters[1].Value);

                //To Trap bussiness error for web 
                if (ErrorNo != 0)
                {
                    return new MethodExecResult(ErrorNo, ErrorMsg, "CEntityMaster", null);
                }

                DataSet ds_ResultData = (DataSet)objdbwork.Result;
               // resultDataTable = ds_ResultData.Tables[0]; 
                return objdbwork.ExecutionStatus;

            }
            catch (Exception ex)
            {
                ErrorNo = 0;
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, ex.Message, "CEntityMaster", ex); ;
            }

        }

        public MethodExecResult DebarredEntitiesUpload(DataTable p_vdsTempTableData, ref  DataSet l_dsReturnData)
        {

            DbWorkItem objdbwork = new DbWorkItem("stp_KYCDebarredEntities");
            try
            {
                DataSet l_dsFileData = new DataSet();
               // DataSet l_dsReturnData = new DataSet();
                DataTable dtUpdated = p_vdsTempTableData.Copy();

                dtUpdated.TableName = "#DebarredEntities";

                dtUpdated.Columns["ClientName"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["ClientName"].ExtendedProperties.Add(DbManager.ColLengthAttr, "255");

                dtUpdated.Columns["PANNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["PANNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "30");

               

                l_dsFileData.Tables.Add(dtUpdated);

                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.InputData = l_dsFileData;

                SqlParameter outParamErrNo = new SqlParameter("@pn_ErrorNo", SqlDbType.Int, 8);
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outParamErrMsg = new SqlParameter("@ps_ErrorMsg", SqlDbType.VarChar, 100);
                outParamErrMsg.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrMsg);

                DbManager.Instance.ExecuteDbTask(objdbwork);

                ErrorNo = Convert.ToInt32(objdbwork.parameters[0].Value);
                if (ErrorNo == 101)
                    ErrorMsg = Convert.ToString(objdbwork.parameters[1].Value);

                //To Trap bussiness error for web 
                if (ErrorNo != 0)
                {
                    return new MethodExecResult(ErrorNo, ErrorMsg, "CEntityMaster", null);
                }

                return objdbwork.ExecutionStatus;

            }
            catch (Exception ex)
            {
                ErrorNo = 0;
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, ex.Message, "CEntityMaster", ex); ;
            }

        }
        
        public DataTable createStatusTable(string errCode, string errMsg)
        {
            DataTable dt = new DataTable();
            dt.TableName = "Status";
            dt.Columns.Add("ErrorCode");
            dt.Columns.Add("Message");
            dt.Rows.Add(errCode, errMsg);

            return dt;

        }
        /// <summary>
        /// Bulk Update Entity Fatca Details
        /// </summary>
        /// <param name="nClientNo">EntityNo</param>
        /// <param name="p_vdsTempTableData">Source DataTable - to be update in database</param>
        /// <returns>Method execution result</returns>
        public MethodExecResult UpdateEntityFatcaDetails(int nClientNo, DataTable p_vdsTempTableData, DateTime? p_dLastUpdatedDate)
        {
            DbWorkItem objdbwork = new DbWorkItem("stp_CCMMasterEntityFatcaDtls");
            try
            {
                DataSet l_dsFileData = new DataSet();

                DataTable dtUpdated = p_vdsTempTableData.Copy();


                dtUpdated.TableName = "#tb_UCCFatcaDetails";


                dtUpdated.Columns["n_FatcaDetailNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_FatcaDetailNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["n_USCitizen"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["n_USCitizen"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["n_OtherCitizen"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["n_OtherCitizen"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["s_BirthPlace"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_BirthPlace"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdated.Columns["s_CountryPlace"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_CountryPlace"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdated.Columns["n_TaxResidentFlag"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_TaxResidentFlag"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["s_TaxResidentCountry"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_TaxResidentCountry"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdated.Columns["s_TaxIdNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_TaxIdNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["s_IdentificationType"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_IdentificationType"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["s_HasChanged"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_HasChanged"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                l_dsFileData.Tables.Add(dtUpdated);

                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.InputData = l_dsFileData;
                SqlParameter outParamErrNo = new SqlParameter("@pn_ErrorNo", SqlDbType.Int, 8);
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outParamErrMsg = new SqlParameter("@ps_ErrorMsg", SqlDbType.VarChar, 100);
                outParamErrMsg.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrMsg);

                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "U");
                objdbwork.AddParameter("@pn_ClientNo", SqlDbType.Int, nClientNo);
                objdbwork.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

                objdbwork.AddParameter("@pd_dLastModifiedDate", SqlDbType.DateTime, p_dLastUpdatedDate);

                objdbwork.AddParameter("@ps_CallingType", SqlDbType.VarChar, "W");
                //CAll TYpe added for identifying Call From Web	


                if (ErrorMsg == "Y")
                    objdbwork.AddParameter("@ps_Process", SqlDbType.Char, "P");
                else
                    objdbwork.AddParameter("@ps_Process", SqlDbType.Char, "A");
                DbManager.Instance.ExecuteDbTask(objdbwork);

                ErrorNo = Convert.ToInt32(objdbwork.parameters[0].Value);
                if (ErrorNo == 101)
                    ErrorMsg = Convert.ToString(objdbwork.parameters[1].Value);

                //To Trap bussiness error for web 
                if (ErrorNo != 0)
                {
                    return new MethodExecResult(ErrorNo, ErrorMsg, "CEntityMaster", null);
                }

                return objdbwork.ExecutionStatus;

            }
            catch (Exception ex)
            {
                ErrorNo = 0;
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, ex.Message, "CEntityMaster", ex); ;
            }

        }


        public MethodExecResult UpdateEntityProductDetails(int nClientNo, DataTable p_vdsTempTableData, DateTime? p_dLastUpdatedDate)
        {
            DbWorkItem objdbwork = new DbWorkItem("stp_CCMMasterEntityExchangeDetails");
            try
            {
                DataSet l_dsFileData = new DataSet();

                DataTable dtUpdated = p_vdsTempTableData.Copy();


                dtUpdated.TableName = "#tb_UCCExchangeProduct";


                dtUpdated.Columns["n_ClientExMapNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_ClientExMapNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "4");

                dtUpdated.Columns["n_ClientNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["n_ClientNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "4");

                dtUpdated.Columns["n_ExNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["n_ExNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "5");

                dtUpdated.Columns["ExchangeNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["ExchangeNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "5");

                dtUpdated.Columns["n_SegmentNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["n_SegmentNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["s_Code"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_Code"].ExtendedProperties.Add(DbManager.ColLengthAttr, "25");

                dtUpdated.Columns["s_CPCode"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["s_CPCode"].ExtendedProperties.Add(DbManager.ColLengthAttr, "25");

                dtUpdated.Columns["n_ClientType"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["n_ClientType"].ExtendedProperties.Add(DbManager.ColLengthAttr, "2");

                dtUpdated.Columns["n_AccountType"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["n_AccountType"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["d_ClientAgreementDate"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["d_ClientAgreementDate"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["s_InpersonVerification"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_InpersonVerification"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["s_ClientStatus"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_ClientStatus"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["s_Remarks"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_Remarks"].ExtendedProperties.Add(DbManager.ColLengthAttr, "200");

                dtUpdated.Columns["s_UCCDownloaded"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_UCCDownloaded"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");


                dtUpdated.Columns["n_BatchNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_BatchNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "2");

                dtUpdated.Columns["n_BranchNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["n_BranchNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "4");

                dtUpdated.Columns["n_GroupNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["n_GroupNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "4");

                dtUpdated.Columns["n_UCCRejRefNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["n_UCCRejRefNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "4");

                dtUpdated.Columns["d_LastModifiedDateTime"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["d_LastModifiedDateTime"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["s_Relationship"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["s_Relationship"].ExtendedProperties.Add(DbManager.ColLengthAttr, "2");

                dtUpdated.Columns["n_UserNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["n_UserNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "4");

                dtUpdated.Columns["s_CTCLTWSId"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_CTCLTWSId"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["s_TradingBranchCode"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_TradingBranchCode"].ExtendedProperties.Add(DbManager.ColLengthAttr, "25");

                dtUpdated.Columns["n_MakerUser"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["n_MakerUser"].ExtendedProperties.Add(DbManager.ColLengthAttr, "4");

                dtUpdated.Columns["d_MakerDatetime"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["d_MakerDatetime"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["n_AuthorizeUser"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["n_AuthorizeUser"].ExtendedProperties.Add(DbManager.ColLengthAttr, "4");

                dtUpdated.Columns["d_AuthorizeDatetime"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["d_AuthorizeDatetime"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");


                dtUpdated.Columns["s_AuthorizationRemarks"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_AuthorizationRemarks"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdated.Columns["s_IsPendingAuth"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_IsPendingAuth"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["s_AuthorizedStatus"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_AuthorizedStatus"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");


                l_dsFileData.Tables.Add(dtUpdated);

                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.InputData = l_dsFileData;
                SqlParameter outParamErrNo = new SqlParameter("@pn_ErrorNo", SqlDbType.Int, 8);
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outParamErrMsg = new SqlParameter("@ps_ErrorMsg", SqlDbType.VarChar, 100);
                outParamErrMsg.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrMsg);

                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "U");
                objdbwork.AddParameter("@pn_ClientNo", SqlDbType.Int, nClientNo);
                objdbwork.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

                objdbwork.AddParameter("@pd_dLastModifiedDate", SqlDbType.DateTime, p_dLastUpdatedDate);

                if (ErrorMsg == "Y")
                    objdbwork.AddParameter("@ps_Process", SqlDbType.Char, "P");
                else
                    objdbwork.AddParameter("@ps_Process", SqlDbType.Char, "A");
                DbManager.Instance.ExecuteDbTask(objdbwork);

                ErrorNo = Convert.ToInt32(objdbwork.parameters[0].Value);
                if (ErrorNo == 101)
                    ErrorMsg = Convert.ToString(objdbwork.parameters[1].Value);

                //To Trap bussiness error for web 
                if (ErrorNo != 0)
                {
                    return new MethodExecResult(ErrorNo, ErrorMsg, "CEntityMaster", null);
                }
                return objdbwork.ExecutionStatus;

            }
            catch (Exception ex)
            {
                ErrorNo = 0;
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, ex.Message, "CEntityMaster", ex); ;
            }

        }

        /// <summary>
        /// Method to upload binary image data in database
        /// </summary>
        /// <param name="Operation">DBOperation</param>
        /// <param name="ClientDocNo">ClientDocument No</param>
        /// <param name="FileName">FileName</param>
        /// <param name="binaryData">File Binary data</param>
        /// <param name="Remarks">Remarks if any</param>
        /// <param name="FileSizeInBytes">File Size(byte)</param>
        /// <param name="FileModifiedDateTime">File Modified DateTime</param>
        /// <returns>Method execution status</returns>
        public static MethodExecResult UploadDocument(string Operation, int ClientDocNo, string FileName,
            byte[] binaryData, string Remarks, long FileSizeInBytes, DateTime? FileModifiedDateTime, int ClientNo, char EntityType, string RepresentativeNo, string DocProofNo, DateTime? DocExpiryDate) 
        {
            try
            {

                DbWorkItem objdbwork = new DbWorkItem("stp_CCMDocumentBinaryMaster");
                objdbwork.ResultType = QueryType.DataSet;

                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, Operation);
                objdbwork.AddParameter("@ps_FileName", SqlDbType.VarChar, FileName);
                objdbwork.AddParameter("@pn_ClientDocNo", SqlDbType.Int, ClientDocNo);
                objdbwork.AddParameter("@pb_BinaryDoc", SqlDbType.VarBinary, binaryData);
                objdbwork.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);
                objdbwork.AddParameter("@pn_ClientNo", SqlDbType.Int, ClientNo);
                objdbwork.AddParameter("@ps_Remarks", SqlDbType.VarChar, Remarks);

                objdbwork.AddParameter("@pn_FileSizeBytes", SqlDbType.BigInt, FileSizeInBytes);
                objdbwork.AddParameter("@pd_FileModifiedDateTime", SqlDbType.DateTime, FileModifiedDateTime);
                objdbwork.AddParameter("@ps_EntityType", SqlDbType.VarChar, EntityType);
                objdbwork.AddParameter("@pn_RepresentativeNo", SqlDbType.VarChar, RepresentativeNo);

                objdbwork.AddParameter("@ps_DocProofNo", SqlDbType.VarChar, DocProofNo);
                objdbwork.AddParameter("@pd_DocExpiryDate", SqlDbType.DateTime, DocExpiryDate);

                DbManager.Instance.ExecuteDbTask(objdbwork);
                return objdbwork.ExecutionStatus;

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }

        }


        /// <summary>
        /// Get document details of Upload document for web call
        /// </summary>
        /// <param name="ClientNo">EntityNo</param>
        /// <param name="resultDataTable">Entity Uploaded document details</param>
        /// <returns>Execution Status</returns>
        public static MethodExecResult GetUploadedDocumentDetail(int ClientNo, ref DataTable resultDataTable)
        {
            try
            {

                DbWorkItem objdbwork = new DbWorkItem("stp_CCMDocumentBinaryMaster");
                objdbwork.ResultType = QueryType.DataSet;

                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "SD");
                objdbwork.AddParameter("@pn_ClientNo", SqlDbType.Int, ClientNo);
                objdbwork.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = objdbwork.Result as DataSet;
                    if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_CCMDocumentBinaryMaster. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        resultDataTable = l_dsReturnData.Tables[0];
                        return objdbwork.ExecutionStatus;
                    }
                }
                else
                {
                    return objdbwork.ExecutionStatus;
                }

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }

        }

        /// <summary>
        /// Get document details of Upload document for web call
        /// </summary>
        /// <param name="ClientNo">EntityNo</param>
        /// <param name="resultDataSet">Entity Uploaded document details</param>
        /// <returns>Execution Status</returns>
        public static MethodExecResult GetUploadedDocumentDetail(int ClientNo, ref DataSet resultDataSet)
        {
            try
            {

                DbWorkItem objdbwork = new DbWorkItem("stp_CCMDocumentBinaryMaster");
                objdbwork.ResultType = QueryType.DataSet;

                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "W");
                objdbwork.AddParameter("@pn_ClientNo", SqlDbType.Int, ClientNo);
                objdbwork.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = objdbwork.Result as DataSet;
                    if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_CCMDocumentBinaryMaster. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        resultDataSet = l_dsReturnData;
                        return objdbwork.ExecutionStatus;
                    }
                }
                else
                {
                    return objdbwork.ExecutionStatus;
                }

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }

        }


        public static MethodExecResult GetUploadType(int ClientNo, ref DataSet resultDataSet)
        {
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_GetDocNo");
                objdbwork.ResultType = QueryType.DataSet;

                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "SU");
                objdbwork.AddParameter("@pn_ClientNo", SqlDbType.Int, ClientNo);

                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = objdbwork.Result as DataSet;
                    if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_GetDocNo. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        resultDataSet = l_dsReturnData;
                        return objdbwork.ExecutionStatus;
                    }
                }
                else
                {
                    return objdbwork.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }
        }



        /// <summary>
        /// Get Binary Image data from database
        /// </summary>
        /// <param name="ClienDoctNo">ClientDocument No</param>
        /// <param name="resultDataTable">DataTable containing Binary data</param>
        /// <returns>Execution Status</returns>
        public static MethodExecResult GetUploadedDocumentImage(int ClienDoctNo, char EntityType, ref DataTable resultDataTable)
        {
            try
            {

                DbWorkItem objdbwork = new DbWorkItem("stp_CCMDocumentBinaryMaster");//string operationFlag
                objdbwork.ResultType = QueryType.DataSet;

                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "S");
                objdbwork.AddParameter("@pn_ClientDocNo", SqlDbType.Int, ClienDoctNo);
                objdbwork.AddParameter("@ps_EntityType", SqlDbType.VarChar, EntityType);
                objdbwork.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);



                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = objdbwork.Result as DataSet;
                    if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_CCMDocumentBinaryMaster. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        resultDataTable = l_dsReturnData.Tables[0];
                        return objdbwork.ExecutionStatus;
                    }
                }
                else
                {
                    return objdbwork.ExecutionStatus;
                }

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }

        }

        /// <summary>
        /// Get client Doc No for web call fron Doc upload tab
        /// </summary>
        /// <param name="ClientNo">Client No</param>
        /// <param name="nType">Document Type</param>
        /// <param name="dt_DocNo">Datatable containing client doc no</param>
        /// <returns>Execution Status</returns>
        public static MethodExecResult GetDocNo(int ClientNo, int nType, ref DataTable dt_DocNo)
        {
            try
            {

                DbWorkItem objdbwork = new DbWorkItem("stp_GetDocNo");//string operationFlag
                objdbwork.ResultType = QueryType.DataSet;

                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "A");
                objdbwork.AddParameter("@pn_ClientNo", SqlDbType.Int, ClientNo);
                objdbwork.AddParameter("@ps_DocType", SqlDbType.Int, nType);



                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = objdbwork.Result as DataSet;
                    if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_GetDocNo. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        dt_DocNo = l_dsReturnData.Tables[0];
                        return objdbwork.ExecutionStatus;
                    }
                }
                else
                {
                    return objdbwork.ExecutionStatus;
                }

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }

        }

        public static MethodExecResult DeleteDocDetails(int ClientNo)
        {
            try
            {

                DbWorkItem objdbwork = new DbWorkItem("stp_GetDocNo");//string operationFlag
                objdbwork.ResultType = QueryType.DataSet;

                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "D");
                objdbwork.AddParameter("@pn_ClientNo", SqlDbType.Int, ClientNo);

                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    //DataSet l_dsReturnData = objdbwork.Result as DataSet;
                    //if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                    //    return new MethodExecResult(1, "No data found", "stp_GetDocNo. Database returned no data. UserNo. " +
                    //        AppEnvironment.AppUser.UserNo.ToString(), null);
                    //else
                    //{
                    //    dt_DocNo = l_dsReturnData.Tables[0];
                        return objdbwork.ExecutionStatus;
                    //}
                }
                else
                {
                    return objdbwork.ExecutionStatus;
                }

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }                
        }

        public static MethodExecResult InsertUploadOption(int ClientNo, string UploadType)
        {
            try
            {

                DbWorkItem objdbwork = new DbWorkItem("stp_GetDocNo");//string operationFlag
                objdbwork.ResultType = QueryType.DataSet;

                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "I");
                objdbwork.AddParameter("@pn_ClientNo", SqlDbType.Int, ClientNo);
                objdbwork.AddParameter("@ps_UploadType", SqlDbType.VarChar, UploadType);

                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    //DataSet l_dsReturnData = objdbwork.Result as DataSet;
                    //if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                    //    return new MethodExecResult(1, "No data found", "stp_GetDocNo. Database returned no data. UserNo. " +
                    //        AppEnvironment.AppUser.UserNo.ToString(), null);
                    //else
                    //{
                    //    dt_DocNo = l_dsReturnData.Tables[0];
                    return objdbwork.ExecutionStatus;
                    //}
                }
                else
                {
                    return objdbwork.ExecutionStatus;
                }

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }
        }


        /// <summary>
        /// Search Entity help details by provided key using random search
        /// </summary>
        /// <param name="sSeatchKey">Key for searching the data</param>
        /// <param name="resultDataTable">Entity result DataTable</param>
        /// <returns>Execution status</returns>
        public static MethodExecResult GetEntityHelp(string sSeatchKey, string sHelpColumn, int ClientNo, ref DataTable resultDataTable)
        {
            try
            {

                DbWorkItem objdbwork = new DbWorkItem("stp_RetrieveEntitiesHelpDetails");
                objdbwork.ResultType = QueryType.DataSet;

                objdbwork.AddParameter("@ps_HelpKey", SqlDbType.VarChar, sSeatchKey);
                objdbwork.AddParameter("@ps_Column", SqlDbType.VarChar, sHelpColumn.ToUpper());
                objdbwork.AddParameter("@pn_EntityNo", SqlDbType.Int, ClientNo);



                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = objdbwork.Result as DataSet;
                    if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_RetrieveEntitiesHelpDetails. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        resultDataTable = l_dsReturnData.Tables[0];
                        return objdbwork.ExecutionStatus;
                    }
                }
                else
                {
                    return objdbwork.ExecutionStatus;
                }

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }

        }

        /// <summary>
        /// Get Authorised Signatories details for provided Entity
        /// </summary>
        /// <param name="NonIndividualClientNo">NonInd. ClientNo</param>
        /// <param name="resultDataTable">Entity details DataTable</param>
        /// <param name="addressDataTable">Entity Address Details</param>
        /// <returns>Excecution Status</returns>
        public static MethodExecResult GetAuthSignDetails(int NonIndividualClientNo,
            ref DataTable resultDataTable, ref DataTable addressDataTable)
        {
            try
            {

                DbWorkItem objdbwork = new DbWorkItem("stp_CCMMasterAuthSign");
                objdbwork.ResultType = QueryType.DataSet;

                if (NonIndividualClientNo > 0)
                    objdbwork.AddParameter("@pn_ClientNoNonInd", SqlDbType.Int, NonIndividualClientNo);

                objdbwork.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);
                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "S");

                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = objdbwork.Result as DataSet;
                    if ((l_dsReturnData == null || l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_CCMMasterAuthSign. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        resultDataTable = l_dsReturnData.Tables[0];
                        addressDataTable = l_dsReturnData.Tables[1];
                        return objdbwork.ExecutionStatus;
                    }
                }
                else
                {
                    return objdbwork.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }
        }

        /// <summary>
        /// Bulk update Authorised Signatories Details
        /// </summary>
        /// <param name="nClientNo">ClientNo</param>
        /// <param name="p_vdsTempTableData">Source DataTable</param>
        /// <returns>Method Execution Status</returns>
        public MethodExecResult UpdateEntityAuthSignDetails(int nClientNo, DataTable p_vdsTempTableData, DataTable p_vdsTempAddressData, DateTime? pd_LastUpdateDate)
        {
            DbWorkItem objdbwork = new DbWorkItem("stp_CCMMasterAuthSign");
            try
            {
                DataSet l_dsFileData = new DataSet();

                DataTable dtUpdated = p_vdsTempTableData.Copy();

                DataTable dtUpdatedAddress = p_vdsTempAddressData.Copy();

               // dtUpdatedAddress.Columns.Add("n_AddressNo", typeof(int));


                dtUpdated.TableName = "#tb_ClientAuthSignDetails";

                dtUpdated.Columns["n_RelatedEntityNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_RelatedEntityNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["n_Type"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_Type"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["n_RelationshipNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_RelationshipNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["n_EntityNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_EntityNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["n_RelatedPartyNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_RelatedPartyNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["n_RowNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_RowNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["s_Details"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_Details"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdated.Columns["s_ClientName"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_ClientName"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");


                dtUpdated.Columns["s_HasChanged"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_HasChanged"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["DOB"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["DOB"].ExtendedProperties.Add(DbManager.ColLengthAttr, "24");

                dtUpdated.Columns["POADate"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["POADate"].ExtendedProperties.Add(DbManager.ColLengthAttr, "24");

                dtUpdated.Columns["sAuthSign"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["sAuthSign"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["s_OtherRelation"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_OtherRelation"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["s_PANNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_PANNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "10");

                dtUpdated.Columns["s_GuardianName"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_GuardianName"].ExtendedProperties.Add(DbManager.ColLengthAttr, "255");

                dtUpdated.Columns["n_Occupation"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_Occupation"].ExtendedProperties.Add(DbManager.ColLengthAttr, "4");

                dtUpdated.Columns["s_AatharNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_AatharNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "25");

                dtUpdated.Columns["s_MinerRelation"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_MinerRelation"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["n_IsNomineeAddsameasEntity"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_IsNomineeAddsameasEntity"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["s_DematStatus"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["s_DematStatus"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");


                dtUpdated.Columns["s_AccountType"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["s_AccountType"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["s_DPID"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["s_DPID"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");


                dtUpdated.Columns["s_DPName"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["s_DPName"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");


                dtUpdated.Columns["s_BeneficiaryId"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["s_BeneficiaryId"].ExtendedProperties.Add(DbManager.ColLengthAttr, "16");

                dtUpdated.Columns["s_OccupationOthers"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["s_OccupationOthers"].ExtendedProperties.Add(DbManager.ColLengthAttr, "75");

                dtUpdated.Columns["s_DPType"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["s_DPType"].ExtendedProperties.Add(DbManager.ColLengthAttr, "4");


                //uncommented
                dtUpdated.Columns["s_Nomination"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["s_Nomination"].ExtendedProperties.Add(DbManager.ColLengthAttr, "4");

                dtUpdated.Columns["n_AccountStatement"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_AccountStatement"].ExtendedProperties.Add(DbManager.ColLengthAttr, "4");

                dtUpdatedAddress.TableName = "#tb_Address";

                dtUpdatedAddress.Columns["n_ClientNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdatedAddress.Columns["n_ClientNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdatedAddress.Columns["n_AddressNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdatedAddress.Columns["n_AddressNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdatedAddress.Columns["n_RowNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdatedAddress.Columns["n_RowNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdatedAddress.Columns["s_AddressLine1"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdatedAddress.Columns["s_AddressLine1"].ExtendedProperties.Add(DbManager.ColLengthAttr, "255");

                dtUpdatedAddress.Columns["s_AddressLine2"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdatedAddress.Columns["s_AddressLine2"].ExtendedProperties.Add(DbManager.ColLengthAttr, "255");

                dtUpdatedAddress.Columns["s_AddressLine3"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdatedAddress.Columns["s_AddressLine3"].ExtendedProperties.Add(DbManager.ColLengthAttr, "255");

                dtUpdatedAddress.Columns["n_CityStateCode"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdatedAddress.Columns["n_CityStateCode"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdatedAddress.Columns["s_StateOther"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdatedAddress.Columns["s_StateOther"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdatedAddress.Columns["n_CountryCode"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdatedAddress.Columns["n_CountryCode"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdatedAddress.Columns["n_StateNumber"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdatedAddress.Columns["n_StateNumber"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdatedAddress.Columns["s_PinCode"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdatedAddress.Columns["s_PinCode"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdatedAddress.Columns["s_TelNo1"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdatedAddress.Columns["s_TelNo1"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdatedAddress.Columns["s_TelNoOffice"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdatedAddress.Columns["s_TelNoOffice"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdatedAddress.Columns["s_FaxNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdatedAddress.Columns["s_FaxNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdatedAddress.Columns["s_City"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdatedAddress.Columns["s_City"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdatedAddress.Columns["s_EMailId"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdatedAddress.Columns["s_EMailId"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdatedAddress.Columns["s_Mobile1"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdatedAddress.Columns["s_Mobile1"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");

                dtUpdatedAddress.Columns["s_Mobile2"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdatedAddress.Columns["s_Mobile2"].ExtendedProperties.Add(DbManager.ColLengthAttr, "100");


                l_dsFileData.Tables.Add(dtUpdated);
                l_dsFileData.Tables.Add(dtUpdatedAddress);



                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.InputData = l_dsFileData;

                SqlParameter outParamErrNo = new SqlParameter("@pn_ErrorNo", SqlDbType.Int, 8);
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outParamErrMsg = new SqlParameter("@ps_ErrorMsg", SqlDbType.VarChar, 100);
                outParamErrMsg.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrMsg);

                objdbwork.AddParameter("@pn_ClientNoNonInd", SqlDbType.Int, nClientNo);
                objdbwork.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);
                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "U");
                objdbwork.AddParameter("@pd_dLastModifiedDate", SqlDbType.DateTime, pd_LastUpdateDate);



                if (ErrorMsg == "Y")
                    objdbwork.AddParameter("@ps_Process", SqlDbType.Char, "P");
                else
                    objdbwork.AddParameter("@ps_Process", SqlDbType.Char, "A");


                DbManager.Instance.ExecuteDbTask(objdbwork);

                ErrorNo = Convert.ToInt32(objdbwork.parameters[0].Value);
                if (ErrorNo == 101)
                    ErrorMsg = Convert.ToString(objdbwork.parameters[1].Value);

                //To Trap bussiness error for web 
                if (ErrorNo != 0)
                {
                    return new MethodExecResult(ErrorNo, ErrorMsg, "CEntityMaster", null);
                }

                return objdbwork.ExecutionStatus;
            }
            catch (Exception ex)
            {
                ErrorNo = 0;
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, ex.Message, "CEntityMaster", ex); ;
            }

        }

        /// <summary>
        /// Cancel Maker Changes 
        /// </summary>
        /// <param name="ClientNo">ClientNo</param>
        /// <returns>Execution result</returns>
        public MethodExecResult MakerCancel(int ClientNo)
        {
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_CDDMakerCancel");
                objdbwork.ResultType = QueryType.DataSet;

                objdbwork.AddParameter("@Pn_EntityNo", SqlDbType.Int, ClientNo);
                objdbwork.AddParameter("@Pn_EntityType", SqlDbType.Int, CCMConstants.CONST_AUTHORIZATION_ACCOUNT_DETAIL);
                objdbwork.AddParameter("@Pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

                DbManager.Instance.ExecuteDbTask(objdbwork);
                return objdbwork.ExecutionStatus;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }

        }

        /// <summary>
        /// Method to validate the date
        /// </summary>
        /// <param name="dt">DateTime object for varification</param>
        /// <returns>True for valid date</returns>
        public static bool IsValidDate(DateTime? dt)
        {
            if (dt == null) return false;
            if (!dt.HasValue) return false;
            return !(dt == DateTime.MaxValue || dt == DateTime.MinValue);
        }

        /// <summary>
        /// DOB validation Failure 
        /// Delete's client Record in Aadhaar Mode. 
        /// </summary>
        /// <param name="ClientNo">ClientNo</param>
        /// <returns></returns>
        public static MethodExecResult DOBValidationFailure(int ClientNo)
        {
            try
            {

                DbWorkItem objdbwork = new DbWorkItem("stp_DOBValidationFailure");
                objdbwork.ResultType = QueryType.DataSet;
                                
                objdbwork.AddParameter("@pn_ClientNo", SqlDbType.Int, ClientNo);

                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    return objdbwork.ExecutionStatus;                   
                }
                else
                {
                    return objdbwork.ExecutionStatus;
                }

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }                
        }

        #region FreezeEntity
        public MethodExecResult FreezeEntity(int nClientNo)
        {
            try
            {
                DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_CDDFreezeEntity");
                l_objDbWorkItem.ResultType = QueryType.DataSet;

                l_objDbWorkItem.AddParameter("@pn_EntityNo", SqlDbType.Int, nClientNo);
                l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);


                return l_objDbWorkItem.ExecutionStatus;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, ex.Message, "CEntityMaster", ex);
            }

        }
        #endregion


        /// <summary>
        /// Bulk Update Entity Custodian details
        /// </summary>
        /// <param name="nClientNo">EntityNo</param>
        /// <param name="p_vdsTempTableData">Source DataTable - to be update in database</param>
        /// <returns>Method execution result</returns>
        public MethodExecResult UpdateEntityCustodianDetails(int nClientNo, DataTable p_vdsTempTableData, DateTime? p_dLastUpdatedDate)
        {
            DbWorkItem objdbwork = new DbWorkItem("stp_CCMMasterEntityCustodianDtls");
            try
            {
                DataSet l_dsFileData = new DataSet();

                DataTable dtUpdated = p_vdsTempTableData.Copy();

                dtUpdated.TableName = "#tb_CustodianDetails";
                

                dtUpdated.Columns["n_ClientCustodianNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_ClientCustodianNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "10");

                dtUpdated.Columns["n_ExchangeNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_ExchangeNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "10");

                dtUpdated.Columns["n_CustodianNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_CustodianNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "10");

                dtUpdated.Columns["s_CustodianCode"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_CustodianCode"].ExtendedProperties.Add(DbManager.ColLengthAttr, "5");

                dtUpdated.Columns["s_CustodianName"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_CustodianName"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["s_ParticipentId"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_ParticipentId"].ExtendedProperties.Add(DbManager.ColLengthAttr, "25");

                dtUpdated.Columns["d_FromDate"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["d_FromDate"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["d_ToDate"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["d_ToDate"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                //dtUpdated.Columns["n_ClientNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                //dtUpdated.Columns["n_ClientNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "4");

                //dtUpdated.Columns["s_HasChanged"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                //dtUpdated.Columns["s_HasChanged"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");


                l_dsFileData.Tables.Add(dtUpdated);

               
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.InputData = l_dsFileData;
                SqlParameter outParamErrNo = new SqlParameter("@pn_ErrorNo", SqlDbType.Int, 8);
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outParamErrMsg = new SqlParameter("@ps_ErrorMsg", SqlDbType.VarChar, 100);
                outParamErrMsg.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrMsg);

                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "U");
                objdbwork.AddParameter("@pn_ClientNo", SqlDbType.Int, nClientNo);
                objdbwork.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);
                objdbwork.AddParameter("@pd_MakerDatetime", SqlDbType.DateTime, p_dLastUpdatedDate);

                if (ErrorMsg == "Y")
                    objdbwork.AddParameter("@ps_Process", SqlDbType.Char, "P");
                else
                    objdbwork.AddParameter("@ps_Process", SqlDbType.Char, "A");
                DbManager.Instance.ExecuteDbTask(objdbwork);

                ErrorNo = Convert.ToInt32(objdbwork.parameters[0].Value);
                if (ErrorNo == 101)
                    ErrorMsg = Convert.ToString(objdbwork.parameters[1].Value);

                //To Trap bussiness error for web 
                if (ErrorNo != 0)
                {
                    return new MethodExecResult(ErrorNo, ErrorMsg, "CEntityMaster", null);
                }

                return objdbwork.ExecutionStatus;

            }

            catch (Exception ex)
            {
                ErrorNo = 0;
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, ex.Message, "CEntityMaster", ex); ;
            }
        }


        /// <summary>
        /// Search Entity help details by provided key using random search
        /// </summary>
        /// <param name="sSeatchKey">Key for searching the data</param>
        /// <param name="resultDataTable">Entity result DataTable</param>
        /// <returns>Execution status</returns>
        /// 

        public static DataSet SchemaOperation(int n_EntityNo, decimal n_SchemeAmount, decimal n_Amount, string s_PaymentType, string s_SchemeName, string s_Segment, string s_Product, string s_Mode, ref int result, ref DataSet DS, string s_AmountFlag, decimal d_EquityAmount, decimal d_CommodityAmount, string s_Chqno_Trnsno)    
        {
            DataSet l_dsReturnData = new DataSet();            
            try                                        
            {

                DbWorkItem objdbwork = new DbWorkItem("stp_KYC_SchemeSetGet");
                objdbwork.ResultType = QueryType.DataSet;

                objdbwork.AddParameter("@Pn_EntityNo", SqlDbType.Int, n_EntityNo);
                objdbwork.AddParameter("@Ps_Mode", SqlDbType.Char, s_Mode);
                if (s_Mode == "SC")
                {
                    objdbwork.AddParameter("@Pn_SchemeAmount", SqlDbType.Money, n_SchemeAmount);
                    objdbwork.AddParameter("@Ps_SchemeName", SqlDbType.VarChar, s_SchemeName);
                    objdbwork.AddParameter("@Ps_Segment", SqlDbType.VarChar, s_Segment);
                    objdbwork.AddParameter("@Ps_Product", SqlDbType.VarChar, s_Product);
                    objdbwork.AddParameter("@Ps_AmountFlag", SqlDbType.VarChar, s_AmountFlag);
                }
                else if (s_Mode == "P")
                {
                    objdbwork.AddParameter("@Ps_Chqno_Trnsno", SqlDbType.VarChar, s_Chqno_Trnsno);
                    objdbwork.AddParameter("@Pn_Amount", SqlDbType.Money, n_Amount);
                    if (d_CommodityAmount!=0)
                    objdbwork.AddParameter("@Pn_CommodityAmount", SqlDbType.Money, d_CommodityAmount);
                    if (d_EquityAmount!=0)
                    objdbwork.AddParameter("@Pn_EquityAmount", SqlDbType.Money, d_EquityAmount);
                    objdbwork.AddParameter("@Ps_PaymentType", SqlDbType.VarChar, s_PaymentType);
                }
                
                SqlParameter outParamErrNo = new SqlParameter();
                outParamErrNo.ParameterName = "@Ps_ErrorCode";
                outParamErrNo.SqlDbType = SqlDbType.Int;
                outParamErrNo.Size = 8;
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outparam = new SqlParameter();
                outparam.ParameterName = "@Ps_ErrorMessage";
                outparam.SqlDbType = SqlDbType.VarChar;
                outparam.Size = 100;
                outparam.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outparam);

                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                     l_dsReturnData = objdbwork.Result as DataSet;

                     DataTable l_Schema = l_dsReturnData.Tables[0].Copy();
                     l_Schema.TableName = "Scheme";// + l_nScheme_Count;
                     DS.Tables.Add(l_Schema);
                }
                else
                {
                    //return objdbwork.ExecutionStatus;
                }
                result = 0;
            }
            catch (Exception ex)
            {
                result = -1;
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                //return new MethodExecResult(-1, null, ex.Message, null);
            }
            return l_dsReturnData;
        }

        public MethodExecResult GetCity(string n_EntityNo, ref DataSet dsdata, string s_CityName = null)
        {
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_GetMastersData");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@ps_CityName", SqlDbType.VarChar, s_CityName);
                objdbwork.AddParameter("@pn_UserNo", SqlDbType.VarChar, n_EntityNo);

                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {

                    dsdata = objdbwork.Result as DataSet;
                    if ((dsdata == null) || (dsdata.Tables.Count == 0))
                    {
                        return new MethodExecResult(-1, null, "No recordset returned from database.", null);
                    }

                    return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, string.Empty, null);
                }
                else
                {
                    Logger.Instance.WriteLog(typeof(CTabStatus), objdbwork.ExecutionStatus);
                    return objdbwork.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CTabStatus), ex.Message, ex);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }
        }

        public MethodExecResult GetBranch(string n_EntityNo, ref DataSet dsdata, string s_BranchCode = null)
        {
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_GetMasterBranchData");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@ps_BranchCode", SqlDbType.VarChar, s_BranchCode);
                objdbwork.AddParameter("@pn_UserNo", SqlDbType.VarChar, n_EntityNo);

                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {

                    dsdata = objdbwork.Result as DataSet;
                    if ((dsdata == null) || (dsdata.Tables.Count == 0))
                    {
                        return new MethodExecResult(-1, null, "No recordset returned from database.", null);
                    }

                    return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, string.Empty, null);
                }
                else
                {
                    Logger.Instance.WriteLog(typeof(CTabStatus), objdbwork.ExecutionStatus);
                    return objdbwork.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CTabStatus), ex.Message, ex);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }
        }

        public MethodExecResult UpdateEntityIntAndAuthDetails(int nClientNo, DataTable p_vdsTempTableData, DateTime? p_dLastUpdatedDate)
        {
            DbWorkItem objdbwork = new DbWorkItem("stp_CCMMasterEntityIntAndAuthDtls");
            try
            {
                DataSet l_dsFileData = new DataSet();

                DataTable dtUpdated = p_vdsTempTableData.Copy();


                dtUpdated.TableName = "#tb_ClientIntAndAuthDetails";


                dtUpdated.Columns["n_RelatedPartyNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_RelatedPartyNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["n_ClientNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_ClientNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["s_SebiRegNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_SebiRegNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "15");
                
                dtUpdated.Columns["n_Status"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_Status"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["s_OthersStatus"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_OthersStatus"].ExtendedProperties.Add(DbManager.ColLengthAttr, "80");

                dtUpdated.Columns["n_Type"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_Type"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["s_Name"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_Name"].ExtendedProperties.Add(DbManager.ColLengthAttr, "80");

                dtUpdated.Columns["n_RelationshipNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_RelationshipNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["n_AddressType"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_AddressType"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["n_AddressNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_AddressNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["s_AddressLine1"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_AddressLine1"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["s_AddressLine2"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_AddressLine2"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["s_AddressLine3"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_AddressLine3"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["n_CityStateCode"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_CityStateCode"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["n_CountryCode"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_CountryCode"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["s_PinCode"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_PinCode"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["s_TelNo1"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_TelNo1"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["s_FaxNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_FaxNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["s_City"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_City"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["n_StateNumber"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_StateNumber"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["s_EMailId"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_EMailId"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["s_Mobile1"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_Mobile1"].ExtendedProperties.Add(DbManager.ColLengthAttr, "50");

                dtUpdated.Columns["s_HasChanged"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_HasChanged"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                l_dsFileData.Tables.Add(dtUpdated);

                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.InputData = l_dsFileData;
                SqlParameter outParamErrNo = new SqlParameter("@pn_ErrorNo", SqlDbType.Int, 8);
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outParamErrMsg = new SqlParameter("@ps_ErrorMsg", SqlDbType.VarChar, 100);
                outParamErrMsg.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrMsg);

                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "U");
                objdbwork.AddParameter("@pn_ClientNo", SqlDbType.Int, nClientNo);
                objdbwork.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

                objdbwork.AddParameter("@pd_dLastModifiedDate", SqlDbType.DateTime, p_dLastUpdatedDate);

                objdbwork.AddParameter("@ps_CallingType", SqlDbType.VarChar, "W");

                if (ErrorMsg == "Y")
                    objdbwork.AddParameter("@ps_Process", SqlDbType.Char, "P");
                else
                    objdbwork.AddParameter("@ps_Process", SqlDbType.Char, "A");
                DbManager.Instance.ExecuteDbTask(objdbwork);

                ErrorNo = Convert.ToInt32(objdbwork.parameters[0].Value);
                if (ErrorNo == 101)
                    ErrorMsg = Convert.ToString(objdbwork.parameters[1].Value);

                if (ErrorNo != 0)
                {
                    return new MethodExecResult(ErrorNo, ErrorMsg, "CEntityMaster", null);
                }

                return objdbwork.ExecutionStatus;

            }
            catch (Exception ex)
            {
                ErrorNo = 0;
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, ex.Message, "CEntityMaster", ex); ;
            }

        }

        public static MethodExecResult GetEntityIntAndAuthDetails(int nClientNo,int nRelationshipNo, ref DataTable dtIntAndAuthResult, int nUserNo)
        {

            dtIntAndAuthResult = new DataTable();
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_CCMMasterEntityIntAndAuthDtls");
            try
            {
                l_objDbWorkItem.ResultType = QueryType.DataSet;

                l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, "S");

                l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, nClientNo);
                l_objDbWorkItem.AddParameter("@pn_RelationshipNo", SqlDbType.Int, nRelationshipNo);
                l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, nUserNo);
                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
                if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                    if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_CCMMasterEntityFatcaDtls. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        dtIntAndAuthResult = l_dsReturnData.Tables[0];
                        return l_objDbWorkItem.ExecutionStatus;
                    }
                }
                else
                {
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }
        }

        /// <summary>
        /// Get Client Details 
        /// </summary>
        /// <param name="objCKYCReferenceData"></param>
        /// <returns>MethodExecResult</returns>
        //public static MethodExecResult RetrieveClientExportDetails(CKYCReferenceData objReferenceData, enBatchCode ProcessType, Clients oClients)
        //{
        //    DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_KYCRetrieveClientExportDetails");
        //    DataSet l_dsReturnData = new DataSet();

        //    try
        //    {
        //        l_objDbWorkItem.ResultType = QueryType.DataSet;

        //        l_objDbWorkItem.AddParameter("@Pd_FromDate", SqlDbType.DateTime, objReferenceData.m_dtFromDate);
        //        l_objDbWorkItem.AddParameter("@Pd_ToDate", SqlDbType.DateTime, objReferenceData.m_dtToDate);
        //        l_objDbWorkItem.AddParameter("@ps_BatchText", SqlDbType.Text, ProcessType.ToString());
                		
        //        DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

        //        if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
        //        {
        //            l_dsReturnData = l_objDbWorkItem.Result as DataSet;
        //            if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
        //                return new MethodExecResult(1, "No data found", "stp_KYCRetrieveClientExportDetails. Database returned no data. UserNo. " +
        //                    AppEnvironment.AppUser.UserNo.ToString(), null);
        //            else
        //            {
        //                //First DataTable contains client Data
        //                DataTable dtClients = l_dsReturnData.Tables[0];

        //                //Second DataTable contains address Data
        //                DataTable dtClientsAddress = l_dsReturnData.Tables[1];

        //                //Third DataTable contains  ProofDetails
        //                DataTable dtClientsProofDetails = l_dsReturnData.Tables[2];

        //                //Fourth DataTable contains Nominee Details
        //                DataTable dtNomineeDetails = l_dsReturnData.Tables[3];

        //                //Fourth DataTable contains Nominee Address Details
        //                DataTable dtNomineeAddressDetails = l_dsReturnData.Tables[4];

        //                //Fifth DataTable contains Image Details
        //                DataTable dtClientImageDetails = l_dsReturnData.Tables[5];

        //                //Sixth DataTable contains Bank Details
        //                DataTable dtClientBankDetails = l_dsReturnData.Tables[6];

        //                //7th DataTable contains Trading Details
        //                DataTable dtClientTradingDetails = l_dsReturnData.Tables[7];

        //                //8th DataTable contains DealingThrough Details
        //                DataTable dtClientDealingThroughDetails = l_dsReturnData.Tables[8];

        //                //9th DataTable contains Fatca Details
        //                DataTable dtClientFatcaDetails = l_dsReturnData.Tables[9];

        //                //10th DataTable contains Scheme Details
        //                DataTable dtSchemeDetails = l_dsReturnData.Tables[10];

        //                //11th DataTable contains BATCH NO Details
        //                DataTable dtBatchNoDetails = l_dsReturnData.Tables[11];

        //                for (int i = 0; i < dtClients.Rows.Count; i++)
        //                {
        //                    Client client = new Client();
        //                    client.InstantiateFromDataRow(client, dtClients.Rows[i]);

        //                    //Populate Address collection for the Client
        //                    client.SetClientAddressesFromDataTable(dtClientsAddress);

        //                    //Populate ProofDetails collection for the Client
        //                    client.SetClientProofDetailsFromDataTable(dtClientsProofDetails);

        //                    //Populate Nominee Details collection for the Client
        //                    client.SetClientDPDetailsFromDataTable(dtNomineeDetails);

        //                    //Populate Nominee Address Details collection for the Client
        //                    client.SetNomineeAddressesFromDataTable(dtNomineeAddressDetails);

        //                    //Populate ImageDetails collection for the Client
        //                    client.SetClientImageDetailsFromDataTable(dtClientImageDetails);

        //                    //Populate BankBranchDetails collection for the Client
        //                    client.SetClientBankBranchDetailsFromDataTable(dtClientBankDetails);

        //                    //Populate TradingDetails collection for the Client
        //                    client.SetClientTradingDetailsFromDataTable(dtClientTradingDetails);

        //                    //Populate DealingThroughDetails collection for the Client
        //                    client.SetClientDealingThroughDetailsFromDataTable(dtClientDealingThroughDetails);

        //                    //Populate FatcaDetails collection for the Client
        //                    client.SetClientFatcaDetailsFromDataTable(dtClientFatcaDetails);

        //                    //Populate SchemeDetails collection for the Client
        //                    client.SetSchemeDetailsFromDataTable(dtSchemeDetails);

        //                    oClients.Add(client);
        //                }
        //                if (dtBatchNoDetails.Rows.Count > 0)
        //                    oClients.BatchNo = Convert.ToInt32(dtBatchNoDetails.Rows[0]["n_BatchNo"]);

        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.Instance.WriteLog(typeof(CEntityMaster), ex);
        //        return new MethodExecResult(-1, ex.Message, "GetCKYCClientDetails", ex);
        //    }
        //    return l_objDbWorkItem.ExecutionStatus;
        //}

        public MethodExecResult DBImport(DataTable p_vdsTempTableData, ref  DataSet l_dsReturnData)
        {

            DbWorkItem objdbwork = new DbWorkItem("stp_KYCDPImport");
            try
            {
                DataSet l_dsFileData = new DataSet();
                // DataSet l_dsReturnData = new DataSet();
                DataTable dtUpdated = p_vdsTempTableData.Copy();

                dtUpdated.TableName = "#DPSlipMast";

                dtUpdated.Columns["Depository"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["Depository"].ExtendedProperties.Add(DbManager.ColLengthAttr, "255");

                dtUpdated.Columns["ToControlSheetNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["ToControlSheetNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "30");

                dtUpdated.Columns["ExchangeNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["ExchangeNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "30");

                l_dsFileData.Tables.Add(dtUpdated);

                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.InputData = l_dsFileData;

                SqlParameter outParamErrNo = new SqlParameter("@pn_ErrorNo", SqlDbType.Int, 8);
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outParamErrMsg = new SqlParameter("@ps_ErrorMsg", SqlDbType.VarChar, 100);
                outParamErrMsg.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrMsg);

                DbManager.Instance.ExecuteDbTask(objdbwork);

                ErrorNo = Convert.ToInt32(objdbwork.parameters[0].Value);
                if (ErrorNo == 101)
                    ErrorMsg = Convert.ToString(objdbwork.parameters[1].Value);

                //To Trap bussiness error for web 
                if (ErrorNo != 0)
                {
                    return new MethodExecResult(ErrorNo, ErrorMsg, "CEntityMaster", null);
                }

                l_dsReturnData = objdbwork.Result as DataSet;

                return objdbwork.ExecutionStatus;
            }
            catch (Exception ex)
            {
                ErrorNo = 0;
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, ex.Message, "DBImport", ex); ;
            }

        }



        public MethodExecResult CDSLDBImport(DataTable p_vdsTempTableData, ref  DataSet l_dsReturnData)
        {

            DbWorkItem objdbwork = new DbWorkItem("stp_KYCDPImport");
            try
            {
                DataSet l_dsFileData = new DataSet();
                // DataSet l_dsReturnData = new DataSet();
                DataTable dtUpdated = p_vdsTempTableData.Copy();

                dtUpdated.TableName = "#DPSlipMast";

                dtUpdated.Columns["Depository"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["Depository"].ExtendedProperties.Add(DbManager.ColLengthAttr, "255");

                dtUpdated.Columns["ToControlSheetNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["ToControlSheetNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "30");

                dtUpdated.Columns["ExchangeNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["ExchangeNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "30");

                l_dsFileData.Tables.Add(dtUpdated);

                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.InputData = l_dsFileData;

                SqlParameter outParamErrNo = new SqlParameter("@pn_ErrorNo", SqlDbType.Int, 8);
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outParamErrMsg = new SqlParameter("@ps_ErrorMsg", SqlDbType.VarChar, 100);
                outParamErrMsg.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrMsg);

                DbManager.Instance.ExecuteDbTask(objdbwork);

                ErrorNo = Convert.ToInt32(objdbwork.parameters[0].Value);
                if (ErrorNo == 101)
                    ErrorMsg = Convert.ToString(objdbwork.parameters[1].Value);

                //To Trap bussiness error for web 
                if (ErrorNo != 0)
                {
                    return new MethodExecResult(ErrorNo, ErrorMsg, "CEntityMaster", null);
                }

                l_dsReturnData = objdbwork.Result as DataSet;

                return objdbwork.ExecutionStatus;
            }
            catch (Exception ex)
            {
                ErrorNo = 0;
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, ex.Message, "DBImport", ex); ;
            }

        }

        /// <summary>
        /// Get Client Details 
        /// </summary>
        /// <param name="objCKYCReferenceData"></param>
        /// <returns>MethodExecResult</returns>
        public static MethodExecResult RetrieveClientExportDetails(CKYCReferenceData objReferenceData, enBatchCode ProcessType, Clients oClients)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_KYCRetrieveClientExportDetails");
            DataSet l_dsReturnData = new DataSet();

            try
            {
                l_objDbWorkItem.ResultType = QueryType.DataSet;

                l_objDbWorkItem.AddParameter("@Pd_FromDate", SqlDbType.DateTime, objReferenceData.m_dtFromDate);
                l_objDbWorkItem.AddParameter("@Pd_ToDate", SqlDbType.DateTime, objReferenceData.m_dtToDate);
                l_objDbWorkItem.AddParameter("@ps_BatchText", SqlDbType.Text, ProcessType.ToString());
                l_objDbWorkItem.AddParameter("@ps_OldBatchNo", SqlDbType.Text, objReferenceData.BatchNo);
                l_objDbWorkItem.AddParameter("@pn_ExportType", SqlDbType.Int, objReferenceData.ProcessType);

                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

                if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                    if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_KYCRetrieveClientExportDetails. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        //First DataTable contains client Data
                        DataTable dtClients = l_dsReturnData.Tables[0];

                        //Second DataTable contains address Data
                        DataTable dtClientsAddress = l_dsReturnData.Tables[1];

                        //Third DataTable contains  ProofDetails
                        DataTable dtClientsProofDetails = l_dsReturnData.Tables[2];

                        //Fourth DataTable contains Nominee Details
                        DataTable dtNomineeDetails = l_dsReturnData.Tables[3];

                        //Fourth DataTable contains Nominee Address Details
                        DataTable dtNomineeAddressDetails = l_dsReturnData.Tables[4];

                        //Fifth DataTable contains Image Details
                        DataTable dtClientImageDetails = l_dsReturnData.Tables[5];

                        //Sixth DataTable contains Bank Details
                        DataTable dtClientBankDetails = l_dsReturnData.Tables[6];

                        //7th DataTable contains Trading Details
                        DataTable dtClientTradingDetails = l_dsReturnData.Tables[7];

                        //8th DataTable contains DealingThrough Details
                        DataTable dtClientDealingThroughDetails = l_dsReturnData.Tables[8];

                        //9th DataTable contains Fatca Details
                        DataTable dtClientFatcaDetails = l_dsReturnData.Tables[9];

                        //10th DataTable contains Scheme Details
                        DataTable dtSchemeDetails = l_dsReturnData.Tables[10];

                        //11th DataTable contains BATCH NO Details
                        DataTable dtBatchNoDetails = l_dsReturnData.Tables[11];

                        for (int i = 0; i < dtClients.Rows.Count; i++)
                        {
                            Client client = new Client();
                            client.InstantiateFromDataRow(client, dtClients.Rows[i]);

                            //Populate Address collection for the Client
                            client.SetClientAddressesFromDataTable(dtClientsAddress);

                            //Populate ProofDetails collection for the Client
                            client.SetClientProofDetailsFromDataTable(dtClientsProofDetails);

                            //Populate Nominee Details collection for the Client
                            client.SetClientDPDetailsFromDataTable(dtNomineeDetails);

                            //Populate Nominee Address Details collection for the Client
                            client.SetNomineeAddressesFromDataTable(dtNomineeAddressDetails);

                            //Populate ImageDetails collection for the Client
                            client.SetClientImageDetailsFromDataTable(dtClientImageDetails);

                            //Populate BankBranchDetails collection for the Client
                            client.SetClientBankBranchDetailsFromDataTable(dtClientBankDetails);

                            //Populate TradingDetails collection for the Client
                            client.SetClientTradingDetailsFromDataTable(dtClientTradingDetails);

                            //Populate DealingThroughDetails collection for the Client
                            client.SetClientDealingThroughDetailsFromDataTable(dtClientDealingThroughDetails);

                            //Populate FatcaDetails collection for the Client
                            client.SetClientFatcaDetailsFromDataTable(dtClientFatcaDetails);

                            //Populate SchemeDetails collection for the Client
                            client.SetSchemeDetailsFromDataTable(dtSchemeDetails);

                            oClients.Add(client);
                        }
                        if (dtBatchNoDetails.Rows.Count > 0)
                            oClients.BatchNo = Convert.ToString(dtBatchNoDetails.Rows[0]["n_BatchNo"]);

                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex);
                return new MethodExecResult(-1, ex.Message, "GetCKYCClientDetails", ex);
            }
            return l_objDbWorkItem.ExecutionStatus;
        }

        /// <summary>
        /// Get Batch No List
        /// </summary>
        /// <param name="objBatchRefData"></param>
        /// <param name="dtBatchNoList"></param>
        /// <returns></returns>
        public static MethodExecResult GetBatchNoList(BatchRefData objBatchRefData, ref DataTable dtBatchNoList)
        {
            try
            {
                dtBatchNoList = new DataTable();

                DbWorkItem objdbwork = new DbWorkItem("stp_CCMMasterBatchDetails");
                objdbwork.ResultType = QueryType.DataSet;

                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "S");
                objdbwork.AddParameter("@Pd_FromDate", SqlDbType.DateTime, objBatchRefData.m_dtFromDate);
                objdbwork.AddParameter("@Pd_ToDate", SqlDbType.DateTime, objBatchRefData.m_dtToDate);
                objdbwork.AddParameter("@pn_ExportType", SqlDbType.Int, objBatchRefData.ProcessType);

                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = objdbwork.Result as DataSet;
                    if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_CCMMasterBatchDetails. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        dtBatchNoList = l_dsReturnData.Tables[0];
                        return objdbwork.ExecutionStatus;
                    }
                }
                else
                {
                    return objdbwork.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CTabStatus), ex.Message, ex);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }
        }

        /// <summary>
        /// Update Batch Details
        /// </summary>
        /// <param name="objReferenceData"></param>
        /// <param name="p_vdsTempTableData"></param>
        /// <param name="sFilterData"></param>
        /// <returns></returns>
        public MethodExecResult UpdateBatchDetails(CKYCReferenceData objReferenceData, DataTable p_vdsTempTableData, string sFilterData)
        {
            DbWorkItem objdbwork = new DbWorkItem("stp_CCMMasterBatchDetails");
            try
            {
                DataSet l_dsFileData = new DataSet();

                DataTable dtUpdated = p_vdsTempTableData.Copy();

                dtUpdated.TableName = "#TempExportDetails";

                dtUpdated.Columns["n_ClientNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_ClientNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");


                l_dsFileData.Tables.Add(dtUpdated);

                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.InputData = l_dsFileData;

                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "U");
                objdbwork.AddParameter("@Pd_FromDate", SqlDbType.DateTime, objReferenceData.m_dtFromDate);
                objdbwork.AddParameter("@Pd_ToDate", SqlDbType.DateTime, objReferenceData.m_dtToDate);
                objdbwork.AddParameter("@pn_ExportType", SqlDbType.Int, objReferenceData.ProcessType);

                objdbwork.AddParameter("@ps_FileBatchNo", SqlDbType.VarChar, objReferenceData.BatchNo);
                objdbwork.AddParameter("@pd_FileCreationDate", SqlDbType.DateTime, DateTime.Now);
                objdbwork.AddParameter("@ps_FilterRange", SqlDbType.VarChar, sFilterData);//change
                objdbwork.AddParameter("@ps_ExportOption", SqlDbType.VarChar, objReferenceData.ExportType);
                objdbwork.AddParameter("@ps_FileName", SqlDbType.VarChar, objReferenceData.FileName);
                objdbwork.AddParameter("@pn_NoOfRows", SqlDbType.Int, p_vdsTempTableData.Rows.Count);
                objdbwork.AddParameter("@ps_status", SqlDbType.VarChar, "S");
                objdbwork.AddParameter("@ps_user", SqlDbType.VarChar, objReferenceData.UserID);

                DbManager.Instance.ExecuteDbTask(objdbwork);

                return objdbwork.ExecutionStatus;
            }
            catch (Exception ex)
            {
                ErrorNo = 0;
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, ex.Message, "CEntityMaster", ex); ;
            }

        }
    }
}