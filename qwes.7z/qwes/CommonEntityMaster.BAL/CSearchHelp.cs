﻿using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace FTIL.Match.CDD.BAL
{
   public class CSearchHelp
    { 

        /// <summary>
        /// Search Entity help details by provided key using random search
        /// </summary>
        /// <param name="sSeatchKey">Key for searching the data</param>
        /// <param name="resultDataTable">Entity result DataTable</param>
        /// <returns>Execution status</returns>
       public static MethodExecResult GetEntityHelp(int sHelpType, string sSeatchKey, string sHelpColumn, int ClientNo, ref DataTable resultDataTable, string ConditionValue = null)
        {
            try
            {

                DbWorkItem objdbwork = new DbWorkItem("stp_RetrieveEntitiesHelpDetails");
                objdbwork.ResultType = QueryType.DataSet;

                objdbwork.AddParameter("@ps_HelpType", SqlDbType.Int, sHelpType);
                objdbwork.AddParameter("@ps_HelpKey", SqlDbType.VarChar, sSeatchKey);
                objdbwork.AddParameter("@ps_Column", SqlDbType.VarChar, sHelpColumn.ToUpper());
                objdbwork.AddParameter("@pn_EntityNo", SqlDbType.Int, ClientNo);
                objdbwork.AddParameter("@ps_ConditionValue", SqlDbType.Int, ConditionValue);
                 
                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = objdbwork.Result as DataSet;
                    if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_RetrieveEntitiesHelpDetails. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        resultDataTable = l_dsReturnData.Tables[0];
                        return objdbwork.ExecutionStatus;
                    }
                }
                else
                {
                    return objdbwork.ExecutionStatus;
                } 
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }
        }


        ///// <summary>
        ///// Search Entity help details by provided key using random search
        ///// </summary>
        ///// <param name="sSeatchKey">Key for searching the data</param>
        ///// <param name="resultDataTable">Entity result DataTable</param>
        ///// <returns>Execution status</returns>
        //public static MethodExecResult GetEntityHelp(string sHelpType, string sSeatchKey, string sHelpColumn, int ClientNo, ref DataTable resultDataTable)
        //{
        //    try
        //    {

        //        DbWorkItem objdbwork = new DbWorkItem("stp_RetrieveEntitiesHelpDetails");
        //        objdbwork.ResultType = QueryType.DataSet;

        //        objdbwork.AddParameter("@ps_HelpType", SqlDbType.VarChar, sHelpType);
        //        objdbwork.AddParameter("@ps_HelpKey", SqlDbType.VarChar, sSeatchKey);
        //        objdbwork.AddParameter("@ps_Column", SqlDbType.VarChar, sHelpColumn.ToUpper());
        //        objdbwork.AddParameter("@pn_EntityNo", SqlDbType.Int, ClientNo);

                 
        //        DbManager.Instance.ExecuteDbTask(objdbwork);

        //        if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
        //        {
        //            DataSet l_dsReturnData = objdbwork.Result as DataSet;
        //            if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
        //                return new MethodExecResult(1, "No data found", "stp_RetrieveEntitiesHelpDetails. Database returned no data. UserNo. " +
        //                    AppEnvironment.AppUser.UserNo.ToString(), null);
        //            else
        //            {
        //                resultDataTable = l_dsReturnData.Tables[0];
        //                return objdbwork.ExecutionStatus;
        //            }
        //        }
        //        else
        //        {
        //            return objdbwork.ExecutionStatus;
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
        //        return new MethodExecResult(-1, null, ex.Message, null);
        //    } 
        //}
         
    }
}
