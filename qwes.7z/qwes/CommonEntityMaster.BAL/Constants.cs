﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FTIL.Match.CDD.BAL
{
    /// <summary>
    /// Common Constants for ClientMaster
    /// </summary>
    public static class CCMConstants
    {
        /// <summary>
        /// Individual Entity
        /// </summary>
        public const string INDIVIDUAL = "I";

        /// <summary>
        /// Non-Individual
        /// </summary>
        public const string NON_INDIVIDUAL = "NI";


        /// <summary>
        /// Authorization constant for Account Details
        /// </summary>
        public const int CONST_AUTHORIZATION_ACCOUNT_DETAIL = 1;

        
        /// <summary>
        /// Static PAN No document Type 
        /// </summary>
        public const int CONST_PAN_DOCTYPE = 8;

        /// <summary>
        /// Static CIN Document Type
        /// </summary>
        public const int CONST_CIN_DOCTYPE = 9;


        /// <summary>
        /// Entity freeze status( will be updated in tb_UCCClient_n_RecordStatus column for soft delete purpose)
        /// </summary>
        public const int ENTITY_FREEZE_STATUS = 1;



        public const int CLIENT_CODE_MAX_LENGTH = 10;

    }


}
