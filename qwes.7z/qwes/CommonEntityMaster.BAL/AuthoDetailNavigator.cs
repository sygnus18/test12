using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;

namespace CommonEntityMaster.BAL
{
    /// <summary>
    /// Class for Maker/Checker functionality 
    /// </summary>
    public class AuthoDetailNavigator
    {
        private ArrayList uniqueId;
        private int index;
        private DataTable dtSource;

        public DataView NavigatedDataSource
        {
            get
            {
                dtSource.DefaultView.RowFilter = string.Format("EntityNo={0}", uniqueId[index]);
                dtSource.DefaultView.Sort = "Values desc";
                return dtSource.DefaultView;
            }
        }

        public bool PreviousAllowed
        { get { return index > 0 && index < uniqueId.Count; } }


        public bool NextAllowed
        { get { return index < (uniqueId.Count - 1); } }


        public AuthoDetailNavigator(DataTable dtSource)
        {
            if(dtSource==null)
                throw new Exception("Navigator Data Source is null");
            else if (!dtSource.Columns.Contains("EntityNo"))
                throw new Exception("Navigator source requires a EntityNo column");

            this.dtSource = dtSource;
            this.uniqueId = new ArrayList();
            for (int i = 0; i < dtSource.Rows.Count; i++)
            {
                if (uniqueId.IndexOf(dtSource.Rows[i]["EntityNo"]) < 0)
                    uniqueId.Add(dtSource.Rows[i]["EntityNo"]);
            }
            index = 0;
        }

        public void Next()
        {
            if(this.NextAllowed)
                index++;
        }

        public void Previous()
        {
            if (this.PreviousAllowed)
                index--;
        }
    }
}
