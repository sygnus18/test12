﻿using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Globalization;
using FTIL.Match.Common.Log;

namespace FTIL.Match.CDD.BAL
{
    public class CAADARVerification
    {
        #region Properties

        public string uid { get; set; }
        public string Poi_name { get; set; }
        public string Poi_dob { get; set; }
        public string Poi_gender { get; set; }
        public string Poi_phone { get; set; }
        public string Poi_email { get; set; }

        public string Poa_co { get; set; }
        public string Poa_house { get; set; }
        public string Poa_street { get; set; }
        public string Poa_lm { get; set; }
        public string Poa_loc { get; set; }
        public string Poa_vtc { get; set; }
        public string Poa_subdist { get; set; }
        public string Poa_dist { get; set; }
        public string Poa_state { get; set; }
        public string Poa_pc { get; set; }
        public string Poa_po { get; set; }
        public string Poa_Pht { get; set; }

        #endregion

        public CAADARVerification(DataSet ds, string Email, string mobileNo)
        {
            try
            {
                DataTable dtUidData = new DataTable();
                DataTable dtPOI = new DataTable();
                DataTable dtPOA = new DataTable();

                //dtPOI = ds.Tables["dtPOI"];
                //dtPOA = ds.Tables["dtPOA"];
                dtUidData = ds.Tables["UIDdata"];
                dtPOI = ds.Tables["poi"];
                dtPOA = ds.Tables["poa"];

                uid = dtUidData.Columns.Contains("uid") ? dtUidData.Rows[0]["uid"].ToString() : string.Empty;
                Poa_Pht = dtUidData.Columns.Contains("Pht") ? dtUidData.Rows[0]["Pht"].ToString() : string.Empty;

                Logger.Instance.WriteLog(typeof(CAADARVerification), "Client Photo Of Aadhaar No : uid " + uid + " " + Poa_Pht);

                Poi_name = dtPOI.Columns.Contains("name") ? dtPOI.Rows[0]["name"].ToString() : string.Empty;
                Poi_dob = dtPOI.Columns.Contains("dob") ? dtPOI.Rows[0]["dob"].ToString() : string.Empty;
                Poi_gender = dtPOI.Columns.Contains("gender") ? dtPOI.Rows[0]["gender"].ToString() : string.Empty;
                Poi_phone = dtPOI.Columns.Contains("phone") ? dtPOI.Rows[0]["phone"].ToString() : string.Empty;

                Poi_email = dtPOI.Columns.Contains("email") ? dtPOI.Rows[0]["email"].ToString() : string.Empty;


                if (string.IsNullOrEmpty(Poi_email))
                {
                    Poi_email = Email;
                }

                if (string.IsNullOrEmpty(Poi_phone))
                {
                    Poi_phone = mobileNo;
                }

                //if (!string.IsNullOrEmpty(Poi_email))
                //{
                //    Poi_email = dtPOI.Columns.Contains("email") ? dtPOI.Rows[0]["email"].ToString() : string.Empty;
                //}
                //else
                //{
                //    Poi_email = Email;
                //}

                Poa_co = dtPOA.Columns.Contains("co") ? dtPOA.Rows[0]["co"].ToString() : string.Empty;
                Poa_house = dtPOA.Columns.Contains("house") ? dtPOA.Rows[0]["house"].ToString() : string.Empty;
                Poa_street = dtPOA.Columns.Contains("street") ? dtPOA.Rows[0]["street"].ToString() : string.Empty;
                Poa_lm = dtPOA.Columns.Contains("lm") ? dtPOA.Rows[0]["lm"].ToString() : string.Empty;
                Poa_loc = dtPOA.Columns.Contains("loc") ? dtPOA.Rows[0]["loc"].ToString() : string.Empty;
                Poa_vtc = dtPOA.Columns.Contains("vtc") ? dtPOA.Rows[0]["vtc"].ToString() : string.Empty;
                Poa_subdist = dtPOA.Columns.Contains("subdist") ? dtPOA.Rows[0]["subdist"].ToString() : string.Empty;
                Poa_dist = dtPOA.Columns.Contains("dist") ? dtPOA.Rows[0]["dist"].ToString() : string.Empty;
                Poa_state = dtPOA.Columns.Contains("state") ? dtPOA.Rows[0]["state"].ToString() : string.Empty;
                Poa_pc = dtPOA.Columns.Contains("pc") ? dtPOA.Rows[0]["pc"].ToString() : string.Empty;
                Poa_po = dtPOA.Columns.Contains("po") ? dtPOA.Rows[0]["po"].ToString() : string.Empty;
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CAADARVerification), Ex.Message);
            }
        }

        public EntityDetails FillEntityMasterProperties()
        {
            CEntityMaster objEntityMaster = new CEntityMaster();
            EntityDetails details = new EntityDetails();
            Address objCorAddress = new Address();
            Address objPerAddress = new Address();
            MethodExecResult objMER = new MethodExecResult(-1);
            string FirstName = string.Empty;
            string MiddleName = string.Empty;
            string LastName = string.Empty;

            try
            {
                //--------------------For The Corresponding Address------------------------------------------------------------------------
                objCorAddress.AddressNo = string.Empty;
                objCorAddress.Address_Line1 = Poa_house + " " + Poa_lm + " " + Poa_street;
                objCorAddress.Address_Line2 = Poa_loc;
                objCorAddress.Address_Line3 = Poa_vtc;
                objCorAddress.City = Poa_dist.ToUpper();
                objCorAddress.State_Others = Poa_state.ToUpper(); ;
                objCorAddress.PIN_Code = Poa_pc;
                objCorAddress.StateCode = Poa_state.ToUpper(); ;
                objCorAddress.Mobile_No = Poi_phone;
                objCorAddress.Email_ID = Poi_email;
                //--------------------End For Corresponding Address---------------------------------------------------------------------------

                //--------------------for the Permaent Address--------------------------------------------------------------------------------
                //objPerAddress.AddressNo = string.Empty;
                //objPerAddress.Address_Line1 = Poa_co + " " + Poa_house + " " + Poa_lm + " " + Poa_street + " " + Poa_loc + " " + Poa_vtc;
                //objPerAddress.Address_Line2 = "";
                //objPerAddress.Address_Line3 = "";
                //objPerAddress.City = Poa_dist.ToUpper();
                //objPerAddress.State_Others = Poa_state.ToUpper(); ;
                //objPerAddress.PIN_Code = Poa_pc;
                //objPerAddress.StateCode = Poa_state.ToUpper(); ;
                //objPerAddress.Mobile_No = Poi_phone;
                //objPerAddress.Email_ID = Poi_email;
                //--------------------------------------------------------------------  


                details.KYCFormNo = string.Empty;
                details.ClientNo = 0;
                details.Applicant_Name = Poi_name;


                //-------Finding Middle Name-------

                string[] SplitName;

                SplitName = Poi_name.Split(' ');
                if (SplitName.Length > 1)
                {
                    if (SplitName.Length == 3)
                    {
                        FirstName = SplitName[0];
                        MiddleName = SplitName[1];
                        LastName = SplitName[2];
                    }
                    else if (SplitName.Length == 2)
                    {
                        FirstName = SplitName[0];
                        LastName = SplitName[1];
                    }
                }
                else
                {
                    FirstName = SplitName[0];
                }

                //details.Father_sHusbands_Name = MiddleName == null || MiddleName == "" ? " " : MiddleName;
                details.Father_sHusbands_Name = string.IsNullOrEmpty(Poa_co) ? " " : Poa_co;
                //--------------------------------------

                details.Short_Code = string.Empty;
                details.Gender = Poi_gender;


                //details.DOB_OR_DOI = string.IsNullOrEmpty(Poi_dob) ? details.DOB_OR_DOI : DateTime.ParseExact(Poi_dob, "dd/MM/yyyy", null);

                try
                {
                    if (!string.IsNullOrEmpty(Poi_dob))
                    {
                        //DateTime dt = DateTime.Parse(APP_DOB_INCORP, new CultureInfo("en-CA"));
                        //APP_DOB_INCORP = dt.ToString("yyyy/MM/dd").Replace('-', '/');
                        //details.DOB_OR_DOI = string.IsNullOrEmpty(APP_DOB_INCORP) ? details.DOB_OR_DOI : Convert.ToDateTime(APP_DOB_INCORP);

                        string dateTimeString = Poi_dob.Replace('-', '/');
                        dateTimeString = Regex.Replace(dateTimeString, @"[^\u0000-\u007F]", string.Empty);

                        string inputFormat = "dd/MM/yyyy";
                        details.DOB_OR_DOI = DateTime.ParseExact(dateTimeString, inputFormat, CultureInfo.InvariantCulture);
                    }
                    else
                    {
                        details.DOB_OR_DOI = null;
                    }
                }
                catch { details.DOB_OR_DOI = null; }


                details.CorrespondenceAddress = objCorAddress;
                details.PermanentAddress = objPerAddress;
                details.FristName = Poi_name;
                details.SkypeId = uid;
                details.SameCorrPermAdd = "Y";
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CTabStatus), Ex.Message, Ex);
            }

            return details;

        }
    }
}