﻿using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace FTIL.Match.CDD.BAL
{
    public class PaymentGateway
    {
        public MethodExecResult GetPaymentGatewaydata(string ColumnNames,string TableName,string ConditionColumn,string ConditionColvalue)
        {
            DataSet dsdata = new DataSet();
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_KYCGetdata");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@s_ColumnNames", SqlDbType.VarChar, ColumnNames);
                objdbwork.AddParameter("@s_TableName", SqlDbType.VarChar,TableName );
                objdbwork.AddParameter("@s_ConditionColumn", SqlDbType.VarChar, ConditionColumn);
                objdbwork.AddParameter("@s_ConditionColvalue", SqlDbType.VarChar,ConditionColvalue );

                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {

                    dsdata = objdbwork.Result as DataSet;
                    if ((dsdata == null) || (dsdata.Tables.Count == 0))
                    {
                        return new MethodExecResult(-1, null, "No recordset returned from database.", null);
                    }

                    return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, string.Empty, null);
                }
                else
                {
                    Logger.Instance.WriteLog(typeof(PaymentGateway), objdbwork.ExecutionStatus);
                    return objdbwork.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(PaymentGateway), ex.Message, ex);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }
        }

        public MethodExecResult PaymentGatewayDetails(string s_Mode, string TransactionNo, string CustomerID, string AccountNumber, 
                                string TxnAmount, string BankID, string CurrencyType, string ItemCode, string TransactionMode, string ClientCode,
                                string CustomerName, string Transaction_Status, string Original_Status, string Transaction_Remarks,string RespMsg, ref DataSet dsdata)
        { 
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_GetPaymentGateway");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@s_Mode", SqlDbType.VarChar, s_Mode);
                objdbwork.AddParameter("@TransactionNo", SqlDbType.VarChar, TransactionNo);
                objdbwork.AddParameter("@CustomerID", SqlDbType.VarChar, CustomerID);
                objdbwork.AddParameter("@AccountNumber", SqlDbType.VarChar, AccountNumber);
                objdbwork.AddParameter("@TxnAmount", SqlDbType.VarChar, TxnAmount);
                objdbwork.AddParameter("@BankID", SqlDbType.VarChar, BankID);
                objdbwork.AddParameter("@CurrencyType", SqlDbType.VarChar, CurrencyType);
                objdbwork.AddParameter("@ItemCode", SqlDbType.VarChar, ItemCode);
                objdbwork.AddParameter("@TransactionMode", SqlDbType.VarChar, TransactionMode);
                objdbwork.AddParameter("@ClientCode", SqlDbType.VarChar, ClientCode);
                objdbwork.AddParameter("@CustomerName", SqlDbType.VarChar, CustomerName);
                objdbwork.AddParameter("@Transaction_Status", SqlDbType.VarChar, Transaction_Status);
                objdbwork.AddParameter("@Original_Status", SqlDbType.VarChar, Original_Status);
                objdbwork.AddParameter("@Transaction_Remarks", SqlDbType.VarChar, Transaction_Remarks);
                objdbwork.AddParameter("@RespMsg", SqlDbType.VarChar, RespMsg); 

                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {

                    dsdata = objdbwork.Result as DataSet;
                    if ((dsdata == null) || (dsdata.Tables.Count == 0))
                    {
                        return new MethodExecResult(-1, null, "No recordset returned from database.", null);
                    }

                    return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, string.Empty, null);
                }
                else
                {
                    Logger.Instance.WriteLog(typeof(PaymentGateway), objdbwork.ExecutionStatus);
                    return objdbwork.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(PaymentGateway), ex.Message, ex);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }
        }


    }
}
