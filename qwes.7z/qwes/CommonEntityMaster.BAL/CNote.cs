﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using System.Data;
using FTIL.Match.Common.Log;

namespace FTIL.Match.CDD.BAL
{
    public class CNote
    {

        public int EntityNo { get; set; }

        public string UserName { get; set; }

        public string NoteDateTime { get; set; }

        public string NoteText { get; set; }

        public string Description { get; set; }


        #region GetNote 
        /// <summary>
        /// Get Entity Note details
        /// </summary>
        /// <param name="nEntityNo">ClientNo</param>
        /// <returns>Method Execution result</returns>
        public MethodExecResult GetNote(int nEntityNo)
        {

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_CDDMasterNote");
            l_objDbWorkItem.ResultType = QueryType.DataSet;


            l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, "S");
            l_objDbWorkItem.AddParameter("@pn_EntityNo", SqlDbType.Int, nEntityNo);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);


            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables[0].Rows.Count == 0))
                    return new MethodExecResult(1, "No data found", "stp_GetEntityProductDetails Database returned no data. UserNo. " +
                        AppEnvironment.AppUser.UserNo.ToString(), null);
                else
                {
                    EntityNo = nEntityNo;
                    UserName = l_dsReturnData.Tables[0].Rows[0]["s_UserName"].ToString();
                    NoteText = l_dsReturnData.Tables[0].Rows[0]["s_Text"].ToString();
                    NoteDateTime = l_dsReturnData.Tables[0].Rows[0]["d_LastModifiedDateTime"].ToString();

                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        }
        #endregion


        public MethodExecResult UpdateNote()
        {
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_CDDMasterNote");
                objdbwork.ResultType = QueryType.DataSet;

                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "U");

                objdbwork.AddParameter("@pn_EntityNo", SqlDbType.Int, EntityNo);
                objdbwork.AddParameter("@s_NoteDescription", SqlDbType.VarChar, Description);
                objdbwork.AddParameter("@ps_NoteText", SqlDbType.VarChar, NoteText);
                objdbwork.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

                DbManager.Instance.ExecuteDbTask(objdbwork);
                return objdbwork.ExecutionStatus;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }

        }

    }
}
