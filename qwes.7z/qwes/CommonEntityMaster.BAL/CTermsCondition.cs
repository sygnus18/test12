﻿using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
namespace FTIL.Match.CDD.BAL
{
   public class CTermsCondition
    {
       public MethodExecResult TermsConditionDetails(string s_Mode, string n_EntityNo, ref DataSet ds, string TCFileName, string UserID)
        {
            try
            {
                DataSet dsdata = new DataSet();

                DbWorkItem objdbwork = new DbWorkItem("stp_TermsCondition");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, s_Mode);
                objdbwork.AddParameter("@pn_EntityNo", SqlDbType.VarChar, n_EntityNo);
                objdbwork.AddParameter("@ps_TCFileName", SqlDbType.VarChar, TCFileName);
                objdbwork.AddParameter("@pn_LastUserNo", SqlDbType.VarChar, UserID);
                

                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {

                    ds = objdbwork.Result as DataSet;
                    if (s_Mode == "S" && ((ds == null) || (ds.Tables.Count == 0)))
                    {

                        return new MethodExecResult(-1, null, "No recordset returned from database.", null);
                    }

                    return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, string.Empty, null);
                }
                else
                {
                    Logger.Instance.WriteLog(typeof(CTabStatus), objdbwork.ExecutionStatus);
                    return objdbwork.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CTabStatus), ex.Message, ex);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }
        }

        
    }
}
