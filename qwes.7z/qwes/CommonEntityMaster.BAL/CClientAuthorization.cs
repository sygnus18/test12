﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FTIL.Match.Common.Db;
using System.Data.SqlClient;
using System.Data;
using FTIL.Match.Common.Log;
using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.CDD.BAL;
using FTIL.Match.Common;
using System.Globalization;


namespace FTIL.Match.CDD.BAL
{
    public class CClientAuthorization
    {

        static CClientAuthorization()
        {
            string sconstr = string.Empty;
        }

        public static MethodExecResult GetCompanyName(ref DataSet dsLicenseDetails)
        {
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_KYCGetLicenseDetails");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "A");

                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {

                    dsLicenseDetails = objdbwork.Result as DataSet;
                    if (dsLicenseDetails.Tables.Count > 0)
                    {
                        return new MethodExecResult(-1, null, "No recordset returned from database.", null);
                    }

                    return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, string.Empty, null);
                }
                else
                {
                    Logger.Instance.WriteLog(typeof(CClientAuthorization), objdbwork.ExecutionStatus);
                    return objdbwork.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CClientAuthorization), ex.Message, ex);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }
        }


        public MethodExecResult SetArchiveConference(string s_Mode, string s_ArchiveID, string s_ArchiveName, string s_Token, string DownloadPath, string sClientNo = "")
        {
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_GetSetArchive");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, s_Mode);
                objdbwork.AddParameter("@ps_ArchiveID", SqlDbType.VarChar, s_ArchiveID);
                objdbwork.AddParameter("@ps_ArchiveName", SqlDbType.VarChar, s_ArchiveName);
                objdbwork.AddParameter("@ps_Token", SqlDbType.VarChar, s_Token);
                objdbwork.AddParameter("@ps_DownloadPath", SqlDbType.VarChar, DownloadPath);
                objdbwork.AddParameter("@ps_ClientNo", SqlDbType.VarChar, sClientNo);

                DbManager.Instance.ExecuteDbTask(objdbwork);
                return objdbwork.ExecutionStatus;

                //if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                //{
                //    return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, string.Empty, null);
                //}
                //else
                //{
                //    Logger.Instance.WriteLog(typeof(CTabStatus), objdbwork.ExecutionStatus);
                //    return objdbwork.ExecutionStatus;
                //}
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CTabStatus), ex.Message, ex);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }

        }


        public DataSet OnlineIPVClients(char s_Mode, int LockBy, int nUserNo, string CallType)
        {
            DbWorkItem objdbwork = null;
            DataSet res = new DataSet();
            try
            {
                objdbwork = new DbWorkItem("stp_KYC_OnlineIPVClient");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@pc_Mode", SqlDbType.Char, s_Mode);
                objdbwork.AddParameter("@ps_CallType", SqlDbType.VarChar, CallType);
                objdbwork.AddParameter("@ps_IpvType", SqlDbType.VarChar, "WIZIQ");
                if (CallType == "ADMIN_LOCK" || CallType == "CHECK_LOCKBY")
                {
                    objdbwork.AddParameter("@pn_IPV_ID", SqlDbType.Int, LockBy);
                    objdbwork.AddParameter("@pn_Admin", SqlDbType.Int, nUserNo);
                }

               
                SqlParameter n_ReturnCodeO = new SqlParameter();
                n_ReturnCodeO.ParameterName = "@pn_ReturnCode";
                n_ReturnCodeO.SqlDbType = SqlDbType.Int;
                //outparam.Size = 100;
                n_ReturnCodeO.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(n_ReturnCodeO);

                SqlParameter s_ReturnMsgO = new SqlParameter();
                s_ReturnMsgO.ParameterName = "@ps_ReturnMsg";
                s_ReturnMsgO.SqlDbType = SqlDbType.VarChar;
                s_ReturnMsgO.Size = 500;
                s_ReturnMsgO.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(s_ReturnMsgO);


                DbManager.Instance.ExecuteDbTask(objdbwork);
                //res.Tables.Add(createStatusTable((string)objdbwork.parameters[objdbwork.parameters.Count - 2].Value.ToString(), (string)objdbwork.parameters[objdbwork.parameters.Count - 1].Value.ToString())); 
                res.Tables.Add(createStatusTable("0", "Success"));
                res.Tables[0].TableName = "Status";

                //int errCode = (int)objdbwork.parameters[objdbwork.parameters.Count - 2].Value;
                int errCode = 0;
                if (errCode == 0 || errCode == 1)
                {
                    //res[1] = ((DataSet)objdbwork.Result).Tables[0];

                    res.Tables.Add(((DataSet)objdbwork.Result).Tables[0].Copy());


                }
                else
                {
                    //res[1] = new DataTable();
                    res.Tables.Add(new DataTable());
                }
                res.Tables[1].TableName = "D1";

                return res;
                //return outparam.Value.ToString();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return res;
            }
        }
        /// <summary>
        /// TO Update Status When IPV Get Completed.
        /// </summary>
        /// <param name="s_Mode">M</param>
        /// <param name="nIPVid">ClientIPVID</param>
        /// <param name="nUserNo"></param>
        /// <param name="CallType">IPV_DONE</param>
        /// <param name="nClientNo">Client No</param>
        /// <returns></returns>
        public string IPVCompleted(char s_Mode, string nIPVid, string nUserNo, string CallType, string nClientNo)
        {
            DbWorkItem objdbwork = null;
            DataSet res = new DataSet();
            try
            {
                objdbwork = new DbWorkItem("stp_KYC_OnlineIPVClient");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@pc_Mode", SqlDbType.Char, s_Mode);
                objdbwork.AddParameter("@ps_CallType", SqlDbType.VarChar, CallType);
                objdbwork.AddParameter("@ps_IpvType", SqlDbType.VarChar, "WIZIQ");
                objdbwork.AddParameter("@pn_IPV_ID", SqlDbType.Int, Convert.ToInt32(nIPVid));
                objdbwork.AddParameter("@pn_Admin", SqlDbType.Int, Convert.ToInt32(nUserNo));
                objdbwork.AddParameter("@ps_ClientNo", SqlDbType.Int, nClientNo);               

                SqlParameter n_ReturnCodeO = new SqlParameter();
                n_ReturnCodeO.ParameterName = "@pn_ReturnCode";
                n_ReturnCodeO.SqlDbType = SqlDbType.Int;                
                n_ReturnCodeO.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(n_ReturnCodeO);
                SqlParameter s_ReturnMsgO = new SqlParameter();
                s_ReturnMsgO.ParameterName = "@ps_ReturnMsg";
                s_ReturnMsgO.SqlDbType = SqlDbType.VarChar;
                s_ReturnMsgO.Size = 500;
                s_ReturnMsgO.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(s_ReturnMsgO);
                DbManager.Instance.ExecuteDbTask(objdbwork);                
                res.Tables.Add(createStatusTable("0", "Success"));
                res.Tables[0].TableName = "Status";                                                                
                return "";               
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return "Error IN IPV Completed";
            }
        }

        public DataSet GetArchiveList(int nClientId)
        {
            DbWorkItem objdbwork = null;
            DataSet res = new DataSet();
            try
            {
                objdbwork = new DbWorkItem("stp_GetSetArchive");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "R");
                objdbwork.AddParameter("@ps_ClientNo", SqlDbType.Int, nClientId);



                DbManager.Instance.ExecuteDbTask(objdbwork);
                //res.Tables.Add(createStatusTable((string)objdbwork.parameters[objdbwork.parameters.Count - 2].Value.ToString(), (string)objdbwork.parameters[objdbwork.parameters.Count - 1].Value.ToString())); 
                res.Tables.Add(createStatusTable("0", "Success"));
                res.Tables[0].TableName = "Status";

                //int errCode = (int)objdbwork.parameters[objdbwork.parameters.Count - 2].Value;
                int errCode = 0;
                if (errCode == 0 || errCode == 1)
                {
                    //res[1] = ((DataSet)objdbwork.Result).Tables[0];

                    res.Tables.Add(((DataSet)objdbwork.Result).Tables[0].Copy());


                }
                else
                {
                    //res[1] = new DataTable();
                    res.Tables.Add(new DataTable());
                }
                res.Tables[1].TableName = "D1";

                return res;
                //return outparam.Value.ToString();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return res;
            }
        }



        public DataSet GetPendingApplication(string nUserNo, string sAuthStatus, string sCode, string sFromDate, string sToDate,string GroupType)
        {
            DbWorkItem objdbwork = null;
            DataSet res = new DataSet();
            try
            {
                objdbwork = new DbWorkItem("stp_KYC_GetPendingApplication");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@Pn_UserNo", SqlDbType.Int, nUserNo);
                objdbwork.AddParameter("@Pn_AuthStatus", SqlDbType.VarChar, sAuthStatus);
                objdbwork.AddParameter("@ps_Code", SqlDbType.VarChar, sCode = sCode == "" || sCode == null ? null : sCode);
                objdbwork.AddParameter("@pd_FromDate", SqlDbType.VarChar, sFromDate = sFromDate == null || sFromDate == "" ? null : sFromDate);
                objdbwork.AddParameter("@pd_ToDate", SqlDbType.VarChar, sToDate = sToDate == "" || sToDate == null ? null : sToDate);

                objdbwork.AddParameter("@pc_GroupType", SqlDbType.VarChar, GroupType = GroupType == "" || GroupType == null ? null : GroupType);

                SqlParameter outParamErrNo = new SqlParameter();
                outParamErrNo.ParameterName = "@Ps_ErrorCode";
                outParamErrNo.SqlDbType = SqlDbType.Int;
                outParamErrNo.Size = 8;
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outparam = new SqlParameter();
                outparam.ParameterName = "@Ps_ErrorMessage";
                outparam.SqlDbType = SqlDbType.VarChar;
                outparam.Size = 100;
                outparam.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outparam);


                DbManager.Instance.ExecuteDbTask(objdbwork);
                //res.Tables.Add(createStatusTable((string)objdbwork.parameters[objdbwork.parameters.Count - 2].Value.ToString(), (string)objdbwork.parameters[objdbwork.parameters.Count - 1].Value.ToString())); 
                res.Tables.Add(createStatusTable("0", "Success"));
                res.Tables[0].TableName = "Status";

                //int errCode = (int)objdbwork.parameters[objdbwork.parameters.Count - 2].Value;
                int errCode = 0;
                if (errCode == 0 || errCode == 1)
                {
                    //res[1] = ((DataSet)objdbwork.Result).Tables[0];

                    res.Tables.Add(((DataSet)objdbwork.Result).Tables[0].Copy());


                }
                else
                {
                    //res[1] = new DataTable();
                    res.Tables.Add(new DataTable());
                }
                res.Tables[1].TableName = "D1";

                return res;
                //return outparam.Value.ToString();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return res;
            }
        }

        public DataSet GetAuthStatusCount(string nUserNo, string sAuthStatus, string sCode, string sFromDate, string sToDate, string s_GroupType)
        {
            DbWorkItem objdbwork = null;
            DataSet res = new DataSet();
            try
            {
                objdbwork = new DbWorkItem("sp_KYC_GetAuthStatus");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@Pn_UserNo", SqlDbType.Int, nUserNo);
                objdbwork.AddParameter("@Pn_AuthStatus", SqlDbType.VarChar, sAuthStatus);
                objdbwork.AddParameter("@ps_Code", SqlDbType.VarChar, sCode = sCode == "" || sCode == null ? null : sCode);
                objdbwork.AddParameter("@pd_FromDate", SqlDbType.VarChar, sFromDate = sFromDate == null || sFromDate == "" ? null : sFromDate);
                objdbwork.AddParameter("@pd_ToDate", SqlDbType.VarChar, sToDate = sToDate == "" || sToDate == null ? null : sToDate);
                objdbwork.AddParameter("@pc_GroupType", SqlDbType.VarChar, s_GroupType = s_GroupType == "" || s_GroupType == null ? null : s_GroupType);

                SqlParameter outParamErrNo = new SqlParameter();
                outParamErrNo.ParameterName = "@Ps_ErrorCode";
                outParamErrNo.SqlDbType = SqlDbType.Int;
                outParamErrNo.Size = 8;
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outparam = new SqlParameter();
                outparam.ParameterName = "@Ps_ErrorMessage";
                outparam.SqlDbType = SqlDbType.VarChar;
                outparam.Size = 100;
                outparam.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outparam);


                DbManager.Instance.ExecuteDbTask(objdbwork);
                //res.Tables.Add(createStatusTable((string)objdbwork.parameters[objdbwork.parameters.Count - 2].Value.ToString(), (string)objdbwork.parameters[objdbwork.parameters.Count - 1].Value.ToString())); 
                res.Tables.Add(createStatusTable("0", "Success"));
                res.Tables[0].TableName = "Status";

                //int errCode = (int)objdbwork.parameters[objdbwork.parameters.Count - 2].Value;
                int errCode = 0;
                if (errCode == 0 || errCode == 1)
                {
                    //res[1] = ((DataSet)objdbwork.Result).Tables[0];

                    res.Tables.Add(((DataSet)objdbwork.Result).Tables[0].Copy());


                }
                else
                {
                    //res[1] = new DataTable();
                    res.Tables.Add(new DataTable());
                }
                res.Tables[1].TableName = "D1";

                return res;
                //return outparam.Value.ToString();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return res;
            }
        }


        public DataTable createStatusTable(string errCode, string errMsg)
        {
            DataTable dt = new DataTable();
            dt.TableName = "Status";
            dt.Columns.Add("ErrorCode");
            dt.Columns.Add("Message");
            dt.Rows.Add(errCode, errMsg);

            return dt;

        }

        public string SetApplicationInProcess(string sToken, string sSessionID, string nUserNo, string nClientNo, string nEntityNo)
        {
            DbWorkItem objdbwork = null;
            DataSet res = new DataSet();
            try
            {
                objdbwork = new DbWorkItem("stp_KYC_SetApplicationInProcess");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@Pn_UserNo", SqlDbType.Int, 1);
                objdbwork.AddParameter("@Pn_EntityNo", SqlDbType.Int, 1);

                SqlParameter outParamErrNo = new SqlParameter();
                outParamErrNo.ParameterName = "@Ps_ErrorCode";
                outParamErrNo.SqlDbType = SqlDbType.Int;
                outParamErrNo.Size = 8;
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outparam = new SqlParameter();
                outparam.ParameterName = "@Ps_ErrorMessage";
                outparam.SqlDbType = SqlDbType.VarChar;
                outparam.Size = 100;
                outparam.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outparam);


                DbManager.Instance.ExecuteDbTask(objdbwork);
                res.Tables.Add(createStatusTable((string)objdbwork.parameters[objdbwork.parameters.Count - 2].Value.ToString(), (string)objdbwork.parameters[objdbwork.parameters.Count - 1].Value.ToString()));
                res.Tables[0].TableName = "Status";

                int errCode = (int)objdbwork.parameters[objdbwork.parameters.Count - 2].Value;
                if (errCode == 0 || errCode == 1)
                {
                    //res[1] = ((DataSet)objdbwork.Result).Tables[0];

                    res.Tables.Add(((DataSet)objdbwork.Result).Tables[0].Copy());


                }
                else
                {
                    //res[1] = new DataTable();
                    res.Tables.Add(new DataTable());
                }
                res.Tables[1].TableName = "D1";

                return "";
                //return outparam.Value.ToString();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return "";
            }

        }
       
        public DataSet ForgotPassword(string ApplicationKey, string Name, string Mobile, string Email, string Panno, string Capcha, string dob)
        {
            DbWorkItem objdbwork = null;
            DataSet res = new DataSet();
            try
            {
                objdbwork = new DbWorkItem("stp_KYC_ChangePassword");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@Ps_Name", SqlDbType.VarChar, Name);
                objdbwork.AddParameter("@Ps_Email", SqlDbType.VarChar, Email);
                objdbwork.AddParameter("@Ps_MobileNo", SqlDbType.VarChar, Mobile);
                objdbwork.AddParameter("@Ps_PANNo", SqlDbType.VarChar, Panno);
                objdbwork.AddParameter("@Ps_DOB", SqlDbType.VarChar, dob);
                //objdbwork.AddParameter("@Ps_Password", SqlDbType.VarChar, s_Pass);
                objdbwork.AddParameter("@Ps_NewPassword", SqlDbType.VarChar, DateTime.Now.ToString("HHmmss"));
                objdbwork.AddParameter("@Ps_CallingType", SqlDbType.VarChar, "F");

                SqlParameter outParamErrNo = new SqlParameter();
                outParamErrNo.ParameterName = "@Pn_ErrorCode";
                outParamErrNo.SqlDbType = SqlDbType.Int;
                outParamErrNo.Size = 8;
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outparam = new SqlParameter();
                outparam.ParameterName = "@Ps_ErrorMessage";
                outparam.SqlDbType = SqlDbType.VarChar;
                outparam.Size = 100;
                outparam.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outparam);


                DbManager.Instance.ExecuteDbTask(objdbwork);
                res.Tables.Add(createStatusTable((string)objdbwork.parameters[objdbwork.parameters.Count - 2].Value.ToString(), (string)objdbwork.parameters[objdbwork.parameters.Count - 1].Value.ToString()));
                res.Tables[0].TableName = "Status";

                int errCode = (int)objdbwork.parameters[objdbwork.parameters.Count - 2].Value;
                if (errCode == 0)
                {
                    res.Tables.Add(((DataSet)objdbwork.Result).Tables[0].Copy());
                }
                else
                {
                    //res[1] = new DataTable();
                    res.Tables.Add(new DataTable());
                }
                res.Tables[1].TableName = "D1";

                return res;
                //return outparam.Value.ToString();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return res;
            }
        }

        public DataSet ChangePassword(string s_ApplicationKey, string s_Name, string s_Mobile, string s_Email, string s_Pass, string s_NewPass, string s_Panno, string s_Capcha, string s_dob)
        {
            DbWorkItem objdbwork = null;
            DataSet res = new DataSet();
            try
            {
                objdbwork = new DbWorkItem("stp_KYC_ChangePassword");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@Ps_Name", SqlDbType.VarChar, s_Name);
                objdbwork.AddParameter("@Ps_Email", SqlDbType.VarChar, s_Email);
                objdbwork.AddParameter("@Ps_MobileNo", SqlDbType.VarChar, s_Mobile);
                objdbwork.AddParameter("@Ps_PANNo", SqlDbType.VarChar, s_Panno);
                objdbwork.AddParameter("@Ps_DOB", SqlDbType.VarChar, s_dob);
                objdbwork.AddParameter("@Ps_Password", SqlDbType.VarChar, s_Pass);
                objdbwork.AddParameter("@Ps_NewPassword", SqlDbType.VarChar, s_NewPass);
                objdbwork.AddParameter("@Ps_CallingType", SqlDbType.VarChar, "C");

                SqlParameter outParamErrNo = new SqlParameter();
                outParamErrNo.ParameterName = "@Pn_ErrorCode";
                outParamErrNo.SqlDbType = SqlDbType.Int;
                outParamErrNo.Size = 8;
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outparam = new SqlParameter();
                outparam.ParameterName = "@Ps_ErrorMessage";
                outparam.SqlDbType = SqlDbType.VarChar;
                outparam.Size = 100;
                outparam.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outparam);


                DbManager.Instance.ExecuteDbTask(objdbwork);
                res.Tables.Add(createStatusTable((string)objdbwork.parameters[objdbwork.parameters.Count - 2].Value.ToString(), (string)objdbwork.parameters[objdbwork.parameters.Count - 1].Value.ToString()));
                res.Tables[0].TableName = "Status";

                int errCode = (int)objdbwork.parameters[objdbwork.parameters.Count - 2].Value;
                if (errCode == 0)
                {
                    res.Tables.Add(((DataSet)objdbwork.Result).Tables[0].Copy());
                }
                else
                {
                    //res[1] = new DataTable();
                    res.Tables.Add(new DataTable());
                }
                res.Tables[1].TableName = "D1";

                return res;
                //return outparam.Value.ToString();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return res;
            }
        }

        public MethodExecResult EntityRevok(string s_Mode, string n_EntityNo, string s_Status, string s_Remarks, ref DataSet dsdata, string n_UserNo, string KYCEntityId)
        {
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_RevokEntityAuthorization");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, s_Mode);
                objdbwork.AddParameter("@pn_EntityNo", SqlDbType.VarChar, n_EntityNo);
                objdbwork.AddParameter("@ps_Status", SqlDbType.VarChar, s_Status);
                objdbwork.AddParameter("@ps_Remarks", SqlDbType.VarChar, s_Remarks);
                objdbwork.AddParameter("@pn_UserNo", SqlDbType.VarChar, n_UserNo);


                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    dsdata = objdbwork.Result as DataSet;
                    if (s_Mode == "S" && ((dsdata == null) || (dsdata.Tables.Count == 0)))
                    {
                        return new MethodExecResult(-1, null, "No recordset returned from database.", null);
                    }

                    return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, string.Empty, null);
                }
                else
                {
                    Logger.Instance.WriteLog(typeof(CTabStatus), objdbwork.ExecutionStatus);
                    return objdbwork.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CTabStatus), ex.Message, ex);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }
        }


        public MethodExecResult EntityAuthorization(string s_Mode, string n_EntityNo, string s_Status, string s_Remarks, ref DataSet dsdata, string n_UserNo)
        {
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_EntityAuthorization");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, s_Mode);
                objdbwork.AddParameter("@pn_EntityNo", SqlDbType.VarChar, n_EntityNo);
                objdbwork.AddParameter("@ps_Status", SqlDbType.VarChar, s_Status);
                objdbwork.AddParameter("@ps_Remarks", SqlDbType.VarChar, s_Remarks);
                objdbwork.AddParameter("@pn_UserNo", SqlDbType.VarChar, n_UserNo);


                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {

                    dsdata = objdbwork.Result as DataSet;
                    if (s_Mode == "S" && ((dsdata == null) || (dsdata.Tables.Count == 0)))
                    {
                        return new MethodExecResult(-1, null, "No recordset returned from database.", null);
                    }

                    return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, string.Empty, null);
                }
                else
                {
                    Logger.Instance.WriteLog(typeof(CTabStatus), objdbwork.ExecutionStatus);
                    return objdbwork.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CTabStatus), ex.Message, ex);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }
        }


        public DataSet GetExportData(string sFromDate, string sToDate)
        {
            DateTime? dtFromDate = null;
            DateTime? dtToDate = null;

            if (sFromDate != null && sFromDate != "")
               // dtFromDate = DateTime.ParseExact(sFromDate, "dd/MM/yyyy", null);

                dtFromDate = DateTime.ParseExact(sFromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);

            if (sToDate != null && sToDate != "")
                //dtToDate = DateTime.ParseExact(sToDate, "dd/MM/yyyy", null);

                dtToDate = DateTime.ParseExact(sToDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);

            DbWorkItem objdbwork = null;
            DataSet res = new DataSet();
            try
            {
                objdbwork = new DbWorkItem("stp_KYCGetEntityDetails");
                objdbwork.ResultType = QueryType.DataSet;
                //objdbwork.AddParameter("@Pd_FromDate", SqlDbType.DateTime, sFromDate = sFromDate == null || sFromDate == "" ? null : sFromDate);
                //objdbwork.AddParameter("@Pd_TODate", SqlDbType.DateTime, sToDate = sToDate == "" || sToDate == null ? null : sToDate);
                objdbwork.AddParameter("@Pd_FromDate", SqlDbType.DateTime, dtFromDate);
                objdbwork.AddParameter("@Pd_TODate", SqlDbType.DateTime, dtToDate);

                DbManager.Instance.ExecuteDbTask(objdbwork);
                res = objdbwork.Result as DataSet;
                //res.Tables.Add(((DataSet)objdbwork.Result).Tables[0].Copy());
                return res;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return res;
            }
        }


        public DataSet LDGetExportData(string sFromDate, string sToDate)
        {
            DateTime? dtFromDate = null;
            DateTime? dtToDate = null;

            if (sFromDate != null && sFromDate != "")
                // dtFromDate = DateTime.ParseExact(sFromDate, "dd/MM/yyyy", null);

                dtFromDate = DateTime.ParseExact(sFromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);

            if (sToDate != null && sToDate != "")
                //dtToDate = DateTime.ParseExact(sToDate, "dd/MM/yyyy", null);

                dtToDate = DateTime.ParseExact(sToDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);

            DbWorkItem objdbwork = null;
            DataSet res = new DataSet();
            try
            {
                objdbwork = new DbWorkItem("stp_KYCGetEntityDetailsLD");
                objdbwork.ResultType = QueryType.DataSet;
                //objdbwork.AddParameter("@Pd_FromDate", SqlDbType.DateTime, sFromDate = sFromDate == null || sFromDate == "" ? null : sFromDate);
                //objdbwork.AddParameter("@Pd_TODate", SqlDbType.DateTime, sToDate = sToDate == "" || sToDate == null ? null : sToDate);
                objdbwork.AddParameter("@Pd_FromDate", SqlDbType.DateTime, dtFromDate);
                objdbwork.AddParameter("@Pd_TODate", SqlDbType.DateTime, dtToDate);

                DbManager.Instance.ExecuteDbTask(objdbwork);
                res = objdbwork.Result as DataSet;
                //res.Tables.Add(((DataSet)objdbwork.Result).Tables[0].Copy());
                return res;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return res;
            }
        }

        public DataSet GetExportedDataSummary(string sFromDate, string sToDate)
        {
            DateTime? dtFromDate = null;
            DateTime? dtToDate = null;

            if (sFromDate != null && sFromDate != "")
                // dtFromDate = DateTime.ParseExact(sFromDate, "dd/MM/yyyy", null);

                dtFromDate = DateTime.ParseExact(sFromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);

            if (sToDate != null && sToDate != "")
                //dtToDate = DateTime.ParseExact(sToDate, "dd/MM/yyyy", null);

                dtToDate = DateTime.ParseExact(sToDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);

            DbWorkItem objdbwork = null;
            DataSet res = new DataSet();
            try
            {
                objdbwork = new DbWorkItem("stp_ClientExportStatus");
                objdbwork.ResultType = QueryType.DataSet;
                //objdbwork.AddParameter("@Pd_FromDate", SqlDbType.DateTime, sFromDate = sFromDate == null || sFromDate == "" ? null : sFromDate);
                //objdbwork.AddParameter("@Pd_TODate", SqlDbType.DateTime, sToDate = sToDate == "" || sToDate == null ? null : sToDate);
                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "S");
                objdbwork.AddParameter("@Pd_FromDate", SqlDbType.DateTime, dtFromDate);
                objdbwork.AddParameter("@Pd_TODate", SqlDbType.DateTime, dtToDate);

                //DbManager.Instance.ExecuteDbTask(objdbwork);
                //res = objdbwork.Result as DataSet;                
                //return res;

                DbManager.Instance.ExecuteDbTask(objdbwork);                
                res.Tables.Add(createStatusTable("0", "Success"));
                res.Tables[0].TableName = "Status";

                //int errCode = (int)objdbwork.parameters[objdbwork.parameters.Count - 2].Value;
                int errCode = 0;
                if (errCode == 0 || errCode == 1)
                {
                    res.Tables.Add(((DataSet)objdbwork.Result).Tables[0].Copy());
                }
                else
                {
                    //res[1] = new DataTable();
                    res.Tables.Add(new DataTable());
                }
                res.Tables[1].TableName = "D1";

                return res;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return res;
            }
        }

        public DataSet GetExportPaymentData(string sFromDate, string sToDate)
        {
            DateTime? dtFromDate = null;
            DateTime? dtToDate = null;

            if (sFromDate != null && sFromDate != "")
                // dtFromDate = DateTime.ParseExact(sFromDate, "dd/MM/yyyy", null);

                dtFromDate = DateTime.ParseExact(sFromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);

            if (sToDate != null && sToDate != "")
                //dtToDate = DateTime.ParseExact(sToDate, "dd/MM/yyyy", null);

                dtToDate = DateTime.ParseExact(sToDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);

            DbWorkItem objdbwork = null;
            DataSet res = new DataSet();
            try
            {
                objdbwork = new DbWorkItem("stp_ExportPaymentGatewayDetails");
                objdbwork.ResultType = QueryType.DataSet;
                //objdbwork.AddParameter("@Pd_FromDate", SqlDbType.DateTime, sFromDate = sFromDate == null || sFromDate == "" ? null : sFromDate);
                //objdbwork.AddParameter("@Pd_TODate", SqlDbType.DateTime, sToDate = sToDate == "" || sToDate == null ? null : sToDate);
                objdbwork.AddParameter("@Pd_FromDate", SqlDbType.DateTime, dtFromDate);
                objdbwork.AddParameter("@Pd_TODate", SqlDbType.DateTime, dtToDate);

                DbManager.Instance.ExecuteDbTask(objdbwork);
                res = objdbwork.Result as DataSet;
                //res.Tables.Add(((DataSet)objdbwork.Result).Tables[0].Copy());
                return res;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return res;
            }
        }

        public string GeneratIPVLink(string s_Mode, string n_ClientNo, string s_Token, ref DataSet dsdata, string n_UserNo, string s_ConfURL, string s_TokSessionId, string s_TokToken)
        {
            try
            {
                string Message;

                DbWorkItem objdbwork = new DbWorkItem("stp_ClientDetailsOfIPV");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, s_Mode);
                objdbwork.AddParameter("@pn_ClientNo", SqlDbType.VarChar, n_ClientNo);
                objdbwork.AddParameter("@ps_Token", SqlDbType.VarChar, s_Token);
                objdbwork.AddParameter("@pn_UserNo", SqlDbType.VarChar, n_UserNo);
                objdbwork.AddParameter("@ps_ConfURL", SqlDbType.VarChar, s_ConfURL);
                objdbwork.AddParameter("@ps_TbToken", SqlDbType.VarChar, s_TokToken);
                objdbwork.AddParameter("@ps_TbSessionId", SqlDbType.VarChar, s_TokSessionId);

                SqlParameter outparam = new SqlParameter();
                outparam.ParameterName = "Ps_ErrorMessage";
                outparam.SqlDbType = SqlDbType.VarChar;
                outparam.Size = 100;
                outparam.Direction = ParameterDirection.Output;

                objdbwork.AddParameter(outparam);

                DbManager.Instance.ExecuteDbTask(objdbwork);

                Message = outparam.Value.ToString();

                return Message;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CTabStatus), ex.Message, ex);
                return "2";

            }
        }


        public MethodExecResult Validate(string s_ClientNo, string s_Token, ref DataSet dsdata)
        {
            string res = string.Empty;
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_ClientDetailsOfIPV");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@pn_ClientNo", SqlDbType.VarChar, s_ClientNo);
                objdbwork.AddParameter("@ps_Token", SqlDbType.VarChar, s_Token);

                SqlParameter outparam = new SqlParameter();
                outparam.ParameterName = "Ps_ErrorMessage";
                outparam.SqlDbType = SqlDbType.VarChar;
                outparam.Size = 100;
                outparam.Direction = ParameterDirection.Output;

                objdbwork.AddParameter(outparam);
                DbManager.Instance.ExecuteDbTask(objdbwork);
                dsdata = objdbwork.Result as DataSet;
                return objdbwork.ExecutionStatus;
                // res = objdbwork.Result as DataSet;
                //Result = outparam.Value.ToString();

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(COTPAuth), ex.Message);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);
            }
        }

        public DataSet GetClientNotification(string LastDatetime)
        {
            DbWorkItem objdbwork = null;
            DataSet res = new DataSet();
            try
            {
                objdbwork = new DbWorkItem("stp_GetClientNotification");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@d_LastDatetime", SqlDbType.VarChar, LastDatetime);

                DbManager.Instance.ExecuteDbTask(objdbwork);
                res.Tables.Add(createStatusTable("0", "Success"));
                res.Tables[0].TableName = "Status";                
                int errCode = 0;
                if (errCode == 0 || errCode == 1)
                {
                    res.Tables.Add(((DataSet)objdbwork.Result).Tables[0].Copy());
                }
                else
                {   
                    res.Tables.Add(new DataTable());
                }
                res.Tables[1].TableName = "D1";

                return res;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return res;
            }
        }

        #region IPV_WizIQ
        public MethodExecResult createSession(string s_ClientNo, string s_Mode, string s_CallType, string s_IpvType, string s_ForceSession, string s_SessId, string s_recordingUrl, string s_AdminUrl, string s_CoAdminURL, string s_attendeeUrl, string s_Admin, string s_IPV_ID, ref int n_ReturnCode, ref string s_ReturnMsg, ref DataSet dsResp, string d_SessionExpiry )
        {
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_KYC_OnlineIPVClient");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@ps_ClientNo",      SqlDbType.Int, s_ClientNo);
                objdbwork.AddParameter("@pc_Mode",          SqlDbType.VarChar, s_Mode);
                objdbwork.AddParameter("@ps_CallType",      SqlDbType.VarChar, s_CallType);
                objdbwork.AddParameter("@ps_IpvType",       SqlDbType.VarChar, s_IpvType);
                objdbwork.AddParameter("@pc_ForceSession",  SqlDbType.VarChar, s_ForceSession);
                objdbwork.AddParameter("@ps_SessId",        SqlDbType.VarChar, s_SessId);
                objdbwork.AddParameter("@ps_recordingUrl",  SqlDbType.VarChar, s_recordingUrl);
                objdbwork.AddParameter("@ps_AdminUrl",      SqlDbType.VarChar, s_AdminUrl);
                objdbwork.AddParameter("@ps_CoAdminURL",    SqlDbType.VarChar, s_CoAdminURL);
                objdbwork.AddParameter("@ps_ClientURL",     SqlDbType.VarChar, s_attendeeUrl);
                //objdbwork.AddParameter("@pn_Admin",         SqlDbType.VarChar, s_Admin);
                objdbwork.AddParameter("@pn_IPV_ID",        SqlDbType.VarChar, s_IPV_ID);
                
                if (d_SessionExpiry !=null)
                    objdbwork.AddParameter("@pd_SessionExpiry", SqlDbType.VarChar, d_SessionExpiry);
                //objdbwork.AddParameter("@ps_ReturnMsg",     SqlDbType.VarChar, s_ReturnMsg);

                SqlParameter n_ReturnCodeO = new SqlParameter();
                n_ReturnCodeO.ParameterName = "@pn_ReturnCode";
                n_ReturnCodeO.SqlDbType = SqlDbType.Int;
                //outparam.Size = 100;
                n_ReturnCodeO.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(n_ReturnCodeO);

                SqlParameter s_ReturnMsgO = new SqlParameter();
                s_ReturnMsgO.ParameterName = "@ps_ReturnMsg";
                s_ReturnMsgO.SqlDbType = SqlDbType.VarChar;
                s_ReturnMsgO.Size = 500;
                s_ReturnMsgO.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(s_ReturnMsgO);

                                           
                DbManager.Instance.ExecuteDbTask(objdbwork);
                n_ReturnCode = (int)n_ReturnCodeO.Value;
                s_ReturnMsg = s_ReturnMsgO.Value.ToString();
                dsResp = (DataSet)objdbwork.Result;

                return objdbwork.ExecutionStatus;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CTabStatus), ex.Message, ex);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }

        }

        public MethodExecResult createSession(string s_ClientNo, string s_Mode, string s_CallType, string s_IpvType, string s_ForceSession, string s_SessId, string s_recordingUrl, string s_AdminUrl, string s_CoAdminURL, string s_attendeeUrl, string s_Admin, string s_IPV_ID, ref int n_ReturnCode, ref string s_ReturnMsg, ref DataSet dsResp, string d_SessionExpiry,int n_SlotNo)
        {
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_KYC_OnlineIPVClient");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@ps_ClientNo", SqlDbType.Int, s_ClientNo);
                objdbwork.AddParameter("@pc_Mode", SqlDbType.VarChar, s_Mode);
                objdbwork.AddParameter("@ps_CallType", SqlDbType.VarChar, s_CallType);
                objdbwork.AddParameter("@ps_IpvType", SqlDbType.VarChar, s_IpvType);
                objdbwork.AddParameter("@pc_ForceSession", SqlDbType.VarChar, s_ForceSession);
                objdbwork.AddParameter("@ps_SessId", SqlDbType.VarChar, s_SessId);
                objdbwork.AddParameter("@ps_recordingUrl", SqlDbType.VarChar, s_recordingUrl);
                objdbwork.AddParameter("@ps_AdminUrl", SqlDbType.VarChar, s_AdminUrl);
                objdbwork.AddParameter("@ps_CoAdminURL", SqlDbType.VarChar, s_CoAdminURL);
                objdbwork.AddParameter("@ps_ClientURL", SqlDbType.VarChar, s_attendeeUrl);
                //objdbwork.AddParameter("@pn_Admin",         SqlDbType.VarChar, s_Admin);
                objdbwork.AddParameter("@pn_IPV_ID", SqlDbType.VarChar, s_IPV_ID);
                objdbwork.AddParameter("@pn_IPVSlotNo", SqlDbType.Int, n_SlotNo);

                if (d_SessionExpiry != null)
                    objdbwork.AddParameter("@pd_SessionExpiry", SqlDbType.VarChar, d_SessionExpiry);
                //objdbwork.AddParameter("@ps_ReturnMsg",     SqlDbType.VarChar, s_ReturnMsg);

                SqlParameter n_ReturnCodeO = new SqlParameter();
                n_ReturnCodeO.ParameterName = "@pn_ReturnCode";
                n_ReturnCodeO.SqlDbType = SqlDbType.Int;
                //outparam.Size = 100;
                n_ReturnCodeO.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(n_ReturnCodeO);

                SqlParameter s_ReturnMsgO = new SqlParameter();
                s_ReturnMsgO.ParameterName = "@ps_ReturnMsg";
                s_ReturnMsgO.SqlDbType = SqlDbType.VarChar;
                s_ReturnMsgO.Size = 500;
                s_ReturnMsgO.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(s_ReturnMsgO);


                DbManager.Instance.ExecuteDbTask(objdbwork);
                n_ReturnCode = (int)n_ReturnCodeO.Value;
                s_ReturnMsg = s_ReturnMsgO.Value.ToString();
                dsResp = (DataSet)objdbwork.Result;

                return objdbwork.ExecutionStatus;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CTabStatus), ex.Message, ex);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }

        }

        public MethodExecResult addClientToSession(string s_SessId, string s_attendeeId, string s_attendeeName, string s_ClientNo = "")
        {
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_addClientToSessionWizIq");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@ps_SessId", SqlDbType.VarChar, s_SessId);
                objdbwork.AddParameter("@ps_attendeeId", SqlDbType.VarChar, s_attendeeId);
                objdbwork.AddParameter("@ps_attendeeName", SqlDbType.VarChar, s_attendeeName);
                objdbwork.AddParameter("@ps_ClientNo", SqlDbType.VarChar, s_ClientNo);

                DbManager.Instance.ExecuteDbTask(objdbwork);
                return objdbwork.ExecutionStatus;

                //if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                //{
                //    return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, string.Empty, null);
                //}
                //else
                //{
                //    Logger.Instance.WriteLog(typeof(CTabStatus), objdbwork.ExecutionStatus);
                //    return objdbwork.ExecutionStatus;
                //}
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CTabStatus), ex.Message, ex);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }

        }

        public MethodExecResult getSessionDetails(string s_ClientNo)
        {
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_GetSetSessionWizIq");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "R");
                objdbwork.AddParameter("@ps_ClientNo", SqlDbType.VarChar, s_ClientNo);

                DbManager.Instance.ExecuteDbTask(objdbwork);
                return objdbwork.ExecutionStatus;

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CTabStatus), ex.Message, ex);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }

        }

        public MethodExecResult SetDownloadFlag(string sClientNo, string SessionID, string DownloadPath)
        {
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_GetdownloadVideoDetails");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "U");
                objdbwork.AddParameter("@ps_TokSessionID", SqlDbType.VarChar, SessionID);
                objdbwork.AddParameter("@ps_DownloadPath", SqlDbType.VarChar, DownloadPath);
                objdbwork.AddParameter("@ps_ClientNo", SqlDbType.VarChar, sClientNo);

                DbManager.Instance.ExecuteDbTask(objdbwork);
                return objdbwork.ExecutionStatus;

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CTabStatus), ex.Message, ex);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }
        }

        public MethodExecResult GetIPVSlots(string s_Mode, ref DataSet dsResp, string d_SlotDate, string GetallSlot)
        {
            try
            {
                DateTime? dtFromDate = null;
                DateTime? dtDateTime = null;

                if (d_SlotDate != null && d_SlotDate != "")
                {                   
                      dtFromDate = DateTime.ParseExact(d_SlotDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);                                    
                }
                if (dtFromDate == DateTime.Now.Date)
                {
                    if (GetallSlot == "Y")
                    {
                        dtDateTime = null;
                    }
                    else
                    {
                        dtDateTime = DateTime.Now;
                    }
                }
                else
                {
                    dtDateTime = null;
                }                
                

                DbWorkItem objdbwork = new DbWorkItem("stp_KYC_OnlineIPVClient");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@pc_Mode", SqlDbType.Char, s_Mode);
                objdbwork.AddParameter("@pd_IPVSlotdate", SqlDbType.DateTime, dtFromDate);
                objdbwork.AddParameter("@pd_SlotTimings", SqlDbType.DateTime, dtDateTime);
        
                SqlParameter n_ReturnCodeO = new SqlParameter();
                n_ReturnCodeO.ParameterName = "@pn_ReturnCode";
                n_ReturnCodeO.SqlDbType = SqlDbType.Int;
                //outparam.Size = 100;
                n_ReturnCodeO.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(n_ReturnCodeO);

                SqlParameter s_ReturnMsgO = new SqlParameter();
                s_ReturnMsgO.ParameterName = "@ps_ReturnMsg";
                s_ReturnMsgO.SqlDbType = SqlDbType.VarChar;
                s_ReturnMsgO.Size = 500;
                s_ReturnMsgO.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(s_ReturnMsgO);

                DbManager.Instance.ExecuteDbTask(objdbwork);                
                dsResp = (DataSet)objdbwork.Result;
                if (dsResp != null && dsResp.Tables.Count > 0)
                {
                    dsResp.Tables[0].TableName = "IPVSlotDesc";
                }

                return objdbwork.ExecutionStatus;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CTabStatus), ex.Message, ex);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }

        }

        public DataSet GetArchives(int ClientNo)
        {
            DbWorkItem objdbwork = null;
            DataSet res = new DataSet();
            try
            {
                objdbwork = new DbWorkItem("stp_GetdownloadVideoDetails");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@ps_Mode", SqlDbType.Char, "S");
                objdbwork.AddParameter("@ps_ClientNo", SqlDbType.Int, ClientNo);

                DbManager.Instance.ExecuteDbTask(objdbwork);
                res.Tables.Add(createStatusTable("0", "Success"));
                res.Tables[0].TableName = "Status";

                int errCode = 0;
                if (errCode == 0 || errCode == 1)
                {
                    res.Tables.Add(((DataSet)objdbwork.Result).Tables[0].Copy());
                }
                else
                {
                    res.Tables.Add(new DataTable());
                }
                res.Tables[1].TableName = "D1";

                return res;

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return res;
            }
        }


        #endregion

        public DataSet DPStatusCount(string s_Depository, string sFromDate, string sToDate)
        {
            DbWorkItem objdbwork = null;
            DataSet res = new DataSet();
            try
            {
                objdbwork = new DbWorkItem("sp_KYC_GetDPStatus");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@ps_Depository", SqlDbType.VarChar, s_Depository);
                objdbwork.AddParameter("@pd_FromDate", SqlDbType.VarChar, sFromDate = sFromDate == null || sFromDate == "" ? null : sFromDate);
                objdbwork.AddParameter("@pd_ToDate", SqlDbType.VarChar, sToDate = sToDate == "" || sToDate == null ? null : sToDate);

                SqlParameter outParamErrNo = new SqlParameter();
                outParamErrNo.ParameterName = "@Ps_ErrorCode";
                outParamErrNo.SqlDbType = SqlDbType.Int;
                outParamErrNo.Size = 8;
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outparam = new SqlParameter();
                outparam.ParameterName = "@Ps_ErrorMessage";
                outparam.SqlDbType = SqlDbType.VarChar;
                outparam.Size = 100;
                outparam.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outparam);


                DbManager.Instance.ExecuteDbTask(objdbwork);
                //res.Tables.Add(createStatusTable((string)objdbwork.parameters[objdbwork.parameters.Count - 2].Value.ToString(), (string)objdbwork.parameters[objdbwork.parameters.Count - 1].Value.ToString())); 
                res.Tables.Add(createStatusTable("0", "Success"));
                res.Tables[0].TableName = "Status";

                //int errCode = (int)objdbwork.parameters[objdbwork.parameters.Count - 2].Value;
                int errCode = 0;
                if (errCode == 0 || errCode == 1)
                {
                    //res[1] = ((DataSet)objdbwork.Result).Tables[0];

                    res.Tables.Add(((DataSet)objdbwork.Result).Tables[0].Copy());


                }
                else
                {
                    //res[1] = new DataTable();
                    res.Tables.Add(new DataTable());
                }
                res.Tables[1].TableName = "D1";

                return res;
                //return outparam.Value.ToString();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return res;
            }
        }
    }
}
