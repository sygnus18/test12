﻿using FTIL.Match.CDD.BAL;
using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web;

namespace eKYCService.Classes
{
    public class CEntityVerification
    {
        #region Properties

        public string APP_UPDTFLG { get; set; }
        public string APP_POS_CODE { get; set; }
        public string APP_TYPE { get; set; }
        public string APP_NO { get; set; }
        public string APP_DATE { get; set; }
        public string APP_PAN_NO { get; set; }
        public string APP_PAN_COPY { get; set; }
        public string APP_EXMT { get; set; }
        public string APP_EXMT_CAT { get; set; }
        public string APP_EXMT_ID_PROOF { get; set; }
        public string APP_IPV_FLAG { get; set; }
        public string APP_IPV_DATE { get; set; }
        public string APP_GEN { get; set; }
        public string APP_NAME { get; set; }
        public string APP_F_NAME { get; set; }
        public string APP_REGNO { get; set; }
        public string APP_DOB_INCORP { get; set; }
        public string APP_COMMENCE_DT { get; set; }
        public string APP_NATIONALITY { get; set; }
        public string APP_OTH_NATIONALITY { get; set; }
        public string APP_COMP_STATUS { get; set; }
        public string APP_OTH_COMP_STATUS { get; set; }
        public string APP_RES_STATUS { get; set; }
        public string APP_RES_STATUS_PROOF { get; set; }
        public string APP_UID_NO { get; set; }
        public string APP_COR_ADD1 { get; set; }
        public string APP_COR_ADD2 { get; set; }
        public string APP_COR_ADD3 { get; set; }
        public string APP_COR_CITY { get; set; }
        public string APP_COR_PINCD { get; set; }
        public string APP_COR_STATE { get; set; }
        public string APP_COR_CTRY { get; set; }
        public string APP_OFF_ISD { get; set; }
        public string APP_OFF_STD { get; set; }
        public string APP_OFF_NO { get; set; }
        public string APP_RES_ISD { get; set; }
        public string APP_RES_STD { get; set; }
        public string APP_RES_NO { get; set; }
        public string APP_MOB_ISD { get; set; }
        public string APP_MOB_NO { get; set; }
        public string APP_FAX_ISD { get; set; }
        public string APP_FAX_STD { get; set; }
        public string APP_FAX_NO { get; set; }
        public string APP_EMAIL { get; set; }
        public string APP_COR_ADD_PROOF { get; set; }
        public string APP_COR_ADD_REF { get; set; }
        public string APP_COR_ADD_DT { get; set; }
        public string APP_PER_ADD_FLAG { get; set; }
        public string APP_PER_ADD1 { get; set; }
        public string APP_PER_ADD2 { get; set; }
        public string APP_PER_ADD3 { get; set; }
        public string APP_PER_CITY { get; set; }
        public string APP_PER_PINCD { get; set; }
        public string APP_PER_STATE { get; set; }
        public string APP_PER_CTRY { get; set; }
        public string APP_PER_ADD_PROOF { get; set; }
        public string APP_PER_ADD_REF { get; set; }
        public string APP_PER_ADD_DT { get; set; }
        public string APP_INCOME { get; set; }
        public string APP_OCC { get; set; }
        public string APP_OTH_OCC { get; set; }
        public string APP_POL_CONN { get; set; }
        public string APP_DOC_PROOF { get; set; }
        public string APP_INTERNAL_REF { get; set; }
        public string APP_BRANCH_CODE { get; set; }
        public string APP_MAR_STATUS { get; set; }
        public string APP_NETWRTH { get; set; }
        public string APP_NETWORTH_DT { get; set; }
        public string APP_INCORP_PLC { get; set; }
        public string APP_OTHERINFO { get; set; }
        public string APP_ACC_OPENDT { get; set; }
        public string APP_ACC_ACTIVEDT { get; set; }
        public string APP_ACC_UPDTDT { get; set; }
        public string APP_PARENT { get; set; }
        public string APP_FILLER1 { get; set; }
        public string APP_FILLER2 { get; set; }
        public string APP_FILLER3 { get; set; }
        public string APP_CVLREFNO { get; set; }
        public string APP_STATUS { get; set; }
        public string APP_STATUSDT { get; set; }
        public string APP_ERROR_DESC { get; set; }
        public string APP_DUMP_TYPE { get; set; }
        public string APP_DNLDDT { get; set; }
        public string APP_REMARKS { get; set; }

        #endregion

        public static Hashtable l_lstNSDL = new Hashtable();
        public static Hashtable l_lstCDSL = new Hashtable();
        public static Hashtable l_lstAadhar = new Hashtable();


        static CEntityVerification()
        {
            //l_lstNSDL.Add("txtFristName");
            //l_lstNSDL.Add("ClientCode");
            //l_lstNSDL.Add("PANNo");
            //l_lstNSDL.Add("Gender ");
            //l_lstNSDL.Add("MaritalStatus");
            //l_lstNSDL.Add("Nationality");


            //l_lstCDSL.Add("NationalityOther");
            //l_lstCDSL.Add("DOB");
            //l_lstCDSL.Add("ClientName");
            //l_lstCDSL.Add("GuardianName");
            //l_lstCDSL.Add("NetWorth");
            //l_lstCDSL.Add("NetWorthAsOnDate");
            //l_lstCDSL.Add("PlaceofIncorporation");
             

            l_lstCDSL.Add("txtFristName","true");
            l_lstCDSL.Add("txtMiddleName", "true");
            l_lstCDSL.Add("txtLastName", "true");
            l_lstCDSL.Add("txtAddress","true");
            l_lstCDSL.Add("Country","true");
            l_lstCDSL.Add("gender","true");
            l_lstCDSL.Add("dateDOB","true");
            l_lstCDSL.Add("DateOfIssue","true");
            l_lstCDSL.Add("ExpiryDate","true");
            l_lstCDSL.Add("Nationality","true");
            l_lstCDSL.Add("OtherNationality","true");
            l_lstCDSL.Add("txtCorrAddress","true");
            l_lstCDSL.Add("cboCorrCity","true");
            l_lstCDSL.Add("txtCorrPIN","true");
            l_lstCDSL.Add("cboCorrState","true");
            l_lstCDSL.Add("cboCorrCountry","true");
            l_lstCDSL.Add("txtCorrTel2","true");
            l_lstCDSL.Add("txtCorrTel1","true");
            l_lstCDSL.Add("txtCorrMobile","true");
            l_lstCDSL.Add("txtCorrFax","true");
            l_lstCDSL.Add("txtCorrMail","true");
            l_lstCDSL.Add("chkSameAsCorrs","true");
            l_lstCDSL.Add("City","true");
            l_lstCDSL.Add("txtPIN","true");
            l_lstCDSL.Add("State","true");
            l_lstCDSL.Add("Occupation","true");
            l_lstCDSL.Add("txtBranch","true");
            l_lstCDSL.Add("Networth","true");
            l_lstCDSL.Add("NetworthDate","true");
            l_lstCDSL.Add("PlaceOfIssue","true");


            l_lstAadhar.Add("txtFristName", "true");
            l_lstAadhar.Add("txtMiddleName", "true");
            l_lstAadhar.Add("txtLastName", "true");
            l_lstAadhar.Add("txtAddress", "true");
            l_lstAadhar.Add("Country", "true");
            l_lstAadhar.Add("gender", "true");
            l_lstAadhar.Add("dateDOB", "true");
            l_lstAadhar.Add("DateOfIssue", "true");
            l_lstAadhar.Add("ExpiryDate", "true");
            l_lstAadhar.Add("Nationality", "true");
            l_lstAadhar.Add("OtherNationality", "true");
            l_lstAadhar.Add("txtCorrAddress", "true");
            l_lstAadhar.Add("cboCorrCity", "true");
            l_lstAadhar.Add("txtCorrPIN", "true");
            l_lstAadhar.Add("cboCorrState", "true");
            l_lstAadhar.Add("cboCorrCountry", "true");
            l_lstAadhar.Add("txtCorrTel2", "true");
            l_lstAadhar.Add("txtCorrTel1", "true");
            l_lstAadhar.Add("txtCorrMobile", "true");
            l_lstAadhar.Add("txtCorrFax", "true");
            l_lstAadhar.Add("txtCorrMail", "true");
            l_lstAadhar.Add("chkSameAsCorrs", "true");
            l_lstAadhar.Add("City", "true");
            l_lstAadhar.Add("txtPIN", "true");
            l_lstAadhar.Add("State", "true");
            l_lstAadhar.Add("Occupation", "true");
            l_lstAadhar.Add("txtBranch", "true");
            l_lstAadhar.Add("Networth", "true");
            l_lstAadhar.Add("NetworthDate", "true");
            l_lstAadhar.Add("PlaceOfIssue", "true");


        }
        public CEntityVerification()
        {
        }

        public CEntityVerification(DataTable dt)
        {
            APP_ACC_ACTIVEDT = dt.Columns.Contains("APP_ACC_ACTIVEDT") ? dt.Rows[0]["APP_ACC_ACTIVEDT"].ToString() : string.Empty;
            APP_ACC_OPENDT = dt.Columns.Contains("APP_ACC_OPENDT") ? dt.Rows[0]["APP_ACC_OPENDT"].ToString() : string.Empty;
            APP_ACC_UPDTDT = dt.Columns.Contains("APP_ACC_UPDTDT") ? dt.Rows[0]["APP_ACC_UPDTDT"].ToString() : string.Empty;
            APP_BRANCH_CODE = dt.Columns.Contains("APP_BRANCH_CODE") ? dt.Rows[0]["APP_BRANCH_CODE"].ToString() : string.Empty;
            APP_COMMENCE_DT = dt.Columns.Contains("APP_COMMENCE_DT") ? dt.Rows[0]["APP_COMMENCE_DT"].ToString() : string.Empty;
            APP_COMP_STATUS = dt.Columns.Contains("APP_COMP_STATUS") ? dt.Rows[0]["APP_COMP_STATUS"].ToString() : string.Empty;
            APP_COR_ADD_DT = dt.Columns.Contains("APP_COR_ADD_DT") ? dt.Rows[0]["APP_COR_ADD_DT"].ToString() : string.Empty;
            APP_COR_ADD_PROOF = dt.Columns.Contains("APP_COR_ADD_PROOF") ? dt.Rows[0]["APP_COR_ADD_PROOF"].ToString() : string.Empty;
            APP_COR_ADD_REF = dt.Columns.Contains("APP_COR_ADD_REF") ? dt.Rows[0]["APP_COR_ADD_REF"].ToString() : string.Empty;
            APP_COR_ADD1 = dt.Columns.Contains("APP_COR_ADD1") ? dt.Rows[0]["APP_COR_ADD1"].ToString() : string.Empty;
            APP_COR_ADD2 = dt.Columns.Contains("APP_COR_ADD2") ? dt.Rows[0]["APP_COR_ADD2"].ToString() : string.Empty;
            APP_COR_ADD3 = dt.Columns.Contains("APP_COR_ADD3") ? dt.Rows[0]["APP_COR_ADD3"].ToString() : string.Empty;
            APP_COR_CITY = dt.Columns.Contains("APP_COR_CITY") ? dt.Rows[0]["APP_COR_CITY"].ToString() : string.Empty;
            APP_COR_CTRY = dt.Columns.Contains("APP_COR_CTRY") ? dt.Rows[0]["APP_COR_CTRY"].ToString() : string.Empty;
            APP_COR_PINCD = dt.Columns.Contains("APP_COR_PINCD") ? dt.Rows[0]["APP_COR_PINCD"].ToString() : string.Empty;
            APP_COR_STATE = dt.Columns.Contains("APP_COR_STATE") ? dt.Rows[0]["APP_COR_STATE"].ToString() : string.Empty;
            APP_CVLREFNO = dt.Columns.Contains("APP_CVLREFNO") ? dt.Rows[0]["APP_CVLREFNO"].ToString() : string.Empty;
            APP_DATE = dt.Columns.Contains("APP_DATE") ? dt.Rows[0]["APP_DATE"].ToString() : string.Empty;
            APP_DNLDDT = dt.Columns.Contains("APP_DNLDDT") ? dt.Rows[0]["APP_DNLDDT"].ToString() : string.Empty;
            APP_DOB_INCORP = dt.Columns.Contains("APP_DOB_DT") ? dt.Rows[0]["APP_DOB_DT"].ToString() : string.Empty;
            APP_DOC_PROOF = dt.Columns.Contains("APP_DOC_PROOF") ? dt.Rows[0]["APP_DOC_PROOF"].ToString() : string.Empty;
            APP_DUMP_TYPE = dt.Columns.Contains("APP_DUMP_TYPE") ? dt.Rows[0]["APP_DUMP_TYPE"].ToString() : string.Empty;
            APP_EMAIL = dt.Columns.Contains("APP_EMAIL") ? dt.Rows[0]["APP_EMAIL"].ToString() : string.Empty;
            APP_ERROR_DESC = dt.Columns.Contains("APP_ERROR_DESC") ? dt.Rows[0]["APP_ERROR_DESC"].ToString() : string.Empty;
            APP_EXMT = dt.Columns.Contains("APP_EXMT") ? dt.Rows[0]["APP_EXMT"].ToString() : string.Empty;
            APP_EXMT_CAT = dt.Columns.Contains("APP_EXMT_CAT") ? dt.Rows[0]["APP_EXMT_CAT"].ToString() : string.Empty;
            APP_EXMT_ID_PROOF = dt.Columns.Contains("APP_EXMT_ID_PROOF") ? dt.Rows[0]["APP_EXMT_ID_PROOF"].ToString() : string.Empty;
            APP_F_NAME = dt.Columns.Contains("APP_F_NAME") ? dt.Rows[0]["APP_F_NAME"].ToString() : string.Empty;
            APP_FAX_ISD = dt.Columns.Contains("APP_FAX_ISD") ? dt.Rows[0]["APP_FAX_ISD"].ToString() : string.Empty;
            APP_FAX_NO = dt.Columns.Contains("APP_FAX_NO") ? dt.Rows[0]["APP_FAX_NO"].ToString() : string.Empty;
            APP_FAX_STD = dt.Columns.Contains("APP_FAX_STD") ? dt.Rows[0]["APP_FAX_STD"].ToString() : string.Empty;
            APP_FILLER1 = dt.Columns.Contains("APP_FILLER1") ? dt.Rows[0]["APP_FILLER1"].ToString() : string.Empty;
            APP_FILLER2 = dt.Columns.Contains("APP_FILLER2") ? dt.Rows[0]["APP_FILLER2"].ToString() : string.Empty;
            APP_FILLER3 = dt.Columns.Contains("APP_FILLER3") ? dt.Rows[0]["APP_FILLER3"].ToString() : string.Empty;
            APP_GEN = dt.Columns.Contains("APP_GEN") ? dt.Rows[0]["APP_GEN"].ToString() : string.Empty;
            APP_INCORP_PLC = dt.Columns.Contains("APP_INCORP_PLC") ? dt.Rows[0]["APP_INCORP_PLC"].ToString() : string.Empty;
            APP_INTERNAL_REF = dt.Columns.Contains("APP_INTERNAL_REF") ? dt.Rows[0]["APP_INTERNAL_REF"].ToString() : string.Empty;
            APP_IPV_DATE = dt.Columns.Contains("APP_IPV_DATE") ? dt.Rows[0]["APP_IPV_DATE"].ToString() : string.Empty;
            APP_IPV_FLAG = dt.Columns.Contains("APP_IPV_FLAG") ? dt.Rows[0]["APP_IPV_FLAG"].ToString() : string.Empty;
            APP_MAR_STATUS = dt.Columns.Contains("APP_MAR_STATUS") ? dt.Rows[0]["APP_MAR_STATUS"].ToString() : string.Empty;
            APP_MOB_ISD = dt.Columns.Contains("APP_MOB_ISD") ? dt.Rows[0]["APP_MOB_ISD"].ToString() : string.Empty;
            APP_MOB_NO = dt.Columns.Contains("APP_MOB_NO") ? dt.Rows[0]["APP_MOB_NO"].ToString() : string.Empty;
            APP_NAME = dt.Columns.Contains("APP_NAME") ? dt.Rows[0]["APP_NAME"].ToString() : string.Empty;
            APP_NATIONALITY = dt.Columns.Contains("APP_NATIONALITY") ? dt.Rows[0]["APP_NATIONALITY"].ToString() : string.Empty;
            APP_NETWORTH_DT = dt.Columns.Contains("APP_NETWORTH_DT") ? dt.Rows[0]["APP_NETWORTH_DT"].ToString() : string.Empty;
            APP_NETWRTH = dt.Columns.Contains("APP_NETWRTH") ? dt.Rows[0]["APP_NETWRTH"].ToString() : string.Empty;
            APP_NO = dt.Columns.Contains("APP_NO") ? dt.Rows[0]["APP_NO"].ToString() : string.Empty;
            APP_OCC = dt.Columns.Contains("APP_OCC") ? dt.Rows[0]["APP_OCC"].ToString() : string.Empty;
            APP_OFF_ISD = dt.Columns.Contains("APP_OFF_ISD") ? dt.Rows[0]["APP_OFF_ISD"].ToString() : string.Empty;
            APP_OFF_NO = dt.Columns.Contains("APP_OFF_NO") ? dt.Rows[0]["APP_OFF_NO"].ToString() : string.Empty;
            APP_OFF_STD = dt.Columns.Contains("APP_OFF_STD") ? dt.Rows[0]["APP_OFF_STD"].ToString() : string.Empty;
            APP_OTH_COMP_STATUS = dt.Columns.Contains("APP_OTH_COMP_STATUS") ? dt.Rows[0]["APP_OTH_COMP_STATUS"].ToString() : string.Empty;
            APP_OTH_NATIONALITY = dt.Columns.Contains("APP_OTH_NATIONALITY") ? dt.Rows[0]["APP_OTH_NATIONALITY"].ToString() : string.Empty;
            APP_OTH_OCC = dt.Columns.Contains("APP_OTH_OCC") ? dt.Rows[0]["APP_OTH_OCC"].ToString() : string.Empty;
            APP_OTHERINFO = dt.Columns.Contains("APP_OTHERINFO") ? dt.Rows[0]["APP_OTHERINFO"].ToString() : string.Empty;
            APP_PAN_COPY = dt.Columns.Contains("APP_PAN_COPY") ? dt.Rows[0]["APP_PAN_COPY"].ToString() : string.Empty;
            APP_PAN_NO = dt.Columns.Contains("APP_PAN_NO") ? dt.Rows[0]["APP_PAN_NO"].ToString() : string.Empty;
            APP_PARENT = dt.Columns.Contains("APP_PARENT") ? dt.Rows[0]["APP_PARENT"].ToString() : string.Empty;
            APP_PER_ADD_DT = dt.Columns.Contains("APP_PER_ADD_DT") ? dt.Rows[0]["APP_PER_ADD_DT"].ToString() : string.Empty;
            APP_PER_ADD_FLAG = dt.Columns.Contains("APP_PER_ADD_FLAG") ? dt.Rows[0]["APP_PER_ADD_FLAG"].ToString() : string.Empty;
            APP_PER_ADD_PROOF = dt.Columns.Contains("APP_PER_ADD_PROOF") ? dt.Rows[0]["APP_PER_ADD_PROOF"].ToString() : string.Empty;
            APP_PER_ADD_REF = dt.Columns.Contains("APP_PER_ADD_REF") ? dt.Rows[0]["APP_PER_ADD_REF"].ToString() : string.Empty;
            APP_PER_ADD1 = dt.Columns.Contains("APP_PER_ADD1") ? dt.Rows[0]["APP_PER_ADD1"].ToString() : string.Empty;
            APP_PER_ADD2 = dt.Columns.Contains("APP_PER_ADD2") ? dt.Rows[0]["APP_PER_ADD2"].ToString() : string.Empty;
            APP_PER_ADD3 = dt.Columns.Contains("APP_PER_ADD3") ? dt.Rows[0]["APP_PER_ADD3"].ToString() : string.Empty;
            APP_PER_CITY = dt.Columns.Contains("APP_PER_CITY") ? dt.Rows[0]["APP_PER_CITY"].ToString() : string.Empty;
            APP_PER_CTRY = dt.Columns.Contains("APP_PER_CTRY") ? dt.Rows[0]["APP_PER_CTRY"].ToString() : string.Empty;
            APP_PER_PINCD = dt.Columns.Contains("APP_PER_PINCD") ? dt.Rows[0]["APP_PER_PINCD"].ToString() : string.Empty;
            APP_PER_STATE = dt.Columns.Contains("APP_PER_STATE") ? dt.Rows[0]["APP_PER_STATE"].ToString() : string.Empty;
            APP_POL_CONN = dt.Columns.Contains("APP_POL_CONN") ? dt.Rows[0]["APP_POL_CONN"].ToString() : string.Empty;
            APP_POS_CODE = dt.Columns.Contains("APP_POS_CODE") ? dt.Rows[0]["APP_POS_CODE"].ToString() : string.Empty;
            APP_REGNO = dt.Columns.Contains("APP_REGNO") ? dt.Rows[0]["APP_REGNO"].ToString() : string.Empty;
            APP_REMARKS = dt.Columns.Contains("APP_REMARKS") ? dt.Rows[0]["APP_REMARKS"].ToString() : string.Empty;
            APP_RES_ISD = dt.Columns.Contains("APP_RES_ISD") ? dt.Rows[0]["APP_RES_ISD"].ToString() : string.Empty;
            APP_RES_NO = dt.Columns.Contains("APP_RES_NO") ? dt.Rows[0]["APP_RES_NO"].ToString() : string.Empty;
            APP_RES_STATUS = dt.Columns.Contains("APP_RES_STATUS") ? dt.Rows[0]["APP_RES_STATUS"].ToString() : string.Empty;
            APP_RES_STATUS_PROOF = dt.Columns.Contains("APP_RES_STATUS_PROOF") ? dt.Rows[0]["APP_RES_STATUS_PROOF"].ToString() : string.Empty;
            APP_RES_STD = dt.Columns.Contains("APP_RES_STD") ? dt.Rows[0]["APP_RES_STD"].ToString() : string.Empty;
            APP_STATUS = dt.Columns.Contains("APP_STATUS") ? dt.Rows[0]["APP_STATUS"].ToString() : string.Empty;
            APP_STATUSDT = dt.Columns.Contains("APP_STATUSDT") ? dt.Rows[0]["APP_STATUSDT"].ToString() : string.Empty;
            APP_TYPE = dt.Columns.Contains("APP_TYPE") ? dt.Rows[0]["APP_TYPE"].ToString() : string.Empty;
            APP_UID_NO = dt.Columns.Contains("APP_UID_NO") ? dt.Rows[0]["APP_UID_NO"].ToString() : string.Empty;
            APP_UPDTFLG = dt.Columns.Contains("APP_UPDTFLG") ? dt.Rows[0]["APP_UPDTFLG"].ToString() : string.Empty; 

        }


        public EntityDetails FillEntityMasterProperties(string Mobile)
        {
            CEntityMaster objEntityMaster = new CEntityMaster();
            EntityDetails details = new EntityDetails();
            Address objCorAddress = new Address();
            Address objPerAddress = new Address();
            MethodExecResult objMER = new MethodExecResult(-1);
             

            objCorAddress.AddressNo = string.Empty;
            objCorAddress.Address_Line1 = APP_COR_ADD1;
            objCorAddress.Address_Line2 = APP_COR_ADD2;
            objCorAddress.Address_Line3 = APP_COR_ADD3;
            objCorAddress.City = APP_COR_CITY;
            objCorAddress.State_Others = APP_COR_STATE;
            objCorAddress.Country = APP_COR_CTRY;
            objCorAddress.PIN_Code = APP_COR_PINCD;
            objCorAddress.StateCode = APP_COR_STATE;

            //objCorAddress.Tel_Work = APP_OFF_NO;

            objCorAddress.Fax_No = APP_FAX_NO;


            if (!string.IsNullOrEmpty(APP_MOB_NO))
            {
                if (APP_MOB_NO != Mobile)
                {
                    objCorAddress.Mobile_No = APP_MOB_NO;
                    objCorAddress.Tel_Work = Mobile;
                }
                else
                    objCorAddress.Mobile_No = APP_MOB_NO;
            }
            else
            {
                objCorAddress.Mobile_No = Mobile;
            }
            objCorAddress.Email_ID = APP_EMAIL;


            objPerAddress.AddressNo = string.Empty;
            objPerAddress.Address_Line1 = APP_PER_ADD1;
            objPerAddress.Address_Line2 = APP_PER_ADD2;
            objPerAddress.Address_Line3 = APP_PER_ADD3;
            objPerAddress.City = APP_PER_CITY;
            objPerAddress.State_Others = APP_PER_STATE;
            objPerAddress.Country = APP_PER_CTRY;
            objPerAddress.PIN_Code = APP_COR_PINCD;
            objPerAddress.Tel_Res = APP_PER_CTRY;
            objPerAddress.StateCode = APP_PER_STATE;
            objPerAddress.Fax_No = APP_FAX_NO;
            objPerAddress.Mobile_No = APP_MOB_NO;
            objPerAddress.Email_ID = APP_EMAIL;

            details.KYCFormNo = string.Empty;
            details.ClientNo = 0;
            details.Applicant_Name = APP_NAME;
            details.Father_sHusbands_Name = APP_F_NAME;
            details.Branch = APP_BRANCH_CODE;
            details.Short_Code = string.Empty;
            details.Gender = APP_GEN;
            details.Marital_status = APP_MAR_STATUS;
            details.StatusNonIndVal = string.Empty;
            details.Nationality = APP_NATIONALITY;
            try
            {
                if (!string.IsNullOrEmpty(APP_DOB_INCORP))
                {
                    //DateTime dt = DateTime.Parse(APP_DOB_INCORP, new CultureInfo("en-CA"));
                    //APP_DOB_INCORP = dt.ToString("yyyy/MM/dd").Replace('-', '/');
                    //details.DOB_OR_DOI = string.IsNullOrEmpty(APP_DOB_INCORP) ? details.DOB_OR_DOI : Convert.ToDateTime(APP_DOB_INCORP);

                    string dateTimeString = APP_DOB_INCORP;
                    dateTimeString = Regex.Replace(dateTimeString, @"[^\u0000-\u007F]", string.Empty);

                    string inputFormat = "dd/MM/yyyy";
                    details.DOB_OR_DOI = DateTime.ParseExact(dateTimeString, inputFormat, CultureInfo.InvariantCulture);
                }
                else
                {
                    details.DOB_OR_DOI = null;
                }
            }
            catch { details.DOB_OR_DOI = null; }

            details.CorrespondenceAddress = objCorAddress;
            details.PermanentAddress = objPerAddress;
            details.FristName = APP_NAME;
            details.MiddleName = string.Empty;
            details.LastName = string.Empty;
            details.SkypeId = APP_UID_NO;
            details.AddressNo = string.Empty;
            details.PerAddressNo = string.Empty;
            details.Title = string.Empty;
            details.NationalityOther = APP_OTH_NATIONALITY;
            details.SameCorrPermAdd = "N";

            details.Occupation = APP_OCC;
            details.OccupationOther = APP_OTH_OCC;
            details.PEPDesc = APP_POL_CONN;
            details.AnnualIncome = APP_INCOME;
            details.PAN = APP_PAN_NO;
            details.PANExempt = APP_EXMT;

            if (!string.IsNullOrEmpty(APP_NETWORTH_DT))
            {//details.NetworthDate = DateTime.ParseExact(APP_NETWORTH_DT, "dd/MM/yyyy", null); //Convert.ToDateTime(NetworthDate);

                string dateTimeString1 = APP_NETWORTH_DT;
                dateTimeString1 = Regex.Replace(dateTimeString1, @"[^\u0000-\u007F]", string.Empty);

                string inputFormat1 = "dd/MM/yyyy";
                details.NetworthDate = DateTime.ParseExact(dateTimeString1, inputFormat1, CultureInfo.InvariantCulture);
            }
            details.Networth = APP_NETWRTH;
            return details;
             
        }
        #region GetFieldList
        public MethodExecResult GetFieldList(string sMode, int nEntityNo, ref DataSet dsdata)
        {
            try
            {  
                DbWorkItem objdbwork = new DbWorkItem("Stp_EntityVerificationOperation"); 
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, sMode);
                objdbwork.AddParameter("@pn_EntityNo", SqlDbType.VarChar, nEntityNo);

                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {

                    dsdata = objdbwork.Result as DataSet;
                    if (sMode == "S" && ((dsdata == null) || (dsdata.Tables.Count == 0)))
                    {
                        return new MethodExecResult(-1, null, "No recordset returned from database.", null);
                    }

                    return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, string.Empty, null);
                }
                else
                {
                    Logger.Instance.WriteLog(typeof(CEntityVerification), objdbwork.ExecutionStatus);
                    return objdbwork.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityVerification), ex.Message, ex);
                // MatchWebUtility.LogWrite.WriteLog(this.GetType().ToString(), "", "", "", "Error:GetFieldList" + ex.Message + " StackTrace: " + ex.StackTrace, ex);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }
        }
        #endregion
         
    }
}