using System;
using System.IO;
using System.Text;
using FTIL.Match.Common.Utils;
using System.Threading.Tasks;
using System.Threading;
 

    /// <summary>
    /// Class for Request log 
    /// </summary>
    public class CLogger
   {
        #region :Variable
            
            private  bool bLogEnabled; 
            private  StreamWriter logfile;
            private  DateTime logDateTime;

            private static CLogger m_Instance;

        #endregion :Variable

        private CLogger()
		{
            try 
            {	        
		        string sEnableLog = "Y" ;// = System.Configuration.ConfigurationManager.AppSettings["EnabledRequestLog"];
                bLogEnabled = sEnableLog == "Y";
            }
            catch
            {
	          	bLogEnabled = false;
            }

            if (bLogEnabled)
            {
                SetLogFile();
            }
		}

        public static CLogger Instance
        {
            get
            {
                if (m_Instance == null)
                    m_Instance = new CLogger();
                return m_Instance;
            }
        }

        #region Public Methods
       
		public void WriteLine(string s)
		{
            if (bLogEnabled)
            {
                CheckDayChanged();

                //Console.WriteLine(s);
                //logfile.Write(DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss:ffff") + "  ");
                logfile.WriteLine((DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss:ffff")) + "  " + s);
            }
		}

        //public void WriteResponse(UserAuthenticationWCFLibrary.Response response)
        //{
        //    WriteLine("Response : " +
        //                " ResponseCode= " +  response.ResponseCode + 
        //                " ResponseMessage= " +  response.ResponseMessage + 
        //                " LoginAttemptCount= " +  response.LoginAttemptCount + 
        //                " n2FAType= " +  response.n2FAType + 
        //                " ReferenceID= " +  response.ReferenceID + 
        //                " Remark= " +  response.Remark + 
        //                " RequestDateTime= " +  response.RequestDateTime + 
        //                " TokenID= " +  response.TokenID
        //             );
        //}
        

		public void Write(string s)
		{
            if (bLogEnabled)
            {
                CheckDayChanged();

               // logfile.Write(DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss:ffff") + "  ");
                logfile.Write(DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss:ffff") + "  " + s);
            }
        }


        private void CheckDayChanged()
        {
            //If date changed create new log file 
            if (logDateTime.Date != DateTime.Now.Date)
            {
                try
                {
                    logfile.Close();
                }
                catch
                {
                }
                SetLogFile();
            }
        }


        private void SetLogFile()
        {

            string BaseDirectory = Convert.ToString(AppDomain.CurrentDomain.BaseDirectory);

            logDateTime = DateTime.Now;

            string sLogPath = BaseDirectory + Convert.ToString(System.Configuration.ConfigurationSettings.AppSettings["RequestLogPath"]);

            string sLogFileName =    System.Configuration.ConfigurationSettings.AppSettings["RequestLogFileName"];

            //Check Whether the Logs Directory Exists if not then Create one
            if (!Directory.Exists(sLogPath))
            {
                Directory.CreateDirectory(sLogPath);
            }

            FileStream tempstream = new FileStream(sLogPath + "\\" + sLogFileName + logDateTime.ToString("yyyyMMdd") + ".log",
                                    FileMode.Append, FileAccess.Write, FileShare.ReadWrite);

            logfile = new StreamWriter(tempstream);

            logfile.AutoFlush = true;

            //This is used to Write a New Log Session inside the File
            //logfile.WriteLine("");
            logfile.WriteLine("====== Log Session : " + logDateTime.ToString() + "======");
        }

        /// <summary>
        /// Write log with new thread for async calling 
        /// </summary>
        /// <param name="s"></param>
        public void WriteLineAsync(string s) 
        { 
             new Thread(() =>
            {
                WriteLine(s);
            }).Start();
           
        }




        /*
         /// <summary>
        /// Write log with new thread for async calling for framework 4.5 and above
        /// </summary>
        /// <param name="s"></param>
       public async Task<int> WriteLineAsync(string s)
        { 
            return await Task.Run<int>(() =>
            {
                WriteLine(s);
                return 0;
            });   
        }
        */

        /// <summary>
        /// Write response details async .
        /// </summary>
        /// <param name="response"></param>
        //public void WriteResponseAsync(UserAuthenticationWCFLibrary.Response response)
        // {
        //      new Thread(() =>
        //      {
        //          WriteResponse(response);
        //      }).Start();
             
        //}

       /*
       /// <summary>
       /// /// Write response details async for framework 4.5 and above
       /// </summary>
       /// <param name="response"></param>
       /// <returns></returns>
       public async Task<int> WriteResponseAsync(UserAuthenticationWCFLibrary.Response response)
       { 
             return await Task.Run<int>(() =>
             {
                 WriteResponse(response);
                 return 0;
             }); 
       }
       */
        #endregion Public Methods
   } 
