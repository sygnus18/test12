﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FTIL.Match.Common.Log;
using UCC.Class;

namespace FTIL.Match.CDD.BAL.DataClasses
{
    public class ClientFatcaDetail
    {
        #region public properties
        public int FatcaDetailNo { get; set; }
        public int ClientNo { get; set; }
        public int USCitizen { get; set; }
        public int OtherCitizen { get; set; }
        public string BirthPlace { get; set; }
        public string CountryPlace { get; set; }
        public int TaxResidentFlag { get; set; }
        public string TaxResidentCountry { get; set; }
        public string TaxIdNo { get; set; }
        public string IdentificationType { get; set; }
        public DateTime LastModifiedDateTime { get; set; }
        #endregion public properties

        #region methods
        /// <summary>
        /// Initializes current instance from DataRow
        /// </summary>
        /// <param name="DataRow">DataRow object containing client Trading details</param>
        #region InitializeFromDataRow
        public void InitializeFromDataRow(DataRow dataRow)
        {
            try
            {
                if ((dataRow["n_ClientNo"] != null) && (dataRow["n_ClientNo"] != DBNull.Value))
                    this.ClientNo = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_ClientNo"));
                if ((dataRow["n_FatcaDetailNo"] != null) && (dataRow["n_FatcaDetailNo"] != DBNull.Value))
                    this.FatcaDetailNo = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_FatcaDetailNo"));
                if ((dataRow["n_USCitizen"] != null) && (dataRow["n_USCitizen"] != DBNull.Value))
                    this.USCitizen = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_USCitizen"));
                if ((dataRow["n_OtherCitizen"] != null) && (dataRow["n_OtherCitizen"] != DBNull.Value))
                    this.OtherCitizen = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_OtherCitizen"));
                this.BirthPlace = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_BirthPlace"));
                this.CountryPlace = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_CountryPlace"));
                if ((dataRow["n_TaxResidentFlag"] != null) && (dataRow["n_TaxResidentFlag"] != DBNull.Value))
                    this.TaxResidentFlag = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_TaxResidentFlag"));
                this.TaxResidentCountry = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_TaxResidentCountry"));
                this.TaxIdNo = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_TaxIdNo"));
                this.IdentificationType = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_IdentificationType"));
                if ((dataRow["d_LastModifiedDateTime"] != null) && (dataRow["d_LastModifiedDateTime"] != DBNull.Value))
                    this.LastModifiedDateTime = Convert.ToDateTime(Utility.GetValueFromDataRow(dataRow, "d_LastModifiedDateTime"));
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                throw ex;
            }
        }
        #endregion
        #endregion methods
    }
}
