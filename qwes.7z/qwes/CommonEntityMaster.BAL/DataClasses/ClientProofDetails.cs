﻿using System.Collections.Generic;

namespace FTIL.Match.CDD.BAL.DataStore
{
    /// <summary>
    /// contains Client Proof Details.
    /// </summary>
    public class ClientProofDetails
    {
        #region class variables
        /// <summary>
        /// List of ClientProofDetail
        /// </summary>
        private List<ClientProofDetail> m_CProofDetailsList;
        #endregion class variables

        #region Properties

        /// <summary>
        /// Proof Details List
        /// </summary>
        public List<ClientProofDetail> ProofDetailsList
        {
            get { return m_CProofDetailsList; }
            set { m_CProofDetailsList = value; }
        }
        #endregion

        #region constructor
        public ClientProofDetails()
        {
            m_CProofDetailsList = new List<ClientProofDetail>();
        }
        #endregion constructor

        #region methods
        /// <summary>
        /// Add new proof Detail
        /// </summary>
        /// <param name="oClientBankDetail">ClientProofDetail Object filled with details</param>
        /// <returns>0 - Success, -1 - Failed</returns>
        public int Add(ClientProofDetail oClientProofDetail)
        {
            int oResult = m_CProofDetailsList.FindIndex(obj => obj.EntityDocNo == oClientProofDetail.EntityDocNo);

            if (oResult != 0)
            {
                m_CProofDetailsList.Add(oClientProofDetail);
                return 0;
            }
            else
            {
                return -1;
            }
        }
        #endregion methods
    }
}
