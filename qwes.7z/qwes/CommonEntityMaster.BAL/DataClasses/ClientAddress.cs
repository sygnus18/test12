﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FTIL.Match.Common.Log;
using UCC.Class;

namespace FTIL.Match.CDD.BAL.DataStore
{
    public class ClientAddress
    {
        #region Properties

        public int ClientNo { get; set; }
        public int AddressType { get; set; }
        public string ContactPerson { get; set; }
        public string Designation { get; set; }
        public string PANNo { get; set; }
        public string DIN { get; set; }
        public string Director { get; set; }
        public string UID { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string AddressLine4 { get; set; }
        public int CityStateCode { get; set; }
        public string City { get; set; }
        public string PinCode { get; set; }
        public int StateNumber { get; set; }
        public string StateOther { get; set; }
        public int CountryCode { get; set; }
        public string TelNoISDCode { get; set; }
        public string TelNoSTDCode { get; set; }
        public string TelNo1 { get; set; }
        public string TelNoOfficeISDCode { get; set; }
        public string TelNoOfficeSTDCode { get; set; }
        public string TelNoOffice { get; set; }
        public string Mobile1 { get; set; }
        public string Mobile2 { get; set; }
        public string FaxNoISDCode { get; set; }
        public string FaxNoSTDCode { get; set; }
        public string FaxNo { get; set; }
        public string EMailId { get; set; }
        public string CCEmail { get; set; }
        public string BCCMail { get; set; }
        public string Default { get; set; }
        public string ContactPersonDefault { get; set; }
        public string SameCorrPermAdd { get; set; }
        public int UserNo { get; set; }
        public string StateName { get; set; }
        public string CountryName { get; set; }
        public DateTime LastModifiedDateTime { get; set; }

        public ClientAddresses oClientAddresses { get; set; }

        #endregion

        #region Constructors

        public ClientAddress(int clientNo, Client_AddressType addressType)
        {
            ClientNo = clientNo;
            AddressType = (int)addressType;
        }

        public ClientAddress()
        { 
        }
        
        #endregion Constructors

        #region public methods

        /// <summary>
        /// Initializes current instance from DataRow
        /// </summary>
        /// <param name="DataRow">DataRow object containing client details</param>
        #region InitializeFromDataRow
        public void InitializeFromDataRow(DataRow dataRow)
        {
            try
            {
                if ((dataRow["n_ClientNo"] != null) && (dataRow["n_ClientNo"] != DBNull.Value))
                    this.ClientNo = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_ClientNo"));
                if ((dataRow["n_AddressType"] != null) && (dataRow["n_AddressType"] != DBNull.Value))
                    this.AddressType = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_AddressType"));
                this.ContactPerson = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_ContactPerson"));
                this.Designation = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_Designation"));
                this.DIN = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_DIN"));
                this.Director = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_Director"));
                this.UID = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_UID"));
                this.PANNo = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_PANNo"));
                this.AddressLine1 = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_AddressLine1"));
                this.AddressLine2 = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_AddressLine2"));
                this.AddressLine3 = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_AddressLine3"));
                this.AddressLine4 = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_AddressLine4"));
                if ((dataRow["n_CityStateCode"] != null) && (dataRow["n_CityStateCode"] != DBNull.Value))
                    this.CityStateCode = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_CityStateCode"));
                this.City = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_City"));
                this.PinCode = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_PinCode"));
                this.StateOther = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_StateOther"));
                if ((dataRow["n_CountryCode"] != null) && (dataRow["n_CountryCode"] != DBNull.Value))
                    this.CountryCode = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_CountryCode"));
                this.TelNoISDCode = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_TelNoISDCode"));
                this.TelNoSTDCode = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_TelNoSTDCode"));
                this.TelNo1 = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_TelNo1"));
                this.TelNoOfficeISDCode = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_TelNoOfficeISDCode"));
                this.TelNoOfficeSTDCode = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_TelNoOfficeSTDCode"));
                this.TelNoOffice = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_TelNoOffice"));
                this.Mobile1 = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_Mobile1"));
                this.Mobile2 = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_Mobile2"));
                this.FaxNoISDCode = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_FaxNoISDCode"));
                this.FaxNoSTDCode = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_FaxNoSTDCode"));
                this.FaxNo = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_FaxNo"));
                this.EMailId = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_EMailId"));
                this.CCEmail = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_CCEmail"));
                this.BCCMail = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_BCCMail"));
                this.Default = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_Default"));
                this.ContactPersonDefault = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_ContactPersonDefault"));
                this.SameCorrPermAdd = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_SameCorrPermAdd"));
                if ((dataRow["n_UserNo"] != null) && (dataRow["n_UserNo"] != DBNull.Value))
                    this.UserNo = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_UserNo"));
                if ((dataRow["d_LastModifiedDateTime"] != null) && (dataRow["d_LastModifiedDateTime"] != DBNull.Value))
                    this.LastModifiedDateTime = Convert.ToDateTime(Utility.GetValueFromDataRow(dataRow, "d_LastModifiedDateTime"));
                if ((dataRow["n_StateNumber"] != null) && (dataRow["n_StateNumber"] != DBNull.Value))
                    this.StateNumber = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_StateNumber"));
                    
                this.StateName = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_StateName"));
                this.CountryName = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_CountryName"));
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                throw ex;
            }
        }
        #endregion

        public string Validate()
        {
            return null;
        }

        #endregion public methods

        public void objtostring()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append(AddressLine1);
            sb.Append(AddressLine2);
            sb.Append(AddressLine3);
            sb.Append(City);
            sb.Append(CityStateCode);
            sb.Append(CountryCode);
            sb.Append(PinCode);
            sb.Append(SameCorrPermAdd);
 
        }

    }   
}
