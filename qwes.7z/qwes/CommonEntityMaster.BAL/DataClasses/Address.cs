﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using UCC.Class;

namespace FTIL.Match.CDD.BAL.DataClasses
{
    /// <summary>
    /// Class for storing Address details
    /// </summary>
    public class Address
    {
        public string AddressNo { get; set; }
        public int ClientNo { get; set; }
        public string Address_Line1 { get; set; }
        public string Address_Line2 { get; set; }
        public string Address_Line3 { get; set; }
        public string City { get; set; }
        public string PIN_Code { get; set; }
        public string StateCode { get; set; }
        public string State_Others { get; set; }
        public string Country { get; set; }

        public string Tel_Res { get; set; }
        public string Tel_Work { get; set; }
        public string Mobile_No { get; set; }
        public string Mobile_NoWork { get; set; }
        public string Fax_No { get; set; }
        public string Email_ID { get; set; }
        
        public string SameCorrPermAdd { get; set; }


        /// <summary>
        /// Set fields from DataRow
        /// </summary>
        /// <param name="row">Source DataRow</param>
        public void SetFromDataRow(DataRow row)
        {
            this.Address_Line1 = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.ADDRESSLINE1));
            this.Address_Line2 = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.ADDRESSLINE2));
            this.Address_Line3 = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.ADDRESSLINE3));
            this.City = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.CITY));
            this.Country = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.COUNTRYCODE));
            this.Email_ID = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.EMAILID));
            this.Fax_No = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.FAXNO));
            this.Mobile_No = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.MOBILE1));
            this.Mobile_NoWork = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.MOBILE2));
            this.Tel_Res = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.TELNO1));
            this.Tel_Work = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.TELNOOFFICE));
            this.PIN_Code = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.PINCODE));
            this.State_Others = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.STATEOTHER));
            this.StateCode = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.STATENUMBER));

            this.SameCorrPermAdd = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.SAMECORRPERMADD));
        
        }

    }
}
