﻿using System;
using System.Collections.Generic;
using System.Data;
using FTIL.Match.Common;
using FTIL.Match.Common.Log;

namespace FTIL.Match.CDD.BAL.DataStore
{
    public class Store
    {
        #region variables 
        public Clients objClients;
        #endregion variables

        #region Constructor
        public Store()
        {
            if (objClients == null)
            {
                objClients = new Clients();
            }
        }
        #endregion Constructor

        #region public methods

        /// <summary>
        /// add new client in objClients
        /// </summary>
        /// <param name="oClient"></param>
        /// <returns></returns>
        public int Add(Client oClient)
        {
            return objClients.Add(oClient);
        }
        
        
        #endregion public methods
    }
}
