﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTIL.Match.CDD.BAL.DataStore
{
    public class ClientSchemeDetails
    {
        #region class variables
        /// <summary>
        /// List of ClientSchemeDetail
        /// </summary>
        private List<ClientSchemeDetail> m_CSchemeDetailsList;
        #endregion class variables

        #region Properties

        /// <summary>
        /// Scheme Details List
        /// </summary>
        public List<ClientSchemeDetail> SchemeDetailsList
        {
            get { return m_CSchemeDetailsList; }
            set { m_CSchemeDetailsList = value; }
        }
        #endregion

        #region constructor
        public ClientSchemeDetails()
        {
            m_CSchemeDetailsList = new List<ClientSchemeDetail>();
        }
        #endregion constructor

        #region methods
        /// <summary>
        /// Add new scheme Detail
        /// </summary>
        /// <param name="oClientSchemeDetail">oClientSchemeDetail Object filled with details</param>
        /// <returns>0 - Success, -1 - Failed</returns>
        public int Add(ClientSchemeDetail oClientSchemeDetail)
        {
            int oResult = m_CSchemeDetailsList.FindIndex(obj => obj.ClientNo == oClientSchemeDetail.ClientNo);

            if (oResult != 0)
            {
                m_CSchemeDetailsList.Add(oClientSchemeDetail);
                return 0;
            }
            else
            {
                return -1;
            }
        }
        #endregion methods

    }
}
