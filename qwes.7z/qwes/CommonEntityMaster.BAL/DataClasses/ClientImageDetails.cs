﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTIL.Match.CDD.BAL.DataClasses
{
    public class ClientImageDetails
    {
        List<ClientImageDetail> m_ClientImgDetail; 
        #region constructor
        public ClientImageDetails()
        {
            m_ClientImgDetail = new List<ClientImageDetail>();
        }
        #endregion constructor

        /// <summary>
         /// Client Image Detail List
        /// </summary>
        public List<ClientImageDetail> ClientImgDetailList
        {
            get { return m_ClientImgDetail; }
            set { m_ClientImgDetail = value; }
        }

        /// <summary>
        /// Add new Image Detail
        /// </summary>
        /// <param name="oClientImageDetail">ClientImgDetail Object filled with details</param>
        /// <returns>0 - Success, -1 - Failed</returns>
        public int Add(ClientImageDetail oClientImgDetail)
        {
            int oResult = m_ClientImgDetail.FindIndex(obj => obj.EntityDocNo == oClientImgDetail.EntityDocNo && oClientImgDetail.EntityType == "D");

            if (oResult != 0)
            {
                m_ClientImgDetail.Add(oClientImgDetail);
                return 0;
            }
            else
            {
                return -1;
            }
        }


        #region Get image by ImageType
        /// <summary>
        /// Get image by ImageType
        /// </summary>
        /// <param name="addressType">image Type Enum</param>
        /// <returns></returns>
        public ClientImageDetail GetImageByType(Client_ImageType ImageType)
        {
            return ClientImgDetailList.Find(img => img.ImageType == (int)ImageType);
        }
        #endregion Get image by ImageType

        //#region Get Photograph by Clientno and Entity type
        ///// <summary>
        ///// Get Photograph by Clientno and Entity type
        ///// </summary>
        ///// <param name="addressType">image Type Enum</param>
        ///// <returns></returns>
        //public ClientImageDetail GetClientPhotograph()
        //{
        //    return ClientImgDetailList.Find(img => img.ImageType == (int)ImageType);
        //}
        //#endregion Get Photograph by Clientno and Entity type
    }
}
