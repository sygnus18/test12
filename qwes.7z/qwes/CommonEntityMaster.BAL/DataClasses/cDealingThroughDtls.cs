﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace FTIL.Match.CDD.BAL.DataClasses
{
    public class cDealingThroughDtls
    {
        public cDealingThroughDtls()
        {
            dtDealingThroughResult = new DataTable();

            dtDealingThroughResult.Columns.Add("n_ClientDealingThroughNo", typeof(int));
            dtDealingThroughResult.Columns.Add("n_Flag", typeof(int));
            dtDealingThroughResult.Columns.Add("s_SubBrokerName", typeof(string));
            dtDealingThroughResult.Columns.Add("s_ExchangeName", typeof(string));
            dtDealingThroughResult.Columns.Add("s_ClientCode", typeof(string));
            dtDealingThroughResult.Columns.Add("s_SebiRegNo", typeof(string));
            dtDealingThroughResult.Columns.Add("n_Ammount", typeof(int));
            dtDealingThroughResult.Columns.Add("s_Remarks", typeof(string));
            dtDealingThroughResult.Columns.Add("s_HasChanged", typeof(string));
            dtDealingThroughResult.Columns.Add("d_LastModifiedDateTime", typeof(string));
                  
        }

        public int    ClientDealingThroughNo { get; set; }
        public int    Flag { get; set; }
        public string SubBrokerName { get; set; }
        public string ExchangeName { get; set; }
        public string ClientCode { get; set; }
        public string SebiRegNo { get; set; }
        public int    Ammount { get; set; }
        public string Remarks { get; set; }
        //public string AccountNo { get; set; }
       
        public bool isValid { get; set; }
        public DateTime? dLastUpdatedDate { get; set; }
        public string AccOthers { get; set; } 
       
        public DataTable dtDealingThroughResult { get; set; }

        public string FlagAccountNo { get; set; }

        /// <summary>
        /// Sync. DataTable with properties/fields
        /// </summary>
        public void SetDataResult()
        {
            DataRow[] dr;
            if (this.ClientDealingThroughNo==0)
                dr = dtDealingThroughResult.Select("n_ClientDealingThroughNo = " + ClientDealingThroughNo + "");
            else
                dr = dtDealingThroughResult.Select("n_ClientDealingThroughNo = " + ClientDealingThroughNo + "");

            if (dr.Length > 0)
            {
                string changedFlag = "N";

                if (Convert.ToInt32(dr[0]["n_ClientDealingThroughNo"]) != ClientDealingThroughNo)
                {
                    dr[0]["n_ClientDealingThroughNo"] = ClientDealingThroughNo;
                    changedFlag = "Y";
                }

                if (Convert.ToInt32(dr[0]["n_Flag"])!= Flag)
                {
                    dr[0]["n_Flag"] = Flag;
                    changedFlag = "Y";
                }

                if (dr[0]["s_SubBrokerName"].ToString() != SubBrokerName)
                {
                    dr[0]["s_SubBrokerName"] = SubBrokerName;
                    changedFlag = "Y";
                }

                if (dr[0]["s_ExchangeName"].ToString() != ExchangeName)
                {
                    dr[0]["s_ExchangeName"] = ExchangeName;
                    changedFlag = "Y";
                }

                if (dr[0]["s_ClientCode"].ToString()!= ClientCode)
                {
                    dr[0]["s_ClientCode"] = ClientCode;
                    changedFlag = "Y";
                }

                if (dr[0]["s_SebiRegNo"].ToString() != SebiRegNo)
                {
                    dr[0]["s_SebiRegNo"] = SebiRegNo;
                    changedFlag = "Y";
                }
                //if (Convert.ToInt32(dr[0]["n_Ammount"])!= Ammount)
                //{
                //    dr[0]["n_Ammount"] = AccountNo;
                //    changedFlag = "Y";
                //}
                if (dr[0]["s_Remarks"].ToString() != Remarks)
                {
                    dr[0]["s_Remarks"] = Remarks;
                    changedFlag = "Y";
                }
                dr[0]["s_HasChanged"] = changedFlag;

                if (changedFlag == "Y")
                {
                    dtDealingThroughResult.AcceptChanges();
                }
            }
            else if (ClientDealingThroughNo!=null)
                dtDealingThroughResult.Rows.Add(new object[] { ClientDealingThroughNo, Flag, SubBrokerName, ExchangeName, ClientCode, SebiRegNo, Ammount, Remarks, "Y", System.DateTime.Now}); 


        }

    }
}
