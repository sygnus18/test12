﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FTIL.Match.Common.Log;

namespace FTIL.Match.CDD.BAL.DataStore
{
    public class ClientDPDetail
    {
        public int ClientNo { get; set; }

        //for DP Details
        public string DPID { get; set; }
        public string DPCode  { get; set; }
        public string DPName { get; set; }
        public string BeneficiaryId { get; set; }
        public string DPType { get; set; }

        /// <summary>
        /// For Second Account Holder and Third Account Holder
        /// AccountType ="S" -Single ,"J"-Joint 
        /// </summary>
        public string AccountType { get; set; }
        //for Nominee Details
        public int RelatedPartyNo { get; set; }
        public int RelationshipNo { get; set; }
        public string RelatedPartyName { get; set; }
        public DateTime? RelatedPartyDOB { get; set; }
        public string GuardianName { get; set; }
        public string  MinerRelation { get; set; }
        public int IsNomineeAddsameasEntity { get; set; }
        public string Nomination { get; set; }
        
        //for related party details
        public int Occupation { get; set; }
        public string OccupationOthers { get; set; }
        public string PANNo { get; set; }
        public string AatharNo { get; set; }
        public int AccountStatement { get; set; }

        /// <summary>
        /// Initializes current instance from DataRow
        /// </summary>
        /// <param name="DataRow">DataRow object containing DP details</param>
        #region InitializeFromDataRow
        public void InitializeFromDataRow(DataRow DataRow)
        {
            try
            {
                if ((DataRow["n_ClientNo"] != null) && (DataRow["n_ClientNo"] != DBNull.Value))
                this.ClientNo = Convert.ToInt32(DataRow["n_ClientNo"]);

                //for DP Details
                this.DPID = DataRow.Table.Columns.Contains("s_DPID") ?  Convert.ToString(DataRow["s_DPID"]): null;
                this.DPName = DataRow.Table.Columns.Contains("s_DPName") ? Convert.ToString(DataRow["s_DPName"]) : null;
                this.BeneficiaryId = DataRow.Table.Columns.Contains("s_BeneficiaryId") ? Convert.ToString(DataRow["s_BeneficiaryId"]) : null;
                this.DPType = DataRow.Table.Columns.Contains("s_DPType") ? Convert.ToString(DataRow["s_DPType"]) : null;
                this.AccountType = DataRow.Table.Columns.Contains("s_AccountType") ? Convert.ToString(DataRow["s_AccountType"]) : null;
                

                //for Nominee Details
                if (DataRow.Table.Columns.Contains("n_RelatedPartyNo") && (DataRow["n_RelatedPartyNo"] != null) && (DataRow["n_RelatedPartyNo"] != DBNull.Value))
                    this.RelatedPartyNo = Convert.ToInt32(DataRow["n_RelatedPartyNo"]);
                if (DataRow.Table.Columns.Contains("n_RelationshipNo") && (DataRow["n_RelationshipNo"] != null) && (DataRow["n_RelationshipNo"] != DBNull.Value))
                    this.RelationshipNo = Convert.ToInt32(DataRow["n_RelationshipNo"]);
                if (DataRow.Table.Columns.Contains("d_DOB") && (DataRow["d_DOB"] != null) && (DataRow["d_DOB"] != DBNull.Value))
                    this.RelatedPartyDOB = Convert.ToDateTime(DataRow["d_DOB"]);
                if (DataRow.Table.Columns.Contains("n_IsNomineeAddsameasEntity") && (DataRow["n_IsNomineeAddsameasEntity"] != null) && (DataRow["n_IsNomineeAddsameasEntity"] != DBNull.Value))
                    this.IsNomineeAddsameasEntity = Convert.ToInt32(DataRow["n_IsNomineeAddsameasEntity"]);
                
                this.RelatedPartyName = DataRow.Table.Columns.Contains("s_Name") ? Convert.ToString(DataRow["s_Name"]): null;
                this.GuardianName = DataRow.Table.Columns.Contains("s_GuardianName") ?  Convert.ToString(DataRow["s_GuardianName"]): null;
                this.MinerRelation = DataRow.Table.Columns.Contains("s_MinerRelation") ? Convert.ToString(DataRow["s_MinerRelation"]): null;
                this.Nomination = DataRow.Table.Columns.Contains("s_Nomination") ? Convert.ToString(DataRow["s_Nomination"]) : null;

                if (DataRow.Table.Columns.Contains("n_Occupation") && (DataRow["n_Occupation"] != null) && (DataRow["n_Occupation"] != DBNull.Value))
                    this.Occupation = Convert.ToInt32(DataRow["n_Occupation"]);
                if (DataRow.Table.Columns.Contains("n_AccountStatement") && (DataRow["n_AccountStatement"] != null) && (DataRow["n_AccountStatement"] != DBNull.Value))
                    this.AccountStatement = Convert.ToInt32(DataRow["n_AccountStatement"]);

                this.OccupationOthers = DataRow.Table.Columns.Contains("s_OccupationOthers") ? Convert.ToString(DataRow["s_OccupationOthers"]): null ;
                this.PANNo = DataRow.Table.Columns.Contains("s_PANNo") ? Convert.ToString(DataRow["s_PANNo"]): null ;
                this.AatharNo = DataRow.Table.Columns.Contains("s_AatharNo") ? Convert.ToString(DataRow["s_AatharNo"]) : null;
                
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "InitializeFromDataRow() Error processing DataRow", ex);
                throw ex;
            }
        }
        #endregion

    }

}
