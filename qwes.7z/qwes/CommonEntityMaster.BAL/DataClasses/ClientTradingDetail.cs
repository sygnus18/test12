﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FTIL.Match.Common.Log;
using UCC.Class;

namespace FTIL.Match.CDD.BAL.DataClasses
{
    /// <summary>
    /// 
    /// </summary>
    public class ClientTradingDetail
    {
        #region public properties
        public int TradingDetailNo { get; set; }
        public int ClientNo { get; set; }
        public int IsPastAction { get; set; }
        public string PastAction { get; set; }
        public string TradingPurpose { get; set; }
        public string OthrsTradingPurpose { get; set; }
        public int TradingExpFlag { get; set; }
        public double TradingExp { get; set; }
        public int OtherExpFlag { get; set; }
        public double OtherExp { get; set; }
        public DateTime LastModifiedDateTime { get; set; }
        #endregion public properties

        #region methods
        /// <summary>
        /// Initializes current instance from DataRow
        /// </summary>
        /// <param name="DataRow">DataRow object containing client Trading details</param>
        #region InitializeFromDataRow
        public void InitializeFromDataRow(DataRow dataRow)
        {
            try
            {
                if ((dataRow["n_ClientNo"] != null) && (dataRow["n_ClientNo"] != DBNull.Value))
                    this.ClientNo = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_ClientNo"));
                if ((dataRow["n_TradingDetailNo"] != null) && (dataRow["n_TradingDetailNo"] != DBNull.Value))
                    this.TradingDetailNo = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_TradingDetailNo"));
                
                if ((dataRow["n_PastAction"] != null) && (dataRow["n_PastAction"] != DBNull.Value))
                    this.IsPastAction = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_PastAction"));
                this.PastAction = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_PastAction"));
                
                if ((dataRow["n_TradingPurpose"] != null) && (dataRow["n_TradingPurpose"] != DBNull.Value))
                    this.TradingExpFlag = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_TradingPurpose"));
                if ((dataRow["s_TradingPurpose"] != null) && (dataRow["s_TradingPurpose"] != DBNull.Value))
                    this.TradingPurpose = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_TradingPurpose"));
                
                if ((dataRow["n_TradingExpFlag"] != null) && (dataRow["n_TradingExpFlag"] != DBNull.Value))
                    this.TradingExpFlag = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_TradingExpFlag"));
                if ((dataRow["n_TradingExp"] != null) && (dataRow["n_TradingExp"] != DBNull.Value))
                    this.TradingExp = Convert.ToDouble(Utility.GetValueFromDataRow(dataRow, "n_TradingExp"));

                 if ((dataRow["n_OtherExpFlag"] != null) && (dataRow["n_OtherExpFlag"] != DBNull.Value))
                    this.OtherExpFlag = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_OtherExpFlag"));
                if ((dataRow["n_OtherExp"] != null) && (dataRow["n_OtherExp"] != DBNull.Value))
                    this.OtherExp = Convert.ToDouble(Utility.GetValueFromDataRow(dataRow, "n_OtherExp"));

                if ((dataRow["d_LastModifiedDateTime"] != null) && (dataRow["d_LastModifiedDateTime"] != DBNull.Value))
                this.LastModifiedDateTime = Convert.ToDateTime(Utility.GetValueFromDataRow(dataRow, "d_LastModifiedDateTime"));

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                throw ex;
            }
        }
        #endregion
        #endregion methods
    }
}
