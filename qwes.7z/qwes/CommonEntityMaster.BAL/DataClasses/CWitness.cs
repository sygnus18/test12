﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using UCC.Class;

namespace FTIL.Match.CDD.BAL.DataClasses
{
    /// <summary>
    /// Class for storing Address details
    /// </summary>
    public class CWitness
    {
        public int ClientNo { get; set; }
        public int WitnessNo { get; set; }
        public string FirstWitnessName { get; set; }
        public string FirstWithnessAddressLine1 { get; set; }
        public string FirstWithnessAddressLine2 { get; set; }
        public string FirstWithnessAddressLine3 { get; set; }
        public string FirstWithnessMobile { get; set; }
        public string FirstWithnessEMailId { get; set; }
        public string SecondWitnessName { get; set; }
        public string SecondWithnessAddressLine1 { get; set; }
        public string SecondWithnessAddressLine2 { get; set; }
        public string SecondWithnessAddressLine3 { get; set; }
        public string SecondWithnessMobile { get; set; }
        public string SecondWithnessEMailId { get; set; }
        public string RequiredWitness { get; set; }


        /// <summary>
        /// Set fields from DataRow
        /// </summary>
        /// <param name="row">Source DataRow</param>
        //public void SetFromDataRow(DataRow row)
        //{
        //    this.Address_Line1 = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.ADDRESSLINE1));
        //    this.Address_Line2 = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.ADDRESSLINE2));
        //    this.Address_Line3 = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.ADDRESSLINE3));
        //    this.City = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.CITY));
        //    this.Country = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.COUNTRYCODE));
        //    this.Email_ID = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.EMAILID));
        //    this.Fax_No = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.FAXNO));
        //    this.Mobile_No = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.MOBILE1));
        //    this.Mobile_NoWork = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.MOBILE2));
        //    this.Tel_Res = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.TELNO1));
        //    this.Tel_Work = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.TELNOOFFICE));
        //    this.PIN_Code = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.PINCODE));
        //    this.State_Others = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.STATEOTHER));
        //    this.StateCode = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.STATENUMBER));

        //    this.SameCorrPermAdd = Convert.ToString(Utility.GetValueFromDataRow(row, CEntityMaster.SAMECORRPERMADD));

        //}

    }
}
