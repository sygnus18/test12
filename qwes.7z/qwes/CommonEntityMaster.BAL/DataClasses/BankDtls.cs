﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace FTIL.Match.CDD.BAL.DataClasses
{
    /// <summary>
    /// Class for Storing BankDetails
    /// </summary>
  public class BankDtls
    {
        public BankDtls()
        {
            dtBankResult = new DataTable();

            dtBankResult.Columns.Add("n_ClientBankNo", typeof(int));
            dtBankResult.Columns.Add("s_BankCode", typeof(string));
            dtBankResult.Columns.Add("s_BankName", typeof(string));
            dtBankResult.Columns.Add("s_MICRCode", typeof(string));
            dtBankResult.Columns.Add("s_Branch", typeof(string));
            dtBankResult.Columns.Add("s_AccountType", typeof(string));
            dtBankResult.Columns.Add("n_AccountTypeVal", typeof(int));
            dtBankResult.Columns.Add("s_CustomerID", typeof(string));
            dtBankResult.Columns.Add("s_AccountNo", typeof(string));
            dtBankResult.Columns.Add("s_IFSCCode", typeof(string));
            dtBankResult.Columns.Add("s_NameOnCheque", typeof(string));

            dtBankResult.Columns.Add("s_Default", typeof(string));
            dtBankResult.Columns.Add("s_HasChanged", typeof(string));
            dtBankResult.Columns.Add("d_LastModifiedDateTime", typeof(string));
            dtBankResult.Columns.Add("s_Others", typeof(string));
                  
        }

        public int ClientBankNo { get; set; }
        public string BankCode { get; set; }
        public string BankName { get; set; }
        public string MICR { get; set; }
        public string Branch { get; set; }
        public string AccountType { get; set; }
        public int AccountTypeVal { get; set; }
        public string AccountNo { get; set; }
        public string CustNo { get; set; }
        public string IFSCCode { get; set; }
        public string NameOnCheque { get; set; }
        public string sDefault { get; set; }
        public bool isValid { get; set; }
        public DateTime? dLastUpdatedDate { get; set; }
        public string AccOthers { get; set; } 
       
        public DataTable dtBankResult { get; set; }

        public string FlagAccountNo { get; set; }

        /// <summary>
        /// Sync. DataTable with properties/fields
        /// </summary>
        public void SetDataResult()
        {
            DataRow[] dr;
            if (this.ClientBankNo==0)
                 dr = dtBankResult.Select("s_AccountNo = " + "'" + FlagAccountNo + "'");
            else
                dr = dtBankResult.Select("n_ClientBankNo = " + ClientBankNo + "");

            if (dr.Length > 0)
            {
                string changedFlag = "N";

                if (Convert.ToInt32(dr[0]["n_ClientBankNo"]) != ClientBankNo)
                {
                    dr[0]["n_ClientBankNo"] = ClientBankNo;
                    changedFlag = "Y";
                }

                if (dr[0]["s_BankCode"].ToString() != BankCode)
                {
                    dr[0]["s_BankCode"] = BankCode;
                    changedFlag = "Y";
                }

                if (dr[0]["s_Branch"].ToString() != Branch)
                {
                    dr[0]["s_Branch"] = Branch;
                    changedFlag = "Y";
                }

                if (dr[0]["s_AccountType"].ToString() != AccountType)
                {
                    dr[0]["s_AccountType"] = AccountType;
                    changedFlag = "Y";
                }

                if (Convert.ToInt32(dr[0]["n_AccountTypeVal"]) != AccountTypeVal)
                {
                    dr[0]["n_AccountTypeVal"] = AccountTypeVal;
                    changedFlag = "Y";
                }

                if (dr[0]["s_BankName"].ToString() != BankName)
                {
                    dr[0]["s_BankName"] = BankName;
                    changedFlag = "Y";
                }
                if (dr[0]["s_AccountNo"].ToString() != AccountNo)
                {
                    dr[0]["s_AccountNo"] = AccountNo;
                    changedFlag = "Y";
                }

                if (dr[0]["s_AccountType"].ToString() != AccountType)
                {
                    dr[0]["s_AccountType"] = AccountType;
                    changedFlag = "Y";
                }
                if (dr[0]["s_CustomerID"].ToString() != CustNo)
                {
                    dr[0]["s_CustomerID"] = CustNo;
                    changedFlag = "Y";
                }
                if (dr[0]["s_IFSCCode"].ToString() != IFSCCode)
                {
                    dr[0]["s_IFSCCode"] = IFSCCode;
                    changedFlag = "Y";
                }
                if (dr[0]["s_NameOnCheque"].ToString() != NameOnCheque)
                {
                    dr[0]["s_NameOnCheque"] = NameOnCheque;
                    changedFlag = "Y";
                }
                if (dr[0]["s_Default"].ToString() != sDefault)
                {
                    dr[0]["s_Default"] = sDefault;
                    changedFlag = "Y";
                }
                if (dr[0]["s_Others"].ToString() != AccOthers)
                {
                    dr[0]["s_Others"] = AccOthers;
                    changedFlag = "Y";
                }

                dr[0]["s_HasChanged"] = changedFlag;

                if (changedFlag == "Y")
                {
                    dtBankResult.AcceptChanges();
                }
            }
            else if (!string.IsNullOrEmpty(AccountNo))
                dtBankResult.Rows.Add(new object[] { ClientBankNo, BankCode, BankName, MICR, Branch, AccountType, AccountTypeVal, CustNo, AccountNo, IFSCCode, NameOnCheque, sDefault, "Y", System.DateTime.Now, AccOthers}); 


        }

    }
}
