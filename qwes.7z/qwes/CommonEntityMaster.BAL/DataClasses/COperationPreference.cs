﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using System.Data;
using FTIL.Match.Common.Log;
using System.Data.SqlClient;

namespace FTIL.Match.CDD.BAL.DataClasses
{
    /// <summary>
    /// Class for Storing BankDetails
    /// </summary>
  public class COperationPreference
    {
      public static readonly string GROUPNO = "GroupNo";
      public static readonly string GROUPCODE = "GroupCode";
      public static readonly string GROUPNAME = "GroupName";

      public static readonly string FAMILYNO = "FamilyNo";
      public static readonly string FAMILYCODE = "FamilyCode";
      public static readonly string FAMILYNAME = "FamilyName";

      public static readonly string PREFERENCECODE = "PreferencesID";

      public static readonly string CHARGECODE = "ChargeCode";

      public static readonly string BROKGRPCODE = "BrokGrpCode";
       
      
    
    public int GroupNo { get; set; }
    public string GroupCode { get; set; }
    public string GroupName { get; set; }   
    public int FamilyNo { get; set; }
    public string FamilyCode { get; set; }
    public string FamilyName { get; set; }


    public int PreferenceNo { get; set; }
    public int ClientNo { get; set; } 
    public string G3 { get; set; }
    public string FmlyGroupCode { get; set; }
    public string PreferenceCode { get; set; }
    public string Charge { get; set; }
    public string BrokMethod { get; set; }
    public string BrokSlab { get; set; }
    public string AllowtoBrok { get; set; }
    public string IntRate { get; set; }
    public string POA { get; set; }
    public string RunningClient { get; set; }
    public string TradeClub { get; set; }
    public string PaymentMode { get; set; }
    public string GlobalPreference { get; set; }
    public string IncludeSTinBrok { get; set; }
    public string IncludeTOInBrok { get; set; }
    public string IncludeSTTinBrok { get; set; }
    public string IncludeSDinBrok { get; set; }
    public string IncludeSEBIInBrok { get; set; }
    public string IncludeCFinBrok { get; set; }
    public string IncludeCCinBrok { get; set; }
    public string IncludeAuctionPenalInBrkg { get; set; }  
    public string ServProvider { get; set; }
    public string FlatISO { get; set; }
    public string Format { get; set; } 
    public string DownloadFor { get; set; }
    public string ContractNoGen { get; set; }
    public string StockTransfer { get; set; }
    public string ChargeDeliveryCharges { get; set; }
    public string RegionMapping { get; set; }
    public string BeforePayinFunds { get; set; }
    public string BeforePayinSecurities { get; set; }
    public string AfterPayoutFunds { get; set; }
    public string AfterPayoutSecurities { get; set; } 
    public string SettlementOn { get; set; }
    public string BillGeneration { get; set; }
    public string BillNoGen { get; set; }
    public string SettDateOnContract { get; set; }
    public string Bills { get; set; }
    public string Contracts { get; set; }
    public string ContractFormType  { get; set; }
      

       
    public DataTable dtPreferanceResult { get; set; }


        public COperationPreference()
        {
            dtPreferanceResult = new DataTable();

            dtPreferanceResult.Columns.Add("n_GroupNo", typeof(int));
            dtPreferanceResult.Columns.Add("s_GroupCode", typeof(string));
            dtPreferanceResult.Columns.Add("s_GroupName", typeof(string));

            dtPreferanceResult.Columns.Add("s_Default", typeof(string));
            dtPreferanceResult.Columns.Add("s_HasChanged", typeof(string));
            dtPreferanceResult.Columns.Add("d_LastModifiedDateTime", typeof(string));

        }

        #region GetLookupData
        /// <summary>
        /// Retrieves Lookup details for specified tab ID.
        /// </summary>

        public MethodExecResult GetLookupData(ref DataSet l_dsLookUp, ref string l_sErrorMsg)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetClientPreferencesLookUpData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            // l_objDbWorkItem.AddParameter("@pn_EntityNo", SqlDbType.Int, nClientNo);
            l_objDbWorkItem.AddParameter("@UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                    return new MethodExecResult(1, "No data found", "stp_GetClientPreferencesLookUpData Database returned no data. UserNo. " +
                        AppEnvironment.AppUser.UserNo.ToString(), null);
                else
                {
                    l_dsLookUp = l_dsReturnData;
                    // dtResult = l_dsReturnData.Tables[0];
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        }
        #endregion

        #region GetCustomization
        /// <summary>
        /// Get CDD Customization details
        /// </summary>
        /// <param name="nClientNo">ClientNo</param>
        /// <param name="dtResult">Entity Customization details DataSet</param>
        /// <returns>Method Execution result</returns>
        public MethodExecResult GetEntityPreferenceDetails(int nClientNo, ref  DataSet dsCustomResult)
        {

            dsCustomResult = new DataSet();
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_CCMUpdateClientPreferences");
            try
            {
                l_objDbWorkItem.ResultType = QueryType.DataSet;
                 

                l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, "S");
                l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.VarChar, nClientNo);
                l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);
                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
                if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                    if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_CCMMasterEntityDocDetails. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        dsCustomResult = l_dsReturnData;
                        if (l_dsReturnData.Tables[0].Rows.Count > 0)
                                BindProperties(l_dsReturnData.Tables[0]);

                        return l_objDbWorkItem.ExecutionStatus;
                    }
                }
                else
                {
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(cCustomization), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }
        }
      private void BindProperties(DataTable dt)
      {
          PreferenceNo = Convert.ToInt32(dt.Rows[0]["n_PreferenceNo"]);
          ClientNo = Convert.ToInt32(dt.Rows[0]["n_ClientNo"]);
          G3 = dt.Rows[0]["s_GroupCode"].ToString();
          FmlyGroupCode = dt.Rows[0]["s_FamilyCode"].ToString();
          FamilyName = dt.Rows[0]["s_FamilyName"].ToString();
          PreferenceCode = dt.Rows[0]["s_PreferenceCode"].ToString();
          Charge = dt.Rows[0]["s_ChargeSlab"].ToString();
          BrokMethod = dt.Rows[0]["n_BrokerageMethod"].ToString();
          BrokSlab = dt.Rows[0]["s_BrokerageScheme"].ToString();
          AllowtoBrok = dt.Rows[0]["s_AllowBrok"].ToString();
          IntRate = dt.Rows[0]["n_IntRate"].ToString();
          POA = dt.Rows[0]["s_POA"].ToString();
          RunningClient = dt.Rows[0]["s_RunningClient"].ToString();
          TradeClub = dt.Rows[0]["s_TradeClub"].ToString();
          PaymentMode = dt.Rows[0]["s_PaymentMode"].ToString();
          GlobalPreference = dt.Rows[0]["s_GlobalPreferences"].ToString();
          IncludeTOInBrok = dt.Rows[0]["s_TOInclude"].ToString();
          IncludeSTinBrok = dt.Rows[0]["s_STInclude"].ToString();
          IncludeSTTinBrok = dt.Rows[0]["s_STTInclude"].ToString();
          IncludeSDinBrok = dt.Rows[0]["s_SDInclude"].ToString();
          IncludeSEBIInBrok = dt.Rows[0]["s_SEBIInclude"].ToString();
          IncludeCFinBrok = dt.Rows[0]["s_CFInclude"].ToString();
          IncludeCCinBrok = dt.Rows[0]["s_CCInclude"].ToString();
          IncludeAuctionPenalInBrkg = dt.Rows[0]["s_AuctionPanelInclude"].ToString();
          ServProvider = dt.Rows[0]["s_ServiceProvider"].ToString();
          FlatISO = dt.Rows[0]["s_ServiceProviderSubType"].ToString();
          Format = dt.Rows[0]["s_Format"].ToString();
          DownloadFor = dt.Rows[0]["s_DownloadFor"].ToString();
          StockTransfer = dt.Rows[0]["s_StockTransfer"].ToString();
          ContractNoGen = dt.Rows[0]["s_ContractNoGeneration"].ToString();
          ContractFormType = dt.Rows[0]["s_ContractFormType"].ToString();   
          ChargeDeliveryCharges = dt.Rows[0]["s_ChargeDelivery"].ToString();
          RegionMapping = dt.Rows[0]["s_RegionMapping"].ToString(); 
            
          /*
           StockTransfer = dt.Rows[0]["s_POA"].ToString();
           BeforePayinFunds = dt.Rows[0]["s_POA"].ToString();
           BeforePayinSecurities = dt.Rows[0]["s_POA"].ToString();
           AfterPayoutFunds = dt.Rows[0]["s_POA"].ToString();
           AfterPayoutSecurities = dt.Rows[0]["s_POA"].ToString();
           SettlementOn = dt.Rows[0]["s_POA"].ToString();
           BillGeneration = dt.Rows[0]["s_POA"].ToString();
           BillNoGen = dt.Rows[0]["s_POA"].ToString();   
           SettDateOnContract = dt.Rows[0]["s_POA"].ToString();
           Bills = dt.Rows[0]["s_POA"].ToString();
           Contracts = dt.Rows[0]["s_POA"].ToString();  */ 
      }
        #endregion


       
    }
}
