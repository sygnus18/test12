﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTIL.Match.CDD.BAL.DataClasses
{
    class CDataProvider
    {
        static Dictionary<string, string> l_dictRiskCategory = new Dictionary<string, string>
        {
            {"LOW","L"},
            {"HIGH","H"}
        };
        public static string GetRiskCategory(string Category)
        {
            string RiskCode;
            l_dictRiskCategory.TryGetValue(Category, out RiskCode);
            return RiskCode;
        }
    }
    
    /// <summary>
    /// Client ImageType
    /// </summary>
    public enum Client_ImageType
    {
        Mapin_Id = 1,
        Passport = 2,
        Voter_Id = 3,
        Driving_License = 4,
        Ration_Card = 5,
        Registration_Details = 6,
        UID = 7,
        PAN = 8,
        CIN = 9,
        RBI_Reference = 10,
        SEBI_Registration = 11,
        POA_Id = 12,
        Electricity_Bill = 13,
        Pass_Book = 14,
        Salary_Slip = 15,
        Nominee_Photograph = 16,
        DP_ID = 17,
        Cancelled_Cheque = 18,
        Bank_Statement = 19,
        NetWorth_Certificate = 20,
        Bank_statement_Six_Month = 21,
        ITR = 22,
        Bank_Statement_ADD = 24,
        Voter_ID = 25,
        Driving_Licence = 26,
        Signature = 27,
        Witness_1_Photo = 28,
        Witness_1_Signature = 29,
        Witness_2_Photo = 30,
        Witness_2_Signature = 31,
        IPV_Selfie = 32,
        Nominee_Address = 33,
        Introducer_Address = 34,
        Authorizer_Address = 35

    }

    /// <summary>
    /// Related Party details
    /// </summary>
    public struct RelatedParty
    {
        public static int Second_Holder = 98;
        public static int Third_Holder = 99;
        public static int Already_Have_Demat_Accnt = 100;
        public static int Introducer = 201;
        public static int Authorizer = 202;
        public static int Third_Witness = 203;
    }

    /// <summary>
    /// yes/No Flag
    /// </summary>
    public struct Flag
    {
        public static readonly string Yes = "Y";
        public static readonly string No = "N";
    }

    /// <summary>
    /// Nominee/Guardian Indicator
    /// </summary>
    public struct Indicator
    {
        public static readonly string Nominee = "N";
        public static readonly string Guardian = "G";
        public static readonly string Otherwise = " ";
    }

    /// <summary>
    /// Marital Status
    /// </summary>
    public enum Marital_Status
    {
        S = 1,//SINGLE
        M = 2,//MARRIED
        D = 3,//DIVORCED
        W = 4,//WIDOWED
        NA = 5 //SEPERATED
    }
    

    /// <summary>
    /// Prefix/Title
    /// </summary>
    public enum Title
    {
        MR = 1,
        MRS = 2,
        MS = 3
    }

    /// <summary>
    ///  For Second Account Holder and Third Account Holder
    /// AccountType ="S" -Single ,"J"-Joint 
    /// </summary>
    public struct AccountType
    {
        public static string Single = "S";
        public static string Joint = "J";
    }
}
