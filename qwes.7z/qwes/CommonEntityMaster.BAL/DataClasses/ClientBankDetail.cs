﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FTIL.Match.Common.Log;
using UCC.Class;

namespace FTIL.Match.CDD.BAL.DataStore
{
    public class ClientBankDetail
    {
        #region Properties
        public int ClientNo { get; set; }
        public Int16 ExNo { get; set; }
        public string BankName { get; set; }
        public string BankBranchAddress { get; set; }
        public string AccountNo { get; set; }
        public int AccountType { get; set; }
        public Int32 BankRecId { get; set; }
        public string Default { get; set; }
        public string BankMICRCode { get; set; }
        public string BankBranch { get; set; }
        public string BankIFSCCode { get; set; }
        public string NameOnCheque { get; set; }
        public string BankCode { get; set; }
        public string BankCity { get; set; }
        public string BankState { get; set; }
        public string BankContactNo { get; set; }
        #endregion

        #region constructor
        public ClientBankDetail()
        {

        }
        #endregion constructor

  
        /// <summary>
        /// Initializes current instance from DataRow
        /// </summary>
        /// <param name="DataRow">DataRow object containing Bank details</param>
        #region InitializeFromDataRow
        public void InitializeFromDataRow(DataRow DataRow)
        {
            try
            {
                if ((DataRow["n_ClientNo"] != null) && (DataRow["n_ClientNo"] != DBNull.Value))
                     this.ClientNo = Convert.ToInt32(DataRow["n_ClientNo"]);
                if ((DataRow["n_ExNo"] != null) && (DataRow["n_ExNo"] != DBNull.Value))
                    this.ExNo = Convert.ToInt16(DataRow["n_ExNo"]);
                if ((DataRow["s_BankName"] != null) && (DataRow["s_BankName"] != DBNull.Value))
                    this.BankName = Convert.ToString(DataRow["s_BankName"]);
                if ((DataRow["s_AccountNo"] != null) && (DataRow["s_AccountNo"] != DBNull.Value))
                    this.AccountNo = DataRow["s_AccountNo"].ToString().Trim();
                if ((DataRow["n_AccountType"] != null) && (DataRow["n_AccountType"] != DBNull.Value))
                    this.AccountType = Convert.ToInt32(DataRow["n_AccountType"]);
                if ((DataRow["s_Default"] != null) && (DataRow["s_Default"] != DBNull.Value))
                    this.Default = DataRow["s_Default"].ToString().Trim();
                if ((DataRow["s_MICRCode"] != null) && (DataRow["s_MICRCode"] != DBNull.Value))
                    this.BankMICRCode = DataRow["s_MICRCode"].ToString().Trim();
                if ((DataRow["s_Branch"] != null) && (DataRow["s_Branch"] != DBNull.Value))
                    this.BankBranch = DataRow["s_Branch"].ToString().Trim();
                if ((DataRow["s_IFSCCode"] != null) && (DataRow["s_IFSCCode"] != DBNull.Value))
                    this.BankIFSCCode = DataRow["s_IFSCCode"].ToString().Trim();
                if ((DataRow["s_NameOnCheque"] != null) && (DataRow["s_NameOnCheque"] != DBNull.Value))
                    this.NameOnCheque = DataRow["s_NameOnCheque"].ToString().Trim();
                if ((DataRow["s_BankCode"] != null) && (DataRow["s_BankCode"] != DBNull.Value))
                    this.BankCode = DataRow["s_BankCode"].ToString().Trim();
                if (DataRow.Table.Columns.Contains("n_ContactNo") == true && (DataRow["n_ContactNo"] != null) && (DataRow["n_ContactNo"] != DBNull.Value))
                    this.BankContactNo = DataRow["n_ContactNo"].ToString().Trim();
                if (DataRow.Table.Columns.Contains("s_Address") == true && (DataRow["s_Address"] != null) && (DataRow["s_Address"] != DBNull.Value))
                    this.BankBranchAddress = DataRow["s_Address"].ToString().Trim();
                if (DataRow.Table.Columns.Contains("s_City") == true && (DataRow["s_City"] != null) && (DataRow["s_City"] != DBNull.Value))
                    this.BankCity = DataRow["s_City"].ToString().Trim();
                if (DataRow.Table.Columns.Contains("s_State") == true && (DataRow["s_State"] != null) && (DataRow["s_State"] != DBNull.Value))
                    this.BankState = DataRow["s_State"].ToString().Trim();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "InitializeFromDataRow() Error processing DataRow", ex);
                throw ex;
            }
        }
        #endregion

    }
}
