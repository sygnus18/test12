﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FTIL.Match.CDD.BAL.DataStore;

namespace FTIL.Match.CDD.BAL.DataClasses.TradingAccountOpening
{
    public class CTradingAccntOpeningBodyDtls
    {
        #region public properties
        public string RecordType { get; set; }
        public string LineNo { get; set; }
        public string BranchCode { get; set; }
        public string ReferenceNo { get; set; }
        public string BenType { get; set; }
        public string BenSubType { get; set; }
        public string BenShortName { get; set; }
        public string BenAccountCategory { get; set; }
        public string BenOccupation { get; set; }
        public string BenFirstHolderName { get; set; }
        public string Filler1 { get; set; }
        public string FirstHolderFatherOrHusbandName { get; set; }
        public string FirstHolderAdd1 { get; set; }
        public string FirstHolderAdd2 { get; set; }
        public string FirstHolderAdd3 { get; set; }
        public string FirstHolderAdd4 { get; set; }
        public string FirstHolderAddrPin { get; set; }
        public string BenHolderPhoneNo { get; set; }
        public string BenHolderFaxNo { get; set; }
        public string BenSecondHolderName { get; set; }
        public string SecondHolderFatherOrHusbandName { get; set; }
        public string BeneficiaryThirdHolderName { get; set; }
        public string ThirdHolderFatherOrHusbandName { get; set; }
        public string CorrespondingBPId { get; set; }
        public string AddressPreferenceFlag { get; set; }
        public string ClientActivationDatetime { get; set; }
        public string Filler2 { get; set; }
        public string FirstHolderFinancialDetail { get; set; }
        public string SecondHolderFinancialDetail { get; set; }
        public string ThirdHolderFinancialDetail { get; set; }
        public string NomineeOrGuardianIndicator { get; set; }
        public string NomineeOrGuardianName { get; set; }
        public string DOB { get; set; }
        public string NomineeOrGuardianAdd1 { get; set; }
        public string NomineeOrGuardianAdd2 { get; set; }
        public string NomineeOrGuardianAdd3 { get; set; }
        public string NomineeOrGuardianAdd4 { get; set; }
        public string NomineeOrGuardianAddPin { get; set; }
        public string StandingInstructionIndicator { get; set; }
        public string Filler3 { get; set; }
        public string IFSCCode { get; set; }
        public string AccountForHoldingReceipts { get; set; }
        public string BenBankAccountType { get; set; }
        public string BenBankName { get; set; }
        public string BenBankAdd1 { get; set; }
        public string BenBankAdd2 { get; set; }
        public string BenBankAdd3 { get; set; }
        public string BenBankAdd4 { get; set; }
        public string BenBankAddrPin { get; set; }
        public string BenBankMICRCode { get; set; }
        public string BenRBIRefNo { get; set; }
        public string BenRBIApprovalDate { get; set; }
        public string BenSEBIRegNo { get; set; }
        public string BenTaxDeductionStatus { get; set; }
        public string BenStatus { get; set; }
        public string BenStatusChangeReason { get; set; }
        public string Filler4 { get; set; }
        public string FirstHolderCorrAdd1 { get; set; }
        public string FirstHolderCorrAdd2 { get; set; }
        public string FirstHolderCorrAdd3 { get; set; }
        public string FirstHolderCorrAdd4 { get; set; }
        public string FirstHolderCorrAddPin { get; set; }
        public string BenCorrPhoneNo { get; set; }
        public string BenCorrFax { get; set; }
        public string NomineeMinorIndicator { get; set; }
        public string MinorNomineeDOB { get; set; }
        public string MinorNomineeGuardianName { get; set; }
        public string MinorNomineeGuardianAdd1 { get; set; }
        public string MinorNomineeGuardianAdd2 { get; set; }
        public string MinorNomineeGuardianAdd3 { get; set; }
        public string MinorNomineeGuardianAdd4 { get; set; }
        public string MinorNomineeGuardianPin { get; set; }
        public string BenBankACCNo { get; set; }
        public string FirstHolderEmail { get; set; }
        public string FirstHolderMob { get; set; }
        public string Filler5 { get; set; }
        public string Filler6 { get; set; }
        public string SMSFlagFirstHolder { get; set; }
        public string PANFlagFirstHolder { get; set; }
        public string Filler7 { get; set; }
        public string NoNominationFlagFirstHolder { get; set; }
        public string Filler8 { get; set; }
        public string SecondHolderEmail { get; set; }
        public string SecondHolderMob { get; set; }
        public string Filler9 { get; set; }
        public string Filler10 { get; set; }
        public string SMSFlagSecondHolder { get; set; }
        public string PanFlagSecondHolder { get; set; }
        public string Filler11 { get; set; }
        public string Filler12 { get; set; }
        public string ThirdHolderEmail { get; set; }
        public string ThirdHolderMob { get; set; }
        public string Filler13 { get; set; }
        public string Filler14 { get; set; }
        public string SMSFlagThirdHolder { get; set; }
        public string PanFlagThirdHolder { get; set; }
        public string Filler15 { get; set; }
        public string FirstHolderAdhaarNo { get; set; }
        public string SecondHolderAdhaarNo { get; set; }
        public string ThirdHolderAdhaarNo { get; set; }
        public string Filler16 { get; set; }
        public string ClientGroupName { get; set; }
        public string BillingCategory { get; set; }
        public string InwardDate { get; set; }
        public string Income { get; set; }
        public string LineOfBusiness { get; set; }
        public string BankingFlag { get; set; }
        public string ChargesBankACCNo { get; set; }
        public string BankAccountType { get; set; }
        public string BankName { get; set; }
        public string BankAdd1 { get; set; }
        public string BankAdd2 { get; set; }
        public string BankAdd3 { get; set; }
        public string BankAdd4 { get; set; }
        public string BankAddPin { get; set; }
        public string MICRCode { get; set; }
        public string ContactPerson1 { get; set; }
        public string ContactPerson2 { get; set; }
        public string CustomerId { get; set; }
        public string InternetTrading { get; set; }
        public string InstantClientID { get; set; }
        public string Filler17 { get; set; }
        public string RECode { get; set; }
        public string RPCode { get; set; }
        public string NAME { get; set; }
        public string NSECashSeg { get; set; }
        public string NSEFNOSeg { get; set; }
        public string NSECDSeg { get; set; }
        public string BSECASHSeg { get; set; }
        public string BSEFNOSeg { get; set; }
        public string BSECDSeg { get; set; }
        public string Filler18 { get; set; }
        public string Filler19 { get; set; }
        public string GrossAuunalIncome { get; set; }
        public string Networth { get; set; }
        public string NetworthDate { get; set; }
        public string Occupation { get; set; }
        public string NatureOfBusiness { get; set; }
        public string EmployerName { get; set; }
        public string PEP { get; set; }
        public string RPEP { get; set; }
        public string OtherInfo { get; set; }
        public string PastAction { get; set; }
        public string ActionTakenBySEBI { get; set; }
        public string DealingThroughOtherBrokers { get; set; }
        public string SubBrokerName { get; set; }
        public string SubBrokerSebiRegNo { get; set; }
        public string SubBrokerAdd { get; set; }
        public string OtherStockBrokerName { get; set; }
        public string OtherBrokerSubBrokerName { get; set; }
        public string OtherBrokerClientCODE { get; set; }
        public string ExchangeOptedAtOtherBroker { get; set; }
        public string DisputesWithOtherBroker { get; set; }
        public string ECN { get; set; }
        public string EmailForECN { get; set; }
        public string IsInternetTrading { get; set; }
        public string TradingExp { get; set; }
        public string TradingExpStock { get; set; }
        public string TradingExpDer { get; set; }
        public string IntrName { get; set; }
        public string IntrStatus { get; set; }
        public string IntrAdd { get; set; }
        public string IntrPhone { get; set; }
        public string TradingNomination { get; set; }
        public string TradingNomineeName { get; set; }
        public string TradingNomineeRelation { get; set; }
        public string TradingNomineePan { get; set; }
        public string TradingNomineeDob { get; set; }
        public string TradingNomineeAddress { get; set; }
        public string TradingNomineePhone { get; set; }
        public string TradingMinorNomineeGuardianName { get; set; }
        public string TradingMinorNomineeGuardianAdd { get; set; }
        public string TradingMinorNomineeGuardianPhoneNo { get; set; }
        public string PaymentMode { get; set; }
        public string ChequeNo { get; set; }
        public string ChequeDate { get; set; }
        public string ChequeBankName { get; set; }
        public string PlanName { get; set; }
        public string AccountNoDirectDebit { get; set; }
        public string AccountOpeningCharges { get; set; }
        public string YSLSchemeCode { get; set; }
        public string Prefix { get; set; }
        public string Gender { get; set; }
        public string MaritalStatus { get; set; }
        public string CityofBirth { get; set; }
        public string CountryOfBirth { get; set; }
        public string Status { get; set; }
        public string Filler20 { get; set; }
        public string Nationality { get; set; }
        public string IdProofSubmitted { get; set; }
        public string ValidTill { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public string AddressProofSubmitted { get; set; }
        public string Filler21 { get; set; }
        public string CountryCodeTelOff { get; set; }
        public string STDCodeTelOff { get; set; }
        public string OffPhone { get; set; }
        public string OffExt { get; set; }
        public string CountryCodeTelRes { get; set; }
        public string STDCodeTelRes { get; set; }
        public string ResPhone { get; set; }
        public string CountryCodeTelFAX { get; set; }
        public string STDCodeTelFAX { get; set; }
        public string FAX { get; set; }
        public string CountryCodeMobile { get; set; }
        public string Mobile { get; set; }
        public string PerAddCity { get; set; }
        public string PerAddState { get; set; }
        public string PerAddCountry { get; set; }
        public string CountryCodeTelPer { get; set; }
        public string STDCodeTelPer { get; set; }
        public string PerPhone { get; set; }
        public string Filler22 { get; set; }
        public string PerMob { get; set; }
        public string FATCAFirstApplicant { get; set; }
        public string ClientStatus { get; set; }
        public string RiskCategorization { get; set; }
        public string UCC { get; set; }
        public string InPersonDate { get; set; }
        public string RunningAccount { get; set; }
        #endregion public properties

        #region constructor
        public CTradingAccntOpeningBodyDtls()
        {
            RecordType = "02";
        }
        #endregion constructor

        #region methods
        public void BindObject(Client objClient)
        {
            ClientAddress objPerAddress = new ClientAddress();
            ClientAddress objCorrAddress = new ClientAddress();

            objPerAddress = objClient.oClientAddresses.GetAddressByType(Client_AddressType.Registered);//for permanat address
            objCorrAddress = objClient.oClientAddresses.GetAddressByType(Client_AddressType.Correspondence);//for Correspondant address

            int[] arrRelationShipNo = { 98, 99, 100, 0, 201, 202, 203 };

            int[] arrDPRelationNo = { 98, 99, 100 };
            //RecordType 
            //LineNo 
            //
            //EmployerName 
            BranchCode = objClient.Branch;
            ReferenceNo = objClient.KYCFormRefCode;
            BenType = CTradingDataProvider.BenType;
            BenSubType = CTradingDataProvider.BenSubType;
            BenAccountCategory = CTradingDataProvider.BenAccountCategory;
            Networth = objClient.NetWorth.ToString();
            NetworthDate = objClient.NetWorthAsOnDate == null ? null : objClient.NetWorthAsOnDate.Value.ToString("yyyyMMdd");
            Occupation = TradingData.GetOccupationType(objClient.Occupation).ToString();
            NatureOfBusiness = objClient.OccupationOthers;
            DOB = objClient.DOB == null ? null : objClient.DOB.Value.ToString("yyyyMMdd");
            FirstHolderAdhaarNo = objClient.UID;
            FirstHolderFinancialDetail = objClient.PANNo;
            PANFlagFirstHolder = Flag.Yes;
            GrossAuunalIncome = objClient.GrAnnIncRange.ToString();
            //if (objClient.StatementPeriodicity != null)
            RunningAccount = TradingData.GetRunningAccountType(objClient.StatementPeriodicity);
            switch (objClient.PEP)
            {
                case 0:
                    PEP = Flag.No;
                    RPEP = Flag.No;
                    break;
                case 1:
                    PEP = Flag.Yes;
                    RPEP = Flag.No;
                    break;
                case 2:
                    PEP = Flag.No;
                    RPEP = Flag.Yes;
                    break;
                case 3:
                    PEP = Flag.Yes;
                    RPEP = Flag.Yes;
                    break;
                default:
                    PEP = Flag.No;
                    RPEP = Flag.No;
                    break;
            }

            if (objClient.TypeofFacility == "2" || objClient.TypeofFacility == "3")
            {
                SMSFlagFirstHolder = Flag.Yes;
            }
            else
            {
                SMSFlagFirstHolder = Flag.No;
            }
            if (objClient.ClientName.Length > 16)
                BenShortName = objClient.ClientName.Substring(0, 16);
            else
                BenShortName = objClient.ClientName;
            BenOccupation = TradingData.GetOccupationType(objClient.Occupation).ToString();
            BenFirstHolderName = objClient.ClientName + " " + objClient.MiddleName + " " + objClient.LastName;

            FirstHolderFatherOrHusbandName = objClient.GuardianName;
            AddressPreferenceFlag = AddressPreference.Local; //"Y";
            if (objPerAddress != null)
            {
                AddressPreferenceFlag = AddressPreference.Local; //"Y";
                if (objPerAddress.AddressLine1.Length > 36 || objPerAddress.AddressLine2.Length > 36 || objPerAddress.AddressLine3.Length > 36)
                {

                    string strAdd = objPerAddress.AddressLine1 + objPerAddress.AddressLine2 + objPerAddress.AddressLine3;

                    string[] arrAdd = Process.spiltData(strAdd, CTradingDataProvider.AddLimitPerline);
                    if (arrAdd.Length == 3)
                    {
                        FirstHolderAdd1 = arrAdd[0];
                        FirstHolderAdd2 = arrAdd[1];
                        FirstHolderAdd3 = arrAdd[2];
                    }
                    if (arrAdd.Length == 2)
                    {
                        FirstHolderAdd1 = arrAdd[0];
                        FirstHolderAdd2 = arrAdd[1];
                    }
                    if (arrAdd.Length == 1)
                    {
                        FirstHolderAdd1 = arrAdd[0];
                    }
                }
                else
                {
                    if (objPerAddress.AddressLine1.Length > 36)
                        objPerAddress.AddressLine1 = objPerAddress.AddressLine1.Substring(0, 36);
                    FirstHolderAdd1 = Process.RemoveSpecialCharFromString(objPerAddress.AddressLine1);
                    if (objPerAddress.AddressLine2.Length > 36)
                        objPerAddress.AddressLine2 = objPerAddress.AddressLine2.Substring(0, 36);
                    FirstHolderAdd2 = Process.RemoveSpecialCharFromString(objPerAddress.AddressLine2);
                    if (objPerAddress.AddressLine3.Length > 36)
                        objPerAddress.AddressLine3 = objPerAddress.AddressLine3.Substring(0, 36);
                    FirstHolderAdd3 = Process.RemoveSpecialCharFromString(objPerAddress.AddressLine3);

                }
                if (string.IsNullOrEmpty(FirstHolderAdd2))
                {
                    FirstHolderAdd2 = Process.RemoveSpecialCharFromString(objPerAddress.City);
                }
                //if (string.IsNullOrEmpty(FirstHolderAdd3))
                //{
                //    FirstHolderAdd3 = Process.RemoveSpecialCharFromString(objPerAddress.StateName);
                //}
                //if (string.IsNullOrEmpty(FirstHolderAdd4))
                //{
                //    FirstHolderAdd4 = Process.RemoveSpecialCharFromString(objPerAddress.StateName);
                //}

                FirstHolderAddrPin = objPerAddress.PinCode;
                BenHolderPhoneNo = objPerAddress.TelNo1;
                BenHolderFaxNo = objPerAddress.FaxNo;
                FirstHolderEmail = objPerAddress.EMailId;
                FirstHolderMob = objPerAddress.Mobile1;
                PerAddCity = objPerAddress.City;
                PerAddState = objPerAddress.StateName;
                PerAddCountry = objPerAddress.CountryName;
                //CountryCodeTelPer 
                STDCodeTelPer = objPerAddress.TelNoSTDCode.ToString();
                PerPhone = objPerAddress.TelNo1.ToString();
                PerMob = objPerAddress.Mobile1.ToString();
                EmailForECN = objPerAddress.EMailId;
                CityofBirth = objPerAddress.City;
                City = objPerAddress.City;
                State = objPerAddress.StateName;
                Country = objPerAddress.CountryName;
                Mobile = objPerAddress.Mobile1;

                if (objPerAddress.SameCorrPermAdd == "Y")
                {
                    if (objPerAddress.AddressLine1.Length > 36 || objPerAddress.AddressLine2.Length > 36 || objPerAddress.AddressLine3.Length > 36)
                    {

                        string strAdd = objPerAddress.AddressLine1 + objPerAddress.AddressLine2 + objPerAddress.AddressLine3;

                        string[] arrAdd = Process.spiltData(strAdd, CTradingDataProvider.AddLimitPerline);
                        if (arrAdd.Length == 3)
                        {
                            FirstHolderCorrAdd1 = arrAdd[0];
                            FirstHolderCorrAdd2 = arrAdd[1];
                            FirstHolderCorrAdd3 = arrAdd[2];
                        }
                        if (arrAdd.Length == 2)
                        {
                            FirstHolderCorrAdd1 = arrAdd[0];
                            FirstHolderCorrAdd2 = arrAdd[1];
                        }
                        if (arrAdd.Length == 1)
                        {
                            FirstHolderCorrAdd1 = arrAdd[0];
                        }
                    }
                    else
                    {
                        if (objPerAddress.AddressLine1.Length > 36)
                            objPerAddress.AddressLine1 = objPerAddress.AddressLine1.Substring(0, 36);
                        FirstHolderCorrAdd1 = Process.RemoveSpecialCharFromString(objPerAddress.AddressLine1);
                        if (objPerAddress.AddressLine2.Length > 36)
                            objPerAddress.AddressLine2 = objPerAddress.AddressLine2.Substring(0, 36);
                        FirstHolderCorrAdd2 = Process.RemoveSpecialCharFromString(objPerAddress.AddressLine2);
                        if (objPerAddress.AddressLine3.Length > 36)
                            objPerAddress.AddressLine3 = objPerAddress.AddressLine3.Substring(0, 36);
                        FirstHolderCorrAdd3 = Process.RemoveSpecialCharFromString(objPerAddress.AddressLine3);
                    }
                    if (string.IsNullOrEmpty(FirstHolderCorrAdd2))
                    {
                        FirstHolderCorrAdd2 = Process.RemoveSpecialCharFromString(objPerAddress.City);
                    }
                    //if (string.IsNullOrEmpty(FirstHolderCorrAdd3))
                    //{
                    //    FirstHolderCorrAdd3 = Process.RemoveSpecialCharFromString(objPerAddress.City);
                    //}
                    //if (string.IsNullOrEmpty(FirstHolderCorrAdd4))
                    //{
                    //    FirstHolderCorrAdd4 = Process.RemoveSpecialCharFromString(objPerAddress.StateName);
                    //}
                    FirstHolderCorrAddPin = objPerAddress.PinCode;
                    BenCorrPhoneNo = objPerAddress.TelNo1;
                    BenCorrFax = objPerAddress.FaxNo;
                }
            }
            if (objCorrAddress != null)
            {
                AddressPreferenceFlag = AddressPreference.ForeignOrCorrespondence; //"N";
                if (objCorrAddress.AddressLine1.Length > 36 || objCorrAddress.AddressLine2.Length > 36 || objCorrAddress.AddressLine3.Length > 36)
                {

                    string strAdd = objCorrAddress.AddressLine1 + objCorrAddress.AddressLine2 + objCorrAddress.AddressLine3;

                    string[] arrAdd = Process.spiltData(strAdd, CTradingDataProvider.AddLimitPerline);
                    if (arrAdd.Length == 3)
                    {
                        FirstHolderCorrAdd1 = arrAdd[0];
                        FirstHolderCorrAdd2 = arrAdd[1];
                        FirstHolderCorrAdd3 = arrAdd[2];
                    }
                    if (arrAdd.Length == 2)
                    {
                        FirstHolderCorrAdd1 = arrAdd[0];
                        FirstHolderCorrAdd2 = arrAdd[1];
                    }
                    if (arrAdd.Length == 1)
                    {
                        FirstHolderCorrAdd1 = arrAdd[0];
                    }
                }
                else
                {
                    if (objCorrAddress.AddressLine1.Length > 36)
                        objCorrAddress.AddressLine1 = objCorrAddress.AddressLine1.Substring(0, 36);
                    FirstHolderCorrAdd1 = Process.RemoveSpecialCharFromString(objCorrAddress.AddressLine1);
                    if (objCorrAddress.AddressLine2.Length > 36)
                        objCorrAddress.AddressLine2 = objCorrAddress.AddressLine2.Substring(0, 36);
                    FirstHolderCorrAdd2 = Process.RemoveSpecialCharFromString(objCorrAddress.AddressLine2);
                    if (objCorrAddress.AddressLine3.Length > 36)
                        objCorrAddress.AddressLine3 = objCorrAddress.AddressLine3.Substring(0, 36);
                    FirstHolderCorrAdd3 = Process.RemoveSpecialCharFromString(objCorrAddress.AddressLine3);
                }
                if (string.IsNullOrEmpty(FirstHolderCorrAdd2))
                {
                    FirstHolderCorrAdd2 = Process.RemoveSpecialCharFromString(objCorrAddress.City);
                }
                //if (string.IsNullOrEmpty(FirstHolderCorrAdd3))
                //{
                //    FirstHolderCorrAdd3 = Process.RemoveSpecialCharFromString(objCorrAddress.StateName);
                //}
                //if (string.IsNullOrEmpty(FirstHolderCorrAdd4))
                //{
                //    FirstHolderCorrAdd4 = Process.RemoveSpecialCharFromString(objCorrAddress.StateName);
                //}
                FirstHolderCorrAddPin = objCorrAddress.PinCode;
                BenCorrPhoneNo = objCorrAddress.TelNo1;
                BenCorrFax = objCorrAddress.FaxNo;
                //CorrespondingBPId 
            }
            if (objClient.oClientBankDetails.ClientBankDetailList.Count > 0)
            {
                ClientBankDetail objClientBankDetail = objClient.oClientBankDetails.ClientBankDetailList[0];
                BankingFlag = "Y";
                BenBankACCNo = objClientBankDetail.AccountNo;
                IFSCCode = objClientBankDetail.BankIFSCCode;
                BenBankAccountType = objClientBankDetail.AccountType.ToString();
                BenBankName = objClientBankDetail.BankName;
                BenBankMICRCode = objClientBankDetail.BankMICRCode;

                ChargesBankACCNo = objClientBankDetail.AccountNo;
                BankAccountType = objClientBankDetail.AccountType.ToString();
                BankName = objClientBankDetail.BankName;
                MICRCode = objClientBankDetail.BankMICRCode;
                if (objClientBankDetail.BankBranchAddress != null)
                {
                    if (objClientBankDetail.BankBranchAddress.Length >= 144)
                    {
                        BenBankAdd1 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(0, 36));
                        BenBankAdd2 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(37, 36));
                        BenBankAdd3 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(73, 36));
                        BenBankAdd4 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(109, 36));

                        BankAdd1 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(0, 36));
                        BankAdd2 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(37, 36));
                        BankAdd3 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(73, 36));
                        BankAdd4 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(109, 36));
                    }
                    else if (objClientBankDetail.BankBranchAddress.Length < 144 && objClientBankDetail.BankBranchAddress.Length > 108)
                    {
                        BenBankAdd1 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(0, 36));
                        BenBankAdd2 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(37, 36));
                        BenBankAdd3 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(73, 36));
                        BenBankAdd4 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(109));

                        BankAdd1 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(0, 36));
                        BankAdd2 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(37, 36));
                        BankAdd3 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(73, 36));
                        BankAdd4 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(109));
                    }
                    else if (objClientBankDetail.BankBranchAddress.Length < 108 && objClientBankDetail.BankBranchAddress.Length > 72)
                    {
                        BenBankAdd1 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(0, 36)); //objClientBankDetail.BankBranchAddress.Substring(0, 36);
                        BenBankAdd2 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(37, 36));
                        BenBankAdd3 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(73));
                        BenBankAdd4 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankCity);

                        BankAdd1 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(0, 36));
                        BankAdd2 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(37, 36));
                        BankAdd3 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(73));
                        BankAdd4 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankCity);
                    }
                    else if (objClientBankDetail.BankBranchAddress.Length < 72 && objClientBankDetail.BankBranchAddress.Length > 36)
                    {
                        BenBankAdd1 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(0, 36)); //objClientBankDetail.BankBranchAddress.Substring(0, 36);
                        BenBankAdd2 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(37));
                        BenBankAdd3 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankCity);
                        BenBankAdd4 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankState);

                        BankAdd1 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(0, 36));
                        BankAdd2 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(37));
                        BankAdd3 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankCity);
                        BankAdd4 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankState);
                    }
                    else if (objClientBankDetail.BankBranchAddress.Length < 36 && objClientBankDetail.BankBranchAddress.Length > 0)
                    {
                        BenBankAdd1 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress);
                        BenBankAdd2 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankCity);
                        BenBankAdd3 = Process.RemoveSpecialCharFromString(".");
                        BenBankAdd4 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankState);

                        BankAdd1 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress);
                        BankAdd2 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankCity);
                        BankAdd3 = Process.RemoveSpecialCharFromString(".");
                        BankAdd4 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankState);
                    }
                }
                //else
                //{
                //    BenBankAdd1 = ".";
                //    BenBankAdd2 = ".";
                //    BenBankAdd3 = ".";
                //    BenBankAdd4 = ".";

                //    BankAdd1 = ".";
                //    BankAdd2 = ".";
                //    BankAdd3 = ".";
                //    BankAdd4 = ".";
                //}

                //BenBankAddrPin = ".";
                //BankAddPin = ".";
            }
            //BenRBIRefNo 
            //BenRBIApprovalDate 
            //BenSEBIRegNo 
            //BenTaxDeductionStatus 

            Prefix = objClient.ClientTitle.TrimEnd('.');
            Gender = objClient.Gender;
            //MaritalStatus = objClient.MaritalStatus;
            //if (objClient.MaritalStatus.Contains(Marital_Status))

            switch (objClient.MaritalStatus.ToUpper())
            {
                case "D":
                    MaritalStatus = ((int)Marital_Status.D).ToString();
                    break;
                case "M":
                    MaritalStatus = ((int)Marital_Status.M).ToString();
                    break;
                case "S":
                    MaritalStatus = ((int)Marital_Status.S).ToString();
                    break;
                case "NA":
                    MaritalStatus = ((int)Marital_Status.NA).ToString();
                    break;
                case "W":
                    MaritalStatus = ((int)Marital_Status.W).ToString();
                    break;
                default:
                    MaritalStatus = "0";
                    break;
            }

            //CountryOfBirth 
            Status = CTradingDataProvider.DefaultStatus;
            if (objClient.Nationality == 1)
                Nationality = CTradingDataProvider.Nationality;
            else
            {
                if (objClient.NationalityOther.Length > 50)
                    objClient.NationalityOther = objClient.NationalityOther.Substring(0, 50);
                Nationality = objClient.NationalityOther;
            }


            NoNominationFlagFirstHolder = Flag.Yes; //"Y";
            NomineeOrGuardianIndicator = Indicator.Otherwise;
            TradingNomination = Flag.No;// "N";

            if (objClient.oClientDPDetails.ClientDPDetailList.Count > 0)
            {
                foreach (ClientDPDetail objClientDPDetail in objClient.oClientDPDetails.ClientDPDetailList)
                {
                    if (!arrRelationShipNo.Contains(objClientDPDetail.RelationshipNo))
                    {
                        ClientAddress objRelatedPartyAddress = new ClientAddress();
                        objRelatedPartyAddress = objClient.oNomineeAddresses.GetAddressByType(Client_AddressType.RelatedParty);//for Related Party address

                        objRelatedPartyAddress = objClient.oNomineeAddresses.GetAddressByClientNo(objClientDPDetail.RelatedPartyNo, Client_AddressType.RelatedParty);
                        TradingNomination = Flag.Yes;// "Y";
                        NomineeOrGuardianIndicator = Indicator.Nominee;
                        NomineeOrGuardianName = objClientDPDetail.RelatedPartyName;
                        NoNominationFlagFirstHolder = Flag.No; // "N";
                        if (objRelatedPartyAddress != null)
                        {
                            if (objCorrAddress.AddressLine1.Length > 36 || objCorrAddress.AddressLine2.Length > 36 || objCorrAddress.AddressLine3.Length > 36)
                            {

                                string strAdd = objCorrAddress.AddressLine1 + objCorrAddress.AddressLine2 + objCorrAddress.AddressLine3;

                                string[] arrAdd = Process.spiltData(strAdd, CTradingDataProvider.AddLimitPerline);
                                if (arrAdd.Length == 3)
                                {
                                    NomineeOrGuardianAdd1 = arrAdd[0];
                                    NomineeOrGuardianAdd2 = arrAdd[1];
                                    NomineeOrGuardianAdd3 = arrAdd[2];
                                }
                                if (arrAdd.Length == 2)
                                {
                                    NomineeOrGuardianAdd1 = arrAdd[0];
                                    NomineeOrGuardianAdd2 = arrAdd[1];
                                }
                                if (arrAdd.Length == 1)
                                {
                                    NomineeOrGuardianAdd1 = arrAdd[0];
                                }
                            }
                            else
                            {
                                if (objRelatedPartyAddress.AddressLine1.Length > 36)
                                    objRelatedPartyAddress.AddressLine1 = objRelatedPartyAddress.AddressLine1.Substring(0, 36);
                                NomineeOrGuardianAdd1 = Process.RemoveSpecialCharFromString(objRelatedPartyAddress.AddressLine1);
                                if (objRelatedPartyAddress.AddressLine2.Length > 36)
                                    objRelatedPartyAddress.AddressLine2 = objRelatedPartyAddress.AddressLine2.Substring(0, 36);
                                NomineeOrGuardianAdd2 = Process.RemoveSpecialCharFromString(objRelatedPartyAddress.AddressLine2);
                                if (objRelatedPartyAddress.AddressLine3.Length > 36)
                                    objRelatedPartyAddress.AddressLine3 = objRelatedPartyAddress.AddressLine3.Substring(0, 36);
                                NomineeOrGuardianAdd3 = Process.RemoveSpecialCharFromString(objRelatedPartyAddress.AddressLine3);
                            }
                            if (string.IsNullOrEmpty(NomineeOrGuardianAdd2))
                            {
                                NomineeOrGuardianAdd2 = Process.RemoveSpecialCharFromString(objRelatedPartyAddress.City);
                            }
                            //NomineeOrGuardianAdd4 = Process.RemoveSpecialCharFromString(objRelatedPartyAddress.City);
                            NomineeOrGuardianAddPin = objRelatedPartyAddress.PinCode;
                        }
                    }
                    else if (arrRelationShipNo.Contains(objClientDPDetail.RelationshipNo))
                    {
                        //if (arrDPRelationNo.Contains(objClientDPDetail.RelationshipNo))
                        //{
                        //    switch(objClientDPDetail.RelationshipNo)
                        //    {
                        //        case 98:
                        //            RunningAccount = TradingData.GetRunningAccountType(objClientDPDetail.AccountStatement);
                        //            break;
                        //        case 99:
                        //            RunningAccount = TradingData.GetRunningAccountType(objClientDPDetail.AccountStatement);
                        //            break;
                        //        case 100:
                        //            RunningAccount = TradingData.GetRunningAccountType(objClientDPDetail.AccountStatement);
                        //            break;
                        //    }
                        //}
                        
                        if (objClientDPDetail.RelationshipNo == RelatedParty.Second_Holder)
                        {
                            BenSecondHolderName = objClientDPDetail.RelatedPartyName;
                            SecondHolderAdhaarNo = objClientDPDetail.AatharNo;
                            SecondHolderFinancialDetail = objClientDPDetail.PANNo;
                            PanFlagSecondHolder = Flag.Yes; // "Y";
                            SMSFlagSecondHolder = Flag.No; // "N";

                        }
                        else if (objClientDPDetail.RelationshipNo == RelatedParty.Third_Holder)
                        {
                            BeneficiaryThirdHolderName = objClientDPDetail.RelatedPartyName;
                            ThirdHolderAdhaarNo = objClientDPDetail.AatharNo;
                            ThirdHolderFinancialDetail = objClientDPDetail.PANNo;
                            SMSFlagThirdHolder = Flag.Yes; // "Y";
                            PanFlagThirdHolder = Flag.No; //  "N";
                        }
                        else if (objClientDPDetail.RelationshipNo == RelatedParty.Introducer)
                        {
                            ClientAddress objRelatedPartyAddress = new ClientAddress();
                            objRelatedPartyAddress = objClient.oNomineeAddresses.GetAddressByClientNo(objClientDPDetail.RelatedPartyNo, Client_AddressType.Others);

                            IntrName = objClientDPDetail.RelatedPartyName;
                            if (objRelatedPartyAddress != null)
                            {
                                if (objRelatedPartyAddress.AddressLine1.Length > 34)
                                    objRelatedPartyAddress.AddressLine1 = objRelatedPartyAddress.AddressLine1.Substring(0, 34);
                                IntrAdd = Process.RemoveSpecialCharFromString(objRelatedPartyAddress.AddressLine1);
                                IntrPhone = objRelatedPartyAddress.TelNo1;
                            }
                            //IntrStatus = objClientDPDetail.;
                        }

                    }

                }

            }

            if (objClient.oClientDealingThroughDetails.DealingThroughDetailList.Count > 0)
            {
                ClientDealingThroughDetail objClientDealingThroughDetail = objClient.oClientDealingThroughDetails.DealingThroughDetailList[0];

                DealingThroughOtherBrokers = objClientDealingThroughDetail.Flag == 1 ? Flag.Yes : Flag.No;
                if (objClientDealingThroughDetail.SubBrokerName.Length > 10)
                    SubBrokerName = objClientDealingThroughDetail.SubBrokerName = objClientDealingThroughDetail.SubBrokerName.Substring(0, 10);
                if (objClientDealingThroughDetail.SebiRegNo.Length > 10)
                    SubBrokerSebiRegNo = objClientDealingThroughDetail.SebiRegNo = objClientDealingThroughDetail.SebiRegNo.Substring(0, 10);
                //SubBrokerAdd 
                //OtherStockBrokerName 
                //OtherBrokerSubBrokerName 
                //OtherBrokerClientCODE 
                //ExchangeOptedAtOtherBroker 
                //DisputesWithOtherBroker 
            }

            if (objClient.oClientTradingDetails.TradingDetailList.Count > 0)
            {

                ClientTradingDetail oClientTradingDetail = objClient.oClientTradingDetails.TradingDetailList[0];
                TradingExp = oClientTradingDetail.TradingExp > 0 ? Flag.Yes : Flag.No;
                PastAction = oClientTradingDetail.IsPastAction == 1 ? Flag.Yes : Flag.No;
                if (PastAction == Flag.Yes)
                    ActionTakenBySEBI = oClientTradingDetail.PastAction;
                //TradingExpStock 
                //TradingExpDer 
                //TradingNomineeName 
                //TradingNomineeRelation 
                //TradingNomineePan 
                //TradingNomineeDob 
                //TradingNomineeAddress 
                //TradingNomineePhone 
                //TradingMinorNomineeGuardianName 
                //TradingMinorNomineeGuardianAdd 
                //TradingMinorNomineeGuardianPhoneNo 
            }
            if (objClient.oClientFatcaDetails.FatcaDetailList.Count > 0)
            {
                ClientFatcaDetail oClientFatcaDetail = objClient.oClientFatcaDetails.FatcaDetailList[0];
                FATCAFirstApplicant = (oClientFatcaDetail.USCitizen == 2 && oClientFatcaDetail.OtherCitizen == 2) ? Flag.No : Flag.Yes; // "N" : "Y";
            }
            StandingInstructionIndicator = CTradingDataProvider.StandingInstruction;
            BenStatus = CTradingDataProvider.BeneficiaryStatus;
            RECode = CTradingDataProvider.RECode;//objClient.UserName;
            //RPCode = objClient.ClientNo.ToString();

            if (objClient.oClientSchemeDetails.SchemeDetailsList.Count > 0)
            {
                ClientSchemeDetail oClientSchemeDetail = objClient.oClientSchemeDetails.SchemeDetailsList[0];
                NSECashSeg = oClientSchemeDetail.NSECM == 1 ? Flag.Yes : Flag.No;
                NSEFNOSeg = oClientSchemeDetail.NSEFO == 1 ? Flag.Yes : Flag.No;
                NSECDSeg = oClientSchemeDetail.NSE_SX == 1 ? Flag.Yes : Flag.No;
                BSECASHSeg = oClientSchemeDetail.BSECM == 1 ? Flag.Yes : Flag.No;
                BSEFNOSeg = oClientSchemeDetail.BSEFO == 1 ? Flag.Yes : Flag.No;
                BSECDSeg = oClientSchemeDetail.BSE_SX == 1 ? Flag.Yes : Flag.No;
            }

            NomineeMinorIndicator = Flag.No;
            YSLSchemeCode = CTradingDataProvider.DefaultYSLSchemeCode;
            ClientGroupName = CTradingDataProvider.ClientGroupName;
            BillingCategory = CTradingDataProvider.BillingCategory;
            ECN = CTradingDataProvider.ECN;//"Y";
            IsInternetTrading = CTradingDataProvider.IsInternetTrading; //"Y";
            ClientStatus = CTradingDataProvider.ClientStatus; //"1";
            RiskCategorization = CDataProvider.GetRiskCategory(objClient.ClientRiskCategory);
            InwardDate = DateTime.Now.Date.ToString("yyyyMMdd");
            InternetTrading = CTradingDataProvider.IsInternetTrading; //"Y";
            InPersonDate = DateTime.Now.Date.ToString("yyyyMMdd");
            CustomerId = objClient.CustId;
            UCC = objClient.UCCCode;
            InstantClientID = objClient.BOID;
            Income = objClient.GrAnnIncRange.ToString();

            if (objClient.oClientProofDetails.ProofDetailsList.Count > 0)
            {
                foreach (ClientProofDetail objClientProofDetail in objClient.oClientProofDetails.ProofDetailsList)
                {
                    if (objClientProofDetail.ReferenceSubType == CKYCProof.PROOFADD.ToString())
                    {
                        AddressProofSubmitted = TradingData.GetPerProofOfAdd(objClientProofDetail.ProofType);
                    }
                }
            }

            //NAME 
            //BenStatusChangeReason 
            //SecondHolderFatherOrHusbandName 
            //SecondHolderEmail 
            //SecondHolderMob 
            //ThirdHolderFatherOrHusbandName 
            //ThirdHolderEmail 
            //ThirdHolderMob 
            //IFSCCode 
            //AccountForHoldingReceipts 
            //NomineeMinorIndicator 
            //MinorNomineeDOB 
            //MinorNomineeGuardianName 
            //MinorNomineeGuardianAdd1 
            //MinorNomineeGuardianAdd2 
            //MinorNomineeGuardianAdd3 
            //MinorNomineeGuardianAdd4 
            //MinorNomineeGuardianPin 


            //LineOfBusiness 
            //ContactPerson1 
            //ContactPerson2 

            //OtherInfo 
            //PaymentMode 
            //ChequeNo 
            //ChequeDate 
            //ChequeBankName 
            //PlanName 
            //AccountNoDirectDebit 
            //AccountOpeningCharges 

            //IdProofSubmitted 
            //ValidTill 
            //CountryCodeTelOff 
            //STDCodeTelOff 
            //OffPhone 
            //OffExt 
            //CountryCodeTelRes 
            //STDCodeTelRes 
            //ResPhone 
            //CountryCodeTelFAX 
            //STDCodeTelFAX 
            //FAX 
            //CountryCodeMobile 
            //ClientActivationDatetime 

            //Filler1 
            //Filler2 
            //Filler3 
            //Filler4 
            //Filler5 
            //Filler6 
            //Filler7 
            //Filler8 
            //Filler9 
            //Filler10 
            //Filler11 
            //Filler12 
            //Filler13 
            //Filler14 
            //Filler15 
            //Filler16 
            //Filler17 
            //Filler18 
            //Filler19 
            //Filler20 
            //Filler21 
            //Filler22 
        }
        #endregion methods
    }
}
