﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTIL.Match.CDD.BAL.DataClasses.TradingAccountOpening
{
    class CTradingAccntOpeningHeaderDetails
    {
        #region Public properties

        public int RecordType { get; set; }

        public string DPId { get; set; }

        public string FullOrIncrementalFlag { get; set; }

        public string IncrementalReferenceDateTime { get; set; }

        public string StatementPreparationDate { get; set; }

        public string StatementPreparationTime { get; set; }

        public int TotalNoOfDetailRecords { get; set; }

        public string BatchNo { get; set; }

        public string Filler { get; set; }

        #endregion Public properties

        #region Constructor
        public CTradingAccntOpeningHeaderDetails()
        {
            RecordType = 1;
            DPId = "IN303270";//for yes bank - temp
        }
        #endregion Constructor
    }
}
