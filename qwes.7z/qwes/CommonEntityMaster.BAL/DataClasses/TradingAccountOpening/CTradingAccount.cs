﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using FTIL.Match.CDD.BAL.DataClasses.CKYC;
using FTIL.Match.CDD.BAL.DataStore;
using FTIL.Match.Common.Log;

namespace FTIL.Match.CDD.BAL.DataClasses.TradingAccountOpening
{
    public class CTradingAccount
    {
        #region class variables
        public StringBuilder sbClientUploadDetails;
        public static readonly string SEPARATOR = "|";
        public static readonly string DATEFORMAT = "yyyyMMdd";
        public static readonly string DATETIMEFORMAT = "ddMMyyyyHHmmss";
        public static readonly string TIMEFORMAT = "HHmmss";
        public static string BaseDirectory = AppDomain.CurrentDomain.BaseDirectory.ToString();
        public static string TradingAccountPath = BaseDirectory + System.Configuration.ConfigurationManager.AppSettings["TradingAccountOpeningFilesPath"];
        public static string TradingAccountDownloadPath = System.Configuration.ConfigurationManager.AppSettings["TradingAccountOpeningFilesPath"];
        public static readonly string FILEEXTENSION = ".txt";
        public static string sdate;
        string BatchNo = "0000";
        string sPath = string.Empty;
        string sDownloadPath = string.Empty;
        #endregion class variables

        #region public properties
        public string sDateOfCreation { get; set; }
        public string UserID { get; set; }
        public int LineNo { get; set; }
        #endregion public properties

        #region constructor
        public CTradingAccount(string sUserID)
        {
            sbClientUploadDetails = new StringBuilder();
            UserID = sUserID;
            LineNo = 0;
        }
        #endregion constructor

        #region Methods

        #region Trading Account Opening file Header Details
        /// <summary>
        /// Add header details.
        /// </summary>
        /// <returns>header string</returns>
        public string HeaderDetails(int nTotalClients)
        {
            StringBuilder sbHeader = new StringBuilder();
            DateTime dCurrentDate = DateTime.Now;

            try
            {
                CTradingAccntOpeningHeaderDetails objHeaderDetails = new CTradingAccntOpeningHeaderDetails();
                //objHeaderDetails.RecordType
                objHeaderDetails.DPId = Process.GetFixLenString(objHeaderDetails.DPId, 8);
                objHeaderDetails.FullOrIncrementalFlag = "F";
                if (objHeaderDetails.FullOrIncrementalFlag != "F")
                    objHeaderDetails.IncrementalReferenceDateTime = dCurrentDate.ToString(DATETIMEFORMAT);

                objHeaderDetails.IncrementalReferenceDateTime = Process.GetFixLenString(objHeaderDetails.IncrementalReferenceDateTime, 14);
                objHeaderDetails.StatementPreparationDate = dCurrentDate.ToString(DATEFORMAT);
                objHeaderDetails.StatementPreparationTime = dCurrentDate.ToString(TIMEFORMAT);
                objHeaderDetails.TotalNoOfDetailRecords = nTotalClients;
                objHeaderDetails.BatchNo = BatchNo.ToString().PadLeft(4, '0');

                sbHeader.Append(Process.GetFixLenString(objHeaderDetails.RecordType.ToString(),2,'0'));//1.RecordType  
                sbHeader.Append(Process.GetFixLenString(objHeaderDetails.DPId,8));//2.DPId 
                sbHeader.Append(Process.GetFixLenString(objHeaderDetails.FullOrIncrementalFlag.ToString(),1));//3.FullOrIncrementalFlag 
                sbHeader.Append(Process.GetFixLenString(objHeaderDetails.IncrementalReferenceDateTime.ToString(),14));//4.IncrementalReferenceDate
                sbHeader.Append(Process.GetFixLenString(objHeaderDetails.StatementPreparationDate.ToString(),8));//5.StatementPreparationDate
                sbHeader.Append(Process.GetFixLenString(objHeaderDetails.StatementPreparationTime.ToString(),6));//6.StatementPreparationTime
                sbHeader.Append(Process.GetFixLenString(objHeaderDetails.TotalNoOfDetailRecords.ToString(), 7, '0'));//7.TotalRecords 
                sbHeader.Append(Process.GetFixLenString(objHeaderDetails.BatchNo.ToString(),10,'0'));//8.BatchNumber 
                sbHeader.Append(Process.GetFixLenString(objHeaderDetails.Filler,2));//9.Filler 
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "HeaderDetails() Error while Adding Trading Account Opening file header details. ", ex);
                throw ex;
            }
            return sbHeader.ToString();
        }
        #endregion Trading Account Opening file Header Details

        #region Trading Account Opening file Body Details
        /// <summary>
        /// Add Trading Account Opening file Body Details.
        /// </summary>
        /// <param name="objClients"></param>
        /// <returns></returns>
        public string BodyDetails(Clients objClients)
        {
            StringBuilder sbBodyDetails = new StringBuilder();
            try
            {
                foreach (Client oClient in objClients.objClients)
                {
                    oClient.LineNo = ++LineNo;
                    sbBodyDetails.Append(DetailRecord(oClient));
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "BodyDetails() Error while adding Trading account opening file Body Details.", ex);
                throw ex;
            }
            //return sbBodyDetails;
            return string.Empty;
        }
        #endregion DP Account Opening file Body Details

        #region Generate Trading Account opening file
        public string GenerateTradingAccountOpeningFile(Clients objClients, CKYCReferenceData objCKYCReferenceData)
        {
            string strHeaderData = string.Empty;
            int TotalClients = objClients.objClients.Count();
            StringBuilder sbTradingAccountOpeningDetails = new StringBuilder();
            DateTime dCurrentDate = DateTime.Now;
            

            if (objCKYCReferenceData.BatchNo != null && objCKYCReferenceData.BatchNo != "0")
                BatchNo = objCKYCReferenceData.BatchNo;
            else
            {
                BatchNo = Process.GetFixLenString(objClients.BatchNo.ToString(), 4, '0');
                objCKYCReferenceData.BatchNo = Process.GetFixLenString(objClients.BatchNo.ToString(), 4, '0');
            }

            //BatchNo = objCKYCReferenceData.BatchNo;

            //create Folder if not exists
            FileInfo fileinfo = new FileInfo(TradingAccountPath);
            if (!fileinfo.Exists)
                Directory.CreateDirectory(fileinfo.Directory.FullName);

            sPath = TradingAccountPath + dCurrentDate.ToString(DATEFORMAT)+"_Trading" + FILEEXTENSION;
            sDownloadPath = TradingAccountDownloadPath + dCurrentDate.ToString(DATEFORMAT)+"_Trading" + FILEEXTENSION;
            objCKYCReferenceData.FileName = dCurrentDate.ToString(DATEFORMAT) + "_Trading" + FILEEXTENSION;
            //Delete existing file if exists
            if (File.Exists(sPath))
            {
                File.Delete(sPath);
            }

            //Write data in to file. 
            using (StreamWriter swTradingAccountFileNew = File.CreateText(sPath))
            {
                strHeaderData = HeaderDetails(TotalClients);
                swTradingAccountFileNew.WriteLine(strHeaderData);

                foreach (Client oClient in objClients.objClients)
                {
                    StringBuilder sbBodyDetails = new StringBuilder();
                    oClient.LineNo = ++LineNo;
                    sbBodyDetails.Append(DetailRecord(oClient));
                    swTradingAccountFileNew.WriteLine(sbBodyDetails.ToString());
                }

            }
            return sDownloadPath;
        }
        #endregion Generate Trading Account opening file

        #region Detail Record per Trading Account
        /// <summary>
        /// Detail Record per Trading Account
        /// </summary>
        /// <returns></returns>
        public string DetailRecord(Client objClient)
        {
            CTradingAccntOpeningBodyDtls objTradingAccntBodyDtls = new CTradingAccntOpeningBodyDtls();
            StringBuilder sbFileBodyDetails = new StringBuilder();
            objTradingAccntBodyDtls.BindObject(objClient);
            objTradingAccntBodyDtls.LineNo = objClient.LineNo.ToString();

            try
            {
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.RecordType, 2));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.LineNo, 7, '0'));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BranchCode, 6));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.ReferenceNo, 8));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenType, 2, '0'));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenSubType, 2, '0'));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenShortName, 16));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenAccountCategory, 2, '0'));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenOccupation, 2, '0'));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenFirstHolderName, 135));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Filler1, 115));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.FirstHolderFatherOrHusbandName, 45));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.FirstHolderAdd1, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.FirstHolderAdd2, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.FirstHolderAdd3, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.FirstHolderAdd4, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.FirstHolderAddrPin, 7));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenHolderPhoneNo, 24));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenHolderFaxNo, 24));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenSecondHolderName, 45));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.SecondHolderFatherOrHusbandName, 45));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BeneficiaryThirdHolderName, 45));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.ThirdHolderFatherOrHusbandName, 45));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.CorrespondingBPId, 8));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.AddressPreferenceFlag, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.ClientActivationDatetime, 14));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Filler2, 55));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.FirstHolderFinancialDetail, 30));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.SecondHolderFinancialDetail, 30));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.ThirdHolderFinancialDetail, 30));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.NomineeOrGuardianIndicator, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.NomineeOrGuardianName, 45));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.DOB, 8));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.NomineeOrGuardianAdd1, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.NomineeOrGuardianAdd2, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.NomineeOrGuardianAdd3, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.NomineeOrGuardianAdd4, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.NomineeOrGuardianAddPin, 7));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.StandingInstructionIndicator, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Filler3, 3));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.IFSCCode, 11));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.AccountForHoldingReceipts, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenBankAccountType, 2, '0'));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenBankName, 135));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenBankAdd1, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenBankAdd2, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenBankAdd3, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenBankAdd4, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenBankAddrPin, 7));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenBankMICRCode, 9));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenRBIRefNo, 50));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenRBIApprovalDate, 8));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenSEBIRegNo, 24));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenTaxDeductionStatus, 20));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenStatus, 2, '0'));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenStatusChangeReason, 50));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Filler4, 28));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.FirstHolderCorrAdd1, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.FirstHolderCorrAdd2, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.FirstHolderCorrAdd3, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.FirstHolderCorrAdd4, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.FirstHolderCorrAddPin, 10));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenCorrPhoneNo, 24));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenCorrFax, 24));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.NomineeMinorIndicator, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.MinorNomineeDOB, 8));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.MinorNomineeGuardianName, 45));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.MinorNomineeGuardianAdd1, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.MinorNomineeGuardianAdd2, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.MinorNomineeGuardianAdd3, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.MinorNomineeGuardianAdd4, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.MinorNomineeGuardianPin, 7));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BenBankACCNo, 30));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.FirstHolderEmail, 50));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.FirstHolderMob, 13));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Filler5, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Filler6, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.SMSFlagFirstHolder, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.PANFlagFirstHolder, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Filler7, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.NoNominationFlagFirstHolder, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Filler8, 10));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.SecondHolderEmail, 50));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.SecondHolderMob, 13));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Filler9, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Filler10, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.SMSFlagSecondHolder, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.PanFlagSecondHolder, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Filler11, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Filler12, 12));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.ThirdHolderEmail, 50));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.ThirdHolderMob, 13));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Filler13, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Filler14, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.SMSFlagThirdHolder, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.PanFlagThirdHolder, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Filler15, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.FirstHolderAdhaarNo, 12));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.SecondHolderAdhaarNo, 12));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.ThirdHolderAdhaarNo, 12));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Filler16, 16));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.ClientGroupName, 8));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BillingCategory, 20));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.InwardDate, 8));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Income, 10));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.LineOfBusiness, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BankingFlag, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.ChargesBankACCNo, 30));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BankAccountType, 2));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BankName, 135));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BankAdd1, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BankAdd2, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BankAdd3, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BankAdd4, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BankAddPin, 7));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.MICRCode, 9));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.ContactPerson1, 30));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.ContactPerson2, 30));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.CustomerId, 10));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.InternetTrading, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.InstantClientID, 8));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Filler17, 41));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.RECode, 10));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.RPCode, 10));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.NAME, 40));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.NSECashSeg, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.NSEFNOSeg, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.NSECDSeg, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BSECASHSeg, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BSEFNOSeg, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.BSECDSeg, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Filler18, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Filler19, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.GrossAuunalIncome, 10));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Networth, 12));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.NetworthDate, 8));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Occupation, 2,'0'));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.NatureOfBusiness, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.EmployerName, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.PEP, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.RPEP, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.OtherInfo, 36));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.PastAction, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.ActionTakenBySEBI, 23));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.DealingThroughOtherBrokers, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.SubBrokerName, 10));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.SubBrokerSebiRegNo, 10));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.SubBrokerAdd, 9));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.OtherStockBrokerName, 9));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.OtherBrokerSubBrokerName, 9));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.OtherBrokerClientCODE, 9));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.ExchangeOptedAtOtherBroker, 5));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.DisputesWithOtherBroker, 34));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.ECN, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.EmailForECN, 34));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.IsInternetTrading, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.TradingExp, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.TradingExpStock, 2));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.TradingExpDer, 2));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.IntrName, 34));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.IntrStatus, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.IntrAdd, 34));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.IntrPhone, 10));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.TradingNomination, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.TradingNomineeName, 23));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.TradingNomineeRelation, 9));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.TradingNomineePan, 11));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.TradingNomineeDob, 8));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.TradingNomineeAddress, 23));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.TradingNomineePhone, 10));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.TradingMinorNomineeGuardianName, 23));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.TradingMinorNomineeGuardianAdd, 23));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.TradingMinorNomineeGuardianPhoneNo, 10));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.PaymentMode, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.ChequeNo, 6));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.ChequeDate, 8));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.ChequeBankName, 23));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.PlanName, 23));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.AccountNoDirectDebit, 30));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.AccountOpeningCharges, 10));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.YSLSchemeCode, 50));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Prefix, 5));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Gender, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.MaritalStatus, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.CityofBirth, 50));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.CountryOfBirth, 50));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Status, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Filler20, 50));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Nationality, 50));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.IdProofSubmitted, 2));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.ValidTill, 8));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.City, 40));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.State, 50));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Country, 50));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.AddressProofSubmitted, 2));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Filler21, 8));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.CountryCodeTelOff, 4));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.STDCodeTelOff, 5));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.OffPhone, 10));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.OffExt, 6));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.CountryCodeTelRes, 4));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.STDCodeTelRes, 5));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.ResPhone, 10));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.CountryCodeTelFAX, 4));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.STDCodeTelFAX, 5));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.FAX, 10));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.CountryCodeMobile, 4));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Mobile, 10));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.PerAddCity, 40));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.PerAddState, 50));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.PerAddCountry, 50));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.CountryCodeTelPer, 4));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.STDCodeTelPer, 5));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.PerPhone, 10));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.Filler22, 4));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.PerMob, 10));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.FATCAFirstApplicant, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.ClientStatus, 2));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.RiskCategorization, 1));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.UCC, 12));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.InPersonDate, 8));
                sbFileBodyDetails.Append(Process.GetFixLenString(objTradingAccntBodyDtls.RunningAccount, 1));
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "DetailRecord() Error while adding Detail Record per Trading Account.", ex);
                return string.Empty;
            }

            return sbFileBodyDetails.ToString();
        }
        #endregion Detail Record per Trading Account

        #endregion Methods
    }
}
