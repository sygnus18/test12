﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTIL.Match.CDD.BAL.DataClasses.TradingAccountOpening
{
    public static class TradingData
    {
        #region Get per proof of add
        static Dictionary<int,int> l_dictPerAddProof = new Dictionary<int, int>
        {
            {2,1},  //Passport
            {26,5}, //DrivingLicence
            {25,2}, //VoterID
            {5,3},  //RationCard
            {24,11},//BankStatement
            {13,9}, //Electricity Bill
            {7,12}  //AadharCard
        };
        public static string GetPerProofOfAdd(int PerAddCode)
        {
            int PerAddProof;
            l_dictPerAddProof.TryGetValue(PerAddCode, out PerAddProof);
            return PerAddProof.ToString();
        }
        #endregion Get per proof of add

        #region Get Occupation by Type
        static Dictionary<int?, int> l_dictOccupation = new Dictionary<int?, int>
        {
            {1 ,1},	//Public Sector
            {2 ,2},    //Private Sector
            {3 ,3},    //Government Service
            {4 ,4},    //Business
            {5 ,5},    //Professional
            {6 ,6},    //Agriculture
            {7 ,7},    //Retired
            {8 ,8},    //Housewife
            {9 ,9},    //Student
            {99,10}	//Others
        };
        public static string GetOccupationType(int? Occupation)
        {
            int OccupationType;
            l_dictOccupation.TryGetValue(Occupation, out OccupationType);
            return OccupationType.ToString();
        }
        #endregion Get Occupation by Type


        #region Get RunningAccount by Type
        static Dictionary<int, string> l_dictRunningAccount = new Dictionary<int, string>
        {
            {1,"B"},// MONTHLY
            {2,"O"}// FORNIGHTLY
        };
        public static string GetRunningAccountType(int RunningAccount)
        {
            string RunningAccountType;
            l_dictRunningAccount.TryGetValue(RunningAccount, out RunningAccountType);
            return RunningAccountType;
        }
        #endregion Get RunningAccount by Type
    }
    public struct CTradingDataProvider
    {
        public static string BranchCode = "0001";
        public static string BenType = "01";
        public static string BenSubType = "01";
        public static string BenAccountCategory = "02";
        public static string Nationality = "INDIAN";
        public static string DefaultStatus = "1";
        public static string StandingInstruction = "N";
        public static string BeneficiaryStatus = "90";
        public static string DefaultYSLSchemeCode = "YESVALUE";
        public static string ClientGroupName = "YES PROS";
        public static string BillingCategory = "YES PROSPERITY";
        public static string ECN = "Y";
        public static string IsInternetTrading = "Y";
        public static string ClientStatus = "1";
        public static string RunningAccount = "B";
        public static string RECode = "ONLINEACC";
        public static int AddLimitPerline = 36;
    }

    /// <summary>
    /// Address preference flag :	Y - for local, N - for Foreign/Correspondence
    /// </summary>
    public struct AddressPreference
    { 
       public static string Local ="Y";
       public static string ForeignOrCorrespondence ="N";
    }
    
}
