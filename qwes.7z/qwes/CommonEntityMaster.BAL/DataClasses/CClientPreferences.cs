﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using MatchCommon;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;

namespace FTIL.Match.CDD.BAL.DataClasses
{
    public class CClientPreferences
    {

#region variables
        //Master columns
        public static readonly string DealerNo = "DealerNo";
        public static readonly string DealerCode = "DealerCode";
        public static readonly string PreferenceCode = "RoundingPrefCode";
        public static readonly string Bills = "PrintBill";
        public static readonly string Contracts = "PrintCont";
        public static readonly string Charge = "ChargeCode";
        public static readonly string ServProvider = "STPServiceProviderCode";
        public static readonly string ISOFlat = "STPType";
        public static readonly string Format = "STPFormat";
        public static readonly string DownloadFor = "STPDownloadFor";
        public static readonly string IntRate = "InterestRate";
        public static readonly string POA = "POA";
        public static readonly string RunningClient = "ClientStatus";
        public static readonly string TradeClub = "TradeClub";
        public static readonly string PaymentMode = "PaymentMode";
        public static readonly string GlobalPreferences = "SoftDollar";
        public static readonly string IncludeSTInBrkg = "IncludeTT";
        public static readonly string IncludeSTInCC = "IncludeSTOnCC";
        public static readonly string IncludeSTTInBrkg = "IncludeSTT";
        public static readonly string IncludeTOInBrkg = "IncludeTO";
        public static readonly string IncludeSDInBrkg = "IncludeSD";
        public static readonly string IncludeSEBIInBrkg = "IncludeSEBI";
        public static readonly string IncludeDepoInBrkg = "";
        public static readonly string IncludeCFInBrkg = "IncludeCF";
        public static readonly string IncludeCCInBrkg = "IncludeCC";
        public static readonly string IncludeAuctionPenalInBrkg = "IncludeDP";
        public static readonly string STOnNetGrossBrkg = "STOnNetGrossBrkg";
        public static readonly string ContractFormType = "ContractForm";
        public static readonly string ContractNoGen = "ContGen";
        public static readonly string BillGen = "BillOnDelivery";
        public static readonly string BillNoGen = "BillGen";
        public static readonly string SettlementOn = "BillContractFlag";
        public static readonly string StockTransfer = "StockTransfer";
        public static readonly string ChargeDelvCharges = "DelvChargesInBill";
        public static readonly string SettDateOnContract = "PrintSettDate";
        public static readonly string RegionMapping = "RegionNo";
        public static readonly string PayoutRiskMatrix = "ProfileNo";
        public static readonly string OverrideRMSFor = "IgnoreRMSFor";
        public static readonly string BeforeFunds = "DPIFundsSchedule";
        public static readonly string BeforeSecurities = "DPISecSchedule";
        public static readonly string AfterFunds = "DPOFundsSchedule";
        public static readonly string AfterSecurities = "DPOSecSchedule";
        public static readonly string AccEntryintheNameOf = "AccountEntry";
        public static readonly string NameOnContract = "NameOnContract";
        //Trade Confirmation memo
        public static readonly string TradeConfMemoEnabled = "TradeConfMemoEnabled";
        //end
        

        //Dropdown and other columns
        public static readonly string SysParamNo = "SysParamNo";
        public static readonly string SysParamValue = "SysParamValue";
        public static readonly string ServProviderDisplay = "STPServiceProviderCodeDisplay";
        public static readonly string ISOFlatDisplay = "STPTypeDisplay";
        public static readonly string FormatDisplay = "STPFormatDisplay";
        public static readonly string DownloadForDisplay = "STPDownloadForDisplay";
        public static readonly string TradeClubDisplay = "TradeClubDisplay";
        public static readonly string PaymentModeDisplay = "PaymentModeDisplay";
        public static readonly string GlobalPreferencesDisplay = "SoftDollarDisplay";
        public static readonly string ContractFormTypeDisplay = "ContractFormDisplay";
        public static readonly string ContractNoGenDisplay = "ContGenDisplay";
        public static readonly string BillGenDisplay = "BillOnDeliveryDisplay";
        public static readonly string BillNoGenDisplay = "BillGenDisplay";
        public static readonly string SettlementOnDisplay = "BillContractFlagDisplay";
        public static readonly string StockTransferDisplay = "StockTransferDisplay";
        public static readonly string ChargeDelvChargesDisplay = "DelvChargesInBillDisplay";
        public static readonly string SettDateOnContractDisplay = "PrintSettDateDisplay";
        public static readonly string RegionMappingDisplay = "RegionDescDisplay";
        public static readonly string PayoutRiskMatrixDisplay = "ProfileCode";
        public static readonly string OverrideRMSForDisplay = "IgnoreRMSForDisplay";
        public static readonly string AccEntryintheNameOfDisplay = "AccountEntryDisplay";
        public static readonly string NameOnContractDisplay = "NameOnContractDisplay";
        #endregion

#region GetLookupData
        /// <summary>
        /// Retrieves Lookup details for specified tab ID.
        /// </summary>

        public MethodExecResult GetLookupData( ref DataSet l_dsLookUp, ref string l_sErrorMsg)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetClientPreferencesLookUpData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

           // l_objDbWorkItem.AddParameter("@pn_EntityNo", SqlDbType.Int, nClientNo);
            l_objDbWorkItem.AddParameter("@UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                    return new MethodExecResult(1, "No data found", "stp_GetClientPreferencesLookUpData Database returned no data. UserNo. " +
                        AppEnvironment.AppUser.UserNo.ToString(), null);
                else
                {
                    l_dsLookUp = l_dsReturnData;
                   // dtResult = l_dsReturnData.Tables[0];
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        }
        #endregion

        #region GetData
        /// <summary>
        /// Retrieves Brokerage data
        /// </summary>
        /// <param name="p_viTabID">Tab ID. 1->Scrip Master, 2->Exchange Mapping, 3->IRF Contract Mapping</param>
        /// <param name="p_rdtLookup">"Looup data as returned from database"</param>
        /// <param name="p_vsMsg">Return error message if any</param>
        /// <returns></returns>
        public long GetData(DataSet p_vdsFilters, ref DataSet p_rdsUnderlyingData, ref string p_rsMsg)
        {
            long l_lngRetCode = 0;
               p_rdsUnderlyingData = null;
            DataSet l_dsReturnData = null;
            //p_vhstFilters.Add("TabID", p_viTabID);
            //long l_lngRetCode= base.PerformDbOperation(p_vdsFilters, MatchCommon.DBOperation.Select, MatchCommon.DateFormat.ShortDate,
                //false, false, "stp_ClientPreferences_Master", ref l_dsReturnData, ref p_rsMsg);

            if ((l_lngRetCode == 0)
                && (l_dsReturnData.Tables.Count > 0))
            {
                p_rdsUnderlyingData = l_dsReturnData;
                return 0;
            }

            return ((l_lngRetCode == 0) ? -1 : l_lngRetCode);
        }
        #endregion



      

    }
}
