﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTIL.Match.CDD.BAL.DataStore
{
    public class ClientBankDetails
    {
        List<ClientBankDetail> m_ClientBankDetail; 
        #region constructor
        public ClientBankDetails()
        {
            m_ClientBankDetail = new List<ClientBankDetail>();
        }
        #endregion constructor

        /// <summary>
        /// Client Bank Detail List
        /// </summary>
        public List<ClientBankDetail> ClientBankDetailList
        {
            get { return m_ClientBankDetail; }
            set { m_ClientBankDetail = value; }
        }

        /// <summary>
        /// Add new Bank Detail
        /// </summary>
        /// <param name="oClientBankDetail">ClientBankDetail Object filled with details</param>
        /// <returns>0 - Success, -1 - Failed</returns>
        public int Add(ClientBankDetail oClientBankDetail)
        {
            int oResult = m_ClientBankDetail.FindIndex(obj => obj.ClientNo == oClientBankDetail.ClientNo);

            if (oResult != 0)
            {
                m_ClientBankDetail.Add(oClientBankDetail);
                return 0;
            }
            else
            {
                return -1;
            }
        }

      
    }
}
