﻿using System;
using System.Data;
using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.Common.Log;

namespace FTIL.Match.CDD.BAL.DataStore
{
    /// <summary>
    /// contains client details.
    /// </summary>
    public class Client
    {
        #region public properties

        #region flag for is Client Valid
        public bool IsValidClient { get; set; }
        #endregion flag for is Client Valid

        #region validation Errors
        private string _ErrorString;

        public string ErrorString
        {
            get { return _ErrorString; }
        }
        #endregion validation Errors

        #region Client Personal Details

        #region ClientNo
        private Int32 _ClientNo;
        /// <summary>
        /// ClientNo
        /// </summary>
        public Int32 ClientNo
        {
            get { return _ClientNo; }
            set { _ClientNo = value; }
        }
        #endregion

        #region ClientCode
        private string _ClientCode;
        /// <summary>
        /// ClientCode
        /// </summary>
        public string ClientCode
        {
            get { return _ClientCode; }
            set { _ClientCode = value; }
        }
        #endregion

        #region ClientName
        private string _ClientName;
        /// <summary>
        /// ClientName
        /// </summary>
        public string ClientName
        {
            get { return _ClientName; }
            set { _ClientName = value; }
        }
        #endregion

        #region PANNo
        private string _PANNo;
        /// <summary>
        /// PANNo
        /// </summary>
        public string PANNo
        {
            get { return _PANNo; }
            set { _PANNo = value; }
        }

        #endregion

        #region Gender
        private string _Gender;
        /// <summary>
        /// Gender
        /// </summary>
        public string Gender
        {
            get { return _Gender; }
            set { _Gender = value; }
        }
        #endregion

        #region MaritalStatus
        private string _MaritalStatus;
        /// <summary>
        /// MaritalStatus
        /// </summary>
        public string MaritalStatus
        {
            get { return _MaritalStatus; }
            set { _MaritalStatus = value; }
        }
        #endregion

        #region Nationality
        private Byte? _Nationality;
        /// <summary>
        /// Nationality
        /// </summary>
        public Byte? Nationality
        {
            get { return _Nationality; }
            set { _Nationality = value; }
        }
        #endregion

        #region NationalityOther
        private string _NationalityOther;
        /// <summary>
        /// NationalityOther
        /// </summary>
        public string NationalityOther
        {
            get { return _NationalityOther; }
            set { _NationalityOther = value; }
        }
        #endregion

        #region PanExempt
        private string _PanExempt;
        /// <summary>
        /// PanExempt
        /// </summary>
        public string PanExempt
        {
            get { return _PanExempt; }
            set { _PanExempt = value; }
        }
        #endregion

        #region CorporateIdNo
        private string _CorporateIdNo;
        /// <summary>
        /// CorporateIdNo
        /// </summary>
        public string CorporateIdNo
        {
            get { return _CorporateIdNo; }
            set { _CorporateIdNo = value; }
        }
        #endregion

        #region CINExempt
        private string _CINExempt;
        /// <summary>
        /// CINExempt
        /// </summary>
        public string CINExempt
        {
            get { return _CINExempt; }
            set { _CINExempt = value; }
        }
        #endregion

        #region DOB
        private DateTime? _DOB;
        /// <summary>
        /// DOB
        /// </summary>
        public DateTime? DOB
        {
            get { return _DOB; }
            set { _DOB = value; }
        }
        #endregion

        #region CreationDate
        private DateTime? _CreationDate;
        /// <summary>
        /// CreationDate
        /// </summary>
        public DateTime? CreationDate
        {
            get { return _CreationDate; }
            set { _CreationDate = value; }
        }
        #endregion

        #endregion Client Personal Details

        #region GuardianName
        private string _GuardianName;
        /// <summary>
        /// GuardianName
        /// </summary>
        public string GuardianName
        {
            get { return _GuardianName; }
            set { _GuardianName = value; }
        }
        #endregion

        #region GrAnnIncRange
        private Int32? _GrAnnIncRange;
        /// <summary>
        /// GrAnnIncRange
        /// </summary>
        public Int32? GrAnnIncRange
        {
            get { return _GrAnnIncRange; }
            set { _GrAnnIncRange = value; }
        }
        #endregion

        #region GrAnnIncAsOnDate
        private DateTime? _GrAnnIncAsOnDate;
        /// <summary>
        /// GrAnnIncAsOnDate
        /// </summary>
        public DateTime? GrAnnIncAsOnDate
        {
            get { return _GrAnnIncAsOnDate; }
            set { _GrAnnIncAsOnDate = value; }
        }
        #endregion

        #region NetWorth
        private Decimal? _NetWorth;
        /// <summary>
        /// NetWorth
        /// </summary>
        public Decimal? NetWorth
        {
            get { return _NetWorth; }
            set { _NetWorth = value; }
        }
        #endregion

        #region NetWorthAsOnDate
        private DateTime? _NetWorthAsOnDate;
        /// <summary>
        /// NetWorthAsOnDate
        /// </summary>
        public DateTime? NetWorthAsOnDate
        {
            get { return _NetWorthAsOnDate; }
            set { _NetWorthAsOnDate = value; }
        }
        #endregion

        #region PEP
        private Byte? _PEP;
        /// <summary>
        /// PEP
        /// </summary>
        public Byte? PEP
        {
            get { return _PEP; }
            set { _PEP = value; }
        }
        #endregion

        #region PlaceofIncorporation
        private string _PlaceofIncorporation;
        /// <summary>
        /// PlaceofIncorporation
        /// </summary>
        public string PlaceofIncorporation
        {
            get { return _PlaceofIncorporation; }
            set { _PlaceofIncorporation = value; }
        }
        #endregion

        #region Occupation
        private Int32? _Occupation;
        /// <summary>
        /// Occupation
        /// </summary>
        public Int32? Occupation
        {
            get { return _Occupation; }
            set { _Occupation = value; }
        }
        #endregion

        #region OccupationOthers
        private string _OccupationOthers;
        /// <summary>
        /// OccupationOthers
        /// </summary>
        public string OccupationOthers
        {
            get { return _OccupationOthers; }
            set { _OccupationOthers = value; }
        }
        #endregion

        #region CommOfBusiness
        private DateTime? _CommOfBusiness;
        /// <summary>
        /// CommOfBusiness
        /// </summary>
        public DateTime? CommOfBusiness
        {
            get { return _CommOfBusiness; }
            set { _CommOfBusiness = value; }
        }
        #endregion

        #region UCCCode
        private string _UCCCode;
        /// <summary>
        /// UCCCode
        /// </summary>
        public string UCCCode
        {
            get { return _UCCCode; }
            set { _UCCCode = value; }
        }
        #endregion

        #region UpdationFlag
        private string _UpdationFlag;
        /// <summary>
        /// UpdationFlag
        /// </summary>
        public string UpdationFlag
        {
            get { return _UpdationFlag; }
            set { _UpdationFlag = value; }
        }
        #endregion

        #region TypeofFacility
        private string _TypeofFacility;
        /// <summary>
        /// TypeofFacility
        /// </summary>
        public string TypeofFacility
        {
            get { return _TypeofFacility; }
            set { _TypeofFacility = value; }
        }
        #endregion

        #region ClientTypeCorporate
        private string _ClientTypeCorporate;
        /// <summary>
        /// ClientTypeCorporate
        /// </summary>
        public string ClientTypeCorporate
        {
            get { return _ClientTypeCorporate; }
            set { _ClientTypeCorporate = value; }
        }
        #endregion

        #region IsPendingAuth
        private bool _IsPendingAuth;
        /// <summary>
        /// Indicates if current client is under authorisation
        /// </summary>
        public bool IsPendingAuth
        {
            get { return _IsPendingAuth; }
            set { _IsPendingAuth = value; }
        }
        #endregion

        #region MakerUser
        private int _MakerUser;
        /// <summary>
        /// Maker User No
        /// </summary>
        public int MakerUser
        {
            get { return _MakerUser; }
            set { _MakerUser = value; }
        }
        #endregion

        #region AllowModificationsToCurrentUser
        /// <summary>
        /// Indicates if current record is under authorisation then current application user can modify it?
        /// </summary>
        public bool AllowModificationsToCurrentUser
        {
            get
            {
                // TODO: need to correct condition for validating maker user
                //if ((this.IsPendingAuth)
                //    && (this.MakerUser != AppEnvironment.AppUser.UserNo)
                //  )
                //{
                //    return false;
                //}

                return true;
            }
        }
        #endregion

        #region LastUserNo
        private Int32 _LastUserNo;
        /// <summary>
        /// LastUserNo
        /// </summary>
        public Int32 LastUserNo
        {
            get { return _LastUserNo; }
            set { _LastUserNo = value; }
        }
        #endregion

        #region LastModifiedDateTime
        private DateTime _LastModifiedDateTime;
        /// <summary>
        /// LastModifiedDateTime
        /// </summary>
        public DateTime LastModifiedDateTime
        {
            get { return _LastModifiedDateTime; }
            set { _LastModifiedDateTime = value; }
        }
        #endregion

        #region AuthorizeDatetime
        private DateTime _AuthorizeDatetime;
        /// <summary>
        /// LastModifiedDateTime
        /// </summary>
        public DateTime AuthorizeDatetime
        {
            get { return _AuthorizeDatetime; }
            set { _AuthorizeDatetime = value; }
        }
        #endregion

        
        #region CheckerView
        /// <summary>
        /// Used to view the client screen in checker view mode
        /// </summary>
        private Boolean _IsCheckerView = false;
        public Boolean IsCheckerView
        {
            get { return _IsCheckerView; }
            set { _IsCheckerView = value; }
        }
        #endregion CheckerView

        #region ClientType

        private short m_ClientType;
        /// <summary>
        /// ClientType : 'I' = Individual 'N'= Non-Individual
        /// </summary>
        public short ClientType
        {
            get { return m_ClientType; }
            set { m_ClientType = value; }
        }
        #endregion

        #region LastUserNo
        private Int32 _Status;
        /// <summary>
        /// LastUserNo
        /// </summary>
        public Int32 Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        #endregion

        #region ClientActivationDate

        private DateTime? m_ClientActivationDate;
        /// <summary>
        /// Client Activation Date
        /// </summary>
        public DateTime? ClientActivationDate
        {
            get { return m_ClientActivationDate; }
            set { m_ClientActivationDate = value; }
        }
        #endregion

        #region UID
        private string _UID;
        /// <summary>
        /// UID
        /// </summary>
        public string UID
        {
            get { return _UID; }
            set { _UID = value; }
        }
        #endregion

        #region UCCType
        private Int32? _UCCType;
        /// <summary>
        /// Occupation
        /// </summary>
        public Int32? UCCType
        {
            get { return _UCCType; }
            set { _UCCType = value; }
        }
        #endregion

        #region ExchangeType

        private string m_ExType;
        /// <summary>
        /// ExchangeType
        /// </summary>
        public string ExType
        {
            get { return m_ExType; }
            set { m_ExType = value; }
        }
        #endregion

        public string ClientTitle { get; set; }

        public string GuardianTitle { get; set; }

        public string MiddleName { get; set; }

        public string LastName { get; set; }

        public string MotherName { get; set; }

        public string MaidenName { get; set; }

        public int LineNo { get; set; }

        public int RelatedPartyNo { get; set; }

        public string ClientRiskCategory { get; set; }

        public string CustId { get; set; }

        public string Branch { get; set; }

        public string CityOfBirth { get; set; }

        public string CountryOfBirth { get; set; }

        public string UserName  { get; set; }

		public int  UserGroupNo { get; set; }
		
        public string UserEmailID { get; set; }
		
        public string UserMobileNo { get; set; }
		
        public string UserPANNo { get; set; }
		
        public DateTime UserDateOfBirth { get; set; }
		
        public string UserRMEmpCode { get; set; }
		
        public string UserRMDesignation { get; set; }
        
        public string UserRMAddress { get; set; }

        public string BOID { get; set; }

        public string KYCFormRefCode { get; set; } 
        public int  StatementPeriodicity { get; set; } 
        
        
        #region BatchNo
        private Int32? _BatchNo;
        /// <summary>
        /// Occupation
        /// </summary>
        public Int32? BatchNo
        {
            get { return _BatchNo; }
            set { _BatchNo = value; }
        }
        #endregion

        #region KYCAdditionalDetail
        //private CKYCAdditionalDetail _KYCAdditionalDetail;
        ///// <summary>
        ///// LastModifiedDateTime
        ///// </summary>
        //public CKYCAdditionalDetail KYCAdditionalDetail
        //{
        //    get { return _KYCAdditionalDetail; }
        //    set { _KYCAdditionalDetail = value; }
        //}
        #endregion

        public string strErrorString { get; set; }
        #endregion public properties

        #region class variables

        public ClientAddresses oClientAddresses { get; set; }

        public ClientBankDetails oClientBankDetails { get; set; }

        public ClientProofDetails oClientProofDetails { get; set; }

        public ClientDPDetails oClientDPDetails { get; set; }

        public ClientAddresses oNomineeAddresses { get; set; }

        public ClientImageDetails oClientImageDetails { get; set; }

        public ClientTradingDetails oClientTradingDetails { get; set; }

        public ClientFatcaDetails oClientFatcaDetails { get; set; }

        public ClientDealingThroughDetails oClientDealingThroughDetails { get; set; }

        public ClientSchemeDetails oClientSchemeDetails { get; set; }
        #endregion class variables

        #region Constructor
        public Client()
        {
            IsValidClient = true;
        }
        #endregion Constructor

        #region methods
        /// <summary>
        /// Creates instance from DataRow
        /// </summary>
        /// <param name="DataRow">DataRow object containing client details</param>
        #region InstantiateFromDataRow
        public void InstantiateFromDataRow(Client m_objClient, DataRow DataRow)
        {
            try
            {
                m_objClient.ClientNo = Convert.ToInt32(DataRow["n_ClientNo"]);
                m_objClient.ClientCode = DataRow["s_ClientCode"].ToString().Trim();
                m_objClient.ClientName = DataRow["s_ClientName"].ToString().Trim();
                if ((DataRow["s_PANNo"] != null) && (DataRow["s_PANNo"] != DBNull.Value))
                    m_objClient.PANNo = DataRow["s_PANNo"].ToString().Trim();
                if ((DataRow["s_Gender"] != null) && (DataRow["s_Gender"] != DBNull.Value))
                    m_objClient.Gender = DataRow["s_Gender"].ToString().Trim();
                if ((DataRow["s_GuardianName"] != null) && (DataRow["s_GuardianName"] != DBNull.Value))
                    m_objClient.GuardianName = DataRow["s_GuardianName"].ToString().Trim();
                if ((DataRow["s_MaritalStatus"] != null) && (DataRow["s_MaritalStatus"] != DBNull.Value))
                    m_objClient.MaritalStatus = DataRow["s_MaritalStatus"].ToString().Trim();
                if ((DataRow["n_Nationality"] != null) && (DataRow["n_Nationality"] != DBNull.Value))
                    m_objClient.Nationality = Convert.ToByte(DataRow["n_Nationality"]);
                if ((DataRow["s_NationalityOther"] != null) && (DataRow["s_NationalityOther"] != DBNull.Value))
                    m_objClient.NationalityOther = DataRow["s_NationalityOther"].ToString().Trim();
                if ((DataRow["s_PanExempt"] != null) && (DataRow["s_PanExempt"] != DBNull.Value))
                    m_objClient.PanExempt = DataRow["s_PanExempt"].ToString().Trim();
                if ((DataRow["s_CorporateIdNo"] != null) && (DataRow["s_CorporateIdNo"] != DBNull.Value))
                    m_objClient.CorporateIdNo = DataRow["s_CorporateIdNo"].ToString().Trim();
                if ((DataRow["s_CINExempt"] != null) && (DataRow["s_CINExempt"] != DBNull.Value))
                    m_objClient.CINExempt = DataRow["s_CINExempt"].ToString().Trim();
                if ((DataRow["d_DOB"] != null) && (DataRow["d_DOB"] != DBNull.Value))
                    m_objClient.DOB = Convert.ToDateTime(DataRow["d_DOB"]);
                if ((DataRow["d_CreationDate"] != null) && (DataRow["d_CreationDate"] != DBNull.Value))
                    m_objClient.CreationDate = Convert.ToDateTime(DataRow["d_CreationDate"]);
                if ((DataRow["n_GrAnnIncRange"] != null) && (DataRow["n_GrAnnIncRange"] != DBNull.Value))
                    m_objClient.GrAnnIncRange = Convert.ToInt32(DataRow["n_GrAnnIncRange"]);
                if ((DataRow["d_GrAnnIncAsOnDate"] != null) && (DataRow["d_GrAnnIncAsOnDate"] != DBNull.Value))
                    m_objClient.GrAnnIncAsOnDate = Convert.ToDateTime(DataRow["d_GrAnnIncAsOnDate"]);
                if ((DataRow["n_NetWorth"] != null) && (DataRow["n_NetWorth"] != DBNull.Value))
                    m_objClient.NetWorth = Convert.ToDecimal(DataRow["n_NetWorth"]);
                if ((DataRow["d_NetWorthAsOnDate"] != null) && (DataRow["d_NetWorthAsOnDate"] != DBNull.Value))
                    m_objClient.NetWorthAsOnDate = Convert.ToDateTime(DataRow["d_NetWorthAsOnDate"]);
                if ((DataRow["n_PEP"] != null) && (DataRow["n_PEP"] != DBNull.Value))
                    m_objClient.PEP = Convert.ToByte(DataRow["n_PEP"]);
                if ((DataRow["s_PlaceofIncorporation"] != null) && (DataRow["s_PlaceofIncorporation"] != DBNull.Value))
                    m_objClient.PlaceofIncorporation = DataRow["s_PlaceofIncorporation"].ToString().Trim();
                if ((DataRow["n_Occupation"] != null) && (DataRow["n_Occupation"] != DBNull.Value))
                    m_objClient.Occupation = Convert.ToInt32(DataRow["n_Occupation"]);
                if ((DataRow["s_OccupationOthers"] != null) && (DataRow["s_OccupationOthers"] != DBNull.Value))
                    m_objClient.OccupationOthers = DataRow["s_OccupationOthers"].ToString().Trim();
                if ((DataRow["d_CommOfBusiness"] != null) && (DataRow["d_CommOfBusiness"] != DBNull.Value))
                    m_objClient.CommOfBusiness = Convert.ToDateTime(DataRow["d_CommOfBusiness"]);
                if ((DataRow["s_UCCCode"] != null) && (DataRow["s_UCCCode"] != DBNull.Value))
                    m_objClient.UCCCode = DataRow["s_UCCCode"].ToString().Trim();
                if ((DataRow["s_UpdationFlag"] != null) && (DataRow["s_UpdationFlag"] != DBNull.Value))
                    m_objClient.UpdationFlag = DataRow["s_UpdationFlag"].ToString().Trim();
                //if ((DataRow["s_Relationship"] != null) && (DataRow["s_Relationship"] != DBNull.Value))
                //    m_objClient.Relationship = DataRow["s_Relationship"].ToString().Trim();
                if ((DataRow["s_TypeofFacility"] != null) && (DataRow["s_TypeofFacility"] != DBNull.Value))
                    m_objClient.TypeofFacility = DataRow["s_TypeofFacility"].ToString().Trim();
                if ((DataRow["s_ClientTypeCorporate"] != null) && (DataRow["s_ClientTypeCorporate"] != DBNull.Value))
                    m_objClient.ClientTypeCorporate = DataRow["s_ClientTypeCorporate"].ToString().Trim();
                if ((DataRow["s_IsPendingAuth"] != null) && (DataRow["s_IsPendingAuth"] != DBNull.Value))
                    m_objClient.IsPendingAuth = (DataRow["s_IsPendingAuth"].ToString().Trim() == "Y");
                if ((DataRow["n_MakerUser"] != null) && (DataRow["n_MakerUser"] != DBNull.Value))
                    m_objClient.MakerUser = Convert.ToInt32(DataRow["n_MakerUser"]);
                if (DataRow.Table.Columns.Contains("n_UCCType") == true && (DataRow["n_UCCType"] != null) && (DataRow["n_UCCType"] != DBNull.Value))
                    m_objClient.UCCType = Convert.ToInt32(DataRow["n_UCCType"]);
                //if ((DataRow.Table.Columns.Contains("n_OwnClient") == true && DataRow["n_OwnClient"] != null) && (DataRow["n_OwnClient"] != DBNull.Value))
                //    m_objClient.ClientStatus = Convert.ToInt32(DataRow["n_OwnClient"]);
                m_objClient.LastUserNo = Convert.ToInt32(DataRow["n_LastUserNo"]);
                m_objClient.LastModifiedDateTime = Convert.ToDateTime(DataRow["d_LastModifiedDateTime"]);
                if ((DataRow["s_ClientTitle"] != null) && (DataRow["s_ClientTitle"] != DBNull.Value))
                    m_objClient.ClientTitle = DataRow["s_ClientTitle"].ToString().Trim();
                if ((DataRow["s_GuardianTitle"] != null) && (DataRow["s_GuardianTitle"] != DBNull.Value))
                    m_objClient.GuardianTitle = DataRow["s_GuardianTitle"].ToString().Trim();
                if ((DataRow["s_MiddleName"] != null) && (DataRow["s_MiddleName"] != DBNull.Value))
                    m_objClient.MiddleName = DataRow["s_MiddleName"].ToString().Trim();
                if ((DataRow["s_LastName"] != null) && (DataRow["s_LastName"] != DBNull.Value))
                    m_objClient.LastName = DataRow["s_LastName"].ToString().Trim();
                if ((DataRow["s_MotherName"] != null) && (DataRow["s_MotherName"] != DBNull.Value))
                    m_objClient.MotherName = DataRow["s_MotherName"].ToString().Trim();
                if ((DataRow["s_MaidenName"] != null) && (DataRow["s_MaidenName"] != DBNull.Value))
                    m_objClient.MaidenName = DataRow["s_MaidenName"].ToString().Trim();
                if (DataRow.Table.Columns.Contains("n_BatchNo") == true && (DataRow["n_BatchNo"] != null) && (DataRow["n_BatchNo"] != DBNull.Value))
                    m_objClient.BatchNo = Convert.ToInt32(DataRow["n_BatchNo"]);
                if (DataRow.Table.Columns.Contains("n_Status") == true && (DataRow["n_Status"] != null) && (DataRow["n_Status"] != DBNull.Value))
                    m_objClient.Status = Convert.ToInt32(DataRow["n_Status"]);
                if (DataRow.Table.Columns.Contains("d_AuthorizeDatetime") == true && (DataRow["d_AuthorizeDatetime"] != null) && (DataRow["d_AuthorizeDatetime"] != DBNull.Value))
                    m_objClient.AuthorizeDatetime = Convert.ToDateTime(DataRow["d_AuthorizeDatetime"]);
                if (DataRow.Table.Columns.Contains("s_ClientRiskCategory") == true && (DataRow["s_ClientRiskCategory"] != null) && (DataRow["s_ClientRiskCategory"] != DBNull.Value))
                    m_objClient.ClientRiskCategory = DataRow["s_ClientRiskCategory"].ToString().Trim();
                if (DataRow.Table.Columns.Contains("s_CustId") == true && (DataRow["s_CustId"] != null) && (DataRow["s_CustId"] != DBNull.Value))
                    m_objClient.CustId = DataRow["s_CustId"].ToString().Trim();
                if (DataRow.Table.Columns.Contains("s_Branch") == true && (DataRow["s_Branch"] != null) && (DataRow["s_Branch"] != DBNull.Value))
                    m_objClient.Branch = DataRow["s_Branch"].ToString().Trim();
                if (DataRow.Table.Columns.Contains("s_CityOfBirth") == true && (DataRow["s_CityOfBirth"] != null) && (DataRow["s_CityOfBirth"] != DBNull.Value))
                    m_objClient.CityOfBirth = DataRow["s_CityOfBirth"].ToString().Trim();
                if (DataRow.Table.Columns.Contains("s_CountryOfBirth") == true && (DataRow["s_CountryOfBirth"] != null) && (DataRow["s_CountryOfBirth"] != DBNull.Value))
                    m_objClient.CountryOfBirth = DataRow["s_CountryOfBirth"].ToString().Trim();
                //User details.
                if (DataRow.Table.Columns.Contains("s_UserName") == true && (DataRow["s_UserName"] != null) && (DataRow["s_UserName"] != DBNull.Value))
                    m_objClient.UserName = DataRow["s_UserName"].ToString().Trim();
                if (DataRow.Table.Columns.Contains("n_UserGroupNo") == true && (DataRow["n_UserGroupNo"] != null) && (DataRow["n_UserGroupNo"] != DBNull.Value))
                    m_objClient.UserGroupNo = Convert.ToInt32(DataRow["n_UserGroupNo"]);
                if (DataRow.Table.Columns.Contains("s_UserEmailID") == true && (DataRow["s_UserEmailID"] != null) && (DataRow["s_UserEmailID"] != DBNull.Value))
                    m_objClient.UserEmailID = DataRow["s_UserEmailID"].ToString().Trim();
                if (DataRow.Table.Columns.Contains("s_UserMobileNo") == true && (DataRow["s_UserMobileNo"] != null) && (DataRow["s_UserMobileNo"] != DBNull.Value))
                    m_objClient.UserMobileNo = DataRow["s_UserMobileNo"].ToString().Trim();
                if (DataRow.Table.Columns.Contains("s_UserPANNo") == true && (DataRow["s_UserPANNo"] != null) && (DataRow["s_UserPANNo"] != DBNull.Value))
                    m_objClient.UserPANNo = DataRow["s_UserPANNo"].ToString().Trim();
                if (DataRow.Table.Columns.Contains("d_UserDateOfBirth") == true && (DataRow["d_UserDateOfBirth"] != null) && (DataRow["d_UserDateOfBirth"] != DBNull.Value))
                    m_objClient.UserDateOfBirth = Convert.ToDateTime(DataRow["d_UserDateOfBirth"]);
                if (DataRow.Table.Columns.Contains("s_UserRMEmpCode") == true && (DataRow["s_UserRMEmpCode"] != null) && (DataRow["s_UserRMEmpCode"] != DBNull.Value))
                    m_objClient.UserRMEmpCode = DataRow["s_UserRMEmpCode"].ToString().Trim();
                if (DataRow.Table.Columns.Contains("s_UserRMDesignation") == true && (DataRow["s_UserRMDesignation"] != null) && (DataRow["s_UserRMDesignation"] != DBNull.Value))
                    m_objClient.UserRMDesignation = DataRow["s_UserRMDesignation"].ToString().Trim();
                if (DataRow.Table.Columns.Contains("s_UserRMAddress") == true && (DataRow["s_UserRMAddress"] != null) && (DataRow["s_UserRMAddress"] != DBNull.Value))
                    m_objClient.UserRMAddress = DataRow["s_UserRMAddress"].ToString().Trim();
                if (DataRow.Table.Columns.Contains("s_UID") == true && (DataRow["s_UID"] != null) && (DataRow["s_UID"] != DBNull.Value))
                    m_objClient.UID = DataRow["s_UID"].ToString().Trim();
                if (DataRow.Table.Columns.Contains("s_BOID") == true && (DataRow["s_BOID"] != null) && (DataRow["s_BOID"] != DBNull.Value))
                    m_objClient.BOID = DataRow["s_BOID"].ToString().Trim();
                if (DataRow.Table.Columns.Contains("s_KYCFormRefCode") == true && (DataRow["s_KYCFormRefCode"] != null) && (DataRow["s_KYCFormRefCode"] != DBNull.Value))
                    m_objClient.KYCFormRefCode = DataRow["s_KYCFormRefCode"].ToString().Trim();
                if (DataRow.Table.Columns.Contains("n_StatementPeriodicity") == true && (DataRow["n_StatementPeriodicity"] != null) && (DataRow["n_StatementPeriodicity"] != DBNull.Value))
                    m_objClient.StatementPeriodicity = Convert.ToInt32(DataRow["n_StatementPeriodicity"]);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "InstantiateFromDataRow() Error Creating instance from DataRow. ClientNo: " + this.ClientNo, ex);
                throw ex;
            }
        }

        #endregion

        /// <summary>
        /// Set Address Details from DataTable
        /// </summary>
        /// <param name="dtAddress">Address DataTable</param>
        #region SetClientAddressesFromDataTable
        public void SetClientAddressesFromDataTable(DataTable dtAddress)
        {
            try
            {
                this.oClientAddresses = new ClientAddresses();

                DataRow[] addresses = dtAddress.Select(" n_ClientNo =  " + this.ClientNo);

                if ((addresses == null) || (addresses.Length == 0))
                {
                    Logger.Instance.WriteLog(this, "Setting ClientAddresses From DataTable. No data found. ClientNo: " + this.ClientNo);
                }
                else
                {
                    for (int i = 0; i < addresses.Length; i++)
                    {
                        ClientAddress address = new ClientAddress();
                        address.InitializeFromDataRow(addresses[i]);
                        this.oClientAddresses.Add(address);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "SetClientAddressesFromDataTable() Error processing DataRow", ex);
                throw ex;
            }
        }
        #endregion

        /// <summary>
        /// Set Nominee Address Details from DataTable
        /// </summary>
        /// <param name="dtAddress">Address DataTable</param>
        #region SetNomineeAddressesFromDataTable
        public void SetNomineeAddressesFromDataTable(DataTable dtAddress)
        {
            try
            {
                this.oNomineeAddresses = new ClientAddresses();

                DataRow[] addresses = dtAddress.Select("n_AddressType in (5,8)");

                if ((addresses == null) || (addresses.Length == 0))
                {
                    Logger.Instance.WriteLog(this, "Setting NomineeAddresses From DataTable. No data found. ClientNo: " + this.ClientNo);
                }
                else
                {
                    for (int i = 0; i < addresses.Length; i++)
                    {
                        ClientAddress address = new ClientAddress();
                        address.InitializeFromDataRow(addresses[i]);
                        this.oNomineeAddresses.Add(address);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "SetNomineeAddressesFromDataTable() Error processing DataRow", ex);
                throw ex;
            }
        }
        #endregion

        /// <summary>
        ///  Set Bank Branch Details from DataTable
        /// </summary>
        /// <param name="dtBankBranchDetails">BankBranchDetails datatable</param>
        #region SetClientBankBranchDetailsFromDataTable
        public void SetClientBankBranchDetailsFromDataTable(DataTable dtBankBranchDetails)
        {
            try
            {
                this.oClientBankDetails = new ClientBankDetails();

                DataRow[] BankBranchDetails = dtBankBranchDetails.Select(" n_ClientNo =  " + this.ClientNo);

                if ((BankBranchDetails == null) || (BankBranchDetails.Length == 0))
                {
                    Logger.Instance.WriteLog(this, "Setting Client Bank Branch Details From DataTable. No data found. ClientNo: " + this.ClientNo);
                }
                else
                {
                    for (int i = 0; i < BankBranchDetails.Length; i++)
                    {
                        ClientBankDetail oClientBankDetail = new ClientBankDetail();
                        oClientBankDetail.InitializeFromDataRow(BankBranchDetails[i]);
                        this.oClientBankDetails.Add(oClientBankDetail);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "SetClientBankBranchDetailsFromDataTable() Error processing DataRow", ex);
                throw ex;
            }
        }
        #endregion

        /// <summary>
        ///  Set Proof Details from DataTable
        /// </summary>
        /// <param name="dtProofDetails">ProofDetails datatable</param>
        #region SetClientProofDetailsFromDataTable
        public void SetClientProofDetailsFromDataTable(DataTable dtProofDetails)
        {
            try
            {
                this.oClientProofDetails = new ClientProofDetails();

                DataRow[] ProofDetails = dtProofDetails.Select(" n_ClientNo =  " + this.ClientNo);

                if ((ProofDetails == null) || (ProofDetails.Length == 0))
                {
                    Logger.Instance.WriteLog(this, "Setting ClientProofDetails From DataTable. No data found. ClientNo: " + this.ClientNo);
                }
                else
                {
                    for (int i = 0; i < ProofDetails.Length; i++)
                    {
                        ClientProofDetail ProofDetail = new ClientProofDetail();
                        ProofDetail.InitializeFromDataRow(ProofDetails[i]);
                        this.oClientProofDetails.Add(ProofDetail);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "SetClientProofDetailsFromDataTable() Error processing DataRow", ex);
                throw ex;
            }
        }
        #endregion

        /// <summary>
        ///  Set DP Details from DataTable
        /// </summary>
        /// <param name="dtDPDetails">DPDetails datatable</param>
        #region SetClientDPDetailsFromDataTable
        public void SetClientDPDetailsFromDataTable(DataTable dtDPDetails)
        {
            try
            {
                this.oClientDPDetails = new ClientDPDetails();

                DataRow[] DPDetails = dtDPDetails.Select(" n_ClientNo =  " + this.ClientNo);

                if ((DPDetails == null) || (DPDetails.Length == 0))
                {
                    Logger.Instance.WriteLog(this, "Setting ClientDPDetails From DataTable. No data found. ClientNo: " + this.ClientNo);
                }
                else
                {
                    for (int i = 0; i < DPDetails.Length; i++)
                    {
                        ClientDPDetail DPDetail = new ClientDPDetail();
                        DPDetail.InitializeFromDataRow(DPDetails[i]);
                        this.oClientDPDetails.Add(DPDetail);
                        this.RelatedPartyNo = DPDetail.RelatedPartyNo;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "SetClientDPDetailsFromDataTable() Error processing DataRow", ex);
                throw ex;
            }
        }
        #endregion SetClientDPDetailsFromDataTable

        /// <summary>
        /// Set Image Details from DataTable
        /// </summary>
        /// <param name="dtImageDetails"></param>
        #region SetClientImageDetailsFromDataTable
        public void SetClientImageDetailsFromDataTable(DataTable dtImageDetails)
        {
            try
            {
                this.oClientImageDetails = new ClientImageDetails();

                DataRow[] ImageDetails = dtImageDetails.Select(" n_ClientNo =  " + this.ClientNo);

                if ((ImageDetails == null) || (ImageDetails.Length == 0))
                {
                    Logger.Instance.WriteLog(this, "Setting ClientImageDetails From DataTable. No data found. ClientNo: " + this.ClientNo);
                }
                else
                {
                    for (int i = 0; i < ImageDetails.Length; i++)
                    {
                        ClientImageDetail ImageDetail = new ClientImageDetail();
                        ImageDetail.InitializeFromDataRow(ImageDetails[i]);
                        this.oClientImageDetails.Add(ImageDetail);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "SetClientImageDetailsFromDataTable() Error processing DataRow", ex);
                throw ex;
            }
        }
        #endregion SetClientImageDetailsFromDataTable

        /// <summary>
        /// Set Trading Details from DataTable
        /// </summary>
        /// <param name="dtTradingDetails"></param>
        #region SetClientTradingDetailsFromDataTable
        public void SetClientTradingDetailsFromDataTable(DataTable dtTradingDetails)
        {
            try
            {
                this.oClientTradingDetails = new ClientTradingDetails();

                DataRow[] TradingDetails = dtTradingDetails.Select(" n_ClientNo =  " + this.ClientNo);

                if ((TradingDetails == null) || (TradingDetails.Length == 0))
                {
                    Logger.Instance.WriteLog(this, "Setting ClientTradingDetails From DataTable. No data found. ClientNo: " + this.ClientNo);
                }
                else
                {
                    for (int i = 0; i < TradingDetails.Length; i++)
                    {
                        ClientTradingDetail TradingDetail = new ClientTradingDetail();
                        TradingDetail.InitializeFromDataRow(TradingDetails[i]);
                        this.oClientTradingDetails.Add(TradingDetail);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "SetClientTradingDetailsFromDataTable() Error processing DataRow", ex);
                throw ex;
            }
        }
        #endregion SetClientTradingDetailsFromDataTable

        /// <summary>
        /// Set Fatca Details from DataTable
        /// </summary>
        /// <param name="dtFatcaDetails"></param>
        #region SetClientFatcaDetailsFromDataTable
        public void SetClientFatcaDetailsFromDataTable(DataTable dtFatcaDetails)
        {
            try
            {
                this.oClientFatcaDetails = new ClientFatcaDetails();

                DataRow[] FatcaDetails = dtFatcaDetails.Select(" n_ClientNo =  " + this.ClientNo);

                if ((FatcaDetails == null) || (FatcaDetails.Length == 0))
                {
                    Logger.Instance.WriteLog(this, "Setting ClientFatcaDetails From DataTable. No data found. ClientNo: " + this.ClientNo);
                }
                else
                {
                    for (int i = 0; i < FatcaDetails.Length; i++)
                    {
                        ClientFatcaDetail FatcaDetail = new ClientFatcaDetail();
                        FatcaDetail.InitializeFromDataRow(FatcaDetails[i]);
                        this.oClientFatcaDetails.Add(FatcaDetail);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "SetClientFatcaDetailsFromDataTable() Error processing DataRow", ex);
                throw ex;
            }
        }
        #endregion SetClientFatcaDetailsFromDataTable

        /// <summary>
        /// Set Dealing through Details from DataTable
        /// </summary>
        /// <param name="dtDelaingThroughDetails"></param>
        #region SetClientDealingThroughDetailsFromDataTable
        public void SetClientDealingThroughDetailsFromDataTable(DataTable dtDelaingThroughDetails)
        {
            try
            {
                this.oClientDealingThroughDetails = new ClientDealingThroughDetails();

                DataRow[] DelaingThroughDetails = dtDelaingThroughDetails.Select(" n_ClientNo =  " + this.ClientNo);

                if ((DelaingThroughDetails == null) || (DelaingThroughDetails.Length == 0))
                {
                    Logger.Instance.WriteLog(this, "Setting DelaingThroughDetails From DataTable. No data found. ClientNo: " + this.ClientNo);
                }
                else
                {
                    for (int i = 0; i < DelaingThroughDetails.Length; i++)
                    {
                        ClientDealingThroughDetail DelaingThroughDetail = new ClientDealingThroughDetail();
                        DelaingThroughDetail.InitializeFromDataRow(DelaingThroughDetails[i]);
                        this.oClientDealingThroughDetails.Add(DelaingThroughDetail);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "SetClientDealingThroughDetailsFromDataTable() Error processing DataRow", ex);
                throw ex;
            }
        }
        #endregion SetClientDealingThroughDetailsFromDataTable

        /// <summary>
        /// Set Scheme Details from DataTable
        /// </summary>
        /// <param name="dtSchemeDetails"></param>
        #region SetSchemeDetailsFromDataTable
        public void SetSchemeDetailsFromDataTable(DataTable dtSchemeDetails)
        {
            try
            {
                this.oClientSchemeDetails = new ClientSchemeDetails();

                DataRow[] SchemeDetails = dtSchemeDetails.Select(" n_ClientNo =  " + this.ClientNo);

                if ((SchemeDetails == null) || (SchemeDetails.Length == 0))
                {
                    Logger.Instance.WriteLog(this, "Setting SchemeDetails From DataTable. No data found. ClientNo: " + this.ClientNo);
                }
                else
                {
                    for (int i = 0; i < SchemeDetails.Length; i++)
                    {
                        ClientSchemeDetail ClientSchemeDetail = new ClientSchemeDetail();
                        ClientSchemeDetail.InitializeFromDataRow(SchemeDetails[i]);
                        this.oClientSchemeDetails.Add(ClientSchemeDetail);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "SetSchemeDetailsFromDataTable() Error processing DataRow", ex);
                throw ex;
            }
        }
        #endregion SetSchemeDetailsFromDataTable


        #endregion methods
    }
}
