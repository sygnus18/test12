﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.CDD.BAL.DataStore;

namespace FTIL.Match.CDD.BAL.DataStore
{
    public class CKYCClientDetails_Yes
    {
        #region public properties
        public string TransactionID { get; set; }
        public string SourceSystemName { get; set; }
        public string SourcesystemCustCode { get; set; }
        public string SmallCustomer { get; set; }
        public string EkycOTPbased { get; set; }
        public string TransactionType { get; set; }
        public string CustomerCreationDate { get; set; }
        public string ModificationDate { get; set; }
        public string UniqueCustomerCode { get; set; }
        public string ConstitutionType { get; set; }
        public string Prefix { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string MaidenPrefix { get; set; }
        public string MaidenFirstName { get; set; }
        public string MaidenMiddleName { get; set; }
        public string MaidenLastName { get; set; }
        public string FatherPrefix { get; set; }
        public string FatherFirstName { get; set; }
        public string FatherMiddleName { get; set; }
        public string FatherLastName { get; set; }
        public string SpousePrefix { get; set; }
        public string SpouseFirstName { get; set; }
        public string SpouseMiddleName { get; set; }
        public string SpouseLastName { get; set; }
        public string MotherPrefix { get; set; }
        public string MotherFirstName { get; set; }
        public string MotherMiddleName { get; set; }
        public string MotherLastName { get; set; }
        public string Gender { get; set; }
        public string MaritalStatus { get; set; }
        public string Citizenship { get; set; }
        public string OccupationType { get; set; }
        public string DateofBirth { get; set; }
        public string ResidentialStatus { get; set; }
        public string EmailId { get; set; }
        public string KYCDateOfDeclaration { get; set; }
        public string KYCPlaceOfDeclaration { get; set; }
        public string KYCVerificationDate { get; set; }
        public string KYCEmployeeName { get; set; }
        public string KYCEmployeeDesignation { get; set; }
        public string KYCVerificationBranch { get; set; }
        public string KYCEmployeeCode { get; set; }
        public string PermanentCKYCAddType { get; set; }
        public string PermanentCountry { get; set; }
        public string PermanentPin { get; set; }
        public string PermanentAddressLine1 { get; set; }
        public string PermanentAddressLine2 { get; set; }
        public string PermanentAddressLine3 { get; set; }
        public string PermanentDistrict { get; set; }
        public string PermanentCity { get; set; }
        public string PermanentState { get; set; }
        public string PermanentAddressProof { get; set; }
        public string CorrespondenceGlobalCountry { get; set; }
        public string CorrespondencePin { get; set; }
        public string CorrespondenceAddressLine1 { get; set; }
        public string CorrespondenceAddressLine2 { get; set; }
        public string CorrespondenceAddressLine3 { get; set; }
        public string CorrespondenceGlobalDistrict { get; set; }
        public string CorrespondenceGlobalCity { get; set; }
        public string CorrespondenceGlobalState { get; set; }
        public string JurisdictionOfResidence { get; set; }
        public string CountryOfBirth { get; set; }
        public string BirthCity { get; set; }
        public string TaxIdentificationNumber { get; set; }
        public string TaxResidencyAddressLine1 { get; set; }
        public string TaxResidencyAddressLine2 { get; set; }
        public string TaxResidencyAddressLine3 { get; set; }
        public string TaxResidencyPin { get; set; }
        public string TaxResidencyDistrict { get; set; }
        public string TaxResidencyCity { get; set; }
        public string TaxResidencyState { get; set; }
        public string TaxResidencyCountry { get; set; }
        public string ResidentialSTDCode { get; set; }
        public string ResidentialTelephoneNumber { get; set; }
        public string OfficeSTDCode { get; set; }
        public string OfficeTelephoneNumber { get; set; }
        public string MobileISD { get; set; }
        public string MobileNumber { get; set; }
        public string FaxSTD { get; set; }
        public string FaxNumber { get; set; }
        public string CKYCID { get; set; }
        public string PassportNumber { get; set; }
        public string PassportExpiryDate { get; set; }
        public string VoterIdCard { get; set; }
        public string PAN { get; set; }
        public string DrivingLicenseNumber { get; set; }
        public string DrivingLicenseExpiryDate { get; set; }
        public string Aadhaar { get; set; }
        public string NREGA { get; set; }
        public string CKYCPOIOtherCentralGovtID { get; set; }
        public string CKYCPOIS01IDNumber { get; set; }
        public string CKYCPOIS02IDNumber { get; set; }
        public string ProofOfIDSubmitted { get; set; }
        public string CustomerDemiseDate { get; set; }
        public string Minor { get; set; }
        public string SourcesystemRelatedPartycode { get; set; }
        public string RelatedPersonType { get; set; }
        public string RelatedPersonPrefix { get; set; }
        public string RelatedPersonFirstName { get; set; }
        public string RelatedPersonMiddleName { get; set; }
        public string RelatedPersonLastName { get; set; }
        public string RelatedPersonCKYCID { get; set; }
        public string RelatedPersonPassportNumber { get; set; }
        public string RelatedPPassportExpiryDate { get; set; }
        public string RelatedPersonVoterIdCard { get; set; }
        public string RelatedPersonPAN { get; set; }
        public string RelatedPDrivingLicenseNumber { get; set; }
        public string RelatedPDrivingLicExpiryDate { get; set; }
        public string RelatedPersonAadhaar { get; set; }
        public string RelatedPersonNREGA { get; set; }
        public string RelatedPCKYCPOICentralGovtID { get; set; }
        public string RelatedPCKYCPOIS01IDNumber { get; set; }
        public string RelatedPCKYCPOIS02IDNumber { get; set; }
        public string RelatedPProofOfIDSubmitted { get; set; }
        public string SourceSystemSegment { get; set; }
        public string AppRefNumberforImages { get; set; }
        public string HolderforImages { get; set; }
        public string BranchCode { get; set; }
        #endregion public properties

        #region method
        public void Add(Client objClient)
        {
            ClientAddress objPerAddress = new ClientAddress();
            ClientAddress objCorrAddress = new ClientAddress();

            objPerAddress = objClient.oClientAddresses.GetAddressByType(Client_AddressType.Registered);//for permanat address
            objCorrAddress = objClient.oClientAddresses.GetAddressByType(Client_AddressType.Correspondence);//for Correspondant address

            int[] arrRelationShipNo = { 98, 99, 100, 0, 201, 202, 203 };
            
            
            //DPM Client ID  + Holder Indicator + System date for data extract
            
            TransactionID = objClient.BOID+CKYCDataProvider.HolderIndicator + DateTime.Today.ToString("ddMMyyy");
            
            SourceSystemName = CKYCDataProvider.SourceSystemName;

            SourcesystemCustCode = objClient.BOID;
            if (SourcesystemCustCode != null)
                SourcesystemCustCode = SourcesystemCustCode + "_1";
            SmallCustomer = CKYCDataProvider.SmallCustomer;
            EkycOTPbased = CKYCDataProvider.EkycOTPbased;
            TransactionType = CKYCDataProvider.TransactionType;

            CustomerCreationDate = objClient.CreationDate.ToString();
            if (!String.IsNullOrEmpty(CustomerCreationDate))
                CustomerCreationDate = DateTime.Parse(CustomerCreationDate).ToString(CKYCDataProvider.DateFormat);
            //ModificationDate
            UniqueCustomerCode = objClient.UCCCode;
            ConstitutionType = CKYCDataProvider.ConstitutionType;
            Prefix = objClient.ClientTitle.TrimEnd('.').ToUpper();
            FirstName = objClient.ClientName;
            MiddleName = objClient.MiddleName;
            LastName = objClient.LastName;
            //MaidenPrefix
            if (!string.IsNullOrEmpty(objClient.MaidenName) && (objClient.MaidenName.Length > 0 || objClient.MaidenName.Contains(" ")))
            {
                string[] arrMaidenName = objClient.MaidenName.Split(' ');
                if (arrMaidenName.Count() > 0)
                {
                    MaidenFirstName = arrMaidenName[0];
                }
                if (arrMaidenName.Count() > 1)
                {
                    MaidenLastName = arrMaidenName[arrMaidenName.Count() - 1];
                }
                if (arrMaidenName.Count() > 2)
                {
                    MaidenMiddleName = arrMaidenName[1];
                }
            }
            
            FatherPrefix = Title.MR.ToString();
            if (!string.IsNullOrEmpty(objClient.GuardianName) && (objClient.GuardianName.Length > 0 || objClient.GuardianName.Contains(" ")))
            {
                string[] Fathername = objClient.GuardianName.Split(' ');
                if (Fathername.Count() > 0)
                {
                    FatherFirstName = Fathername[0];
                    FatherLastName = objClient.LastName;
                }
                if (Fathername.Count() > 1)
                {
                    FatherLastName = Fathername[Fathername.Count() - 1];
                }
                if (Fathername.Count() > 2)
                {
                    FatherMiddleName = Fathername[1];
                }
            }
            
            //SpousePrefix
            //SpouseFirstName
            //SpouseMiddleName
            //SpouseLastName

            MotherPrefix = Title.MRS.ToString();
            MotherFirstName = objClient.MotherName;
            if (!string.IsNullOrEmpty(objClient.MotherName) && (objClient.MotherName.Length > 0 || objClient.MotherName.Contains(" ")))
            {
                string[] arrMothername = objClient.MotherName.Split(' ');
                if (arrMothername.Count() > 0)
                {
                    MotherFirstName = arrMothername[0];
                    MotherLastName = objClient.LastName;
                }
                if (arrMothername.Count() > 1)
                {
                    MotherLastName = arrMothername[arrMothername.Count() - 1];
                }
                if (arrMothername.Count() > 2)
                {
                    MotherMiddleName = arrMothername[1];
                }
            }
            Gender = CKYCDataProvider.GetGender(objClient.Gender);
            MaritalStatus = CKYCDataProvider.GetMaritalStatus(objClient.MaritalStatus);
            Citizenship = CKYCDataProvider.Citizenship;
            OccupationType = CKYCDataProvider.GetOccupationType(objClient.Occupation);
            DateofBirth = objClient.DOB.ToString();
            if (!String.IsNullOrEmpty(DateofBirth))
                DateofBirth = DateTime.Parse(DateofBirth).ToString(CKYCDataProvider.DateFormat);
            ResidentialStatus = objClient.Status.ToString();
            KYCDateOfDeclaration = objClient.CreationDate.ToString();
            if (!String.IsNullOrEmpty(KYCDateOfDeclaration))
                KYCDateOfDeclaration = DateTime.Parse(KYCDateOfDeclaration).ToString(CKYCDataProvider.DateFormat);
            KYCPlaceOfDeclaration = CKYCDataProvider.KYCBranchPlace; // objClient.Branch;
            KYCVerificationDate = objClient.AuthorizeDatetime.ToString();
            if (!String.IsNullOrEmpty(KYCVerificationDate))
                KYCVerificationDate = DateTime.Parse(KYCVerificationDate).ToString(CKYCDataProvider.DateFormat);
            KYCEmployeeName = objClient.UserRMEmpCode;
            KYCEmployeeDesignation = CKYCDataProvider.KYCEmployeeDesignation;// objClient.UserRMDesignation;
            KYCVerificationBranch = CKYCDataProvider.KYCBranchPlace;//objClient.Branch;
            KYCEmployeeCode = objClient.UserName;

            if (objPerAddress != null)
            {
                //if (objPerAddress.AddressLine1.Length > 36)
                //    objPerAddress.AddressLine1 = objPerAddress.AddressLine1.Substring(0, 36);
                PermanentAddressLine1 =  Process.RemoveSpecialCharFromString(objPerAddress.AddressLine1);
                //if (objPerAddress.AddressLine2.Length > 36)
                //    objPerAddress.AddressLine2 = objPerAddress.AddressLine2.Substring(0, 36);
                PermanentAddressLine2 =  Process.RemoveSpecialCharFromString(objPerAddress.AddressLine2);
                //if (objPerAddress.AddressLine3.Length > 36)
                //    objPerAddress.AddressLine3 = objPerAddress.AddressLine3.Substring(0, 36);
                PermanentAddressLine3 =  Process.RemoveSpecialCharFromString(objPerAddress.AddressLine3);
                EmailId = objPerAddress.EMailId;
                PermanentCity = objPerAddress.City;
                //PermanentState = objPerAddress.StateName;
                PermanentCountry = objPerAddress.CountryName;
                PermanentPin = objPerAddress.PinCode;

                ResidentialSTDCode = objPerAddress.TelNoSTDCode;
                //ResidentialTelephoneNumber = objPerAddress.TelNo1;
                OfficeSTDCode = objPerAddress.TelNoOfficeSTDCode;
                OfficeTelephoneNumber = objPerAddress.TelNoOffice;
                MobileNumber = objPerAddress.Mobile1;
                FaxSTD = objPerAddress.FaxNoSTDCode;
                FaxNumber = objPerAddress.FaxNo;

                if (objPerAddress.SameCorrPermAdd == "Y")
                {
                    CorrespondenceAddressLine1 =  Process.RemoveSpecialCharFromString(objPerAddress.AddressLine1);
                    CorrespondenceAddressLine2 =  Process.RemoveSpecialCharFromString(objPerAddress.AddressLine2);
                    CorrespondenceAddressLine3 =  Process.RemoveSpecialCharFromString(objPerAddress.AddressLine3);
                    CorrespondencePin = objPerAddress.PinCode;
                    //CorrespondenceGlobalDistrict
                    CorrespondenceGlobalCity = objPerAddress.City;
                    //CorrespondenceGlobalState = objPerAddress.StateName;
                    CorrespondenceGlobalCountry = objPerAddress.CountryName;
                }

                //TaxResidencyAddressLine1 = objPerAddress.AddressLine1.Replace(",", " ");
                //TaxResidencyAddressLine2 = objPerAddress.AddressLine2.Replace(",", " ");
                //TaxResidencyAddressLine3 = objPerAddress.AddressLine3.Replace(",", " ");
                //TaxResidencyPin = objPerAddress.PinCode;
                ////TaxResidencyDistrict
                //TaxResidencyCity = objPerAddress.City;
                //TaxResidencyState = objPerAddress.StateName;
                //TaxResidencyCountry = objPerAddress.CountryName;
                PermanentCKYCAddType = CKYCDataProvider.PermanentCKYCAddType;

                //MobileISD
                //PermanentDistrict
            }
            if (objCorrAddress != null)
            {
                CorrespondenceAddressLine1 =  Process.RemoveSpecialCharFromString(objCorrAddress.AddressLine1);
                CorrespondenceAddressLine2 =  Process.RemoveSpecialCharFromString(objCorrAddress.AddressLine2);
                CorrespondenceAddressLine3 =  Process.RemoveSpecialCharFromString(objCorrAddress.AddressLine3);
                CorrespondencePin = objCorrAddress.PinCode;
                //CorrespondenceGlobalDistrict
                CorrespondenceGlobalCity = objCorrAddress.City;
                //CorrespondenceGlobalState = objCorrAddress.StateName;
                CorrespondenceGlobalCountry = objCorrAddress.CountryName;
            }

            JurisdictionOfResidence = CKYCDataProvider.JurisdictionOfResidence;

            CountryOfBirth = objClient.CountryOfBirth;
            BirthCity = objClient.CityOfBirth;
            //TaxIdentificationNumber = objClient.PANNo;
            Minor = CKYCDataProvider.Minor;
            ProofOfIDSubmitted = CKYCDataProvider.ProofOfIDSubmitted;
            PAN = objClient.PANNo;
            if (objClient.oClientProofDetails.ProofDetailsList.Count > 0)
            {
                foreach (ClientProofDetail objClientProofDetail in objClient.oClientProofDetails.ProofDetailsList)
                {
                    if (objClientProofDetail.ReferenceSubType == CKYCProof.PROOFADD.ToString())
                    {
                        PermanentAddressProof = CKYCDataProvider.GetPerProofOfAdd(objClientProofDetail.ProofType);

                        if (PermanentAddressProof.ToUpper() == "PASSPORT")
                        {
                            PassportNumber = objClientProofDetail.IssuePlaceOfProof;
                            try
                            {
                                if (!string.IsNullOrEmpty(objClientProofDetail.IssueDateOfProof))
                                    PassportExpiryDate = DateTime.Parse(objClientProofDetail.IssueDateOfProof).ToString(CKYCDataProvider.DateFormat);
                            }
                            catch
                            { 
                            }
                        }
                        if (PermanentAddressProof.ToUpper() == "DRIVINGLICENCE")
                        {
                            DrivingLicenseNumber = objClientProofDetail.IssuePlaceOfProof;
                            try
                            {
                                if (!string.IsNullOrEmpty(objClientProofDetail.IssueDateOfProof))
                                    DrivingLicenseExpiryDate = DateTime.Parse(objClientProofDetail.IssueDateOfProof).ToString(CKYCDataProvider.DateFormat);
                            }
                            catch
                            {
                            }
                        }
                        if (PermanentAddressProof.ToUpper() == "VOTERID")
                        {
                            VoterIdCard = objClientProofDetail.IssuePlaceOfProof;
                        }
                    }
                }
            }
            SourceSystemSegment = CKYCDataProvider.SourceSystemSegment;
            Aadhaar = objClient.UID;
            AppRefNumberforImages = objClient.PANNo;

            //CKYCID 
            //NREGA 
            //CKYCPOIOtherCentralGovtID
            //CKYCPOIS01IDNumber 
            //CKYCPOIS02IDNumber 
            //CustomerDemiseDate
            //SourcesystemRelatedPartycode
            //RelatedPersonType
            //RelatedPersonPrefix 
            //RelatedPersonFirstName
            //RelatedPersonMiddleName
            //RelatedPersonLastName
            //RelatedPersonCKYCID 
            //RelatedPersonPassportNumber
            //RelatedPPassportExpiryDate
            //RelatedPersonVoterIdCard
            //RelatedPersonPAN
            //RelatedPDrivingLicenseNumber
            //RelatedPDrivingLicExpiryDate
            //RelatedPersonAadhaar
            //RelatedPersonNREGA 
            //RelatedPCKYCPOICentralGovtID
            //RelatedPCKYCPOIS01IDNumber 
            //RelatedPCKYCPOIS02IDNumber 
            //RelatedPProofOfIDSubmitted
            //HolderforImages
            BranchCode = objClient.Branch;
        }
        #endregion method
    }
}
