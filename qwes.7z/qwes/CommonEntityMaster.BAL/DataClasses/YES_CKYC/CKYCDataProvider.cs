﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTIL.Match.CDD.BAL.DataStore
{
    public static class CKYCDataProvider
    {
        #region variables
        public static string separator = "|";
        public static string SourceSystemName = "DPSECURE";
        public static string TransactionType = "New";
        public static string SmallCustomer = "NO";
        public static string EkycOTPbased = "NO";
        public static string ConstitutionType = "01";
        public static string Minor = "NO";
        public static string ProofOfIDSubmitted = "PAN";
        public static string Citizenship = "INDIA";
        public static string JurisdictionOfResidence = "IN";
        public static string PermanentCKYCAddType = "Residential";
        public static string SourceSystemSegment = "DEMAT";
        public static string KYCBranchPlace = "MUMBAI";// objClient.Branch;
        public static string KYCEmployeeDesignation = "RE";
        public static string HolderIndicator ="1";
        /// <summary>
        /// Date Format 'DD-MON-YYYY'
        /// </summary>
        public static readonly string DateFormat = "dd-MMM-yyyy";//FTIL.Match.Common.Constants.Formatting.Instance.SHORT_DATE_UNIVERSAL_FORMAT_PLAIN;
        #endregion variables

        #region Get Occupation by Type
        static Dictionary<int?, string> l_dictOccupation = new Dictionary<int?, string>
        {
            {4,"Business"},	         //B-01
            {5,"Professional"},	     //O-01	
            {10,"Self Employed"},    //O-02
            {7,"Retired"},	         //O-03
            {8,"Housewife"},	     //O-04
            {9,"Student"},	         //O-05
            {1,"Public Sector"},	 //S-01
            {2,"Private Sector"},	 //S-02
            {3,"Government Service"},//S-03
            {99,"NA"}	             //X-01
        };
        public static string GetOccupationType(int? Occupation)
        {
            string OccupationType;
            l_dictOccupation.TryGetValue(Occupation, out OccupationType);
            return OccupationType;
        }
        #endregion Get Occupation by Type

        #region GetDocumentCodeby by Doctype
        static Dictionary<int, string> l_dictDocumentCode = new Dictionary<int, string>
        {
            {8,"PAN"},

            {2,"Passport"},
            //{36,"Passport"},
            
            {7,"AadharCard"},
            //{38,"AadharCard"},
            
            //{4,"DrivingLicence"},
            {26,"DrivingLicence"},
            //{42,"DrivingLicence"},

            //{3,"VoterID"},
            {25,"VoterID"},
            //{41,"VoterID"},

            {5,"RationCard"},
            //{37,"RationCard"},

            {13,"Utilitybill2m"},
            //{39,"Utilitybill2m"},

            
            {24,"BankStatement"},
            //{19,"BankStatement"},
            //{40,"BankStatement"},
            
            {0,"Photo"}
            //{,"OthersPOICKYCInd "},
        };

        public static string GetDocumentCode(int DocType)
        {
            string DocCode = string.Empty;
            l_dictDocumentCode.TryGetValue(DocType, out DocCode);
            return DocCode;
        }
        #endregion GetDocumentCodeby by Doctype

        #region Get Gender by Type
        static Dictionary<string, string> l_dictGender = new Dictionary<string, string>
        {
               {"M","Male"}, 
               {"F","Female"}, 
               {"O","Transgender"}
        };
        public static string GetGender(string GenderCode)
        {
            string GenderValue;
            l_dictGender.TryGetValue(GenderCode, out GenderValue);
            return GenderValue;
        }
        #endregion Get Gender by Type

        #region Get Marital Status by Type
        static Dictionary<string, string> l_dictMaritalStatus = new Dictionary<string, string>
        {
            {"M","Married"},
            {"S","UnMarried"},
            {"W","Others"},
            {"D","Others"},
            {"NA","Others"}
        };
        public static string GetMaritalStatus(string MaritalStatusCode)
        {
            string MaritalStatusValue;
            l_dictMaritalStatus.TryGetValue(MaritalStatusCode, out MaritalStatusValue);
            return MaritalStatusValue;
        }
        #endregion Get  Marital Status by Type

        #region Get per proof of add
        static Dictionary<int, string> l_dictPerAddProof = new Dictionary<int, string>
        {
            {7,"AadharCard"},
            {2,"Passport"},
            {26,"DrivingLicence"},
            {25,"VoterID"},
            {5,"RationCard"},
            {24,"BankStatement"},
            {13,"Utilitybill2m"}
            //{,"NREGA"},
            //{,"Utilitybill2m"},
            //{,"PropertyTax"},
            //{,"PensionOrder"},
            //{,"EmployerHouseLetter"},
            //{,"ForeignEmbassyLetter"},
        };
        public static string GetPerProofOfAdd(int PerAddCode)
        {
            string PerAddProof;
            l_dictPerAddProof.TryGetValue(PerAddCode, out PerAddProof);
            return PerAddProof;
        }
        #endregion Get per proof of add

    }

    /// <summary>
    /// CKYC Address Type
    /// </summary>
    public enum CKYCAddressType
    {
        ResidentialOrBusiness = 1,
        Residential = 2,
        Business = 3,
        RegisteredOffice = 4,
        Unspecified = 5
    }

    public enum CKYCProof
    {
        PROOFADD,
        PROOFAUTHA,
        PROOFBANK,
        PROOFCOADD,
        PROOFDP,
        PROOFFIN,
        PROOFIDEN,
        PROOFINTA,
        PROOFNOM,
        PROOFNOMA,
        PROOFPOA,
        PROOFSIG,
        PROOFSLFIE,
        PROOFW1PHO,
        PROOFW1SIG,
        PROOFW2PHO,
        PROOFW2SIG
    }
}
