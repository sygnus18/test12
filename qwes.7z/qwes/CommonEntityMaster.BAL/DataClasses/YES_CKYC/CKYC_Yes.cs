﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.CDD.BAL.DataClasses.CKYC;
using FTIL.Match.CDD.BAL.DataStore;
using FTIL.Match.Common.Log;

namespace FTIL.Match.CDD.BAL.DataStore
{
    public class CKYC_Yes
    {
        public static readonly string DATEFORMAT = "yyyyMMdd";
        public static string BaseDirectory = AppDomain.CurrentDomain.BaseDirectory.ToString();
        public static string CKYCPath = BaseDirectory + System.Configuration.ConfigurationManager.AppSettings["CKYCBulkUploadPath"];
        public static string CKYCFolderDownloadPath = System.Configuration.ConfigurationManager.AppSettings["CKYCBulkUploadPath"];
        public static readonly string FILEEXTENSION = ".csv";
        string sPath = string.Empty;
        string BatchNo = string.Empty;
        string sDownloadPath = string.Empty;
        string CKYCFolderPath = string.Empty;


        /// <summary>
        /// Genrate File
        /// </summary>
        /// <param name="objClients"></param>
        /// <returns></returns>
        public string GenrateFile(Clients objClients, CKYCReferenceData objCKYCReferenceData)
        {
            string resp = string.Empty;
            var CKYCDetails = new List<CKYCClientDetails_Yes>();
            StringBuilder sbClientDetail = new StringBuilder();
            CKYCClientDetails_Yes objDetail = new CKYCClientDetails_Yes();
            if (objCKYCReferenceData.BatchNo != null && objCKYCReferenceData.BatchNo != "0")
                BatchNo = objCKYCReferenceData.BatchNo;
            else
            {
                BatchNo = Process.GetFixLenString(objClients.BatchNo.ToString(), 4, '0');
                objCKYCReferenceData.BatchNo = Process.GetFixLenString(objClients.BatchNo.ToString(), 4, '0');
            }
            Type t = typeof(CKYCClientDetails_Yes);
            PropertyInfo[] fields = t.GetProperties();
            DateTime dCurrentDate = DateTime.Now;

            string CKYCFolderName = dCurrentDate.ToString(DATEFORMAT) + "_CKYC";
            CKYCFolderPath = CKYCPath + CKYCFolderName + "\\";

            //create Folder if not exists
            FileInfo fileinfo = new FileInfo(CKYCFolderPath);
            if (!fileinfo.Exists)
                Directory.CreateDirectory(fileinfo.Directory.FullName);

            sPath = CKYCFolderPath + dCurrentDate.ToString(DATEFORMAT) + "_CKYC" + FILEEXTENSION;
            objCKYCReferenceData.FileName = dCurrentDate.ToString(DATEFORMAT) + "_CKYC" + FILEEXTENSION;
            sDownloadPath = CKYCFolderDownloadPath + CKYCFolderName + ".zip"; ;

            //Delete existing file if exists
            if (File.Exists(sPath))
            {
                File.Delete(sPath);
            }

            //Write data in to file. 
            using (StreamWriter swCKYCFileNew = File.CreateText(sPath))
            {
                swCKYCFileNew.WriteLine(Process.ToCsvHeaderFields(CKYCDataProvider.separator, fields, objDetail));

                foreach (Client oClient in objClients.objClients)
                {
                    StringBuilder sbBodyDetails = new StringBuilder();
                    // oClient.LineNo = ++LineNo;
                    ImageDetails(oClient, CKYCFolderPath);
                    objDetail.Add(oClient);
                    sbBodyDetails.Append(Process.ToCsvFields(CKYCDataProvider.separator, fields, objDetail));
                    swCKYCFileNew.WriteLine(sbBodyDetails.ToString());
                }
            }
            //Zip Attachted Documnets.
            Process.CreateZipFile(CKYCPath, CKYCFolderName, null, ref resp);

            string res = Process.ToCsv(CKYCDataProvider.separator, CKYCDetails);
            return sDownloadPath;
        }

        public void ImageDetails(Client objClient, string FolderPath)
        {
            try
            {
                string resp = string.Empty;
                if (objClient.oClientImageDetails.ClientImgDetailList.Count > 0)
                {
                    //string ImgFolderPath = ClientWiseStoreData(objClient.ClientNo, FolderPath);
                    if (FolderPath != string.Empty)
                        foreach (ClientImageDetail objClientImageDetail in objClient.oClientImageDetails.ClientImgDetailList)
                        {
                            string ext = Path.GetExtension(objClientImageDetail.ImageName);

                            string DocCode = CKYCDataProvider.GetDocumentCode(objClientImageDetail.ImageType);
                            if (DocCode != null)
                            {
                                string s_FileName = objClient.PANNo.ToString() + "_" + DocCode + ext;
                                File.WriteAllBytes(FolderPath + s_FileName, objClientImageDetail.l_bImage);
                            }
                        }

                    //Create Clientwise zip file to store images.
                    //Process.CreateZipFile(FolderPath, objClient.ClientNo.ToString(), null, ref resp);
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "ImageDetails() Error while Adding  Image Details .Client no :" + objClient.ClientNo, ex);
                throw ex;
            }
        }

        #region  Clientwise Data Store Path
        public string ClientWiseStoreData(int ClientNo, string FolderPath)
        {
            string ImgFolderPath = string.Empty;
            try
            {
                string sFolderName = ClientNo.ToString();
                ImgFolderPath = FolderPath + "\\" + sFolderName + "\\";

                FileInfo fileinfo = new FileInfo(ImgFolderPath);
                if (!fileinfo.Exists)
                    Directory.CreateDirectory(fileinfo.Directory.FullName);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "ClientWiseStoreData() Error while Adding  Clientwise Data Store Path .Client no :" + ClientNo, ex);
                throw ex;
            }
            return ImgFolderPath;
        }
        #endregion  Clientwise Data Store Path
    }
}
