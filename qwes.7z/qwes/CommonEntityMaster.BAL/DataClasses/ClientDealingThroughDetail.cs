﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FTIL.Match.Common.Log;
using UCC.Class;

namespace FTIL.Match.CDD.BAL.DataClasses
{
    public class ClientDealingThroughDetail
    {
        #region public properties
        public int ClientDealingThroughNo { get; set; }
        public int ClientNo { get; set; }
        public int Flag { get; set; }
        public string SubBrokerName { get; set; }
        public string ExchangeName { get; set; } 
        public string ClientCode { get; set; }
        public string SebiRegNo { get; set; }
        public int Ammount { get; set; }
        public string Remarks { get; set; }
        public DateTime LastModifiedDateTime { get; set; }
        #endregion public properties

        #region methods
        /// <summary>
        /// Initializes current instance from DataRow
        /// </summary>
        /// <param name="DataRow">DataRow object containing client Trading details</param>
        #region InitializeFromDataRow
        public void InitializeFromDataRow(DataRow dataRow)
        {
            try
            {
                if ((dataRow["n_ClientNo"] != null) && (dataRow["n_ClientNo"] != DBNull.Value))
                    this.ClientNo = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_ClientNo"));
                if ((dataRow["n_ClientDealingThroughNo"] != null) && (dataRow["n_ClientDealingThroughNo"] != DBNull.Value))
                    this.ClientDealingThroughNo = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_ClientDealingThroughNo"));

                if ((dataRow["n_Flag"] != null) && (dataRow["n_Flag"] != DBNull.Value))
                    this.Flag = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_Flag"));
               
                //if ((dataRow["s_SubBrokerName"] != null) && (dataRow["s_SubBrokerName"] != DBNull.Value))
                    this.SubBrokerName = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_SubBrokerName"));

                //if ((dataRow["s_ExchangeName"] != null) && (dataRow["s_ExchangeName"] != DBNull.Value))
                    this.ExchangeName = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_ExchangeName"));

                // if ((dataRow["s_ClientCode"] != null) && (dataRow["s_ClientCode"] != DBNull.Value))
                    this.ClientCode = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_ClientCode"));

                //if ((dataRow["s_SebiRegNo"] != null) && (dataRow["s_SebiRegNo"] != DBNull.Value))
                    this.SebiRegNo = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_SebiRegNo"));

                 if ((dataRow["n_Ammount"] != null) && (dataRow["n_Ammount"] != DBNull.Value))
                    this.Ammount = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_Ammount"));

                //if ((dataRow["s_Remarks"] != null) && (dataRow["s_Remarks"] != DBNull.Value))
                    this.Remarks = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_Remarks"));

                if ((dataRow["d_LastModifiedDateTime"] != null) && (dataRow["d_LastModifiedDateTime"] != DBNull.Value))
                    this.LastModifiedDateTime = Convert.ToDateTime(Utility.GetValueFromDataRow(dataRow, "d_LastModifiedDateTime"));
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                throw ex;
            }
        }
        #endregion
        #endregion methods
    }
}
