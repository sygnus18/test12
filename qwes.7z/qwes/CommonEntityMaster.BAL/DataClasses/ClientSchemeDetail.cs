﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FTIL.Match.Common.Log;
using UCC.Class;

namespace FTIL.Match.CDD.BAL.DataStore
{
    public class ClientSchemeDetail
    {
        public int SchemeNo { get; set; }
        public int ClientNo { get; set; }
        public string SchemeAmount { get; set; }
        public string Amount { get; set; }
        public string PaymentType { get; set; }
        public string SchemeName { get; set; }
        public string EquityAmount { get; set; }
        public string CommodityAmount { get; set; }
        public string AmountFlag { get; set; }
        public string Chqno_Trnsno { get; set; }
        public string WEB { get; set; }
        public string EXE { get; set; }
        public string MOB { get; set; }
        public int NSECM { get; set; }
        public int BSECM { get; set; }
        public int MSEICM { get; set; }
        public int NSEFO { get; set; }
        public int BSEFO { get; set; }
        public int MSEIFO { get; set; }
        public int NSE_SX { get; set; }
        public int BSE_SX { get; set; }
        public int MSEI_SX { get; set; }
        public int NCDEX { get; set; }
        public int MCX { get; set; }
        public int NMCE { get; set; }




        /// <summary>
        /// Initializes current instance from DataRow
        /// </summary>
        /// <param name="DataRow">DataRow object containing client proof details</param>
        #region InitializeFromDataRow
        public void InitializeFromDataRow(DataRow dataRow)
        {
            try
            {
                if ((dataRow["n_ClientNo"] != null) && (dataRow["n_ClientNo"] != DBNull.Value))
                    this.ClientNo = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_ClientNo"));
                if ((dataRow["n_SchemeNo"] != null) && (dataRow["n_SchemeNo"] != DBNull.Value))
                    this.SchemeNo = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_SchemeNo"));
                if ((dataRow["n_ClientNo"] != null) && (dataRow["n_ClientNo"] != DBNull.Value))
                    if ((dataRow["n_SchemeAmount"] != null) && (dataRow["n_SchemeAmount"] != DBNull.Value))
                    this.SchemeAmount = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "n_SchemeAmount"));
                if ((dataRow["n_Amount"] != null) && (dataRow["n_Amount"] != DBNull.Value))
                    this.Amount = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "n_Amount"));
                if ((dataRow["s_PaymentType"] != null) && (dataRow["s_PaymentType"] != DBNull.Value))
                    this.PaymentType = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_PaymentType"));
                if ((dataRow["s_SchemeName"] != null) && (dataRow["s_SchemeName"] != DBNull.Value))
                    this.SchemeName = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_SchemeName"));
                if ((dataRow["n_EquityAmount"] != null) && (dataRow["n_EquityAmount"] != DBNull.Value))
                    this.EquityAmount = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "n_EquityAmount"));
                if ((dataRow["n_CommodityAmount"] != null) && (dataRow["n_CommodityAmount"] != DBNull.Value))
                    this.CommodityAmount = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "n_CommodityAmount"));
                if ((dataRow["n_AmountFlag"] != null) && (dataRow["n_AmountFlag"] != DBNull.Value))
                    this.AmountFlag = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "n_AmountFlag"));
                if ((dataRow["s_Chqno_Trnsno"] != null) && (dataRow["s_Chqno_Trnsno"] != DBNull.Value))
                    this.Chqno_Trnsno = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_Chqno_Trnsno"));
                if ((dataRow["WEB"] != null) && (dataRow["WEB"] != DBNull.Value))
                    this.WEB = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "WEB"));
                if ((dataRow["EXE"] != null) && (dataRow["EXE"] != DBNull.Value))
                    this.EXE = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "EXE"));
                if ((dataRow["MOB"] != null) && (dataRow["MOB"] != DBNull.Value))
                    this.MOB = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "MOB"));
                if ((dataRow["NSECM"] != null) && (dataRow["NSECM"] != DBNull.Value))
                    this.NSECM = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "NSECM"));
                if ((dataRow["BSECM"] != null) && (dataRow["BSECM"] != DBNull.Value))
                    this.BSECM = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "BSECM"));
                if ((dataRow["MSEICM"] != null) && (dataRow["MSEICM"] != DBNull.Value))
                    this.MSEICM = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "MSEICM"));
                if ((dataRow["NSEFO"] != null) && (dataRow["NSEFO"] != DBNull.Value))
                    this.NSEFO = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "NSEFO"));
                if ((dataRow["BSEFO"] != null) && (dataRow["BSEFO"] != DBNull.Value))
                    this.BSEFO = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "BSEFO"));
                if ((dataRow["MSEIFO"] != null) && (dataRow["MSEIFO"] != DBNull.Value))
                    this.MSEIFO = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "MSEIFO"));
                if ((dataRow["NSE_SX"] != null) && (dataRow["NSE_SX"] != DBNull.Value))
                    this.NSE_SX = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "NSE_SX"));
                if ((dataRow["BSE_SX"] != null) && (dataRow["BSE_SX"] != DBNull.Value))
                    this.BSE_SX = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "BSE_SX"));
                if ((dataRow["MSEI_SX"] != null) && (dataRow["MSEI_SX"] != DBNull.Value))
                    this.MSEI_SX = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "MSEI_SX"));
                if ((dataRow["NCDEX"] != null) && (dataRow["NCDEX"] != DBNull.Value))
                    this.NCDEX = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "NCDEX"));
                if ((dataRow["MCX"] != null) && (dataRow["MCX"] != DBNull.Value))
                    this.MCX = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "MCX"));
                if ((dataRow["NMCE"] != null) && (dataRow["NMCE"] != DBNull.Value))
                    this.NMCE = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "NMCE"));

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                throw ex;
            }
        }
        #endregion

    }
}
