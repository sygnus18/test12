﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTIL.Match.CDD.BAL.DataClasses
{
    public class ClientTradingDetails
    {
        #region class variables
        /// <summary>
        /// List of ClientTradingDetail 
        /// </summary>
        private List<ClientTradingDetail> m_TradingDetailList;
        #endregion class variables

        #region Constructor

        public ClientTradingDetails()
        {
            m_TradingDetailList = new List<ClientTradingDetail>();
        }
        
        #endregion

        #region Properties

        /// <summary>
        /// Trading Detail List
        /// </summary>
        public List<ClientTradingDetail> TradingDetailList
        {
            get { return m_TradingDetailList; }
            set { m_TradingDetailList = value; }
        }
        #endregion Properties

        #region Public methods

        /// <summary>
        /// Add new Trading Detail
        /// </summary>
        /// <param name="oClientImageDetail">Trading Detail Object filled with details</param>
        /// <returns>0 - Success, -1 - Failed</returns>
        public int Add(ClientTradingDetail oClientTradingDetail)
        {
            int oResult = m_TradingDetailList.FindIndex(obj => obj.ClientNo == oClientTradingDetail.ClientNo);

            if (oResult != 0)
            {
                m_TradingDetailList.Add(oClientTradingDetail);
                return 0;
            }
            else
            {
                return -1;
            }
        }


        #endregion Public methods
    }
}
