﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FTIL.Match.Common.Log;
using UCC.Class;

namespace FTIL.Match.CDD.BAL.DataStore
{
    public class ClientProofDetail
    {
        #region Constructor
        public ClientProofDetail()
        {
        }
        #endregion Constructor

        #region Properties
        
        public int ClientNo { get; set; }
        public int ProofType { get; set; }
        public int ExNo { get; set; }
        public string ProofNumber { get; set; }
        public string IssuePlaceOfProof { get; set; }
        public string IssueDateOfProof { get; set; }
        
        public int EntityDocNo { get; set; } //for CKYC
        public string ProofProvided { get; set; } //for CKYC
        public string DateOfExpiry { get; set; } //for CKYC
        public string DocCode { get; set; } //for CKYC
        public string Details { get; set; } //for CKYC
        public string ReferenceSubType { get; set; } //for CKYC
        #endregion Properties

        /// <summary>
        /// Initializes current instance from DataRow
        /// </summary>
        /// <param name="DataRow">DataRow object containing client proof details</param>
        #region InitializeFromDataRow
        public void InitializeFromDataRow(DataRow dataRow)
        {
            try
            {
                if ((dataRow["n_ClientNo"] != null) && (dataRow["n_ClientNo"] != DBNull.Value))
                this.ClientNo = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_ClientNo"));
                if ((dataRow["s_ProofType"] != null) && (dataRow["s_ProofType"] != DBNull.Value))
                this.ProofType = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "s_ProofType"));
                //if ((dataRow["n_ExNo"] != null) && (dataRow["n_ExNo"] != DBNull.Value))
                //this.ExNo = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_ExNo"));
                this.ProofNumber = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_ProofNumber"));
                this.IssuePlaceOfProof = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_IssuePlaceOfProof"));
                this.IssueDateOfProof = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "d_IssueDateOfProof"));

                if ((dataRow["n_EntityDocNo"] != null) && (dataRow["n_EntityDocNo"] != DBNull.Value))
                this.EntityDocNo = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_EntityDocNo"));//for CKYC
                this.ProofProvided = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_ProofProvided"));//for CKYC
                this.DateOfExpiry = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "d_DateOfExpiry"));//for CKYC
                this.DocCode = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_Code"));//for CKYC
                if (dataRow.Table.Columns.Contains("s_Details") == true && (dataRow["s_Details"] != null) && (dataRow["s_Details"] != DBNull.Value))
                    this.Details = dataRow["s_Details"].ToString().Trim();
                if (dataRow.Table.Columns.Contains("s_ReferenceSubType") == true && (dataRow["s_ReferenceSubType"] != null) && (dataRow["s_ReferenceSubType"] != DBNull.Value))
                    this.ReferenceSubType = dataRow["s_ReferenceSubType"].ToString().Trim();
                
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                throw ex;
            }
        }
        #endregion
    }
}
