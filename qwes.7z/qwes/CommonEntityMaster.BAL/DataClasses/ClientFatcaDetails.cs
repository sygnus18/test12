﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTIL.Match.CDD.BAL.DataClasses
{
    public class ClientFatcaDetails
    {
        #region class variables
        /// <summary>
        /// List of ClientFatcaDetail 
        /// </summary>
        private List<ClientFatcaDetail> m_FatcaDetailList;
        #endregion class variables

        #region Constructor
        public ClientFatcaDetails()
        {
            m_FatcaDetailList = new List<ClientFatcaDetail>();
        }
        #endregion

        #region Properties

        /// <summary>
        /// Client Fatca Detail
        /// </summary>
        public List<ClientFatcaDetail> FatcaDetailList
        {
            get { return m_FatcaDetailList; }
            set { m_FatcaDetailList = value; }
        }
        #endregion Properties

        #region Public methods

        /// <summary>
        /// Add new Fatca Detail
        /// </summary>
        /// <param name="oClientFatcaDetail">Trading Detail Object filled with details</param>
        /// <returns>0 - Success, -1 - Failed</returns>
        public int Add(ClientFatcaDetail oClientFatcaDetail)
        {
            int oResult = m_FatcaDetailList.FindIndex(obj => obj.ClientNo == oClientFatcaDetail.ClientNo);

            if (oResult != 0)
            {
                m_FatcaDetailList.Add(oClientFatcaDetail);
                return 0;
            }
            else
            {
                return -1;
            }
        }


        #endregion Public methods
    }
}
