﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace FTIL.Match.CDD.BAL.DataClasses
{
    public class cFatcaDetails
    {
        public cFatcaDetails()
        {
            dtFatcaDetailshResult = new DataTable();

            dtFatcaDetailshResult.Columns.Add("n_FatcaDetailNo", typeof(int));
            dtFatcaDetailshResult.Columns.Add("n_USCitizen", typeof(int));
            dtFatcaDetailshResult.Columns.Add("n_OtherCitizen", typeof(int));
            dtFatcaDetailshResult.Columns.Add("s_BirthPlace", typeof(string));
            dtFatcaDetailshResult.Columns.Add("s_CountryPlace", typeof(string));
            dtFatcaDetailshResult.Columns.Add("n_TaxResidentFlag", typeof(int));
            dtFatcaDetailshResult.Columns.Add("s_TaxResidentCountry", typeof(string));
            dtFatcaDetailshResult.Columns.Add("s_TaxIdNo", typeof(string));
            dtFatcaDetailshResult.Columns.Add("s_IdentificationType", typeof(string));
            dtFatcaDetailshResult.Columns.Add("s_HasChanged", typeof(string));
            dtFatcaDetailshResult.Columns.Add("d_LastModifiedDateTime", typeof(string));
        }

         public int FatcaDetailNo { get; set; }
         public int USCitizen { get; set; }
         public int OtherCitizen { get; set; }
         public string BirthPlace { get; set; }
         public string CountryPlace { get; set; }
         public int TaxResidentFlag { get; set; }
         public string TaxResidentCountry { get; set; }
         public string TaxIdNo { get; set; }
         public string IdentificationType { get; set; }
       
         public bool isValid { get; set; }
         public DateTime? dLastUpdatedDate { get; set; }
         public DataTable dtFatcaDetailshResult { get; set; }


         /// <summary>
         /// Sync. DataTable with properties/fields
         /// </summary>
         public void SetDataResult()
         {

             dtFatcaDetailshResult.Rows.Add(new object[] { FatcaDetailNo, USCitizen, OtherCitizen, BirthPlace, CountryPlace, TaxResidentFlag, TaxResidentCountry, TaxIdNo, IdentificationType, "Y", System.DateTime.Now });

         }
    }
}
