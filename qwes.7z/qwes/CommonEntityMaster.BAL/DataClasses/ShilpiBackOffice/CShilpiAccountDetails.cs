﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using FTIL.Match.CDD.BAL.DataClasses.CKYC;
using FTIL.Match.CDD.BAL.DataStore;
using FTIL.Match.Common.Log;

namespace FTIL.Match.CDD.BAL.DataClasses.ShilpiBackOffice
{
    public class CShilpiAccountDetails
    {
        #region variables
        string BatchNo = "0000";
        public StringBuilder sbBackOfficeAccountDetails;
        public static readonly string DATEFORMAT = "ddMMyyyy";
        public static string BaseDirectory = AppDomain.CurrentDomain.BaseDirectory.ToString();
        public static string BackOfficeFilePath = BaseDirectory + ConfigurationManager.AppSettings["ShilpiFilesPath"];

        public static string BackOfficeFileDownloadPath = ConfigurationManager.AppSettings["ShilpiFilesPath"];
        public static readonly string FILEEXTENSION = ".XML";
        string sBackOfficeFilePath = string.Empty;
        string sDownloadPath = string.Empty;
        string sBackOfficeFolderPath = string.Empty;
        string sBackOfficeFolderName = string.Empty;
        string sPath = string.Empty;
        #endregion variables

        #region public properties
        public string sDateOfCreation { get; set; }
        public string UserID { get; set; }
        public int LineNo { get; set; }
        #endregion public properties

        #region constructor
        public CShilpiAccountDetails(string sUserID)
        {
            sbBackOfficeAccountDetails = new StringBuilder();
            UserID = sUserID;
            LineNo = 0;
        }
        #endregion constructor

        /// <summary>
        /// Genarate Shilpi Back Office File
        /// </summary>
        /// <param name="objClients"></param>
        /// <param name="objCKYCReferenceData"></param>
        /// <returns></returns>
        public string GenarateShilpiBackOfficeFile(Clients objClients, CKYCReferenceData objCKYCReferenceData)
        {
            try
            {
                int TotalClients = objClients.objClients.Count();
                StringBuilder sbDPAccountOpeningDetails = new StringBuilder();
                DateTime dCurrentDate = DateTime.Now;
                string resp = string.Empty;

                if (objCKYCReferenceData.BatchNo != null && objCKYCReferenceData.BatchNo != "0")
                    BatchNo = objCKYCReferenceData.BatchNo;
                else
                {
                    BatchNo = Process.GetFixLenString(objClients.BatchNo.ToString(), 4, '0');
                    objCKYCReferenceData.BatchNo = Process.GetFixLenString(objClients.BatchNo.ToString(), 4, '0');
                }

                //create Folder if not exists
                FileInfo fileinfo = new FileInfo(BackOfficeFilePath);

                if (!fileinfo.Directory.Exists)
                    Directory.CreateDirectory(fileinfo.Directory.FullName);

                sBackOfficeFolderName = dCurrentDate.ToString(DATEFORMAT);
                string BatchFolderName = BatchNo.ToString();
                sBackOfficeFolderPath = BackOfficeFilePath + sBackOfficeFolderName + "\\" + BatchFolderName + "\\";
                sBackOfficeFilePath = sBackOfficeFolderPath + dCurrentDate.ToString("dd-MM-yyyy") + FILEEXTENSION;

                sDownloadPath = BackOfficeFileDownloadPath + sBackOfficeFolderName + "\\" + BatchFolderName + ".zip"; ;

                FileInfo ClientWisefileinfo = new FileInfo(sBackOfficeFolderPath);

                if (ClientWisefileinfo.Directory.Exists)
                    Directory.Delete(ClientWisefileinfo.Directory.FullName, true);

                Directory.CreateDirectory(ClientWisefileinfo.Directory.FullName);

                //Delete existing file if exists
                if (File.Exists(sBackOfficeFilePath))
                {
                    File.Delete(sBackOfficeFilePath);
                }

                XmlSerializer serializer = new XmlSerializer(typeof(root));
                XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
                ns.Add("", "");

                List<rootClientdetail> l_Client = new List<rootClientdetail>();
                root objroot = new root();

                //Write data in to file. 
                using (StreamWriter swBackOfficeFileNew = File.CreateText(sBackOfficeFilePath))
                {
                    foreach (Client oClient in objClients.objClients)
                    {
                        StringBuilder sbBackOfficeDetails = new StringBuilder();
                        oClient.LineNo = ++LineNo;
                        l_Client.Add(ClientDetailRecord(oClient));

                        //sbBackOfficeDetails.Append(ClientDetailRecord(oClient));
                        //swBackOfficeFileNew.Write(sbBackOfficeDetails.ToString());
                    }

                    objroot.clientdetail = l_Client.ToArray();
                    //FileStream s = new FileStream(s_Filepath, FileMode.Create);
                    serializer.Serialize(swBackOfficeFileNew, objroot, ns);
                    //s.Close();
                }
                //Zip Attachted Documnets.
                Process.CreateZipFile(BackOfficeFilePath + sBackOfficeFolderName, BatchFolderName, null, ref resp);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "GenarateShilpiBackOfficeFile() Error while Uploading Attachment.", ex);
                throw ex;
            }
            return sDownloadPath;
        }

        /// <summary>
        /// Genarate clientwise XML Node data.
        /// </summary>
        /// <param name="objClient"></param>
        /// <returns></returns>
        public rootClientdetail ClientDetailRecord(Client objClient)
        {
            string result = string.Empty;
            rootClientdetail objrootClientdetail = new rootClientdetail();
            try
            {
                ClientAddress objPerAddress = new ClientAddress();
                ClientAddress objCorrAddress = new ClientAddress();

                objPerAddress = objClient.oClientAddresses.GetAddressByType(Client_AddressType.Registered);//for permanat address
                objCorrAddress = objClient.oClientAddresses.GetAddressByType(Client_AddressType.Correspondence);//for Correspondant address

                int[] arrRelationShipNo = { 98, 99, 100, 201, 202, 203 };

                objrootClientdetail.dfappno = objClient.ClientNo.ToString();
                objrootClientdetail.dfdateentry = objClient.AuthorizeDatetime.ToString("dd-MM-yyyy");
                objrootClientdetail.cmbapptype = Process.GetFixLenString(((int)KycType.Individual).ToString(), 2, '0');
                objrootClientdetail.AccountType = Process.GetFixLenString(((int)enAccountType.Normal).ToString(), 2, '0');
                objrootClientdetail.cmbkraname = KRAAgency.NDML;
                objrootClientdetail.cmbprefixName = objClient.ClientTitle.TrimEnd('.').ToUpper();
                objrootClientdetail.dffirstname = objClient.ClientName;
                objrootClientdetail.dfmidname = objClient.MiddleName;
                objrootClientdetail.dflastname = objClient.LastName;
                objrootClientdetail.dffullname = objClient.ClientName + " " + objClient.MiddleName + " " + objClient.LastName;
                objrootClientdetail.cmbaddsame = "N";

                if (!string.IsNullOrEmpty(objClient.MotherName) && objClient.MotherName.Contains(" "))
                {
                    string[] arrName = objClient.MotherName.Split(' ');
                    if (arrName.Length > 0)
                    {
                        objrootClientdetail.dfMotherfirstname = arrName[0];
                    }
                    if (arrName.Length > 1)
                    {
                        objrootClientdetail.dfMotherlastname = arrName[arrName.Length - 1];
                    }
                    if (arrName.Length > 2)
                    {
                        for (int len = 1; len < arrName.Length; len++)
                        {
                            objrootClientdetail.dfMothermidname = objrootClientdetail.dfMothermidname + " " + arrName[len];
                        }
                    }
                }
                objrootClientdetail.dfmotherfullname = objClient.MotherName;

                //objrootClientdetail.cmbprefixMother

                if (!string.IsNullOrEmpty(objClient.MaidenName) && objClient.MaidenName.Contains(" "))
                {
                    string[] arrName = objClient.MaidenName.Split(' ');
                    if (arrName.Length > 0)
                    {
                        objrootClientdetail.dfMaidenfirstname = arrName[0];
                    }
                    if (arrName.Length > 1)
                    {
                        objrootClientdetail.dfMaidenlastname = arrName[arrName.Length - 1];
                    }
                    if (arrName.Length > 2)
                    {
                        for (int len = 1; len < arrName.Length; len++)
                        {
                            objrootClientdetail.dfMaidenmidname = objrootClientdetail.dfMaidenmidname + " " + arrName[len];
                        }
                    }
                }
                objrootClientdetail.dfMaidenfullname = objClient.MaidenName;
                objrootClientdetail.cmbfatherspouse = "01";

                //objrootClientdetail.cmbprefixfather
                //objrootClientdetail.cmbprefixfirstMaiden
                if (!string.IsNullOrEmpty(objClient.GuardianName) && objClient.GuardianName.Contains(" "))
                {
                    string[] arrName = objClient.GuardianName.Split(' ');
                    if (arrName.Length > 0)
                    {
                        objrootClientdetail.dffatherfirstname = arrName[0];
                    }
                    if (arrName.Length > 1)
                    {
                        objrootClientdetail.dffatherlastname = arrName[arrName.Length - 1];
                    }
                    if (arrName.Length > 2)
                    {
                        for (int len = 1; len < arrName.Length; len++)
                        {
                            objrootClientdetail.dffathermidname = objrootClientdetail.dffathermidname + " " + arrName[len];
                        }
                    }
                }

                objrootClientdetail.dffathername = objClient.GuardianName;
                objrootClientdetail.cmbgender = objClient.Gender == "U" ? "O" : objClient.Gender;
                if (objClient.MaritalStatus!=null)
                    objrootClientdetail.cmbmaritalstatus = CShilpiFileManager.GetMarriStatusType(objClient.MaritalStatus);
                objrootClientdetail.dfdatedob = objClient.DOB == null ? null : objClient.DOB.Value.ToString("dd-MM-yyyy");
                objrootClientdetail.dfpanno = objClient.PANNo;
                if (objClient.Status != null)
                    objrootClientdetail.cmbstatus = CShilpiFileManager.GetResStatusType(objClient.Status);
                objrootClientdetail.cmbnationality = Process.GetFixLenString(objClient.Nationality.ToString(), 2, '0');
                objrootClientdetail.cmbnationalityother = objClient.NationalityOther;
                if (objClient.GrAnnIncRange != null)
                    objrootClientdetail.cmbannualincome = objClient.GrAnnIncRange.ToString();
                if (objClient.PEP != null)
                    objrootClientdetail.cmbpep = CShilpiFileManager.GetPEPDetails(objClient.PEP);
                if (objClient.Occupation != null)
                    objrootClientdetail.cmbocc = Process.GetFixLenString(CShilpiFileManager.GetOccupationType(objClient.Occupation), 2, '0');

                

                #region Per address
                if (objPerAddress != null)
                {
                    objrootClientdetail.dfpadd1 = (string.IsNullOrWhiteSpace(objPerAddress.AddressLine1)) == true ? null : objPerAddress.AddressLine1;
                    objrootClientdetail.dfpadd2 = (string.IsNullOrWhiteSpace(objPerAddress.AddressLine2)) == true ? null : objPerAddress.AddressLine2;
                    objrootClientdetail.dfpadd3 = (string.IsNullOrWhiteSpace(objPerAddress.AddressLine3)) == true ? null : objPerAddress.AddressLine3;
                    objrootClientdetail.dfpcity = (string.IsNullOrWhiteSpace(objPerAddress.City)) == true ? null : objPerAddress.City;
                    objrootClientdetail.dfppincode = objPerAddress.PinCode;
                    //objrootClientdetail.dfpDistrict  
                    //objrootClientdetail.dfpproofrefno         

                    objrootClientdetail.cmbaddsame = (string.IsNullOrWhiteSpace(objPerAddress.SameCorrPermAdd)) == true ? "N" : objPerAddress.SameCorrPermAdd;
                    objrootClientdetail.dfoffisd = (string.IsNullOrWhiteSpace(objPerAddress.TelNoISDCode)) == true ? null : objPerAddress.TelNoISDCode;
                    objrootClientdetail.dfoffstd = (string.IsNullOrWhiteSpace(objPerAddress.TelNoOfficeSTDCode)) == true ? null : objPerAddress.TelNoOfficeSTDCode;
                    objrootClientdetail.dfoffnumber = (string.IsNullOrWhiteSpace(objPerAddress.TelNoOffice)) == true ? null : objPerAddress.TelNoOffice;
                    objrootClientdetail.dfresisd = (string.IsNullOrWhiteSpace(objPerAddress.TelNoISDCode)) == true ? null : objPerAddress.TelNoISDCode;
                    objrootClientdetail.dfresstd = (string.IsNullOrWhiteSpace(objPerAddress.TelNoSTDCode)) == true ? null : objPerAddress.TelNoSTDCode;
                    objrootClientdetail.dfresnumber = (string.IsNullOrWhiteSpace(objPerAddress.TelNo1)) == true ? null : objPerAddress.TelNo1;
                    objrootClientdetail.dfmobnumber = (string.IsNullOrWhiteSpace(objPerAddress.Mobile1)) == true ? null : objPerAddress.Mobile1;
                    objrootClientdetail.dfemail = (string.IsNullOrWhiteSpace(objPerAddress.EMailId)) == true ? null : objPerAddress.EMailId;
                    objrootClientdetail.cmbpstate = (string.IsNullOrWhiteSpace(objPerAddress.StateNumber.ToString())) == true ? null : Process.GetFixLenString(CShilpiFileManager.GetStateCode(objPerAddress.StateNumber), 2, '0');
                    objrootClientdetail.cmbpcountry = (string.IsNullOrWhiteSpace(objPerAddress.CountryCode.ToString())) == true ? null : Process.GetFixLenString(CShilpiFileManager.GetCountryCode(objPerAddress.CountryCode), 3, '0'); 

                    //objrootClientdetail.dfmobisd
                    //objrootClientdetail.dfContType
                    if (objrootClientdetail.cmbaddsame == "Y")
                    {
                        objrootClientdetail.dfcadd1 = (string.IsNullOrWhiteSpace(objPerAddress.AddressLine1)) == true ? null : objPerAddress.AddressLine1;
                        objrootClientdetail.dfcadd2 = (string.IsNullOrWhiteSpace(objPerAddress.AddressLine2)) == true ? null : objPerAddress.AddressLine2;
                        objrootClientdetail.dfcadd3 = (string.IsNullOrWhiteSpace(objPerAddress.AddressLine3)) == true ? null : objPerAddress.AddressLine3;
                        objrootClientdetail.dfccity = (string.IsNullOrWhiteSpace(objPerAddress.City)) == true ? null : objPerAddress.City;
                        objrootClientdetail.dfcpincode = objPerAddress.PinCode;
                        if (objPerAddress.StateNumber != null)
                            objrootClientdetail.cmbcstate = Process.GetFixLenString(CShilpiFileManager.GetStateCode(objPerAddress.StateNumber), 2, '0');
                        if (objPerAddress.CountryCode != null)
                            objrootClientdetail.cmbccountry = Process.GetFixLenString(CShilpiFileManager.GetCountryCode(objPerAddress.CountryCode), 3, '0');

                        //objrootClientdetail.dfcproofrefno
                        //objrootClientdetail.dfdatecaddrefno
                    }
                }
                #endregion Per address

                #region Corr Address
                if (objCorrAddress != null && objrootClientdetail.cmbaddsame == "N")
                {
                    objrootClientdetail.dfcadd1 = (string.IsNullOrWhiteSpace(objCorrAddress.AddressLine1)) == true ? null : objCorrAddress.AddressLine1;
                    objrootClientdetail.dfcadd2 = (string.IsNullOrWhiteSpace(objCorrAddress.AddressLine2)) == true ? null : objCorrAddress.AddressLine2;
                    objrootClientdetail.dfcadd3 = (string.IsNullOrWhiteSpace(objCorrAddress.AddressLine3)) == true ? null : objCorrAddress.AddressLine3;
                    objrootClientdetail.dfccity = (string.IsNullOrWhiteSpace(objCorrAddress.City)) == true ? null : objCorrAddress.City;
                    objrootClientdetail.dfcpincode = objCorrAddress.PinCode;
                    if (objCorrAddress.StateNumber != null)
                        objrootClientdetail.cmbcstate = Process.GetFixLenString(CShilpiFileManager.GetStateCode(objCorrAddress.StateNumber), 2, '0');
                    if (objCorrAddress.CountryCode != null)
                        objrootClientdetail.cmbccountry = Process.GetFixLenString(CShilpiFileManager.GetCountryCode(objCorrAddress.CountryCode), 3, '0');

                    //objrootClientdetail.dfcproofrefno
                    //objrootClientdetail.dfdatecaddrefno
                }
                #endregion Corr Address
                

                #region Bank Details
                if (objClient.oClientBankDetails.ClientBankDetailList.Count > 0)
                {
                    ClientBankDetail objClientBankDetail = objClient.oClientBankDetails.ClientBankDetailList[0];

                    objrootClientdetail.dfbankacno = objClientBankDetail.AccountNo;
                    objrootClientdetail.dfbankname = objClientBankDetail.BankName;
                    objrootClientdetail.cmbbankactype = objClientBankDetail.AccountType.ToString();
                    objrootClientdetail.dfbankmicrcode = objClientBankDetail.BankMICRCode;
                    objrootClientdetail.dfbankifsccode = objClientBankDetail.BankIFSCCode;
                    if (objClientBankDetail.BankBranchAddress != null)
                    {
                        string[] arrAdd = Process.spiltData(objClientBankDetail.BankBranchAddress, CShlpiDataProvider.AddLimitPerline);
                        if (arrAdd.Length == 3)
                        {
                            objrootClientdetail.dfbankadd1 = (string.IsNullOrWhiteSpace(arrAdd[0])) == true ? null : arrAdd[0];
                            objrootClientdetail.dfbankadd2 = (string.IsNullOrWhiteSpace(arrAdd[1])) == true ? null : arrAdd[1];
                            objrootClientdetail.dfbankadd3 = (string.IsNullOrWhiteSpace(arrAdd[2])) == true ? null : arrAdd[2];
                        }
                        if (arrAdd.Length == 2)
                        {
                            objrootClientdetail.dfbankadd1 = (string.IsNullOrWhiteSpace(arrAdd[0])) == true ? null : arrAdd[0];
                            objrootClientdetail.dfbankadd2 = (string.IsNullOrWhiteSpace(arrAdd[1])) == true ? null : arrAdd[1];
                        }
                        if (arrAdd.Length == 1)
                        {
                            objrootClientdetail.dfbankadd1 = (string.IsNullOrWhiteSpace(arrAdd[0])) == true ? null : arrAdd[0];
                        }

                        objrootClientdetail.dfbankcity = (string.IsNullOrWhiteSpace(objClientBankDetail.BankCity)) == true ? null : objClientBankDetail.BankCity;
                        //objrootClientdetail.dfbankpincode=objClientBankDetail
                        //objrootClientdetail.dfbankshortcode     
                    }
                }
                #endregion Bank Details

                if (objClient.oClientDPDetails.ClientDPDetailList.Count > 0)
                {
                    foreach (ClientDPDetail objClientDPDetail in objClient.oClientDPDetails.ClientDPDetailList)
                    {
                        if (!arrRelationShipNo.Contains(objClientDPDetail.RelationshipNo))
                        {
                            #region Nomination
                            if (objClientDPDetail.Nomination != "N")
                            {
                                if (!string.IsNullOrEmpty(objClientDPDetail.RelatedPartyName) && objClientDPDetail.RelatedPartyName.Contains(" "))
                                {
                                    string[] arrName = objClientDPDetail.RelatedPartyName.Split(' ');
                                    if (arrName.Length > 0)
                                    {
                                        objrootClientdetail.dfnomineefirstname = arrName[0];
                                    }
                                    if (arrName.Length > 1)
                                    {
                                        objrootClientdetail.dfnomineelastname = arrName[arrName.Length - 1];
                                    }
                                    if (arrName.Length > 2)
                                    {
                                        for (int len = 1; len < arrName.Length; len++)
                                        {
                                            objrootClientdetail.dfnomineemidname = objrootClientdetail.dfnomineemidname + " " + arrName[len];
                                        }
                                    }
                                }

                                objrootClientdetail.dfnomineerelation = objClientDPDetail.RelationshipNo.ToString();
                                //objrootClientdetail.dfnomineepanno
                                //objrootClientdetail.dfnomineefathername    
                                objrootClientdetail.dfdatenomineedob = objClientDPDetail.RelatedPartyDOB == null ? null : objClientDPDetail.RelatedPartyDOB.Value.ToString("dd-MM-yyyy");

                                if (!string.IsNullOrEmpty(objClientDPDetail.GuardianName) && objClientDPDetail.GuardianName.Contains(" "))
                                {
                                    string[] arrName = objClientDPDetail.RelatedPartyName.Split(' ');
                                    if (arrName.Length > 0)
                                    {
                                        objrootClientdetail.dfguardianfirstname = arrName[0];
                                    }
                                    if (arrName.Length > 1)
                                    {
                                        objrootClientdetail.dfguardianlastname = arrName[arrName.Length - 1];
                                    }
                                    if (arrName.Length > 2)
                                    {
                                        for (int len = 1; len < arrName.Length; len++)
                                        {
                                            objrootClientdetail.dfguardianmidname = objrootClientdetail.dfguardianmidname + " " + arrName[len];
                                        }
                                    }

                                    //objrootClientdetail.dfguardianfathername 
                                    //objrootClientdetail.dfguardianrelation    
                                    //objrootClientdetail.dfguardianpanno
                                    //objrootClientdetail.dfguardianadd1                
                                    //objrootClientdetail.dfguardianadd2     
                                    //objrootClientdetail.dfguardianadd3     
                                    //objrootClientdetail.dfguardiancity
                                    //objrootClientdetail.dfguardianpincode    
                                    //objrootClientdetail.dfguardianstate         
                                    //objrootClientdetail.dfguardiancountry    
                                    //objrootClientdetail.dfguardianphone
                                }

                                ClientAddress objRelatedPartyAddress = new ClientAddress();
                                objRelatedPartyAddress = objClient.oNomineeAddresses.GetAddressByType(Client_AddressType.RelatedParty);//for Related Party address
                                if (objRelatedPartyAddress != null)
                                {
                                    objrootClientdetail.dfnomineeadd1 = (string.IsNullOrWhiteSpace(objRelatedPartyAddress.AddressLine1)) == true ? null : Process.RemoveSpecialCharFromString(objRelatedPartyAddress.AddressLine1);
                                    objrootClientdetail.dfnomineeadd2 = (string.IsNullOrWhiteSpace(objRelatedPartyAddress.AddressLine2)) == true ? null : Process.RemoveSpecialCharFromString(objRelatedPartyAddress.AddressLine2);
                                    objrootClientdetail.dfnomineeadd3 = (string.IsNullOrWhiteSpace(objRelatedPartyAddress.AddressLine3)) == true ? null : Process.RemoveSpecialCharFromString(objRelatedPartyAddress.AddressLine3);
                                    objrootClientdetail.dfnomineecity = objRelatedPartyAddress.City;
                                    objrootClientdetail.dfnomineepincode = objRelatedPartyAddress.PinCode;
                                    if (objRelatedPartyAddress.StateNumber!=null)
                                        objrootClientdetail.dfnomineestate = Process.GetFixLenString(CShilpiFileManager.GetStateCode(objRelatedPartyAddress.StateNumber), 2, '0');
                                    if (objRelatedPartyAddress.CountryCode != null)
                                        objrootClientdetail.dfnomineecountry = Process.GetFixLenString(CShilpiFileManager.GetCountryCode(objRelatedPartyAddress.CountryCode), 3, '0'); 
                                    objrootClientdetail.dfnomineephoneno = objRelatedPartyAddress.Mobile1;
                                }
                            }
                            #endregion Nomination

                            #region  Already Have Demat Accnt
                            //for Already Have Demat Accnt
                            if (objClientDPDetail.RelationshipNo == RelatedParty.Already_Have_Demat_Accnt)
                            {
                                if (objClientDPDetail.DPType == DPType.NSDL)
                                {
                                    objrootClientdetail.dfnsdldpid = CShlpiDataProvider.NSDLDPId;
                                    objrootClientdetail.dfnsdlType = objClientDPDetail.DPType;
                                    objrootClientdetail.dfnsdldpname = objClientDPDetail.DPName;
                                    objrootClientdetail.dfnsdlclientid = objClientDPDetail.DPID;
                                }
                                else if (objClientDPDetail.DPType == DPType.CDSL)
                                {
                                    objrootClientdetail.dfcdsldpid = CShlpiDataProvider.CDSLDPId;
                                    objrootClientdetail.dfcdslType = objClientDPDetail.DPType;
                                    objrootClientdetail.dfcdsldpname = objClientDPDetail.DPName;
                                    objrootClientdetail.dfcdslclientid = objClientDPDetail.DPID;
                                }
                            }
                            #endregion  Already Have Demat Accnt

                            #region second holder details
                            if (objClientDPDetail.RelationshipNo == RelatedParty.Second_Holder)//for second holder details
                            {
                                if (!string.IsNullOrEmpty(objClientDPDetail.RelatedPartyName) && objClientDPDetail.RelatedPartyName.Contains(" "))
                                {
                                    string[] arrName = objClientDPDetail.RelatedPartyName.Split(' ');
                                    if (arrName.Length > 0)
                                    {
                                        objrootClientdetail.dfshfirstname = arrName[0];
                                    }
                                    if (arrName.Length > 1)
                                    {
                                        objrootClientdetail.dfshlastname = arrName[arrName.Length - 1];
                                    }
                                    if (arrName.Length > 2)
                                    {
                                        for (int len = 1; len < arrName.Length; len++)
                                        {
                                            objrootClientdetail.dfshmidname = objrootClientdetail.dfshmidname + " " + arrName[len];
                                        }
                                    }
                                }
                                objrootClientdetail.dfshpanno = (string.IsNullOrWhiteSpace(objClientDPDetail.PANNo)) == true ? null : objClientDPDetail.PANNo;

                                //objrootClientdetail.dfshfather
                                //objrootClientdetail.dfshemail
                                //objrootClientdetail.dfshmobile
                            }
                            #endregion second holder details

                            #region third holder details
                            else if (objClientDPDetail.RelationshipNo == RelatedParty.Third_Holder)//for third holder details 
                            {
                                if (!string.IsNullOrEmpty(objClientDPDetail.RelatedPartyName) && objClientDPDetail.RelatedPartyName.Contains(" "))
                                {
                                    string[] arrName = objClientDPDetail.RelatedPartyName.Split(' ');
                                    if (arrName.Length > 0)
                                    {
                                        objrootClientdetail.dfthfirstname = arrName[0];
                                    }
                                    if (arrName.Length > 1)
                                    {
                                        objrootClientdetail.dfthlastname = arrName[arrName.Length - 1];
                                    }
                                    if (arrName.Length > 2)
                                    {
                                        for (int len = 1; len < arrName.Length; len++)
                                        {
                                            objrootClientdetail.dfthsecondname = objrootClientdetail.dfthsecondname + " " + arrName[len];
                                        }
                                    }
                                }

                                objrootClientdetail.dfthpanno = (string.IsNullOrWhiteSpace(objClientDPDetail.PANNo)) == true ? null : objClientDPDetail.PANNo;

                                //objrootClientdetail.dfthfather
                                //objrootClientdetail.dfthemail
                                //objrootClientdetail.dfthmobile
                            }
                            #endregion third holder details
                        }
                    }
                }

                #region Scheme Details
                if (objClient.oClientSchemeDetails.SchemeDetailsList.Count > 0)
                {
                    ClientSchemeDetail oClientSchemeDetail = objClient.oClientSchemeDetails.SchemeDetailsList[0];
                    objrootClientdetail.cmbnsecash = oClientSchemeDetail.NSECM == 1 ? Flag.Yes : Flag.No;
                    objrootClientdetail.cmbnsefo = oClientSchemeDetail.NSEFO == 1 ? Flag.Yes : Flag.No;
                    objrootClientdetail.cmbnsecd = oClientSchemeDetail.NSE_SX == 1 ? Flag.Yes : Flag.No;
                    objrootClientdetail.cmbbsecash = oClientSchemeDetail.BSECM == 1 ? Flag.Yes : Flag.No;
                    objrootClientdetail.cmbbsefo = oClientSchemeDetail.BSEFO == 1 ? Flag.Yes : Flag.No;
                    objrootClientdetail.cmbbsecd = oClientSchemeDetail.BSE_SX == 1 ? Flag.Yes : Flag.No;
                }
                #endregion Scheme Details

                objrootClientdetail.dfucccode     = (string.IsNullOrWhiteSpace(objClient.ClientCode)) == true ? null : objClient.ClientCode;
                objrootClientdetail.dfbranch      = (string.IsNullOrWhiteSpace(objClient.Branch)) == true ? null : objClient.Branch;
                objrootClientdetail.dfbackoffcode = (string.IsNullOrWhiteSpace(objClient.ClientCode)) == true ? null : objClient.ClientCode;
                
                //objrootClientdetail.dfgroupcode
                //objrootClientdetail.cmbtariffplan

                #region Proof Details
                if (objClient.oClientProofDetails.ProofDetailsList.Count > 0)
                {
                    foreach (ClientProofDetail objClientProofDetail in objClient.oClientProofDetails.ProofDetailsList)
                    {
                        if (objClientProofDetail.ReferenceSubType == CKYCProof.PROOFADD.ToString())//Per Add proof
                        {
                            if (objClientProofDetail.ProofType!=null)
                                objrootClientdetail.cmbpproof =Process.GetFixLenString(CShilpiFileManager.GetPerProofOfAdd(objClientProofDetail.ProofType), 2, '0');
                        }
                        else if (objClientProofDetail.ReferenceSubType == CKYCProof.PROOFCOADD.ToString())//Corr Add proof
                        {
                            if (objClientProofDetail.ProofType != null)
                                objrootClientdetail.cmbcproof = Process.GetFixLenString(CShilpiFileManager.GetCorrProofOfAdd(objClientProofDetail.ProofType), 2, '0');
                        }
                        else if (objClientProofDetail.ReferenceSubType == CKYCProof.PROOFIDEN.ToString())//ID proof
                        {
                            if (objClientProofDetail.ProofType != null)
                                objrootClientdetail.cmbidproof = Process.GetFixLenString(CShilpiFileManager.GetIDProof(objClientProofDetail.ProofType), 2, '0');
                        }
                    }
                }
                #endregion Proof Details

                #region extraFields
                //objrootClientdetail.CKYCno
                //objrootClientdetail.dfuidno
                //objrootClientdetail.cmbJurisdictionoutsideIndia

                //objrootClientdetail.dfsubbranch
                //objrootClientdetail.dfrmtlcode    
                //objrootClientdetail.dfintroby     

                //objrootClientdetail.cmbmfss      
                //objrootClientdetail.cmbmcx   
                //objrootClientdetail.cmbncdex       

                //objrootClientdetail.cmbnsdl       
                //objrootClientdetail.cmbcdsl
                #endregion extraFields
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "ClientDetailRecord() Error while Uploading Attachment.", ex);
                throw ex;
            }
            return objrootClientdetail;
        }
    }
}
