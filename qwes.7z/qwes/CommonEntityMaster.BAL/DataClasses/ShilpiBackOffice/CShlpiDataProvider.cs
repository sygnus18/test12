﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTIL.Match.CDD.BAL.DataClasses.ShilpiBackOffice
{
    public struct CShlpiDataProvider
    {
        public static int AddLimitPerline = 36;
        public static string CDSLDPId = ConfigurationManager.AppSettings["CDSLDPId"];
        public static string NSDLDPId = ConfigurationManager.AppSettings["NSDLDPId"];
    }

    public struct DPType
    {
        public static string NSDL = "NSDL";
        public static string CDSL = "CDSL";
    }

    public enum enAccountType
    {
        Normal = 1
    }

    public enum KycType
    {
        Individual = 1,
        NonIndividual = 2
    }

    public enum Proof
    {
        PROOFADD,
        PROOFAUTHA,
        PROOFBANK,
        PROOFCOADD,
        PROOFDP,
        PROOFFIN,
        PROOFIDEN,
        PROOFINTA,
        PROOFNOM,
        PROOFNOMA,
        PROOFPOA,
        PROOFSIG,
        PROOFSLFIE,
        PROOFW1PHO,
        PROOFW1SIG,
        PROOFW2PHO,
        PROOFW2SIG
    }

    public struct KRAAgency
    {
        public static string NDML = "NDML";
        public static string CVL = "CVL";
        public static string KARVY = "KARVY";
        public static string DOTEX = "DOTEX";
        public static string CAMS = "CAMS";
    }

    public static class CShilpiFileManager
    {
        #region Get PEP Details
        static Dictionary<byte?, string> l_dictPEP = new Dictionary<byte?, string>
        {
            {0,"NA"},	//NA Not Available  
            {1,"PEP"},	//PEP Politically Exposed Person   
            {2,"RPEP"}	//RPEP Related to Politically Exposed Person
        };

        public static string GetPEPDetails(byte? PEPNo)
        {
            string PEPDetails = string.Empty;
            try
            {
                l_dictPEP.TryGetValue(PEPNo, out PEPDetails);
            }
            catch
            {
            }
            return PEPDetails;
        }
        #endregion Get PEP Details

        #region Get Occupation by Type
        static Dictionary<int?, int> l_dictOccupation = new Dictionary<int?, int>
        {
            {1 ,2},	   //Public Sector
            {2 ,1},    //Private Sector
            {3 ,2},    //Government Service
            {4 ,3},    //Business
            {5 ,4},    //Professional
            {6 ,5},    //Agriculture
            {7 ,6},    //Retired
            {8 ,7},    //Housewife
            {9 ,8},    //Student
            {99,99}    //Others
        };

        public static string GetOccupationType(int? Occupation)
        {
            int OccupationType = 0;
            try
            {
                l_dictOccupation.TryGetValue(Occupation, out OccupationType);
            }
            catch { }
            return OccupationType.ToString();
        }
        #endregion Get Occupation by Type

        #region Get Marriage Status by Type
        static Dictionary<string, string> l_dictMarriStatus = new Dictionary<string, string>
        {
            {"S" ,"S"},	
            {"M" ,"M"}, 
            {"W" ,"M"}, 
            {"D" ,"M"}, 
            {"NA","M"}  
        };

        public static string GetMarriStatusType(string MarriStatus)
        {
            string MarriStatusType = string.Empty;
            try
            {
                l_dictMarriStatus.TryGetValue(MarriStatus, out MarriStatusType);
            }
            catch { }
            return MarriStatusType;
        }
        #endregion Get  Marriage Status by Type

        #region Get Residential Status by Type
        static Dictionary<int, string> l_dictResStatus = new Dictionary<int, string>
        {
            {1 ,"R"},  //Resident
            {4 ,"N"},  //Non Resident Individual
            {7 ,"P"}   //Foreign National
        };

        public static string GetResStatusType(int ResStatus)
        {
            string ResStatusType = string.Empty;
            try
            {
                l_dictResStatus.TryGetValue(ResStatus, out ResStatusType);
            }
            catch
            { }
            return ResStatusType;
        }
        #endregion Get Residential Status by Type

        #region Get Corr proof of add
        static Dictionary<int, int> l_dictCorrAddProof = new Dictionary<int, int>
        {
            {38,31},	//31	AADHAR
            {36,01},	//01	Passport
            {41,06},	//06	Voter Identity Card
            {37,07},	//07	Ration Card
            {42,02},	//02	Driving License
            {39,10},	//10	Latest Electricity Bill
            {40,04} 	//04	Latest Bank Account Statement
                        //03	Latest Bank Passbook
                        //05	Latest Demat Account Statement
                        //08	Registered Lease / Sale Agreement of Residence
                        //09	Latest Land Line Telephone Bill
                        //11	Gas Bill
                        //12	Registration Certificate issued under Shops and Establishments Act
                        //13	Flat Maintenance Bill
                        //14	Insurance copy
                        //15	Self Declaration by High Court / Supreme Court Judge
                        //16	Power of Attorney given by FII/sub-account to the Custodians (which are duly notarised and/or apostiled or consluarised) giving registered address.
                        //17	Proof of Address issued by Scheduled Commercial Banks / Scheculed Co-operative Banks / Multinational Foreign banks.
                        //18	Proof of Address issued by Elected representatives to the Legistlative Assembly
                        //19	Proof of Address issued by Parliament
                        //20	Proof of Address issued by any Government / Statutory Authority
                        //21	Proof of Address issued by Notary Public
                        //22	Proof of Address issued by Gazetted Officer
                        //23	ID Card with address issued by Central / State Government 
                        //24	ID Card with address issued by Statutory / Regulatory Authorities
                        //25	ID Card with address issued by Public Sector Undertakings
                        //26	ID Card with address issued by Scheculded Commercial Banks
                        //27	ID Card with address issued by Public Financial Institutions
                        //28	ID Card with address issued by Colleges affiliated to uinversities
                        //29	ID Card issued by Professional Bodies such as ICAI/ ICWAI/ ICSI/ Bar Council/ etc. to their Members
        };
       

        public static string GetCorrProofOfAdd(int CorrAddCode)
        {
            int AddProof = 0 ;
            try
            {
                l_dictCorrAddProof.TryGetValue(CorrAddCode, out AddProof);
            }
            catch { }
            return AddProof.ToString();
        }
        #endregion Get Corr proof of add

        #region Get per proof of add
        static Dictionary<int, int> l_dictPerAddProof = new Dictionary<int, int>
        {
            {7,31},	    //31	AADHAR
            {2,01},	    //01	Passport
            {25,06},	//06	Voter Identity Card
            {5,07},	    //07	Ration Card
            {26,02},	//02	Driving License
            {13,10},	//10	Latest Electricity Bill
            {24,04} 	//04	Latest Bank Account Statement
                        //03	Latest Bank Passbook
                        //05	Latest Demat Account Statement
                        //08	Registered Lease / Sale Agreement of Residence
                        //09	Latest Land Line Telephone Bill
                        //11	Gas Bill
                        //12	Registration Certificate issued under Shops and Establishments Act
                        //13	Flat Maintenance Bill
                        //14	Insurance copy
                        //15	Self Declaration by High Court / Supreme Court Judge
                        //16	Power of Attorney given by FII/sub-account to the Custodians (which are duly notarised and/or apostiled or consluarised) giving registered address.
                        //17	Proof of Address issued by Scheduled Commercial Banks / Scheculed Co-operative Banks / Multinational Foreign banks.
                        //18	Proof of Address issued by Elected representatives to the Legistlative Assembly
                        //19	Proof of Address issued by Parliament
                        //20	Proof of Address issued by any Government / Statutory Authority
                        //21	Proof of Address issued by Notary Public
                        //22	Proof of Address issued by Gazetted Officer
                        //23	ID Card with address issued by Central / State Government 
                        //24	ID Card with address issued by Statutory / Regulatory Authorities
                        //25	ID Card with address issued by Public Sector Undertakings
                        //26	ID Card with address issued by Scheculded Commercial Banks
                        //27	ID Card with address issued by Public Financial Institutions
                        //28	ID Card with address issued by Colleges affiliated to uinversities
                        //29	ID Card issued by Professional Bodies such as ICAI/ ICWAI/ ICSI/ Bar Council/ etc. to their Members
        };


        public static string GetPerProofOfAdd(int PerAddCode)
        {
            int AddProof = 0;
            try
            {
                l_dictPerAddProof.TryGetValue(PerAddCode, out AddProof);
            }
            catch { }
            return AddProof.ToString();
        }
        #endregion Get per proof of add

        #region Get ID proof
        static Dictionary<int, int> l_dictIDProof = new Dictionary<int, int>
        {
             {3,02},	//02	Voters Identity Card
             {4,05},	//05	Driving License
             {8,27} 	//27	PAN Card with Photograph

            //01	Passport
            //03	Ration Card
            //04	Registered Lease or Sale Agreement of Residence
            //06	Flat Maintenance bill
            //07	Insurance Copy
            //08	Utility bills like Telephone Bill (land line), Electricity bill or Gas bill
            //09	Bank Account Statement/Passbook
            //10	Self-declaration by High Court and Supreme Court judges
            //11	Proof of address issued by Bank Managers of Scheduled Commercial / Scheduled Co-Operative / Multinational Foreign Banks
            //12	Proof of address issued by Gazetted Officer
            //13	Proof of address issued by Notary public
            //14	Proof of address issued by Elected representatives to the Legislative Assembly
            //15	Proof of address issued by Parliament
            //16	Proof of address issued by any Govt. or Statutory Authority
            //17	ID Card with address issued by Central / State Govt
            //18	ID Card with address issued by Statutory/Regulatory Authorities
            //19	ID Card with address issued by Public Sector Undertakings
            //20	ID Card with address issued by Scheduled Commercial Banks
            //21	ID Card with address issued by Public Financial Institutions
            //22	ID Card with address issued by Colleges affiliated to Universities
            //23	ID Card with address issued by Professional Bodies such as ICAI/ICWAI/ICSI/Bar Council etc. to their Members
            //24	Power Of Attorney given by FII/sub-account to Custodian (duly notarized and/or apostiled or consularised) giving registered address
            //25	Proof of address in the name of the spouse
            //26	Unique Identification Number (UID) (Aadhaar)
        };


        public static string GetIDProof(int IDCode)
        {
            int IDProof = 0;
            try
            {
                l_dictIDProof.TryGetValue(IDCode, out IDProof);
            }
            catch { }
            return IDProof.ToString();
        }
        #endregion Get ID proof 

        #region Get State Code
        static Dictionary<int, int> l_dictState = new Dictionary<int, int>
        {
            {14,01},	//Jammu and Kashmir
            {13,02},	//Himachal Pradesh
            {26,03},	//Punjab
            {6,04},	    //Chandigarh
            {34,05},	//Uttarakhand
            {12,06},	//Haryana
            {9,07},	    //Delhi
            {27,08},	//Rajasthan
            {31,09},	//Uttar Pradesh
            {5,10},	    //Bihar
            {28,11},	//Sikkim
            {3,12},	    //Arunachal Pradesh
            {4,13},	    //Assam
            {20,14},	//Manipur
            {22,15},	//Mizoram
            {30,16},	//Tripura
            {21,17},	//Meghalaya
            {23,18},	//Nagaland
            {32,19},	//West Bengal
            {35,20},	//Jharkhand
            {24,21},	//Orissa
            {33,22},	//Chhattisgarh
            {18,23},	//Madhya Pradesh
            {11,24},	//Gujarat
            {8,25},	    //Daman and Diu
            {7,26},	    //Dadra and Nagar Haveli
            {19,27},	//Maharashtra
            {2,28},	    //Andhra Pradesh
            {15,29},	//Karnataka
            {10,30},	//Goa
            {17,31},	//Lakshadweep
            {16,32},	//Kerala
            {29,33},	//Tamil Nadu
            {25,34},	//Puducherry
            {1,35},	    //Andaman and Nicobar Islands
            {99,99}	    //Others
        };


        public static string GetStateCode(int nState)
        {
            int nStateCode = 0;
            try
            {
                l_dictState.TryGetValue(nState, out nStateCode);
            }
            catch { }
            return nStateCode.ToString();
        }
        #endregion Get State Code


    #region Get Country Code
        static Dictionary<int, int> l_dictCountry = new Dictionary<int, int>
        {
            {1,001}, //Afghanistan
            {200,002}, //Aland Islands
            {2,003}, //Albania
            {3,004}, //Algeria
            {201,005}, //American Samoa
            {202,006}, //Andorra
            {4,007}, //Angola
            {203,008}, //Anguilla
            {204,009}, //Antarctica
            {205,010}, //Antigua And Barbuda
            {5,011}, //Argentina
            {6,012}, //Armenia
            {7,013}, //Aruba
            {8,014}, //Australia
            {9,015}, //Austria
            {10,016}, //Azerbaijan
            {11,017}, //Bahamas
            {12,018}, //Bahrain
            {13,019}, //Bangladesh
            {14,020}, //Barbados
            {15,021}, //Belarus
            {16,022}, //Belgium
            {17,023}, //Belize
            {18,024}, //Benin
            {19,025}, //Bermuda
            {20,026}, //Bhutan
            {21,027}, //Bolivia
            {22,028}, //Bosnia And Herzegovina
            {23,029}, //Botswana
            {206,030}, //Bouvet Island
            {24,031}, //Brazil
            {207,032}, //British Indian Ocean Territory
            //{,033}, //Brunei Darussalam
            {26,034}, //Bulgaria
            {27,035}, //Burkina Faso
            {28,036}, //Burundi
            {208,037}, //Cambodia
            {29,038}, //Cameroon
            {30,039}, //Canada
            {31,040}, //Cape Verde
            {32,041}, //Cayman Islands
            {33,042}, //Central African Republic
            {34,043}, //Chad
            {35,044}, //Chile
            {36,045}, //China
            {209,046}, //Christmas Island
            {210,047}, //Cocos (Keeling) Islands
            {37,048}, //Colombia
            {39,049}, //Comoros
            {40,050}, //Congo
            {211,051}, //Congo, The Democratic Republic Of The
            {41,052}, //Cook Islands
            {42,053}, //Costa Rica
            {43,054}, //Cote D Ivoire
            {44,055}, //Croatia
            {45,056}, //Cuba
            {46,057}, //Cyprus
            {47,058}, //Czech Republic
            {48,059}, //Denmark
            {49,060}, //Djibouti
            {50,061}, //Dominica
            {51,062}, //Dominican Republic
            {53,063}, //Ecuador
            {54,064}, //Egypt
            {55,065}, //El Salvador
            {56,066}, //Equatorial Guinea
            {212,067}, //Eritrea
            {57,068}, //Estonia
            {58,069}, //Ethiopia
            {59,070}, //Falkland Islands (Malvinas)
            {213,071}, //Faroe Islands
            {60,072}, //Fiji
            {61,073}, //Finland
            {62,074}, //France
            {63,075}, //French Guiana
            {64,076}, //French Polynesia
            {214,077}, //French Southern Territories
            {65,078}, //Gabon
            {66,079}, //Gambia
            {67,080}, //Georgia
            {68,081}, //Germany
            {69,082}, //Ghana
            {70,083}, //Gibraltar
            {71,084}, //Greece
            {72,085}, //Greenland
            {73,086}, //Grenada
            {74,087}, //Guadeloupe
            {75,088}, //Guam
            {76,089}, //Guatemala
            {77,090}, //Guernsey
            {78,091}, //Guinea
            {79,092}, //Guinea-Bissau
            {80,093}, //Guyana
            {81,094}, //Haiti
            {215,095}, //Heard Island And Mcdonald Islands
            {216,096}, //Holy See (Vatican City State)
            {82,097}, //Honduras
            {83,098}, //Hong Kong
            {217,099}, //Hungary
            {84,100}, //Iceland
            {85,101}, //India
            {86,102}, //Indonesia
            {87,103}, //Iran, Islamic Republic Of
            {88,104}, //Iraq
            {89,105}, //Ireland
            {218,106}, //Isle Of Man
            {90,107}, //Israel
            {91,108}, //Italy
            {92,109}, //Jamaica
            {93,110}, //Japan
            {219,111}, //Jersey
            {94,112}, //Jordan
            {95,113}, //Kazakhstan
            {96,114}, //Kenya
            {220,115}, //Kiribati
            {221,116}, //Korea, Democratic People S Republic Of
            {222,117}, //Korea, Republic Of
            {97,118}, //Kuwait
            {98,119}, //Kyrgyzstan
            //{,120}, //Lao People S Democratic Republic
            {100,121}, //Latvia
            {101,122}, //Lebanon
            {102,123}, //Lesotho
            {103,124}, //Liberia
            {104,125}, //Libyan Arab Jamahiriya
            {223,126}, //Liechtenstein
            {105,127}, //Lithuania
            {106,128}, //Luxembourg
            {107,129}, //Macao
            {108,130}, //Macedonia The Former Yugoslav Republic Of
            {109,131}, //Madagascar
            {110,132}, //Malawi
            {111,133}, //Malaysia
            {112,134}, //Maldives
            {113,135}, //Mali
            {114,136}, //Malta
            {224,137}, //Marshall Islands
            {225,138}, //Martinique
            {115,139}, //Mauritania
            {116,140}, //Mauritius
            {226,141}, //Mayotte
            {117,142}, //Mexico
            {227,143}, //Micronesia, Federated States Of
            {118,144}, //Moldova Republic Of
            {228,145}, //Monaco
            {120,146}, //Mongolia
            {121,147}, //Montserrat
            {122,148}, //Morocco
            {123,149}, //Mozambique
            {124,150}, //Myanmar
            {125,151}, //Namibia
            {229,152}, //Nauru
            {126,153}, //Nepal
            {127,154}, //Netherlands
            {128,155}, //Netherlands Antilles
            {129,156}, //New Caledonia
            {130,157}, //New Zealand
            {131,158}, //Nicaragua
            {132,159}, //Niger
            {133,160}, //Nigeria
            {230,161}, //Niue
            {231,162}, //Norfolk Island
            {232,163}, //Northern Mariana Islands
            {136,164}, //Norway
            {137,165}, //Oman
            {138,166}, //Pakistan
            {233,167}, //Palau
            {234,168}, //Palestinian Territory Occupied
            {139,169}, //Panama
            {140,170}, //Papua New Guinea
            {141,171}, //Paraguay
            {142,172}, //Peru
            {143,173}, //Philippines
            {235,174}, //Pitcairn
            {144,175}, //Poland
            {145,176}, //Portugal
            {236,177}, //Puerto Rico
            {146,178}, //Qatar
            {237,179}, //Reunion
            {147,180}, //Romania
            //{,181}, //Russian Federation
            {149,182}, //Rwanda
            //{,183}, //Saint Helena
            {238,184}, //Saint Kitts And Nevis
            {239,185}, //Saint Lucia
            {240,186}, //Saint Pierre And Miquelon
            {241,187}, //Saint Vincent And The Grenadines
            {242,188}, //Samoa
            {243,189}, //San Marino
            {244,190}, //Sao Tome And Principe
            {151,191}, //Saudi Arabia
            {152,192}, //Senegal
            {245,193}, //Serbia And Montenegro
            {153,194}, //Seychelles
            {246,195}, //Sierra Leone
            {154,196}, //Singapore
            {155,197}, //Slovakia
            {156,198}, //Slovenia
            {157,199}, //Solomon Islands
            {158,200}, //Somalia
            {159,201}, //South Africa
            //{,202}, //South Georgia And The South Sandwich Islands
            {161,203}, //Spain
            {162,204}, //Sri Lanka
            {167,205}, //Sudan
            {168,206}, //Suriname
            {247,207}, //Svalbard And Jan Mayen
            {169,208}, //Swaziland
            {170,209}, //Sweden
            {171,210}, //Switzerland
            {172,211}, //Syrian Arab Republic
            {173,212}, //Taiwan, Province Of China
            {174,213}, //Tajikistan
            {175,214}, //Tanzania, United Republic Of
            {176,215}, //Thailand
            {248,216}, //Timor-Leste
            {177,217}, //Togo
            {249,218}, //Tokelau
            {179,219}, //Tonga
            {180,220}, //Trinidad And Tobago
            {181,221}, //Tunisia
            {182,222}, //Turkey
            {183,223}, //Turkmenistan
            {250,224}, //Turks And Caicos Islands
            {251,225}, //Tuvalu
            {185,226}, //Uganda
            {252,227}, //Ukraine
            {186,228}, //United Arab Emirates
            {187,229}, //United Kingdom
            //{,230}, //United States
            {253,231}, //United States Minor Outlying Islands
            {188,232}, //Uruguay
            {254,233}, //Uzbekistan
            {190,234}, //Vanuatu
            {191,235}, //Venezuela
            {192,236}, //Viet Nam
            {255,237}, //Virgin Islands, British
            {256,238}, //Virgin Islands, U.S.
            {257,239}, //Wallis And Futuna
            {258,240}, //Western Sahara
            {195,241}, //Yemen
            {198,242}, //Zambia
            {199,243} //Zimbabwe
        };


        public static string GetCountryCode(int nCountry)
        {
            int nCountryCode = 0;
            try
            {
                l_dictCountry.TryGetValue(nCountry, out nCountryCode);
            }
            catch { }
            return nCountryCode.ToString();
        }
        #endregion Get Country Code

    }
}
