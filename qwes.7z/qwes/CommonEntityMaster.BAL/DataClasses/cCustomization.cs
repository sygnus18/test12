﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using System.Data;
using FTIL.Match.Common.Log;
using System.Data.SqlClient;

namespace FTIL.Match.CDD.BAL.DataClasses
{
   public class cCustomization
    {
        public cCustomization()
        {
                                         
        }

        public DataTable dtCustomization { get; set; }
        public bool isValid { get; set; }

        public int ProductNo { get; set; }
        public string sCustId { get; set; }

        public int FieldType { get; set; }
        public string FieldName { get; set; }
        public int FieldNo { get; set; }
        public int Format { get; set; }
        public int MinLen { get; set; }
        public int MaxLen { get; set; }
        public bool isMandatory { get; set; }

        public int nErrorNo { get; set; }
        public string sErrorMsg { get; set; }
        public string sMode { get; set; }
        public string FieldValue { get; set; }
        public string sComboVal { get; set; }

        /// <summary>
        /// Sync. DataTable with properties/fields
        /// </summary>
        public void SetDataResult()
        {
            DataRow[] dr;
            string sMandatory = isMandatory == true ? "Y" : "N";
            if (this.FieldNo == 0)
                dr = dtCustomization.Select("s_FieldName = " + "'" + FieldName + "'");
            else
                dr = dtCustomization.Select("n_CustomFieldNo = " + this.FieldNo + "");

            if (dr.Length > 0)
            {
                string changedFlag = "N";

                if (Convert.ToInt32(dr[0]["n_FieldFormatNo"]) != Format)
                {
                    dr[0]["n_FieldFormatNo"] = Format;
                    changedFlag = "Y";
                }

                if (dr[0]["n_FieldMandatory"].ToString() != sMandatory)
                {
                    dr[0]["n_FieldMandatory"] = sMandatory;
                    changedFlag = "Y";
                }

                //if (dr[0]["s_FieldValue"].ToString() != FieldValue)
                //{
                //    dr[0]["s_FieldValue"] = FieldValue;
                //    changedFlag = "Y";
                //}

                if (dr[0]["sComboVal"].ToString() != sComboVal)
                {
                    dr[0]["sComboVal"] = sComboVal;
                }


                dr[0]["s_HasChanged"] = changedFlag;

                if (changedFlag == "Y")
                {
                    dtCustomization.AcceptChanges();
                }
            }
            else if (!string.IsNullOrEmpty(FieldName))
                dtCustomization.Rows.Add(new object[] { FieldNo, ProductNo, FieldType, Format,
                 MaxLen , MinLen, isMandatory, FieldName,FieldValue ,"Y", sComboVal });


        }


        #region GetCustomization
        /// <summary>
        /// Get CDD Customization details
        /// </summary>
        /// <param name="nClientNo">ClientNo</param>
        /// <param name="dtResult">Entity Customization details DataSet</param>
        /// <returns>Method Execution result</returns>
        public MethodExecResult GetCustomizationDetails(int nProductNo, ref DataSet dsCustomResult, string s_CustId)
        {

            dsCustomResult = new DataSet();
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetSetUCCCustomiztionDtl");
            try
            {
                l_objDbWorkItem.ResultType = QueryType.DataSet;

                SqlParameter outParamErrNo = new SqlParameter("@pn_ErrorNo", SqlDbType.Int, 8);
                outParamErrNo.Direction = ParameterDirection.Output;
                l_objDbWorkItem.AddParameter(outParamErrNo);

                SqlParameter outParamErrMsg = new SqlParameter("@ps_ErrorMsg", SqlDbType.VarChar, 100);
                outParamErrMsg.Direction = ParameterDirection.Output;
                l_objDbWorkItem.AddParameter(outParamErrMsg);

                l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, "S");
                l_objDbWorkItem.AddParameter("@ps_CustId", SqlDbType.VarChar, s_CustId);
                l_objDbWorkItem.AddParameter("@pn_ProductNo", SqlDbType.Int, nProductNo);
                l_objDbWorkItem.AddParameter("@UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);
                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
                if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                    if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_CCMMasterEntityDocDetails. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        dsCustomResult = l_dsReturnData;
                        return l_objDbWorkItem.ExecutionStatus;
                    }
                }
                else
                {
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(cCustomization), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }
        }
        #endregion


        #region GetCustomization
        /// <summary>
        /// Get CDD Customization field details
        /// </summary>
        /// <param name="nClientNo"></param>
        /// <param name="dtResult">Entity Customization field details DataSet</param>
        /// <returns>Method Execution result</returns>
        public MethodExecResult GetCustomizationField(int nProductNo, ref DataSet dsFieldResult, string s_CustId)
        {

            dsFieldResult = new DataSet();
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetUCCCustomFields");
            try
            {
                l_objDbWorkItem.ResultType = QueryType.DataSet;
                
                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
                if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                    if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_GetUCCUCCCustomFields. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        dsFieldResult = l_dsReturnData;
                        return l_objDbWorkItem.ExecutionStatus;
                    }
                }
                else
                {
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(cCustomization), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }
        }
        #endregion


        #region AddEditField
        /// <summary>
        ///AddEditField details
        /// </summary>
        /// <param name="nProductId">ClientNo</param>
        /// <returns>Method Execution result</returns>
        public MethodExecResult AddEditField(int nProductId)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_AddUpdateUCCCustomFields");
            try
            {
                l_objDbWorkItem.ResultType = QueryType.DataSet;

                SqlParameter outParamErrNo = new SqlParameter("@pn_Result", SqlDbType.Int, 8);
                outParamErrNo.Direction = ParameterDirection.Output;
                l_objDbWorkItem.AddParameter(outParamErrNo);

                SqlParameter outNewFieldNo = new SqlParameter("@pn_NewFieldNo", SqlDbType.Int, 8);
                outNewFieldNo.Direction = ParameterDirection.Output;
                l_objDbWorkItem.AddParameter(outNewFieldNo);


                l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, sMode);
                l_objDbWorkItem.AddParameter("@pn_ProductNo", SqlDbType.Int, nProductId);
                l_objDbWorkItem.AddParameter("@pn_FieldType", SqlDbType.Int, this.FieldType);
                l_objDbWorkItem.AddParameter("@pn_FieldFormat", SqlDbType.Int, this.Format);
                l_objDbWorkItem.AddParameter("@pn_FieldNo", SqlDbType.VarChar, this.FieldNo);
                l_objDbWorkItem.AddParameter("@ps_FieldName", SqlDbType.VarChar, this.FieldName);

                if(FieldType==9)
                    l_objDbWorkItem.AddParameter("@ps_ComboVal", SqlDbType.VarChar, this.sComboVal);

                l_objDbWorkItem.AddParameter("@pn_MaxLen", SqlDbType.Int, this.MaxLen);
                l_objDbWorkItem.AddParameter("@pn_MinLen", SqlDbType.Int, this.MinLen);
                l_objDbWorkItem.AddParameter("@pc_Mandatory", SqlDbType.VarChar, isMandatory == true ? "Y" : "N");
                l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);


                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
                if (l_objDbWorkItem.parameters[0].Value == null)
                    sErrorMsg = null;
                else

                {
                    nErrorNo = Convert.ToInt32(l_objDbWorkItem.parameters[0].Value);
                    this.FieldNo = Convert.ToInt32(l_objDbWorkItem.parameters[1].Value);
                    sErrorMsg = l_objDbWorkItem.ExecutionStatus.ErrorMessage;
                    if (nErrorNo == 99)
                        sErrorMsg = FieldName +  " already exist!";
                }

                return l_objDbWorkItem.ExecutionStatus;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex.Message);
                return l_objDbWorkItem.ExecutionStatus;
            }
        }
        #endregion


        /// <summary>
        /// Bulk Update Entity bank details
        /// </summary>
        /// <param name="nClientNo">EntityNo</param>
        /// <param name="p_vdsTempTableData">Source DataTable - to be update in database</param>
        /// <returns>Method execution result</returns>
        public MethodExecResult UpdateFieldValuesDetails(int pn_ProductNo, DataTable p_vdsTempTableData, DateTime? p_dLastUpdatedDate)
        {
            DbWorkItem objdbwork = new DbWorkItem("stp_GetSetUCCCustomiztionDtl");
            try
            {
                DataSet l_dsFileData = new DataSet();
                DataTable dtUpdated = p_vdsTempTableData.Copy();
                dtUpdated.TableName = "#tb_UCCCustomFieldsValue";

                dtUpdated.Columns["n_CustomFieldNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_CustomFieldNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["n_ProductNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_ProductNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["n_FieldTypeNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_FieldTypeNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["n_FieldFormatNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_FieldFormatNo"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["n_FieldMaxLength"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_FieldMaxLength"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["n_FieldMinLength"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, null);
                dtUpdated.Columns["n_FieldMinLength"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8");

                dtUpdated.Columns["n_FieldMandatory"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["n_FieldMandatory"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["s_FieldName"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_FieldName"].ExtendedProperties.Add(DbManager.ColLengthAttr, "255");

                dtUpdated.Columns["s_FieldValue"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_FieldValue"].ExtendedProperties.Add(DbManager.ColLengthAttr, "255");

                dtUpdated.Columns["s_HasChanged"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["s_HasChanged"].ExtendedProperties.Add(DbManager.ColLengthAttr, "1");

                dtUpdated.Columns["sComboVal"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, string.Empty);
                dtUpdated.Columns["sComboVal"].ExtendedProperties.Add(DbManager.ColLengthAttr, "255");

                l_dsFileData.Tables.Add(dtUpdated);

                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.InputData = l_dsFileData;
                SqlParameter outParamErrNo = new SqlParameter("@pn_ErrorNo", SqlDbType.Int, 8);
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outParamErrMsg = new SqlParameter("@ps_ErrorMsg", SqlDbType.VarChar, 100);
                outParamErrMsg.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrMsg);

                objdbwork.AddParameter("@ps_Mode", SqlDbType.VarChar, "U");
                objdbwork.AddParameter("@ps_CustId", SqlDbType.VarChar, sCustId);
                objdbwork.AddParameter("@pn_ProductNo", SqlDbType.Int, pn_ProductNo);
                objdbwork.AddParameter("@UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);
                objdbwork.AddParameter("@pd_dLastModifiedDate", SqlDbType.DateTime, p_dLastUpdatedDate);

                //if (sErrorMsg == "Y")
                //    objdbwork.AddParameter("@ps_Process", SqlDbType.Char, "P");
                //else
                //    objdbwork.AddParameter("@ps_Process", SqlDbType.Char, "A");
                DbManager.Instance.ExecuteDbTask(objdbwork);

                nErrorNo = Convert.ToInt32(objdbwork.parameters[0].Value);
                if (nErrorNo == 101)
                    sErrorMsg = Convert.ToString(objdbwork.parameters[1].Value);

                return objdbwork.ExecutionStatus;

            }
            catch (Exception ex)
            {
                nErrorNo = 0;
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return new MethodExecResult(-1, ex.Message, "CEntityMaster", ex); ;
            }

        }
    }
}

