﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using FTIL.Match.Common.Log;
using XceedZipLib;

namespace FTIL.Match.CDD.BAL.DataStore
{
    /// <summary>
    /// Custom property attribute for providing fieldS.
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class DataFilter : Attribute
    {
        public DataFilter()
        {
 
        }
    }

    public class Process
    {
        private char m_PaddingChar;
        private bool m_HasPaddingChar = false;

        /// <summary>
        /// Length of the field( useful for fix length field record)
        /// </summary>
        public int Length { get; set; }

        /// <summary>
        /// Index of the field
        /// </summary>
        public int Index { get; set; }


        /// <summary>
        /// Padding Character for numeric type 
        /// </summary>
        public char PaddingCharacter
        {
            get { return m_PaddingChar; }
            set
            {
                //m_HasPaddingChar = true;
                m_PaddingChar = value;
            }
        }

        /// <summary>
        /// Join properties into the string 
        /// </summary>
        /// <param name="obj">Source object which properties would be joined, those having property attribute [DataField]</param>
        /// <returns>joined string</returns>
        public string JoinProperties(object obj)
        {
            PropertyInfo[] propInfo = obj.GetType().GetProperties();

            StringBuilder sb = new StringBuilder();

            string valueString = string.Empty;
            //List<string> Removeprop = new List<string>() { "IsValidClient", "ErrorString", "ClientNo", "ClientAddresses", "ClientBanks", "ClientDPs", "ClientExchanges", "strErrorString", "oClientAddresses", "oClientBankDetails", "oClientProofDetails" };

            foreach (PropertyInfo pi in propInfo)
            {

                object val = pi.GetValue(obj, null);

            }

            return sb.ToString();
        }


        /// <summary>
        /// Generate fix length string
        /// </summary>
        /// <param name="value">Source string</param>
        /// <param name="length">Desired length of string</param>
        /// <returns>Fix length string</returns>
        public static string GetFixLenString(string value, int length)
        {
            if (value == null)
                value = "";
            else if (value.Length > length)
            {
                value = value.Substring(0,length);
            }
            StringBuilder sb = new StringBuilder(length);
            sb.Append(value).ToString();
            return sb.ToString().PadRight(length);
        }


        /// <summary>
        /// Generate fix length string
        /// </summary>
        /// <param name="value">Source string</param>
        /// <param name="length">Desired length of string</param>
        /// <param name="paddingCharacter">Padding character</param>
        /// <returns>Fix length string</returns>
        public static string GetFixLenString(string value, int length, char paddingChar)
        {
            if (value == null)
            {
                value = GetFixLenString(value, length);
                return value;
            }
            else if (value.Length > length)
            {
                value = value.Substring(0, length);
            }
            return value.PadLeft(length, paddingChar);
        }

        #region CreateZipFile
        /// <summary>
        /// Zip Attachted Documnets.
        /// </summary>
        /// <param name="sFileToZipName"></param>
        /// <param name="sPwd"></param>
        /// <param name="sRtnMsg"></param>
        /// <param name="ClientNo"></param>
        /// <returns></returns>
        public static void CreateZipFile(string sFileToZipName, string sFolderName, string sPwd, ref string sRtnMsg)
        {
            //string sZipfilename = null;
            string XceedZipLic = System.Configuration.ConfigurationManager.AppSettings["XCEEDZIPLIC"];
            string DownloadAttachmentPath = sFileToZipName;

            DataTable dt = new DataTable();
            XceedZip Xfilezip;
            xcdError Xresultcode;
            try
            {
                Xfilezip = new XceedZipClass();
                sRtnMsg = string.Empty;

                //initializing xceed zip objects
                Xfilezip.CompressionLevel = xcdCompressionLevel.xclHigh;
                Xfilezip.DeleteZippedFiles = false;//true will delete signed file after zipped
                Xfilezip.ZipOpenedFiles = false;
                Xfilezip.PreservePaths = false;
                Xfilezip.RequiredFileAttributes = xcdFileAttributes.xfaNone;
                Xfilezip.ExtraHeaders = xcdExtraHeader.xehNone;
                Xfilezip.UseTempFile = false;

                if (!Xfilezip.License(XceedZipLic))
                {
                    throw new Exception("Xceed zip licence is either incorrect or expired.");
                }
                string sFolderpath = sFileToZipName + "\\" + sFolderName;
                string[] arrFileListToZip = Directory.GetFiles(sFolderpath, "*.*", SearchOption.AllDirectories);
                StringBuilder sFileList = new StringBuilder();

                //if (File.Exists(sZipfilename))
                //{ File.Delete(sZipfilename); }

                Xfilezip.EncryptionPassword = sPwd;

                foreach (var item in arrFileListToZip)
                {
                    sFileList.Append(item + "|");
                }
                Xfilezip.FilesToProcess = sFileList.ToString().EndsWith("|") ? sFileList.ToString().Substring(0, sFileList.ToString().Length - 1) : sFileList.ToString();

                Xfilezip.ZipFilename = DownloadAttachmentPath + "\\" + sFolderName + ".zip";

                if (File.Exists(Xfilezip.ZipFilename))
                    File.Delete(Xfilezip.ZipFilename); 

                Xresultcode = Xfilezip.Zip();

                if (Xresultcode == xcdError.xerSuccess)
                {
                    Directory.Delete(sFolderpath, true);
                    return;
                }
                else
                {
                    throw new Exception("Exception Error while zipping file :" + Xresultcode);
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog("Process", "CreateZipFile()  Error while zipping file:- " + sFileToZipName, ex);
                throw ex;
            }
            finally
            {
                Xfilezip = null;
            }
        }
        #endregion CreateZipFile

        public static string ToCsv<T>(string separator, IEnumerable<T> objectlist)
        {
            Type t = typeof(T);
            PropertyInfo[] fields = t.GetProperties();

            string header = String.Join(separator, fields.Select(f => f.Name).ToArray());

            StringBuilder csvdata = new StringBuilder();
            csvdata.AppendLine(header);

            foreach (var o in objectlist)
                csvdata.AppendLine(ToCsvFields(separator, fields, o));

            return csvdata.ToString();
        }

        public static string ToCsvFields(string separator, PropertyInfo[] fields, object o)
        {
            StringBuilder linie = new StringBuilder();

            foreach (var f in fields)
            {
                if (linie.Length > 0 || f != fields[0])
                    linie.Append(separator);

                var x = f.GetValue(o);

                if (x != null)
                    linie.Append(x.ToString());
            }

            return linie.ToString();
        }

        public static string ToCsvHeaderFields(string separator, PropertyInfo[] fields, object o)
        {
            StringBuilder linie = new StringBuilder();

            foreach (var f in fields)
            {
                if (linie.Length > 0)
                    linie.Append(separator);

                var x = f.Name;

                if (x != null)
                    linie.Append(x.ToString());
            }

            return linie.ToString();
        }

        /// <summary>
        /// Remove SpecialChar From String
        /// </summary>
        /// <param name="strData"></param>
        /// <returns></returns>
        public static string RemoveSpecialCharFromString(String strData)
        {
            strData = Regex.Replace(strData, @"[^0-9a-zA-Z]+", " ");
            return strData;
        }

        public static string[] spiltData(string str, int length)
        {
            str = Process.RemoveSpecialCharFromString(str);
            string[] arrAdd = new string[3];
            int length_1 = length + 1;//37
            int length_2 = (length*2) + 1;//73

            if (str.Length > (length*3))
            {
                arrAdd[0] = str.Substring(0, length);
                arrAdd[1] = str.Substring(length_1, length);
                arrAdd[2] = str.Substring(length_2, length);
            }
            else if (str.Length < (length * 3) && str.Length > (length * 2))
            {
                arrAdd[0] = str.Substring(0, length);
                arrAdd[1] = str.Substring(length_1, length);
                arrAdd[2] = str.Substring(length_2);
            }
            else if (str.Length > (length))
            {
                arrAdd[0] = str.Substring(0, length);
                arrAdd[1] = str.Substring(length_1);
            }

            return arrAdd;
        }
    }

     
}
