﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FTIL.Match.CDD.BAL.DataStore;

namespace FTIL.Match.CDD.BAL.DataClasses.CKYC
{
    class CKYCClientIdentityDetails
    {
        public int RecordType { get; set; }
        public int LineNo { get; set; }
        public string IDType { get; set; }
        public string IdentityNo { get; set; }
        public string ExpiryDate { get; set; }
        public string IDProofSubmitted { get; set; }
        public int IDVerificationStatus { get; set; }
        public string Filler1 { get; set; }
        public string Filler2 { get; set; }
        public string Filler3 { get; set; }
        public string Filler4 { get; set; }

        public CKYCClientIdentityDetails()
        {
            RecordType = 30;

        }
        public void BindObject(ClientProofDetail objClientProofDetail)
        {
            IDType = objClientProofDetail.DocCode;
            IdentityNo = objClientProofDetail.ProofNumber;
            ExpiryDate = objClientProofDetail.DateOfExpiry;
            IDProofSubmitted = objClientProofDetail.ProofProvided;
            IDVerificationStatus = 02;

        }
    }
}
