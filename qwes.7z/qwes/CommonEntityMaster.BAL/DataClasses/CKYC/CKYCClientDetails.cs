﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FTIL.Match.CDD.BAL.DataStore;
using FTIL.Match.Common.Log;

namespace FTIL.Match.CDD.BAL.DataClasses.CKYC
{
    /// <summary>
    /// 
    /// </summary>
    class CKYCClientDetails
    {
        #region Public properties
        public int RecordType { get; set; }
        public int LineNo { get; set; }
        public int AppType { get; set; }
        public int BranchCode { get; set; }
        public int? ApplicantNameUpdFlag { get; set; }
        public int? EntityDtlsUpdFlag { get; set; }
        public int? AddressDtlsUpdFlag { get; set; }
        public int? ContactDtlsUpdFlag { get; set; }
        public int? RemarksUpdeFlag { get; set; }
        public int? KYCVerificationUpdFlag { get; set; }
        public int? IdentityDetailsUpdFlag { get; set; }
        public int? RelatedPrsnDtlsFlag { get; set; }
        public int? ControllingPrsnDtlsFlag { get; set; }
        public int? ImgDetailsUpdFlag { get; set; }
        public int ConstitutionType { get; set; }
        public int AccntHolderTypeFlag { get; set; }
        public int AccntHolderType { get; set; }
        public int AccntType { get; set; }
        public string CKYCNo { get; set; }
        public string ApplicantNamePrefix { get; set; }
        public string ApplicantFirstName { get; set; }
        public string ApplicantMiddleName { get; set; }
        public string ApplicantLastName { get; set; }
        public string EntityName { get; set; }
        public string MaidenNamePrefix { get; set; }
        public string MaidenFirstName { get; set; }
        public string MaidenMiddleName { get; set; }
        public string MaidenLastName { get; set; }
        public string MaidenFullName { get; set; }
        public int FatherOrSpouseNameFlag { get; set; }
        public string FatherOrSpouseNamePrefix { get; set; }
        public string FatherOrSpouseFirstName { get; set; }
        public string FatherOrSpouseMiddleName { get; set; }
        public string FatherOrSpouseLastName { get; set; }
        public string FatherOrSpouseFullName { get; set; }
        public string ApplicantMotherNamePrefix { get; set; }
        public string MotherFirstName { get; set; }
        public string MotherMiddleName { get; set; }
        public string MotherLastName { get; set; }
        public string MotherFullName { get; set; }
        public string Gender { get; set; }
        public string MaritalStatus { get; set; }
        public string Nationality { get; set; }
        public int? OccupationType { get; set; }
        public DateTime? DOB { get; set; }
        public string PlaceOfIncorporation { get; set; }
        public DateTime? DateOfCommencementOfBusiness { get; set; }
        public string CountryOfIncorporation { get; set; }
        public string CountryOfResidenceAsPerTaxLaws { get; set; }
        public string IdentificationType { get; set; }
        public string TINNo { get; set; }
        public string TINIssuingCountry { get; set; }
        public string PAN { get; set; }
        public string ResidentialStatus { get; set; }
        public string TaxResidentFlag   { get; set; }
        public string JurisdictionOfRes { get; set; }
        public string TaxIdentificationNo	{ get; set; }
        public string CountryOfBirth { get; set; }
        public string PlaceOfBirth { get; set; }
        public string PerAddType { get; set; }
        public string PerAddLine1 { get; set; }
        public string PerAddLine2 { get; set; }
        public string PerAddLine3 { get; set; }
        public string PerAddCity { get; set; }
        public string PerAddDistrict { get; set; }
        public string PerAddState { get; set; }
        public string PerAddCountry { get; set; }
        public string PerAddPINCode { get; set; }
        public string PerPOA { get; set; }
        public string OthersPOA { get; set; }
        public int AddrPerSameAsCorrFlag { get; set; }
        public string CorrAddrType { get; set; }
        public string CorrAddrLine1 { get; set; }
        public string CorrAddrLine2 { get; set; }
        public string CorrAddrLine3 { get; set; }
        public string CorrAddrCity { get; set; }
        public string CorrAddrDistrict { get; set; }
        public string CorrAddrState { get; set; }
        public string CorrAddrCountry { get; set; }
        public string CorrAddrPINCode { get; set; }
        public string CorrPOA { get; set; }
        public int AddrJurisdictionSameAsPerFlag { get; set; }
        public string AddrJurisdictionType { get; set; }
        public string AddrJurisdictionLine1 { get; set; }
        public string AddrJurisdictionLine2 { get; set; }
        public string AddrJurisdictionLine3 { get; set; }
        public string AddrJurisdictionCity { get; set; }
        public string AddrJurisdictionState { get; set; }
        public string AddrJurisdictionCountry { get; set; }
        public string AddrJurisdictionZIPCode { get; set; }
        public string JurisdictionPOA { get; set; }
        public long ResTelSTDCode { get; set; }
        public long ResTelNo { get; set; }
        public long OfcTelSTDCode { get; set; }
        public long OfcTelNo { get; set; }
        public long MobTelISDCode { get; set; }
        public long MobNo { get; set; }
        public long FaxSTDCode { get; set; }
        public long FaxNo { get; set; }
        public string EmailID { get; set; }
        public string Remarks { get; set; }
        public string DateOfDeclaration { get; set; }
        public string PlaceofDeclaration { get; set; }
        public string KYCVerificationDate { get; set; }
        public int TypeofDocumentSubmitted { get; set; }
        public string KYCVerificationName { get; set; }
        public string KYCVerificationDesignation { get; set; }
        public string KYCVerificationBranch { get; set; }
        public string KYCVerificationEMPCode { get; set; }
        public string OrgName { get; set; }
        public string OrgCode { get; set; }
        public int NoOfIdentityDetails { get; set; }
        public int NoOfRelatedpeople { get; set; }
        public int NoOfControllingPrsnsResidentOutsideIndia { get; set; }
        public int NoOfLocalAddressDetails { get; set; }
        public int NoOfImages { get; set; }
        public string ErrorCode { get; set; }
        public string Filler1 { get; set; }
        public string Filler2 { get; set; }
        public string Filler3 { get; set; }
        public string Filler4 { get; set; }
        #endregion Public properties

        #region Constructor
        public CKYCClientDetails()
        {
            RecordType = 20;
            AppType = 01;
            BranchCode = 01;
            ConstitutionType = 01;
            AccntType = 01;
            FatherOrSpouseNameFlag = 01;
        }
        #endregion Constructor

        #region methods
        public void BindObject(Client objClient)
        {
            try
            {
                ClientAddress objPerAddress = new ClientAddress();
                ClientAddress objCorrAddress = new ClientAddress();
                objPerAddress = objClient.oClientAddresses.GetAddressByType(Client_AddressType.Registered);//for permanat address
                objCorrAddress = objClient.oClientAddresses.GetAddressByType(Client_AddressType.Correspondence);//for Correspondant address
                
                
                CKYCNo = objClient.ClientNo.ToString();
                ApplicantNamePrefix = objClient.ClientTitle.TrimEnd('.');
                ApplicantFirstName = objClient.ClientName;
                ApplicantMiddleName = objClient.MiddleName;
                ApplicantLastName = objClient.LastName;
                EntityName = objClient.ClientName;
                MaidenFirstName = objClient.MaidenName;
                MaidenFullName= objClient.MaidenName; //--check
                FatherOrSpouseNamePrefix = objClient.GuardianTitle.TrimEnd('.');
                FatherOrSpouseFirstName = objClient.GuardianName;
                FatherOrSpouseLastName = objClient.LastName;
                FatherOrSpouseFullName = objClient.GuardianName + " " + objClient.LastName;
                ApplicantMotherNamePrefix = "Mrs";  //--Check
                MotherFirstName = objClient.MotherName;
                MotherMiddleName = objClient.MiddleName;
                MotherLastName = objClient.LastName;
                MotherFullName = objClient.MotherName + " " + objClient.MiddleName + " " + objClient.LastName;
                Gender = objClient.Gender;
                MaritalStatus = objClient.MaritalStatus;
                Nationality = objClient.Nationality.ToString();
                OccupationType = objClient.Occupation;
                DOB = objClient.DOB;
                PlaceOfIncorporation = objClient.PlaceofIncorporation;
                DateOfCommencementOfBusiness = objClient.CommOfBusiness;
                TINNo = objClient.PANNo; //--check
                PAN = objClient.PANNo;
                //AccntType=
                //MaidenNamePrefix=
                //MaidenMiddleName=
                //MaidenLastName=
                //FatherOrSpouseNameFlag=
                //FatherOrSpouseMiddleName=
                //CountryOfIncorporation=objClient.
                //CountryOfResidenceAsPerTaxLaws=
                //IdentificationType=objClient
                //TINIssuingCountry=
                //ResidentialStatus=
                //TaxResidentFlag=
                //JurisdictionOfRes=
                //TaxIdentificationNo=
                //CountryOfBirth=
                //PlaceOfBirth=
                if (objPerAddress != null)
                {
                    PerAddType = objPerAddress.AddressType.ToString();
                    PerAddLine1 = objPerAddress.AddressLine1;
                    PerAddLine2 = objPerAddress.AddressLine2;
                    PerAddLine3 = objPerAddress.AddressLine3;
                    PerAddCity = objPerAddress.City;
                    PerAddState = objPerAddress.StateNumber.ToString();
                    PerAddCountry = objPerAddress.CountryCode.ToString();
                    PerAddPINCode = objPerAddress.PinCode;
                    AddrPerSameAsCorrFlag = (objPerAddress.SameCorrPermAdd == "Y") ? 01 : 02;
                    ResTelSTDCode = (objPerAddress.TelNoSTDCode == string.Empty) ? 0 : Convert.ToInt64(objPerAddress.TelNoSTDCode);
                    ResTelNo = (objPerAddress.TelNo1 == string.Empty) ? 0 : Convert.ToInt64(objPerAddress.TelNo1);
                    MobTelISDCode = (objPerAddress.TelNoISDCode == string.Empty) ? 0 : Convert.ToInt64(objPerAddress.TelNoISDCode);
                    MobNo = (objPerAddress.Mobile1 == string.Empty) ? 0 : Convert.ToInt64(objPerAddress.Mobile1);
                    FaxSTDCode = (objPerAddress.FaxNoISDCode == string.Empty) ? 0 : Convert.ToInt64(objPerAddress.FaxNoISDCode);
                    FaxNo = (objPerAddress.FaxNo == string.Empty) ? 0 : Convert.ToInt64(objPerAddress.FaxNo);
                    EmailID = objPerAddress.EMailId;
                    //PerAddDistrict=
                    //PerPOA=
                    //OthersPOA=
                }
                if (objCorrAddress != null)
                {
                    CorrAddrType = objCorrAddress.AddressType.ToString();
                    CorrAddrLine1 = objCorrAddress.AddressLine1;
                    CorrAddrLine2 = objCorrAddress.AddressLine2;
                    CorrAddrLine3 = objCorrAddress.AddressLine3;
                    CorrAddrCity = objCorrAddress.City;
                    CorrAddrState = objCorrAddress.StateNumber.ToString();
                    CorrAddrCountry = objCorrAddress.CountryCode.ToString();
                    CorrAddrPINCode = objCorrAddress.PinCode;
                    //CorrPOA=
                    //CorrAddrDistrict=
                }

                //DateOfDeclaration=
                //PlaceofDeclaration=
                //KYCVerificationDate=
                //TypeofDocumentSubmitted=
                //KYCVerificationName=
                //KYCVerificationDesignation=
                //KYCVerificationBranch=
                //KYCVerificationEMPCode=

                NoOfIdentityDetails = objClient.oClientProofDetails.ProofDetailsList.Count;
                NoOfRelatedpeople = objClient.oClientDPDetails.ClientDPDetailList.Count;
                NoOfImages = objClient.oClientImageDetails.ClientImgDetailList.Count;
                
                //RecordType=10
                //LineNo
                //AppType=01
                //BranchCode=01
                //ApplicantNameUpdFlag=     --blank
                //EntityDtlsUpdFlag=        --blank
                //AddressDtlsUpdFlag=       --blank
                //ContactDtlsUpdFlag=       --blank
                //RemarksUpdeFlag=          --blank
                //KYCVerificationUpdFlag=   --blank
                //IdentityDetailsUpdFlag=   --blank
                //RelatedPrsnDtlsFlag=      --blank
                //ControllingPrsnDtlsFlag=  --blank
                //ImgDetailsUpdFlag=        --blank
                //ConstitutionType=         --blank
                //AccntHolderTypeFlag=      --blank
                //AccntHolderType=          --blank
                //Remarks=     --Blank
                //AddrJurisdictionSameAsPerFlag= --Blank
                //AddrJurisdictionType=          --Blank
                //AddrJurisdictionLine1=         --Blank
                //AddrJurisdictionLine2=         --Blank
                //AddrJurisdictionLine3=         --Blank
                //AddrJurisdictionCity=          --Blank
                //AddrJurisdictionState=         --Blank
                //AddrJurisdictionCountry=       --Blank
                //AddrJurisdictionZIPCode=       --Blank
                //JurisdictionPOA=               --Blank
                //OfcTelSTDCode   --Blank
                //OfcTelNo        --Blank
                //OrgName=        --Blank  
                //OrgCode=        --Blank
                //NoOfControllingPrsnsResidentOutsideIndia=  --Blank
                //NoOfLocalAddressDetails=    --Blank
                //ErrorCode=  --Blank
                //Filler1=    --Blank
                //Filler2=    --Blank
                //Filler3=    --Blank
                //Filler4=    --Blank
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "BindObject() Error processing CKYC Client Details , Client no:" + objClient.ClientNo, ex);
                throw ex;
            }

        }
        #endregion methods

    }
}
