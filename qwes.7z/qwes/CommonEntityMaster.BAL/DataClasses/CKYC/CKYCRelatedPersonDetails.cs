﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FTIL.Match.CDD.BAL.DataStore;
using FTIL.Match.Common.Log;

namespace FTIL.Match.CDD.BAL.DataClasses.CKYC
{
    class CKYCRelatedPersonDetails
    {
        #region Public properties
        public int RecordType { get; set; }
        public int LineNo { get; set; }
        public string TypeofRelationship { get; set; }
        public string AddOrDlteOfRelatedPrsn { get; set; }
        public string KYCNoOfRelatedPerson { get; set; }
        public string RelatedPrsnNamePrefix { get; set; }
        public string RelatedPrsnFirstName { get; set; }
        public string RelatedPrsnMiddleName { get; set; }
        public string RelatedPrsnLastName { get; set; }
        public string RelatedPrsnMaidenNamePrefix { get; set; }
        public string RelatedPrsnMaidenFirstName { get; set; }
        public string RelatedPrsnMaidenMiddleName { get; set; }
        public string RelatedPersnMaidenLastName { get; set; }
        public string ReatedPersonFatherOrSpouseNameFlag { get; set; }
        public string RelatedPersonFatherOrSpouseNamePrefix { get; set; }
        public string RelatedPersonFatherOrSpouseFirstName { get; set; }
        public string RelatedPersonFatherOrSpouseMiddleName { get; set; }
        public string ReatedPersonFatherOrSpouseLastName { get; set; }
        public string RelatedPersonMotherNamePrefix { get; set; }
        public string RelatedPersonMothersFirstName { get; set; }
        public string RelatedPersonMothersMiddleName { get; set; }
        public string RelatedPersonMothersLastName { get; set; }
        public DateTime? DOB { get; set; }
        public string Gender { get; set; }
        public string MaritialStatus { get; set; }
        public string Nationality { get; set; }
        public string ResidentialStatus { get; set; }
        public string OccupationType { get; set; }
        public string RelatedPrsnResidentFlag { get; set; }
        public string JurisdictionOfResidence { get; set; }
        public string TINo { get; set; }
        public string CountryOfBirth { get; set; }
        public string PlaceOfBirth { get; set; }
        public string PANCard { get; set; }
        public string UID { get; set; }
        public string VoterIDCard { get; set; }
        public string NREGAJobCard { get; set; }
        public string PassportNo { get; set; }
        public string PassportExpDate { get; set; }
        public string DrivingLicNo { get; set; }
        public string DrivingLicExpDate { get; set; }
        public string AnyOtherProofOfIDName { get; set; }
        public string AnyOtherProofOfIDNo { get; set; }
        public string SimplifiedMeasuresAccountDocumentTypeCode { get; set; }
        public string SimplifiedMeasuresAccountIdentificationNo { get; set; }
        public string RelatedPrsnAddrType { get; set; }
        public string AddrLine1 { get; set; }
        public string AddrLine2 { get; set; }
        public string AddrLine3 { get; set; }
        public string AddrCity { get; set; }
        public string AddrPINCode { get; set; }
        public string AddrState { get; set; }
        public string AddrCountry { get; set; }
        public string ProofOfAddrCorr { get; set; }
        public string ProofOfAddrOthrs { get; set; }
        public string DateOfDeclaration { get; set; }
        public string PlaceOfDeclaration { get; set; }
        public string KYCVerificationDate { get; set; }
        public string TypeOfDocumentSubmitted { get; set; }
        public string KYCVerificationName { get; set; }
        public string KYCVerificationDesignation { get; set; }
        public string KYCVerificationBranch { get; set; }
        public string KYCVerificationEMPCode { get; set; }
        public string OrganisationName { get; set; }
        public string OrganisationCode { get; set; }
        public string Filler1 { get; set; }
        public string Filler2 { get; set; }
        public string Filler3 { get; set; }
        public string Filler4 { get; set; }
        #endregion Public properties

        #region Constructor
        public CKYCRelatedPersonDetails()
        {
            RecordType = 40;

        }
        #endregion Constructor

        #region Methods
        public void BindObject(ClientDPDetail objClientDPDetail, Client objClient)
        {
            try
            {
                ClientAddress objRelatedPartyAddress = new ClientAddress();
                objRelatedPartyAddress = objClient.oNomineeAddresses.GetAddressByType(Client_AddressType.RelatedParty);//for Related Party address

                RelatedPrsnFirstName = objClientDPDetail.RelatedPartyName;
                DOB = objClientDPDetail.RelatedPartyDOB;

                if (objRelatedPartyAddress != null)
                {
                    AddrLine1 = objRelatedPartyAddress.AddressLine1;
                    AddrLine2 = objRelatedPartyAddress.AddressLine2;
                    AddrLine3 = objRelatedPartyAddress.AddressLine3;
                    AddrCity = objRelatedPartyAddress.City;
                    AddrPINCode = objRelatedPartyAddress.PinCode;
                    AddrState = objRelatedPartyAddress.StateNumber.ToString();
                    AddrCountry = objRelatedPartyAddress.CountryCode.ToString();
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "BindObject() Error processing Client DP Details , Client no :" + objClientDPDetail.ClientNo, ex);
                throw ex;
            }
            
        }
        #endregion Methods
    }
}
