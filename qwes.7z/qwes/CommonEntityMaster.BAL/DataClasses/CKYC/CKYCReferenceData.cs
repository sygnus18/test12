﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FTIL.Match.Common.Log;

namespace FTIL.Match.CDD.BAL.DataClasses.CKYC
{
    public enum enProcessType
    {
        //CKYC_Import = 1,
        CKYC_Export = 1,
        //CKYC_Update = 3,
        Trading_Account_Opening = 2,
        DP_Account_Opening = 3,
        KRA_File = 4,
        CDSL_BO_Setup = 5
    }


    public enum enBatchCode
    {
        CBNO = 1,
        TBNO = 2,
        DPBNO = 3,
        KBNO = 4,
        CDSLBNO = 5
        //Debarred_Entities = 7
    }


    public class CKYCReferenceData
    {
        #region Member variables
        public DateTime m_dtFromDate;
        public DateTime m_dtToDate;
        string m_sCompanyCode;
        string m_sClientCode;
        string m_sExportType;
        string m_sDownloadType;
        #endregion Member variables

        #region properties
        public string FromDate
        {
            get { return m_dtFromDate.ToString(); }
            set
            {
                m_dtFromDate =DateTime.ParseExact(value,"dd/MM/yyyy",CultureInfo.InvariantCulture);
            }
        }

        public string ToDate
        {
            get { return m_dtToDate.ToString(); }
            set
            {
                m_dtToDate = DateTime.ParseExact(value, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
        }
        public string ClientCode { get; set; }     
        public string UserID { get; set; }
        public string Token { get; set; }
        public string UserNo { get; set; }
        public string FICode { get; set; }
        public string Region { get; set; }
        public string BatchNo { get; set; }
        public int ProcessType { get; set; }
        public string ExportType { get; set; }
        public string DownloadType { get; set; }
        public string CKYCYESFlag { get; set; }
        public string FileName { get; set; }

        #endregion properties
    }


    public class BatchRefData
    {
        public DateTime m_dtFromDate;
        public DateTime m_dtToDate;

        #region properties
        public int ProcessType { get; set; }
        public string Token { get; set; }
        public string FromDate
        {
            get { return m_dtFromDate.ToString(); }
            set
            {
                m_dtFromDate = DateTime.ParseExact(value, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
        }
        public string ToDate
        {
            get { return m_dtToDate.ToString(); }
            set
            {
                m_dtToDate = DateTime.ParseExact(value, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
        }
        #endregion properties
    }
}
