﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTIL.Match.CDD.BAL.DataClasses.CKYC
{
    public class CKYCImageDetails
    {
        public int RecordType { get; set; }
        public int LineNumber { get; set; }
        public string ImageName { get; set; }
        public int ImageType { get; set; }
        public int ImageFlag { get; set; }//for Global or Local Image 
        public int BranchCode { get; set; }
        public string Filler1 { get; set; }
        public string Filler2 { get; set; }
        public string Filler3 { get; set; }


        public CKYCImageDetails()
        {
            RecordType = 70;
        }

        public void BindObject(ClientImageDetail objClientImageDetail)
        {
            ImageName = objClientImageDetail.ImageName;
            ImageType = objClientImageDetail.ImageType;
            BranchCode = 01;
            ImageFlag = 01;
        }

    }
}
