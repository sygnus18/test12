﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTIL.Match.CDD.BAL.DataClasses.CKYC
{
    /// <summary>
    /// Contains Header details
    /// </summary>
    public class CKYCHeaderData
    {
        #region public properties
        public int RecordType { get; set; }
        public string BatchNumber { get; set; }
        public string FICode { get; set; }
        public string RegionCode { get; set; }
        public int TotalRecords { get; set; }
        public DateTime CreateDate { get; set; }
        public string VersionNumber { get; set; }
        public string Filler1 { get; set; }
        public string Filler2 { get; set; }
        public string Filler3 { get; set; }
        public string Filler4 { get; set; }
        #endregion public properties

        #region Constructor
        public CKYCHeaderData()
        {
            RecordType = 10;
            TotalRecords = 1;
            VersionNumber = "V1.1";
        }
        #endregion Constructor
    }
}
