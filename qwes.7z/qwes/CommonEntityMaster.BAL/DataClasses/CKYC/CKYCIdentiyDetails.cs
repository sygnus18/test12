﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTIL.Match.CDD.BAL.DataClasses.CKYC
{
    class CKYCIdentiyDetails
    {
        #region Public properties
        string RecordType { get; set; }
        string LineNumber { get; set; }
        string IdentificationType { get; set; }
        string IdentityNumber { get; set; }
        string ExpiryDate { get; set; }
        string IdentityProofSubmitted { get; set; }
        string IdentityVerificationStatus { get; set; }
        string Filler1 { get; set; }
        string Filler2 { get; set; }
        string Filler3 { get; set; }
        string Filler4 { get; set; }
        #endregion Public properties
    }
}
