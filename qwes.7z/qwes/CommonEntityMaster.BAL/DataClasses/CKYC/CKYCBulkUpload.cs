﻿using System;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using FTIL.Match.CDD.BAL.DataStore;
using FTIL.Match.Common.Log;
using XceedZipLib;
using System.Security.Cryptography.Pkcs;

namespace FTIL.Match.CDD.BAL.DataClasses.CKYC
{
    /// <summary>
    /// contains CKYC Bulk Upload data.
    /// </summary>
    public class CKYCBulkUpload
    {
        #region class variables
        public StringBuilder sbClientUploadDetails;
        public static readonly string SEPARATOR = "|";
        public static readonly string DATEFORMAT = "ddMMyyyy";
        public static readonly string DATETIMEFORMAT = "ddMMyyyyHHmmss";
        public static string BaseDirectory = AppDomain.CurrentDomain.BaseDirectory.ToString();
        public static string CKYCBulkUploadPath = BaseDirectory + System.Configuration.ConfigurationManager.AppSettings["CKYCBulkUploadPath"];
        public static string sFICode = System.Configuration.ConfigurationManager.AppSettings["FICODE"];
        public static string sRegionOrBranch = System.Configuration.ConfigurationManager.AppSettings["REGIONORBRANCH"];
        public static string sBulkUploadFlag = "U";
        public static readonly string FILEEXTENSION = ".txt";
        public static string sdate;
        string sCKYCBulkUploadPath = string.Empty;
        string sCKYCBulkUploadFolderName = string.Empty;
        string ImgFolderPath = string.Empty;
        string BatchNo = "0000";
        #endregion class variables

        #region public properties
        public string sDateOfCreation { get; set; }
        public string UserID { get; set; }
        public int LineNo { get; set; }
        #endregion public properties

        #region constructor
        public CKYCBulkUpload(string sUserID)
        {
            sbClientUploadDetails = new StringBuilder();
            UserID = sUserID;
            LineNo = 0;
        }
        #endregion constructor

        #region methods

        #region CKYC file Header Details
        /// <summary>
        /// Add header details.
        /// </summary>
        /// <returns>header string</returns>
        public string HeaderDetails(int nTotalClients)
        {
            StringBuilder sbHeader = new StringBuilder();
            try
            {
                CKYCHeaderData objCKYCHeaderData = new CKYCHeaderData();
                objCKYCHeaderData.CreateDate = DateTime.Now;
                sDateOfCreation = DateTime.Now.ToString(DATEFORMAT);
                objCKYCHeaderData.TotalRecords = nTotalClients;
                objCKYCHeaderData.BatchNumber = BatchNo.ToString().PadLeft(4, '0');

                sbHeader.Append(ToCsvFields(objCKYCHeaderData.RecordType)); //1.Record Type
                sbHeader.Append(ToCsvFields(objCKYCHeaderData.BatchNumber)); //2.Batch Number
                sbHeader.Append(ToCsvFields(objCKYCHeaderData.FICode)); //3.FI Code
                sbHeader.Append(ToCsvFields(objCKYCHeaderData.RegionCode)); //4.Region Code
                sbHeader.Append(ToCsvFields(objCKYCHeaderData.TotalRecords)); //5.Total No of Detail Records
                sbHeader.Append(ToCsvFields(objCKYCHeaderData.CreateDate)); //6.Create Date 
                sbHeader.Append(ToCsvFields(objCKYCHeaderData.VersionNumber)); //7.Version Number
                sbHeader.Append(ToCsvFields(objCKYCHeaderData.Filler1)); //8.Filler1
                sbHeader.Append(ToCsvFields(objCKYCHeaderData.Filler2)); //9.Filler2
                sbHeader.Append(ToCsvFields(objCKYCHeaderData.Filler3)); //10.Filler3
                sbHeader.Append(ToCsvFields(objCKYCHeaderData.Filler4)); //11.Filler4
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "HeaderDetails() Error CKYC Adding header details. ", ex);
                throw ex;
            }
            return sbHeader.ToString();
        }
        #endregion CKYC File Header Details

        #region CKYC file Body Details
        /// <summary>
        /// Add CKYC file Body Details.
        /// </summary>
        /// <param name="objClients"></param>
        /// <returns></returns>
        public StringBuilder BodyDetails(Clients objClients)
        {
            StringBuilder sbBodyDetails = new StringBuilder();
            try
            {
                foreach (Client oClient in objClients.objClients)
                {
                    oClient.LineNo = ++LineNo;
                    sbBodyDetails.AppendLine(DetailRecord(oClient));//20.Detail Record
                    sbBodyDetails.Append(IdentityDetails(oClient));//30.Identity Details
                    sbBodyDetails.Append(RelatedPersonDetails(oClient));//40.Related Person Details
                    sbBodyDetails.Append(ImageDetails(oClient));//70.Image Details
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "BodyDetails() Error CKYC Adding Body details. ", ex);
                throw ex;
            }
            return sbBodyDetails;
        }
        #endregion CKYC file Body Details

        #region 1.Detail Record
        /// <summary>
        /// Detail Record per KYC record				
        /// </summary>
        public string DetailRecord(Client objClient)
        {
            StringBuilder csvdata = new StringBuilder();
            try
            {
                CKYCClientDetails objCKYCClientDetails = new CKYCClientDetails();
                objCKYCClientDetails.BindObject(objClient);
                objCKYCClientDetails.LineNo = objClient.LineNo;

                csvdata.Append(ToCsvFields(objCKYCClientDetails.RecordType));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.LineNo));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.AppType));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.BranchCode));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.ApplicantNameUpdFlag));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.EntityDtlsUpdFlag));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.AddressDtlsUpdFlag));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.ContactDtlsUpdFlag));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.RemarksUpdeFlag));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.KYCVerificationUpdFlag));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.IdentityDetailsUpdFlag));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.RelatedPrsnDtlsFlag));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.ControllingPrsnDtlsFlag));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.ImgDetailsUpdFlag));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.ConstitutionType));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.AccntHolderTypeFlag));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.AccntHolderType));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.AccntType));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.CKYCNo));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.ApplicantNamePrefix));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.ApplicantFirstName));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.ApplicantMiddleName));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.ApplicantLastName));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.EntityName));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.MaidenNamePrefix));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.MaidenFirstName));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.MaidenMiddleName));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.MaidenLastName));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.MaidenFullName));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.FatherOrSpouseNameFlag));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.FatherOrSpouseNamePrefix));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.FatherOrSpouseFirstName));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.FatherOrSpouseMiddleName));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.FatherOrSpouseLastName));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.FatherOrSpouseFullName));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.ApplicantMotherNamePrefix));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.MotherFirstName));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.MotherMiddleName));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.MotherLastName));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.MotherFullName));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.Gender));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.MaritalStatus));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.Nationality));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.OccupationType));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.DOB));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.PlaceOfIncorporation));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.DateOfCommencementOfBusiness));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.CountryOfIncorporation));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.CountryOfResidenceAsPerTaxLaws));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.IdentificationType));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.TINNo));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.TINIssuingCountry));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.PAN));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.ResidentialStatus));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.TaxResidentFlag));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.JurisdictionOfRes));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.TaxIdentificationNo));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.CountryOfBirth));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.PlaceOfBirth));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.PerAddType));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.PerAddLine1));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.PerAddLine2));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.PerAddLine3));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.PerAddCity));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.PerAddDistrict));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.PerAddState));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.PerAddCountry));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.PerAddPINCode));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.PerPOA));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.OthersPOA));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.AddrPerSameAsCorrFlag));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.CorrAddrType));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.CorrAddrLine1));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.CorrAddrLine2));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.CorrAddrLine3));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.CorrAddrCity));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.CorrAddrDistrict));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.CorrAddrState));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.CorrAddrCountry));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.CorrAddrPINCode));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.CorrPOA));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.AddrJurisdictionSameAsPerFlag));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.AddrJurisdictionType));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.AddrJurisdictionLine1));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.AddrJurisdictionLine2));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.AddrJurisdictionLine3));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.AddrJurisdictionCity));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.AddrJurisdictionState));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.AddrJurisdictionCountry));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.AddrJurisdictionZIPCode));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.JurisdictionPOA));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.ResTelSTDCode));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.ResTelNo));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.OfcTelSTDCode));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.OfcTelNo));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.MobTelISDCode));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.MobNo));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.FaxSTDCode));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.FaxNo));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.EmailID));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.Remarks));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.DateOfDeclaration));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.PlaceofDeclaration));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.KYCVerificationDate));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.TypeofDocumentSubmitted));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.KYCVerificationName));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.KYCVerificationDesignation));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.KYCVerificationBranch));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.KYCVerificationEMPCode));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.OrgName));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.OrgCode));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.NoOfIdentityDetails));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.NoOfRelatedpeople));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.NoOfControllingPrsnsResidentOutsideIndia));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.NoOfLocalAddressDetails));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.NoOfImages));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.ErrorCode));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.Filler1));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.Filler2));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.Filler3));
                csvdata.Append(ToCsvFields(objCKYCClientDetails.Filler4));
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "BodyDetails() Error Adding Detail Record per KYC record.Client no :" + objClient.ClientNo, ex);
                throw ex;
            }
            return csvdata.ToString();
        }
        #endregion 1.Detail Record

        #region 2.IdentityDetails
        /// <summary>
        /// Identity Details, Multiple per KYC record			
        /// </summary>
        public string IdentityDetails(Client objClient)
        {
            StringBuilder csvdata = new StringBuilder();
            try
            {
                if (objClient.oClientProofDetails.ProofDetailsList.Count > 0)
                {
                    foreach (ClientProofDetail objClientProofDetail in objClient.oClientProofDetails.ProofDetailsList)
                    {
                        CKYCClientIdentityDetails objCKYCClientIDDetails = new CKYCClientIdentityDetails();
                        StringBuilder csvProofdata = new StringBuilder();
                        objCKYCClientIDDetails.BindObject(objClientProofDetail);
                        objCKYCClientIDDetails.LineNo = objClient.LineNo;

                        csvProofdata.Append(ToCsvFields(objCKYCClientIDDetails.RecordType));
                        csvProofdata.Append(ToCsvFields(objCKYCClientIDDetails.LineNo));
                        csvProofdata.Append(ToCsvFields(objCKYCClientIDDetails.IDType));
                        csvProofdata.Append(ToCsvFields(objCKYCClientIDDetails.IdentityNo));
                        csvProofdata.Append(ToCsvFields(objCKYCClientIDDetails.ExpiryDate));
                        csvProofdata.Append(ToCsvFields(objCKYCClientIDDetails.IDProofSubmitted));
                        csvProofdata.Append(ToCsvFields(objCKYCClientIDDetails.IDVerificationStatus));
                        csvProofdata.Append(ToCsvFields(objCKYCClientIDDetails.Filler1));
                        csvProofdata.Append(ToCsvFields(objCKYCClientIDDetails.Filler2));
                        csvProofdata.Append(ToCsvFields(objCKYCClientIDDetails.Filler3));
                        csvProofdata.Append(ToCsvFields(objCKYCClientIDDetails.Filler4));
                        csvdata.AppendLine(csvProofdata.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "IdentityDetails() Error Adding Identity Details .Client no :" + objClient.ClientNo, ex);
                throw ex;
            }
            return csvdata.ToString();
        }
        #endregion 2.IdentityDetails

        #region 3.Related Person Details
        public string RelatedPersonDetails(Client objClient)
        {
            StringBuilder csvdata = new StringBuilder();
            try
            {
                if (objClient.oClientDPDetails.ClientDPDetailList.Count > 0)
                {
                    foreach (ClientDPDetail objClientDPDetail in objClient.oClientDPDetails.ClientDPDetailList)
                    {
                        CKYCRelatedPersonDetails objCKYCRelatedPersonDetails = new CKYCRelatedPersonDetails();
                        objCKYCRelatedPersonDetails.BindObject(objClientDPDetail, objClient);
                        StringBuilder csvRelatedPartydata = new StringBuilder();
                        objCKYCRelatedPersonDetails.LineNo = objClient.LineNo;
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.RecordType));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.LineNo));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.TypeofRelationship));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.AddOrDlteOfRelatedPrsn));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.KYCNoOfRelatedPerson));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.RelatedPrsnNamePrefix));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.RelatedPrsnFirstName));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.RelatedPrsnMiddleName));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.RelatedPrsnLastName));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.RelatedPrsnMaidenNamePrefix));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.RelatedPrsnMaidenFirstName));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.RelatedPrsnMaidenMiddleName));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.RelatedPersnMaidenLastName));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.ReatedPersonFatherOrSpouseNameFlag));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.RelatedPersonFatherOrSpouseNamePrefix));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.RelatedPersonFatherOrSpouseFirstName));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.RelatedPersonFatherOrSpouseMiddleName));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.ReatedPersonFatherOrSpouseLastName));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.RelatedPersonMotherNamePrefix));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.RelatedPersonMothersFirstName));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.RelatedPersonMothersMiddleName));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.RelatedPersonMothersLastName));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.DOB));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.Gender));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.MaritialStatus));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.Nationality));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.ResidentialStatus));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.OccupationType));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.RelatedPrsnResidentFlag));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.JurisdictionOfResidence));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.TINo));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.CountryOfBirth));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.PlaceOfBirth));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.PANCard));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.UID));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.VoterIDCard));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.NREGAJobCard));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.PassportNo));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.PassportExpDate));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.DrivingLicNo));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.DrivingLicExpDate));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.AnyOtherProofOfIDName));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.AnyOtherProofOfIDNo));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.SimplifiedMeasuresAccountDocumentTypeCode));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.SimplifiedMeasuresAccountIdentificationNo));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.RelatedPrsnAddrType));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.AddrLine1));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.AddrLine2));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.AddrLine3));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.AddrCity));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.AddrPINCode));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.AddrState));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.AddrCountry));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.ProofOfAddrCorr));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.ProofOfAddrOthrs));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.DateOfDeclaration));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.PlaceOfDeclaration));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.KYCVerificationDate));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.TypeOfDocumentSubmitted));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.KYCVerificationName));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.KYCVerificationDesignation));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.KYCVerificationBranch));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.KYCVerificationEMPCode));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.OrganisationName));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.OrganisationCode));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.Filler1));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.Filler2));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.Filler3));
                        csvRelatedPartydata.Append(ToCsvFields(objCKYCRelatedPersonDetails.Filler4));
                        csvdata.AppendLine(csvRelatedPartydata.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "RelatedPersonDetails() Error while Adding  Related Person Details .Client no :" + objClient.ClientNo, ex);
                throw ex;
            }
            return csvdata.ToString();
        }
        #endregion 3.Related Person Details

        #region 4.ImageDetails
        /// <summary>
        /// Image Details, Multiple per KYC record			
        /// </summary>
        public string ImageDetails(Client objClient)
        {
            StringBuilder csvdata = new StringBuilder();
            try
            {
                string resp = string.Empty;
                DataTable dtStatus = new DataTable();

                if (objClient.oClientImageDetails.ClientImgDetailList.Count > 0)
                {
                    //Create Clientwise Folder,to store images.
                    ClientWiseStoreData(objClient.ClientNo);

                    foreach (ClientImageDetail objClientImageDetail in objClient.oClientImageDetails.ClientImgDetailList)
                    {
                        File.WriteAllBytes(ImgFolderPath + objClientImageDetail.ImageName, objClientImageDetail.l_bImage);

                        CKYCImageDetails objCKYCImageDetails = new CKYCImageDetails();
                        objCKYCImageDetails.BindObject(objClientImageDetail);
                        objCKYCImageDetails.LineNumber = objClient.LineNo;
                        StringBuilder csvImgdata = new StringBuilder();

                        csvImgdata.Append(ToCsvFields(objCKYCImageDetails.RecordType));
                        csvImgdata.Append(ToCsvFields(objCKYCImageDetails.LineNumber));
                        csvImgdata.Append(ToCsvFields(objCKYCImageDetails.ImageName));
                        csvImgdata.Append(ToCsvFields(objCKYCImageDetails.ImageType));
                        csvImgdata.Append(ToCsvFields(objCKYCImageDetails.ImageFlag));
                        csvImgdata.Append(ToCsvFields(objCKYCImageDetails.BranchCode));
                        csvImgdata.Append(ToCsvFields(objCKYCImageDetails.Filler1));
                        csvImgdata.Append(ToCsvFields(objCKYCImageDetails.Filler2));
                        csvImgdata.Append(ToCsvFields(objCKYCImageDetails.Filler3));
                        csvdata.AppendLine(csvImgdata.ToString());
                    }

                    //Create Clientwise zip file to store images.
                    CreateZipFile(sCKYCBulkUploadPath, objClient.ClientNo.ToString(), null, ref resp);
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "ImageDetails() Error while Adding  Image Details .Client no :" + objClient.ClientNo, ex);
                throw ex;
            }
            return csvdata.ToString();
        }
        #endregion 4.ImageDetails

        #region  Clientwise Data Store Path
        public void ClientWiseStoreData(int ClientNo)
        {
            try
            {
                string sFolderName = ClientNo.ToString();
                ImgFolderPath = sCKYCBulkUploadPath + sFolderName + "\\";

                FileInfo fileinfo = new FileInfo(ImgFolderPath);
                if (!fileinfo.Exists)
                    Directory.CreateDirectory(fileinfo.Directory.FullName);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "ClientWiseStoreData() Error while Adding  Clientwise Data Store Path .Client no :" + ClientNo, ex);
                throw ex;
            }
        }
        #endregion  Clientwise Data Store Path

        #region Convert object to string
        /// <summary>
        /// Convert object to string
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public string ToCsvFields(object obj)
        {
            StringBuilder sbline = new StringBuilder();
            try
            {
                if (obj != null)
                {
                    if (obj is DateTime)
                        sbline.Append(DateTime.Parse(obj.ToString()).ToString("dd-MM-yyyy"));
                    else
                        sbline.Append(obj.ToString());
                }
                sbline.Append(SEPARATOR);
            }
            catch (Exception ex)
            {
                throw new Exception("ToCsvFields() Error while Converting object to string.", ex);
            }
            return sbline.ToString();
        }
        #endregion Convert object to string

        #region ExportToCSV
        /// <summary>
        /// Convert String to CSV File and Export the file.
        /// </summary>
        /// <param name="strCsv"></param>
        public void ExportToCSV(string strCsv)
        {
            try
            {
                string sFileName = sFICode + "_" + sRegionOrBranch + "_" + sdate + "_" + UserID + "_" + sBulkUploadFlag + "_" + BatchNo.ToString().PadLeft(4, '0') + FILEEXTENSION;

                FileInfo fileinfo = new FileInfo(sCKYCBulkUploadPath);
                if (!fileinfo.Exists)
                    Directory.CreateDirectory(fileinfo.Directory.FullName);
                string FilePath = sCKYCBulkUploadPath + "\\" + sFileName;

                if (File.Exists(FilePath))
                {
                    File.Delete(FilePath);
                }

                using (StreamWriter sw = File.CreateText(FilePath))
                {
                    sw.WriteLine(strCsv);
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "ExportToCSV() Error while Converting String to CSV File and Export the file.", ex);
                throw ex;
            }
        }
        #endregion ExportToCSV

        #region CreateZipFile
        /// <summary>
        /// Zip Attachted Documnets.
        /// </summary>
        /// <param name="sFileToZipName"></param>
        /// <param name="sPwd"></param>
        /// <param name="sRtnMsg"></param>
        /// <param name="ClientNo"></param>
        /// <returns></returns>
        private void CreateZipFile(string sFileToZipName, string sFolderName, string sPwd, ref string sRtnMsg)
        {
            string sZipfilename = null;
            string XceedZipLic = System.Configuration.ConfigurationManager.AppSettings["XCEEDZIPLIC"];
            string DownloadAttachmentPath = sFileToZipName;

            DataTable dt = new DataTable();
            XceedZip Xfilezip;
            xcdError Xresultcode;
            try
            {
                Xfilezip = new XceedZipClass();
                sRtnMsg = string.Empty;

                //initializing xceed zip objects
                Xfilezip.CompressionLevel = xcdCompressionLevel.xclHigh;
                Xfilezip.DeleteZippedFiles = false;//true will delete signed file after zipped
                Xfilezip.ZipOpenedFiles = false;
                Xfilezip.PreservePaths = false;
                Xfilezip.RequiredFileAttributes = xcdFileAttributes.xfaNone;
                Xfilezip.ExtraHeaders = xcdExtraHeader.xehNone;
                Xfilezip.UseTempFile = false;

                if (!Xfilezip.License(XceedZipLic))
                {
                    throw new Exception("Xceed zip licence is either incorrect or expired.");
                }
                string sFolderpath = sFileToZipName + "\\" + sFolderName;
                string[] arrFileListToZip = Directory.GetFiles(sFolderpath, "*.*", SearchOption.AllDirectories);
                StringBuilder sFileList = new StringBuilder();

                if (File.Exists(sZipfilename))
                { File.Delete(sZipfilename); }

                Xfilezip.EncryptionPassword = sPwd;

                foreach (var item in arrFileListToZip)
                {
                    sFileList.Append(item + "|");
                }
                Xfilezip.FilesToProcess = sFileList.ToString().EndsWith("|") ? sFileList.ToString().Substring(0, sFileList.ToString().Length - 1) : sFileList.ToString();

                Xfilezip.ZipFilename = DownloadAttachmentPath + "\\" + sFolderName + ".zip";
                Xresultcode = Xfilezip.Zip();


                if (Xresultcode == xcdError.xerSuccess)
                {
                    Directory.Delete(sFolderpath, true);
                    return;
                }
                else
                {
                    throw new Exception("Exception Error while zipping file :" + Xresultcode);
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "CreateZipFile()  Error while zipping file:- " + sFileToZipName, ex);
                throw ex;
            }
            finally
            {
                Xfilezip = null;
            }
        }
        #endregion CreateZipFile

        #region UploadAttachment
        public void UploadAttachment(Clients objClients, CKYCReferenceData objCKYCReferenceData)
        {
            try
            {
                string resp = string.Empty;
                string sCKYCDetails = string.Empty;
                StringBuilder sbCKYCDetails = new StringBuilder();
                int TotalClients = objClients.objClients.Count();
                if (!string.IsNullOrEmpty(objCKYCReferenceData.FICode))
                    sFICode = objCKYCReferenceData.FICode;
                if (!string.IsNullOrEmpty(objCKYCReferenceData.Region))
                    sRegionOrBranch = objCKYCReferenceData.Region;
                 BatchNo = objCKYCReferenceData.BatchNo;

                //create directory for bulk upload.
                ExportFilePath();

                //Add CKYC file header details in StringBuilder
                sbCKYCDetails.AppendLine(HeaderDetails(TotalClients));

                //Add CKYC file body details in StringBuilder
                sbCKYCDetails.Append(BodyDetails(objClients));

                sCKYCDetails = sbCKYCDetails.ToString();

                //Convert String to CSV File and Export the file.
                ExportToCSV(sCKYCDetails);

                //Zip Attachted Documnets.
                CreateZipFile(CKYCBulkUploadPath, sCKYCBulkUploadFolderName, null, ref resp);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "UploadAttachment() Error while Uploading Attachment.", ex);
                throw ex;
            }
        }
        #endregion UploadAttachment

        #region ExportFilePath
        public void ExportFilePath()
        {
            try
            {
                sdate = System.DateTime.Now.ToString(DATETIMEFORMAT);
                sCKYCBulkUploadFolderName = sFICode + "_" + sRegionOrBranch + "_" + sdate + "_" + UserID + "_" + sBulkUploadFlag + "_" + BatchNo.ToString().PadLeft(4, '0');
                sCKYCBulkUploadPath = CKYCBulkUploadPath + sCKYCBulkUploadFolderName + "\\";

                FileInfo fileinfo = new FileInfo(sCKYCBulkUploadPath);
                if (!fileinfo.Exists)
                    Directory.CreateDirectory(fileinfo.Directory.FullName);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "ExportFilePath() Error while creating Directory for bulk upload.", ex);
                throw ex;
            }
        }
        #endregion ExportFilePath
        #endregion methods


    }

    public class STPConstant
    {
        #region Sign Generating Error
        public const int VAL_ERR_SIGN_FILE_NOT_FOUND = 1;
        public const int VAL_ERR_FINGERPRINT_FILE_CANT_CREATE = 2;
        public const int VAL_ERR_SIGNING = 3;
        public const int VAL_ERR_NO_STORE_FOUND = 4;
        public const int VAL_ERR_NO_CERT_SELECTED = 5;
        public const string STR_ERR_NO_STORE_FOUND = "Error : Certificate is either damaged, uninstalled or not present.";
        public const string STR_ERR_NO_CERT_SELECTED = "Error : Certificate selection dialog was cancelled.";
        public const string STR_ERR_IN_SIGNING = "Error : Problem incurred during Signing.";
        public const string STR_UNDEFINED_SIGNATURE = "-1";
        #endregion

        #region Sign Verification Error
        public const int VAL_ERR_ORIG_FILE_NOT_FOUND = 1;
        public const int VAL_ERR_FINGER_FILE_NOT_FOUND = 2;
        public const int VAL_ERR_VERIFING = 3;
        public const string STR_ERR_ORIG_FILE_NOT_FOUND = "Error : Original File Not Found Or Cannot Be Accessed.";
        public const string STR_ERR_FINGER_FILE_NOT_FOUND = "Error : Digital Signature File Not Found Or Cannot Be Accessed for Original file.";
        public const string STR_ERR_VERIFING = "Error : Signature or Certificate is not valid.";
        public const string STR_SUCCESS = "Success";
        #endregion
    }
}
