﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTIL.Match.CDD.BAL.DataClasses
{
    public class ClientDealingThroughDetails
    {
        #region class variables
        /// <summary>
        /// List of DealingThroughDetail 
        /// </summary>
        private List<ClientDealingThroughDetail> m_DealingThroughDetailList;
        #endregion class variables

        #region Constructor

        public ClientDealingThroughDetails()
        {
            m_DealingThroughDetailList = new List<ClientDealingThroughDetail>();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Dealing Through Detail List
        /// </summary>
        public List<ClientDealingThroughDetail> DealingThroughDetailList
        {
            get { return m_DealingThroughDetailList; }
            set { m_DealingThroughDetailList = value; }
        }
        #endregion Properties

        #region Public methods

        /// <summary>
        /// Add new Dealing Through Detail
        /// </summary>
        /// <param name="oCDealingThroughDetail">Dealing Through Detail Object filled with details</param>
        /// <returns>0 - Success, -1 - Failed</returns>
        public int Add(ClientDealingThroughDetail oCDealingThroughDetail)
        {
            int oResult = m_DealingThroughDetailList.FindIndex(obj => obj.ClientNo == oCDealingThroughDetail.ClientNo);

            if (oResult != 0)
            {
                m_DealingThroughDetailList.Add(oCDealingThroughDetail);
                return 0;
            }
            else
            {
                return -1;
            }
        }
        #endregion Public methods
    }
}
