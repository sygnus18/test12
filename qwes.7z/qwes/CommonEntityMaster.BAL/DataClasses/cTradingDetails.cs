﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace FTIL.Match.CDD.BAL.DataClasses
{
    public class cTradingDetails
    {
        public cTradingDetails()
        {
            dtTradingDetailshResult = new DataTable();

            dtTradingDetailshResult.Columns.Add("n_TradingDetailNo", typeof(int));
            dtTradingDetailshResult.Columns.Add("n_PastAction", typeof(int));
            dtTradingDetailshResult.Columns.Add("s_PastAction", typeof(string));
            dtTradingDetailshResult.Columns.Add("n_TradingPurpose", typeof(int));
            dtTradingDetailshResult.Columns.Add("s_TradingPurpose", typeof(string));
            dtTradingDetailshResult.Columns.Add("n_TradingExpFlag", typeof(int));
            dtTradingDetailshResult.Columns.Add("n_TradingExp", typeof(decimal));
            dtTradingDetailshResult.Columns.Add("n_OtherExpFlag", typeof(int));
            dtTradingDetailshResult.Columns.Add("n_OtherExp", typeof(decimal));
            dtTradingDetailshResult.Columns.Add("s_HasChanged", typeof(string));
            dtTradingDetailshResult.Columns.Add("d_LastModifiedDateTime", typeof(string));
        }

         public int    ClientDealingThroughNo { get; set; }
         public int PastAction { get; set; }
         public string PastActionDtls { get; set; }
         public int TradingPurpose { get; set; }
         public string TradingPurposeDtls { get; set; }
         public int TradingExpFlag { get; set; }
         public decimal TradingExp { get; set; }
         public int OtherExpFlag { get; set; }
         public decimal OtherExp { get; set; }
       
        public bool isValid { get; set; }
        public DateTime? dLastUpdatedDate { get; set; }
        public string AccOthers { get; set; }

        public DataTable dtTradingDetailshResult { get; set; }

        public string FlagAccountNo { get; set; }

         

        /// <summary>
        /// Sync. DataTable with properties/fields
        /// </summary>
        public void SetDataResult()
        {
            //DataRow[] dr;
            //if (this.ClientDealingThroughNo == 0)
            //    dr = dtTradingDetailshResult.Select("n_ClientDealingThroughNo = " + ClientDealingThroughNo + "");
            //else
            //    dr = dtTradingDetailshResult.Select("n_ClientDealingThroughNo = " + ClientDealingThroughNo + "");

            //if (dr.Length > 0)
            //{
            //    string changedFlag = "N";

            //    if (Convert.ToInt32(dr[0]["n_ClientDealingThroughNo"]) != ClientDealingThroughNo)
            //    {
            //        dr[0]["n_ClientDealingThroughNo"] = ClientDealingThroughNo;
            //        changedFlag = "Y";
            //    }

            //    if (Convert.ToInt32(dr[0]["n_Flag"]) != Flag)
            //    {
            //        dr[0]["n_Flag"] = Flag;
            //        changedFlag = "Y";
            //    }

            //    if (dr[0]["s_SubBrokerName"].ToString() != SubBrokerName)
            //    {
            //        dr[0]["s_SubBrokerName"] = SubBrokerName;
            //        changedFlag = "Y";
            //    }

            //    if (dr[0]["s_ExchangeName"].ToString() != ExchangeName)
            //    {
            //        dr[0]["s_ExchangeName"] = ExchangeName;
            //        changedFlag = "Y";
            //    }

            //    if (dr[0]["s_ClientCode"].ToString() != ClientCode)
            //    {
            //        dr[0]["s_ClientCode"] = ClientCode;
            //        changedFlag = "Y";
            //    }

            //    if (dr[0]["s_SebiRegNo"].ToString() != SebiRegNo)
            //    {
            //        dr[0]["s_SebiRegNo"] = SebiRegNo;
            //        changedFlag = "Y";
            //    }
            //    //if (Convert.ToInt32(dr[0]["n_Ammount"])!= Ammount)
            //    //{
            //    //    dr[0]["n_Ammount"] = AccountNo;
            //    //    changedFlag = "Y";
            //    //}
            //    if (dr[0]["s_Remarks"].ToString() != Remarks)
            //    {
            //        dr[0]["s_Remarks"] = Remarks;
            //        changedFlag = "Y";
            //    }
            //    dr[0]["s_HasChanged"] = changedFlag;

            //    if (changedFlag == "Y")
            //    {
            //        dtDealingThroughResult.AcceptChanges();
            //    }
            //}
            //else if (ClientDealingThroughNo != null)
            dtTradingDetailshResult.Rows.Add(new object[] { ClientDealingThroughNo, PastAction, PastActionDtls, TradingPurpose, TradingPurposeDtls, TradingExpFlag, TradingExp, OtherExpFlag, OtherExp, "Y", System.DateTime.Now });


        }
    }

}
