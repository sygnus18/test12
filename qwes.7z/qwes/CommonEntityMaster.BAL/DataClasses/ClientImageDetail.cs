﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FTIL.Match.Common.Log;
using UCC.Class;

namespace FTIL.Match.CDD.BAL.DataClasses
{
    public class ClientImageDetail
    {
        #region public properties
        public int ClientNo { get; set; }
        public int EntityDocNo { get; set; }
        public string EntityType { get; set; }
        public int ImageType { get; set; }
        public byte[] l_bImage { get; set; }
        public string ImageName { get; set; }
        #endregion public properties

        #region methods
        /// <summary>
        /// Initializes current instance from DataRow
        /// </summary>
        /// <param name="DataRow">DataRow object containing client Image details</param>
        #region InitializeFromDataRow
        public void InitializeFromDataRow(DataRow dataRow)
        {
            try
            {
                if ((dataRow["n_ClientNo"] != null) && (dataRow["n_ClientNo"] != DBNull.Value))
                this.ClientNo = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_ClientNo"));
                if ((dataRow["n_EntityDocNo"] != null) && (dataRow["n_EntityDocNo"] != DBNull.Value))
                this.EntityDocNo = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "n_EntityDocNo"));//for CKYC
                this.ImageName = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_FileName"));//for CKYC
                if ((dataRow["b_BinaryDoc"] != null) && (dataRow["b_BinaryDoc"] != DBNull.Value))
                this.l_bImage = (byte[])(Utility.GetValueFromDataRow(dataRow, "b_BinaryDoc"));//for CKYC
                if (dataRow.Table.Columns.Contains("s_ProofType") == true && (dataRow["s_ProofType"] != null) && (dataRow["s_ProofType"] != DBNull.Value))
                    this.ImageType = Convert.ToInt32(Utility.GetValueFromDataRow(dataRow, "s_ProofType"));//for CKYC
                if (dataRow.Table.Columns.Contains("s_EntityType") == true && (dataRow["s_EntityType"] != null) && (dataRow["s_EntityType"] != DBNull.Value))
                    this.EntityType = Convert.ToString(Utility.GetValueFromDataRow(dataRow, "s_EntityType"));//for CKYC
                
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                throw ex;
            }
        }
        #endregion
        #endregion methods
    }
}
