﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using System.Data;
using FTIL.Match.Common.Log;
using System.Data.SqlClient;
using System.Xml;
using System.IO;

namespace FTIL.Match.CDD.BAL

{
    public class CExchangeMap
    {
        public CExchangeMap()
        {
            dtExchangeResult = new DataTable();

            dtExchangeResult.Columns.Add("ExchangeCode", typeof(string));
            dtExchangeResult.Columns.Add("ExchangeName", typeof(string));
            dtExchangeResult.Columns.Add("n_ClientExMapNo", typeof(int));
            dtExchangeResult.Columns.Add("n_ClientNo", typeof(int));
            dtExchangeResult.Columns.Add("n_ExNo", typeof(int));
            dtExchangeResult.Columns.Add("n_SegmentNo", typeof(int));
            dtExchangeResult.Columns.Add("s_Code", typeof(string));
            dtExchangeResult.Columns.Add("s_CPCode", typeof(string));


            dtExchangeResult.Columns.Add("n_ClientType", typeof(int));
            dtExchangeResult.Columns.Add("n_AccountType", typeof(int));
            dtExchangeResult.Columns.Add("d_ClientAgreementDate", typeof(string));
            dtExchangeResult.Columns.Add("s_InpersonVerification", typeof(string));
            dtExchangeResult.Columns.Add("s_ClientStatus", typeof(string));
            dtExchangeResult.Columns.Add("s_Remarks", typeof(string));
            dtExchangeResult.Columns.Add("s_UCCDownloaded", typeof(string));
            dtExchangeResult.Columns.Add("n_BatchNo", typeof(int));


            dtExchangeResult.Columns.Add("n_BranchNo", typeof(int));
            dtExchangeResult.Columns.Add("n_GroupNo", typeof(int));
            dtExchangeResult.Columns.Add("n_UCCRejRefNo", typeof(int));
            dtExchangeResult.Columns.Add("d_LastModifiedDateTime", typeof(string));
            dtExchangeResult.Columns.Add("s_Relationship", typeof(string));
            dtExchangeResult.Columns.Add("n_UserNo", typeof(int));
            dtExchangeResult.Columns.Add("s_CTCLTWSId", typeof(string));


            dtExchangeResult.Columns.Add("s_TradingBranchCode", typeof(string));
            dtExchangeResult.Columns.Add("n_MakerUser", typeof(int));
            dtExchangeResult.Columns.Add("d_MakerDatetime", typeof(int));
            dtExchangeResult.Columns.Add("n_AuthorizeUser", typeof(int));
            dtExchangeResult.Columns.Add("d_AuthorizeDatetime", typeof(string));
            dtExchangeResult.Columns.Add("s_AuthorizationRemarks", typeof(string));
            dtExchangeResult.Columns.Add("s_IsPendingAuth", typeof(string));
                  
        }

        #region Variables
        public int ClientNo { get; set; }
        public int ExMapingNo { get; set; }
        public int TradingCode { get; set; }
        public int CtclId { get; set; }
        public int TradingBranchId { get; set; }
        public int ExchangeNo { get; set; }
        public int EntityTypeId { get; set; }
        public string EntityType { get; set; } 
        public int AddModifyFlag { get; set; }
        public DataTable dtExchangeResult { get; set; }
        public DateTime? dLastUpdatedDate { get; set; }  
        #endregion

        #region GetExchangeDetails
        /// <summary>
        /// Get Entity Exchange details
        /// </summary>
        /// <param name="nClientNo">ClientNo</param>
        /// <returns>Method Execution result</returns>
        public MethodExecResult GetExchangeDetails(int nClientNo, ref DataTable dtResult)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetExchangeDetails");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@pn_EntityNo", SqlDbType.Int, nClientNo);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                    return new MethodExecResult(1, "No data found", "stp_GetExchangeDetails Database returned no data. UserNo. " +
                        AppEnvironment.AppUser.UserNo.ToString(), null);
                else
                {
                    dtResult = l_dsReturnData.Tables[0];
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        }

        public MethodExecResult GetExchangeDetailsForProduct(int nClientNo, ref DataTable dtResult,string Operation)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_CCMMasterEntityExchangeDetails");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@pn_ClientNo ", SqlDbType.Int, nClientNo);
            l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, Operation);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);


            //l_objDbWorkItem.AddParameter("@s_Code", SqlDbType.VarChar, TradingCode);
            //l_objDbWorkItem.AddParameter("@s_CTCLTWSId", SqlDbType.VarChar, CtclId);
            //l_objDbWorkItem.AddParameter("@s_TradingBranchCode", SqlDbType.VarChar, TradingBranchId);
            //l_objDbWorkItem.AddParameter("@n_ExNo", SqlDbType.Int, ExchangeNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                    return new MethodExecResult(1, "No data found", "stp_GetExchangeDetailsForProduct Database returned no data. UserNo. " +
                        AppEnvironment.AppUser.UserNo.ToString(), null);
                else
                {
                    dtResult = l_dsReturnData.Tables[0];
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        }
        #endregion

        #region  UpdateExchangeData
        public MethodExecResult UpdateExchangeData()
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCUpdateEntityExchangeData");
            try
            {

                l_objDbWorkItem.ResultType = QueryType.DataSet;
                l_objDbWorkItem.AddParameter("@pn_AddModify", SqlDbType.Int, this.AddModifyFlag);
                l_objDbWorkItem.AddParameter("@pn_ExMapNo", SqlDbType.Int, this.ExMapingNo);
                l_objDbWorkItem.AddParameter("@pn_ExNo", SqlDbType.Int, this.ExchangeNo);
                l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, this.ClientNo);
                l_objDbWorkItem.AddParameter("@pn_TradingNo", SqlDbType.Int, this.TradingCode);
                l_objDbWorkItem.AddParameter("@pn_CtciId", SqlDbType.Int, this.CtclId);
                l_objDbWorkItem.AddParameter("@pn_TradingBranchId", SqlDbType.Int, this.TradingBranchId);

                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
               
                return l_objDbWorkItem.ExecutionStatus;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex.Message);
                return l_objDbWorkItem.ExecutionStatus;
            }
        }
        #endregion

        public void SetDataResult()
        {
            DataRow[] dr;
            if (this.ClientNo == 0)
                dr = dtExchangeResult.Select("n_ExNo = " + "'" + ClientNo + "'");
            else
                dr = dtExchangeResult.Select("n_ExNo = " + ClientNo + "");

            if (dr.Length > 0)
            {
                string changedFlag = "N";

                if (Convert.ToInt32(dr[0]["n_ExNo"]) != ExchangeNo)
                {
                    dr[0]["n_ExNo"] = ExchangeNo;
                    changedFlag = "Y";
                }

                //if (dr[0]["s_BankCode"].ToString() != BankCode)
                //{
                //    dr[0]["s_BankCode"] = BankCode;
                //    changedFlag = "Y";
                //}

                //if (dr[0]["s_Branch"].ToString() != Branch)
                //{
                //    dr[0]["s_Branch"] = Branch;
                //    changedFlag = "Y";
                //}

                //if (dr[0]["s_AccountType"].ToString() != AccountType)
                //{
                //    dr[0]["s_AccountType"] = AccountType;
                //    changedFlag = "Y";
                //}

                //if (Convert.ToInt32(dr[0]["n_AccountTypeVal"]) != AccountTypeVal)
                //{
                //    dr[0]["n_AccountTypeVal"] = AccountTypeVal;
                //    changedFlag = "Y";
                //}

                //if (dr[0]["s_BankName"].ToString() != BankName)
                //{
                //    dr[0]["s_BankName"] = BankName;
                //    changedFlag = "Y";
                //}
                //if (dr[0]["s_AccountNo"].ToString() != AccountNo)
                //{
                //    dr[0]["s_AccountNo"] = AccountNo;
                //    changedFlag = "Y";
                //}

                //if (dr[0]["s_AccountType"].ToString() != AccountType)
                //{
                //    dr[0]["s_AccountType"] = AccountType;
                //    changedFlag = "Y";
                //}
                //if (dr[0]["s_CustomerID"].ToString() != CustNo)
                //{
                //    dr[0]["s_CustomerID"] = CustNo;
                //    changedFlag = "Y";
                //}
                //if (dr[0]["s_IFSCCode"].ToString() != IFSCCode)
                //{
                //    dr[0]["s_IFSCCode"] = IFSCCode;
                //    changedFlag = "Y";
                //}
                //if (dr[0]["s_NameOnCheque"].ToString() != NameOnCheque)
                //{
                //    dr[0]["s_NameOnCheque"] = NameOnCheque;
                //    changedFlag = "Y";
                //}
                //if (dr[0]["s_Default"].ToString() != sDefault)
                //{
                //    dr[0]["s_Default"] = sDefault;
                //    changedFlag = "Y";
                //}

                //dr[0]["s_HasChanged"] = changedFlag;

                if (changedFlag == "Y")
                {
                    dtExchangeResult.AcceptChanges();
                }
            }
           // else if (!string.IsNullOrEmpty(ExchangeNo))
                dtExchangeResult.Rows.Add(new object[] { ExchangeNo});// BankCode, BankName, MICR, Branch, AccountType, AccountTypeVal, CustNo, AccountNo, IFSCCode, NameOnCheque, sDefault, "Y", System.DateTime.Now });


        }
    }
}
