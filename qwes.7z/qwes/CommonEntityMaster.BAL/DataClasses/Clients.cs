﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;
using FTIL.Match.Common.Log;

namespace FTIL.Match.CDD.BAL.DataStore
{

    #region ExchangeType (enum)
    public enum ExchangeType
    {
        None = 0,
        NSE = 3015,
        BSE = 1,
        MCXSX = 5000
    }
    #endregion


    public class Clients
    {
        #region class variables

        public List<Client> objClients;
        public static string BaseDirectory = AppDomain.CurrentDomain.BaseDirectory.ToString();
        public static readonly string CLIENTNAME = "ClientName";
        public static readonly string CLIENTCODE = "ClientCode";
        public static readonly string ERRORS = "Errors";
        public static readonly string FILENAME = "UCI_";
        public static readonly string FILEEXTENSION = ".csv";
        
        #endregion class variables

        public string BatchNo { get; set; }

        public Clients()
        {
            objClients = new List<Client>();
        }

        #region Public methods

        /// <summary>
        /// Add new client
        /// </summary>
        /// <param name="oClient">Client Object filled with details</param>
        /// <returns>0 - Success, -1 - Failed</returns>
        public int Add(Client oClient)
        {
            int oResult = 1; ;

            if (objClients != null)
            {
                oResult = objClients.FindIndex(obj => obj.ClientNo == oClient.ClientNo);
            }
            if (oResult != 0)
            {
                objClients.Add(oClient);
                return 0;
            }
            else
            {
                return -1;
            }
        }

        #region Commented code
        ///// <summary>
        ///// Validate UCC Client
        ///// </summary>
        ///// <returns></returns>
        //public DataTable ClientUCCValidate()
        //{

        //    StringBuilder sb = new StringBuilder();
        //    CExportNSEValidator objNSEValidator = new CExportNSEValidator();
        //    DataTable tb_ErrorTable = new DataTable();
        //    try
        //    {
        //        //validate client data
        //        foreach (Client oClient in objClients)
        //        {
        //            objNSEValidator.ValidateClient(oClient);
        //        }

        //        //adding header 
        //        //sb.AppendLine(objNSEValidator.AddHeader());

        //        //exporting valid  details
        //        foreach (Client oClient in objClients)
        //        {
        //            if (oClient.IsValidClient)
        //                sb.AppendLine(objNSEValidator.NSEExport(oClient));
        //        }

        //        string strCsvData = sb.ToString();

        //        if (!string.IsNullOrEmpty(strCsvData))
        //            ExportToCSV(strCsvData);

        //        tb_ErrorTable = ConvertToDataTable();
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.Instance.WriteLog(this, "ClientUCCValidate() Error processing UCC Client Export", ex);
        //    }
        //    return tb_ErrorTable;
        //}

        ///// <summary>
        /////  Export UCC as per exchange no.
        ///// </summary>
        ///// <param name="nExchNo"></param>
        ///// <returns>dt_ErrorTable</returns>
        //public DataTable ClientExport(int nExchNo)
        //{
        //    DataTable dt_ErrorTable = new DataTable();

        //    if (nExchNo == (int)ExchangeType.NSE)
        //    {
        //        dt_ErrorTable = ExportUCCforNSE();
        //    }
        //    else if (nExchNo == (int)ExchangeType.BSE)
        //    {
        //        dt_ErrorTable = ExportUCCforBSE();
        //    }
        //    else if (nExchNo == (int)ExchangeType.MCXSX)
        //    {
        //        dt_ErrorTable = ExportUCCforMCXSX();
        //    }
        //    return dt_ErrorTable;
        //}

        ///// <summary>
        /////  Export UCC in NSE format
        ///// </summary>
        ///// <returns>dt_ErrorTable</returns>
        //private DataTable ExportUCCforNSE()
        //{
        //    StringBuilder sb = new StringBuilder();
        //    CExportNSEValidator objNSEValidator = new CExportNSEValidator();
        //    DataTable tb_ErrorTable = new DataTable();
        //    try
        //    {
        //        string strCsvData = string.Empty;
        //        foreach (Client oClient in objClients)
        //        {
        //            objNSEValidator.ValidateClient(oClient);

        //            if (oClient.IsValidClient)
        //                sb.AppendLine(objNSEValidator.NSEExport(oClient));
        //        }
        //        strCsvData = sb.ToString();

        //        if (!string.IsNullOrEmpty(strCsvData))
        //            ExportToCSV(strCsvData);

        //        tb_ErrorTable = ConvertToDataTable();
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.Instance.WriteLog(this, "ExportUCCforNSE() Error while Exporting UCC in NSE format", ex);
        //    }
        //    return tb_ErrorTable;
        //}

        ///// <summary>
        ///// Export UCC in BSE format
        ///// </summary>
        ///// <returns>dt_ErrorTable</returns>
        //private DataTable ExportUCCforBSE()
        //{
        //    DataTable tb_ErrorTable = new DataTable();
        //    try
        //    {

        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.Instance.WriteLog(this, "ExportUCCforBSE() Error while Exporting UCC in BSE format", ex);
        //    }
        //    return tb_ErrorTable;
        //}

        ///// <summary>
        ///// Export UCC in BSE format
        ///// </summary>
        ///// <returns>dt_ErrorTable</returns>
        //private DataTable ExportUCCforMCXSX()
        //{
        //    DataTable tb_ErrorTable = new DataTable();
        //    try
        //    {

        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.Instance.WriteLog(this, "ExportUCCforMCXSX() Error while Exporting UCC in MCX format", ex);
        //    }
        //    return tb_ErrorTable;
        //}

        ///// <summary>
        ///// Convert invalid client objects in to DataTable.
        ///// </summary>
        ///// <returns>DataTable  for invalid clients.</returns>
        //public DataTable ConvertToDataTable()
        //{
        //    DataTable dt_ErrorTable = new DataTable();
        //    try
        //    {
        //        dt_ErrorTable.Columns.Add(CLIENTNAME, typeof(string));
        //        dt_ErrorTable.Columns.Add(CLIENTCODE, typeof(string));
        //        dt_ErrorTable.Columns.Add(ERRORS, typeof(string));

        //        foreach (Client oClient in objClients)
        //        {
        //            if (oClient.IsValidClient == false)
        //                dt_ErrorTable.Rows.Add(oClient.ClientName, oClient.ClientCode, oClient.strErrorString);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.Instance.WriteLog(this, "ConvertToDataTable() Error while Converting invalid client objects in to DataTable.", ex);
        //    }
        //    return dt_ErrorTable;
        //}

        ///// <summary>
        ///// Convert String to CSV File and Export the file.
        ///// </summary>
        ///// <param name="strCsv"></param>
        //public void ExportToCSV(string strCsv)
        //{
        //    try
        //    {
        //        string strdate = DateTime.Now.ToString("yyyyMMdd");
        //        string FileName = FILENAME + strdate + FILEEXTENSION;
        //        string l_ExportFilePath = BaseDirectory + Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["UCCExportFilePath"]);
        //        FileInfo fileinfo = new FileInfo(l_ExportFilePath);
        //        if (!fileinfo.Exists)
        //            Directory.CreateDirectory(fileinfo.Directory.FullName);
        //        string FilePath = l_ExportFilePath + "\\" + FileName;
        //        if (File.Exists(FilePath))
        //        {
        //            File.Delete(FilePath);
        //        }

        //        System.IO.File.WriteAllText(FilePath, strCsv.ToString());
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.Instance.WriteLog(this, "ExportToCSV() Error while Converting String to CSV File and Export the file.", ex);
        //    }
        //}
        #endregion Commented code
        #endregion Public methods

    }
}
