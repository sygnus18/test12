﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UCC.Class;

namespace FTIL.Match.CDD.BAL.DataClasses
{
    /// <summary>
    /// Class for storing Entity data
    /// </summary>
    public class EntityDetails
    {
        public int RowNo { get; set; }
        public int ClientNo { get; set; }
        public int GuardianClientNo { get; set; }
        public int EntityPhotoDocNo { get; set; }

        public string EntityId { get; set; }
        public string KYCFormNo { get; set; }
        public string CustomerID { get; set; }

   
        public string EntityType { get; set; }
        public string Applicant_Name { get; set; }
        public string Branch { get; set; }
        public string Short_Code { get; set; }
        public string FristName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string SkypeId { get; set; }
        public string Title { get; set; }
        public string AddressNo { get; set; }
        public string PerAddressNo { get; set; }
        public string IS_Parent_Accont { get; set; }
        public int Parent_Account_No { get; set; }
        public string Father_sHusbands_Name { get; set; }
        public string Gender { get; set; }
        public string Marital_status { get; set; }
        public DateTime? DOB_OR_DOI { get; set; }
        public string Photo_upload { get; set; }
        public string PAN { get; set; }
        public string Evidence_Documents { get; set; }
        public string UID_Aadhar_card { get; set; }
        public string StatusText { get; set; }
        public string StatusNonIndVal { get; set; }
        public string Status_Date { get; set; }
        public string Client_profile_status { get; set; }
        public string POA_type { get; set; }
        public string POA_effective_from { get; set; }
        public string POA_effective_till { get; set; }
        public string POA_Photo_upload { get; set; }
        public string POA_Name { get; set; }
        public string POA_Address { get; set; }
        public string Nationality { get; set; }
        public string NationalityOther { get; set; }

        public Address PermanentAddress { get; set; }
        public Address CorrespondenceAddress { get; set; }
     
        public string SameCorrPermAdd { get; set; }
        public string Politically_Exposed_Person { get; set; }
        public string Any_Other_Information { get; set; }
        public DateTime? Date_of_Declaration { get; set; }
        public DateTime? DateOfCreation { get; set; }
        public DateTime? DateOfBusinessComm { get; set; }
        public string Originals_verified_TRUE { get; set; }
        public string SelfAttested_Self_Certified { get; set; }
        public string Document_received_Date { get; set; }
        public string No_Of_Documents { get; set; }
        public string No_Of_Documents2 { get; set; }
        public string No_Of_Documents3 { get; set; }
        public string No_Of_Documents4 { get; set; }
        public string RBI_APPROVAL_NO { get; set; }
        public string PlaceOfIncorpration { get; set; }
        public string CIN { get; set; }
        public string KYCCode { get; set; }

        public string AnnualIncome { get; set; }
        public DateTime? AnnualIncomeDate { get; set; }
        public string Networth { get; set; }
        public DateTime? NetworthDate { get; set; }
        public string Occupation { get; set; }
        public string OccupationOther { get; set; }
        public string PEP { get; set; }
        public string PEPDesc { get; set; }
        public string UserId { get; set; }
        public string FacilityType { get; set; }
        public string Guardian_Name { get; set; }
        public int iCount { get; set; }

        public bool IsValid { get; set; }
        public bool IsValidOther { get; set; }
        public int n_Solutation { get; set; }
        public string StandingInstruction { get; set; }
        public string SEBIRegistration {get; set;}
        public string TaxDeductionStatus {get; set;}
        public string SelfAuth { get; set; }
        public string sSubType { get; set; }
        public string AuthrizationStatus { get; set; }
        public string AuthRemarks { get; set; }
        public int MakerUserNo { get; set; }
        public int LastUpdatedUserNo { get; set; }
        public string DefaultIDDetails { get; set; }
        public string PANExempt { get; set; }
        public string sErrorMsg { get; set; }

        public string PreferenceNo { get; set; }
        public string G3 { get; set; }
        public string FmlyGroupCode { get; set; }
        public string preferenceCode { get; set; }
        public string BrokMethod { get; set; }
        public string BrokSlab { get; set; }
        public string Charge { get; set; }
        public string AllowtoBrok { get; set; }
        public string Bills { get; set; }
        public string Contracts { get; set; }
        public string ChargeSlab { get; set; }
        public string IntRate { get; set; }
        public string POA { get; set; }
        public string RunningClient { get; set; }
        public string TradeCode { get; set; }
        public string PaymentMode { get; set; }
        public string GlobalPreferences { get; set; }
        public string STInBrok { get; set; }
        public string STTInBrok { get; set; }
        public string SDInBrok { get; set; }
        public string CFInBrok { get; set; }
        public string CcInBrok { get; set; }
        public string AuctionPenalInBrok { get; set; }
        public string TOInBrok { get; set; }
        public string SebinBrok { get; set; }
        public string BeforePayInFunds { get; set; }
        public string BeforePayInSecurities { get; set; }
        public string AfterPayOutFunds { get; set; }
        public string AfterPayOutSecurities { get; set; }

        public string ServProvider { get; set; }
        public string FlatIso { get; set; }
        public string Format { get; set; }
        public string DownloadFor { get; set; }
        public string ContractFormType { get; set; }
        public string ContrctNoGen { get; set; }
        public string BillGeneration { get; set; }
        public string BillNoGen { get; set; }
        public string SettlementOn { get; set; }
        public string StockTransfer { get; set; }
        public string ChargeDeliveryCharge { get; set; }
        public string SettlementDateOnContract { get; set; }
        public string RegionMapping { get; set; }

        public string CallingType { get; set; }

        public string ContractNote_Mode { get; set; }

        public string Education { get; set; }

        public string VerificationMode { get; set; }
        public string Title2 { get; set; }
        public string MotherName { get; set; }
        public string MaidenName { get; set; }
        public string StatementPeriodicity { get; set; }

        public string companyname  { get; set; } 
        public string companyadd  { get; set; }
        public string pincode  { get; set; }
        public string designation  { get; set; }
        public string typeoftrade { get; set; }

        /// <summary>
        /// Check Authorised status of record
        /// </summary>
        public bool IsAuthorized
        {
            get
            {
                if (string.IsNullOrEmpty(AuthrizationStatus)) return true;
                return AuthrizationStatus == "Authorized";
            }

        }
      

        /// <summary>
        /// Validate the fields
        /// </summary>
        /// <param name="FieldVal">Field value</param>
        /// <param name="InvalidCiteria">Invalid condition</param>
        /// <param name="FieldName">Name of the Fields</param>
        /// <param name="sMsg">Error message</param>
        /// <returns>Error Text</returns>
        public string ValidateField(string FieldVal, string InvalidCiteria, string FieldName, ref string sMsg)
        {
            bool IsVaild;
            string RetVal;
            RetVal = "";
            IsVaild = FieldVal != InvalidCiteria;
            if (!IsVaild)
            {
                iCount +=1;
                RetVal = FieldName ;
                if (iCount==1) sMsg = " can not be blank.";
                else sMsg = " are mandatory.";
            }

            return RetVal;
        }
       
    }
}
