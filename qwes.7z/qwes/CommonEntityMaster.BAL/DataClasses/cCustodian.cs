﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using System.Data;
using FTIL.Match.Common.Log;
using System.Data.SqlClient;
using System.Xml;
using System.IO;

namespace FTIL.Match.CDD.BAL.DataClasses
{
   public class cCustodian
    {

        public cCustodian()
        {
            dtCustodianResult = new DataTable();
            dtCustodianResult.Columns.Add("n_ExNo", typeof(int)); 
            dtCustodianResult.Columns.Add("n_CustNo", typeof(int));
            dtCustodianResult.Columns.Add("s_CustCode", typeof(string));
            dtCustodianResult.Columns.Add("s_CustodianName", typeof(string));
            dtCustodianResult.Columns.Add("s_ParticipantId", typeof(string));
            dtCustodianResult.Columns.Add("FromDate", typeof(DateTime));           
            dtCustodianResult.Columns.Add("ToDate", typeof(DateTime));


        }
        #region Variables
        public int ClientNo { get; set; }
        public int CustNo { get; set; }
        public string CustCode { get; set; }
        public string ParticipantId { get; set; }
        public string CustodianName { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public DateTime? dLastUpdatedDate { get; set; }
        public int ExchangeNo { get; set; }
        public int EntityTypeId { get; set; }
        public string EntityType { get; set; }
        public int AddModifyFlag { get; set; }
        public DataTable dtCustodianResult { get; set; }
        #endregion


       
    }
}
