﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTIL.Match.CDD.BAL.DataStore
{
    public enum Client_AddressType
    {
        Registered = 4, //permanant
        ContactPerson = 4,//3
        Correspondence = 1,//4
        Others = 5, //introducer & Authhorizer
        RelatedParty=8 //nominee
    }

    public class ClientAddresses
    {
        #region class variables
        /// <summary>
        /// List of CAddress 
        /// </summary>
        private List<ClientAddress> m_AddressList;

        //public List<ClientAddress> objClientAddresses;

        #endregion class variables

        #region Constructor
       
        public ClientAddresses()
        {
            m_AddressList = new List<ClientAddress>();
        }
        
        #endregion

        #region Properties

        /// <summary>
        /// Address List
        /// </summary>
        public List<ClientAddress> AddressList
        {
            get { return m_AddressList; }
            set { m_AddressList = value; }
        }
        #endregion Properties

        #region Public methods

        #region Add new client address
        /// <summary>
        /// Add new client address
        /// </summary>
        /// <param name="oClient">ClientAddress Object filled with details</param>
        public void Add(ClientAddress oClientAddress)
        {
            m_AddressList.Add(oClientAddress);
        }
        #endregion Add new client address

        #region Get address by AddressType
        /// <summary>
        /// Get address by AddressType
        /// </summary>
        /// <param name="addressType">Address Type Enum</param>
        /// <returns></returns>
        public ClientAddress GetAddressByType(Client_AddressType addressType)
        {
            return m_AddressList.Find(addr => addr.AddressType == (int)addressType);
        }
        #endregion Get address by AddressType

        #region Get address by ClientNo
        /// <summary>
        /// Get address by ClientNo
        /// </summary>
        /// <param name="addressType">Address Type Enum</param>
        /// <returns></returns>
        public ClientAddress GetAddressByClientNo(int ClientNo, Client_AddressType addressType)
        {
            return m_AddressList.Find(addr => (addr.ClientNo == ClientNo && addr.AddressType == (int)addressType));
        }
        #endregion Get address by AddressType

        #region Validate UCC Client address
        /// <summary>
        /// Validate UCC Client address
        /// </summary>
        /// <returns></returns>
        public string ClientAddressValidate()
        {
            StringBuilder sb = new StringBuilder();

            foreach (ClientAddress oClientAddress in m_AddressList)
            {
                sb.Append(oClientAddress.Validate());
            }

            return sb.ToString();
        }
        #endregion Validate UCC Client address

        #endregion Public methods
    }
}
