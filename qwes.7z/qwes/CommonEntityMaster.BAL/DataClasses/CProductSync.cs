﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using System.Data;
using FTIL.Match.Common.Log;
using System.Data.SqlClient;
using System.Xml;
using System.IO;

namespace FTIL.Match.CDD.BAL
{
    public class CProductSync
    {
        public int ClientNo { get; set; }
        public string CDDCode { get; set; }
        public string ClientName { get; set; }
        public string CustId { get; set; }
        public string EntityType { get; set; }
        public string EntityProductID { get; set; }
        public int ProductId { get; set; } 

        public int BranchNo { get; set; }
        public int GroupNo { get; set; }
        public int UserId { get; set; }
        public int EntityTypeId { get; set; }

        public int nErrorNo { get; set; }
        public string sErrorMsg { get; set; }

        public string DPType { get; set; }
        public string DPCode { get; set; }
        public DateTime? dFromDate { get; set;}

        public string MatchConstr { get; set; }
        public string DPMatchConstr { get; set; }
        private DataTable dtCustom;

        public string sXMLData { get; set; }

        #region GetEntityProducts
        /// <summary>
        /// Get Entity Product Map details
        /// </summary>
        /// <param name="nClientNo">ClientNo</param>
        /// <returns>Method Execution result</returns>
        public MethodExecResult GetEntityProducts(int nClientNo, ref DataTable dtResult)
        {

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetEntityProductDetails");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@pn_EntityNo", SqlDbType.Int, nClientNo);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                    return new MethodExecResult(1, "No data found", "stp_GetEntityProductDetails Database returned no data. UserNo. " +
                        AppEnvironment.AppUser.UserNo.ToString(), null);
                else
                {
                    dtResult = l_dsReturnData.Tables[0];
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        }
        #endregion


        #region SyncProducts
        /// <summary>
        /// Sync Products Map details
        /// </summary>
        /// <param name="nProductId">ClientNo</param>
        /// <returns>Method Execution result</returns>
        public MethodExecResult SyncProducts(int nProductId)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_SyncProductDetails");
            try
            {
                this.EntityTypeId = this.EntityType == "I" ? 1 : 2;
                l_objDbWorkItem.ResultType = QueryType.DataSet;

                SqlParameter outParamErrNo = new SqlParameter("@pn_ErrorNo", SqlDbType.Int, 8);
                outParamErrNo.Direction = ParameterDirection.Output;
                l_objDbWorkItem.AddParameter(outParamErrNo);

                SqlParameter outParamErrMsg = new SqlParameter("@ps_ErrorDesc", SqlDbType.VarChar, 100);
                outParamErrMsg.Direction = ParameterDirection.Output;
                l_objDbWorkItem.AddParameter(outParamErrMsg);

                l_objDbWorkItem.AddParameter("@pn_ProductId", SqlDbType.Int, nProductId);
                l_objDbWorkItem.AddParameter("@ps_ClientCode", SqlDbType.VarChar, this.EntityProductID);
                l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, this.ClientNo);
                l_objDbWorkItem.AddParameter("@ps_CDDCode", SqlDbType.VarChar, this.CDDCode);
                l_objDbWorkItem.AddParameter("@ps_ClientName", SqlDbType.VarChar, this.ClientName);
                l_objDbWorkItem.AddParameter("@ps_ClientCustomerID", SqlDbType.VarChar, this.CustId);
                l_objDbWorkItem.AddParameter("@pn_BranchNo", SqlDbType.Int, 1);
                l_objDbWorkItem.AddParameter("@pn_ClientGroupNo", SqlDbType.Int, 67);
                l_objDbWorkItem.AddParameter("@pn_EntityType", SqlDbType.Int, this.EntityTypeId);

                l_objDbWorkItem.AddParameter("@ErrorNo", SqlDbType.Int, nErrorNo);
                l_objDbWorkItem.AddParameter("@ErrorDesc", SqlDbType.VarChar, this.sErrorMsg);

                if (nProductId==17 || nProductId==18)
                    l_objDbWorkItem.AddParameter("@DPId", SqlDbType.VarChar, this.DPCode);

                l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);
               
                
                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
                if (l_objDbWorkItem.parameters[0].Value == null)
                    sErrorMsg = null;
                else
                {
                    nErrorNo = Convert.ToInt32(l_objDbWorkItem.parameters[0].Value);
                    sErrorMsg = Convert.ToString(l_objDbWorkItem.parameters[1].Value);
                }

                return l_objDbWorkItem.ExecutionStatus;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex.Message);
                return l_objDbWorkItem.ExecutionStatus;
            }
        }
        #endregion



        #region SyncProductsMatch
        /// <summary>
        /// Sync Products Map details for Match
        /// </summary>
        /// <param name="nProductId">ClientNo</param>
        /// <returns>Method Execution result</returns>
        public int SyncProductsMatch(int nProductId)
        {
            try
            {
                setConnection();
                SqlConnection con = new SqlConnection(MatchConstr);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "stp_APIClient";

                con.Open();
                cmd.Connection = con;
                cmd.CommandTimeout = 0;
                this.EntityTypeId = this.EntityType == "I" ? 1 : 2;
                //l_objDbWorkItem.ResultType = QueryType.DataSet;

                SqlParameter outParamErrNo = new SqlParameter("@ErrorNo", SqlDbType.Int, 8);
                outParamErrNo.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(outParamErrNo);

                SqlParameter outParamErrMsg = new SqlParameter("@ErrorDesc", SqlDbType.VarChar, 100);
                outParamErrMsg.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(outParamErrMsg);

                cmd.Parameters.Add("@ClientCode", SqlDbType.VarChar, 12);
                cmd.Parameters["@ClientCode"].Value = EntityProductID;

                cmd.Parameters.Add("@ClientName", SqlDbType.VarChar, 100);
                cmd.Parameters["@ClientName"].Value = this.ClientName;

                cmd.Parameters.Add("@ClientCustomerID", SqlDbType.VarChar, 30);
                cmd.Parameters["@ClientCustomerID"].Value = this.CustId;

                cmd.Parameters.Add("@BranchNo", SqlDbType.Int);
                cmd.Parameters["@BranchNo"].Value = 1;

                cmd.Parameters.Add("@ClientGroupNo", SqlDbType.Int);
                cmd.Parameters["@ClientGroupNo"].Value = 67;

                cmd.Parameters.Add("@UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);
                cmd.Parameters["@UserNo"].Value = AppEnvironment.AppUser.UserNo;

                cmd.Parameters.Add("@EntityType", SqlDbType.Int);
                cmd.Parameters["@EntityType"].Value = this.EntityTypeId;

               int iResult=cmd.ExecuteNonQuery();
               con.Close();
                if (cmd.Parameters[0].Value == null)
                    sErrorMsg = null;
                else
                {
                    nErrorNo = Convert.ToInt32(cmd.Parameters[0].Value);
                    sErrorMsg = Convert.ToString(cmd.Parameters[1].Value);
                }

                if (nErrorNo == 0)
                    SyncProducts(nProductId);
                return 0;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex.Message);
                nErrorNo = 2;
                sErrorMsg = ex.Message;
                return -1;
            }
        }
        #endregion


        #region SyncProductsMatchDP
        /// <summary>
        /// Sync Products Map details for MatchDP
        /// </summary>
        /// <param name="nProductId">ClientNo</param>
        /// <returns>Method Execution result</returns>
        public int SyncProductsMatchDP(int nProductId)
        {
            try
            {
                //if (nProductId == 17)
                //    DPXLMData();
                //return 0;

                setConnection();
                SqlConnection con = new SqlConnection(DPMatchConstr);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "stp_APIDPClient";

                con.Open();
                cmd.Connection = con;
                cmd.CommandTimeout = 0;
                this.EntityTypeId = this.EntityType == "I" ? 1 : 2;
                SqlParameter outParamErrNo = new SqlParameter("@ErrorNo", SqlDbType.Int, 8);
                outParamErrNo.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(outParamErrNo);

                SqlParameter outParamErrMsg = new SqlParameter("@ErrorDesc", SqlDbType.VarChar, 100);
                outParamErrMsg.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(outParamErrMsg);

                cmd.Parameters.Add("@ClientCode", SqlDbType.VarChar, 12);
                cmd.Parameters["@ClientCode"].Value = EntityProductID;

                cmd.Parameters.Add("@DPId", SqlDbType.VarChar, 20);
                cmd.Parameters["@DPId"].Value = DPCode;

                cmd.Parameters.Add("@DPType", SqlDbType.VarChar, 10);
                cmd.Parameters["@DPType"].Value = DPType;

                cmd.Parameters.Add("@ClientName", SqlDbType.VarChar, 100);
                cmd.Parameters["@ClientName"].Value = this.ClientName;

                cmd.Parameters.Add("@ClientCustomerID", SqlDbType.VarChar, 30);
                cmd.Parameters["@ClientCustomerID"].Value = this.CustId;

                cmd.Parameters.Add("@dtFromDate", SqlDbType.DateTime);
                cmd.Parameters["@dtFromDate"].Value = dFromDate;

                cmd.Parameters.Add("@UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);
                cmd.Parameters["@UserNo"].Value = AppEnvironment.AppUser.UserNo;

                int iResult = cmd.ExecuteNonQuery();
                con.Close();
                if (cmd.Parameters[0].Value == null)
                    sErrorMsg = null;
                else
                {
                    nErrorNo = Convert.ToInt32(cmd.Parameters[0].Value);
                    sErrorMsg = Convert.ToString(cmd.Parameters[1].Value);
                }
                cmd = null;
                if (nErrorNo == 0)
                {
                    SyncProducts(nProductId);
                    //if(nProductId==17)
                    //    DPXLMData();
                }
                return 0;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex.Message);
                nErrorNo = 2;
                sErrorMsg = ex.Message;
                return -1;
            }
        }
        #endregion


        #region DPXLM
        /// <summary>
        /// Sync Products Map details for MatchDP
        /// </summary>
        /// <param name="nProductId">ClientNo</param>
        /// <returns>Method Execution result</returns>
        public string DPXLMData() 
        {

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetClientDetails");
            try
            {
                string sXML = string.Empty;
                this.EntityTypeId = this.EntityType == "I" ? 1 : 2;
                l_objDbWorkItem.ResultType = QueryType.DataSet;

                //SqlParameter outParamErrMsg = new SqlParameter("@ps_ErrorDesc", SqlDbType.VarChar, 100);
                //outParamErrMsg.Direction = ParameterDirection.Output;
                //l_objDbWorkItem.AddParameter(outParamErrMsg);
                
                l_objDbWorkItem.AddParameter("@pd_ClientNo", SqlDbType.Int, ClientNo);
                l_objDbWorkItem.AddParameter("@ps_DPType", SqlDbType.VarChar, this.DPType);
                l_objDbWorkItem.AddParameter("@ps_MappingCode", SqlDbType.VarChar, this.EntityProductID);
                l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);
                l_objDbWorkItem.AddParameter("@ps_EntityType", SqlDbType.VarChar, this.EntityType == "I" ? "I" : "NI");
                             
                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
                if (l_objDbWorkItem.parameters[0].Value == null)
                    sErrorMsg = null;
                else
                {
                    //nErrorNo = Convert.ToInt32(l_objDbWorkItem.parameters[0].Value);
                    //sErrorMsg = Convert.ToString(l_objDbWorkItem.parameters[1].Value);
                }
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;

                //dtCustom = null;
                //GetCustomizationDetails(this.ProductId, ref dtCustom, CustId);

                createXML(l_dsReturnData, ref sXML);
                this.sXMLData = sXML;

                return sXML;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex.Message);
                nErrorNo = 109;
                sErrorMsg = l_objDbWorkItem.ExecutionStatus.ErrorMessage;
                return "-1";
            }

          
        }
        #endregion



        #region GetCustomization
        /// <summary>
        /// Get CDD Customization details
        /// </summary>
        /// <param name="nClientNo">ClientNo</param>
        /// <param name="dtResult">Entity Customization details DataSet</param>
        /// <returns>Method Execution result</returns>
        public MethodExecResult GetCustomizationDetails(int nProductNo, ref DataTable dtCustomResult, string s_CustId)
        {

            dtCustomResult = new DataTable();
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetSetUCCCustomiztionDtl");
            try
            {
                l_objDbWorkItem.ResultType = QueryType.DataSet;

                SqlParameter outParamErrNo = new SqlParameter("@pn_ErrorNo", SqlDbType.Int, 8);
                outParamErrNo.Direction = ParameterDirection.Output;
                l_objDbWorkItem.AddParameter(outParamErrNo);

                SqlParameter outParamErrMsg = new SqlParameter("@ps_ErrorMsg", SqlDbType.VarChar, 100);
                outParamErrMsg.Direction = ParameterDirection.Output;
                l_objDbWorkItem.AddParameter(outParamErrMsg);

                l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, "S");
                l_objDbWorkItem.AddParameter("@ps_CustId", SqlDbType.VarChar, s_CustId);
                l_objDbWorkItem.AddParameter("@pn_ProductNo", SqlDbType.Int, nProductNo);
                l_objDbWorkItem.AddParameter("@UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);
                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
                if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                    if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                        return new MethodExecResult(1, "No data found", "stp_GetSetUCCCustomiztionDtl. Database returned no data. UserNo. " +
                            AppEnvironment.AppUser.UserNo.ToString(), null);
                    else
                    {
                        dtCustomResult = l_dsReturnData.Tables[0];
                        return l_objDbWorkItem.ExecutionStatus;
                    }
                }
                else
                {
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }
        }
        #endregion


        public void setConnection()
        {

            MatchConstr = System.Configuration.ConfigurationSettings.AppSettings.Get("Match");
            DPMatchConstr = System.Configuration.ConfigurationSettings.AppSettings.Get("MatchDP");

           DbConnectionParameters l_objDbConParams = null;
           MethodExecResult l_objMethodExecResult = DbConnectionParameters.GetInstanceFromConnString(MatchConstr, ref l_objDbConParams);
           
            MatchConstr="Database=" + l_objDbConParams.Database +
                        ";Server=" + l_objDbConParams.DataSource +
                        ";User ID=" + l_objDbConParams.UserId +
                        ";Password=" + l_objDbConParams.Password + "";

            l_objDbConParams = null;
            l_objMethodExecResult = DbConnectionParameters.GetInstanceFromConnString(DPMatchConstr, ref l_objDbConParams);

            DPMatchConstr = "Database=" + l_objDbConParams.Database +
                        ";Server=" + l_objDbConParams.DataSource +
                        ";User ID=" + l_objDbConParams.UserId +
                        ";Password=" + l_objDbConParams.Password + "";

        }

        private void createXML(DataSet ds, ref string sXML)
        {
            try
            {
                string sXMLData;
            
                DataTable dt = new DataTable();
                dt = ds.Tables[0];
                ds.Tables[0].TableName = "MasterData";
                ds.Tables[1].TableName = "CustemFields";
                sXMLData = ds.GetXml();
                sXML = sXMLData;

                //DataSet dsXML = new DataSet();
                //StringReader stream = null;
                //XmlTextReader reader = null;
                //stream = new StringReader(sXMLData);
                //reader = new XmlTextReader(stream);
                //dsXML.ReadXml(reader);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex.Message);
            }

        }
        private void createXML_OLD(DataSet ds)
        {
            try
            {
                DataTable dt = new DataTable();
                dt = ds.Tables[0];

                //ds.WriteXml("MatchDPTest.xml");
                //return;

                XmlTextWriter writer = new XmlTextWriter("MatchDP.xml", System.Text.Encoding.UTF8);
                writer.WriteStartDocument(true);
                writer.Formatting = Formatting.Indented;
                writer.Indentation = 2;
                writer.WriteStartElement("MatchXML");
                writer.WriteStartElement("MasterData");

                for (int iCnt = 1; iCnt <= dt.Columns.Count - 1; iCnt++)
                {

                    createNode(dt.Columns[iCnt].ColumnName, dt.DefaultView[0][iCnt].ToString(), writer);

                }

                writer.WriteEndElement();
                
                //--------------------DP Custom fields----------------------------
                writer.WriteStartElement("CustomFields");

                for (int iCnt = 0; iCnt <= dtCustom.Rows.Count - 1; iCnt++)
                {
                    createNode(dtCustom.Rows[iCnt]["s_FieldName"].ToString(), dtCustom.DefaultView[0]["s_FieldValue"].ToString(), writer);
                }
                writer.WriteEndElement();
                writer.WriteEndDocument();

                writer.Close();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex.Message);
            }

        }

        private void createNode(string sColName, string sColVal, XmlTextWriter writer)
        {
            if (sColVal == "")
                sColVal = "";

            writer.WriteStartElement(sColName);
            writer.WriteRaw(sColVal);
            writer.WriteFullEndElement();
            //writer.WriteString(sColVal);
            //writer.WriteEndElement();
        }



    }
}
