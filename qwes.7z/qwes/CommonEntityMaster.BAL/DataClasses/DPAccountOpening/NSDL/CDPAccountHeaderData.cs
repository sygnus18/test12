﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTIL.Match.CDD.BAL.DataClasses.DPAccountOpening
{
    class CDPAccountHeaderData
    {
        //Header Record (01)
        public int RecordType { get; set; }

        //DP’s own DP Id
        public string DPId { get; set; }

        //F- Full OR I-Incremental
        public string FullOrIncrementalFlag { get; set; }

        //Applicable only in case of Incremental. It is a system date from onwards incremental information  extracted
        public string IncrementalReferenceDate { get; set; }

        //System Date
        public string StatementPreparationDate { get; set; }

        //System Time
        public string StatementPreparationTime { get; set; }

        public int TotalRecords { get; set; }

        //Unique for each file. 
        public string BatchNumber { get; set; }

        public string Filler { get; set; }

        public CDPAccountHeaderData()
        {
            RecordType = 1;
            DPId = "IN303270";//for yes bank - temp
        }

    }
}
