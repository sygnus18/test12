﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FTIL.Match.CDD.BAL.DataStore;
using FTIL.Match.Common.Log;
using System.Data;
using System.Configuration;
using System.Data;
using XceedZipLib;
using FTIL.Match.CDD.BAL.DataClasses.CKYC;

namespace FTIL.Match.CDD.BAL.DataClasses.DPAccountOpening
{
    public class CDpAccount
    {
        #region class variables
        public StringBuilder sbClientUploadDetails;
        public static readonly string SEPARATOR = "|";
        public static readonly string DATEFORMAT = "yyyyMMdd";
        public static readonly string DATETIMEFORMAT = "ddMMyyyyHHmmss";
        public static readonly string TIMEFORMAT = "HHmmss";
        public static string BaseDirectory = AppDomain.CurrentDomain.BaseDirectory.ToString();
        public static string DPAccountPath = BaseDirectory + ConfigurationManager.AppSettings["DPAccountOpeningFilesPath"];
        public static string DPAccountDownloadPath = ConfigurationManager.AppSettings["DPAccountOpeningFilesPath"];
        public static string sFICode = ConfigurationManager.AppSettings["FICODE"];
        public static string sRegionOrBranch = ConfigurationManager.AppSettings["REGIONORBRANCH"];
        public static string sBulkUploadFlag = "U";
        public static readonly string FILEEXTENSION = ".txt";
        public static string sdate;
        string sCKYCBulkUploadPath = string.Empty;
        string sCKYCBulkUploadFolderName = string.Empty;
        string ImgFolderPath = string.Empty;
        string BatchNo = "0000";
        string sDPFilePath = string.Empty;
		string sDownloadPath = string.Empty;
        string sDPFolderPath = string.Empty;
        string sDPFolderName = string.Empty;
        #endregion class variables

        #region public properties
        public string sDateOfCreation { get; set; }
        public string UserID { get; set; }
        public int LineNo { get; set; }
        #endregion public properties

        #region constructor
        public CDpAccount(string sUserID)
        {
            sbClientUploadDetails = new StringBuilder();
            UserID = sUserID;
            LineNo = 0;
        }
        #endregion constructor

        #region methods
        #region DP Account Opening file Header Details
        /// <summary>
        /// Add header details.
        /// </summary>
        /// <returns>header string</returns>
        public string HeaderDetails(int nTotalClients)
        {
            StringBuilder sbHeader = new StringBuilder();
            DateTime dCurrentDate = DateTime.Now;

            try
            {
                CDPAccountHeaderData objDPAccountHeaderData = new CDPAccountHeaderData();
                //objDPAccountHeaderData.RecordType.ToString().PadLeft(2, '0');
                objDPAccountHeaderData.DPId = Process.GetFixLenString(objDPAccountHeaderData.DPId, 8);
                objDPAccountHeaderData.FullOrIncrementalFlag = "F";
                if (objDPAccountHeaderData.FullOrIncrementalFlag != "F")
                    objDPAccountHeaderData.IncrementalReferenceDate = dCurrentDate.ToString(DATETIMEFORMAT);

                objDPAccountHeaderData.IncrementalReferenceDate = Process.GetFixLenString(objDPAccountHeaderData.IncrementalReferenceDate, 14);
                objDPAccountHeaderData.StatementPreparationDate = dCurrentDate.ToString(DATEFORMAT);
                objDPAccountHeaderData.StatementPreparationTime = dCurrentDate.ToString(TIMEFORMAT);
                objDPAccountHeaderData.TotalRecords = nTotalClients;
                objDPAccountHeaderData.BatchNumber = Process.GetFixLenString(BatchNo.ToString(),4,'0');

                sbHeader.Append(Process.GetFixLenString(objDPAccountHeaderData.RecordType.ToString(),2, '0'));//1.RecordType  
                sbHeader.Append(Process.GetFixLenString(objDPAccountHeaderData.DPId,8));//2.DPId 
                sbHeader.Append(Process.GetFixLenString(objDPAccountHeaderData.FullOrIncrementalFlag.ToString(),1));//3.FullOrIncrementalFlag 
                sbHeader.Append(Process.GetFixLenString(objDPAccountHeaderData.IncrementalReferenceDate.ToString(),14));//4.IncrementalReferenceDate
                sbHeader.Append(Process.GetFixLenString(objDPAccountHeaderData.StatementPreparationDate.ToString(),8));//5.StatementPreparationDate
                sbHeader.Append(Process.GetFixLenString(objDPAccountHeaderData.StatementPreparationTime.ToString(),6));//6.StatementPreparationTime
                sbHeader.Append(Process.GetFixLenString(objDPAccountHeaderData.TotalRecords.ToString(),7, '0'));//7.TotalRecords 
                sbHeader.Append(Process.GetFixLenString(objDPAccountHeaderData.BatchNumber.ToString(),10));//8.BatchNumber 
                sbHeader.Append(Process.GetFixLenString(objDPAccountHeaderData.Filler,2));//9.Filler 
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "HeaderDetails() Error while Adding DP Account Opening file header details. ", ex);
                throw ex;
            }
            return sbHeader.ToString();
        }
        #endregion DP Account Opening file Header Details

        #region DP Account Opening file Body Details
        /// <summary>
        /// Add DP Account Opening file Body Details.
        /// </summary>
        /// <param name="objClients"></param>
        /// <returns></returns>
        public string BodyDetails(Clients objClients)
        {
            StringBuilder sbBodyDetails = new StringBuilder();
            try
            {
                foreach (Client oClient in objClients.objClients)
                {
                    oClient.LineNo = ++LineNo;
                    sbBodyDetails.Append(DetailRecord(oClient));
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "BodyDetails() Error while adding DP account aoening file Body Details.", ex);
                throw ex;
            }
            //return sbBodyDetails;
            return string.Empty;
        }
        #endregion DP Account Opening file Body Details

        #region Generate DP Account opening file
        public string GenerateDPAccountOpeningFile(Clients objClients,CKYCReferenceData objCKYCReferenceData)
        {
            string strHeaderData = string.Empty;
            string resp = string.Empty;
            int TotalClients = objClients.objClients.Count();
            StringBuilder sbDPAccountOpeningDetails = new StringBuilder();
            DateTime dCurrentDate = DateTime.Now;
            
            if (objCKYCReferenceData.BatchNo != null && objCKYCReferenceData.BatchNo != "0")
                BatchNo = objCKYCReferenceData.BatchNo;
            else
            {
                BatchNo = Process.GetFixLenString(objClients.BatchNo.ToString(), 4, '0');
                objCKYCReferenceData.BatchNo = Process.GetFixLenString(objClients.BatchNo.ToString(), 4, '0');
            }

            //create Folder if not exists
            FileInfo fileinfo = new FileInfo(DPAccountPath);
            if (!fileinfo.Directory.Exists)
                Directory.CreateDirectory(fileinfo.Directory.FullName);
            sDPFolderName = dCurrentDate.ToString(DATEFORMAT);
            sDPFolderPath = DPAccountPath + sDPFolderName + "\\";
            sDPFilePath = sDPFolderPath + dCurrentDate.ToString(DATEFORMAT) +"_DP"+ FILEEXTENSION;
			sDownloadPath = sDPFolderPath;
            objCKYCReferenceData.FileName = dCurrentDate.ToString(DATEFORMAT) + "_DP" + FILEEXTENSION;

            FileInfo ClientWisefileinfo = new FileInfo(sDPFolderPath);

            if (ClientWisefileinfo.Directory.Exists)
                Directory.Delete(ClientWisefileinfo.Directory.FullName,true);

            Directory.CreateDirectory(ClientWisefileinfo.Directory.FullName);
            
            //Delete existing file if exists
            if (File.Exists(sDPFilePath))
            {
                File.Delete(sDPFilePath);
            }

            //Write data in to file. 
            using (StreamWriter swDPAccountFileNew = File.CreateText(sDPFilePath))
            {
                strHeaderData = HeaderDetails(TotalClients);
                swDPAccountFileNew.WriteLine(strHeaderData);

                foreach (Client oClient in objClients.objClients)
                {
                    StringBuilder sbBodyDetails = new StringBuilder();
                    oClient.LineNo = ++LineNo;
                    sbBodyDetails.Append(DetailRecord(oClient));
                    swDPAccountFileNew.WriteLine(sbBodyDetails.ToString());
                }

            }

            //Create Clientwise zip file to store images.
            string sZipfilePath = CreateZipFile(DPAccountPath, sDPFolderName, null, ref resp);

            return sZipfilePath;
        }
        #endregion Generate DP Account opening file

        #region Detail Record per DP Account
        /// <summary>
        /// Detail Record per DP Account
        /// </summary>
        /// <returns></returns>
        public string DetailRecord(Client objClient)
        {
            ClientImageDetail objSignImg = new ClientImageDetail();

            objSignImg = objClient.oClientImageDetails.GetImageByType(Client_ImageType.Signature);//for permanat address
            if (objSignImg != null)
            {
                string ImgName = string.Empty;

                if (!string.IsNullOrEmpty(objClient.KYCFormRefCode))
                    ImgName = objClient.KYCFormRefCode;
                else
                    ImgName = objClient.ClientNo.ToString();

                File.WriteAllBytes(sDPFolderPath + ImgName + ".TIFF", objSignImg.l_bImage);
            }
            CDPAccountClientDetails objCDPAccountClientDetails = new CDPAccountClientDetails();
            StringBuilder sbDPAccountFileBodyDetails = new StringBuilder();
            objCDPAccountClientDetails.BindObject(objClient);
            objCDPAccountClientDetails.LineNo = objClient.LineNo.ToString();

            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.RecordType, 2));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.LineNo, 7 ,'0'));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BranchCode, 6));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.ReferenceNo, 8));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BeneficiaryType, 2, '0'));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BeneficiarySubType, 2, '0'));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BeneficiaryShortName, 16));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BeneficiaryAccountCategory, 2, '0'));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BeneficiaryOccupation, 2, '0'));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BeneficiaryFirstHolderName, 135));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.Notes, 65));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.AdditionalInfo, 50));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.FirstHolderFatherOrHusbandName, 45));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.FirstHolderAddress1, 36));//36
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.FirstHolderAddress2, 36));//36
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.FirstHolderAddress3, 36));//36
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.FirstHolderAddress4, 36));//36
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.FirstHolderAddressPin, 7));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BeneficiaryHolderPhone, 24));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BeneficiaryHolderFax, 24));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BeneficiarySecondHolderName, 45));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.SecondHolderFatherOrHusbandName, 45));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BeneficiaryThirdHolderName, 45));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.ThirdHolderFatherOrHusbandName, 45));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.CorrespondingBPId, 8));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.AddressPreferenceFlag, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.DateOfBirthForSecondHolder, 8));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.DateOfBirthForThirdHolder, 8));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.UCICforFirstHolder, 10));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.UCICforSecondHolder, 10));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.UCICforThirdHolder, 10));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.UCICforGuardian, 10));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.GuardianPAN, 10));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.RGESSFlag, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BSDAFlag, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.POAFlag, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.FirstHolderFinancialDetail, 30));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.SecondHolderFinancialDetail, 30));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.ThirdHolderFinancialDetail, 30));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.NomineeOrGuardianIndicator, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.NomineeOrGuardianName, 45));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.DOBMinor, 8));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.NomineeOrGuardianAddLine1, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.NomineeOrGuardianAddLine2, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.NomineeOrGuardianAddLine3, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.NomineeOrGuardianAddLine4, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.NomineeOrGuardianAddPin, 7));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.StandingInstructionIndicator, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.Filler1, 3));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.IFSCCode, 11));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.IsCommodityClient, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BeneficiaryBankAccountType, 2, '0'));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BeneficiaryBankName, 135));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BenBankAddrLine1, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BenBankAddrLine2, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BenBankAddrLine3, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BenBankAddrLine4, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BenBankAddrPin, 7));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BenMICRCode, 9));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BenRBIRefNo, 50));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BenRBIApprovalDate, 8));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BenSEBIRegNo, 24));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BenTaxDeductionStatus, 20));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.LeadID, 14));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.IsDISNotReq, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.Filler2, 65));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.FirstHolderCorrAdd1, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.FirstHolderCorrAdd2, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.FirstHolderCorrAdd3, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.FirstHolderCorrAdd4, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.FirstHolderCorrAddPin, 10));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BenHolderCorrPhone, 24));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BenHolderCorrFax, 24));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.NomineeMinorIndicator, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.MinorNomineeDOB, 8));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.MinorNomineeGuardianName, 45));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.MinorNomineeGuardianAddr1, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.MinorNomineeGuardianAddr2, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.MinorNomineeGuardianAddr3, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.MinorNomineeGuardianAddr4, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.MinorNomineeGuardianPin, 7));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BenBankACCNo, 30));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.FirstHolderEmail, 50));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.FirstHolderMobile, 13));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.Filler3, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.Filler4, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.SMSFlagfirstHolder, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.PANFlagFirstHolder, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.Filler5, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.NoNominationFlagFirstHolder, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.Filler6, 10));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.SecondHolderEmail, 50));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.SecondHolderMob, 13));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.Filler7, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.Filler8, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.SMSFlagSecondHolder, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.PanFlagSecondHolder, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.Filler9, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.Filler10, 12));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.ThirdHolderEmail, 50));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.ThirdHolderMob, 13));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.Filler11, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.Filler12, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.SMSFlagThirdHolder, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.PanFlagThirdHolder, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.Filler13, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.FirstHolderAdhaarNo, 12));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.SecondHolderAdhaarNo, 12));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.ThirdHolderAdhaarNo, 12));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.Filler14, 16));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.ClientGroupName, 8));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BillingCategory, 20));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.InwardDate, 8));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.Income, 10));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.LineOfBusiness, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BankingFlag, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.ChargesBankACCNo, 30));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BankAccountType, 2));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BankName, 135));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BankAddLine1, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BankAddLine2, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BankAddLine3, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BankAddLine4, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.BankAddPin, 7));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.MICRCode, 9));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.ContactPerson1, 30));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.ContactPerson2, 30));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.CustomerId, 10));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.InternetTrading, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.InstantClientID, 8));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.SecondHolderAddress1, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.SecondHolderAddress2, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.SecondHolderAddress3, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.SecondHolderAddress4, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.SecondHolderZip, 10));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.SecondHolderPhoneNo, 24));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.ThirdHolderAdd1, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.ThirdHolderAdd2, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.ThirdHolderAdd3, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.ThirdHolderAdd4, 36));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.ThirdHolderZip, 10));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.ThirdHolderPhoneNo, 24));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.FATCAForFirstHolder, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.FATCAForSecondHolder, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.FATCAForThirdHolder, 1));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.CITYOFBIRTHFirstHolder, 30));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.COUNTRYOFBIRTHFirstHolder, 30));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.NationalityOfFirstHolder, 30));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.CITYOFBIRTHOfSecondHolder, 30));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.COUNTRYOFBIRTHOfSecondHolder, 30));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.NationalityOfSecondHolder, 30));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.CITYOfBIRTHOfThirdHolder, 30));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.COUNTRYOfBIRTHOfThirdHolder, 30));
            sbDPAccountFileBodyDetails.Append(Process.GetFixLenString(objCDPAccountClientDetails.NationalityOfThirdHolder, 30));

            return sbDPAccountFileBodyDetails.ToString();
        }
        #endregion Detail Record per DP Account

        #region CreateZipFile
        /// <summary>
        /// Zip Attachted Documnets.
        /// </summary>
        /// <param name="sFileToZipName"></param>
        /// <param name="sPwd"></param>
        /// <param name="sRtnMsg"></param>
        /// <param name="ClientNo"></param>
        /// <returns></returns>
        private string CreateZipFile(string sFileToZipName, string sFolderName, string sPwd, ref string sRtnMsg)
        {
            string sZipfilePath = string.Empty;
            string XceedZipLic = System.Configuration.ConfigurationManager.AppSettings["XCEEDZIPLIC"];
            string DownloadAttachmentPath = sFileToZipName;

            DataTable dt = new DataTable();
            XceedZip Xfilezip;
            xcdError Xresultcode;
            try
            {
                Xfilezip = new XceedZipClass();
                sRtnMsg = string.Empty;

                //initializing xceed zip objects
                Xfilezip.CompressionLevel = xcdCompressionLevel.xclHigh;
                Xfilezip.DeleteZippedFiles = false;//true will delete signed file after zipped
                Xfilezip.ZipOpenedFiles = false;
                Xfilezip.PreservePaths = false;
                Xfilezip.RequiredFileAttributes = xcdFileAttributes.xfaNone;
                Xfilezip.ExtraHeaders = xcdExtraHeader.xehNone;
                Xfilezip.UseTempFile = false;

                if (!Xfilezip.License(XceedZipLic))
                {
                    throw new Exception("Xceed zip licence is either incorrect or expired.");
                }
                string sFolderpath = sFileToZipName + "\\" + sFolderName;
                string[] arrFileListToZip = Directory.GetFiles(sFolderpath, "*.*", SearchOption.AllDirectories);
                StringBuilder sFileList = new StringBuilder();

                

                Xfilezip.EncryptionPassword = sPwd;

                foreach (var item in arrFileListToZip)
                {
                    sFileList.Append(item + "|");
                }
                Xfilezip.FilesToProcess = sFileList.ToString().EndsWith("|") ? sFileList.ToString().Substring(0, sFileList.ToString().Length - 1) : sFileList.ToString();

                Xfilezip.ZipFilename = DownloadAttachmentPath + sFolderName + ".zip";
               
                if (File.Exists(Xfilezip.ZipFilename))
                    File.Delete(Xfilezip.ZipFilename); 
                
                Xresultcode = Xfilezip.Zip();

                sZipfilePath = DPAccountDownloadPath + sFolderName + ".zip";
                if (Xresultcode == xcdError.xerSuccess)
                {
                    Directory.Delete(sFolderpath, true);
                    return sZipfilePath;
                }
                else
                {
                    throw new Exception("Exception Error while zipping file :" + Xresultcode);
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "CreateZipFile()  Error while zipping file:- " + sFileToZipName, ex);
                throw ex;
            }
            finally
            {
                Xfilezip = null;
            }
        }
        #endregion CreateZipFile
        #endregion methods
    }
}
