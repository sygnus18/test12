﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTIL.Match.CDD.BAL.DataClasses.DPAccountOpening
{
    /// <summary>
    /// DP Static Data Provider
    /// </summary>
    public struct CDPDataProvider
    {
        public static string RecordType = "02";
        public static string BranchCode = "0001";
        public static string BeneficiaryType = "01";
        public static string BeneficiarySubType = "01";
        public static string BeneficiaryAccountCategory = "02";
        public static string Nationality = "INDIAN";
        public static string ClientGroupName = "YSL";
        public static string LeadID = "LD251215654321";
        public static readonly string StandingInstructionYES = "Y";
        public static readonly string StandingInstructionOtherwise = "N";
        public static string BillingCategory = "YES PROSPERITY";
        public static int AddLimitPerline = 36;
    }



    /// <summary>
    /// Account for holding and dealing in electronic warehouse receipts
    /// </summary>
    public struct EWareHouseReceipt
    {
        public static string CommodityClient = "Y";
        public static string NonCommodityClient = "N";
        public static string Others = " ";
    }

     public static class DPData
    {
        #region Get Occupation by Type
        static Dictionary<int?, int> l_dictOccupation = new Dictionary<int?, int>
        {
             {1	,1},    //Public Sector
             {2	,1},    //Private Sector
             {3	,1},    //Government Service
             {4	,5},    //Business
             {5	,6},    //Professional
             {6	,7},    //Agriculturist
             {7	,8},    //Retired
             {8	,3},    //Housewife
             {9	,2},    //Student
             {99,8},	//Others (please specify)
             {10,8} 	//Self Employed
        };
        public static string GetOccupationType(int? Occupation)
        {
            int OccupationType;
            l_dictOccupation.TryGetValue(Occupation, out OccupationType);
            return OccupationType.ToString();
        }
        #endregion Get Occupation by Type


        #region Get income by Type
        static Dictionary<int?, int> l_dictIncome = new Dictionary<int?, int>
        {
             {1	,1},   
             {2	,1},   
             {3	,2},   
             {4	,3},   
             {5	,4}    
        };
        public static string GetIncomeCode(int? IncomeCode)
        {
            int Income;
            l_dictIncome.TryGetValue(IncomeCode, out Income);
            return Income.ToString();
        }
        #endregion Get Occupation by Type



    }

}
