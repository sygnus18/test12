﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FTIL.Match.CDD.BAL.DataStore;

namespace FTIL.Match.CDD.BAL.DataClasses.DPAccountOpening
{
    class CDPAccountClientDetails
    {
        #region Public properties
        public string Description { get; set; }
        public string RecordType { get; set; }
        public string LineNo { get; set; }
        public string BranchCode { get; set; }
        public string ReferenceNo { get; set; }
        public string BeneficiaryType { get; set; }
        public string BeneficiarySubType { get; set; }
        public string BeneficiaryShortName { get; set; }
        public string BeneficiaryAccountCategory { get; set; }
        public string BeneficiaryOccupation { get; set; }
        public string BeneficiaryFirstHolderName { get; set; }
        public string Notes { get; set; }
        public string AdditionalInfo { get; set; }
        public string FirstHolderFatherOrHusbandName { get; set; }
        public string FirstHolderAddress1 { get; set; }
        public string FirstHolderAddress2 { get; set; }
        public string FirstHolderAddress3 { get; set; }
        public string FirstHolderAddress4 { get; set; }
        public string FirstHolderAddressPin { get; set; }
        public string BeneficiaryHolderPhone { get; set; }
        public string BeneficiaryHolderFax { get; set; }
        public string BeneficiarySecondHolderName { get; set; }
        public string SecondHolderFatherOrHusbandName { get; set; }
        public string BeneficiaryThirdHolderName { get; set; }
        public string ThirdHolderFatherOrHusbandName { get; set; }
        public string CorrespondingBPId { get; set; }
        public string AddressPreferenceFlag { get; set; }
        public string DateOfBirthForSecondHolder { get; set; }
        public string DateOfBirthForThirdHolder { get; set; }
        public string UCICforFirstHolder { get; set; }
        public string UCICforSecondHolder { get; set; }
        public string UCICforThirdHolder { get; set; }
        public string UCICforGuardian { get; set; }
        public string GuardianPAN { get; set; }
        public string RGESSFlag { get; set; }
        public string BSDAFlag { get; set; }
        public string POAFlag { get; set; }
        public string FirstHolderFinancialDetail { get; set; }
        public string SecondHolderFinancialDetail { get; set; }
        public string ThirdHolderFinancialDetail { get; set; }
        public string NomineeOrGuardianIndicator { get; set; }
        public string NomineeOrGuardianName { get; set; }
        public string DOBMinor { get; set; }
        public string NomineeOrGuardianAddLine1 { get; set; }
        public string NomineeOrGuardianAddLine2 { get; set; }
        public string NomineeOrGuardianAddLine3 { get; set; }
        public string NomineeOrGuardianAddLine4 { get; set; }
        public string NomineeOrGuardianAddPin { get; set; }
        public string StandingInstructionIndicator { get; set; }
        public string Filler1 { get; set; }
        public string IFSCCode { get; set; }
        public string IsCommodityClient { get; set; }
        public string BeneficiaryBankAccountType { get; set; }
        public string BeneficiaryBankName { get; set; }
        public string BenBankAddrLine1 { get; set; }
        public string BenBankAddrLine2 { get; set; }
        public string BenBankAddrLine3 { get; set; }
        public string BenBankAddrLine4 { get; set; }
        public string BenBankAddrPin { get; set; }
        public string BenMICRCode { get; set; }
        public string BenRBIRefNo { get; set; }
        public string BenRBIApprovalDate { get; set; }
        public string BenSEBIRegNo { get; set; }
        public string BenTaxDeductionStatus { get; set; }
        public string LeadID { get; set; }
        public string IsDISNotReq { get; set; }
        public string Filler2 { get; set; }
        public string FirstHolderCorrAdd1 { get; set; }
        public string FirstHolderCorrAdd2 { get; set; }
        public string FirstHolderCorrAdd3 { get; set; }
        public string FirstHolderCorrAdd4 { get; set; }
        public string FirstHolderCorrAddPin { get; set; }
        public string BenHolderCorrPhone { get; set; }
        public string BenHolderCorrFax { get; set; }
        public string NomineeMinorIndicator { get; set; }
        public string MinorNomineeDOB { get; set; }
        public string MinorNomineeGuardianName { get; set; }
        public string MinorNomineeGuardianAddr1 { get; set; }
        public string MinorNomineeGuardianAddr2 { get; set; }
        public string MinorNomineeGuardianAddr3 { get; set; }
        public string MinorNomineeGuardianAddr4 { get; set; }
        public string MinorNomineeGuardianPin { get; set; }
        public string BenBankACCNo { get; set; }
        public string FirstHolderEmail { get; set; }
        public string FirstHolderMobile { get; set; }
        public string Filler3 { get; set; }
        public string Filler4 { get; set; }
        public string SMSFlagfirstHolder { get; set; }
        public string PANFlagFirstHolder { get; set; }
        public string Filler5 { get; set; }
        public string NoNominationFlagFirstHolder { get; set; }
        public string Filler6 { get; set; }
        public string SecondHolderEmail { get; set; }
        public string SecondHolderMob { get; set; }
        public string Filler7 { get; set; }
        public string Filler8 { get; set; }
        public string SMSFlagSecondHolder { get; set; }
        public string PanFlagSecondHolder { get; set; }
        public string Filler9 { get; set; }
        public string Filler10 { get; set; }
        public string ThirdHolderEmail { get; set; }
        public string ThirdHolderMob { get; set; }
        public string Filler11 { get; set; }
        public string Filler12 { get; set; }
        public string SMSFlagThirdHolder { get; set; }
        public string PanFlagThirdHolder { get; set; }
        public string Filler13 { get; set; }
        public string FirstHolderAdhaarNo { get; set; }
        public string SecondHolderAdhaarNo { get; set; }
        public string ThirdHolderAdhaarNo { get; set; }
        public string Filler14 { get; set; }
        public string ClientGroupName { get; set; }
        public string BillingCategory { get; set; }
        public string InwardDate { get; set; }
        public string Income { get; set; }
        public string LineOfBusiness { get; set; }
        public string BankingFlag { get; set; }
        public string ChargesBankACCNo { get; set; }
        public string BankAccountType { get; set; }
        public string BankName { get; set; }
        public string BankAddLine1 { get; set; }
        public string BankAddLine2 { get; set; }
        public string BankAddLine3 { get; set; }
        public string BankAddLine4 { get; set; }
        public string BankAddPin { get; set; }
        public string MICRCode { get; set; }
        public string ContactPerson1 { get; set; }
        public string ContactPerson2 { get; set; }
        public string CustomerId { get; set; }
        public string InternetTrading { get; set; }
        public string InstantClientID { get; set; }
        public string SecondHolderAddress1 { get; set; }
        public string SecondHolderAddress2 { get; set; }
        public string SecondHolderAddress3 { get; set; }
        public string SecondHolderAddress4 { get; set; }
        public string SecondHolderZip { get; set; }
        public string SecondHolderPhoneNo { get; set; }
        public string ThirdHolderAdd1 { get; set; }
        public string ThirdHolderAdd2 { get; set; }
        public string ThirdHolderAdd3 { get; set; }
        public string ThirdHolderAdd4 { get; set; }
        public string ThirdHolderZip { get; set; }
        public string ThirdHolderPhoneNo { get; set; }
        public string FATCAForFirstHolder { get; set; }
        public string FATCAForSecondHolder { get; set; }
        public string FATCAForThirdHolder { get; set; }
        public string CITYOFBIRTHFirstHolder { get; set; }
        public string COUNTRYOFBIRTHFirstHolder { get; set; }
        public string NationalityOfFirstHolder { get; set; }
        public string CITYOFBIRTHOfSecondHolder { get; set; }
        public string COUNTRYOFBIRTHOfSecondHolder { get; set; }
        public string NationalityOfSecondHolder { get; set; }
        public string CITYOfBIRTHOfThirdHolder { get; set; }
        public string COUNTRYOfBIRTHOfThirdHolder { get; set; }
        public string NationalityOfThirdHolder { get; set; }
        #endregion Public properties

        #region Constructor
        public CDPAccountClientDetails()
        {

        }
        #endregion Constructor

        #region methods
        public void BindObject(Client objClient)
        {
            ClientAddress objPerAddress = new ClientAddress();
            ClientAddress objCorrAddress = new ClientAddress();

            objPerAddress = objClient.oClientAddresses.GetAddressByType(Client_AddressType.Registered);//for permanat address
            objCorrAddress = objClient.oClientAddresses.GetAddressByType(Client_AddressType.Correspondence);//for Correspondant address

            int[] arrRelationShipNo = { 98, 99,100, 201, 202, 203 };

            //BenRBIApprovalDate
            //BenSEBIRegNo
            //BenTaxDeductionStatus
            //Notes
            //AdditionalInfo 
            //UCICforFirstHolder
            RecordType =CDPDataProvider.RecordType;
            BranchCode = CDPDataProvider.BranchCode;
            ReferenceNo = objClient.KYCFormRefCode; 
            BeneficiaryType = CDPDataProvider.BeneficiaryType;
            BeneficiarySubType = CDPDataProvider.BeneficiarySubType;
            BeneficiaryAccountCategory = CDPDataProvider.BeneficiaryAccountCategory;
            PANFlagFirstHolder = Flag.Yes;
            FATCAForFirstHolder = Flag.No;
            AddressPreferenceFlag = Flag.No;
            if (objClient.ClientName.Length > 16)
                BeneficiaryShortName = objClient.ClientName.Substring(0, 16);
            else
                BeneficiaryShortName = objClient.ClientName;
            BeneficiaryOccupation = DPData.GetOccupationType(objClient.Occupation);
            BeneficiaryFirstHolderName = objClient.ClientName + " " + objClient.MiddleName + " " + objClient.LastName;
            FirstHolderAdhaarNo = objClient.UID;
            if (objClient.DOB.HasValue)
                DOBMinor = objClient.DOB.Value.ToString("yyyyMMdd");
            FirstHolderFatherOrHusbandName = objClient.GuardianName;
            FirstHolderFinancialDetail = objClient.PANNo;
            
            if (objClient.Nationality == 1)
                NationalityOfFirstHolder = CDPDataProvider.Nationality;
            if (objClient.TypeofFacility == "2" || objClient.TypeofFacility == "3")
                SMSFlagfirstHolder = Flag.Yes;
            else
                SMSFlagfirstHolder = Flag.No;
            if (objPerAddress != null)
            {
                AddressPreferenceFlag = Flag.Yes;
                if (objPerAddress.AddressLine1.Length > 36 || objPerAddress.AddressLine2.Length > 36 || objPerAddress.AddressLine3.Length > 36)
                {
                    
                    string strPerAdd = objPerAddress.AddressLine1 + objPerAddress.AddressLine2 + objPerAddress.AddressLine3;

                    string[] arrAdd = Process.spiltData(strPerAdd, CDPDataProvider.AddLimitPerline);
                    if (arrAdd.Length == 3)
                    {
                        FirstHolderAddress1 =arrAdd[0];
                        FirstHolderAddress2 =arrAdd[1];
                        FirstHolderAddress3 =arrAdd[2];
                    }
                    if (arrAdd.Length == 2)
                    {
                        FirstHolderAddress1 = arrAdd[0];
                        FirstHolderAddress2 = arrAdd[1];
                    }
                    if (arrAdd.Length == 1)
                    {
                        FirstHolderAddress1 = arrAdd[0];
                    }
                }
                else
                {
                    if (objPerAddress.AddressLine1.Length > 36)
                        objPerAddress.AddressLine1 = objPerAddress.AddressLine1.Substring(0, 36);
                    FirstHolderAddress1 = Process.RemoveSpecialCharFromString(objPerAddress.AddressLine1);
                    if (objPerAddress.AddressLine2.Length > 36)
                        objPerAddress.AddressLine2 = objPerAddress.AddressLine2.Substring(0, 36);
                    FirstHolderAddress2 = Process.RemoveSpecialCharFromString(objPerAddress.AddressLine2);
                    if (objPerAddress.AddressLine3.Length > 36)
                        objPerAddress.AddressLine3 = objPerAddress.AddressLine3.Substring(0, 36);
                    FirstHolderAddress3 = Process.RemoveSpecialCharFromString(objPerAddress.AddressLine3);
                }
                if (!string.IsNullOrEmpty(FirstHolderAddress4))
                {
                    FirstHolderAddress4 = FirstHolderAddress4 + " " + Process.RemoveSpecialCharFromString(objPerAddress.City);
                }
                else if (string.IsNullOrEmpty(FirstHolderAddress3))
                {
                    FirstHolderAddress3 = Process.RemoveSpecialCharFromString(objPerAddress.City);
                    FirstHolderAddress4 = Process.RemoveSpecialCharFromString(objPerAddress.StateName);
                }
                else 
                {
                    FirstHolderAddress4 = Process.RemoveSpecialCharFromString(objPerAddress.City)+" "+ Process.RemoveSpecialCharFromString(objPerAddress.StateName);
                }

                FirstHolderAddressPin = objPerAddress.PinCode;
                BeneficiaryHolderPhone = objPerAddress.TelNo1;
                BeneficiaryHolderFax = objPerAddress.FaxNo;
                FirstHolderEmail = objPerAddress.EMailId;
                FirstHolderMobile = objPerAddress.Mobile1;
                if (objPerAddress.SameCorrPermAdd == Flag.Yes)
                {
                    AddressPreferenceFlag = Flag.No;
                    if (objPerAddress.AddressLine1.Length > 36 || objPerAddress.AddressLine2.Length > 36 || objPerAddress.AddressLine3.Length > 36)
                    {

                        string strPerAdd = objPerAddress.AddressLine1 + objPerAddress.AddressLine2 + objPerAddress.AddressLine3;

                        string[] arrAdd = Process.spiltData(strPerAdd, CDPDataProvider.AddLimitPerline);
                        if (arrAdd.Length == 3)
                        {
                            FirstHolderCorrAdd1 = arrAdd[0];
                            FirstHolderCorrAdd2 = arrAdd[1];
                            FirstHolderCorrAdd3 = arrAdd[2];
                        }
                        if (arrAdd.Length == 2)
                        {
                            FirstHolderCorrAdd1 = arrAdd[0];
                            FirstHolderCorrAdd2 = arrAdd[1];
                        }
                        if (arrAdd.Length == 1)
                        {
                            FirstHolderCorrAdd1 = arrAdd[0];
                        }
                    }
                    else
                    {
                        if (objPerAddress.AddressLine1.Length > 36)
                            objPerAddress.AddressLine1 = objPerAddress.AddressLine1.Substring(0, 36);
                        FirstHolderCorrAdd1 = Process.RemoveSpecialCharFromString(objPerAddress.AddressLine1);
                        if (objPerAddress.AddressLine2.Length > 36)
                            objPerAddress.AddressLine2 = objPerAddress.AddressLine2.Substring(0, 36);
                        FirstHolderCorrAdd2 = Process.RemoveSpecialCharFromString(objPerAddress.AddressLine2);
                        if (objPerAddress.AddressLine3.Length > 36)
                            objPerAddress.AddressLine3 = objPerAddress.AddressLine3.Substring(0, 36);
                        FirstHolderCorrAdd3 = Process.RemoveSpecialCharFromString(objPerAddress.AddressLine3);
                    }
                    if (!string.IsNullOrEmpty(FirstHolderCorrAdd4))
                    {
                        FirstHolderCorrAdd4 = FirstHolderCorrAdd4 + " " + Process.RemoveSpecialCharFromString(objPerAddress.City);
                    }
                    else if (string.IsNullOrEmpty(FirstHolderCorrAdd3))
                    {
                        FirstHolderCorrAdd3 = Process.RemoveSpecialCharFromString(objPerAddress.City);
                        FirstHolderCorrAdd4 = Process.RemoveSpecialCharFromString(objPerAddress.StateName);
                    }
                    else
                    {
                        FirstHolderCorrAdd4 = Process.RemoveSpecialCharFromString(objPerAddress.City) + " " + Process.RemoveSpecialCharFromString(objPerAddress.StateName);
                    }
                    FirstHolderCorrAddPin = objPerAddress.PinCode;
                    BenHolderCorrPhone = objPerAddress.TelNo1;
                    BenHolderCorrFax = objPerAddress.FaxNo;
                }
            }
            
            if (objCorrAddress != null )
            {
                AddressPreferenceFlag = Flag.No;
                if (objCorrAddress.AddressLine1.Length > 36 || objCorrAddress.AddressLine2.Length > 36 || objCorrAddress.AddressLine3.Length > 36)
                {

                    string strPerAdd = objCorrAddress.AddressLine1 + objCorrAddress.AddressLine2 + objCorrAddress.AddressLine3;

                    string[] arrAdd = Process.spiltData(strPerAdd, CDPDataProvider.AddLimitPerline);
                    if (arrAdd.Length == 3)
                    {
                        FirstHolderCorrAdd1 = arrAdd[0];
                        FirstHolderCorrAdd2 = arrAdd[1];
                        FirstHolderCorrAdd3 = arrAdd[2];
                    }
                    if (arrAdd.Length == 2)
                    {
                        FirstHolderCorrAdd1 = arrAdd[0];
                        FirstHolderCorrAdd2 = arrAdd[1];
                    }
                    if (arrAdd.Length == 1)
                    {
                        FirstHolderCorrAdd1 = arrAdd[0];
                    }
                }
                else
                {
                    if (objCorrAddress.AddressLine1.Length > 36)
                        objCorrAddress.AddressLine1 = objCorrAddress.AddressLine1.Substring(0, 36);
                    FirstHolderCorrAdd1 = Process.RemoveSpecialCharFromString(objCorrAddress.AddressLine1);
                    if (objCorrAddress.AddressLine2.Length > 36)
                        objCorrAddress.AddressLine2 = objCorrAddress.AddressLine2.Substring(0, 36);
                    FirstHolderCorrAdd2 = Process.RemoveSpecialCharFromString(objCorrAddress.AddressLine2);
                    if (objCorrAddress.AddressLine3.Length > 36)
                        objCorrAddress.AddressLine3 = objCorrAddress.AddressLine3.Substring(0, 36);
                    FirstHolderCorrAdd3 = Process.RemoveSpecialCharFromString(objCorrAddress.AddressLine3);
                }
                if (!string.IsNullOrEmpty(FirstHolderCorrAdd4))
                {
                    FirstHolderCorrAdd4 = FirstHolderCorrAdd4 + " " + Process.RemoveSpecialCharFromString(objCorrAddress.City);
                }
                else if (string.IsNullOrEmpty(FirstHolderCorrAdd3))
                {
                    FirstHolderCorrAdd3 = Process.RemoveSpecialCharFromString(objCorrAddress.City);
                    FirstHolderCorrAdd4 = Process.RemoveSpecialCharFromString(objCorrAddress.StateName);
                }
                else
                {
                    FirstHolderCorrAdd4 = Process.RemoveSpecialCharFromString(objCorrAddress.City) + " " + Process.RemoveSpecialCharFromString(objCorrAddress.StateName);
                }

                FirstHolderCorrAddPin = objCorrAddress.PinCode;
                BenHolderCorrPhone = objCorrAddress.TelNo1;
                BenHolderCorrFax = objCorrAddress.FaxNo;
            }
            NoNominationFlagFirstHolder = Flag.Yes;
            NomineeMinorIndicator = Flag.No;
            
            if (objClient.oClientDPDetails.ClientDPDetailList.Count > 0)
            {
                foreach (ClientDPDetail objClientDPDetail in objClient.oClientDPDetails.ClientDPDetailList)
                {
                    if (!arrRelationShipNo.Contains(objClientDPDetail.RelationshipNo))
                    {
                        if (objClientDPDetail.Nomination != "N")
                        {
                            NoNominationFlagFirstHolder = Flag.No;
                            ClientAddress objRelatedPartyAddress = new ClientAddress();
                            objRelatedPartyAddress = objClient.oNomineeAddresses.GetAddressByType(Client_AddressType.RelatedParty);//for Related Party address

                            NomineeOrGuardianIndicator = Indicator.Nominee;// N - Nominee, G - Guardian, Space otherwise
                            NomineeOrGuardianName = objClientDPDetail.RelatedPartyName;

                            if (objRelatedPartyAddress != null)
                            {
                                if (objRelatedPartyAddress.AddressLine1.Length > 36 || objRelatedPartyAddress.AddressLine2.Length > 36 || objRelatedPartyAddress.AddressLine3.Length > 36)
                                {
                                    string strPerAdd = objRelatedPartyAddress.AddressLine1 + objRelatedPartyAddress.AddressLine2 + objRelatedPartyAddress.AddressLine3;

                                    string[] arrAdd = Process.spiltData(strPerAdd, CDPDataProvider.AddLimitPerline);
                                    if (arrAdd.Length == 3)
                                    {
                                        NomineeOrGuardianAddLine1 = arrAdd[0];
                                        NomineeOrGuardianAddLine2 = arrAdd[1];
                                        NomineeOrGuardianAddLine3 = arrAdd[2];
                                    }
                                    if (arrAdd.Length == 2)
                                    {
                                        NomineeOrGuardianAddLine1 = arrAdd[0];
                                        NomineeOrGuardianAddLine2 = arrAdd[1];
                                    }
                                    if (arrAdd.Length == 1)
                                    {
                                        NomineeOrGuardianAddLine1 = arrAdd[0];
                                    }
                                }
                                if (objRelatedPartyAddress.AddressLine1.Length > 36)
                                    objRelatedPartyAddress.AddressLine1 = objRelatedPartyAddress.AddressLine1.Substring(0, 36);
                                NomineeOrGuardianAddLine1 = Process.RemoveSpecialCharFromString(objRelatedPartyAddress.AddressLine1);
                                if (objRelatedPartyAddress.AddressLine2.Length > 36)
                                    objRelatedPartyAddress.AddressLine2 = objRelatedPartyAddress.AddressLine2.Substring(0, 36);
                                NomineeOrGuardianAddLine2 = Process.RemoveSpecialCharFromString(objRelatedPartyAddress.AddressLine2);
                                if (objRelatedPartyAddress.AddressLine3.Length > 36)
                                    objRelatedPartyAddress.AddressLine3 = objRelatedPartyAddress.AddressLine3.Substring(0, 36);
                                NomineeOrGuardianAddLine3 = Process.RemoveSpecialCharFromString(objRelatedPartyAddress.AddressLine3);

                                if (!string.IsNullOrEmpty(NomineeOrGuardianAddLine4))
                                {
                                    NomineeOrGuardianAddLine4 = NomineeOrGuardianAddLine4 + " " + Process.RemoveSpecialCharFromString(objRelatedPartyAddress.City);
                                }
                                else if (string.IsNullOrEmpty(NomineeOrGuardianAddLine3))
                                {
                                    NomineeOrGuardianAddLine3 = Process.RemoveSpecialCharFromString(objRelatedPartyAddress.City);
                                    NomineeOrGuardianAddLine4 = Process.RemoveSpecialCharFromString(objRelatedPartyAddress.StateName);
                                }
                                else
                                {
                                    NomineeOrGuardianAddLine4 = Process.RemoveSpecialCharFromString(objRelatedPartyAddress.City) + " " + Process.RemoveSpecialCharFromString(objRelatedPartyAddress.StateName);
                                }
                                
                                NomineeOrGuardianAddPin = objRelatedPartyAddress.PinCode;

                                //MinorNomineeDOB
                                //MinorNomineeGuardianName 
                                //MinorNomineeGuardianAddr1
                                //MinorNomineeGuardianAddr2
                                //MinorNomineeGuardianAddr3
                                //MinorNomineeGuardianAddr4
                                //MinorNomineeGuardianPin
                            }
                        }
                    }
                    else if (arrRelationShipNo.Contains(objClientDPDetail.RelationshipNo))
                    {
                        //for second holder details
                        if (objClientDPDetail.RelationshipNo == RelatedParty.Second_Holder)
                        {
                            BeneficiarySecondHolderName = objClientDPDetail.RelatedPartyName;
                            SecondHolderAdhaarNo = objClientDPDetail.AatharNo;
                            SecondHolderFinancialDetail = objClientDPDetail.PANNo;
                            PanFlagSecondHolder = objClientDPDetail.PANNo == null ? Flag.No : Flag.Yes;
                            SMSFlagSecondHolder = Flag.No;
                            
                            //SecondHolderFatherOrHusbandName = objClientDPDetail
                            //UCICforSecondHolder = objClientDPDetail
                            //DateOfBirthForSecondHolder = objClientDPDetail
                            //SecondHolderEmail = objClientDPDetail 
                            //SecondHolderMob = objClientDPDetail
                            //SecondHolderAddress1 = objClientDPDetail
                            //SecondHolderAddress2 = objClientDPDetail
                            //SecondHolderAddress3 = objClientDPDetail
                            //SecondHolderAddress4 = objClientDPDetail
                            //SecondHolderZip = objClientDPDetail
                            //SecondHolderPhoneNo = objClientDPDetail
                            //FATCAForSecondHolder = objClientDPDetail
                            //CITYOFBIRTHOfSecondHolder = objClientDPDetail
                            //COUNTRYOFBIRTHOfSecondHolder = objClientDPDetail
                            //NationalityOfSecondHolder = objClientDPDetail

                        }
                        else if (objClientDPDetail.RelationshipNo == RelatedParty.Third_Holder)
                        {
                            //for third holder details    
                            BeneficiaryThirdHolderName = objClientDPDetail.RelatedPartyName;
                            ThirdHolderAdhaarNo = objClientDPDetail.AatharNo;
                            ThirdHolderFinancialDetail = objClientDPDetail.PANNo;
                            PanFlagThirdHolder = objClientDPDetail.PANNo == null ? Flag.No : Flag.Yes;
                            SMSFlagThirdHolder = Flag.No;
                            //ThirdHolderFatherOrHusbandName = objClientDPDetail
                            //UCICforThirdHolder = objClientDPDetail
                            //ThirdHolderEmail = objClientDPDetail
                            //ThirdHolderMob = objClientDPDetail
                            //DateOfBirthForThirdHolder = objClientDPDetail
                            //ThirdHolderAdd1 = objClientDPDetail
                            //ThirdHolderAdd2 = objClientDPDetail  
                            //ThirdHolderAdd3 = objClientDPDetail
                            //ThirdHolderAdd4 = objClientDPDetail
                            //ThirdHolderZip = objClientDPDetail
                            //ThirdHolderPhoneNo = objClientDPDetail
                            //FATCAForThirdHolder = objClientDPDetail
                            //CITYOfBIRTHOfThirdHolder = objClientDPDetail
                            //COUNTRYOfBIRTHOfThirdHolder = objClientDPDetail
                            //NationalityOfThirdHolder = objClientDPDetail
                        }

                    }
                }
            }
            if (objClient.oClientBankDetails.ClientBankDetailList.Count > 0)
            {
                ClientBankDetail objClientBankDetail = objClient.oClientBankDetails.ClientBankDetailList[0];
                BankingFlag = Flag.Yes;
                BenBankACCNo = objClientBankDetail.AccountNo;
                IFSCCode = objClientBankDetail.BankIFSCCode;
                BeneficiaryBankAccountType = objClientBankDetail.AccountType.ToString();
                BeneficiaryBankName = objClientBankDetail.BankName;
                ChargesBankACCNo = objClientBankDetail.AccountNo;
                BankAccountType = objClientBankDetail.AccountType.ToString();
                BankName = objClientBankDetail.BankName;
                MICRCode = objClientBankDetail.BankMICRCode;
                BenMICRCode = objClientBankDetail.BankMICRCode;
                if (objClientBankDetail.BankBranchAddress != null)
                {
                    if (objClientBankDetail.BankBranchAddress.Length >= 144)
                    {
                        BenBankAddrLine1 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(0, 36));
                        BenBankAddrLine2 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(37, 36));
                        BenBankAddrLine3 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(73, 36));
                        BenBankAddrLine4 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(109, 36));

                        BankAddLine1 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(0, 36));
                        BankAddLine2 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(37, 36));
                        BankAddLine3 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(73, 36));
                        BankAddLine4 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(109, 36));
                    }
                    else if (objClientBankDetail.BankBranchAddress.Length < 144 && objClientBankDetail.BankBranchAddress.Length > 108)
                    {
                        BenBankAddrLine1 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(0, 36));
                        BenBankAddrLine2 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(37, 36));
                        BenBankAddrLine3 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(73, 36));
                        BenBankAddrLine4 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(109));

                        BankAddLine1 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(0, 36));
                        BankAddLine2 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(37, 36));
                        BankAddLine3 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(73, 36));
                        BankAddLine4 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(109));
                    }
                    else if (objClientBankDetail.BankBranchAddress.Length < 108 && objClientBankDetail.BankBranchAddress.Length > 72)
                    {
                        BenBankAddrLine1 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(0, 36));
                        BenBankAddrLine2 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(37, 36));
                        BenBankAddrLine3 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(73));
                        BenBankAddrLine4 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankCity);

                        BankAddLine1 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(0, 36));
                        BankAddLine2 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(37, 36));
                        BankAddLine3 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(73));
                        BankAddLine4 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankCity);
                    }
                    else if (objClientBankDetail.BankBranchAddress.Length < 72 && objClientBankDetail.BankBranchAddress.Length > 36)
                    {
                        BenBankAddrLine1 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(0, 36));
                        BenBankAddrLine2 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(37));
                        BenBankAddrLine3 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankCity);
                        BenBankAddrLine4 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankState);

                        BankAddLine1 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(0, 36));
                        BankAddLine2 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress.Substring(37));
                        BankAddLine3 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankCity);
                        BankAddLine4 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankState);
                    }
                    else if (objClientBankDetail.BankBranchAddress.Length < 36 && objClientBankDetail.BankBranchAddress.Length > 0)
                    {
                        BenBankAddrLine1 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress);
                        BenBankAddrLine2 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankCity);
                        BenBankAddrLine3 = Process.RemoveSpecialCharFromString(".");
                        BenBankAddrLine4 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankState);

                        BankAddLine1 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankBranchAddress);
                        BankAddLine2 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankCity);
                        BankAddLine3 = Process.RemoveSpecialCharFromString(".");
                        BankAddLine4 = Process.RemoveSpecialCharFromString(objClientBankDetail.BankState);
                    }
                }
                //else
                //{
                //    BenBankAddrLine1 = ".";
                //    BenBankAddrLine2 = ".";
                //    BenBankAddrLine3 = ".";
                //    BenBankAddrLine4 = ".";

                //    BankAddLine1 = ".";
                //    BankAddLine2 = ".";
                //    BankAddLine3 = ".";
                //    BankAddLine4 = ".";
                //}

                //BenBankAddrPin = ".";
                //BankAddPin = ".";
            }
            else
            {
                BankingFlag = Flag.No;
            }
            StandingInstructionIndicator = CDPDataProvider.StandingInstructionYES;//Y - Yes, N - Otherwise 
            IsDISNotReq = Flag.No;
            InternetTrading = Flag.Yes;
            //LeadID = CDPDataProvider.LeadID;
            IsCommodityClient = EWareHouseReceipt.NonCommodityClient;
            ClientGroupName = CDPDataProvider.ClientGroupName;
            InwardDate = objClient.AuthorizeDatetime.ToString("yyyyMMdd");
            InstantClientID = objClient.BOID;
            CITYOFBIRTHFirstHolder = objClient.CityOfBirth;
            COUNTRYOFBIRTHFirstHolder = objClient.CountryOfBirth;
            CustomerId = objClient.CustId;
            Income = DPData.GetIncomeCode(objClient.GrAnnIncRange);
            BillingCategory = CDPDataProvider.BillingCategory;

            //CorrespondingBPId
            //UCICforGuardian
            //GuardianPAN
            //RGESSFlag
            //BSDAFlag
            //POAFlag               
            //BenRBIRefNo
            
            
            //LineOfBusiness
            //ContactPerson1
            //ContactPerson2
            //Filler                 
            //Filler
            //Filler
            //Filler
            //Fillers 
            //Filler
            //Filler
            //Filler
            //Fillers
            //Filler
            //Filler 
            //Filler
            //Filler 
        }
        #endregion methods
       
    }
}
