﻿using System;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using FTIL.Match.CDD.BAL.DataClasses.CKYC;
using FTIL.Match.CDD.BAL.DataClasses.DPAccountOpening.CDSL;
using FTIL.Match.CDD.BAL.DataStore;
using FTIL.Match.Common.Log;

namespace FTIL.Match.CDD.BAL.DataClasses.DPAccountOpening
{
    /// <summary>
    ///  CDSL Account Details
    /// </summary>
    public class CDSLAccountDetails
    {
        #region variables
        string BatchNo = "0000";
        public StringBuilder sbCDSLAccountDetails;
        public static readonly string DATEFORMAT = "ddMMyyyy";
        public static string BaseDirectory = AppDomain.CurrentDomain.BaseDirectory.ToString();
        public static string CDSLFilePath = BaseDirectory + ConfigurationManager.AppSettings["CDSLFilesPath"];

        public static string CDSLFileDownloadPath = ConfigurationManager.AppSettings["CDSLFilesPath"];
        public static readonly string FILEEXTENSION = ".02523";
        string sCDSLFilePath = string.Empty;
        string sDownloadPath = string.Empty;
        string sCDSLFolderPath = string.Empty;
        string sCDSLFolderName = string.Empty;
        string sPath = string.Empty;
        int nRecordType = 8;
        #endregion variables

        #region public properties
        public string sDateOfCreation { get; set; }
        public string UserID { get; set; }
        public int LineNo { get; set; }
        #endregion public properties

        #region constructor
        public CDSLAccountDetails(string sUserID)
        {
            sbCDSLAccountDetails = new StringBuilder();
            UserID = sUserID;
            LineNo = 0;
        }
        #endregion constructor

        #region CDSL file Header Details
        /// <summary>
        /// Add header details.
        /// </summary>
        /// <returns>header string</returns>
        public string HeaderDetails(int nTotalClients)
        {
            StringBuilder sbHeader = new StringBuilder();
            try
            {
                CHeaderDetails objCHeaderDetails = new CHeaderDetails();
                objCHeaderDetails.DPId = CDSLDataProvider.CDSLDPId;
                objCHeaderDetails.OperatorID = CDSLDataProvider.OperatorID;
                objCHeaderDetails.TotalNoOfRecords = nTotalClients.ToString();


                sbHeader.Append(Process.GetFixLenString(objCHeaderDetails.DPId, 6, '0'));
                sbHeader.Append(Process.GetFixLenString(objCHeaderDetails.OperatorID, 6));
                sbHeader.Append(Process.GetFixLenString(objCHeaderDetails.TotalNoOfRecords, 5, '0'));
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "HeaderDetails() Error CDSL Adding header details. ", ex);
                throw ex;
            }
            return sbHeader.ToString();
        }
        #endregion CDSL file Header Details

        #region UploadAttachment
        public string GenarateCDSLFile(Clients objClients, CKYCReferenceData objCKYCReferenceData)
        {
            try
            {
                string strHeaderData = string.Empty;
                string resp = string.Empty;
                int TotalClients = objClients.objClients.Count();
                StringBuilder sbDPAccountOpeningDetails = new StringBuilder();
                DateTime dCurrentDate = DateTime.Now;

                if (objCKYCReferenceData.BatchNo != null && objCKYCReferenceData.BatchNo != "0")
                    BatchNo = Process.GetFixLenString(objCKYCReferenceData.BatchNo.ToString(), 5, '0');
                else
                {
                    BatchNo = Process.GetFixLenString(objClients.BatchNo.ToString(), 5, '0');
                    objCKYCReferenceData.BatchNo = Process.GetFixLenString(objClients.BatchNo.ToString(), 5, '0');
                }

                //create Folder if not exists
                FileInfo fileinfo = new FileInfo(CDSLFilePath);

                if (!fileinfo.Directory.Exists)
                    Directory.CreateDirectory(fileinfo.Directory.FullName);

                sCDSLFolderName = dCurrentDate.ToString(DATEFORMAT) + "_CDAS";
                string BatchFolderName = BatchNo.ToString();
                sCDSLFolderPath = CDSLFilePath + sCDSLFolderName + "\\" + BatchFolderName + "\\";
                sCDSLFilePath = sCDSLFolderPath + "08" + CDSLDataProvider.CDSLDPId +"."+ BatchNo.ToString();

                sDownloadPath = CDSLFileDownloadPath + sCDSLFolderName + "\\" + BatchFolderName + ".zip"; ;

                FileInfo ClientWisefileinfo = new FileInfo(sCDSLFolderPath);

                if (ClientWisefileinfo.Directory.Exists)
                    Directory.Delete(ClientWisefileinfo.Directory.FullName, true);

                Directory.CreateDirectory(ClientWisefileinfo.Directory.FullName);

                //Delete existing file if exists
                if (File.Exists(sCDSLFilePath))
                {
                    File.Delete(sCDSLFilePath);
                }

                //Write data in to file. 
                using (StreamWriter swDPAccountFileNew = File.CreateText(sCDSLFilePath))
                {
                    strHeaderData = HeaderDetails(TotalClients);
                    swDPAccountFileNew.WriteLine(strHeaderData);

                    foreach (Client oClient in objClients.objClients)
                    {

                        StringBuilder sbBodyDetails = new StringBuilder();
                        oClient.LineNo = ++LineNo;
                        SignImg(oClient, sCDSLFolderPath);

                        sbBodyDetails.Append(DetailRecord(oClient));
                        swDPAccountFileNew.Write(sbBodyDetails.ToString());
                    }

                }

                //Zip Attachted Documnets.
                //Process.CreateZipFile(CDSLFilePath + sCDSLFolderName, BatchFolderName, null, ref resp);
                return sDownloadPath;

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "UploadAttachment() Error while Uploading Attachment.", ex);
                throw ex;
            }
        }
        #endregion UploadAttachment

        #region ExportFilePath
        public void ExportFilePath()
        {
            try
            {
                string sdate = System.DateTime.Now.ToString(DATEFORMAT);
                string sCDSLBulkUploadFolderName = "08" + CDSLDataProvider.CDSLDPId + BatchNo.ToString();
                //string sCDSLBulkUploadPath = CKYCBulkUploadPath + sCDSLBulkUploadFolderName + "\\";
                //FileInfo fileinfo = new FileInfo(sCDSLBulkUploadPath);
                //if (!fileinfo.Exists)
                //    Directory.CreateDirectory(fileinfo.Directory.FullName);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "ExportFilePath() Error while creating Directory for bulk upload.", ex);
                throw ex;
            }
        }
        #endregion ExportFilePath

        #region Signature File Details
        /// <summary>
        ///Save Signature File Details at given path
        /// </summary>
        /// <param name="objClient"></param>
        /// <param name="path"></param>
        public void SignImg(Client objClient, string path)
        {
            ClientImageDetail objSignImg = new ClientImageDetail();
            string SerialNo = Process.GetFixLenString(objClient.LineNo.ToString(), 4, '0');
            objSignImg = objClient.oClientImageDetails.GetImageByType(Client_ImageType.Signature);
            if (objSignImg != null)
            {
                string ImgName = string.Empty;
                string ext = Path.GetExtension(objSignImg.ImageName);
                ImgName = "b" + BatchNo.ToString() + SerialNo + "bosignature.bmp"; // objSignImg.ImageName;
                File.WriteAllBytes(path + ImgName, objSignImg.l_bImage);
            }
        }
        #endregion Signature File Details

        #region Detail Record per CDSL Account
        /// <summary>
        /// Detail Record per CDSL Account
        /// </summary>
        /// <returns></returns>
        public string DetailRecord(Client objClient)
        {
            StringBuilder sbBodyDetails = new StringBuilder();
            nRecordType = 8;
            try
            {
                sbBodyDetails.AppendLine(FirstLineDetails(objClient));

                sbBodyDetails.AppendLine(SecondLineDetails(objClient));

                string sThirdLineDetails = ThirdLineDetails(objClient);
                if (sThirdLineDetails != null)
                    sbBodyDetails.AppendLine(sThirdLineDetails);

                //sbBodyDetails.AppendLine(FourthLineDetails(objClient));

                sbBodyDetails.AppendLine(FifthLineDetails(objClient));

                //sbBodyDetails.AppendLine(SixthLineDetails(objClient));

                sbBodyDetails.AppendLine(SeventhLineDetails(objClient));

                string sEighthLineDetails = EighthLineDetails(objClient);
                if (sEighthLineDetails != null)
                    sbBodyDetails.AppendLine(sEighthLineDetails);

                string sNinthLineDetails = NinthLineDetails(objClient);
                if (sNinthLineDetails != null)
                    sbBodyDetails.AppendLine(sNinthLineDetails);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "DetailRecord() Error CDSL Account Body details. ", ex);
                throw ex;
            }
            return sbBodyDetails.ToString();
        }
        #endregion Detail Record per CDSL Account

        #region First Line Details.
        /// <summary>
        /// Bo Set Up First Line Details
        /// </summary>
        public string FirstLineDetails(Client oClient)
        {
            string BOFirstLineDetails = string.Empty;
            StringBuilder sbFirstLinDetails = new StringBuilder();
            try
            {
                clsBOFirstLineDetails objclsBOFirstLineDetails = new clsBOFirstLineDetails();
                objclsBOFirstLineDetails.BindObject(oClient);

                sbFirstLinDetails.Append(Process.GetFixLenString(objclsBOFirstLineDetails.RecordType1, 2, '0'));
                sbFirstLinDetails.Append(Process.GetFixLenString(objclsBOFirstLineDetails.SerialNo, 4, '0'));
                sbFirstLinDetails.Append(Process.GetFixLenString(objclsBOFirstLineDetails.BOId, 16, '0'));
                sbFirstLinDetails.Append(Process.GetFixLenString(objclsBOFirstLineDetails.BORequestReceiptDate, 14));
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "FirstLineDetails() Error processing of Client no :" + oClient.ClientNo, ex);
            }
            return sbFirstLinDetails.ToString();
        }
        #endregion First Line Details.

        #region Second Line Details.
        /// <summary>
        ///  Bo Set Up Second Line Details(First Account Holder)
        /// </summary>
        public string SecondLineDetails(Client oClient)
        {
            string BOSecondLineDetails = string.Empty;
            StringBuilder sbSecondLinDetails = new StringBuilder();
            try
            {
                clsBOSecondLineDetails objclsBOSecondLineDetails = new clsBOSecondLineDetails();
                objclsBOSecondLineDetails.BindObject(oClient);

                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_RecordType02, 2, '0'));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_Product_No, 4, '0'));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_Bo_Name, 100));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_Bo_Middle_Name, 20));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_Last_Name, 20));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_Bo_Title, 10));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_Bo_Suffix, 10));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_FatherOrHusband_Name, 50));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_Cust_Addr_1, 30));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_Cust_Addr_2, 30));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_Cust_Addr_3, 30));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_Cust_Addr_City, 25));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_Cust_Addr_State, 25));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_Cust_Addr_Country, 25));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_Cust_Addr_Zip, 10));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_Cust_ph_1_Indc, 1));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_Cust_Ph_1, 17));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_Cust_Ph_2_indc, 1));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_Cust_Ph_2, 17));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_Cust_Addl_phone, 100));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_Cust_Fax, 17));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_PAN, 10));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_UID, 12));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_Poa_Flag, 1));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_Filler1, 2));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_IT_Circle, 15));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_Cust_email, 50));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_User_Text1, 50));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_User_Text2, 50));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_User_Field3, 4, '0'));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_User_Field4, 4));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_User_Field5, 4, '0'));
                sbSecondLinDetails.Append(Process.GetFixLenString(objclsBOSecondLineDetails.FAH_Signature_File_Flag, 1));
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "SecondLineDetails() Error processing of Client no :" + oClient.ClientNo, ex);
            }
            return sbSecondLinDetails.ToString();
        }
        #endregion Second Line Details.

        #region Third Line Details.
        /// <summary>
        ///  Bo Set Up Third Line Details(Second Account holder)
        /// </summary>
        public string ThirdLineDetails(Client oClient)
        {
            string BOThirdLineDetails = string.Empty;
            StringBuilder sbThirdLinDetails = new StringBuilder();
            try
            {
                clsBOThirdLineDetails objclsBOThirdLineDetails = new clsBOThirdLineDetails();
                if (!objclsBOThirdLineDetails.BindObject(oClient))
                    return null;

                sbThirdLinDetails.Append(Process.GetFixLenString(objclsBOThirdLineDetails.SAH_RecordType03, 2, '0'));
                sbThirdLinDetails.Append(Process.GetFixLenString(objclsBOThirdLineDetails.SAH_Bo_Name, 100));
                sbThirdLinDetails.Append(Process.GetFixLenString(objclsBOThirdLineDetails.SAH_Bo_Middle_Name, 20));
                sbThirdLinDetails.Append(Process.GetFixLenString(objclsBOThirdLineDetails.SAH_Search_Name, 20));
                sbThirdLinDetails.Append(Process.GetFixLenString(objclsBOThirdLineDetails.SAH_Bo_Title, 10));
                sbThirdLinDetails.Append(Process.GetFixLenString(objclsBOThirdLineDetails.SAH_Bo_Suffix, 10));
                sbThirdLinDetails.Append(Process.GetFixLenString(objclsBOThirdLineDetails.SAH_FatherOrHusband_Name, 50));
                sbThirdLinDetails.Append(Process.GetFixLenString(objclsBOThirdLineDetails.SAH_PAN, 10));
                sbThirdLinDetails.Append(Process.GetFixLenString(objclsBOThirdLineDetails.SAH_UID, 15));
                sbThirdLinDetails.Append(Process.GetFixLenString(objclsBOThirdLineDetails.SAH_IT_Circle, 15));
                sbThirdLinDetails.Append(Process.GetFixLenString(objclsBOThirdLineDetails.SAH_MOB_No, 10));
                sbThirdLinDetails.Append(Process.GetFixLenString(objclsBOThirdLineDetails.SAH_Email, 50));
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "ThirdLineDetails() Error processing of Client no :" + oClient.ClientNo, ex);
            }
            return sbThirdLinDetails.ToString();
        }
        #endregion Third Line Details.

        #region Fourth Line Details.
        /// <summary>
        ///  Bo Set Up Fourth Line Details(Third Account Holder)
        /// </summary>
        public string FourthLineDetails(Client oClient)
        {
            string BOFourthLineDetails = string.Empty;
            StringBuilder sbFourthLinDetails = new StringBuilder();
            try
            {
                clsBOFourthLineDetails objclsBOFourthLineDetails = new clsBOFourthLineDetails();
                objclsBOFourthLineDetails.BindObject(oClient);

                sbFourthLinDetails.Append(Process.GetFixLenString(objclsBOFourthLineDetails.TAH_RecordType04, 2, '0'));
                sbFourthLinDetails.Append(Process.GetFixLenString(objclsBOFourthLineDetails.TAH_Bo_Name, 100));
                sbFourthLinDetails.Append(Process.GetFixLenString(objclsBOFourthLineDetails.TAH_Bo_Middle_Name, 20));
                sbFourthLinDetails.Append(Process.GetFixLenString(objclsBOFourthLineDetails.TAH_Search_Name, 20));
                sbFourthLinDetails.Append(Process.GetFixLenString(objclsBOFourthLineDetails.TAH_Bo_Title, 10));
                sbFourthLinDetails.Append(Process.GetFixLenString(objclsBOFourthLineDetails.TAH_Bo_Suffix, 10));
                sbFourthLinDetails.Append(Process.GetFixLenString(objclsBOFourthLineDetails.TAH_FatherOrHusband_Name, 50));
                sbFourthLinDetails.Append(Process.GetFixLenString(objclsBOFourthLineDetails.TAH_PAN, 10));
                sbFourthLinDetails.Append(Process.GetFixLenString(objclsBOFourthLineDetails.TAH_UID, 15));
                sbFourthLinDetails.Append(Process.GetFixLenString(objclsBOFourthLineDetails.TAH_IT_Circle, 15));
                sbFourthLinDetails.Append(Process.GetFixLenString(objclsBOFourthLineDetails.TAH_MOB_No, 10));
                sbFourthLinDetails.Append(Process.GetFixLenString(objclsBOFourthLineDetails.TAH_Email, 50));
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "FourthLineDetails() Error processing of Client no :" + oClient.ClientNo, ex);
            }
            return sbFourthLinDetails.ToString();
        }
        #endregion Fourth Line Details.

        #region Fifth Line Details.
        /// <summary>
        ///  Bo Set Up Fifth Line Details(Product Details):
        /// </summary>
        public string FifthLineDetails(Client oClient)
        {
            string BOFifthLineDetails = string.Empty;
            StringBuilder sbFifthLinDetails = new StringBuilder();
            try
            {
                clsBOFifthLineDetails objclsBOFifthLineDetails = new clsBOFifthLineDetails();
                objclsBOFifthLineDetails.BindObject(oClient);

                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.RecordType05, 2, '0'));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.MaturityDate, 8,'0'));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.DP_Internal_Ref_No, 10));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.DOB, 8));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.SexCode, 1));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Occupation, 4));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.LifeStyle, 4));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Geographical_Code, 4));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Education, 4));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Annual_income_code, 4, '0'));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Nationality_Code, 3));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Legal_Status_Code, 2, '0'));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Bo_Fee_Type, 2, '0'));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Language_Code, 2, '0'));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Category_4_Code, 2, '0'));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Bank_Option_5, 2, '0'));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.StaffOrRelative, 1));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Staff_Code, 10));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Alph_Code_1_User_Text_1, 39));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Family_Account_Flag, 1));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Email_Statement_flag, 1));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Cas_Mode, 2));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Mental_Disability, 1));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Filler_1, 1));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Rgess_Flag, 1));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Annual_Report_Flag, 1));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Pledge_Standing_Instruction_Flag, 1));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Email_Rta_Download_Flag, 1));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Bsda_Flag, 1));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Alph_Code_2_User_Text_2, 50));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Numeric_4_Dummy1, 4, '0'));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Numeric_4_Dummy2, 4, '0'));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Numeric_4_Dummy3, 4, '0'));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Security_Access_Code, 2, '0'));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Bo_Category, 2, '0'));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Bo_Settlement_Planning_Flag, 1));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Dividend_Bank_Ifsc_Code, 15));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Rbi_Reference_Number, 30));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Rbi_Approval_Date, 8,'0'));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Sebi_Registration_Number, 24));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Beneficiary_Tax_Deduction_Status, 2, '0'));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Smart_Card_Required, 1));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Smart_Card_Number, 20));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Smart_Card_Pin, 10, '0'));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.EcsOrmandate, 1));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Electronic_Confirmation, 1));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Dividend_Currency, 6, '0'));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Group_Code, 8));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Bo_Sub_Status, 4, '0'));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Clearing_Corporation_Id, 4, '0'));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Clearing_Member_Id, 8));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Stock_Exchange, 2, '0'));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Confirmation_Waived, 1));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Trading_Id, 8));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Bo_Statement_Cycle_Code, 2,'0'));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.CustodianOrPms_Email_Id, 50));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Divnd_Bank_Acct_Type, 12));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Divnd_Bank_Code, 12));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Divnd_Acct_Numb, 20));
                sbFifthLinDetails.Append(Process.GetFixLenString(objclsBOFifthLineDetails.Divnd_Bank_Ccy, 6, '0'));
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "FifthLineDetails() Error processing of Client no :" + oClient.ClientNo, ex);
            }
            return sbFifthLinDetails.ToString();
        }
        #endregion Fifth Line Details.

        #region Sixth Line Details.
        /// <summary>
        ///  Bo Set Up Sixth Line Details(POA Link details):
        /// </summary>
        public string SixthLineDetails(Client oClient)
        {
            string BOSixthLineDetails = string.Empty;
            StringBuilder sbSixthLinDetails = new StringBuilder();
            try
            {
                clsBOSixthLineDetails objclsBOSixthLineDetails = new clsBOSixthLineDetails();
                objclsBOSixthLineDetails.BindObject(oClient);

                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.RecordType06, 2, '0'));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.POA_Id, 16));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Setup_Date, 8));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Poa, 1));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Gpa_bpa_Flag, 1));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Effective_From_Date, 8));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Effective_To_Date, 8));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.User_Field_1, 4, '0'));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.User_Field_2, 4, '0'));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Ca_Charfld_Remark, 50));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_1, 100));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_2, 20));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_3, 20));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_4, 10));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_5, 10));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_6, 50));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_7, 30));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_8, 30));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_9, 30));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_10, 25));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_11, 25));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_12, 25));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_13, 10));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_14, 1));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_15, 17));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_16, 1));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_17, 17));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_18, 100));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_19, 17));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_20, 10));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_21, 15));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_22, 15));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_23, 50));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Poa_Master_Id, 50));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_24, 50));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.User_Field_3, 4, '0'));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_25, 4, '0'));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_26, 4, '0'));
                sbSixthLinDetails.Append(Process.GetFixLenString(objclsBOSixthLineDetails.Filler_27, 1));
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "SixthLineDetails() Error processing of Client no :" + oClient.ClientNo, ex);
            }
            return sbSixthLinDetails.ToString();
        }
        #endregion Sixth Line Details.

        #region Seventh Line Details.
        /// <summary>
        /// Seventh Line is for Permanent Address Details purpose code should be 12
        /// </summary>
        public string SeventhLineDetails(Client oClient)
        {
            string BOSeventhLineDetails = string.Empty;
            StringBuilder sbSeventhLinDetails = new StringBuilder();
            try
            {
                clsBOSeventhLineDetails objclsBOSeventhLineDetails = new clsBOSeventhLineDetails();
                objclsBOSeventhLineDetails.BindObject(oClient);

                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.RecordType07, 2, '0'));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.Purpose_Code, 2, '0'));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.Bo_Name, 100));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.Bo_Middle_Name, 20));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.Last_Name, 20));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.Bo_Title, 10));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.Bo_Suffix, 10));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.FatherOrHusband_Name, 50));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.Address_line_1, 30));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.Address_line_2, 30));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.Address_line_3, 30));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.City, 25));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.State, 25));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.Country, 25));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.Zip, 10));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.Ph_1_indc, 1));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.Ph_1, 17));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.Ph_2_indc, 1));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.Ph_2, 17));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.Additional_Phone, 100));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.Fax, 17));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.Income_Tax_Pan, 25));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.IT_Circle, 15));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.Cust_mail, 50));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.User_Text_1, 50));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.User_Text_2, 50));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.User_Field_3, 4, '0'));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.User_Field_4, 4, '0'));
                sbSeventhLinDetails.Append(Process.GetFixLenString(objclsBOSeventhLineDetails.User_Field_5, 4, '0'));
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "SeventhLineDetails() Error processing of Client no :" + oClient.ClientNo, ex);
            }

            return sbSeventhLinDetails.ToString();
        }
        #endregion Seventh Line Details.

        #region Eighth Line Details
        /// <summary>
        ///  Bo Set Up Eighth Line Details for Nominee Name and address
        /// </summary>
        public string EighthLineDetails(Client oClient)
        {
            string BOEighthLineDetails = string.Empty;
            StringBuilder sbEighthLinDetails = new StringBuilder();
            try
            {
                clsBOEighthLineDetails objclsBOEighthLineDetails = new clsBOEighthLineDetails();
                //objclsBOEighthLineDetails.BindObject(oClient);

                if (!objclsBOEighthLineDetails.BindNomineeObject(oClient))
                    return null;
                else
                {
                    objclsBOEighthLineDetails.RecordType08 = nRecordType.ToString();
                    nRecordType++;

                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.RecordType08, 2, '0'));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.Purpose_Code, 2, '0'));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.Bo_Name, 100));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.Bo_Middle_Name, 20));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.Last_Name, 20));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.Bo_Title, 10));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.Bo_Suffix, 10));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.FatherOrHusband_Name, 50));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.Add_Line_1, 30));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.Add_Line_2, 30));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.Add_Line_3, 30));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.City, 25));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.State, 25));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.Country, 25));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.Zip, 10));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.Ph_1_Indc, 1));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.Ph_1, 17));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.Ph_2_Indc, 1));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.Ph_2, 17));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.Additional_Phone, 92));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.DOB, 8));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.Fax, 17));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.PanID, 10));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.Uid, 15));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.It_Circle, 15));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.Email, 50));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.User_Text_1, 50));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.User_Text_2, 50));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.User_Field_3, 4, '0'));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.User_Field_4, 4, '0'));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.User_Field_5, 4, '0'));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.Nominee_Serial_Number, 2, '0'));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.Relationship_With_Bo, 2, '0'));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.Percentage_Of_Shares, 5, '0'));
                    sbEighthLinDetails.Append(Process.GetFixLenString(objclsBOEighthLineDetails.Residual_Securities_Flag, 1));


                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "EighthLineDetails() Error processing of Client no :" + oClient.ClientNo, ex);
            }
            return sbEighthLinDetails.ToString();
        }
        #endregion Eighth Line Details

        #region Ninth Line Details
        /// <summary>
        ///  Bo Set Up ninth Line Details for SMS File Setup Registration
        /// </summary>
        public string NinthLineDetails(Client oClient)
        {
            string BONinthLineDetails = string.Empty;
            StringBuilder sbNinthLinDetails = new StringBuilder();
            try
            {
                clsBONinthLineDetails objclsBONinthLineDetails = new clsBONinthLineDetails();
                if (!objclsBONinthLineDetails.BindObject(oClient))
                    return null;
                else
                {
                    objclsBONinthLineDetails.RecordType09 = nRecordType.ToString();
                    nRecordType++;

                    sbNinthLinDetails.Append(Process.GetFixLenString(objclsBONinthLineDetails.RecordType09, 2, '0'));
                    sbNinthLinDetails.Append(Process.GetFixLenString(objclsBONinthLineDetails.Purpose_Code, 2, '0'));
                    sbNinthLinDetails.Append(Process.GetFixLenString(objclsBONinthLineDetails.Upload_Flag, 1));
                    sbNinthLinDetails.Append(Process.GetFixLenString(objclsBONinthLineDetails.Mob_No, 10));
                    sbNinthLinDetails.Append(Process.GetFixLenString(objclsBONinthLineDetails.Email_Id, 100));
                    sbNinthLinDetails.Append(Process.GetFixLenString(objclsBONinthLineDetails.Remarks, 100));
                    sbNinthLinDetails.Append(Process.GetFixLenString(objclsBONinthLineDetails.Push_Pull_Flag, 1));
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "NinthLineDetails() Error processing of Client no :" + oClient.ClientNo, ex);
            }
            return sbNinthLinDetails.ToString();
        }
        #endregion Ninth Line Details
    }
}
