﻿using System.Collections.Generic;
using System.Configuration;

namespace FTIL.Match.CDD.BAL.DataClasses.DPAccountOpening.CDSL
{
    /// <summary>
    /// PAN Verification flag 
    /// </summary>
    public enum PANVerificationFlag
    {
        PAN_Not_Verified = 0,
        PAN_Verified = 1,
        PAN_Verification_Reversed = 2
    }

    /// <summary>
    /// Record Type
    /// </summary>
    public struct RecordType
    {
        public static int One = 1;
        public static int Two = 2;
        public static int Three = 3;
        public static int Four = 4;
        public static int Five = 5;
        public static int Six = 6;
        public static int Seven = 7;
    }

    /// <summary>
    /// Purpose Code
    /// </summary>
    public struct PurposeCode
    {
        public static int Permanent_Address = 12;
        public static int Nominee_Name_And_Address = 6;
        public static int Guardian_Name_And_Address = 7;
        public static int Nominee_Guardian_Name_And_Address = 8;
        public static int SMS_Registration = 16;
        public static int Authorized_Signatory = 18;
        public static int Payin_Through_SMS = 19;
        public static int Mapping_Of_CM_Accounts_With_CM_POA_Master = 21;
    }

    /// <summary>
    /// If POA Type Flag is ‘C’, then Purpose Code 21 details will be mandatory for CM POA.
    /// If POA Type Flag is ‘R’, then it will be considered as a Regular POA
    /// </summary>
    public struct POAType
    {
        public static string POA_Master_Creation = "C";
        public static string Regular_POA = "R";
    }

    static class CDSLDataProvider
    {
        #region variables
        public static int AddLimitPerline = 30;
        public static string ph_1_Indc = "M";
        public static string Signature_File_Flag = "Y";
        public static string CDSLDPId = ConfigurationManager.AppSettings["CDSLDPId"];
        public static int CDSLDPIdPrefix = 12;
        public static int Product_No = 1;
        public static string First_Holder_PAN_Verification_Code = ((int)PANVerificationFlag.PAN_Verified).ToString();
        public static string Second_Holder_PAN_Verification_Code = ((int)PANVerificationFlag.PAN_Not_Verified).ToString();
        public static string Third_Holder_PAN_Verification_Code = ((int)PANVerificationFlag.PAN_Not_Verified).ToString();
        public static int[] arrRelationShipNo = { 98, 99, 100, 0, 201, 202, 203 };
        public static int[] arrDPRelationNo = { 98, 99, 100 };
        public static string OperatorID = "BHUSHI";
		public static string Bo_Category = "01";
        public static string Bo_Settlement_Planning_Flag = "N";
        public static string Bo_Sub_Status = "3";
        public static int Divnd_Bank_Ccy = 999001;
        public static string Bo_Statement_Cycle_Code = "EM";
        public static int Percentage_Of_Shares = 10000;
        public static string Residual_Securities_Flag = "N";
        public static string Security_Access_Code = "0";
        public static string Dividend_Currency = "0";
        public static string MaturityDate = "0";
        public static string Legal_Status_Code = "0";
        public static string Bo_Fee_Type = "0";
        public static string Category_4_Code = "0";
        public static string Bank_Option_5 = "0";
        public static string Numeric_4_Dummy1 = "0";
        public static string Numeric_4_Dummy2 = "0";
        public static string Numeric_4_Dummy3 = "0";
        public static string Rbi_Approval_Date = "0";
        public static string Smart_Card_Pin = "0";
        public static string Clearing_Corporation_Id = "0";
        public static string Stock_Exchange = "0";
        public static string Confirmation_Waived = "Y";
        public static string Family_Account_Flag = "N";
        public static string Email_Statement_flag = "Y";
        public static string Mental_Disability = "N";
        #endregion variables

        #region Get Gender by Type
        static Dictionary<string, string> l_dictGender = new Dictionary<string, string>
        {
            {"M","M"},
            {"F","F"},
            {"U","M"}
        };
        public static string GetGenderType(string Gender)
        {
            string GenderCode;
            l_dictGender.TryGetValue(Gender, out GenderCode);
            return GenderCode;
        }
        #endregion Get Gender by Type

        #region Get Annual_Report_Flag by Type
        static Dictionary<int, int> l_dictFacility = new Dictionary<int, int>
        {
            {0,1},
            {1,1},
            {2,2},
            {3,2}
        };
        public static string GetAnnualReportFlag(int AnnualReportFlag)
        {
            int AnnualReportFlagCode = 0;
            try
            {
                l_dictFacility.TryGetValue(AnnualReportFlag, out AnnualReportFlagCode);
            }
            catch { }

            return AnnualReportFlagCode.ToString();
        }
        #endregion Get Annual_Report_Flag by Type

        #region Get Relationship_With_Bo by Relation No
        static Dictionary<int, int> l_dictRelation = new Dictionary<int, int>
        {
            {103,2},	//Son
            {102,5},	//Mother
            {101,4},	//Father
            {107,11},	//Grandmother
            {106,10},	//Grandfather
            {105,1},	//Spouse
            {104,3},	//Daughter
            {109,7},	//SISTER
            {108,6},	//BROTHER
            {100,12}    //Not Provided 
        };
        public static string GetRelationBONo(int RelationNo)
        {
            int RelationBONo = 0;
            try
            {
                l_dictRelation.TryGetValue(RelationNo, out RelationBONo);
            }
            catch { }
            return RelationBONo.ToString();
        }
        #endregion Get Relationship_With_Bo by Relation No

        #region Get Divnd_Bank_Acct_Type by Accocunt Type Code
        static Dictionary<int, int> l_dictAcct_Type = new Dictionary<int, int>
        {
            {10,10},//"SAVING"},
            {11,11},//"CURRENT"},
            {12,13},//"OTHERS"},
            {99,13} //"OTHERS"}
        };
        public static string GetDivnd_Bank_Acct_Type(int Acct_Type_Code)
        {
            int Acct_Type = 0;
            try
            {
                l_dictAcct_Type.TryGetValue(Acct_Type_Code, out Acct_Type);
            }
            catch { }
            return Acct_Type.ToString();
        }
        #endregion Get Divnd_Bank_Acct_Type by Accocunt Type Code

        #region Get Occupation by Occupation Code
        static Dictionary<int?, string> l_dictOccupation_Type = new Dictionary<int?, string>
        {
            {4,"B" },//	Business
            {8,"H" },//	Housewife
            {99,"O"},//	Others
            {10,"O"},//	Others
            {5,"P" },//	Professional
            {7,"R" },//	Retired
            //{1,"S" },//	Service
            {9,"ST"},//	Student
            {6,"F" },//	FARMER
            {1,"PV"},//	PRIVATE SECTOR
            {2,"PS"},//	PUBLIC SECTOR
            {3,"GS"} //	GOVERNMENT SERVICES
        };
        public static string GetOccupation(int? OccupationNo)
        {
            string Occupation_Code = null;
            try
            {
                l_dictOccupation_Type.TryGetValue(OccupationNo, out Occupation_Code);
            }
            catch { }
            return Occupation_Code.ToString();
        }
        #endregion Get Occupatione by Occupation Code



    }
}
