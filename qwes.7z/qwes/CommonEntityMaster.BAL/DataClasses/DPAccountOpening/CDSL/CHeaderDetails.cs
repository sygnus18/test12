﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTIL.Match.CDD.BAL.DataClasses.DPAccountOpening
{
    /// <summary>
    /// Contains Header details
    /// </summary>
    public class CHeaderDetails
    {
        #region public properties
        public string DPId { get; set; }
        public string OperatorID { get; set; }
        public string TotalNoOfRecords { get; set; }
        #endregion public properties
    }
}
