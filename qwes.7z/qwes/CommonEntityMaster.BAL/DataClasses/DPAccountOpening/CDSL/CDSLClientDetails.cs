﻿using System.Linq;
using FTIL.Match.CDD.BAL.DataClasses.DPAccountOpening.CDSL;
using FTIL.Match.CDD.BAL.DataStore;

namespace FTIL.Match.CDD.BAL.DataClasses.DPAccountOpening
{
    #region First Line
    /// <summary>
    /// Bo Set Up First Line Details
    /// </summary>
    public class clsBOFirstLineDetails
    {
        #region properties
        public string RecordType1 { get; set; }
        public string SerialNo { get; set; }
        public string BOId { get; set; }
        public string BORequestReceiptDate { get; set; }
        #endregion properties

        #region methods
        public void BindObject(Client objClient)
        {
            RecordType1 = RecordType.One.ToString();
            SerialNo = objClient.LineNo.ToString();
            BOId = CDSLDataProvider.CDSLDPIdPrefix.ToString() + CDSLDataProvider.CDSLDPId + objClient.BOID;
            BORequestReceiptDate = objClient.AuthorizeDatetime == null ? null : objClient.AuthorizeDatetime.ToString("ddMMyyyyHHmmss");
        }
        #endregion methods
    }
    #endregion First Line

    #region Second Line
    /// <summary>
    ///  Bo Set Up Second Line Details(First Account Holder)
    /// </summary>
    public class clsBOSecondLineDetails
    {
        #region properties
        public string FAH_RecordType02 { get; set; }
        public string FAH_Product_No { get; set; }
        public string FAH_Bo_Name { get; set; }
        public string FAH_Bo_Middle_Name { get; set; }
        public string FAH_Last_Name { get; set; }
        public string FAH_Bo_Title { get; set; }
        public string FAH_Bo_Suffix { get; set; }
        public string FAH_FatherOrHusband_Name { get; set; }
        public string FAH_Cust_Addr_1 { get; set; }
        public string FAH_Cust_Addr_2 { get; set; }
        public string FAH_Cust_Addr_3 { get; set; }
        public string FAH_Cust_Addr_City { get; set; }
        public string FAH_Cust_Addr_State { get; set; }
        public string FAH_Cust_Addr_Country { get; set; }
        public string FAH_Cust_Addr_Zip { get; set; }
        public string FAH_Cust_ph_1_Indc { get; set; }
        public string FAH_Cust_Ph_1 { get; set; }
        public string FAH_Cust_Ph_2_indc { get; set; }
        public string FAH_Cust_Ph_2 { get; set; }
        public string FAH_Cust_Addl_phone { get; set; }
        public string FAH_Cust_Fax { get; set; }
        public string FAH_PAN { get; set; }
        public string FAH_UID { get; set; }
        public string FAH_Poa_Flag { get; set; }
        public string FAH_Filler1 { get; set; }
        public string FAH_IT_Circle { get; set; }
        public string FAH_Cust_email { get; set; }
        public string FAH_User_Text1 { get; set; }
        public string FAH_User_Text2 { get; set; }
        public string FAH_User_Field3 { get; set; }
        public string FAH_User_Field4 { get; set; }
        public string FAH_User_Field5 { get; set; }
        public string FAH_Signature_File_Flag { get; set; }
        #endregion properties

        #region methods
        public void BindObject(Client objClient)
        {
            ClientAddress objPerAddress = new ClientAddress();
            ClientAddress objCorrAddress = new ClientAddress();

            objPerAddress = objClient.oClientAddresses.GetAddressByType(Client_AddressType.Registered);//for permanat address
            objCorrAddress = objClient.oClientAddresses.GetAddressByType(Client_AddressType.Correspondence);//for Correspondant address

            FAH_RecordType02 = RecordType.Two.ToString();
            FAH_Product_No = CDSLDataProvider.Product_No.ToString();
            FAH_Bo_Name = objClient.ClientName;
            FAH_Bo_Middle_Name = objClient.MiddleName;
            FAH_Last_Name = objClient.LastName;
            FAH_Bo_Title = objClient.ClientTitle;

            FAH_FatherOrHusband_Name = objClient.GuardianName;
            if (objPerAddress != null)
            {
                if (objPerAddress.AddressLine1.Length > CDSLDataProvider.AddLimitPerline || objPerAddress.AddressLine2.Length > CDSLDataProvider.AddLimitPerline || objPerAddress.AddressLine3.Length > CDSLDataProvider.AddLimitPerline)
                {
                    string strPerAdd = objPerAddress.AddressLine1 + objPerAddress.AddressLine2 + objPerAddress.AddressLine3;

                    string[] arrAdd = Process.spiltData(strPerAdd, CDSLDataProvider.AddLimitPerline);
                    if (arrAdd.Length == 3)
                    {
                        FAH_Cust_Addr_1 = arrAdd[0];
                        FAH_Cust_Addr_2 = arrAdd[1];
                        FAH_Cust_Addr_3 = arrAdd[2];
                    }
                    if (arrAdd.Length == 2)
                    {
                        FAH_Cust_Addr_1 = arrAdd[0];
                        FAH_Cust_Addr_2 = arrAdd[1];
                    }
                    if (arrAdd.Length == 1)
                    {
                        FAH_Cust_Addr_1 = arrAdd[0];
                    }
                }
                else
                {
                    FAH_Cust_Addr_1 = Process.RemoveSpecialCharFromString(objPerAddress.AddressLine1);
                    FAH_Cust_Addr_2 = Process.RemoveSpecialCharFromString(objPerAddress.AddressLine2);
                    FAH_Cust_Addr_3 = Process.RemoveSpecialCharFromString(objPerAddress.AddressLine3);
                }
                FAH_Cust_Addr_City = objPerAddress.City;
                FAH_Cust_Addr_State = objPerAddress.StateName;
                FAH_Cust_Addr_Country = objPerAddress.CountryName;
                FAH_Cust_Addr_Zip = objPerAddress.PinCode;
                FAH_Cust_ph_1_Indc = CDSLDataProvider.ph_1_Indc;
                FAH_Cust_Ph_1 = objPerAddress.Mobile1;
                FAH_Cust_email = objPerAddress.EMailId;
                FAH_Signature_File_Flag = CDSLDataProvider.Signature_File_Flag;
                FAH_Cust_Addl_phone = objPerAddress.TelNo1;
                FAH_User_Field3 = "0";
                FAH_User_Field4 = "0000";//For PAN Exemption Code always 0
                FAH_User_Field5 = CDSLDataProvider.First_Holder_PAN_Verification_Code + CDSLDataProvider.Second_Holder_PAN_Verification_Code
                    + CDSLDataProvider.Third_Holder_PAN_Verification_Code + "0";

                //FAH_Poa_Flag = POAType.Regular_POA;
            }
            FAH_PAN = objClient.PANNo;
            FAH_UID = objClient.UID;

            //FAH_Cust_Ph_2_indc       
            //FAH_Cust_Ph_2            
            //FAH_Cust_Fax 
            //FAH_Bo_Suffix            
            //FAH_IT_Circle            
            //FAH_User_Text1           
            //FAH_User_Text2           
            //FAH_Filler1              
        }
        #endregion methods
    }
    #endregion Second Line

    #region Third Line
    /// <summary>
    ///  Bo Set Up Third Line Details(Second Account holder)
    /// </summary>
    public class clsBOThirdLineDetails
    {
        #region properties
        public string SAH_RecordType03 { get; set; }
        public string SAH_Bo_Name { get; set; }
        public string SAH_Bo_Middle_Name { get; set; }
        public string SAH_Search_Name { get; set; }
        public string SAH_Bo_Title { get; set; }
        public string SAH_Bo_Suffix { get; set; }
        public string SAH_FatherOrHusband_Name { get; set; }
        public string SAH_PAN { get; set; }
        public string SAH_UID { get; set; }
        public string SAH_IT_Circle { get; set; }
        public string SAH_MOB_No { get; set; }
        public string SAH_Email { get; set; }
        #endregion properties

        #region methods
        public bool BindObject(Client objClient)
        {
            bool IsUpdated = false;
            SAH_RecordType03 = RecordType.Three.ToString();
            if (objClient.oClientDPDetails.ClientDPDetailList.Count > 0)
            {
                foreach (ClientDPDetail objClientDPDetail in objClient.oClientDPDetails.ClientDPDetailList)
                {
                    if (CDSLDataProvider.arrRelationShipNo.Contains(objClientDPDetail.RelationshipNo))
                    {
                        if (objClientDPDetail.RelationshipNo == RelatedParty.Second_Holder)
                        {
                            if (objClientDPDetail.AccountType == AccountType.Joint)
                            {
                                SAH_Bo_Name = objClientDPDetail.RelatedPartyName;
                                if (!string.IsNullOrEmpty(objClientDPDetail.RelatedPartyName) && objClientDPDetail.RelatedPartyName.Contains(" "))
                                {
                                    string[] arrSAH_Name = objClientDPDetail.RelatedPartyName.Split(' ');
                                    if (arrSAH_Name.Count() > 0)
                                    {
                                        SAH_Bo_Name = arrSAH_Name[0];
                                    }
                                    if (arrSAH_Name.Count() > 1)
                                    {
                                        SAH_Search_Name = arrSAH_Name[arrSAH_Name.Count() - 1];
                                    }
                                    if (arrSAH_Name.Count() > 2)
                                    {
                                        SAH_Bo_Middle_Name = arrSAH_Name[1];
                                    }
                                }
                                SAH_UID = objClientDPDetail.AatharNo;
                                SAH_PAN = objClientDPDetail.PANNo;
                                IsUpdated = true;
                            }
                        }
                    }
                }
            }
            //SAH_Bo_Title            
            //SAH_Bo_Suffix           
            //SAH_FatherOrHusband_Name
            //SAH_IT_Circle           
            //SAH_MOB_No              
            //SAH_Email     
            return IsUpdated;
        }
        #endregion methods
    }
    #endregion Third Line

    #region Fourth Line
    /// <summary>
    ///  Bo Set Up Fourth Line Details(Third Account Holder)
    /// </summary>
    public class clsBOFourthLineDetails
    {
        #region properties
        public string TAH_RecordType04 { get; set; }
        public string TAH_Bo_Name { get; set; }
        public string TAH_Bo_Middle_Name { get; set; }
        public string TAH_Search_Name { get; set; }
        public string TAH_Bo_Title { get; set; }
        public string TAH_Bo_Suffix { get; set; }
        public string TAH_FatherOrHusband_Name { get; set; }
        public string TAH_PAN { get; set; }
        public string TAH_UID { get; set; }
        public string TAH_IT_Circle { get; set; }
        public string TAH_MOB_No { get; set; }
        public string TAH_Email { get; set; }
        #endregion properties

        #region methods
        public void BindObject(Client objClient)
        {
            TAH_RecordType04 = RecordType.Four.ToString();
            if (objClient.oClientDPDetails.ClientDPDetailList.Count > 0)
            {
                foreach (ClientDPDetail objClientDPDetail in objClient.oClientDPDetails.ClientDPDetailList)
                {
                    if (CDSLDataProvider.arrRelationShipNo.Contains(objClientDPDetail.RelationshipNo))
                    {
                        if (objClientDPDetail.RelationshipNo == RelatedParty.Third_Holder)
                        {
                            TAH_Bo_Name = objClientDPDetail.RelatedPartyName;
                            if (!string.IsNullOrEmpty(objClientDPDetail.RelatedPartyName) && objClientDPDetail.RelatedPartyName.Contains(" "))
                            {
                                string[] arrSAH_Name = objClientDPDetail.RelatedPartyName.Split(' ');
                                if (arrSAH_Name.Count() > 0)
                                {
                                    TAH_Bo_Name = arrSAH_Name[0];
                                }
                                if (arrSAH_Name.Count() > 1)
                                {
                                    TAH_Search_Name = arrSAH_Name[arrSAH_Name.Count() - 1];
                                }
                                if (arrSAH_Name.Count() > 2)
                                {
                                    TAH_Bo_Middle_Name = arrSAH_Name[1];
                                }
                            }
                            TAH_UID = objClientDPDetail.AatharNo;
                            TAH_PAN = objClientDPDetail.PANNo;
                        }
                    }
                }
            }

            //TAH_Bo_Title            
            //TAH_Bo_Suffix           
            //TAH_FatherOrHusband_Name
            //TAH_IT_Circle           
            //TAH_MOB_No              
            //TAH_Email               
        }
        #endregion methods
    }
    #endregion Fourth Line

    #region Fifth Line
    /// <summary>
    ///  Bo Set Up Fifth Line Details(Product Details):
    /// </summary>
    public class clsBOFifthLineDetails
    {
        #region properties
        public string RecordType05 { get; set; }
        public string MaturityDate { get; set; }
        public string DP_Internal_Ref_No { get; set; }
        public string DOB { get; set; }
        public string SexCode { get; set; }
        public string Occupation { get; set; }
        public string LifeStyle { get; set; }
        public string Geographical_Code { get; set; }
        public string Education { get; set; }
        public string Annual_income_code { get; set; }
        public string Nationality_Code { get; set; }
        public string Legal_Status_Code { get; set; }
        public string Bo_Fee_Type { get; set; }
        public string Language_Code { get; set; }
        public string Category_4_Code { get; set; }
        public string Bank_Option_5 { get; set; }
        public string StaffOrRelative { get; set; }
        public string Staff_Code { get; set; }
        public string Alph_Code_1_User_Text_1 { get; set; }
        public string Family_Account_Flag { get; set; }
        public string Email_Statement_flag { get; set; }
        public string Cas_Mode { get; set; }
        public string Mental_Disability { get; set; }
        public string Filler_1 { get; set; }
        public string Rgess_Flag { get; set; }
        public string Annual_Report_Flag { get; set; }
        public string Pledge_Standing_Instruction_Flag { get; set; }
        public string Email_Rta_Download_Flag { get; set; }
        public string Bsda_Flag { get; set; }
        public string Alph_Code_2_User_Text_2 { get; set; }
        public string Numeric_4_Dummy1 { get; set; }
        public string Numeric_4_Dummy2 { get; set; }
        public string Numeric_4_Dummy3 { get; set; }
        public string Security_Access_Code { get; set; }
        public string Bo_Category { get; set; }
        public string Bo_Settlement_Planning_Flag { get; set; }
        public string Dividend_Bank_Ifsc_Code { get; set; }
        public string Rbi_Reference_Number { get; set; }
        public string Rbi_Approval_Date { get; set; }
        public string Sebi_Registration_Number { get; set; }
        public string Beneficiary_Tax_Deduction_Status { get; set; }
        public string Smart_Card_Required { get; set; }
        public string Smart_Card_Number { get; set; }
        public string Smart_Card_Pin { get; set; }
        public string EcsOrmandate { get; set; }
        public string Electronic_Confirmation { get; set; }
        public string Dividend_Currency { get; set; }
        public string Group_Code { get; set; }
        public string Bo_Sub_Status { get; set; }
        public string Clearing_Corporation_Id { get; set; }
        public string Clearing_Member_Id { get; set; }
        public string Stock_Exchange { get; set; }
        public string Confirmation_Waived { get; set; }
        public string Trading_Id { get; set; }
        public string Bo_Statement_Cycle_Code { get; set; }
        public string CustodianOrPms_Email_Id { get; set; }
        public string Divnd_Bank_Acct_Type { get; set; }
        public string Divnd_Bank_Code { get; set; }
        public string Divnd_Acct_Numb { get; set; }
        public string Divnd_Bank_Ccy { get; set; }
        #endregion properties

        #region methods
        public void BindObject(Client objClient)
        {
            RecordType05 = RecordType.Five.ToString();

            DP_Internal_Ref_No = objClient.KYCFormRefCode;
            DOB = objClient.DOB == null ? null : objClient.DOB.Value.ToString("ddMMyyyy");
            SexCode = CDSLDataProvider.GetGenderType(objClient.Gender);
            Occupation = CDSLDataProvider.GetOccupation(objClient.Occupation);

            Annual_income_code = objClient.GrAnnIncRange.ToString();
            Nationality_Code = objClient.Nationality.ToString();
            Family_Account_Flag = CDSLDataProvider.Family_Account_Flag;
            Email_Statement_flag = CDSLDataProvider.Email_Statement_flag;
            Mental_Disability = CDSLDataProvider.Mental_Disability;
            Bo_Category = CDSLDataProvider.Bo_Category;
            Bo_Settlement_Planning_Flag = CDSLDataProvider.Bo_Settlement_Planning_Flag;
            Bo_Sub_Status = CDSLDataProvider.Bo_Sub_Status;
            Bo_Statement_Cycle_Code = CDSLDataProvider.Bo_Statement_Cycle_Code.ToString(); //set default value
            //if (objClient.oClientDPDetails.ClientDPDetailList.Count > 0)
            //{
            //    foreach (ClientDPDetail objClientDPDetail in objClient.oClientDPDetails.ClientDPDetailList)
            //    {
            //        if (CDSLDataProvider.arrDPRelationNo.Contains(objClientDPDetail.RelationshipNo))
            //        {
            //            Bo_Statement_Cycle_Code = objClientDPDetail.AccountStatement.ToString();
            //        }
            //    }
            //}

            if (objClient.oClientBankDetails.ClientBankDetailList.Count > 0)
            {
                ClientBankDetail objClientBankDetail = objClient.oClientBankDetails.ClientBankDetailList[0];
                Divnd_Bank_Code = objClientBankDetail.BankMICRCode;                
                Divnd_Acct_Numb = objClientBankDetail.AccountNo;
                Dividend_Bank_Ifsc_Code = objClientBankDetail.BankIFSCCode;
                Divnd_Bank_Acct_Type = CDSLDataProvider.GetDivnd_Bank_Acct_Type(objClientBankDetail.AccountType);
                Divnd_Bank_Ccy = CDSLDataProvider.Divnd_Bank_Ccy.ToString();
            }

            Security_Access_Code    =CDSLDataProvider.Security_Access_Code    ;
            Dividend_Currency       =CDSLDataProvider.Dividend_Currency       ;  
            MaturityDate            =CDSLDataProvider.MaturityDate            ;
            Legal_Status_Code       =CDSLDataProvider.Legal_Status_Code       ;
            Bo_Fee_Type             =CDSLDataProvider.Bo_Fee_Type             ;
            Category_4_Code         =CDSLDataProvider.Category_4_Code         ;
            Bank_Option_5           =CDSLDataProvider.Bank_Option_5           ;
            Numeric_4_Dummy1        =CDSLDataProvider.Numeric_4_Dummy1        ;            
            Numeric_4_Dummy2        =CDSLDataProvider.Numeric_4_Dummy2        ;            
            Numeric_4_Dummy3        =CDSLDataProvider.Numeric_4_Dummy3        ;
            Rbi_Approval_Date       =CDSLDataProvider.Rbi_Approval_Date       ;
            Smart_Card_Pin          =CDSLDataProvider.Smart_Card_Pin          ;
            Clearing_Corporation_Id =CDSLDataProvider.Clearing_Corporation_Id ;
            Stock_Exchange          =CDSLDataProvider.Stock_Exchange          ;
            Confirmation_Waived     =CDSLDataProvider.Confirmation_Waived     ;

            //LifeStyle                       
            //Geographical_Code               
            //Education                       
            //Annual_Report_Flag              
            //Language_Code                   
            //StaffOrRelative                 
            //Staff_Code                      
            //Alph_Code_1_User_Text_1         
            //Cas_Mode                        
            //Filler_1                        
            //Rgess_Flag                      
            //Pledge_Standing_Instruction_Flag
            //Email_Rta_Download_Flag         
            //Bsda_Flag                       
            //Alph_Code_2_User_Text_2         
            //Rbi_Reference_Number            
            //Sebi_Registration_Number        
            //Beneficiary_Tax_Deduction_Status
            //Smart_Card_Required             
            //Smart_Card_Number               
            //EcsOrmandate                    
            //Electronic_Confirmation         
            //Group_Code                      
            //Clearing_Member_Id              
            //Trading_Id                      
            //CustodianOrPms_Email_Id         
        }
        #endregion methods
    }
    #endregion Fifth Line

    #region Sixth Line
    /// <summary>
    ///  Bo Set Up Sixth Line Details(POA Link details):
    /// </summary>
    public class clsBOSixthLineDetails
    {
        #region Properties
        public string RecordType06 { get; set; }
        public string POA_Id { get; set; }
        public string Setup_Date { get; set; }
        public string Poa { get; set; }
        public string Gpa_bpa_Flag { get; set; }
        public string Effective_From_Date { get; set; }
        public string Effective_To_Date { get; set; }
        public string User_Field_1 { get; set; }
        public string User_Field_2 { get; set; }
        public string Ca_Charfld_Remark { get; set; }
        public string Filler_1 { get; set; }
        public string Filler_2 { get; set; }
        public string Filler_3 { get; set; }
        public string Filler_4 { get; set; }
        public string Filler_5 { get; set; }
        public string Filler_6 { get; set; }
        public string Filler_7 { get; set; }
        public string Filler_8 { get; set; }
        public string Filler_9 { get; set; }
        public string Filler_10 { get; set; }
        public string Filler_11 { get; set; }
        public string Filler_12 { get; set; }
        public string Filler_13 { get; set; }
        public string Filler_14 { get; set; }
        public string Filler_15 { get; set; }
        public string Filler_16 { get; set; }
        public string Filler_17 { get; set; }
        public string Filler_18 { get; set; }
        public string Filler_19 { get; set; }
        public string Filler_20 { get; set; }
        public string Filler_21 { get; set; }
        public string Filler_22 { get; set; }
        public string Filler_23 { get; set; }
        public string User_Text_1 { get; set; }
        public string Poa_Master_Id { get; set; }
        public string Filler_24 { get; set; }
        public string User_Field_3 { get; set; }
        public string Filler_25 { get; set; }
        public string Filler_26 { get; set; }
        public string Filler_27 { get; set; }
        #endregion Properties

        #region methods
        public void BindObject(Client objClient)
        {
            RecordType06 = "06";
            //POA_Id             
            //Setup_Date         
            //Poa                
            //Gpa_bpa_Flag       
            //Effective_From_Date
            //Effective_To_Date  
            //User_Field_1       
            //User_Field_2       
            //Ca_Charfld_Remark  
            //Filler_1           
            //Filler_2           
            //Filler_3           
            //Filler_4           
            //Filler_5           
            //Filler_6           
            //Filler_7           
            //Filler_8           
            //Filler_9           
            //Filler_10          
            //Filler_11          
            //Filler_12          
            //Filler_13          
            //Filler_14          
            //Filler_15          
            //Filler_16          
            //Filler_17          
            //Filler_18          
            //Filler_19          
            //Filler_20          
            //Filler_21          
            //Filler_22          
            //Filler_23          
            //User_Text_1        
            //Poa_Master_Id      
            //Filler_24          
            //User_Field_3       
            //Filler_25          
            //Filler_26          
            //Filler_27          
        }
        #endregion methods
    }
    #endregion Sixth Line

    #region Seventh Line
    /// <summary>
    /// Seventh Line is for Permanent Address Details purpose code should be 12
    /// </summary>
    public class clsBOSeventhLineDetails
    {
        #region properties
        public string RecordType07 { get; set; }
        public string Purpose_Code { get; set; }
        public string Bo_Name { get; set; }
        public string Bo_Middle_Name { get; set; }
        public string Last_Name { get; set; }
        public string Bo_Title { get; set; }
        public string Bo_Suffix { get; set; }
        public string FatherOrHusband_Name { get; set; }
        public string Address_line_1 { get; set; }
        public string Address_line_2 { get; set; }
        public string Address_line_3 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public string Zip { get; set; }
        public string Ph_1_indc { get; set; }
        public string Ph_1 { get; set; }
        public string Ph_2_indc { get; set; }
        public string Ph_2 { get; set; }
        public string Additional_Phone { get; set; }
        public string Fax { get; set; }
        public string Income_Tax_Pan { get; set; }
        public string IT_Circle { get; set; }
        public string Cust_mail { get; set; }
        public string User_Text_1 { get; set; }
        public string User_Text_2 { get; set; }
        public string User_Field_3 { get; set; }
        public string User_Field_4 { get; set; }
        public string User_Field_5 { get; set; }
        #endregion properties

        #region methods
        public void BindObject(Client objClient)
        {
            ClientAddress objPerAddress = new ClientAddress();
            ClientAddress objCorrAddress = new ClientAddress();

            objPerAddress = objClient.oClientAddresses.GetAddressByType(Client_AddressType.Registered);//for permanat address
            objCorrAddress = objClient.oClientAddresses.GetAddressByType(Client_AddressType.Correspondence);//for Correspondant address

            RecordType07 = RecordType.Seven.ToString();
            Purpose_Code = PurposeCode.Permanent_Address.ToString();
            Bo_Name = objClient.ClientName;
            Bo_Middle_Name = objClient.MiddleName;
            Last_Name = objClient.LastName;
            if(!string.IsNullOrWhiteSpace(objClient.ClientTitle))
                Bo_Title = objClient.ClientTitle.TrimEnd('.').ToUpper();
            FatherOrHusband_Name = objClient.GuardianName;
            Income_Tax_Pan = objClient.PANNo;

            if (objPerAddress != null)
            {
                if (objPerAddress.AddressLine1.Length > CDSLDataProvider.AddLimitPerline || objPerAddress.AddressLine2.Length > CDSLDataProvider.AddLimitPerline || objPerAddress.AddressLine3.Length > CDSLDataProvider.AddLimitPerline)
                {
                    string strPerAdd = objPerAddress.AddressLine1 + objPerAddress.AddressLine2 + objPerAddress.AddressLine3;

                    string[] arrAdd = Process.spiltData(strPerAdd, CDSLDataProvider.AddLimitPerline);
                    if (arrAdd.Length == 3)
                    {
                        Address_line_1 = arrAdd[0];
                        Address_line_2 = arrAdd[1];
                        Address_line_3 = arrAdd[2];
                    }
                    if (arrAdd.Length == 2)
                    {
                        Address_line_1 = arrAdd[0];
                        Address_line_2 = arrAdd[1];
                    }
                    if (arrAdd.Length == 1)
                    {
                        Address_line_1 = arrAdd[0];
                    }
                }
                else
                {
                    Address_line_1 = Process.RemoveSpecialCharFromString(objPerAddress.AddressLine1);
                    Address_line_2 = Process.RemoveSpecialCharFromString(objPerAddress.AddressLine2);
                    Address_line_3 = Process.RemoveSpecialCharFromString(objPerAddress.AddressLine3);
                }

                City = objPerAddress.City;
                State = objPerAddress.StateName;
                Country = objPerAddress.CountryName;
                Zip = objPerAddress.PinCode;
                Ph_1_indc = CDSLDataProvider.ph_1_Indc;
                Ph_1 = objPerAddress.Mobile1;
                Cust_mail = objPerAddress.EMailId;
                User_Field_3 = "0";
                User_Field_4 = "0";
                User_Field_5 = "0";

                //Bo_Suffix           
                //Ph_2_indc           
                //Ph_2                
                //Additional_Phone    
                //Fax                 
                //IT_Circle           
                //User_Text_1         
                //User_Text_2         
            }
        }
        #endregion methods
    }
    #endregion Seventh Line

    #region Eighth Line
    /// <summary>
    ///  Bo Set Up Eighth Line Details for Nominee Name and address
    /// </summary>
    public class clsBOEighthLineDetails
    {
        #region properties
        public string RecordType08 { get; set; }
        public string Purpose_Code { get; set; }
        public string Bo_Name { get; set; }
        public string Bo_Middle_Name { get; set; }
        public string Last_Name { get; set; }
        public string Bo_Title { get; set; }
        public string Bo_Suffix { get; set; }
        public string FatherOrHusband_Name { get; set; }
        public string Add_Line_1 { get; set; }
        public string Add_Line_2 { get; set; }
        public string Add_Line_3 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public string Zip { get; set; }
        public string Ph_1_Indc { get; set; }
        public string Ph_1 { get; set; }
        public string Ph_2_Indc { get; set; }
        public string Ph_2 { get; set; }
        public string Additional_Phone { get; set; }
        public string DOB { get; set; }
        public string Fax { get; set; }
        public string PanID { get; set; }
        public string Uid { get; set; }
        public string It_Circle { get; set; }
        public string Email { get; set; }
        public string User_Text_1 { get; set; }
        public string User_Text_2 { get; set; }
        public string User_Field_3 { get; set; }
        public string User_Field_4 { get; set; }
        public string User_Field_5 { get; set; }

        public string Nominee_Serial_Number { get; set; }
        public string Relationship_With_Bo { get; set; }
        public string Percentage_Of_Shares { get; set; }
        public string Residual_Securities_Flag { get; set; }

        #endregion properties

        #region methods
        public bool BindObject(Client objClient)
        {
            bool IsUpdated = false;
            //RecordType08
            //Purpose_Code
            //Bo_Name
            //Bo_Middle_Name
            //Last_Name
            //Bo_Title
            //Bo_Suffix
            //FatherOrHusband_Name
            //Add_Line_1
            //Add_Line_2
            //Add_Line_3
            //City
            //State
            //Country
            //Zip
            //Ph_1_Indc
            //Ph_1
            //Ph_2_Indc
            //Ph_2
            //Additional_Phone
            //DOB
            //Fax
            //PanID
            //Uid
            //It_Circle
            //Email
            //User_Text_1
            //User_Text_2
            //User_Field_3
            //User_Field_4
            //User_Field_5
            return IsUpdated;
        }

        public bool BindNomineeObject(Client objClient)
        {
            bool IsUpdated = false;

            if (objClient.oClientDPDetails.ClientDPDetailList.Count > 0)
            {
                foreach (ClientDPDetail objClientDPDetail in objClient.oClientDPDetails.ClientDPDetailList)
                {
                    if (!CDSLDataProvider.arrRelationShipNo.Contains(objClientDPDetail.RelationshipNo))
                    {
                        if (objClientDPDetail.Nomination != "N")
                        {
                            IsUpdated = true;
                            Purpose_Code = PurposeCode.Nominee_Name_And_Address.ToString();// "6";
                            Nominee_Serial_Number = "01";
                            Bo_Name = objClientDPDetail.RelatedPartyName;
                            if (!string.IsNullOrEmpty(objClientDPDetail.RelatedPartyName) && objClientDPDetail.RelatedPartyName.Contains(" "))
                            {
                                string[] arrRelatedParty_Name = objClientDPDetail.RelatedPartyName.Split(' ');
                                if (arrRelatedParty_Name.Count() > 0)
                                {
                                    Bo_Name = arrRelatedParty_Name[0];
                                }
                                if (arrRelatedParty_Name.Count() > 1)
                                {
                                    Last_Name = arrRelatedParty_Name[arrRelatedParty_Name.Count() - 1];
                                }
                                if (arrRelatedParty_Name.Count() > 2)
                                {
                                    Bo_Middle_Name = arrRelatedParty_Name[1];
                                }
                            }
                            if (objClientDPDetail.RelatedPartyDOB.HasValue)
                                DOB = objClientDPDetail.RelatedPartyDOB.Value.ToString("ddMMyyyy");

                            //Bo_Title
                            //Bo_Suffix
                            //FatherOrHusband_Name
                            //Additional_Phone
                            //Fax
                            //PanID
                            //Uid
                            Relationship_With_Bo = CDSLDataProvider.GetRelationBONo(objClientDPDetail.RelationshipNo);
                            Percentage_Of_Shares = CDSLDataProvider.Percentage_Of_Shares.ToString();
                            Residual_Securities_Flag = CDSLDataProvider.Residual_Securities_Flag;
                            ClientAddress objRelatedPartyAddress = new ClientAddress();
                            objRelatedPartyAddress = objClient.oNomineeAddresses.GetAddressByType(Client_AddressType.RelatedParty);//for Related Party address

                            if (objRelatedPartyAddress != null)
                            {
                                if (objRelatedPartyAddress.AddressLine1.Length > CDSLDataProvider.AddLimitPerline || objRelatedPartyAddress.AddressLine2.Length > CDSLDataProvider.AddLimitPerline || objRelatedPartyAddress.AddressLine3.Length > CDSLDataProvider.AddLimitPerline)
                                {
                                    string strAdd = objRelatedPartyAddress.AddressLine1 + objRelatedPartyAddress.AddressLine2 + objRelatedPartyAddress.AddressLine3;

                                    string[] arrAdd = Process.spiltData(strAdd, CDSLDataProvider.AddLimitPerline);
                                    if (arrAdd.Length == 3)
                                    {
                                        Add_Line_1 = arrAdd[0];
                                        Add_Line_2 = arrAdd[1];
                                        Add_Line_3 = arrAdd[2];
                                    }
                                    if (arrAdd.Length == 2)
                                    {
                                        Add_Line_1 = arrAdd[0];
                                        Add_Line_2 = arrAdd[1];
                                    }
                                    if (arrAdd.Length == 1)
                                    {
                                        Add_Line_1 = arrAdd[0];
                                    }
                                }
                                else
                                {
                                    Add_Line_1 = Process.RemoveSpecialCharFromString(objRelatedPartyAddress.AddressLine1);
                                    Add_Line_2 = Process.RemoveSpecialCharFromString(objRelatedPartyAddress.AddressLine1);
                                    Add_Line_3 = Process.RemoveSpecialCharFromString(objRelatedPartyAddress.AddressLine1);
                                }

                                City = objRelatedPartyAddress.City;
                                State = objRelatedPartyAddress.StateName;
                                Country = objRelatedPartyAddress.CountryName;
                                Zip = objRelatedPartyAddress.PinCode;
                                Ph_1_Indc = CDSLDataProvider.ph_1_Indc;
                                Ph_1 = objRelatedPartyAddress.Mobile1;
                                Email = objRelatedPartyAddress.EMailId;

                                //Ph_2_Indc
                                //Ph_2
                            }

                            //RecordType08
                            //It_Circle
                            //User_Text_1
                            //User_Text_2
                            //User_Field_3
                            //User_Field_4
                            //User_Field_5
                        }
                    }
                }
            }
            return IsUpdated;
        }
        #endregion methods
    }
    #endregion Eighth Line

    #region Ninth Line
    /// <summary>
    ///  Bo Set Up ninth Line Details for SMS File Setup Registration
    /// </summary>
    public class clsBONinthLineDetails
    {
        #region Properties
        public string RecordType09 { get; set; }
        public string Purpose_Code { get; set; }
        public string Upload_Flag { get; set; }
        public string Mob_No { get; set; }
        public string Email_Id { get; set; }
        public string Remarks { get; set; }
        public string Push_Pull_Flag { get; set; }
        #endregion Properties

        #region methods
        public bool BindObject(Client objClient)
        {
            bool IsUpdated = false;
            ClientAddress objPerAddress = new ClientAddress();

            objPerAddress = objClient.oClientAddresses.GetAddressByType(Client_AddressType.Registered);//for permanat address

            if (objPerAddress != null)
            {
                Purpose_Code = PurposeCode.SMS_Registration.ToString();//FOR SMS REGISTRATION
                Upload_Flag = "S";
                Mob_No = objPerAddress.Mobile1;
                Email_Id = objPerAddress.EMailId;
                Push_Pull_Flag = "P";
                IsUpdated = true;

                //RecordType09 = "08";
                //Remarks
            }
            return IsUpdated;
        }
        #endregion methods
    }
    #endregion Ninth Line
}


