﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;  
using FTIL.Match.Common.Db;
using System.Windows.Forms;
using System.Data.SqlClient;
using FTIL.Match.Common;
using FTIL.Match.Common.Log;


/// <summary>
///================================================================================          
/// File/Class/Custom Name    : CAudittrail.cs
/// Base CR No.               : 
/// Author                    : kushal S
/// DateCreated               : 24-03-2015
/// Reviewd By                :
/// Description               : Class to provide Audit trails
/// 
///================================================================================

///================================================================================
///                           Revision History
///================================================================================          
/// Author                    :
/// Revision/CR No.           :
/// Revision Date             :
/// Reviewd By                :          
/// Reason for Revision       :
///================================================================================
/// </summary>

namespace FTIL.Match.CDD.BAL
{
    public class CAudittrailPopUp
    {
        #region Variables

        public static readonly string MODULENAME = "s_ModuleName";
        public static readonly string SUBMODULENAME = "s_SubModuleName";
        public static readonly string TABLEDESCRIPTION = "s_TableDescription";
        public static readonly string TABLENAME = "s_TableName";
        public static readonly string VIEWNAME = "s_ViewName"; 

        public string OperationType
        {
            get;
            set;
        }
        public string PageSize
        {
            get;
            set;
        }
        public string SearchPageNo
        {
            get;
            set;
        }
        public string SubModuleName
        {
            get;
            set;
        }
        public string TableDescription
        {
            get;
            set;
        }
        public string FromDate
        {
            get;
            set;
        }
        public string ToDate
        {
            get;
            set;
        }
        public string RecordType
        {
            get;
            set;
        }
        public string  Column
        {
            get;
            set;
        }
        public string  FilterValue
        {
            get;
            set;
        }
        public string ClientCode
        {
            get;
            set;
        }  

        #endregion

        #region Constructor
        public CAudittrailPopUp()
        {
        }
        #endregion

        #region AuditTrailOperation
        public MethodExecResult AuditTrailOperation(ref DataSet dsGrpdata)
        {
            try
            {

                DbWorkItem objdbwork = new DbWorkItem("stp_CCMAuditTrailData");
                objdbwork.ResultType = QueryType.DataSet;

                objdbwork.AddParameter(new SqlParameter("Pn_OperationType", OperationType));
                objdbwork.AddParameter(new SqlParameter("Pn_PageSize", PageSize));
                objdbwork.AddParameter(new SqlParameter("Pn_SearchPageNo", SearchPageNo));
                objdbwork.AddParameter(new SqlParameter("Ps_SubModuleName", SubModuleName));
                objdbwork.AddParameter(new SqlParameter("Ps_TableDescription", TableDescription));
                objdbwork.AddParameter(new SqlParameter("Pd_FromDate", FromDate));
                objdbwork.AddParameter(new SqlParameter("Pd_ToDate", ToDate)); 
                objdbwork.AddParameter(new SqlParameter("Ps_User", AppEnvironment.AppUser.UserNo));
                objdbwork.AddParameter(new SqlParameter("Ps_Column", Column));
                objdbwork.AddParameter(new SqlParameter("Ps_FilterValue", FilterValue));
                objdbwork.AddParameter(new SqlParameter("Ps_ClientCode", ClientCode)); 

                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {

                    dsGrpdata = objdbwork.Result as DataSet;
                    if ((dsGrpdata == null) || (dsGrpdata.Tables.Count == 0))
                    {
                        return new MethodExecResult(-1, null, "No recordset returned from database.", null);
                    }

                    return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, string.Empty, null);
                }
                else
                {
                    Logger.Instance.WriteLog(typeof(CAudittrail), objdbwork.ExecutionStatus);
                    return objdbwork.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CAudittrail), ex.Message);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }
        }
        #endregion
         
    }

}
