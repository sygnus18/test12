﻿using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace FTIL.Match.CDD.BAL
{
    public class cCommission
    {
        #region GetExchangeDetails
        /// <summary>
        /// Get Entity Exchange details
        /// </summary>
        /// <param name="nClientNo">ClientNo</param>
        /// <returns>Method Execution result</returns>
        //public MethodExecResult GetBrokerageDetails(ref DataTable dtResult)
        //{
        //    DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetBrokerageDetails");
        //    l_objDbWorkItem.ResultType = QueryType.DataSet;

        //   // l_objDbWorkItem.AddParameter("@pn_EntityNo", SqlDbType.Int, nClientNo);
        //   // l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

        //    DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
        //    if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
        //    {
        //        DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
        //        if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
        //            return new MethodExecResult(1, "No data found", "stp_GetBrokerageDetails Database returned no data. UserNo. " +
        //                AppEnvironment.AppUser.UserNo.ToString(), null);
        //        else
        //        {
        //            dtResult = l_dsReturnData.Tables[0];
        //            return  l_objDbWorkItem.ExecutionStatus;
        //        }
        //    }
        //    else
        //    {
        //        return l_objDbWorkItem.ExecutionStatus;
        //    }
        //}
        #endregion
    }
}
