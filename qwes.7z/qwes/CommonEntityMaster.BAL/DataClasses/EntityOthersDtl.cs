﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace FTIL.Match.CDD.BAL.DataClasses
{
    /// <summary>
    /// Class for storing Entity Document Details
    /// </summary>
    public class EntityOthersDtl
    {
        public EntityOthersDtl()
        {
            dtResult = new DataTable();

            dtResult.Columns.Add("n_ClientDocNo", typeof(int));
            dtResult.Columns.Add("n_Type", typeof(int));
            dtResult.Columns.Add("s_Details", typeof(string));
            dtResult.Columns.Add("d_DateOfIssue", typeof(DateTime));
            dtResult.Columns.Add("d_DateOfExpiry", typeof(DateTime));
            dtResult.Columns.Add("s_IssuedPlace", typeof(string));
            dtResult.Columns.Add("s_ProofProvided", typeof(string));
            dtResult.Columns.Add("s_HasChanged", typeof(string));
            dtResult.Columns.Add("s_DocType", typeof(string));
            dtResult.Columns.Add("FileModifiedDateTime", typeof(string));
        }

        public int DocNo { get; set; }
        public string IdentityType { get; set; }
    
        public string IdentityTypeDetails { get; set; }
        public DateTime DateOfIssue { get; set; }
        public DateTime ExpiryDate { get; set; }
        public string PlaceOfIssue { get; set; }
        public string ProofProvided { get; set; }
        public bool IsVaild { get; set; }
        public DateTime? dLastUpdatedDate { get; set; } 
        /// <summary>
        /// Document Detail DataTable
        /// </summary>
        public DataTable dtResult { get; set; }


        /// <summary>
        /// Update/Sync datatable with current property
        /// </summary>
        public void SetDataResult()
        {
            DataTable dt;
            dt = dtResult;

            DataRow[] dr =   dt.Select("n_Type = " + IdentityType);

            if (dr.Length > 0)
            {
                string changedFlag = "N";

                if (Convert.ToString(dr[0]["s_Details"]) != IdentityTypeDetails)
                {
                    dr[0]["s_Details"] = IdentityTypeDetails;
                    changedFlag = "Y";
                }


                DateTime date;

                DateTime.TryParse(dr[0]["d_DateOfIssue"].ToString(), out date);

                if (DateTime.TryParse(dr[0]["d_DateOfIssue"].ToString(), out date))
                {
                    if (date.Date != DateOfIssue.Date)
                    {
                        dr[0]["d_DateOfIssue"] = DateOfIssue.Date;
                        changedFlag = "Y";
                    }
                }

                if (DateTime.TryParse(dr[0]["d_DateOfIssue"].ToString(), out date))
                {
                    if (date.Date != ExpiryDate.Date)
                    {
                        dr[0]["d_DateOfExpiry"] = ExpiryDate.Date;
                        changedFlag = "Y";
                    }
                }


                if (Convert.ToString(dr[0]["s_IssuedPlace"]) != PlaceOfIssue)
                {
                    dr[0]["s_IssuedPlace"] = PlaceOfIssue;
                    changedFlag = "Y";
                }

                dr[0]["s_HasChanged"] = changedFlag;

                if (changedFlag == "Y")
                {
                    dtResult.AcceptChanges();
                }
            }
            else
                dt.Rows.Add(new object[] { DocNo, IdentityType, IdentityTypeDetails, DateOfIssue.Date, ExpiryDate.Date, PlaceOfIssue, ProofProvided, "Y",System.DateTime.Now }); 

            dtResult = dt;
        }
    }
}
