﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTIL.Match.CDD.BAL.DataStore
{
    public class ClientDPDetails
    {
         List<ClientDPDetail> m_ClientDPDetail; 
        #region constructor
         public ClientDPDetails()
        {
            m_ClientDPDetail = new List<ClientDPDetail>();
        }
        #endregion constructor

        /// <summary>
         /// Client DP Detail List
        /// </summary>
         public List<ClientDPDetail> ClientDPDetailList
        {
            get { return m_ClientDPDetail; }
            set { m_ClientDPDetail = value; }
        }

        /// <summary>
        /// Add new DP Detail
        /// </summary>
         /// <param name="oClientDPDetail">ClientDPDetail Object filled with details</param>
        /// <returns>0 - Success, -1 - Failed</returns>
         public int Add(ClientDPDetail oClientDPDetail)
        {
            int oResult = m_ClientDPDetail.FindIndex(obj => obj.RelatedPartyNo == oClientDPDetail.RelatedPartyNo);

            if (oResult != 0)
            {
                m_ClientDPDetail.Add(oClientDPDetail);
                return 0;
            }
            else
            {
                return -1;
            }
            //ClientDPDetailList.Add(oClientDPDetail);
            ////    return 0;
        }
    }
}
