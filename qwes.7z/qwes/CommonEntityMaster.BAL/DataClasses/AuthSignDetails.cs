﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace FTIL.Match.CDD.BAL.DataClasses
{
    /// <summary>
    /// Class for storing Authorised Signatories.
    /// </summary>
    public class AuthSignDetails
    {
        public AuthSignDetails()
        {
            dtResult = new DataTable();
            dtResult.Columns.Add("s_ClientName", typeof(string));
            dtResult.Columns.Add("n_Type", typeof(int));
            dtResult.Columns.Add("s_Details", typeof(string));
            dtResult.Columns.Add("n_RelationshipNo", typeof(int));
            dtResult.Columns.Add("s_CustId", typeof(string));
            dtResult.Columns.Add("n_EntityNo", typeof(int));
            dtResult.Columns.Add("n_RelatedEntityNo", typeof(int));
            dtResult.Columns.Add("n_RelatedPartyNo", typeof(int));
            dtResult.Columns.Add("n_RowNo", typeof(int));
            dtResult.Columns.Add("s_HasChanged", typeof(string));
            dtResult.Columns.Add("DOB", typeof(DateTime));
            dtResult.Columns.Add("d_LastModifiedDateTime", typeof(string));
            dtResult.Columns.Add("POADate", typeof(string));
            dtResult.Columns.Add("sAuthSign", typeof(string));
            dtResult.Columns.Add("s_OtherRelation", typeof(string));
            dtResult.Columns.Add("s_PANNo", typeof(string));
            dtResult.Columns.Add("s_GuardianName", typeof(string));
            dtResult.Columns.Add("n_Occupation", typeof(int));
            dtResult.Columns.Add("s_AatharNo", typeof(string));
            dtResult.Columns.Add("s_MinerRelation", typeof(string));
            dtResult.Columns.Add("n_IsNomineeAddsameasEntity", typeof(string));
            dtResult.Columns.Add("s_DematStatus", typeof(string));
            dtResult.Columns.Add("s_AccountType", typeof(string));
            dtResult.Columns.Add("s_DPID", typeof(string));
            dtResult.Columns.Add("s_DPName", typeof(string));
            dtResult.Columns.Add("s_BeneficiaryId", typeof(string));
            dtResult.Columns.Add("s_OccupationOthers", typeof(string));
            dtResult.Columns.Add("s_DPType", typeof(string));
            dtResult.Columns.Add("s_Nomination", typeof(string));
            dtResult.Columns.Add("n_AccountStatement", typeof(int)); 


            dtAddress = new DataTable();

            dtAddress.Columns.Add("n_ClientNo", typeof(int));
            dtAddress.Columns.Add("s_AddressLine1", typeof(string));
            dtAddress.Columns.Add("s_AddressLine2", typeof(string));
            dtAddress.Columns.Add("s_AddressLine3", typeof(string));
            dtAddress.Columns.Add("n_CityStateCode", typeof(int));
            dtAddress.Columns.Add("s_StateOther", typeof(string));
            dtAddress.Columns.Add("n_CountryCode", typeof(int));
            dtAddress.Columns.Add("s_PinCode", typeof(string));
            dtAddress.Columns.Add("s_TelNo1",  typeof(string));
            dtAddress.Columns.Add("s_TelNoOffice", typeof(string));
            dtAddress.Columns.Add("s_FaxNo",typeof(string));
            dtAddress.Columns.Add("s_City", typeof(string));
            dtAddress.Columns.Add("n_StateNumber", typeof(int));
            dtAddress.Columns.Add("s_EMailId", typeof(string));
            dtAddress.Columns.Add("s_Mobile1", typeof(string));
            dtAddress.Columns.Add("s_Mobile2", typeof(string));
            dtAddress.Columns.Add("n_RowNo", typeof(int));
            dtAddress.Columns.Add("n_AddressNo", typeof(int));
            

            Deleted = false;
        }

        public int IndividualEntityNo { get; set; }

        public int NonIndividualEntityNo { get; set; }

        public int RelatedPartyNo { get; set; }

        public int RelationshipNo { get; set; }

        public string DIN { get; set; }

        public DataTable dtResult { get; set; }

        public DataTable dtAddress { get; set; }

        public string CustID { get; set; }

        public string IndividualName { get; set; }

        public string IDType { get; set; }

        public bool Deleted { get; set; }
        public bool IsRelatedPartyGridUpdated { get; set; }
        public string AuthSign { get; set; }
        public string sOtherRelation { get; set; }

        public DateTime? dDOB { get; set; }
        public DateTime? dLastUpdatedDate { get; set; }
        public DateTime? POADate { get; set; }

        public string PANNo { get; set; }

        public string GuardianName { get; set; }

        public int Occupation { get; set; }

        public string AatharNo { get; set; }

        public string MinerRelation { get; set; }

        public int n_IsNomineeAddsameasEntity { get; set; }

        public string DematStatus { get; set; }
        public string AccountType { get; set; }
        public string DPID { get; set; }
        public string DPName { get; set; }
        public string BeneficiaryId { get; set; }
        public string OccupationOthers { get; set; }
        public string DPType { get; set; }
        public string s_Nomination { get; set; }

        public int AccountStatement { get; set; }
        /// <summary>
        /// Sync. DataTable with properties/fields
        /// </summary>
        public void SetDataResult(int nRowNo)
        {

            DataRow[] dr = null;
            
            if(IndividualEntityNo > 0)
                dr = dtResult.Select("n_RelatedEntityNo = " + IndividualEntityNo);
            else
                dr = dtResult.Select("s_ClientName = '" + IndividualName + "'");


            if (dr.Length > 0)
            {
                string changedFlag = "N";

                if (Convert.ToInt32(dr[0]["n_RelationshipNo"]) != RelationshipNo)
                {
                    dr[0]["n_RelationshipNo"] = RelationshipNo;
                    changedFlag = "Y";
                }
                if (dr[0]["n_Type"].ToString() != IDType)
                {
                    dr[0]["n_Type"] = IDType;
                    changedFlag = "Y";
                }
                if (dr[0]["s_Details"].ToString() != DIN)
                {
                    dr[0]["s_Details"] = DIN;
                    changedFlag = "Y";
                }
                if (dr[0]["s_ClientName"].ToString() != IndividualName)
                {
                    dr[0]["s_ClientName"] = IndividualName;
                    changedFlag = "Y";
                }
                if (dr[0]["DOB"].ToString() == "")
                {
                    dr[0]["DOB"] = dDOB;
                    changedFlag = "Y";
                }
                else
                    if (dr[0]["DOB"].ToString() != dDOB.ToString())
                    {
                        dr[0]["DOB"] = dDOB;
                        changedFlag = "Y";
                    }


                if (dr[0]["POADate"].ToString() == "")
                {
                    if (POADate != null)
                    {
                        dr[0]["POADate"] = POADate;
                        changedFlag = "Y";
                    }
                }
                else
                    if (Convert.ToDateTime(dr[0]["POADate"].ToString()) != POADate)
                    {
                        if (POADate != null)
                        {
                            dr[0]["POADate"] = POADate;
                            changedFlag = "Y";
                        }
                    }


                if (dr[0]["sAuthSign"].ToString() != AuthSign)
                {
                    dr[0]["sAuthSign"] = AuthSign;
                    changedFlag = "Y";
                }

                if (dr[0]["s_OtherRelation"].ToString() != sOtherRelation)
                {
                    dr[0]["s_OtherRelation"] = sOtherRelation;
                    changedFlag = "Y";
                }

                if (dr[0]["s_PANNo"].ToString() != PANNo)
                {
                    dr[0]["s_PANNo"] = PANNo;
                    changedFlag = "Y";
                }

                if (dr[0]["s_GuardianName"].ToString() != GuardianName)
                {
                    dr[0]["s_GuardianName"] = GuardianName;
                    changedFlag = "Y";
                }

                if (Convert.ToInt32(dr[0]["n_Occupation"])!= Occupation)
                {
                    dr[0]["n_Occupation"] = Occupation;
                    changedFlag = "Y";
                }

                if (Convert.ToInt32(dr[0]["n_AccountStatement"]) != AccountStatement)
                {
                    dr[0]["n_AccountStatement"] = AccountStatement;
                    changedFlag = "Y";
                }

                if (dr[0]["s_AatharNo"].ToString() != AatharNo)
                {
                    dr[0]["s_AatharNo"] = AatharNo;
                    changedFlag = "Y";
                }

                if (dr[0]["s_MinerRelation"].ToString() != MinerRelation)
                {
                    dr[0]["s_MinerRelation"] = MinerRelation;
                    changedFlag = "Y";
                }

                if (Convert.ToInt32(dr[0]["n_IsNomineeAddsameasEntity"]) != n_IsNomineeAddsameasEntity)
                {
                    dr[0]["n_IsNomineeAddsameasEntity"] = n_IsNomineeAddsameasEntity;
                    changedFlag = "Y";
                }

                if (Convert.ToInt32(dr[0]["s_DematStatus"]) != n_IsNomineeAddsameasEntity)
                {
                    dr[0]["s_DematStatus"] = DematStatus;
                    changedFlag = "Y";
                }
                if (dr[0]["s_AccountType"].ToString() != AccountType)
                {
                    dr[0]["s_AccountType"] = AccountType;
                    changedFlag = "Y";
                }
                if (Convert.ToString(dr[0]["s_DPID"]) != DPID)
                {
                    dr[0]["s_DPID"] = n_IsNomineeAddsameasEntity;
                    changedFlag = "Y";
                }
                if (Convert.ToString(dr[0]["s_DPName"]) != DPName)
                {
                    dr[0]["s_DPName"] = n_IsNomineeAddsameasEntity;
                    changedFlag = "Y";
                }
                if (Convert.ToString(dr[0]["s_BeneficiaryId"]) != BeneficiaryId)
                {
                    dr[0]["s_BeneficiaryId"] = BeneficiaryId;
                    changedFlag = "Y";
                }
                if (Convert.ToString(dr[0]["s_OccupationOthers"]) != OccupationOthers)
                {
                    dr[0]["s_OccupationOthers"] = OccupationOthers;
                    changedFlag = "Y";
                }

                if (dr[0]["s_DPType"].ToString() != DPType)
                {
                    dr[0]["s_DPType"] = DPType;
                    changedFlag = "Y";
                }
                //s_Nomination
                if (dr[0]["s_Nomination"].ToString() != s_Nomination)
                {
                    dr[0]["s_Nomination"] = s_Nomination;
                    changedFlag = "Y";
                }

                dr[0]["s_HasChanged"] = changedFlag;

                if (changedFlag == "Y")
                {
                    dtResult.AcceptChanges();
                }
            }
            else
                dtResult.Rows.Add(new object[] {
                    IndividualName, IDType, DIN, RelationshipNo,CustID, NonIndividualEntityNo, IndividualEntityNo, RelatedPartyNo
                    , nRowNo, "Y", dDOB,System.DateTime.Now, POADate, AuthSign, sOtherRelation,PANNo,GuardianName,Occupation,AatharNo,MinerRelation,n_IsNomineeAddsameasEntity
                ,DematStatus,AccountType,DPID,DPName,BeneficiaryId,OccupationOthers,DPType,s_Nomination,AccountStatement });
        }


        public void SetEntityAddress(Address address, int RelatedPartyNo, int nRowNo)
        {
            DataRow[] dr = null;

            if (RelatedPartyNo > 0)
            {
                dr = dtAddress.Select("n_ClientNo = " + RelatedPartyNo);

                DataRow[] entityRow = dtResult.Select("n_RelatedPartyNo = " + RelatedPartyNo);

                if (entityRow.Length > 0)
                    entityRow[0]["s_HasChanged"] = "Y";

            }
            else
                dr = dtAddress.Select("n_RowNo = " + nRowNo);


            if (dr.Length > 0) dtAddress.Rows.Remove(dr[0]);

            dtAddress.Rows.Add(new object[] { RelatedPartyNo,
                                      // address.AddressNo,
                                        address.Address_Line1,
                                        address.Address_Line2,
                                        address.Address_Line3,
                                        address.StateCode,
                                        address.State_Others,
                                        address.Country,
                                        address.PIN_Code,
                                        address.Tel_Res,
                                        address.Tel_Work,
                                        address.Fax_No,
                                        address.City,
                                        address.StateCode,
                                        address.Email_ID,
                                        address.Mobile_No,
                                        address.Mobile_NoWork,
                                        nRowNo,
                                         address.AddressNo,
                             });
        }

        /// <summary>
        /// Check records in DataTable has been updated or not
        /// </summary>
        /// <returns>Return true if updated</returns>
        public bool HasRecordUpdated()
        {
            if (Deleted) return true;

           DataRow[] dr = dtResult.Select("s_HasChanged = " + "'Y'");
         
           return dr.Length > 0;
        }
    }
}
