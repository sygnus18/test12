﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FTIL.Match.CDD.BAL.DataClasses.CKYC;
using FTIL.Match.CDD.BAL.DataStore;
using FTIL.Match.Common.Log;
using iTextSharp.text;
using iTextSharp.text.html;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using XceedZipLib;
 

namespace FTIL.Match.CDD.BAL.DataClasses.KRAFileDownload
{
    public class CKRADownload
    {
        #region class variables
        public StringBuilder sbKRADownloadDetails;
        public static readonly string DATEFORMAT = "yyyyMMdd";
        public static readonly string DATETIMEFORMAT = "ddMMyyyyHHmmss";
        public static readonly string TIMEFORMAT = "HHmmss";
        public static string BaseDirectory = AppDomain.CurrentDomain.BaseDirectory.ToString();
        public static string KRADownloadPath = BaseDirectory + System.Configuration.ConfigurationManager.AppSettings["KRAFileDownloadPath"];
        public static string KRAPdfPath = BaseDirectory + System.Configuration.ConfigurationManager.AppSettings["PDFPath"];
        public static string KRAFileDownloadPath = System.Configuration.ConfigurationManager.AppSettings["KRAFileDownloadPath"];
        public static readonly string FILEEXTENSION = ".txt";
        public static string sdate;
        string KRAFolderPath = string.Empty;
        string BatchNo = "0000";
        string sPath = string.Empty;
        string sDownloadPath = string.Empty;
        #endregion class variables

        #region public properties
        public string sDateOfCreation { get; set; }
        public string UserID { get; set; }
        public int LineNo { get; set; }
        #endregion public properties

        #region constructor
        public CKRADownload(string sUserID)
        {
            sbKRADownloadDetails = new StringBuilder();
            UserID = sUserID;
            LineNo = 0;
        }
        #endregion constructor

        #region Methods

        #region KRA download file Header Details
        /// <summary>
        /// Add header details.
        /// </summary>
        /// <returns>header string</returns>
        public string HeaderDetails(int nTotalClients)
        {
            StringBuilder sbHeader = new StringBuilder();
            DateTime dCurrentDate = DateTime.Now;

            try
            {
                CKRAHeaderDetails objHeaderDetails = new CKRAHeaderDetails();

                objHeaderDetails.RecordType = NDMLRecordType.ConstNDMLIndividualHeader;
                objHeaderDetails.BatchNo = BatchNo;
                objHeaderDetails.BranchCode = CNDMLDataProvider.BranchCode;
                objHeaderDetails.IntermediaryID = CNDMLDataProvider.IntermediaryID;
                objHeaderDetails.IntermediaryRole = CNDMLDataProvider.IntermediaryRole;
                objHeaderDetails.TotalRecords = nTotalClients;
                objHeaderDetails.SenderDate = dCurrentDate.ToString(DATEFORMAT);
                objHeaderDetails.FileFormatVersion = CNDMLDataProvider.FileFormatVersion;

                sbHeader.Append(objHeaderDetails.RecordType.ToString().PadLeft(2, '0'));//1.RecordType  
                sbHeader.Append(Process.GetFixLenString(BatchNo.ToString(), 8, '0'));
                sbHeader.Append(Process.GetFixLenString(objHeaderDetails.BranchCode, 6, '0'));
                sbHeader.Append(Process.GetFixLenString(objHeaderDetails.IntermediaryID, 5));
                sbHeader.Append(Process.GetFixLenString(objHeaderDetails.IntermediaryRole.ToString(), 2, '0'));
                sbHeader.Append(Process.GetFixLenString(objHeaderDetails.TotalRecords.ToString(), 7, '0'));
                sbHeader.Append(Process.GetFixLenString(objHeaderDetails.SenderDate, 8));
                sbHeader.Append(Process.GetFixLenString(objHeaderDetails.UserId, 8));
                sbHeader.Append(Process.GetFixLenString(objHeaderDetails.FileFormatVersion, 6));
                sbHeader.Append(Process.GetFixLenString(objHeaderDetails.Filler, 28));
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "HeaderDetails() Error while Adding KRA download file header details. ", ex);
                throw ex;
            }
            return sbHeader.ToString();
        }
        #endregion KRA download file Header Details

        #region Generate KRA download file
        public string GenerateKRADownloadFile(Clients objClients,CKYCReferenceData objCKYCReferenceData)
        {
            string resp = string.Empty;
            string strHeaderData = string.Empty;
            int TotalClients = objClients.objClients.Count();
            if (objCKYCReferenceData.BatchNo != null && objCKYCReferenceData.BatchNo != "0")
                BatchNo = objCKYCReferenceData.BatchNo;
            else
            {
                BatchNo = Process.GetFixLenString(objClients.BatchNo.ToString(), 8, '0');
                objCKYCReferenceData.BatchNo = Process.GetFixLenString(objClients.BatchNo.ToString(), 8, '0');
            }

            //BatchNo = objCKYCReferenceData.BatchNo;

            StringBuilder sbKRADownloadDetails = new StringBuilder();
            DateTime dCurrentDate = DateTime.Now;
            string KRAFolderName = dCurrentDate.ToString(DATEFORMAT) + "_KRA";
            KRAFolderPath = KRADownloadPath + KRAFolderName + "\\";
            //create Folder if not exists
            FileInfo fileinfo = new FileInfo(KRAFolderPath);
            if (!fileinfo.Exists)
                Directory.CreateDirectory(fileinfo.Directory.FullName);


            sPath = KRAFolderPath + dCurrentDate.ToString(DATEFORMAT) + "_KRA" + FILEEXTENSION;
            objCKYCReferenceData.FileName = dCurrentDate.ToString(DATEFORMAT) + "_KRA" + FILEEXTENSION;
            sDownloadPath = KRAFileDownloadPath + dCurrentDate.ToString(DATEFORMAT) + "_KRA" + ".zip";
            
            //Delete existing file if exists
            if (File.Exists(sPath))
            {
                File.Delete(sPath);
            }

            //Write data in to file. 
            using (StreamWriter swKRADownloadFileNew = File.CreateText(sPath))
            {
                strHeaderData = HeaderDetails(TotalClients);
                swKRADownloadFileNew.WriteLine(strHeaderData);

                foreach (Client oClient in objClients.objClients)
                {
                    StringBuilder sbBodyDetails = new StringBuilder();
                    oClient.LineNo = ++LineNo;
                    ImageDetails(oClient, KRAFolderPath);
                    sbBodyDetails.Append(DetailRecord(oClient));
                    swKRADownloadFileNew.WriteLine(sbBodyDetails.ToString());
                }

            }
            //Zip Attachted Documnets.
            CreateZipFile(KRADownloadPath, KRAFolderName, null, ref resp);
            return sDownloadPath;
        }
        #endregion Generate DP Account opening file

        #region Detail Record per KYC client
        /// <summary>
        /// Detail Record per DP Account
        /// </summary>
        /// <returns></returns>
        public string DetailRecord(Client objClient)
        {
            CKRAClientDetails objCKRAClientDetails = new CKRAClientDetails();
            StringBuilder sbKRAFileBodyDtls = new StringBuilder();
            objCKRAClientDetails.BindObject(objClient);
            objCKRAClientDetails.LineNo = objClient.LineNo.ToString();

            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.RecordType, 2, '0'));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.LineNo, 7, '0'));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.TransactionStatus, 1));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.ApplicantName, 45));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.IPVFlag, 1));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.IPVPerson, 30));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.IPVPersonDesignation, 20));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.IPVPersonOrganization, 70));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.IPVDate, 8));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.Filler1, 76));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.FatherOrHusbandName, 45));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.Gender, 1));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.MaritalStatus, 1));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.DOB, 8));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.Filler2, 83));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.PAN, 10));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.EvidenceIfPANExemption, 75));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.UID, 16));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.Status, 2,'0'));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.Filler3, 75));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.Nationality, 2,'0'));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.Nationalityother, 50));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.POI, 2, '0'));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.POIOthers, 75));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.CorrAdd1, 36));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.CorrAdd2, 36));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.CorrAdd3, 36));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.CorrCity, 36));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.CorrPINCode, 10));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.CorrState, 2, '0'));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.CorrStateOthers, 75));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.CorrCountry, 3));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.CorrPOA, 2, '0'));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.CorrPOAOthers, 75));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.CorrOffTel, 24));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.CorrResTel, 24));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.Mob, 15));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.Fax, 24));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.EmailID, 50));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.Filler4, 50));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.AddFlag, 1));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.PerAdd1, 36));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.PerAdd2, 36));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.PerAdd3, 36));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.PerCity, 36));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.PerPIN, 10));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.PerState, 2, '0'));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.PerStateOthers, 75));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.PerCountry, 3));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.PerPOA, 2,'0'));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.PerPOAOthers, 75));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.GrossAnnualIncomeRange, 2,'0'));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.NetWorth, 18));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.NetWorthAsonDate, 8));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.Filler5, 3));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.PEP, 2,'0'));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.Occupation, 2,'0'));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.OccupationDetails, 75));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.OtherInfo, 100));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.DateofDeclaration, 8));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.TrueCopiesOfDocReceivedFlag, 1));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.SelfCertifiedDocCopiesReceivedFlag, 1));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.DocumentReceivedDate, 8));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.NoOfDocsSubmitted, 2, '0'));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.SenderRefNo1, 35));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.SenderRefNo2, 35));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.ClientActivationDate, 14));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.ClientUpdationDate, 14));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.Filler6, 1));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.OldRecordFlag, 1));
            sbKRAFileBodyDtls.Append(Process.GetFixLenString(objCKRAClientDetails.Filler7, 35));

            return sbKRAFileBodyDtls.ToString();
        }
        #endregion Detail Record per KYC client

        public void ImageDetails(Client objClient, string FolderPath)
        {
            try
            {
                string[] DocExtFormats = { ".JPEG", ".TIFF", ".TIF", ".JPG", ".PNG" };
                string resp = string.Empty;
              
                int startPage = 3;
                int endPage = 35;
                string outputPdfPath = string.Empty;

                if (objClient.oClientImageDetails.ClientImgDetailList.Count > 0)
                {
                    string ImgFolderPath = ClientWiseStoreData(objClient, FolderPath);
                    if (ImgFolderPath != string.Empty)
                    {
                        var document = new Document(PageSize.LETTER.Rotate(), 0, 0, 0, 0);
                        string pdfFilePath = KRAFolderPath;
                        string PdfFileName = objClient.ClientCode.ToString() + ".pdf";
                        string sourcepath = KRAPdfPath + objClient.ClientCode + ".pdf";

                        if (File.Exists(sourcepath))
                            ExtractPages(sourcepath, ImgFolderPath + PdfFileName, startPage, endPage, objClient.PANNo);

                        //Create Clientwise zip file to store images.
                        CreateZipFile(FolderPath, objClient.PANNo.ToString(), null, ref resp);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "ImageDetails() Error while Adding  Image Details .Client no :" + objClient.ClientNo, ex);
                throw ex;
            }
        }

        #region  Clientwise Data Store Path
        public string ClientWiseStoreData(Client objClient, string FolderPath)
        {
            string ImgFolderPath = string.Empty;
            try
            {
                string sFolderName = objClient.PANNo.ToString();
                ImgFolderPath = FolderPath + sFolderName + "\\";

                FileInfo fileinfo = new FileInfo(ImgFolderPath);
                if (!fileinfo.Exists)
                    Directory.CreateDirectory(fileinfo.Directory.FullName);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "ClientWiseStoreData() Error while Adding  Clientwise Data Store Path .Client no :" + objClient.ClientNo, ex);
                throw ex;
            }
            return ImgFolderPath;
        }
        #endregion  Clientwise Data Store Path

        public void CreatePDFFile(string ImgFolderPath, string ImageName)
    {
        Document doc = new Document(PageSize.A4, 10f, 10f, 100f, 0f);
        string pdfFilePath = ImgFolderPath;      
        PdfWriter writer = PdfWriter.GetInstance(doc, new FileStream(pdfFilePath + "/Default.pdf",FileMode.OpenOrCreate));
        doc.Open();
        try
        {
            Paragraph paragraph = new Paragraph("Getting Started ITextSharp.");
            string imageURL = ImgFolderPath + ImageName;
            iTextSharp.text.Image jpg = iTextSharp.text.Image.GetInstance(imageURL);
            //Resize image depend upon your need
            jpg.ScaleToFit(140f, 120f);
            //Give space before image
            jpg.SpacingBefore = 10f;
            //Give some space after the image
            jpg.SpacingAfter = 1f;
            jpg.Alignment = Element.ALIGN_LEFT;
 
            doc.Add(paragraph);
            doc.Add(jpg);
 
        }
        catch (Exception ex)
        { }
        finally
        {
            doc.Close();
        }
    }

        #region CreateZipFile
        /// <summary>
        /// Zip Attachted Documnets.
        /// </summary>
        /// <param name="sFileToZipName"></param>
        /// <param name="sPwd"></param>
        /// <param name="sRtnMsg"></param>
        /// <param name="ClientNo"></param>
        /// <returns></returns>
        private void CreateZipFile(string sFileToZipName, string sFolderName, string sPwd, ref string sRtnMsg)
        {
            string sZipfilename = null;
            string XceedZipLic = System.Configuration.ConfigurationManager.AppSettings["XCEEDZIPLIC"];
            string DownloadAttachmentPath = sFileToZipName;

            DataTable dt = new DataTable();
            XceedZip Xfilezip;
            xcdError Xresultcode;
            try
            {
                Xfilezip = new XceedZipClass();
                sRtnMsg = string.Empty;

                //initializing xceed zip objects
                Xfilezip.CompressionLevel = xcdCompressionLevel.xclHigh;
                Xfilezip.DeleteZippedFiles = false;//true will delete signed file after zipped
                Xfilezip.ZipOpenedFiles = false;
                Xfilezip.PreservePaths = false;
                Xfilezip.RequiredFileAttributes = xcdFileAttributes.xfaNone;
                Xfilezip.ExtraHeaders = xcdExtraHeader.xehNone;
                Xfilezip.UseTempFile = false;

                if (!Xfilezip.License(XceedZipLic))
                {
                    throw new Exception("Xceed zip licence is either incorrect or expired.");
                }
                string sFolderpath = sFileToZipName + "\\" + sFolderName;
                string[] arrFileListToZip = Directory.GetFiles(sFolderpath, "*.*", SearchOption.AllDirectories);
                StringBuilder sFileList = new StringBuilder();

               

                Xfilezip.EncryptionPassword = sPwd;

                foreach (var item in arrFileListToZip)
                {
                    sFileList.Append(item + "|");
                }
                Xfilezip.FilesToProcess = sFileList.ToString().EndsWith("|") ? sFileList.ToString().Substring(0, sFileList.ToString().Length - 1) : sFileList.ToString();

                Xfilezip.ZipFilename = DownloadAttachmentPath + sFolderName + ".zip";

                if (File.Exists(Xfilezip.ZipFilename))
                { File.Delete(Xfilezip.ZipFilename); }

                Xresultcode = Xfilezip.Zip();


                if (Xresultcode == xcdError.xerSuccess)
                {
                    Directory.Delete(sFolderpath, true);
                    return;
                }
                else
                {
                    throw new Exception("Exception Error while zipping file :" + Xresultcode);
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "CreateZipFile()  Error while zipping file:- " + sFileToZipName, ex);
                throw ex;
            }
            finally
            {
                Xfilezip = null;
            }
        }
        #endregion CreateZipFile

        public void ExtractPages(string sourcePdfPath, string outputPdfPath, int startPage, int endPage, string pass)
        {
            PdfReader reader = null;
            Document sourceDocument = null;
            PdfCopy pdfCopyProvider = null;
            PdfImportedPage importedPage = null;
           
            try
            {
                // Intialize a new PdfReader instance with the contents of the source Pdf file:
                reader = new PdfReader(sourcePdfPath,new System.Text.ASCIIEncoding().GetBytes(pass));
                PdfReader.unethicalreading = true;
                // For simplicity, I am assuming all the pages share the same size
                // and rotation as the first page:
                sourceDocument = new Document(reader.GetPageSizeWithRotation(startPage));

                // Initialize an instance of the PdfCopyClass with the source 
                // document and an output file stream:
                pdfCopyProvider = new PdfCopy(sourceDocument,
                    new System.IO.FileStream(outputPdfPath, System.IO.FileMode.Create,FileAccess.Write));

                sourceDocument.Open();

                // Walk the specified range and add the page copies to the output file:
                for (int i = startPage; i <= endPage; i++)
                {
                    if (i == 3 || i == 29 || i == 30)
                    {
                        importedPage = pdfCopyProvider.GetImportedPage(reader, i);
                        pdfCopyProvider.AddPage(importedPage);
                    }
                }
                sourceDocument.Close();
                reader.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion Methods
    }
}
