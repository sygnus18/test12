﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTIL.Match.CDD.BAL.DataClasses.KRAFileDownload
{
    public class CKRAHeaderDetails
    {
        public string RecordType { get; set; }
        public string BatchNo { get; set; }
        public string BranchCode { get; set; }
        public string IntermediaryID { get; set; }
        public int IntermediaryRole { get; set; }
        public int TotalRecords { get; set; }
        public string SenderDate { get; set; }
        public string UserId { get; set; }
        public string FileFormatVersion { get; set; }
        public string Filler { get; set; }

        public CKRAHeaderDetails()
        {
        }

    }
}
