﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FTIL.Match.CDD.BAL.DataStore;

namespace FTIL.Match.CDD.BAL.DataClasses.KRAFileDownload
{
    public class CKRAClientDetails
    {
        #region properties
        public string RecordType { get; set; }
        public string LineNo { get; set; }
        public string TransactionStatus { get; set; }
        public string ApplicantName { get; set; }
        public string IPVFlag { get; set; }
        public string IPVPerson { get; set; }
        public string IPVPersonDesignation { get; set; }
        public string IPVPersonOrganization { get; set; }
        public string IPVDate { get; set; }
        public string Filler1 { get; set; }
        public string FatherOrHusbandName { get; set; }
        public string Gender { get; set; }
        public string MaritalStatus { get; set; }
        public string DOB { get; set; }
        public string Filler2 { get; set; }
        public string PAN { get; set; }
        public string EvidenceIfPANExemption { get; set; }
        public string UID { get; set; }
        public string Status { get; set; }
        public string Filler3 { get; set; }
        public string Nationality { get; set; }
        public string Nationalityother { get; set; }
        public string POI { get; set; }
        public string POIOthers { get; set; }
        public string CorrAdd1 { get; set; }
        public string CorrAdd2 { get; set; }
        public string CorrAdd3 { get; set; }
        public string CorrCity { get; set; }
        public string CorrPINCode { get; set; }
        public string CorrState { get; set; }
        public string CorrStateOthers { get; set; }
        public string CorrCountry { get; set; }
        public string CorrPOA { get; set; }
        public string CorrPOAOthers { get; set; }
        public string CorrOffTel { get; set; }
        public string CorrResTel { get; set; }
        public string Mob { get; set; }
        public string Fax { get; set; }
        public string EmailID { get; set; }
        public string Filler4 { get; set; }
        public string AddFlag { get; set; }
        public string PerAdd1 { get; set; }
        public string PerAdd2 { get; set; }
        public string PerAdd3 { get; set; }
        public string PerCity { get; set; }
        public string PerPIN { get; set; }
        public string PerState { get; set; }
        public string PerStateOthers { get; set; }
        public string PerCountry { get; set; }
        public string PerPOA { get; set; }
        public string PerPOAOthers { get; set; }
        public string GrossAnnualIncomeRange { get; set; }
        public string NetWorth { get; set; }
        public string NetWorthAsonDate { get; set; }
        public string Filler5 { get; set; }
        public string PEP { get; set; }
        public string Occupation { get; set; }
        public string OccupationDetails { get; set; }
        public string OtherInfo { get; set; }
        public string DateofDeclaration { get; set; }
        public string TrueCopiesOfDocReceivedFlag { get; set; }
        public string SelfCertifiedDocCopiesReceivedFlag { get; set; }
        public string DocumentReceivedDate { get; set; }
        public string NoOfDocsSubmitted { get; set; }
        public string SenderRefNo1 { get; set; }
        public string SenderRefNo2 { get; set; }
        public string ClientActivationDate { get; set; }
        public string ClientUpdationDate { get; set; }
        public string Filler6 { get; set; }
        public string OldRecordFlag { get; set; }
        public string Filler7 { get; set; }
        #endregion properties

        #region constructor
        public CKRAClientDetails()
        {
        }
        #endregion constructor

        #region Methods
        public void BindObject(Client objClient)
        {
            ClientAddress objPerAddress = new ClientAddress();
            ClientAddress objCorrAddress = new ClientAddress();

            objPerAddress = objClient.oClientAddresses.GetAddressByType(Client_AddressType.Registered);//for permanat address
            objCorrAddress = objClient.oClientAddresses.GetAddressByType(Client_AddressType.Correspondence);//for Correspondant address

            int[] arrRelationShipNo = { 98, 99, 100, 0, 201, 202, 203 };

            RecordType = NDMLRecordType.ConstNDMLIndividualDetail;
            TransactionStatus = CNDMLDataProvider.TransactionStatus;
            ApplicantName = objClient.ClientName + " " + objClient.MiddleName + " " + objClient.LastName;
            if (objClient.ClientName.Length > 45)
                ApplicantName = ApplicantName.Substring(0, 45);
            FatherOrHusbandName = objClient.GuardianName;
            Gender = objClient.Gender;//Commented
            MaritalStatus = objClient.MaritalStatus;//Commented
            if (objClient.DOB.HasValue)
                DOB = objClient.DOB.Value.ToString("yyyyMMdd");
            PAN = objClient.PANNo.ToString();
            UID = objClient.UID;
            Status = ((int)KRAFileTypeEnum.INDIVIDUAL).ToString();//01 for resident individual
            Nationality = objClient.Nationality.ToString();
            Nationalityother = objClient.NationalityOther;
            POI = CNDMLDataProvider.POI;
  
            if (objPerAddress != null)
            {
                if (objPerAddress.SameCorrPermAdd == "Y")
                {
                    AddFlag = "Y";
                    if (objPerAddress.AddressLine1.Length > 36)
                        objPerAddress.AddressLine1 = objPerAddress.AddressLine1.Substring(0, 36);
                    CorrAdd1 =   Process.RemoveSpecialCharFromString(objPerAddress.AddressLine1);
                    if (objPerAddress.AddressLine2.Length > 36)
                        objPerAddress.AddressLine2 = objPerAddress.AddressLine2.Substring(0, 36);
                    CorrAdd2 =   Process.RemoveSpecialCharFromString(objPerAddress.AddressLine2);
                    if (objPerAddress.AddressLine3.Length > 36)
                        objPerAddress.AddressLine3 = objPerAddress.AddressLine3.Substring(0, 36);
                    CorrAdd3 =   Process.RemoveSpecialCharFromString(objPerAddress.AddressLine3);
                    CorrPINCode = objPerAddress.PinCode;
                    CorrResTel = objPerAddress.TelNo1;//Commented
                    CorrCity = objPerAddress.City;
                    CorrState = objPerAddress.StateNumber.ToString();//Commented
                    CorrStateOthers = objPerAddress.StateOther;//Commented
                    CorrCountry = objPerAddress.CountryCode.ToString();
                    //CorrOffTel = objPerAddress.TelNoOffice;

                    if (objClient.oClientProofDetails.ProofDetailsList.Count > 0)
                    {
                        foreach (ClientProofDetail objClientProofDetail in objClient.oClientProofDetails.ProofDetailsList)
                        {
                            if (objClientProofDetail.ReferenceSubType == CKYCProof.PROOFADD.ToString())
                            {
                                CorrPOA = CNDMLDataProvider.GetPerProofOfAdd(objClientProofDetail.ProofType);
                                //PerPOAOthers
                            }
                            //if (objClientProofDetail.ReferenceSubType == CKYCProof.PROOFCOADD.ToString())
                            //{
                            //    CorrPOA = CNDMLDataProvider.GetCorrProofOfAdd(objClientProofDetail.ProofType);
                            //    //CorrPOAOthers
                            //}
                        }
                    }

                    if (objPerAddress.AddressLine1.Length > 36)
                        objPerAddress.AddressLine1 = objPerAddress.AddressLine1.Substring(0, 36);
                    PerAdd1 =   Process.RemoveSpecialCharFromString(objPerAddress.AddressLine1);
                    if (objPerAddress.AddressLine2.Length > 36)
                        objPerAddress.AddressLine2 = objPerAddress.AddressLine2.Substring(0, 36);
                    PerAdd2 =   Process.RemoveSpecialCharFromString(objPerAddress.AddressLine2);
                    if (objPerAddress.AddressLine3.Length > 36)
                        objPerAddress.AddressLine3 = objPerAddress.AddressLine3.Substring(0, 36);
                    PerAdd3 =  Process.RemoveSpecialCharFromString( objPerAddress.AddressLine3);
                    PerPIN = objPerAddress.PinCode;
                    PerCity = objPerAddress.City;
                    PerState = objPerAddress.StateNumber.ToString();//Commented
                    PerStateOthers = objPerAddress.StateOther;//Commented
                    PerCountry = objPerAddress.CountryCode.ToString();
                }
                else
                {
                    AddFlag = "N";
                    if (objPerAddress.AddressLine1.Length > 36)
                        objPerAddress.AddressLine1 = objPerAddress.AddressLine1.Substring(0, 36);
                    PerAdd1 =   Process.RemoveSpecialCharFromString(objPerAddress.AddressLine1);
                    if (objPerAddress.AddressLine2.Length > 36)
                        objPerAddress.AddressLine2 = objPerAddress.AddressLine2.Substring(0, 36);
                    PerAdd2 =   Process.RemoveSpecialCharFromString(objPerAddress.AddressLine2);
                    if (objPerAddress.AddressLine3.Length > 36)
                        objPerAddress.AddressLine3 = objPerAddress.AddressLine3.Substring(0, 36);
                    PerAdd3 =   Process.RemoveSpecialCharFromString(objPerAddress.AddressLine3);
                    PerPIN = objPerAddress.PinCode;
                    PerCity = objPerAddress.City;
                    PerState = objPerAddress.StateNumber.ToString();//Commented
                    PerStateOthers = objPerAddress.StateOther;//Commented
                    PerCountry = objPerAddress.CountryCode.ToString();
                }
                Mob = objPerAddress.Mobile1.ToString();
                Fax = objPerAddress.FaxNo.ToString();
                EmailID = objPerAddress.EMailId;
            }

            if (objCorrAddress != null)
            {
                AddFlag = "N";
                if (objCorrAddress.AddressLine1.Length > 36)
                    objCorrAddress.AddressLine1 = objCorrAddress.AddressLine1.Substring(0, 36);
                CorrAdd1 =   Process.RemoveSpecialCharFromString(objCorrAddress.AddressLine1);
                if (objCorrAddress.AddressLine2.Length > 36)
                    objCorrAddress.AddressLine2 = objCorrAddress.AddressLine2.Substring(0, 36);
                CorrAdd2 =   Process.RemoveSpecialCharFromString(objCorrAddress.AddressLine2);
                if (objCorrAddress.AddressLine3.Length > 36)
                    objCorrAddress.AddressLine3 = objCorrAddress.AddressLine3.Substring(0, 36);
                CorrAdd3 =   Process.RemoveSpecialCharFromString(objCorrAddress.AddressLine3);
                CorrPINCode = objCorrAddress.PinCode;
                //CorrResTel = objCorrAddress.TelNo1;//Commented
                CorrCity = objCorrAddress.City;
                CorrState = objCorrAddress.StateNumber.ToString();//Commented
                CorrStateOthers = objCorrAddress.StateOther;//Commented
                CorrCountry = objCorrAddress.CountryCode.ToString();
                //CorrOffTel = objCorrAddress.TelNoOffice;
                
                if (objClient.oClientProofDetails.ProofDetailsList.Count > 0)
                {
                    foreach (ClientProofDetail objClientProofDetail in objClient.oClientProofDetails.ProofDetailsList)
                    {
                        //if (objClientProofDetail.ReferenceSubType == CKYCProof.PROOFADD.ToString())
                        //{
                        //    CorrPOA = CNDMLDataProvider.GetPerProofOfAdd(objClientProofDetail.ProofType);
                        //    //PerPOAOthers
                        //}
                        if (objClientProofDetail.ReferenceSubType == CKYCProof.PROOFCOADD.ToString())
                        {
                            CorrPOA = CNDMLDataProvider.GetCorrProofOfAdd(objClientProofDetail.ProofType);
                            //CorrPOAOthers
                        }
                    }
                }
            }
            GrossAnnualIncomeRange = objClient.GrAnnIncRange.ToString();
            NetWorth = objClient.NetWorth.ToString();//Commented
            if (objClient.NetWorthAsOnDate.HasValue)//Commented
                NetWorthAsonDate = objClient.NetWorthAsOnDate.Value.ToString("yyyyMMdd");//Commented
            PEP = objClient.PEP.ToString();
            Occupation = CNDMLDataProvider.GetOccupationType(objClient.Occupation);
            OccupationDetails = objClient.OccupationOthers;
            DateofDeclaration = objClient.AuthorizeDatetime.ToString("yyyyMMdd");//Commented

            TrueCopiesOfDocReceivedFlag="Y";
            SelfCertifiedDocCopiesReceivedFlag = "Y";


            if (objClient.oClientProofDetails.ProofDetailsList.Count > 0)
            {
                foreach (ClientProofDetail objClientProofDetail in objClient.oClientProofDetails.ProofDetailsList)
                {
                    if (objClientProofDetail.ReferenceSubType == CKYCProof.PROOFADD.ToString())
                    {
                        PerPOA = CNDMLDataProvider.GetPerProofOfAdd(objClientProofDetail.ProofType);
                        //PerPOAOthers
                    }
                    //if (objClientProofDetail.ReferenceSubType == CKYCProof.PROOFCOADD.ToString())
                    //{
                    //    CorrPOA = CNDMLDataProvider.GetCorrProofOfAdd(objClientProofDetail.ProofType);
                    //    //CorrPOAOthers
                    //}
                }
            }

            //IPVFlag
            //IPVPerson
            //IPVPersonDesignation
            //IPVPersonOrganization
            //IPVDate
            //EvidenceIfPANExemption
            //OtherInfo
            //DocumentReceivedDate
            //NoOfDocsSubmitted
            //SenderRefNo1
            //SenderRefNo2
            //ClientActivationDate 
            //ClientUpdationDate 
            //OldRecordFlag
            //Filler1
            //Filler2
            //Filler3
            //Filler4
            //Filler5
            //Filler6
            //Filler7

        }
        #endregion Methods
    }
}
