﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTIL.Match.CDD.BAL.DataClasses.KRAFileDownload
{

    /// <summary>
    /// KRA Agency Enums
    /// </summary>
    public enum KRAAgencyEnum
    {
        CAMS = 1,
        CVL = 2,
        DOTEX = 3,
        KARVY = 4,
        NDML = 5
    }

    /// <summary>
    /// KRA FileType Enums
    /// </summary>
    public enum KRAFileTypeEnum
    {
        INDIVIDUAL = 1,
        NON_INDIVIDUAL = 2,
        DEFAULT = -1
    }

    /// <summary>
    /// Client Type
    /// </summary>
    public struct ClientType
    {
        public static readonly char INDIVIDUAL = 'I';
        public static readonly char NON_INDIVIDUAL = 'N';
    }

    /// <summary>
    ///NDML Record Type 
    /// </summary>
    public struct NDMLRecordType
    {
        public static readonly string ConstNDMLIndividualHeader = "01";
        public static readonly string ConstNDMLIndividualDetail = "02";
        public static readonly string ConstNDMLNonIndividualHeader = "03";
        public static readonly string ConstNDMLNonIndividualDetail = "04";
        public static readonly string ConstNDMLPromoterDetail = "05";
        public static readonly string ConstNDMLIndexHeader = "06";
        public static readonly string ConstNDMLIndexDetail = "07";
    }

    public static class CNDMLDataProvider
    {
        public static string BranchCode = "0000";
        public static string IntermediaryID = "P2638";//for YES BANK
        public static int IntermediaryRole = 1;
        public static string TransactionStatus = "A";
        public static string FileFormatVersion = "99";
        public static string POI = "05";




        #region Get Occupation by Type
        static Dictionary<int?, int> l_dictOccupation = new Dictionary<int?, int>
        {
            {1 ,1},	//Public Sector
            {2 ,2},    //Private Sector
            {3 ,3},    //Government Service
            {4 ,4},    //Business
            {5 ,5},    //Professional
            {6 ,6},    //Agriculture
            {7 ,7},    //Retired
            {8 ,8},    //Housewife
            {9 ,9},    //Student
            {99,99},	//Others
            {10,99}	    //self
        };
        public static string GetOccupationType(int? Occupation)
        {
            int OccupationType;
            l_dictOccupation.TryGetValue(Occupation, out OccupationType);
            return OccupationType.ToString();
        }
        #endregion Get Occupation by Type


        #region Get per proof of add
        static Dictionary<int, int> l_dictPerAddProof = new Dictionary<int, int>
        {
            {7,26},	    //UID
            {2,01},	    //Passport
            {25,02},	//Voters Identity Card
            {5,03},	    //Ration Card
            {26,05},	//Driving License
            {13,08},	//Utility bills like Telephone Bill (land line), Electricity bill or Gas bill
            {24,09}	    //Bank Account Statement/Passbook
            //{,04},	//Registered Lease or Sale Agreement of Residence
            //{,06},	//Flat Maintenance bill
            //{,07},	//Insurance Copy
            //{,10},	//Self-declaration by High Court and Supreme Court judges
            //{,11},	//Proof of address issued by Bank Managers of Scheduled Commercial / Scheduled Co-Operative / Multinational Foreign Banks
            //{,12},	//Proof of address issued by Gazetted Officer
            //{,13},	//Proof of address issued by Notary public
            //{,14},	//Proof of address issued by Elected representatives to the Legislative Assembly
            //{,15},	//Proof of address issued by Parliament
            //{,16},	//Proof of address issued by any Govt. or Statutory Authority
            //{,17},	//ID Card with address issued by Central / State Govt
            //{,18},	//ID Card with address issued by Statutory/Regulatory Authorities
            //{,19},	//ID Card with address issued by Public Sector Undertakings
            //{,20},	//ID Card with address issued by Scheduled Commercial Banks
            //{,21},	//ID Card with address issued by Public Financial Institutions
            //{,22},	//ID Card with address issued by Colleges affiliated to Universities
            //{,23},	//ID Card with address issued by Professional Bodies such as ICAI, ICWAI, ICSI, Bar Council etc., to their Members
            //{,24},	//Power Of Attorney given by FII/sub-account to Custodian (duly notarized and/or apostiled or consularised) giving registered address
            //{,25},	//Proof of address in the name of the spouse
        };

        public static string GetPerProofOfAdd(int PerAddCode)
        {
            int AddProof;
            l_dictPerAddProof.TryGetValue(PerAddCode, out AddProof);
            return AddProof.ToString();
        }
        #endregion Get per proof of add



        #region Get Corr proof of add
        static Dictionary<int, int> l_dictCorrAddProof = new Dictionary<int, int>
        {
            {38,26},	//UID
            {36,01},	//Passport
            {41,02},	//Voters Identity Card
            {37,03},	//Ration Card
            {42,05},	//Driving License
            {39,08},	//Utility bills like Telephone Bill (land line), Electricity bill or Gas bill
            {40,09} 	//Bank Account Statement/Passbook
            //{,04},	//Registered Lease or Sale Agreement of Residence
            //{,06},	//Flat Maintenance bill
            //{,07},	//Insurance Copy
            //{,10},	//Self-declaration by High Court and Supreme Court judges
            //{,11},	//Proof of address issued by Bank Managers of Scheduled Commercial / Scheduled Co-Operative / Multinational Foreign Banks
            //{,12},	//Proof of address issued by Gazetted Officer
            //{,13},	//Proof of address issued by Notary public
            //{,14},	//Proof of address issued by Elected representatives to the Legislative Assembly
            //{,15},	//Proof of address issued by Parliament
            //{,16},	//Proof of address issued by any Govt. or Statutory Authority
            //{,17},	//ID Card with address issued by Central / State Govt
            //{,18},	//ID Card with address issued by Statutory/Regulatory Authorities
            //{,19},	//ID Card with address issued by Public Sector Undertakings
            //{,20},	//ID Card with address issued by Scheduled Commercial Banks
            //{,21},	//ID Card with address issued by Public Financial Institutions
            //{,22},	//ID Card with address issued by Colleges affiliated to Universities
            //{,23},	//ID Card with address issued by Professional Bodies such as ICAI, ICWAI, ICSI, Bar Council etc., to their Members
            //{,24},	//Power Of Attorney given by FII/sub-account to Custodian (duly notarized and/or apostiled or consularised) giving registered address
            //{,25},	//Proof of address in the name of the spouse
        };
       

        public static string GetCorrProofOfAdd(int CorrAddCode)
        {
            int AddProof;
            l_dictCorrAddProof.TryGetValue(CorrAddCode, out AddProof);
            return AddProof.ToString();
        }
        #endregion Get Corr proof of add

          
    }

    static class KRAData
    {
       
    }
}
