﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;

namespace FTIL.Match.CDD.BAL
{
    public class COTPAuth
    {
        static COTPAuth()
        {
            //FTIL.UM.Common.Base.ConnectionManager.SetDbManagerConnectionString("");
        }
        public MethodExecResult UpdateOTP(string s_Name, string s_Email, string s_MobileNo, string s_PANNo, string s_DOB, string s_OTP, string s_Mode)
        {
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_KYC_OTPAuth");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@Ps_Mode", SqlDbType.VarChar, "U");
                objdbwork.AddParameter("@Ps_Type", SqlDbType.VarChar, s_Mode);
                objdbwork.AddParameter("@Ps_Name", SqlDbType.VarChar, s_Name);
                objdbwork.AddParameter("@Ps_Email", SqlDbType.VarChar, s_Email);
                objdbwork.AddParameter("@Ps_MobileNo", SqlDbType.VarChar, s_MobileNo);
                objdbwork.AddParameter("@Ps_PANNo", SqlDbType.VarChar, s_PANNo);
                objdbwork.AddParameter("@Ps_DOB", SqlDbType.VarChar, s_DOB);
                objdbwork.AddParameter("@Ps_OTP", SqlDbType.VarChar, s_OTP);
                
                DbManager.Instance.ExecuteDbTask(objdbwork);
                return objdbwork.ExecutionStatus;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(COTPAuth), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }
        }

        public string[] AuthorizeOTP(string s_Name, string s_Email, string s_MobileNo, string s_PANNo, string s_DOB, string s_OTP, string Mode,string operationType, string ClientCodeType)
        {
            string[] Result = new string[2];
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_KYC_OTPAuth");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@Ps_Mode", SqlDbType.VarChar, operationType);
                objdbwork.AddParameter("@Ps_Type", SqlDbType.VarChar, Mode);
                objdbwork.AddParameter("@Ps_Name", SqlDbType.VarChar, s_Name);
                objdbwork.AddParameter("@Ps_Email", SqlDbType.VarChar, s_Email);
                objdbwork.AddParameter("@Ps_MobileNo", SqlDbType.VarChar, s_MobileNo);
                objdbwork.AddParameter("@Ps_PANNo", SqlDbType.VarChar, s_PANNo);
                objdbwork.AddParameter("@Ps_DOB", SqlDbType.VarChar, s_DOB);
                objdbwork.AddParameter("@Ps_OTP", SqlDbType.VarChar, s_OTP);
                objdbwork.AddParameter("@Ps_ClientCodeType", SqlDbType.VarChar, ClientCodeType);

                SqlParameter outparam = new SqlParameter();
                outparam.ParameterName = "Ps_ErrorMessage";
                outparam.SqlDbType = SqlDbType.VarChar;
                outparam.Size = 100;
                outparam.Direction = ParameterDirection.Output;

                objdbwork.AddParameter(outparam);

                SqlParameter UserIdoutparam = new SqlParameter();
                UserIdoutparam.ParameterName = "Ps_UserId";
                UserIdoutparam.SqlDbType = SqlDbType.VarChar;
                UserIdoutparam.Size = 20;
                UserIdoutparam.Direction = ParameterDirection.Output;

                objdbwork.AddParameter(UserIdoutparam);               

                DbManager.Instance.ExecuteDbTask(objdbwork);

                Result[0] = outparam.Value.ToString();
                Result[1] = UserIdoutparam.Value.ToString();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(COTPAuth), ex.Message);
                Result[0] = ex.Message.ToString();
            }
            return Result;
        }

        public string AuthorizeAppKey(string ApplicationKey)
        {
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_KYC_AuthAppKey");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@Ps_AppKey", SqlDbType.VarChar, ApplicationKey);
                
                SqlParameter outparam = new SqlParameter();
                outparam.ParameterName = "Ps_OutMessage";
                outparam.SqlDbType = SqlDbType.VarChar;
                outparam.Size = 100;
                outparam.Direction = ParameterDirection.Output;

                objdbwork.AddParameter(outparam);

                DbManager.Instance.ExecuteDbTask(objdbwork);
                return outparam.Value.ToString();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(COTPAuth), ex.Message);
                return ex.Message;
            }
        }


        public string[] AuthorizeOTP(string s_Name, string s_Email, string s_MobileNo, string s_PANNo, string s_DOB, string s_OTP, string Mode, string operationType, string ClientCodeType, string s_FirstName, string s_MiddleName, string s_LastName)
        {
            string[] Result = new string[2];
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_KYC_OTPAuth");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@Ps_Mode", SqlDbType.VarChar, operationType);
                objdbwork.AddParameter("@Ps_Type", SqlDbType.VarChar, Mode);
                objdbwork.AddParameter("@Ps_Name", SqlDbType.VarChar, s_Name);
                objdbwork.AddParameter("@Ps_Email", SqlDbType.VarChar, s_Email);
                objdbwork.AddParameter("@Ps_MobileNo", SqlDbType.VarChar, s_MobileNo);
                objdbwork.AddParameter("@Ps_PANNo", SqlDbType.VarChar, s_PANNo);
                objdbwork.AddParameter("@Ps_DOB", SqlDbType.VarChar, s_DOB);
                objdbwork.AddParameter("@Ps_OTP", SqlDbType.VarChar, s_OTP);
                objdbwork.AddParameter("@Ps_ClientCodeType", SqlDbType.VarChar, ClientCodeType);
                objdbwork.AddParameter("@Ps_FirstName", SqlDbType.VarChar, s_FirstName);
                objdbwork.AddParameter("@Ps_MiddleName", SqlDbType.VarChar, s_MiddleName);
                objdbwork.AddParameter("@Ps_LastName", SqlDbType.VarChar, s_LastName);

                SqlParameter outparam = new SqlParameter();
                outparam.ParameterName = "Ps_ErrorMessage";
                outparam.SqlDbType = SqlDbType.VarChar;
                outparam.Size = 100;
                outparam.Direction = ParameterDirection.Output;

                objdbwork.AddParameter(outparam);

                SqlParameter UserIdoutparam = new SqlParameter();
                UserIdoutparam.ParameterName = "Ps_UserId";
                UserIdoutparam.SqlDbType = SqlDbType.VarChar;
                UserIdoutparam.Size = 20;
                UserIdoutparam.Direction = ParameterDirection.Output;

                objdbwork.AddParameter(UserIdoutparam);

                DbManager.Instance.ExecuteDbTask(objdbwork);

                Result[0] = outparam.Value.ToString();
                Result[1] = UserIdoutparam.Value.ToString();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(COTPAuth), ex.Message);
                Result[0] = ex.Message.ToString();
            }
            return Result;
        }
    }
}
