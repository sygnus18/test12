﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FTIL.Match.Common.Db;
using System.Data.SqlClient;
using System.Data;
using FTIL.Match.Common.Log; 
using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.CDD.BAL;
using FTIL.Match.Common; 


namespace FTIL.Match.CDD.BAL
{
    public class CUserRegistration
    {

       static CUserRegistration()
        {
            string sconstr = string.Empty; 
        }


       public DataSet RegisterUser(string ApplicationKey,string Name, string Mobile, string Email, string Pass, string Panno, string Capcha, string dob,string ipAdress)
        {
            DbWorkItem objdbwork = null;
            DataSet res = new DataSet();
            try
            {
                objdbwork = new DbWorkItem("stp_KYC_RegisterUser");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@Ps_Name", SqlDbType.VarChar, Name);
                objdbwork.AddParameter("@Ps_MobileNo", SqlDbType.VarChar, Mobile);
                objdbwork.AddParameter("@Ps_Email", SqlDbType.VarChar, Email);
                objdbwork.AddParameter("@Ps_Password", SqlDbType.VarChar, Pass);
                //objdbwork.AddParameter("@Ps_SecurityQueNo", SqlDbType.Int, SecurityQueNo);
                //objdbwork.AddParameter("@Ps_SecurityAns", SqlDbType.VarChar, SecurityAns);
                objdbwork.AddParameter("@Ps_PANNo", SqlDbType.VarChar, Panno);
                objdbwork.AddParameter("@Ps_DOB", SqlDbType.VarChar, dob);
                objdbwork.AddParameter("@Ps_IpAddress", SqlDbType.VarChar, ipAdress);



                SqlParameter outParamErrNo = new SqlParameter();
                outParamErrNo.ParameterName = "@Ps_ErrorCode";
                outParamErrNo.SqlDbType = SqlDbType.Int;
                outParamErrNo.Size = 8;
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outparam = new SqlParameter();
                outparam.ParameterName = "@Ps_ErrorMessage";
                outparam.SqlDbType = SqlDbType.VarChar;
                outparam.Size = 100;
                outparam.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outparam);


                DbManager.Instance.ExecuteDbTask(objdbwork);
                res.Tables.Add(createStatusTable((string)objdbwork.parameters[objdbwork.parameters.Count - 2].Value.ToString(), (string)objdbwork.parameters[objdbwork.parameters.Count - 1].Value.ToString()));
                res.Tables[0].TableName = "Status";

                int errCode = (int)objdbwork.parameters[objdbwork.parameters.Count - 2].Value;
                if (errCode == 0 || errCode == 1)
                {
                    //res[1] = ((DataSet)objdbwork.Result).Tables[0];

                    res.Tables.Add(((DataSet)objdbwork.Result).Tables[0].Copy());


                }
                else
                {
                    //res[1] = new DataTable();
                    res.Tables.Add(new DataTable());
                }
                res.Tables[1].TableName = "D1";

                return res;
                //return outparam.Value.ToString();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
                return res;
            }
        }

       public DataSet CheckClientDetails( string Panno)
       {
           DbWorkItem objdbwork = null;
           DataSet res = new DataSet();
           try
           {
               objdbwork = new DbWorkItem("stp_KYC_CheckClientDetails");
               objdbwork.ResultType = QueryType.DataSet;
               objdbwork.AddParameter("@Ps_PANNo", SqlDbType.VarChar, Panno);

               SqlParameter outParamErrNo = new SqlParameter();
               outParamErrNo.ParameterName = "@Ps_ErrorCode";
               outParamErrNo.SqlDbType = SqlDbType.Int;
               outParamErrNo.Size = 8;
               outParamErrNo.Direction = ParameterDirection.Output;
               objdbwork.AddParameter(outParamErrNo);

               SqlParameter outparam = new SqlParameter();
               outparam.ParameterName = "@Ps_ErrorMessage";
               outparam.SqlDbType = SqlDbType.VarChar;
               outparam.Size = 100;
               outparam.Direction = ParameterDirection.Output;
               objdbwork.AddParameter(outparam);


               DbManager.Instance.ExecuteDbTask(objdbwork);
               res.Tables.Add(createStatusTable((string)objdbwork.parameters[objdbwork.parameters.Count - 2].Value.ToString(), (string)objdbwork.parameters[objdbwork.parameters.Count - 1].Value.ToString()));
               res.Tables[0].TableName = "Status";

               int errCode = (int)objdbwork.parameters[objdbwork.parameters.Count - 2].Value;
               if (errCode == 0 || errCode == 1)
               {
                   //res[1] = ((DataSet)objdbwork.Result).Tables[0];

                   res.Tables.Add(((DataSet)objdbwork.Result).Tables[0].Copy());


               }
               else
               {
                   //res[1] = new DataTable();
                   res.Tables.Add(new DataTable());
               }
               res.Tables[1].TableName = "D1";

               return res;
               //return outparam.Value.ToString();
           }
           catch (Exception ex)
           {
               Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
               return res;
           }
       }

       public DataSet RegisterRM(string n_RMID, int n_ClientNo, string s_Brach, string s_SubBroker, string s_ClientCode)
       {
           DbWorkItem objdbwork = null;
           DataSet res = new DataSet();
           try
           {
               objdbwork = new DbWorkItem("stp_KYC_RMDetails");
               objdbwork.ResultType = QueryType.DataSet;
               //objdbwork.AddParameter("@Ps_Email", SqlDbType.VarChar, s_Email);
               //objdbwork.AddParameter("@Ps_Name", SqlDbType.VarChar, s_Name);
               //objdbwork.AddParameter("@Ps_PAN", SqlDbType.VarChar, s_PAN);
               //objdbwork.AddParameter("@Pn_Mobile", SqlDbType.Int, n_Mobile);
               //objdbwork.AddParameter("@Ps_SecurityQueNo", SqlDbType.Int, SecurityQueNo);
               //objdbwork.AddParameter("@Ps_SecurityAns", SqlDbType.VarChar, SecurityAns);
               objdbwork.AddParameter("@Pn_RMID", SqlDbType.VarChar, n_RMID);
               objdbwork.AddParameter("@pn_ClientNo", SqlDbType.Int, n_ClientNo);
               objdbwork.AddParameter("@Ps_Brach", SqlDbType.VarChar, s_Brach);
               objdbwork.AddParameter("@Ps_SubBroker", SqlDbType.VarChar, s_SubBroker);
               objdbwork.AddParameter("@Ps_ClientCode", SqlDbType.VarChar, s_ClientCode);

               DbManager.Instance.ExecuteDbTask(objdbwork);
               //res.Tables.Add(createStatusTable((string)objdbwork.parameters[objdbwork.parameters.Count - 2].Value.ToString(), (string)objdbwork.parameters[objdbwork.parameters.Count - 1].Value.ToString()));
               //res.Tables[0].TableName = "Status";

               //int errCode = (int)objdbwork.parameters[objdbwork.parameters.Count - 2].Value;
               //if (errCode == 0 || errCode == 1)
               //{
               //    //res[1] = ((DataSet)objdbwork.Result).Tables[0];

                   res.Tables.Add(((DataSet)objdbwork.Result).Tables[0].Copy());


               //}
               //else
               //{
               //    //res[1] = new DataTable();
               //    res.Tables.Add(new DataTable());
               //}
               res.Tables[0].TableName = "Status";

               return res;
               //return outparam.Value.ToString();
           }
           catch (Exception ex)
           {
               Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
               return res;
           }
       }

       public DataSet AddToken(string s_Token, string s_RMID,string s_MODE)
       {
           DbWorkItem objdbwork = null;
           DataSet res = new DataSet();
           try
           {
               objdbwork = new DbWorkItem("stp_KYC_TokenDetails");
               objdbwork.ResultType = QueryType.DataSet;
               objdbwork.AddParameter("@Ps_Token", SqlDbType.VarChar, s_Token);
               objdbwork.AddParameter("@Pn_RMID", SqlDbType.VarChar, s_RMID);
               objdbwork.AddParameter("@Pc_Mode", SqlDbType.Char, s_MODE);
              
               //objdbwork.AddParameter("@Ps_SecurityQueNo", SqlDbType.Int, SecurityQueNo);
               //objdbwork.AddParameter("@Ps_SecurityAns", SqlDbType.VarChar, SecurityAns);
           

               DbManager.Instance.ExecuteDbTask(objdbwork);
               //res.Tables.Add(createStatusTable((string)objdbwork.parameters[objdbwork.parameters.Count - 2].Value.ToString(), (string)objdbwork.parameters[objdbwork.parameters.Count - 1].Value.ToString()));
               //res.Tables[0].TableName = "Status";

               //int errCode = (int)objdbwork.parameters[objdbwork.parameters.Count - 2].Value;
               //if (errCode == 0 || errCode == 1)
               //{
               //    //res[1] = ((DataSet)objdbwork.Result).Tables[0];

               res.Tables.Add(((DataSet)objdbwork.Result).Tables[0].Copy());
               res.Tables[0].TableName = "Result";

               res.Tables.Add(((DataSet)objdbwork.Result).Tables[1].Copy());
               res.Tables[1].TableName = "Status";
               
               //}
               //else
               //{
               //    //res[1] = new DataTable();
               //    res.Tables.Add(new DataTable());
               //}
              

               return res;
               //return outparam.Value.ToString();
           }
           catch (Exception ex)
           {
               Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
               return res;
           }
       }


       public DataSet Login(string ApplicationKey, string Email, string Pass, string Panno, string userType, string IpAddress, string RmName, string s_CallType)
       {    
           DbWorkItem objdbwork = null;
           DataSet res = new DataSet();
           DataTable dt = new DataTable();
           try
           {
               objdbwork = new DbWorkItem("stp_KYC_LoginUser");
               objdbwork.ResultType = QueryType.DataSet;
               objdbwork.AddParameter("@Ps_Email", SqlDbType.VarChar, Email);
               objdbwork.AddParameter("@Ps_Password", SqlDbType.VarChar, Pass);
               objdbwork.AddParameter("@Ps_PANNo", SqlDbType.VarChar, Panno);
               objdbwork.AddParameter("@Ps_UserType", SqlDbType.VarChar, userType);
               objdbwork.AddParameter("@Ps_IpAddress", SqlDbType.VarChar, IpAddress);
               objdbwork.AddParameter("@Ps_RmName", SqlDbType.VarChar, RmName);


               SqlParameter outParamErrNo = new SqlParameter();
               outParamErrNo.ParameterName = "@Ps_ErrorCode";
               outParamErrNo.SqlDbType = SqlDbType.Int;
               outParamErrNo.Size = 8;
               outParamErrNo.Direction = ParameterDirection.Output;
               objdbwork.AddParameter(outParamErrNo);

               SqlParameter outparam = new SqlParameter();
               outparam.ParameterName = "@Ps_ErrorMessage";
               outparam.SqlDbType = SqlDbType.VarChar;
               outparam.Size = 100;
               outparam.Direction = ParameterDirection.Output;
               objdbwork.AddParameter(outparam);



               DbManager.Instance.ExecuteDbTask(objdbwork);

               res = (DataSet)objdbwork.Result;

               if (objdbwork.ExecutionStatus.ReturnCode == 0)
               {


                   if (res != null && res.Tables.Count > 1)
                   {
                       res.Tables[0].TableName = "D1";
                       res.Tables[0].Columns.Add("sessionId");

                       res.Tables[1].TableName = "Status";
                   }
                   else
                   {
                       res.Tables[0].TableName = "Status";
                   }
               }
               else
               {
                  res.Tables.Add(createStatusTable(objdbwork.ExecutionStatus.ReturnCode.ToString(), objdbwork.ExecutionStatus.ErrorMessage));  
               }
               return res;
               //return outparam.Value.ToString();
           }
           catch (Exception ex)
           {
               Logger.Instance.WriteLog(typeof(CUserRegistration), ex.Message, ex);
               return res;
           }
       }

       public DataSet Login(string ApplicationKey, string Email, string Pass, string Panno, string userType, string IpAddress, string RmName, string s_CallType, string s_ClientNo = null)
       {
           DbWorkItem objdbwork = null;
           DataSet res = new DataSet();
           DataTable dt = new DataTable();
           try
           {
               objdbwork = new DbWorkItem("stp_KYC_LoginUser");
               objdbwork.ResultType = QueryType.DataSet;
               objdbwork.AddParameter("@Ps_Email", SqlDbType.VarChar, Email);
               objdbwork.AddParameter("@Ps_Password", SqlDbType.VarChar, Pass);
               objdbwork.AddParameter("@Ps_PANNo", SqlDbType.VarChar, Panno);
               objdbwork.AddParameter("@Ps_UserType", SqlDbType.VarChar, userType);
               objdbwork.AddParameter("@Ps_IpAddress", SqlDbType.VarChar, IpAddress);
               objdbwork.AddParameter("@Ps_RmName", SqlDbType.VarChar, RmName);
               objdbwork.AddParameter("@n_ClientNo", SqlDbType.VarChar, s_ClientNo);



               SqlParameter outParamErrNo = new SqlParameter();
               outParamErrNo.ParameterName = "@Ps_ErrorCode";
               outParamErrNo.SqlDbType = SqlDbType.Int;
               outParamErrNo.Size = 8;
               outParamErrNo.Direction = ParameterDirection.Output;
               objdbwork.AddParameter(outParamErrNo);

               SqlParameter outparam = new SqlParameter();
               outparam.ParameterName = "@Ps_ErrorMessage";
               outparam.SqlDbType = SqlDbType.VarChar;
               outparam.Size = 100;
               outparam.Direction = ParameterDirection.Output;
               objdbwork.AddParameter(outparam);



               DbManager.Instance.ExecuteDbTask(objdbwork);

               res = (DataSet)objdbwork.Result;

               if (objdbwork.ExecutionStatus.ReturnCode == 0)
               {


                   if (res != null && res.Tables.Count > 1)
                   {
                       res.Tables[0].TableName = "D1";
                       res.Tables[0].Columns.Add("sessionId");

                       res.Tables[1].TableName = "Status";
                   }
                   else
                   {
                       res.Tables[0].TableName = "Status";
                   }
               }
               else
               {
                   res.Tables.Add(createStatusTable(objdbwork.ExecutionStatus.ReturnCode.ToString(), objdbwork.ExecutionStatus.ErrorMessage));
               }
               return res;
               //return outparam.Value.ToString();
           }
           catch (Exception ex)
           {
               Logger.Instance.WriteLog(typeof(CUserRegistration), ex.Message, ex);
               return res;
           }
       }

       public  void LoginAndLogOutTrail(string s_Email, string s_Panno, int n_Type, string s_TerminalId, string s_Status)
       {
           DbWorkItem objdbwork = null;
           DataSet res = new DataSet();
           DataTable dt = new DataTable();
           try
           {
               objdbwork = new DbWorkItem("stp_KYC_LoginTrail");
               objdbwork.ResultType = QueryType.DataSet;
               objdbwork.AddParameter("@Ps_EmailID", SqlDbType.VarChar, s_Email);
               objdbwork.AddParameter("@Ps_PANNo", SqlDbType.VarChar, s_Panno);
               objdbwork.AddParameter("@Ps_Status", SqlDbType.VarChar, s_Status);
               objdbwork.AddParameter("@Pn_RequestType", SqlDbType.Int,n_Type );
               objdbwork.AddParameter("@Ps_Remarks", SqlDbType.VarChar, null);
               objdbwork.AddParameter("@Ps_TerminalId", SqlDbType.VarChar, s_TerminalId);


               //SqlParameter outParamErrNo = new SqlParameter();
               //outParamErrNo.ParameterName = "@Ps_ErrorCode";
               //outParamErrNo.SqlDbType = SqlDbType.Int;
               //outParamErrNo.Size = 8;
               //outParamErrNo.Direction = ParameterDirection.Output;
               //objdbwork.AddParameter(outParamErrNo);

               //SqlParameter outparam = new SqlParameter();
               //outparam.ParameterName = "@Ps_ErrorMessage";
               //outparam.SqlDbType = SqlDbType.VarChar;
               //outparam.Size = 100;
               //outparam.Direction = ParameterDirection.Output;
               //objdbwork.AddParameter(outparam);



               DbManager.Instance.ExecuteDbTask(objdbwork);

              
               //return outparam.Value.ToString();
           }
           catch (Exception ex)
           {
               Logger.Instance.WriteLog(typeof(CUserRegistration), ex.Message, ex);
               //return res;
           }
       }

        public DataTable createStatusTable(string errCode, string errMsg)
        {
            DataTable dt = new DataTable();
            dt.TableName = "Status";
            dt.Columns.Add("ErrorCode");
            dt.Columns.Add("Message");
            dt.Rows.Add(errCode, errMsg);

            return dt;

        }

            //public object AuthorizeOTP(string ApplicationKey, string s_Name, string s_Email, int n_MobileNo, string s_PANNo, string s_OTP)
            //{
            //    try
            //    {
            //        DbWorkItem objdbwork = new DbWorkItem("stp_OTPAuth");
            //        objdbwork.ResultType = QueryType.DataSet;
            //        objdbwork.AddParameter("@Ps_Mode", SqlDbType.VarChar, "U");
            //        objdbwork.AddParameter("@Ps_Name", SqlDbType.VarChar, s_Name);
            //        objdbwork.AddParameter("@Ps_Email", SqlDbType.VarChar, s_Email);
            //        objdbwork.AddParameter("@Pn_MobileNo", SqlDbType.Int, n_MobileNo);
            //        objdbwork.AddParameter("@Ps_PANNo", SqlDbType.VarChar, s_PANNo);
            //        objdbwork.AddParameter("@Ps_OTP", SqlDbType.VarChar, s_OTP);

            //        SqlParameter outparam = new SqlParameter();
            //        outparam.ParameterName = "Ps_ErrorMessage";
            //        outparam.SqlDbType = SqlDbType.VarChar;
            //        outparam.Direction = ParameterDirection.Output;

            //        objdbwork.AddParameter(outparam);

            //        DbManager.Instance.ExecuteDbTask(objdbwork);
            //        return objdbwork.Result;
            //        //return outparam.Value.ToString();
            //    }
            //    catch (Exception ex)
            //    {
            //        Logger.Instance.WriteLog(typeof(CEntityMaster), ex.Message);
            //        return ex.Message;
            //    }
            //}

        public DataSet ForgotPassword(string ApplicationKey, string Name, string Mobile, string Email,  string Panno, string Capcha, string dob,string NewPassword)
        {
            DbWorkItem objdbwork = null;
            DataSet res = new DataSet();
            try
            {
                objdbwork = new DbWorkItem("stp_KYC_ChangePassword");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@Ps_Name", SqlDbType.VarChar, Name);
                objdbwork.AddParameter("@Ps_Email", SqlDbType.VarChar, Email);
                objdbwork.AddParameter("@Ps_MobileNo", SqlDbType.VarChar, Mobile);
                objdbwork.AddParameter("@Ps_PANNo", SqlDbType.VarChar, Panno);
                objdbwork.AddParameter("@Ps_DOB", SqlDbType.VarChar, dob);
                //objdbwork.AddParameter("@Ps_Password", SqlDbType.VarChar, s_Pass);
                objdbwork.AddParameter("@Ps_NewPassword", SqlDbType.VarChar, NewPassword);
                objdbwork.AddParameter("@Ps_CallingType", SqlDbType.VarChar, "F");

                SqlParameter outParamErrNo = new SqlParameter();
                outParamErrNo.ParameterName = "@Pn_ErrorCode";
                outParamErrNo.SqlDbType = SqlDbType.Int;
                outParamErrNo.Size = 8;
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outparam = new SqlParameter();
                outparam.ParameterName = "@Ps_ErrorMessage";
                outparam.SqlDbType = SqlDbType.VarChar;
                outparam.Size = 100;
                outparam.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outparam);


                DbManager.Instance.ExecuteDbTask(objdbwork);
                res.Tables.Add(createStatusTable((string)objdbwork.parameters[objdbwork.parameters.Count - 2].Value.ToString(), (string)objdbwork.parameters[objdbwork.parameters.Count - 1].Value.ToString()));
                res.Tables[0].TableName = "Status";

                int errCode = (int)objdbwork.parameters[objdbwork.parameters.Count - 2].Value;
                if (errCode == 0)
                {
                    res.Tables.Add(((DataSet)objdbwork.Result).Tables[0].Copy());
                }
                else
                {
                    //res[1] = new DataTable();
                    res.Tables.Add(new DataTable());
                }
                res.Tables[1].TableName = "D1";

                return res;
                //return outparam.Value.ToString();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CUserRegistration), ex.Message, ex);
                return res;
            }
        }

        public DataSet ForgotPassword(string ApplicationKey, string Email, string Panno, string Capcha, string NewPassword)
        {
            DbWorkItem objdbwork = null;
            DataSet res = new DataSet();
            try
            {
                objdbwork = new DbWorkItem("stp_KYC_ChangePassword_New");
                objdbwork.ResultType = QueryType.DataSet;                
                objdbwork.AddParameter("@Ps_Email", SqlDbType.VarChar, Email);                
                objdbwork.AddParameter("@Ps_PANNo", SqlDbType.VarChar, Panno);                                
                objdbwork.AddParameter("@Ps_NewPassword", SqlDbType.VarChar, NewPassword);
                objdbwork.AddParameter("@Ps_CallingType", SqlDbType.VarChar, "F");

                SqlParameter outParamErrNo = new SqlParameter();
                outParamErrNo.ParameterName = "@Pn_ErrorCode";
                outParamErrNo.SqlDbType = SqlDbType.Int;
                outParamErrNo.Size = 8;
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outparam = new SqlParameter();
                outparam.ParameterName = "@Ps_ErrorMessage";
                outparam.SqlDbType = SqlDbType.VarChar;
                outparam.Size = 100;
                outparam.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outparam);


                DbManager.Instance.ExecuteDbTask(objdbwork);
                res.Tables.Add(createStatusTable((string)objdbwork.parameters[objdbwork.parameters.Count - 2].Value.ToString(), (string)objdbwork.parameters[objdbwork.parameters.Count - 1].Value.ToString()));
                res.Tables[0].TableName = "Status";

                int errCode = (int)objdbwork.parameters[objdbwork.parameters.Count - 2].Value;
                if (errCode == 0)
                {
                    res.Tables.Add(((DataSet)objdbwork.Result).Tables[0].Copy());
                }
                else
                {
                    //res[1] = new DataTable();
                    res.Tables.Add(new DataTable());
                }
                res.Tables[1].TableName = "D1";

                return res;
                //return outparam.Value.ToString();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CUserRegistration), ex.Message, ex);
                return res;
            }
        }

        public DataSet ChangePassword(string s_ApplicationKey, string s_Name, string s_Mobile, string s_Email, string s_Pass, string s_NewPass, string s_Panno, string s_Capcha, string s_dob)
        {
            DbWorkItem objdbwork = null;
            DataSet res = new DataSet();
            try
            {
                objdbwork = new DbWorkItem("stp_KYC_ChangePassword");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter("@Ps_Name", SqlDbType.VarChar, s_Name);
                objdbwork.AddParameter("@Ps_Email", SqlDbType.VarChar, s_Email);
                objdbwork.AddParameter("@Ps_MobileNo", SqlDbType.VarChar, s_Mobile);
                objdbwork.AddParameter("@Ps_PANNo", SqlDbType.VarChar, s_Panno);
                objdbwork.AddParameter("@Ps_DOB", SqlDbType.VarChar, s_dob);
                objdbwork.AddParameter("@Ps_Password", SqlDbType.VarChar, s_Pass);
                objdbwork.AddParameter("@Ps_NewPassword", SqlDbType.VarChar, s_NewPass);
                objdbwork.AddParameter("@Ps_CallingType", SqlDbType.VarChar, "C");

                SqlParameter outParamErrNo = new SqlParameter();
                outParamErrNo.ParameterName = "@Pn_ErrorCode";
                outParamErrNo.SqlDbType = SqlDbType.Int;
                outParamErrNo.Size = 8;
                outParamErrNo.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outParamErrNo);

                SqlParameter outparam = new SqlParameter();
                outparam.ParameterName = "@Ps_ErrorMessage";
                outparam.SqlDbType = SqlDbType.VarChar;
                outparam.Size = 100;
                outparam.Direction = ParameterDirection.Output;
                objdbwork.AddParameter(outparam);


                DbManager.Instance.ExecuteDbTask(objdbwork);
                res.Tables.Add(createStatusTable((string)objdbwork.parameters[objdbwork.parameters.Count - 2].Value.ToString(), (string)objdbwork.parameters[objdbwork.parameters.Count - 1].Value.ToString()));
                res.Tables[0].TableName = "Status";

                int errCode = (int)objdbwork.parameters[objdbwork.parameters.Count - 2].Value;
                if (errCode == 0)
                {
                    res.Tables.Add(((DataSet)objdbwork.Result).Tables[0].Copy());
                }
                else
                {
                    //res[1] = new DataTable();
                    res.Tables.Add(new DataTable());
                }
                res.Tables[1].TableName = "D1";

                return res;
                //return outparam.Value.ToString();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CUserRegistration), ex.Message, ex);
                return res;
            }
        }

        public string EntityModeOperation(string OpMode, string ClientNo, string UserID, string EntityMode)
        {
            Logger.Instance.WriteLog(typeof(CUserRegistration), OpMode + ClientNo + UserID + EntityMode);
                
            DataSet dsdata = new DataSet();
            string s_Result = string.Empty; 
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_EntityModeOperation");
                objdbwork.ResultType = QueryType.DataSet;

                objdbwork.AddParameter("@ps_OperationMode", SqlDbType.VarChar, OpMode);
                objdbwork.AddParameter("@ps_ClientNo", SqlDbType.VarChar, ClientNo);
                objdbwork.AddParameter("@ps_UserID", SqlDbType.VarChar, UserID);
                objdbwork.AddParameter("@ps_EntityMode", SqlDbType.VarChar, EntityMode);

                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    dsdata = objdbwork.Result as DataSet;
                    if (((dsdata != null) && (dsdata.Tables.Count != 0) && (dsdata.Tables[0].Rows.Count > 0)))
                    {
                        s_Result= dsdata.Tables[0].Rows[0]["s_VerificationMode"] == null ? s_Result : Convert.ToString(dsdata.Tables[0].Rows[0]["s_VerificationMode"]);
                    }
                }
                else
                {
                    Logger.Instance.WriteLog(typeof(CUserRegistration), objdbwork.ExecutionStatus);
                     
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CUserRegistration), ex.Message, ex);
            }
            return s_Result;
        }

        public string GetModeForAadhar()
        {
            string Mode = null;
            DataSet xmldata = new DataSet();
            try
            {
                xmldata.ReadXml(AppDomain.CurrentDomain.BaseDirectory + @"DependentFiles\XML\Mode.xml");

                if (xmldata != null && xmldata.Tables.Count > 0)
                {
                    xmldata.Tables[0].DefaultView.Sort = "priorityOrder  asc";

                    for (int i = 0; i < xmldata.Tables[0].Rows.Count; i++)
                    {
                        string name = xmldata.Tables[0].Rows[i]["Name"].ToString();
                        string url = xmldata.Tables[0].Rows[i]["Url"].ToString();

                        if (name.ToUpper().Trim() == "AADHAAR")
                        {
                            Mode = "A";
                        }
                    }
                }
            }
            catch (Exception Ex)
            {

            }
            return Mode;
        }


    }
}
