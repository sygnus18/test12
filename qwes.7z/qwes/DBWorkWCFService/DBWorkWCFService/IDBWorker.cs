﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace DBWorkWCFService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IDBWorker 
    {
        [OperationContract]
        string GetData(int value);

        [OperationContract]
        [WebInvoke(Method = "*", ResponseFormat = WebMessageFormat.Json)]
        Response GetDropDownData(string DropDownType, string UserNo);

        [OperationContract]
        [WebInvoke(Method = "*", ResponseFormat = WebMessageFormat.Json)]
        Response GetProcessFilterData(string HelpType, string UserNo);

        [OperationContract]
        [WebInvoke(Method = "*", ResponseFormat = WebMessageFormat.Json)]
        Response GetProcessData(string Mode, string UserNo);


        [OperationContract]
        [WebInvoke(Method = "*", ResponseFormat = WebMessageFormat.Json)]
        Response ComputeProcessHash(Dictionary<object, object> DictParams);

        [OperationContract]
        [WebInvoke(Method = "*", ResponseFormat = WebMessageFormat.Json)]
        Response ComputeProcess(string UserNo, string processName, DateTime Date, string Company, string Exchange, string ClientCode, DateTime Todate, string UnderlyingCode, string BillFrequency, DateTime PostingDate);
          
    } 
}
