﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace DBWorkWCFService
{

    /// <summary>
    /// Class for storing response data
    /// </summary>
    ///<author>kushal S</author> 
    [DataContract]
    public class Response
    {
        public Response()
        {

        } 
        /// <summary>
        /// Response Code
        /// </summary>
        [DataMember]
        public long ResponseCode { get; set; }


        /// <summary>
        /// Error messege or waring messge.
        /// </summary>
        [DataMember]
        public string ResponseMessage { get; set; }

        /// <summary>
        /// Dataset return from database
        /// </summary>
        [DataMember]
        public DataSet DataSet { get; set; }
         
        /// <summary>
        /// Unique token ID for handshake.
        /// </summary>
        [DataMember]
        public string TokenID { get; set; }

        /// <summary>
        /// ReferenceID
        /// </summary>
        [DataMember]
        public string ReferenceID { get; set; }

        /// <summary>
        /// Remarks
        /// </summary>
        [DataMember]
        public string Remark { get; set; }


        /// <summary>
        /// DateTime in DD:MM:YYYY:HH:MM:SS Format
        /// </summary>
        [DataMember]
        public string RequestDateTime { get; set; }

    }
}
