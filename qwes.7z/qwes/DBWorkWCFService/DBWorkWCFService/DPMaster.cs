﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using FTIL.Match.Common.Log;
using FTIL.Match.Common;
using DailyProcess.BAL;
using System.IO;
using System.Xml;

namespace DBWorkWCFService
{
    class DPMaster : IDPMaster 
    {
        CDPNSDLClientsData obj_CDPNSDLClientsData = new CDPNSDLClientsData();
        DataSet dsXML = new DataSet();
        DataTable SourceDataTable { get; set; }
        DataSet dsClientMasterdata = new DataSet();
        MethodExecResult objMethodExecResult;

        public DPMaster()
        {
            Utility.DBInitializer();  
        }
        
        string IDPMaster.GetDPMasterData(int n_ProductNo,string composite)
        {

            DataSet dsResultdata = null;
            StringReader stream = null;
            XmlTextReader reader = null;
            stream = new StringReader(composite);
            reader = new XmlTextReader(stream);

            dsXML.ReadXml(reader);

            SourceDataTable = dsXML.Tables[0];
            obj_CDPNSDLClientsData.dtClientDetails = SourceDataTable;
            obj_CDPNSDLClientsData.dsXML = dsXML;
            obj_CDPNSDLClientsData.setData();
            Logger.Instance.WriteLog(this, "Cust Id " + obj_CDPNSDLClientsData.SenderReferenceNumber1 + " request recieved.");

            objMethodExecResult = obj_CDPNSDLClientsData.ManageData( n_ProductNo , dsXML);
            if (objMethodExecResult.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, "Cust Id " + obj_CDPNSDLClientsData.SenderReferenceNumber1 + " has been imported.");
                return obj_CDPNSDLClientsData.sMsg; // "Successfull";

            }
            else
                return objMethodExecResult.ErrorMessage;

                
            
            //   obj_CDPNSDLClientsData.GetAllData(ref dsResultdata);

            //    // insert data import data into Match
            //    objMethodExecResult = obj_CDPNSDLClientsData.DPIUClientMasterData(ref dsXML);
           


            //if (objMethodExecResult.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            //{
            //    Logger.Instance.WriteLog(this, "Cust Id " + obj_CDPNSDLClientsData.SenderReferenceNumber1 + " has been imported.");
            //    return obj_CDPNSDLClientsData.sMsg; // "Successfull";

            //}
            //else
            //    return objMethodExecResult.ErrorMessage;


        }
    }
}
