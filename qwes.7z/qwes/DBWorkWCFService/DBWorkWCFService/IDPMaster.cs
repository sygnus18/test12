﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace DBWorkWCFService
{
    [ServiceContract]
  public interface IDPMaster
    {
        [OperationContract]
        [ WebInvoke(Method = "*", ResponseFormat = WebMessageFormat.Json)]
        string GetDPMasterData(int n_ProductNo, string Response);


    }
}
