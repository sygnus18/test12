﻿using DailyProcess.BAL;
using FTIL.Match.Common;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.ServiceModel;
using System.Text;
using System.Xml;
using FTIL.Match.Common.Log;

namespace DBWorkWCFService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class DBWorker : IDBWorker 
    {
        CProcessDetail objProcessDetails = new CProcessDetail();
        MethodExecResult objMethodExecResult;
        DataSet dsProcess;
        static DBWorker()
        {  
            Utility.DBInitializer();  
        }

        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        } 
        public Response GetDropDownData(string DropDownType, string UserNo)
        {   
            Response objResponse = new Response();
            objProcessDetails.UserNo = UserNo;
            objMethodExecResult = objProcessDetails.GetDropDownData(DropDownType, ref dsProcess);

           return setResopnseobjtostring(objMethodExecResult, dsProcess);
        }
        public Response GetProcessFilterData(string HelpType, string UserNo)
        {
            Response objResponse = new Response();
            objProcessDetails.UserNo = UserNo;
            objMethodExecResult = objProcessDetails.GetProcessFilterData(HelpType,ref dsProcess); 
            return setResopnseobjtostring(objMethodExecResult, dsProcess);
        } 
        public Response GetProcessData(string Mode, string UserNo)
        {
            objProcessDetails.Mode = Mode;
            objProcessDetails.UserNo = UserNo; 
            objMethodExecResult = objProcessDetails.GetProcessData(ref dsProcess);
             return setResopnseobjtostring(objMethodExecResult, dsProcess);  
        }

        public Response ComputeProcess(string UserNo, string processName, DateTime Date, string Company, string Exchange, string ClientCode, DateTime Todate, string UnderlyingCode, string BillFrequency,DateTime PostingDate)
        {  
            string PrepairStatement = null; 
            Response objResponse = new Response();
             DataSet ds =null;
             getParamValues(UserNo, processName, Company, Exchange, UnderlyingCode, Date, Todate,BillFrequency,PostingDate);
          /*  objMethodExecResult = objProcessDetails.ComputeProcess("R", ref ds);
            if (objMethodExecResult.ReturnCode == 0 && ds != null && ds.Tables[0].Rows.Count > 0)
                 {
                     PrepairStatement = ds.Tables[0].Rows[0]["s_Statements"].ToString();
                     objMethodExecResult = objProcessDetails.PrepareStatement(UserNo, ref PrepairStatement, Date, Company, Exchange, ClientCode, sCallType, Todate, UnderlyingCode);

                     if (objMethodExecResult.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                     {
                         objProcessDetails.PreparedStatement = PrepairStatement;
                         objMethodExecResult = objProcessDetails.ComputeProcess("R", ref ds); 
                     }
                 }
                 objResponse.Remark = PrepairStatement;*/
             objMethodExecResult = objProcessDetails.CallComputeProcess();
             return setResopnseobjtostring(objMethodExecResult, ds, objResponse); 
        }

        public Response ComputeProcessHash(Dictionary<object,object> objIDictParam)
        { 
           getParamValues(objIDictParam);
           Response objResponse = new Response();
          /*   DataSet ds =null; 
                 objMethodExecResult = objProcessDetails.ComputeProcess("R", ref ds);
                 if (objMethodExecResult.ReturnCode == 0 && ds != null && ds.Tables[0].Rows.Count > 0)
                 {
                     PrepairStatement = ds.Tables[0].Rows[0]["s_Statements"].ToString();

                     objMethodExecResult = objProcessDetails.PrepareStatement(objProcessDetails.UserNo, ref PrepairStatement, objProcessDetails.Date, objProcessDetails.Company, objProcessDetails.Exchange, objProcessDetails.ClientCode, null, objProcessDetails.ToDate, objProcessDetails.UnderlyingCode);

                     if (objMethodExecResult.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                     {
                         objMethodExecResult = objProcessDetails.ComputeProcess("E",ref ds);
                     }
                 }
                 objResponse.Remark = PrepairStatement;*/
           objMethodExecResult = objProcessDetails.CallComputeProcess();
           return setResopnseobjtostring(objMethodExecResult, null, objResponse); 
        }

        private void getParamValues(IDictionary<object, object> DictParams)
        {
            objProcessDetails.UserNo = DictParams.ContainsKey("User") ? DictParams["User"].ToString() : null;
            objProcessDetails.ProcessName = DictParams.ContainsKey("ProcessName") ? DictParams["ProcessName"].ToString() : null;
            objProcessDetails.Company = DictParams.ContainsKey("Company") ? DictParams["Company"].ToString() : null;
            objProcessDetails.Exchange = DictParams.ContainsKey("Exchange") ? DictParams["Exchange"].ToString() : null;
            objProcessDetails.UnderlyingCode = DictParams.ContainsKey("UnderlyingCode") ? DictParams["UnderlyingCode"].ToString() : null;
            objProcessDetails.BillFrequency = DictParams.ContainsKey("BillFrequency") ? DictParams["BillFrequency"].ToString() : null;  
            if (DictParams.ContainsKey("Date"))
                objProcessDetails.Date = Convert.ToDateTime(DictParams["Date"]);
            else
                objProcessDetails.Date = null;
             
            if (DictParams.ContainsKey("ToDate"))
                objProcessDetails.ToDate = Convert.ToDateTime(DictParams["ToDate"]);
            else
                objProcessDetails.ToDate = null;


            if (DictParams.ContainsKey("PostingDate"))
                objProcessDetails.PostingDate = Convert.ToDateTime(DictParams["PostingDate"]);
            else
                objProcessDetails.PostingDate = null; 

        }
        private void getParamValues(string UserNo, string ProcessName, string Company, string Exchange, string UnderlyingCode, DateTime Date, DateTime ToDate, string BillFrequency, DateTime PostingDate)
        {
            objProcessDetails.UserNo = UserNo;
            objProcessDetails.ProcessName = !string.IsNullOrEmpty(ProcessName) ? ProcessName : null;
            objProcessDetails.Company = !string.IsNullOrEmpty(Company) ? Company : null;
            objProcessDetails.Exchange = !string.IsNullOrEmpty(Exchange) ? Exchange : null;
            objProcessDetails.UnderlyingCode = !string.IsNullOrEmpty(UnderlyingCode) ? UnderlyingCode : null;
            objProcessDetails.BillFrequency = !string.IsNullOrEmpty(BillFrequency) ? BillFrequency : null; 
            objProcessDetails.Date = Date;
            objProcessDetails.ToDate = ToDate;
            objProcessDetails.PostingDate = PostingDate; 
        }

        private Response setResopnseobjtostring(MethodExecResult objMethodExecResult, DataSet ds, Response objResponse)
        {
          //  Response objResponse = new Response();
            objResponse.ResponseCode = objMethodExecResult.ReturnCode;
            objResponse.ResponseMessage = objMethodExecResult.ErrorMessage;
            objResponse.DataSet = ds;
           //  string strResponse = JSONSerialize(objResponse);
             return objResponse; 
        }
        private Response setResopnseobjtostring(MethodExecResult objMethodExecResult, DataSet ds)
        {
             Response objResponse = new Response();
            objResponse.ResponseCode = objMethodExecResult.ReturnCode;
            objResponse.ResponseMessage = objMethodExecResult.ErrorMessage;
            objResponse.DataSet = ds;
            string strResponse = JSONSerialize(objResponse);
            return objResponse;
        }
        private string JSONSerialize(Response objResponse)
        {
            // Serialize the results as JSON
            DataContractJsonSerializer serializer = new DataContractJsonSerializer(objResponse.GetType());
            string json = null;
            using (MemoryStream memoryStream = new MemoryStream())
            {    
                serializer.WriteObject(memoryStream, objResponse);
                // Return the results serialized as JSON
                json = Encoding.Default.GetString(memoryStream.ToArray()); 
            }
            return json;
        }

        CDPNSDLClientsData obj_CDPNSDLClientsData = new CDPNSDLClientsData();
        DataSet dsXML = new DataSet();
        DataTable SourceDataTable { get; set; }
        DataSet dsClientMasterdata = new DataSet();

        string GetDPMasterData(string composite)
        {

            DataSet dsResultdata = null;
            StringReader stream = null;
            XmlTextReader reader = null;
            stream = new StringReader(composite);
            reader = new XmlTextReader(stream);

            dsXML.ReadXml(reader);

            SourceDataTable = dsXML.Tables[0];
            obj_CDPNSDLClientsData.dtClientDetails = SourceDataTable;
            obj_CDPNSDLClientsData.setData();
            Logger.Instance.WriteLog(this, "Cust Id " + obj_CDPNSDLClientsData.SenderReferenceNumber1 + " request recieved."); 

            obj_CDPNSDLClientsData.GetAllData(ref dsResultdata);

            // insert data import data into Match
            objMethodExecResult = obj_CDPNSDLClientsData.DPIUClientMasterData(ref dsXML);

            if (objMethodExecResult.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, "Cust Id " + obj_CDPNSDLClientsData.SenderReferenceNumber1 + " has been imported.");
                return obj_CDPNSDLClientsData.sParamMsg; // "Successfull";
                
            }
            else
                return objMethodExecResult.ErrorMessage;

           
        }
        
    }
}
