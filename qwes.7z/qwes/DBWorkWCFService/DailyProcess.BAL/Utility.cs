﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FTIL.Match.Common.Log;
using FTIL.Match.Common;
using System.Configuration;
using FTIL.Match.Common.Db;
using System.Runtime.Serialization.Json;
using System.IO;

namespace DailyProcess.BAL
{
   public static class Utility
    {
       static string l_sConnStrIdentifier = string.Empty;
       static string l_sConnStr = string.Empty; 
      
       public static string m_sConnStr
       {
           set
           {
               l_sConnStr = value;
           }
           get
           {
               return l_sConnStr;
           }
       } 


        public static void DBInitializer() 
        {
            string l_sConnStrIdentifier = string.Empty;
            string l_sConnStr = string.Empty;
            CProcessDetail l_objProcessDetail;
            string ErrorMassage;

            l_sConnStr = ConfigurationManager.AppSettings.Get("DervConnStr");
            if (string.IsNullOrEmpty(l_sConnStr))
            {
               /*  MessageBox.Show("Connection information not found." + Environment.NewLine +
                    "Make sure you have set proper database settings.", "Daily Process", MessageBoxButtons.OK, MessageBoxIcon.Error);*/ 
                ErrorMassage = "Connection information not found." + Environment.NewLine + "Make sure you have set proper database settings.";
                return ;
            }

            l_objProcessDetail = new CProcessDetail();
            MethodExecResult l_objMethodExecResult =  SetConnectionString(l_sConnStrIdentifier, l_sConnStr);
            if (l_objMethodExecResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(l_objProcessDetail, l_objMethodExecResult);
               // MessageBox.Show(l_objMethodExecResult.ErrorMessage, "Daily Process", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ErrorMassage = l_objMethodExecResult.ErrorMessage; 
                return;
            } 
        }

        public static MethodExecResult SetConnectionString(string p_vsConnStrIdentifier, string p_vsConnString)
        {
            DbConnectionParameters l_objDbConParams = null;
            MethodExecResult l_objMethodExecResult = DbConnectionParameters.GetInstanceFromConnString(p_vsConnString, ref l_objDbConParams);
            if (l_objMethodExecResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
                return l_objMethodExecResult;

            MatchCommonUIParams.Instance.DbConnParams = l_objDbConParams;
            MatchCommonUIParams.Instance.DbConnParams.Identifier = p_vsConnStrIdentifier;

            m_sConnStr = l_objDbConParams.ConnectionString;
            return new MethodExecResult(MethodExecResult.SuccessfulReturnCode);

        }

        public static T DeserializeJson<T>(string strResponse)
        {
            T objResponse ;

            DataContractJsonSerializer jsonSer = new DataContractJsonSerializer(typeof(T));

            using (MemoryStream stream = new MemoryStream(Encoding.UTF8.GetBytes(strResponse)))
            {
                objResponse = (T)jsonSer.ReadObject(stream);
            }

            return objResponse;
        }
    }
}
