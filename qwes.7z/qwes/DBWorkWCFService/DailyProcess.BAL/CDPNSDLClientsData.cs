﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using System.Data;
using MatchCommon;
using System.Data.SqlClient;
using DailyProcess.BAL;
using FTIL.Match.Common.Log;

namespace DailyProcess.BAL
{
    public class CDPNSDLClientsData
    {

        #region Variables
        //public const string BatchNumber  = " "BatchNumber"";

        long m_UserNo = 0;
        public const string spName = "stp_DPAPIClientImportData";
        public const string N_CLIENTNO = "n_ClientNo";
        public const string BENEFICIARYTYPE = "BeneficiaryType";
        public const string BENEFICIARYSUBTYPE = "BeneficiarySubType";
        public const string BENEFICIARYSHORTNAME = "BeneficiaryShortName";
        public const string BENEFICIARYOCCUPATION = "BeneficiaryOccupation";
        public const string BENEFICIARYFIRSTHOLDERNAME = "BeneficiaryFirstHolderName";
        public const string FIRSTHOLDERFATHERHUSBANDNAME = "FirstHolderFatherHusbandName";
        public const string BENEFICIARYSECONDHOLDERNAME = "BeneficiarySecondHolderName";
        public const string SECONDHOLDERFATHERHUSBANDNAME = "SecondHolderFatherHusbandName";
        public const string BENEFICIARYTHIRDHOLDERNAME = "BeneficiaryThirdHolderName";
        public const string THIRDHOLDERFATHERHUSBANDNAME = "ThirdHolderFatherHusbandName";
        public const string ADDRESSPREFERENCEFLAG = "AddresspreferenceFlag";
        public const string FIRSTHOLDERPAN = "FirstHolderPAN";
        public const string SECONDHOLDERPAN = "SecondHolderPAN";
        public const string THIRDHOLDERPAN = "ThirdHolderPAN";
        public const string NOMINEEGUARDIANINDICATOR = "NomineeGuardianIndicator";
        public const string NOMINEEGUARDIANNAME = "NomineeGuardianName";
        public const string NOMINEEMINORINDICATOR = "NomineeMinorIndicator";
        public const string MINORNOMINEEGUARDIANNAME = "MinorNomineeGuardianName";
        public const string DATEOFBIRTHOFMINOR = "DateofBirthofMinor";
        public const string STANDINGINSTRUCTIONINDICATOR = "StandingInstructionIndicator";
        public const string BENEFICIARYBANKACCOUNT = "BeneficiaryBankAccount";
        public const string BENEFICIARYBANKNAME = "BeneficiaryBankName";
        public const string IFSCNO = "IFSC";
        public const string BENEFICIARYRBIREFERENCENO = "BeneficiaryRBIReferenceNo";
        public const string BENEFICIARYRBIAPPROVALDATE = "BeneficiaryRBIApprovalDate";
        public const string BENEFICIARYTAXDEDUCTIONSTATUS = "BeneficiaryTaxDeductionStatus";
        public const string LOCALADDRESSPRESENT = "LocaladdressPresent";
        public const string BANKADDRESSPRESENT = "BankAddressPresent";
        public const string NOMINEEGUARDIANADDRESSPRESENT = "NomineeGuardianAddressPresent";
        public const string MINORNOMINEEGUARDIANADDRESSPRESENT = "MinorNomineeGuardianAddressPresent";
        public const string CORRESPONDENCEADDRESSPRESENT = "CorrespondenceAddressPresent";
        public const string NOMINEENAME = "NomineeName";
        public const string NOOFFIRSTHOLDERAUTHSIGNATORIES = "NoofFirstHolderAuthSignatories";
        public const string NOOFSECHOLDERAUTHSIGNATORIES = "NoofSecHolderAuthSignatories";
        public const string NOOFTHIRDHOLDERAUTHSIGNATORIES = "NoofThirdHolderAuthSignatories";
        public const string SIZEOFSIGNATURE = "SizeofSignature";
        public const string SENDERREFERENCENUMBER1 = "SenderReferenceNumber1";
        public const string SENDERREFERENCENUMBER2 = "SenderReferenceNumber2";
        public const string MICRCODE = "MICRCode";
        public const string BANKACCTTYPE = "BankAcctType";
        public const string NOOFPOAMAPPINGFIRSTHOLDER = "NoOfPoaMappingFirstHolder";
        public const string EMAILIDFIRSTHOLDER = "EmailIdFirstHolder";
        public const string MOBILENOFIRSTHOLDER = "MobileNoFirstHolder";
        public const string SMSFACILITYFIRSTHOLDER = "SMSFacilityFirstHolder";
        public const string AUTHFLAGFIRSTHOLDER = "AuthFlagFirstHolder";
        public const string PANFLAGFIRSTHOLDER = "PANFlagFirstHolder";
        public const string NONOMINATIONFLAGFIRSTHOLDER = "NoNominationFlagFirstHolder";
        public const string NOPOAMAPPINGSECONDHOLDER = "NoPoaMappingSecondHolder";
        public const string EMAILIDSECONDHOLDER = "EmailIdSecondHolder";
        public const string MOBILENOSECONDHOLDER = "MobileNoSecondHolder";
        public const string SMSFACILITYSECONDHOLDER = "SMSFacilitySecondHolder";
        public const string AUTHFLAGSECONDHOLDER = "AuthFlagSecondHolder";
        public const string PANFLAGSECONDHOLDER = "PANFlagSecondHolder";
        public const string NOPOAMAPPINGTHIRDHOLDER = "NoPoaMappingThirdHolder";
        public const string EMAILIDTHIRDHOLDER = "EmailIdThirdHolder";
        public const string MOBILENOOFTHIRDHOLDER = "MobileNoofThirdHolder";
        public const string SMSFACILITYTHIRDHOLDER = "SMSFacilityThirdHolder";
        public const string AUTHFLAGTHIRDHOLDER = "AuthFlagThirdHolder";
        public const string PANFLAGTHIRDHOLDER = "PANFlagThirdHolder";
        public const string ADDRESSTYPECODE = "AddressTypeCode";
        public const string ADDRESS1 = "Address1";
        public const string ADDRESS2 = "Address2";
        public const string ADDRESS3 = "Address3";
        public const string ADDRESS4 = "Address4";
        public const string PINCODE = "Pincode";
        public const string PHONENO = "PhoneNo";
        public const string FAXNO = "FaxNo";
        public const string CORRADDRESSTYPECODE = "CorrAddressTypeCode";
        public const string CORRADDRESS1 = "CorrAddress1";
        public const string CORRADDRESS2 = "CorrAddress2";
        public const string CORRADDRESS3 = "CorrAddress3";
        public const string CORRADDRESS4 = "CorrAddress4";
        public const string CORRPINCODE = "CorrPincode";
        public const string CORRPHONENO = "CorrPhoneNo";
        public const string CORRFAXNO = "CorrFaxNo";

        public const string NOMINEEADDRESSTYPECODE = "NomineeAddressTypeCode";
        public const string NOMINEEADDRESS1 = "NomineeAddress1";
        public const string NOMINEEADDRESS2 = "NomineeAddress2";
        public const string NOMINEEADDRESS3 = "NomineeAddress3";
        public const string NOMINEEADDRESS4 = "NomineeAddress4";
        public const string NOMINEEPINCODE = "NomineePincode";
        public const string NOMINEEPHONENO = "NomineePhoneNo";
        public const string NOMINEEFAXNO = "NomineeFaxNo";

        public const string HOLDERINDICATOR1 = "HolderIndicator1";
        public const string HOLDERINDICATOR2 = "HolderIndicator2";
        public const string HOLDERINDICATOR3 = "HolderIndicator3";
        public const string POAHOLDERINDICATOR1 = "POAHolderIndicator1";
        public const string POAHOLDERINDICATOR2 = "POAHolderIndicator2";
        public const string POAHOLDERINDICATOR3 = "POAHolderIndicator3";
        public const string SIGNATORYID = "SignatoryID";
        public const string POATYPE = "POAType";
        public const string POAID = "POAId";
        public const string SEBIREGISTRATION = "SEBIRegistration";
        public const string AUTHFLAGFORFIRSTHOLDER = "AuthFlagForFirstHolder";
        public const string AUTHFLAGFORSECONTHOLDER = "AuthFlagForSecontHolder";
        public const string AUTHFLAGFORTHIRDHOLDER = "AuthFlagForThirdHolder";
        public const string CREATIONDATE = "CreationDate";
        public const string MAPPINGCODE = "MappingCode";
        public const string CIN = "CIN";
        public const string USERNO = "UserNo"; 

        public const string spGetDataName = "stp_GetDPEntityData";

        public const int MATCHNET = 1;
        public const int DP_NSDL = 17;
        public const int DP_CDSL = 18; 
        #endregion

        #region Properties

        public DataSet dsgridDatasetClientDataEntry { get; set; }

        public string n_ClientNo { get; set; }
        public string BeneficiaryType { get; set; }
        public string BeneficiarySubType { get; set; }
        public string BeneficiaryShortName { get; set; }
        public string BeneficiaryOccupation { get; set; }
        public string BeneficiaryFirstHolderName { get; set; }
        public string FirstHolderFatherHusbandName { get; set; }
        public string BeneficiarySecondHolderName { get; set; }
        public string SecondHolderFatherHusbandName { get; set; }
        public string BeneficiaryThirdHolderName { get; set; }
        public string ThirdHolderFatherHusbandName { get; set; }
        public string AddresspreferenceFlag { get; set; }
        public string FirstHolderPAN { get; set; }
        public string SecondHolderPAN { get; set; }
        public string ThirdHolderPAN { get; set; }
        public string NomineeGuardianIndicator { get; set; }
        public string NomineeGuardianName { get; set; }
        public string NomineeMinorIndicator { get; set; }
        public string MinorNomineeGuardianName { get; set; }
        public string DateofBirthofMinor { get; set; }
        public string StandingInstructionIndicator { get; set; }
        public string BeneficiaryBankAccount { get; set; }
        public string BeneficiaryBankName { get; set; }
        public string IFSC { get; set; }
        public string BeneficiaryRBIReferenceNo { get; set; }
        public string BeneficiaryRBIApprovalDate { get; set; }
        public string BeneficiaryTaxDeductionStatus { get; set; }
        public string LocaladdressPresent { get; set; }
        public string BankAddressPresent { get; set; }
        public string NomineeGuardianAddressPresent { get; set; }
        public string MinorNomineeGuardianAddressPresent { get; set; }
        public string CorrespondenceAddressPresent { get; set; }
        public string NomineeName { get; set; }
        public string NoofFirstHolderAuthSignatories { get; set; }
        public string NoofSecHolderAuthSignatories { get; set; }
        public string NoofThirdHolderAuthSignatories { get; set; }
        public string SizeofSignature { get; set; }
        public string SenderReferenceNumber1 { get; set; }
        public string SenderReferenceNumber2 { get; set; }
        public string MICRCode { get; set; }
        public string BankAcctType { get; set; }
        public string NoOfPoaMappingFirstHolder { get; set; }
        public string EmailIdFirstHolder { get; set; }
        public string MobileNoFirstHolder { get; set; }
        public string SMSFacilityFirstHolder { get; set; }
        public string AuthFlagFirstHolder { get; set; }
        public string PANFlagFirstHolder { get; set; }
        public string NoNominationFlagFirstHolder { get; set; }
        public string NoPoaMappingSecondHolder { get; set; }
        public string EmailIdSecondHolder { get; set; }
        public string MobileNoSecondHolder { get; set; }
        public string SMSFacilitySecondHolder { get; set; }
        public string AuthFlagSecondHolder { get; set; }
        public string PANFlagSecondHolder { get; set; }
        public string NoPoaMappingThirdHolder { get; set; }
        public string EmailIdThirdHolder { get; set; }
        public string MobileNoofThirdHolder { get; set; }
        public string SMSFacilityThirdHolder { get; set; }
        public string AuthFlagThirdHolder { get; set; }
        public string PANFlagThirdHolder { get; set; }
        public string AddressTypeCode { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }
        public string Address4 { get; set; }
        public string Pincode { get; set; }
        public string PhoneNo { get; set; }
        public string FaxNo { get; set; }
        public string CorrAddressTypeCode { get; set; }
        public string CorrAddress1 { get; set; }
        public string CorrAddress2 { get; set; }
        public string CorrAddress3 { get; set; }
        public string CorrAddress4 { get; set; }
        public string CorrPincode { get; set; }
        public string CorrPhoneNo { get; set; }
        public string CorrFaxNo { get; set; }
        public string NomineeAddressTypeCode { get; set; }
        public string NomineeAddress1 { get; set; }
        public string NomineeAddress2 { get; set; }
        public string NomineeAddress3 { get; set; }
        public string NomineeAddress4 { get; set; }
        public string NomineePincode { get; set; }
        public string NomineePhoneNo { get; set; }
        public string NomineeFaxNo { get; set; }
        public string HolderIndicator1 { get; set; }
        public string HolderIndicator2 { get; set; }
        public string HolderIndicator3 { get; set; }
        public string POAHolderIndicator1 { get; set; }
        public string POAHolderIndicator2 { get; set; }
        public string POAHolderIndicator3 { get; set; }
        public string SignatoryID { get; set; }
        public string POAType { get; set; }
        public string POAId { get; set; }
        public string SEBIRegistration { get; set; }
        public string AuthFlagForFirstHolder { get; set; }
        public string AuthFlagForSecontHolder { get; set; }
        public string AuthFlagForThirdHolder { get; set; }
        public string CreationDate { get; set; }
        public string MappingCode { get; set; }
        public string sCin { get; set; }
        public DataTable dtClientDetails { get; set; }
        public DataSet dsXML {get; set; }
        public Boolean bDealerUpdate { get; set; }
        public Boolean bAddressUpdate { get; set; }
        public Boolean bBankUpdate { get; set; }
        string sCountry { get; set; }
        string sState { get; set; }

        public string sMsg {get; set;}

        public string sParamMsg { get; set; }

        #endregion

        #region Working Module "DPIUClientMasterData"

        public MethodExecResult DPIUClientMasterData(ref DataSet dsResultdata)
        {
            Utility.DBInitializer();

            try
            {
               

                DbWorkItem l_objPerformDBOp = new DbWorkItem(spName);
                l_objPerformDBOp.ResultType = QueryType.DataSet;
                l_objPerformDBOp.AddParameter(new SqlParameter("s_MappingCode", MappingCode));
                l_objPerformDBOp.AddParameter(new SqlParameter("BeneficiaryType", BeneficiaryType));
                l_objPerformDBOp.AddParameter(new SqlParameter("BeneficiarySubType", BeneficiarySubType));
                l_objPerformDBOp.AddParameter(new SqlParameter("BeneficiaryShortName", BeneficiaryShortName));
                l_objPerformDBOp.AddParameter(new SqlParameter("BeneficiaryOccupation", BeneficiaryOccupation));
                l_objPerformDBOp.AddParameter(new SqlParameter("BeneficiaryFirstHolderName", BeneficiaryFirstHolderName));
                l_objPerformDBOp.AddParameter(new SqlParameter("FirstHolderFatherHusbandName", FirstHolderFatherHusbandName));
                l_objPerformDBOp.AddParameter(new SqlParameter("BeneficiarySecondHolderName", BeneficiarySecondHolderName));
                l_objPerformDBOp.AddParameter(new SqlParameter("SecondHolderFatherHusbandName", SecondHolderFatherHusbandName));
                l_objPerformDBOp.AddParameter(new SqlParameter("BeneficiaryThirdHolderName", BeneficiaryThirdHolderName));
                l_objPerformDBOp.AddParameter(new SqlParameter("ThirdHolderFatherHusbandName", ThirdHolderFatherHusbandName));
                l_objPerformDBOp.AddParameter(new SqlParameter("AddresspreferenceFlag", AddresspreferenceFlag));
                l_objPerformDBOp.AddParameter(new SqlParameter("FirstHolderPAN", FirstHolderPAN));
                l_objPerformDBOp.AddParameter(new SqlParameter("SecondHolderPAN", SecondHolderPAN));
                l_objPerformDBOp.AddParameter(new SqlParameter("ThirdHolderPAN", ThirdHolderPAN));
                l_objPerformDBOp.AddParameter(new SqlParameter("NomineeGuardianIndicator", NomineeGuardianIndicator));
                l_objPerformDBOp.AddParameter(new SqlParameter("NomineeGuardianName", NomineeGuardianName));
                l_objPerformDBOp.AddParameter(new SqlParameter("NomineeMinorIndicator", NomineeMinorIndicator));
                l_objPerformDBOp.AddParameter(new SqlParameter("MinorNomineeGuardianName", MinorNomineeGuardianName));
                l_objPerformDBOp.AddParameter(new SqlParameter("DateofBirthofMinor", DateofBirthofMinor));
                l_objPerformDBOp.AddParameter(new SqlParameter("StandingInstructionIndicator", StandingInstructionIndicator));
                l_objPerformDBOp.AddParameter(new SqlParameter("BeneficiaryBankAccount", BeneficiaryBankAccount));
                l_objPerformDBOp.AddParameter(new SqlParameter("BeneficiaryBankName", BeneficiaryBankName));
                l_objPerformDBOp.AddParameter(new SqlParameter("IFSC", IFSC));
                l_objPerformDBOp.AddParameter(new SqlParameter("BeneficiaryRBIReferenceNo", BeneficiaryRBIReferenceNo));
                l_objPerformDBOp.AddParameter(new SqlParameter("BeneficiaryRBIApprovalDate", BeneficiaryRBIApprovalDate));
                l_objPerformDBOp.AddParameter(new SqlParameter("BeneficiaryTaxDeductionStatus", BeneficiaryTaxDeductionStatus));
                l_objPerformDBOp.AddParameter(new SqlParameter("LocaladdressPresent", LocaladdressPresent));
                l_objPerformDBOp.AddParameter(new SqlParameter("BankAddressPresent", BankAddressPresent));
                l_objPerformDBOp.AddParameter(new SqlParameter("NomineeGuardianAddressPresent", NomineeGuardianAddressPresent));
                l_objPerformDBOp.AddParameter(new SqlParameter("MinorNomineeGuardianAddressPresent", MinorNomineeGuardianAddressPresent));
                l_objPerformDBOp.AddParameter(new SqlParameter("CorrespondenceAddressPresent", CorrespondenceAddressPresent));
                l_objPerformDBOp.AddParameter(new SqlParameter("NomineeName", NomineeName));
                l_objPerformDBOp.AddParameter(new SqlParameter("NoofFirstHolderAuthSignatories", NoofFirstHolderAuthSignatories));
                l_objPerformDBOp.AddParameter(new SqlParameter("NoofSecHolderAuthSignatories", NoofSecHolderAuthSignatories));
                l_objPerformDBOp.AddParameter(new SqlParameter("NoofThirdHolderAuthSignatories", NoofThirdHolderAuthSignatories));
                l_objPerformDBOp.AddParameter(new SqlParameter("SizeofSignature", SizeofSignature));
                l_objPerformDBOp.AddParameter(new SqlParameter("SenderReferenceNumber1", SenderReferenceNumber1));
                l_objPerformDBOp.AddParameter(new SqlParameter("SenderReferenceNumber2", SenderReferenceNumber2));
                l_objPerformDBOp.AddParameter(new SqlParameter("MICRCode", MICRCode));
                l_objPerformDBOp.AddParameter(new SqlParameter("BankAcctType", BankAcctType));
                l_objPerformDBOp.AddParameter(new SqlParameter("NoOfPoaMappingFirstHolder", NoOfPoaMappingFirstHolder));
                l_objPerformDBOp.AddParameter(new SqlParameter("EmailIdFirstHolder", EmailIdFirstHolder));
                l_objPerformDBOp.AddParameter(new SqlParameter("MobileNoFirstHolder", MobileNoFirstHolder));
                l_objPerformDBOp.AddParameter(new SqlParameter("SMSFacilityFirstHolder", SMSFacilityFirstHolder));
                l_objPerformDBOp.AddParameter(new SqlParameter("AuthFlagFirstHolder", AuthFlagFirstHolder));
                l_objPerformDBOp.AddParameter(new SqlParameter("PANFlagFirstHolder", PANFlagFirstHolder));
                l_objPerformDBOp.AddParameter(new SqlParameter("NoNominationFlagFirstHolder", NoNominationFlagFirstHolder));
                l_objPerformDBOp.AddParameter(new SqlParameter("NoPoaMappingSecondHolder", NoPoaMappingSecondHolder));
                l_objPerformDBOp.AddParameter(new SqlParameter("EmailIdSecondHolder", EmailIdSecondHolder));
                l_objPerformDBOp.AddParameter(new SqlParameter("MobileNoSecondHolder", MobileNoSecondHolder));
                l_objPerformDBOp.AddParameter(new SqlParameter("SMSFacilitySecondHolder", SMSFacilitySecondHolder));
                l_objPerformDBOp.AddParameter(new SqlParameter("AuthFlagSecondHolder", AuthFlagSecondHolder));
                l_objPerformDBOp.AddParameter(new SqlParameter("PANFlagSecondHolder", PANFlagSecondHolder));
                l_objPerformDBOp.AddParameter(new SqlParameter("NoPoaMappingThirdHolder", NoPoaMappingThirdHolder));
                l_objPerformDBOp.AddParameter(new SqlParameter("EmailIdThirdHolder", EmailIdThirdHolder));
                l_objPerformDBOp.AddParameter(new SqlParameter("MobileNoofThirdHolder", MobileNoofThirdHolder));
                l_objPerformDBOp.AddParameter(new SqlParameter("SMSFacilityThirdHolder", SMSFacilityThirdHolder));
                l_objPerformDBOp.AddParameter(new SqlParameter("AuthFlagThirdHolder", AuthFlagThirdHolder));
                l_objPerformDBOp.AddParameter(new SqlParameter("PANFlagThirdHolder", PANFlagThirdHolder));
                l_objPerformDBOp.AddParameter(new SqlParameter("AddressTypeCode", AddressTypeCode));
                l_objPerformDBOp.AddParameter(new SqlParameter("Address1", Address1));
                l_objPerformDBOp.AddParameter(new SqlParameter("Address2", Address2));
                l_objPerformDBOp.AddParameter(new SqlParameter("Address3", Address3));
                l_objPerformDBOp.AddParameter(new SqlParameter("Address4", Address4));
                l_objPerformDBOp.AddParameter(new SqlParameter("Pincode", Pincode));
                l_objPerformDBOp.AddParameter(new SqlParameter("PhoneNo", PhoneNo));
                l_objPerformDBOp.AddParameter(new SqlParameter("FaxNo", FaxNo));
                l_objPerformDBOp.AddParameter(new SqlParameter("CorrAddressTypeCode", CorrAddressTypeCode));
                l_objPerformDBOp.AddParameter(new SqlParameter("CorrAddress1", CorrAddress1));
                l_objPerformDBOp.AddParameter(new SqlParameter("CorrAddress2", CorrAddress2));
                l_objPerformDBOp.AddParameter(new SqlParameter("CorrAddress3", CorrAddress3));
                l_objPerformDBOp.AddParameter(new SqlParameter("CorrAddress4", CorrAddress4));
                l_objPerformDBOp.AddParameter(new SqlParameter("CorrPincode", CorrPincode));
                l_objPerformDBOp.AddParameter(new SqlParameter("CorrPhoneNo", CorrPhoneNo));
                l_objPerformDBOp.AddParameter(new SqlParameter("CorrFaxNo", CorrFaxNo));
                l_objPerformDBOp.AddParameter(new SqlParameter("NomineeAddressTypeCode", NomineeAddressTypeCode));
                l_objPerformDBOp.AddParameter(new SqlParameter("NomineeAddress1", NomineeAddress1));
                l_objPerformDBOp.AddParameter(new SqlParameter("NomineeAddress2", NomineeAddress2));
                l_objPerformDBOp.AddParameter(new SqlParameter("NomineeAddress3", NomineeAddress3));
                l_objPerformDBOp.AddParameter(new SqlParameter("NomineeAddress4", NomineeAddress4));
                l_objPerformDBOp.AddParameter(new SqlParameter("NomineePincode", NomineePincode));
                l_objPerformDBOp.AddParameter(new SqlParameter("NomineePhoneNo", NomineePhoneNo));
                l_objPerformDBOp.AddParameter(new SqlParameter("NomineeFaxNo", NomineeFaxNo));
                l_objPerformDBOp.AddParameter(new SqlParameter("HolderIndicator1", HolderIndicator1));
                l_objPerformDBOp.AddParameter(new SqlParameter("HolderIndicator2", HolderIndicator2));
                l_objPerformDBOp.AddParameter(new SqlParameter("HolderIndicator3", HolderIndicator3));
                l_objPerformDBOp.AddParameter(new SqlParameter("POAHolderIndicator1", POAHolderIndicator1));
                l_objPerformDBOp.AddParameter(new SqlParameter("POAHolderIndicator2", POAHolderIndicator2));
                l_objPerformDBOp.AddParameter(new SqlParameter("POAHolderIndicator3", POAHolderIndicator3));
                l_objPerformDBOp.AddParameter(new SqlParameter("SignatoryID", SignatoryID));
                l_objPerformDBOp.AddParameter(new SqlParameter("POAType", POAType));
                l_objPerformDBOp.AddParameter(new SqlParameter("POAId", POAId));
                l_objPerformDBOp.AddParameter(new SqlParameter("SEBIRegistration", SEBIRegistration));
                l_objPerformDBOp.AddParameter(new SqlParameter("AuthFlagForFirstHolder", AuthFlagForFirstHolder));
                l_objPerformDBOp.AddParameter(new SqlParameter("AuthFlagForSecontHolder", AuthFlagForSecontHolder));
                l_objPerformDBOp.AddParameter(new SqlParameter("AuthFlagForThirdHolder", AuthFlagForThirdHolder));
                l_objPerformDBOp.AddParameter(new SqlParameter("CreationDate", CreationDate));

                l_objPerformDBOp.AddParameter(new SqlParameter("UserNo", this.m_UserNo));

                l_objPerformDBOp.AddParameter(new SqlParameter("Country", this.sCountry));
                l_objPerformDBOp.AddParameter(new SqlParameter("State", this.sState));
                l_objPerformDBOp.AddParameter(new SqlParameter("bDealerUpdate", this.bDealerUpdate));
                l_objPerformDBOp.AddParameter(new SqlParameter("bAddressUpdate", this.bAddressUpdate));
                l_objPerformDBOp.AddParameter(new SqlParameter("bBankUpdate", this.bBankUpdate));


                DbManager.Instance.ExecuteDbTask(l_objPerformDBOp);

                if (l_objPerformDBOp.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {

                    dsResultdata = l_objPerformDBOp.Result as DataSet;
                    if ((dsResultdata != null) && (dsResultdata.Tables.Count != 0))
                    {
                        return new MethodExecResult(-1, null, "No recordset returned from database.", null);
                    }

                    return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, "Successfull", null);
                }
                else
                {
                    // Logger.Instance.WriteLog(typeof(CGroupManagementMaster), objdbwork.ExecutionStatus);
                    return l_objPerformDBOp.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                //Logger.Instance.WriteLog(typeof(CGroupManagementMaster), ex.Message);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }
        }
        #endregion


        public void setData()
        {
           
            try
            {
                 //DataTable dtClientDetails = dsXML.Tables[0];
                this.n_ClientNo = dtClientDetails.DefaultView[0][CDPNSDLClientsData.N_CLIENTNO].ToString();
                this.BeneficiaryType = dtClientDetails.DefaultView[0][CDPNSDLClientsData.BENEFICIARYTYPE].ToString();
                this.BeneficiarySubType = dtClientDetails.DefaultView[0][CDPNSDLClientsData.BENEFICIARYSUBTYPE].ToString();
                this.BeneficiaryOccupation = dtClientDetails.DefaultView[0][CDPNSDLClientsData.BENEFICIARYOCCUPATION].ToString();
                this.BeneficiaryFirstHolderName = dtClientDetails.DefaultView[0][CDPNSDLClientsData.BENEFICIARYFIRSTHOLDERNAME].ToString();
                this.FirstHolderFatherHusbandName = dtClientDetails.DefaultView[0][CDPNSDLClientsData.FIRSTHOLDERFATHERHUSBANDNAME].ToString();
                this.BeneficiarySecondHolderName = dtClientDetails.DefaultView[0][CDPNSDLClientsData.BENEFICIARYSECONDHOLDERNAME].ToString();
                this.SecondHolderFatherHusbandName = dtClientDetails.DefaultView[0][CDPNSDLClientsData.SECONDHOLDERFATHERHUSBANDNAME].ToString();
                this.BeneficiaryThirdHolderName = dtClientDetails.DefaultView[0][CDPNSDLClientsData.BENEFICIARYTHIRDHOLDERNAME].ToString();
                this.ThirdHolderFatherHusbandName = dtClientDetails.DefaultView[0][CDPNSDLClientsData.THIRDHOLDERFATHERHUSBANDNAME].ToString();
                this.AddresspreferenceFlag = dtClientDetails.DefaultView[0][CDPNSDLClientsData.ADDRESSPREFERENCEFLAG].ToString();
                this.FirstHolderPAN = dtClientDetails.DefaultView[0][CDPNSDLClientsData.FIRSTHOLDERPAN].ToString();
                this.SecondHolderPAN = dtClientDetails.DefaultView[0][CDPNSDLClientsData.SECONDHOLDERPAN].ToString();
                this.ThirdHolderPAN = dtClientDetails.DefaultView[0][CDPNSDLClientsData.THIRDHOLDERPAN].ToString();
                this.NomineeGuardianIndicator = dtClientDetails.DefaultView[0][CDPNSDLClientsData.NOMINEEGUARDIANINDICATOR].ToString();
                this.NomineeGuardianName = dtClientDetails.DefaultView[0][CDPNSDLClientsData.NOMINEEGUARDIANNAME].ToString();
                this.NomineeMinorIndicator = dtClientDetails.DefaultView[0][CDPNSDLClientsData.NOMINEEMINORINDICATOR].ToString();
                this.MinorNomineeGuardianName = dtClientDetails.DefaultView[0][CDPNSDLClientsData.MINORNOMINEEGUARDIANNAME].ToString();
                this.DateofBirthofMinor = dtClientDetails.DefaultView[0][CDPNSDLClientsData.DATEOFBIRTHOFMINOR].ToString();
                this.StandingInstructionIndicator = dtClientDetails.DefaultView[0][CDPNSDLClientsData.STANDINGINSTRUCTIONINDICATOR].ToString();
                this.BeneficiaryBankAccount = dtClientDetails.DefaultView[0][CDPNSDLClientsData.BENEFICIARYBANKACCOUNT].ToString();
                this.BeneficiaryBankName = dtClientDetails.DefaultView[0][CDPNSDLClientsData.BENEFICIARYBANKNAME].ToString();
                this.IFSC = dtClientDetails.DefaultView[0][CDPNSDLClientsData.IFSCNO].ToString();
                this.BeneficiaryRBIReferenceNo = dtClientDetails.DefaultView[0][CDPNSDLClientsData.BENEFICIARYRBIREFERENCENO].ToString();
                this.BeneficiaryRBIApprovalDate = dtClientDetails.DefaultView[0][CDPNSDLClientsData.BENEFICIARYRBIAPPROVALDATE].ToString();
                this.BeneficiaryTaxDeductionStatus = dtClientDetails.DefaultView[0][CDPNSDLClientsData.BENEFICIARYTAXDEDUCTIONSTATUS].ToString();
                this.LocaladdressPresent = dtClientDetails.DefaultView[0][CDPNSDLClientsData.LOCALADDRESSPRESENT].ToString();
                this.BankAddressPresent = dtClientDetails.DefaultView[0][CDPNSDLClientsData.BANKADDRESSPRESENT].ToString();
                this.NomineeGuardianAddressPresent = dtClientDetails.DefaultView[0][CDPNSDLClientsData.NOMINEEGUARDIANADDRESSPRESENT].ToString();
                this.MinorNomineeGuardianAddressPresent = dtClientDetails.DefaultView[0][CDPNSDLClientsData.N_CLIENTNO].ToString();
                this.CorrespondenceAddressPresent = dtClientDetails.DefaultView[0][CDPNSDLClientsData.CORRESPONDENCEADDRESSPRESENT].ToString();
                this.NomineeName = dtClientDetails.DefaultView[0][CDPNSDLClientsData.NOMINEENAME].ToString();
                this.NoofFirstHolderAuthSignatories = dtClientDetails.DefaultView[0][CDPNSDLClientsData.NOOFFIRSTHOLDERAUTHSIGNATORIES].ToString();
                this.NoofSecHolderAuthSignatories = dtClientDetails.DefaultView[0][CDPNSDLClientsData.NOOFSECHOLDERAUTHSIGNATORIES].ToString();
                this.NoofThirdHolderAuthSignatories = dtClientDetails.DefaultView[0][CDPNSDLClientsData.NOOFTHIRDHOLDERAUTHSIGNATORIES].ToString();
                this.SizeofSignature = dtClientDetails.DefaultView[0][CDPNSDLClientsData.SIZEOFSIGNATURE].ToString();
                this.SenderReferenceNumber1 = dtClientDetails.DefaultView[0][CDPNSDLClientsData.SENDERREFERENCENUMBER1].ToString();
                this.SenderReferenceNumber2 = dtClientDetails.DefaultView[0][CDPNSDLClientsData.SENDERREFERENCENUMBER2].ToString();
                this.MICRCode = dtClientDetails.DefaultView[0][CDPNSDLClientsData.MICRCODE].ToString();
                this.BankAcctType = dtClientDetails.DefaultView[0][CDPNSDLClientsData.BANKACCTTYPE].ToString();
                this.NoOfPoaMappingFirstHolder = dtClientDetails.DefaultView[0][CDPNSDLClientsData.NOOFPOAMAPPINGFIRSTHOLDER].ToString();
                this.EmailIdFirstHolder = dtClientDetails.DefaultView[0][CDPNSDLClientsData.EMAILIDFIRSTHOLDER].ToString();
                this.MobileNoFirstHolder = dtClientDetails.DefaultView[0][CDPNSDLClientsData.MOBILENOFIRSTHOLDER].ToString();
                this.SMSFacilityFirstHolder = dtClientDetails.DefaultView[0][CDPNSDLClientsData.SMSFACILITYFIRSTHOLDER].ToString();
                this.AuthFlagFirstHolder = dtClientDetails.DefaultView[0][CDPNSDLClientsData.AUTHFLAGFIRSTHOLDER].ToString();
                this.PANFlagFirstHolder = dtClientDetails.DefaultView[0][CDPNSDLClientsData.PANFLAGFIRSTHOLDER].ToString();
                this.NoNominationFlagFirstHolder = dtClientDetails.DefaultView[0][CDPNSDLClientsData.NONOMINATIONFLAGFIRSTHOLDER].ToString();
                this.NoPoaMappingSecondHolder = dtClientDetails.DefaultView[0][CDPNSDLClientsData.NOPOAMAPPINGSECONDHOLDER].ToString();
                this.EmailIdSecondHolder = dtClientDetails.DefaultView[0][CDPNSDLClientsData.EMAILIDSECONDHOLDER].ToString();
                this.MobileNoSecondHolder = dtClientDetails.DefaultView[0][CDPNSDLClientsData.MOBILENOSECONDHOLDER].ToString();
                this.SMSFacilitySecondHolder = dtClientDetails.DefaultView[0][CDPNSDLClientsData.SMSFACILITYSECONDHOLDER].ToString();
                this.AuthFlagSecondHolder = dtClientDetails.DefaultView[0][CDPNSDLClientsData.AUTHFLAGSECONDHOLDER].ToString();
                this.PANFlagSecondHolder = dtClientDetails.DefaultView[0][CDPNSDLClientsData.PANFLAGSECONDHOLDER].ToString();
                this.NoPoaMappingThirdHolder = dtClientDetails.DefaultView[0][CDPNSDLClientsData.NOPOAMAPPINGTHIRDHOLDER].ToString();
                this.EmailIdThirdHolder = dtClientDetails.DefaultView[0][CDPNSDLClientsData.EMAILIDTHIRDHOLDER].ToString();
                this.MobileNoofThirdHolder = dtClientDetails.DefaultView[0][CDPNSDLClientsData.MOBILENOOFTHIRDHOLDER].ToString();
                this.SMSFacilityThirdHolder = dtClientDetails.DefaultView[0][CDPNSDLClientsData.SMSFACILITYTHIRDHOLDER].ToString();
                this.AuthFlagThirdHolder = dtClientDetails.DefaultView[0][CDPNSDLClientsData.AUTHFLAGTHIRDHOLDER].ToString();
                this.PANFlagThirdHolder = dtClientDetails.DefaultView[0][CDPNSDLClientsData.PANFLAGTHIRDHOLDER].ToString();
                this.AddressTypeCode = dtClientDetails.DefaultView[0][CDPNSDLClientsData.ADDRESSTYPECODE].ToString();
                this.Address1 = dtClientDetails.DefaultView[0][CDPNSDLClientsData.ADDRESS1].ToString();
                this.Address2 = dtClientDetails.DefaultView[0][CDPNSDLClientsData.ADDRESS2].ToString();
                this.Address3 = dtClientDetails.DefaultView[0][CDPNSDLClientsData.ADDRESS3].ToString();
                this.Address4 = dtClientDetails.DefaultView[0][CDPNSDLClientsData.ADDRESS4].ToString();
                this.Pincode = dtClientDetails.DefaultView[0][CDPNSDLClientsData.PINCODE].ToString();
                this.PhoneNo = dtClientDetails.DefaultView[0][CDPNSDLClientsData.PHONENO].ToString();
                this.FaxNo = dtClientDetails.DefaultView[0][CDPNSDLClientsData.FAXNO].ToString();
                this.CorrAddressTypeCode = dtClientDetails.DefaultView[0][CDPNSDLClientsData.CORRADDRESSTYPECODE].ToString();
                this.CorrAddress1 = dtClientDetails.DefaultView[0][CDPNSDLClientsData.CORRADDRESS1].ToString();
                this.CorrAddress2 = dtClientDetails.DefaultView[0][CDPNSDLClientsData.CORRADDRESS2].ToString();
                this.CorrAddress3 = dtClientDetails.DefaultView[0][CDPNSDLClientsData.CORRADDRESS3].ToString();
                this.CorrAddress4 = dtClientDetails.DefaultView[0][CDPNSDLClientsData.CORRADDRESS4].ToString();
                this.CorrPincode = dtClientDetails.DefaultView[0][CDPNSDLClientsData.CORRPINCODE].ToString();
                this.CorrPhoneNo = dtClientDetails.DefaultView[0][CDPNSDLClientsData.CORRPHONENO].ToString();
                this.CorrFaxNo = dtClientDetails.DefaultView[0][CDPNSDLClientsData.CORRFAXNO].ToString();
                this.NomineeAddressTypeCode = dtClientDetails.DefaultView[0][CDPNSDLClientsData.NOMINEEADDRESSTYPECODE].ToString();
                this.NomineeAddress1 = dtClientDetails.DefaultView[0][CDPNSDLClientsData.NOMINEEADDRESS1].ToString();
                this.NomineeAddress2 = dtClientDetails.DefaultView[0][CDPNSDLClientsData.NOMINEEADDRESS2].ToString();
                this.NomineeAddress3 = dtClientDetails.DefaultView[0][CDPNSDLClientsData.NOMINEEADDRESS3].ToString();
                this.NomineeAddress4 = dtClientDetails.DefaultView[0][CDPNSDLClientsData.NOMINEEADDRESS4].ToString();
                this.NomineePincode = dtClientDetails.DefaultView[0][CDPNSDLClientsData.NOMINEEPINCODE].ToString();
                this.NomineePhoneNo = dtClientDetails.DefaultView[0][CDPNSDLClientsData.NOMINEEPHONENO].ToString();
                this.NomineeFaxNo = dtClientDetails.DefaultView[0][CDPNSDLClientsData.NOMINEEFAXNO].ToString();
                this.HolderIndicator1 = dtClientDetails.DefaultView[0][CDPNSDLClientsData.HOLDERINDICATOR1].ToString();
                this.HolderIndicator2 = dtClientDetails.DefaultView[0][CDPNSDLClientsData.HOLDERINDICATOR2].ToString();
                this.HolderIndicator3 = dtClientDetails.DefaultView[0][CDPNSDLClientsData.HOLDERINDICATOR3].ToString();
                this.POAHolderIndicator1 = dtClientDetails.DefaultView[0][CDPNSDLClientsData.POAHOLDERINDICATOR1].ToString();
                this.POAHolderIndicator2 = dtClientDetails.DefaultView[0][CDPNSDLClientsData.POAHOLDERINDICATOR2].ToString();
                this.POAHolderIndicator3 = dtClientDetails.DefaultView[0][CDPNSDLClientsData.POAHOLDERINDICATOR3].ToString();
                this.SignatoryID = dtClientDetails.DefaultView[0][CDPNSDLClientsData.SIGNATORYID].ToString();
                this.POAType = dtClientDetails.DefaultView[0][CDPNSDLClientsData.POATYPE].ToString();
                this.POAId = dtClientDetails.DefaultView[0][CDPNSDLClientsData.POAID].ToString();
                this.SEBIRegistration = dtClientDetails.DefaultView[0][CDPNSDLClientsData.SEBIREGISTRATION].ToString();
                this.AuthFlagForFirstHolder = dtClientDetails.DefaultView[0][CDPNSDLClientsData.AUTHFLAGFORFIRSTHOLDER].ToString();
                this.AuthFlagForSecontHolder = dtClientDetails.DefaultView[0][CDPNSDLClientsData.AUTHFLAGFORSECONTHOLDER].ToString();
                this.AuthFlagForThirdHolder = dtClientDetails.DefaultView[0][CDPNSDLClientsData.AUTHFLAGFORTHIRDHOLDER].ToString();
                this.CreationDate = dtClientDetails.DefaultView[0][CDPNSDLClientsData.CREATIONDATE].ToString();
                this.BeneficiaryShortName = dtClientDetails.DefaultView[0][CDPNSDLClientsData.BENEFICIARYSHORTNAME].ToString();
                //obj_CDPNSDLClientsData.UserNo = dtClientDetails.DefaultView[0][CDPNSDLClientsData.N_CLIENTNO].ToString();
                this.MappingCode = dtClientDetails.DefaultView[0][CDPNSDLClientsData.MAPPINGCODE].ToString();
                this.sCin = dtClientDetails.DefaultView[0][CDPNSDLClientsData.CIN].ToString();
                m_UserNo = Convert.ToInt32(dtClientDetails.DefaultView[0][CDPNSDLClientsData.USERNO]);


            }
            catch (Exception ex)
            {
            }
            
        }

        public MethodExecResult ManageData(int n_ProductNo, DataSet ds)
        {
            MethodExecResult objMethodExecResult = null;
            DataSet dsResultdata = null;
            DataSet dsTemp = null;
            try
            {
                if (n_ProductNo == 1)
                {
                    objMethodExecResult = SyncProductsMatch();
                }
                else if (n_ProductNo == 2)
                {
                    //GetAllData(ref dsResultdata);
                    // insert data import data into Match
                    objMethodExecResult = SyncMDSWEB();
                }
                else if (n_ProductNo == 17 || n_ProductNo == 18)
                {
                    GetAllData(ref dsResultdata);
                    // insert data import data into Match
                    objMethodExecResult = DPIUClientMasterData(ref dsTemp);
                }


                if (objMethodExecResult.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    Logger.Instance.WriteLog(this, "Cust Id " + SenderReferenceNumber1 + " has been imported.");
                    return objMethodExecResult; // this.sMsg; // "Successfull";

                }
                else
                    return objMethodExecResult;
               
            }

            catch (Exception ex)
            {
                return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, string.Empty, null);
            }
        }

        public MethodExecResult GetAllData(ref DataSet dsResultdata)
        {
            DbWorkItem l_objPerformDBOp = new DbWorkItem(spGetDataName);
            try
            {
                l_objPerformDBOp.ResultType = QueryType.DataSet;
                l_objPerformDBOp.AddParameter(new SqlParameter("@s_ClientCode", this.MappingCode));

                DbManager.Instance.ExecuteDbTask(l_objPerformDBOp);
            }
            catch (Exception ex)
            {
            }

            if (l_objPerformDBOp.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {

                dsResultdata = l_objPerformDBOp.Result as DataSet;
                if ((dsResultdata != null) && (dsResultdata.Tables.Count != 0))
                {
                    fncCompareData(dsResultdata);
                    return new MethodExecResult(-1, null, "done.", null);
                }

                return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, string.Empty, null);
            }
            else
            {
                return l_objPerformDBOp.ExecutionStatus;
            }


        }

        private void fncCompareData( DataSet ds )
        {
           
            try
            {
                int iCount = 0;
                int iIdx = 0;
                sMsg = "";
                if (ds.Tables[0].Rows.Count == 0)
                {
                    if (dtClientDetails.DefaultView[0]["BeneficiaryFirstHolderName"].ToString() == "")
                    {
                        this.bDealerUpdate = false;
                        this.sMsg = "Name,";  //"BeneficiaryFirstHolderName|";
                       
                    }
                    else
                        this.bDealerUpdate = true;

                }
                if (ds.Tables[1].Rows.Count == 0)
                {
                    if (dtClientDetails.DefaultView[0]["BeneficiaryBankAccount"].ToString() == "" || dtClientDetails.DefaultView[0]["BankAcctType"].ToString() == "")
                    {
                        sMsg = sMsg + "Bank details";
                        this.bBankUpdate = false;
                    }
                    else
                        this.bBankUpdate = true;


                }

                if (ds.Tables[2].Rows.Count == 0)
                {
                    if (dtClientDetails.DefaultView[0]["Address1"].ToString() == "" )
                    {
                        this.bAddressUpdate = false;
                    }
                    else
                    {
                        iIdx = dtClientDetails.DefaultView[iCount]["Address4"].ToString().IndexOf(",");
                        sState = dtClientDetails.DefaultView[iCount]["Address4"].ToString().Substring(0, iIdx);
                        sCountry = dtClientDetails.DefaultView[iCount]["Address4"].ToString().Substring(iIdx + 1,
                                    (dtClientDetails.DefaultView[iCount]["Address4"].ToString().Length - (iIdx + 1)));

                        this.bAddressUpdate = true;
                    }
                }
                


                if (this.bDealerUpdate == true && this.bBankUpdate == true && this.bAddressUpdate == true) return;


                if (sMsg != "")
                {
                    sMsg = sMsg.Remove(sMsg.Length - 1, 1);
                    sMsg = sMsg + " not found.";
                }
                else sMsg = "Successfull";


                if (this.bDealerUpdate == false)
                {
                    foreach (DataRowView dw in ds.Tables[0].DefaultView)
                    {
                        if (dw["DealerName"].ToString().Trim() != dtClientDetails.DefaultView[iCount]["BeneficiaryFirstHolderName"].ToString().Trim()
                            || dw["PANNo"].ToString().Trim() != dtClientDetails.DefaultView[iCount]["FirstHolderPAN"].ToString().Trim()
                            )
                               bDealerUpdate = true;

                        iCount += 1;
                    }
                }

                if (this.bBankUpdate == false)
                {
                    iCount = 0;
                    foreach (DataRowView dw in ds.Tables[1].DefaultView)
                    {
                        if (dw["AccountCode"].ToString().Trim() != dtClientDetails.DefaultView[iCount]["BeneficiaryBankAccount"].ToString().Trim() ||
                            dw["BankAccType"].ToString().Trim() != dtClientDetails.DefaultView[iCount]["BankAcctType"].ToString().Trim()
                            )
                            bBankUpdate = true;

                        iCount += 1;
                    }
                }
                if (this.bAddressUpdate == false)
                {
                    iCount = 0;
                    foreach (DataRowView dw in ds.Tables[2].DefaultView)
                    {
                        
                        if (dtClientDetails.DefaultView[iCount]["Address4"].ToString() != "")
                        {
                            iIdx = dtClientDetails.DefaultView[iCount]["Address4"].ToString().IndexOf(",");
                            sState = dtClientDetails.DefaultView[iCount]["Address4"].ToString().Substring (0, iIdx);

                            sCountry = dtClientDetails.DefaultView[iCount]["Address4"].ToString().Substring(iIdx + 1, 
                                            (dtClientDetails.DefaultView[iCount]["Address4"].ToString().Length - (iIdx+1))
                                            );
                            
                        }

                        if (dw["AddressLine1"].ToString().Trim() != dtClientDetails.DefaultView[iCount]["Address1"].ToString().Trim() ||
                            dw["AddressLine2"].ToString().Trim() != dtClientDetails.DefaultView[iCount]["Address2"].ToString().Trim() ||
                            dw["City"].ToString().Trim() != dtClientDetails.DefaultView[iCount]["Address3"].ToString() ||
                            dw["State"].ToString() != sState ||
                            dw["Country"].ToString() != sCountry ||
                            dw["PinCode"].ToString().Trim() != dtClientDetails.DefaultView[iCount]["Pincode"].ToString().Trim() ||
                            dw["TelNo1"].ToString().Trim() != dtClientDetails.DefaultView[iCount]["PhoneNo"].ToString().Trim() ||
                            dw["FaxNo"].ToString().Trim() != dtClientDetails.DefaultView[iCount]["FaxNo"].ToString().Trim() ||
                            dw["EMailId"].ToString().Trim() != dtClientDetails.DefaultView[iCount]["EmailIdFirstHolder"].ToString().Trim() 
                            )
                            bAddressUpdate = true;

                        iCount += 1;
                    }

                }

            }
            catch (Exception ex)
            {
                sMsg = ex.Message; // "error";
            }

        }



        #region SyncProductsMatch
        /// <summary>
        /// Sync Products Map details for Match .Net
        /// </summary>
        /// <param name="nProductId">ClientNo</param>
        /// <returns>Method Execution result</returns>
        public MethodExecResult SyncProductsMatch()
        {
            int nErrorNo;
            int nEntityType;
            nEntityType = POAType == "C" ? 1 : 2;
            //DataSet dsResultdata;
            try
            {
                DbWorkItem l_objPerformDBOp = new DbWorkItem("stp_APIClient");  // Match .Net
                l_objPerformDBOp.ResultType = QueryType.DataSet;

                SqlParameter outParamErrNo = new SqlParameter("@ErrorNo", SqlDbType.Int, 8);
                outParamErrNo.Direction = ParameterDirection.Output;
                l_objPerformDBOp.AddParameter(outParamErrNo);

                SqlParameter outParamErrMsg = new SqlParameter("@ErrorDesc", SqlDbType.VarChar, 100);
                outParamErrMsg.Direction = ParameterDirection.Output;
                l_objPerformDBOp.AddParameter(outParamErrMsg);

                l_objPerformDBOp.AddParameter(new SqlParameter("ClientCode", MappingCode));
                l_objPerformDBOp.AddParameter(new SqlParameter("ClientName", BeneficiaryFirstHolderName));
                l_objPerformDBOp.AddParameter(new SqlParameter("ClientCustomerID", SenderReferenceNumber1));
                l_objPerformDBOp.AddParameter(new SqlParameter("BranchNo", 1));
                l_objPerformDBOp.AddParameter(new SqlParameter("ClientGroupNo", 68));
                l_objPerformDBOp.AddParameter(new SqlParameter("UserNo", m_UserNo));
                l_objPerformDBOp.AddParameter(new SqlParameter("EntityType", nEntityType));

                DbManager.Instance.ExecuteDbTask(l_objPerformDBOp);

                if (l_objPerformDBOp.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    if (l_objPerformDBOp.parameters[0].Value == null)
                        sMsg = "Successfull";
                    else
                    {
                        nErrorNo = Convert.ToInt32(l_objPerformDBOp.parameters[0].Value);
                        sMsg = Convert.ToString(l_objPerformDBOp.parameters[1].Value);
                        sMsg = "Successfull";
                    }

                    return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, string.Empty, null);
                }
                else
                {
                    return l_objPerformDBOp.ExecutionStatus;
                }
               
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex.Message);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);
            }
        }
        #endregion

        #region SyncProductsMatch
        /// <summary>
        /// Sync Products Map details for Match
        /// </summary>
        /// <param name="nProductId">ClientNo</param>
        /// <returns>Method Execution result</returns>
        public MethodExecResult SyncMDSWEB() 
        {
            int nErrorNo;
            string nEntityType;
            nEntityType = POAType == "C" ? "Individual" : "Non-Individual";
            //DataSet dsResultdata;
            try
            {
                string sPOA;
                sPOA = POAHolderIndicator1 == "0" ? "N" : "Y";

                DbWorkItem l_objPerformDBOp = new DbWorkItem("sp_wpClientMaster_CDD");
                l_objPerformDBOp.ResultType = QueryType.DataSet;

                SqlParameter outParamErrNo = new SqlParameter("@MPn_ErrorCode", SqlDbType.Int, 8);
                outParamErrNo.Direction = ParameterDirection.Output;
                l_objPerformDBOp.AddParameter(outParamErrNo);

                SqlParameter outParamErrMsg = new SqlParameter("@MPs_ReturnErrorMessage", SqlDbType.VarChar, 200);
                outParamErrMsg.Direction = ParameterDirection.Output;
                l_objPerformDBOp.AddParameter(outParamErrMsg);

                l_objPerformDBOp.AddParameter(new SqlParameter("@MPs_Mode", "I"));
                l_objPerformDBOp.AddParameter(new SqlParameter("@MPs_CustId", SenderReferenceNumber1));
                l_objPerformDBOp.AddParameter(new SqlParameter("@MPs_ClientCode", MappingCode));
                l_objPerformDBOp.AddParameter(new SqlParameter("@MPs_ClientName", BeneficiaryFirstHolderName));
                l_objPerformDBOp.AddParameter(new SqlParameter("@MPs_ClientType", nEntityType));
                l_objPerformDBOp.AddParameter(new SqlParameter("@MPd_CreationDate", Convert.ToDateTime(CreationDate)));
                l_objPerformDBOp.AddParameter(new SqlParameter("@MPs_PAN", FirstHolderPAN));
                l_objPerformDBOp.AddParameter(new SqlParameter("@MPs_POA", sPOA));
                l_objPerformDBOp.AddParameter(new SqlParameter("@MPs_CIN", sCin));
                l_objPerformDBOp.AddParameter(new SqlParameter("@MPn_UserNo", m_UserNo));

                DbManager.Instance.ExecuteDbTask(l_objPerformDBOp);

                if (l_objPerformDBOp.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    if (l_objPerformDBOp.parameters[0].Value == null)
                        sMsg = "Successfull";
                    else
                    {
                        nErrorNo = Convert.ToInt32(l_objPerformDBOp.parameters[0].Value);
                        sMsg = Convert.ToString(l_objPerformDBOp.parameters[1].Value);
                        if(nErrorNo==0)
                            sMsg = "Successfull";
                    }

                    return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, string.Empty, null);
                }
                else
                {
                    return l_objPerformDBOp.ExecutionStatus;
                }

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex.Message);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);
            }
        }
        #endregion

        
    }
}
