﻿using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace DailyProcess.BAL
{
   public class CProcessDetail
   {

       #region Variables

       public static readonly string MODULENAME = "s_ModuleName"; 

       public string Type
       {
           get;
           set;
       }
       
       public DateTime?  Date
       {
           get;
           set;
       }
     
       public string ClientCode
       {
           get;
           set;
       }

       public string Company
       {
           get;
           set;
       }

       public string Exchange
       {
           get;
           set;
       }

       public string ProcessName
       {
           get;
           set;
       }

       public DateTime? ToDate
       {
           get;
           set;
       }
       public string Mode
       {
           get;
           set;
       } 
       public string UserNo
       {
           get;
           set;
       }
       public string UnderlyingCode
       {
           get;
           set;
       }
       public string BillFrequency
       {
           get;
           set;
       }
       public DateTime? PostingDate
       {
           get;
           set;
       }

       public string PreparedStatement
       {
           get;
           set;
       }
       #endregion


       public CProcessDetail()
       {
       }

        #region GetProcessData
        public MethodExecResult GetProcessData(ref DataSet dsProcess)
        {
            try
            { 
                DbWorkItem objdbwork = new DbWorkItem("sp_wpProcRptWorker");
                objdbwork.ResultType = QueryType.DataSet;
                objdbwork.AddParameter(new SqlParameter("Ps_Mode", Mode));
                objdbwork.AddParameter(new SqlParameter("Pn_UserNo", UserNo)); 
                DbManager.Instance.ExecuteDbTask(objdbwork);
                
                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {

                    dsProcess = objdbwork.Result as DataSet;
                    if ((dsProcess == null) || (dsProcess.Tables.Count == 0))
                    {
                        return new MethodExecResult(-1, null, "No recordset returned from database.", null);
                    } 

                    return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, string.Empty, null);
                }
                else
                {
                    Logger.Instance.WriteLog(typeof(CProcessDetail), objdbwork.ExecutionStatus);
                    return objdbwork.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CProcessDetail), ex.Message);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }
        }

        #endregion
        public MethodExecResult GetProcessFilterData(string HelpType, ref DataSet dsProcess)
        {
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("stp_mwGetProcessFilterData1");
                objdbwork.ResultType = QueryType.DataSet;

                objdbwork.AddParameter(new SqlParameter("Pn_HelpType", HelpType));
                objdbwork.AddParameter(new SqlParameter("Pn_UserNo", UserNo));

                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {

                    dsProcess = objdbwork.Result as DataSet;
                    if ((dsProcess == null) || (dsProcess.Tables.Count == 0))
                    {
                        return new MethodExecResult(-1, null, "No recordset returned from database.", null);
                    }

                    return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, string.Empty, null);
                }
                else
                {
                    Logger.Instance.WriteLog(typeof(CProcessDetail), objdbwork.ExecutionStatus);
                    return objdbwork.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CProcessDetail), ex.Message);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }
        }
        public MethodExecResult GetDropDownData(string Type, ref DataSet dsProcess)
        {
            try
            {
                DbWorkItem objdbwork = new DbWorkItem("sp_wpFillDDLMaster");
                objdbwork.ResultType = QueryType.DataSet;

                objdbwork.AddParameter(new SqlParameter("Ps_Type", Type));
                objdbwork.AddParameter(new SqlParameter("Ps_ConditionField1", null));
                objdbwork.AddParameter(new SqlParameter("Ps_ConditionField2", null)); 
                objdbwork.AddParameter(new SqlParameter("Pn_UserNo", UserNo));

                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {

                    dsProcess = objdbwork.Result as DataSet;
                    if ((dsProcess == null) || (dsProcess.Tables.Count == 0))
                    {
                        return new MethodExecResult(-1, null, "No recordset returned from database.", null);
                    }

                    return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, string.Empty, null);
                }
                else
                {
                    Logger.Instance.WriteLog(typeof(CProcessDetail), objdbwork.ExecutionStatus);
                    return objdbwork.ExecutionStatus;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CProcessDetail), ex.Message);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null);

            }
        }

        public MethodExecResult ComputeProcess(string Mode, ref DataSet dsGrpdata)
        { 
            try
            {   
                DbWorkItem objdbwork = new DbWorkItem("sp_wpProcRptWorker");

                objdbwork.ResultType = QueryType.DataSet;

                objdbwork.AddParameter(new SqlParameter("Ps_Id",  ProcessName));
                objdbwork.AddParameter(new SqlParameter("Ps_Mode", Mode));
                objdbwork.AddParameter(new SqlParameter("Ps_PreparedStatments", PreparedStatement));
                objdbwork.AddParameter(new SqlParameter("Ps_Groups", null));
                objdbwork.AddParameter(new SqlParameter("Ps_Branches", null));
                objdbwork.AddParameter(new SqlParameter("Ps_ContractDeliveryNo", null));
                objdbwork.AddParameter(new SqlParameter("Ps_StrikePrice", ""));
                objdbwork.AddParameter(new SqlParameter("Ps_ErrorMessage", ""));
                objdbwork.AddParameter(new SqlParameter("Pn_UserNo", UserNo)); 
                objdbwork.AddParameter(new SqlParameter("Pn_Segment", null));
                objdbwork.AddParameter(new SqlParameter("Ps_Exchanges", Exchange));
                objdbwork.AddParameter(new SqlParameter("Ps_Companies", Company));
                objdbwork.AddParameter(new SqlParameter("Pn_ErrorNumber", 0));

                DbManager.Instance.ExecuteDbTask(objdbwork);

                if (objdbwork.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    dsGrpdata = objdbwork.Result as DataSet;
                    return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, string.Empty, null);
                }
                else
                {
                    Logger.Instance.WriteLog(typeof(CProcessDetail), objdbwork.ExecutionStatus);
                    return objdbwork.ExecutionStatus;
                }
            }
            catch (Exception ex)
            { 
                Logger.Instance.WriteLog(typeof(CProcessDetail), ex.Message);
                return new MethodExecResult(-1, null, "No recordset returned from database.", null); 
            } 
        }

        public MethodExecResult PrepareStatement(string UserNo, ref string Statement, DateTime? Date, string Company, string Exchange, string txtClientCode, string ddlEntityType, DateTime? ToDate, string UnderlyingCode, string BillFrequency, DateTime? PostingDate)
        {
            try
            {
                Dictionary<string, string> dictParam = new Dictionary<string, string>();
                dictParam.Add("UserNo", UserNo);
                dictParam.Add("Statement", Statement);
                dictParam.Add("Date", Date.Value.ToString());
                dictParam.Add("Company", Company);
                dictParam.Add("Exchange", Exchange);
                dictParam.Add("txtClientCode", txtClientCode);
                dictParam.Add("ddlEntityType", ddlEntityType);
                dictParam.Add("ToDate", ToDate.Value.ToString());
                dictParam.Add("UnderlyingCode", UnderlyingCode);
                dictParam.Add("PostingDate", PostingDate.Value.ToString());
                dictParam.Add("Frequency", BillFrequency); 

                int p1 = 0, p2 = 0;
                string varName, format, varValue = string.Empty;
                bool isValueQuoted = false;
                while (Statement.IndexOf('<') >= 0)
                {
                    p1 = Statement.IndexOf('<') + 1;
                    p2 = Statement.IndexOf('>', p1);

                    isValueQuoted = (Statement[p1 - 2] == '\'' && Statement[p2 + 1] == '\'');
                    varName = Statement.Substring(p1, p2 - p1);
                    p1 = varName.IndexOf('[') + 1;
                    if (p1 > 0)
                    {
                        p2 = varName.IndexOf(']');
                        format = varName.Substring(p1, p2 - p1);
                        varName = varName.Substring(0, p1 - 1);
                        if (varName == "Today")
                            varValue = DateTime.Now.ToString(format);
                        else
                            varValue = Date.Value.ToString(format);
                    }
                    else if (varName == "LoggedInUserNo")
                        varValue = UserNo;
                    else
                        varValue = dictParam.ContainsKey(varName) ? dictParam[varName] : null;

                    if (string.IsNullOrEmpty(varValue) || varValue == "-1") //BlankItem or All
                        varValue = "Null";
                    else if (varValue != "Null" && isValueQuoted)
                        varValue = "'" + varValue + "'";

                    p1 = Statement.IndexOf('<');
                    p2 = Statement.IndexOf('>') + 1;

                    p1 = isValueQuoted ? p1 - 1 : p1;
                    p2 = isValueQuoted ? p2 + 1 : p2;

                    Statement = Statement.Remove(p1, p2 - p1);
                    Statement = Statement.Insert(p1, varValue);
                }

                return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, string.Empty, null);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CProcessDetail), ex.Message);
                return new MethodExecResult(-1, null, ex.Message, null);
            }
        }
        public MethodExecResult CallComputeProcess()
        {
            string l_statement = null;
            string PrepairStatement =null; 
            string l_Mode;
            MethodExecResult objMethodExecResult = null;
            DataSet ds= null;
            try
            {
                l_Mode = "R";
                objMethodExecResult = ComputeProcess(l_Mode, ref ds);
                if (objMethodExecResult.ReturnCode == 0 && ds != null && ds.Tables[0].Rows.Count > 0)
                {
                    l_statement = ds.Tables[0].Rows[0]["s_Statements"].ToString();
                    PrepairStatement=l_statement ;
                    objMethodExecResult = PrepareStatement(UserNo, ref PrepairStatement, Date, Company, Exchange, ClientCode, "E", ToDate, UnderlyingCode,BillFrequency,PostingDate); //Exchange= "E"

                    if (objMethodExecResult.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                    {
                        l_Mode = "E";
                        objMethodExecResult = ComputeProcess(l_Mode, ref ds);

                        if (ProcessName == "CollateralValuation")
                        {
                            PrepairStatement = l_statement;
                            objMethodExecResult = PrepareStatement(UserNo, ref PrepairStatement, Date, Company, Exchange, ClientCode, "C", ToDate, UnderlyingCode, BillFrequency, PostingDate);//Client = "C"

                            if (objMethodExecResult.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                            {
                                objMethodExecResult = ComputeProcess(l_Mode, ref ds);
                            }
                        }
                    }
                }
                return objMethodExecResult;
            }
            catch(Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CProcessDetail), ex.Message);
                return objMethodExecResult;
            }
        }
   }
}


