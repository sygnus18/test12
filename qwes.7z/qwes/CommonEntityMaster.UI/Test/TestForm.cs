﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using FTIL.Match.Common.Constants;
using CommonEntityMaster.BAL;
namespace CommonEntityMaster.Test
{
    public partial class TestForm : Form
    {
        AutoCompleteStringCollection m_AutoCompleteStringCollection;
        Dictionary<string, string> m_dicMenuNameCodeMap;
        public TestForm()
        {
            InitializeComponent();
            m_AutoCompleteStringCollection = new AutoCompleteStringCollection();
        }
        private void MyTestFunction()
        {
            

            //if (!m_dicMenuNameCodeMap.ContainsKey(sDisplayText.ToUpper()))
            //    m_dicMenuNameCodeMap.Add(sDisplayText.ToUpper(), l_drMenuItemRows[l_intCounter]["MenuCode"].ToString());

            //if (!m_dicMenuNameCodeMap.ContainsKey(sDisplayText.ToUpper()))
            //    m_dicMenuNameCodeMap.Add(sDisplayText.ToUpper(), l_drMenuItemRows[l_intCounter]["MenuCode"].ToString());


        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.MyTestFunction();
        }

        private void TestForm_Load(object sender, EventArgs e)
        {
            SortedList<string, string> l_sortlstParams = new SortedList<string, string>();
            //l_sortlstParams.Add("CompanyNo", "2");
            //l_sortlstParams.Add("ExNo", "0");
            //CICMCommon.PopulateHelp(FTIL.Match.Common.AppEnvironment.AppUser.UserNo, "Client", "Client Code", "Client Name",
            //    ref CICMCommon.AutoCompleteStringCollectionClientsCode, ref CICMCommon.AutoCompleteStringCollectionClientsName, ref CICMCommon.DicClientCodeNameMap, l_sortlstParams);
            //textBox1.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            //textBox1.AutoCompleteSource = AutoCompleteSource.CustomSource;
            //textBox1.AutoCompleteCustomSource = CICMCommon.AutoCompleteStringCollectionClientsCode;

            //textBox2.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            //textBox2.AutoCompleteSource = AutoCompleteSource.CustomSource;
            //textBox2.AutoCompleteCustomSource = CICMCommon.AutoCompleteStringCollectionClientsName;

            l_sortlstParams.Add("CompanyNo", "2");
            l_sortlstParams.Add("ExNo", "0");
            l_sortlstParams.Add("CollGroupCode", "Other Securities");
            l_sortlstParams.Add("EntityCode", "RM001");
            l_sortlstParams.Add("ProcessType", "CI");
            l_sortlstParams.Add("ProcDate", "11/03/2015"); //DD/MM/YYYY
            l_sortlstParams.Add("CollType", "I"); //DD/MM/YYYY
            l_sortlstParams.Add("CollateralHead", "1"); //DD/MM/YYYY


            CommonUtils.PopulateHelp(FTIL.Match.Common.AppEnvironment.AppUser.UserNo, "Collateral", "Collateral Code", "Collateral Name",
                ref EntityManager.AutoCompleteStringCollectionCustID, ref EntityManager.AutoCompleteStringCollectionEntityName,
                ref EntityManager.DicCustomerIdNameMap, l_sortlstParams);
            textBox1.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            textBox1.AutoCompleteSource = AutoCompleteSource.CustomSource;
            textBox1.AutoCompleteCustomSource = EntityManager.AutoCompleteStringCollectionCustID;

            textBox2.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            textBox2.AutoCompleteSource = AutoCompleteSource.CustomSource;
            textBox2.AutoCompleteCustomSource = EntityManager.AutoCompleteStringCollectionEntityName;

        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    SortedList<string, string> l_Sortedlst = null;
                    l_Sortedlst = EntityManager.DicCustomerIdNameMap[textBox1.Text.ToUpper()];
                    textBox2.Text = l_Sortedlst["Collateral Name"].ToString();
                }
                catch { }
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            //if (e.KeyCode == Keys.Enter)
            //{
            //    try
            //    {
            //        IEnumerable<KeyValuePair<string, string>> l_DicOut;
            //        l_DicOut = from c in CICMCommon.DicClientCodeNameMap
            //                where  c.Value.ToUpper().Trim() == textBox2.Text.ToUpper().Trim()
            //                     select c;

            //        foreach (KeyValuePair<String, String> myKey in l_DicOut)
            //        {
            //            textBox1.Text = myKey.Key;
            //        }
            //    }
            //    catch { }
            //}
        }

       
    }
}
