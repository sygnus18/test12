namespace FTIL.Match.CDD.UI.Forms
{
    partial class frmEntityMaster : frmGridCommon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEntityMaster));
            this.dgvMasterData = new MatchCommon.CustomControls.FTTrueDBGrid();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMasterData)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvMasterData
            // 
            this.dgvMasterData.AllowUpdate = false;
            this.dgvMasterData.AlternatingRows = true;
            this.dgvMasterData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvMasterData.BackColor = System.Drawing.Color.White;
            this.dgvMasterData.FilterBar = true;
            this.dgvMasterData.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvMasterData.Images.Add(((System.Drawing.Image)(resources.GetObject("dgvMasterData.Images"))));
            this.dgvMasterData.Location = new System.Drawing.Point(0, 0);
            this.dgvMasterData.MarqueeStyle = C1.Win.C1TrueDBGrid.MarqueeEnum.HighlightRow;
            this.dgvMasterData.Name = "dgvMasterData";
            this.dgvMasterData.PreviewInfo.Location = new System.Drawing.Point(0, 0);
            this.dgvMasterData.PreviewInfo.Size = new System.Drawing.Size(0, 0);
            this.dgvMasterData.PreviewInfo.ZoomFactor = 75D;
            this.dgvMasterData.PrintInfo.PageSettings = ((System.Drawing.Printing.PageSettings)(resources.GetObject("dgvMasterData.PrintInfo.PageSettings")));
            this.dgvMasterData.RecordSelectors = false;
            this.dgvMasterData.RowHeight = 20;
            this.dgvMasterData.Size = new System.Drawing.Size(1030, 530);
            this.dgvMasterData.TabIndex = 0;
            this.dgvMasterData.Text = "UserMaster";
            // 
            // btnModify
            // 
            this.btnModify.Click += new System.EventHandler(this.btnModify_Click);
            // 
            // txtCode
            // 
            this.txtCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            // 
            // lblRecordCount
            // 
            this.lblRecordCount.Location = new System.Drawing.Point(980, 544);
            // 
            // ftLabel2
            // 
            this.ftLabel2.Location = new System.Drawing.Point(931, 544);
            // 
            // frmEntityMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(1030, 631);
            this.Name = "frmEntityMaster";
            this.Load += new System.EventHandler(this.frmEntityMaster_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMasterData)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MatchCommon.CustomControls.FTTrueDBGrid dgvMasterData;

        //private MatchCommon.CustomControls.FTTrueDBGrid dgvMasterData;



    
    }
}