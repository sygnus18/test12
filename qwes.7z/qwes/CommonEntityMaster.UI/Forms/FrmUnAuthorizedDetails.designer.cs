namespace CommonEntityMaster.UI.Forms
{
    partial class FrmUnAuthorizedDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbUnAuthoDetails = new System.Windows.Forms.GroupBox();
            this.tabChildEntities = new System.Windows.Forms.TabControl();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnUserRights = new System.Windows.Forms.Button();
            this.grbUnAuthoDetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbUnAuthoDetails
            // 
            this.grbUnAuthoDetails.BackColor = System.Drawing.Color.Gainsboro;
            this.grbUnAuthoDetails.Controls.Add(this.tabChildEntities);
            this.grbUnAuthoDetails.Location = new System.Drawing.Point(0, 0);
            this.grbUnAuthoDetails.Name = "grbUnAuthoDetails";
            this.grbUnAuthoDetails.Size = new System.Drawing.Size(756, 539);
            this.grbUnAuthoDetails.TabIndex = 0;
            this.grbUnAuthoDetails.TabStop = false;
            this.grbUnAuthoDetails.Text = "UnAuthorized Details";
            // 
            // tabChildEntities
            // 
            this.tabChildEntities.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabChildEntities.Location = new System.Drawing.Point(3, 16);
            this.tabChildEntities.Name = "tabChildEntities";
            this.tabChildEntities.SelectedIndex = 0;
            this.tabChildEntities.Size = new System.Drawing.Size(750, 520);
            this.tabChildEntities.TabIndex = 1;
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(711, 545);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(41, 21);
            this.btnClose.TabIndex = 17;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnUserRights
            // 
            this.btnUserRights.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUserRights.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnUserRights.Location = new System.Drawing.Point(596, 545);
            this.btnUserRights.Name = "btnUserRights";
            this.btnUserRights.Size = new System.Drawing.Size(94, 21);
            this.btnUserRights.TabIndex = 18;
            this.btnUserRights.Text = "&User Rights";
            this.btnUserRights.UseVisualStyleBackColor = true;
            this.btnUserRights.Click += new System.EventHandler(this.btnUserRights_Click);
            // 
            // FrmUnAuthorizedDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(756, 569);
            this.Controls.Add(this.btnUserRights);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.grbUnAuthoDetails);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmUnAuthorizedDetails";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Advance Setting Master";
            this.Load += new System.EventHandler(this.FrmUnAuthorizedDetails_Load);
            this.grbUnAuthoDetails.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbUnAuthoDetails;
        private C1.Win.C1FlexGrid.C1FlexGrid[] gridZoneDef;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnUserRights;
        private System.Windows.Forms.TabControl tabChildEntities;
    }
}