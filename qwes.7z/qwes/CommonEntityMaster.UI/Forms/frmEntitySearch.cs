﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using UCC.Class;
using C1.Win.C1FlexGrid;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;
using MatchCommon;
using FTIL.Match.CDD.BAL;
 

namespace FTIL.Match.CDD.UI.Forms
{
    /// <summary>
    /// Form for Enity Help Window
    /// </summary>
    public partial class frmEntitySearch : MatchCommon.UI.Forms.frmMatchBase
    {
        #region Types

        /// <summary>
        /// Search data
        /// </summary>
        private DataTable m_dtSearchData;

        /// <summary>
        /// Constructor
        /// </summary>
        #region Constructor
        public frmEntitySearch()
        {
            InitializeComponent();

            NotVisibleColumns = new List<string>();

            dgvSearchGrid.KeyUp += dgvSearchGrid_KeyUp;

            KeyPreview = true;

            this.dgvSearchGrid.Cols.Fixed = UIConstants.FlexGridLeftFixColumn;

       }
        #endregion

        #region Events

        /// <summary>
        /// Window load event handler. Initializes controls.
        /// Retrieves data applying search text filter.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region frmSearch_Load
        private void frmSearch_Load(object sender, EventArgs e)
        {
            PopulateLookup();
            txtSearch.Text = SearchKey;

            cboColumn.SelectedIndex = DefaultSearchColumnIndex;

            //Select default 
            if (!AllowAdvanceSearch)
            {
                PopulateGridByColumn(HelpType); 
            }

            cboColumn.Enabled = AllowAdvanceSearch;
            txtSearch.Enabled = AllowAdvanceSearch;
            btnApply.Enabled = AllowAdvanceSearch;
            btnAdd.Visible = IsAddNewEnable;

        } 
        #endregion

        /// <summary>
        /// Window shown event handler.
        /// Sets focus on grid.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region frmSearch_Shown
        private void frmSearch_Shown(object sender, System.EventArgs e)
        {
            dgvSearchGrid.Focus();
        }
        #endregion

        /// <summary>
        /// Retrieves records for specified search type applying search text filter.
        /// If only one record found, sets same as selected and closes window.
        /// </summary>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region PopulateGrid
        private long PopulateGrid()
        {
            dgvSearchGrid.DataSource = m_dtSearchData;

            //Hide columns
            if(NotVisibleColumns.Count>0)
                foreach (string col in NotVisibleColumns)
                {
                    dgvSearchGrid.Cols[col].Visible = false;
                }

            return 0;
        } 
        #endregion
         

        /// <summary>
        /// Retrieves records for specified search type applying search text filter.
        /// If only one record found, sets same as selected and closes window.
        /// </summary>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region PopulateGridByColumn
        private long PopulateGridByColumn(int HelpType=1)
        {
            if (cboColumn.SelectedItem ==null)
            {
                return 0;
            } 

            DataTable helpDataTable = null;

			CSearchHelp.GetEntityHelp(HelpType, txtSearch.Text.Trim(), cboColumn.SelectedItem.ToString(), EntityNo, ref helpDataTable, ConditionColValue);
             
            m_dtSearchData = helpDataTable;

            dgvSearchGrid.DataSource = m_dtSearchData.DefaultView;

            if (m_dtSearchData.Rows.Count == 1)
            {
                SelectedRow = dgvSearchGrid.Rows.Selected[0];
                this.DialogResult = DialogResult.OK;
                this.Close();
            }


                //Hide columns
                if (NotVisibleColumns.Count > 0)
                    foreach (string col in NotVisibleColumns)
                    {
                        dgvSearchGrid.Cols[col].Visible = false;
                    }
            
            return 0;
        }
        #endregion



   
        /// <summary>
        /// Retrieves records applying search text box filter.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnApply_Click
        private void btnApply_Click(object sender, EventArgs e)
        {
            PopulateGridByColumn(HelpType);
        } 
        #endregion

        /// <summary>
        /// Grid mouse double click event handler.
        /// Marks double clicked record as selected and closes window.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region dgvSearchGrid_DoubleClick
        private void dgvSearchGrid_DoubleClick(object sender, EventArgs e)
        {
            //HitTestInfo l_htiInfo = dgvSearchGrid.HitTest(dgvSearchGrid.PointToClient(Cursor.Position));

            //if (
            //    (l_htiInfo.Column < dgvSearchGrid.Cols.Fixed)
            //    || (l_htiInfo.Column > dgvSearchGrid.Cols.Count)
            //    || (l_htiInfo.Row < dgvSearchGrid.Rows.Fixed)
            //    || (l_htiInfo.Row > dgvSearchGrid.Rows.Count)
            //   )
            //{
            //    return;
            //}

            if (dgvSearchGrid.Rows.Selected.Count != 1)
            {
                MessageBox.Show("Select single record!!!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            SelectedRow = dgvSearchGrid.Rows.Selected[0];


            if (SelectedRow == null)
            {
                return;
            }


            this.DialogResult = DialogResult.OK;
            this.Close();
        }
        
        #endregion
        
        /// <summary>
        /// Close button click event handler
        /// Closes current window marking dialog result as Cancel
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnClose_Click
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
        #endregion

        /// <summary>
        /// Grid key up event handler.
        /// Redirects to dgvSearchGrid_DoubleClick if pressed key is ENTER
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region dgvSearchGrid_KeyUp
        private void dgvSearchGrid_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                dgvSearchGrid_DoubleClick(this, EventArgs.Empty);

            if(e.KeyCode == Keys.Escape)
                btnClose_Click(this, EventArgs.Empty);

        }
        #endregion

        /// <summary>
        /// Search text box key up event handler.
        /// Performs Apply button clicked if pressed key is ENTER.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtSearch_KeyUp
        private void txtSearch_KeyUp(object sender, KeyEventArgs e)
        {
            if ((e.KeyValue == 13) || (e.KeyValue == 9))
                btnApply_Click(this, EventArgs.Empty);
        }
        #endregion

        #endregion

        #region Methods

        /// <summary>
        /// Formats data layout of grid. Sets visible columns, their titles.
        /// </summary>
        #region FormatGrid
        private void FormatGrid()
        {
        

        } 
        #endregion

        /// <summary>
        /// Bind DropDown
        /// </summary>
        private void PopulateLookup()
        {
            cboColumn.Items.Clear();
            foreach (string item in Columns)
            {
                cboColumn.Items.Add(item);
            }
        }


        #endregion

        #region Properties

        /// <summary>
        /// Grid Selected Row
        /// </summary>
        public Row SelectedRow { get; set; }


        /// <summary>
        /// DataTable of searched Data
        /// </summary>
        public DataTable SearchDataDT
        {
            get { return m_dtSearchData; }
            set { m_dtSearchData = value; }
        }

        /// <summary>
        /// List of non visible column
        /// </summary>
        public List<string> NotVisibleColumns { get; set; }

        /// <summary>
        /// With key Data have been searched.
        /// </summary>
        public string SearchKey { get; set; }


        /// <summary>
        /// List of non visible column
        /// </summary>
        public string[] Columns { get; set; }


        /// <summary>
        /// Required Advance Search
        /// </summary>
        public bool AllowAdvanceSearch { get; set; }


        /// <summary>
        /// Default Search Column Index
        /// </summary>
        public int DefaultSearchColumnIndex { get; set; }


        /// <summary>
        /// Flag to add new Record
        /// </summary>
        public bool AddNewRecord { get; set; }


        /// <summary>
        /// EntityNo if any
        /// </summary>
        public int EntityNo { get; set; }

        /// <summary>
        /// With key Data have been searched.
        /// </summary>
        public int HelpType { get; set; }

        /// <summary>
        /// Flag to set Addnew button visible property
        /// </summary>
        public bool IsAddNewEnable { get; set; }


        /// <summary>
        /// Condition Column Value
        /// </summary>
        public string ConditionColValue { get; set; }


        #endregion

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddNewRecord = true;
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        #endregion

        private void frmEntitySearch_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) this.Close();
        }

    }
}
