﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.Common.Log;

namespace FTIL.Match.CDD.UI.Forms 
{
    public partial class frmAddColumn : Form
    {
        public int ProductNo { get; set; }
        public string sCustId { get; set; }
        public int FieldType { get; set; }
        public string FieldName { get; set; }
        public int FieldNo { get; set; }
        public int Format { get; set; }
        public int MinLen { get; set; }
        public int MaxLen { get; set; }
        public bool isMandatory { get; set; }
        private bool isEdit { get; set; }
        public string sComboVal { get; set; }

        public DataTable dtCustomization { get; set; }

        cCustomization objCustomization;
        DataSet dsResult = null;
        public frmAddColumn()
        {
            InitializeComponent();
            objCustomization = new cCustomization();
            this.KeyPreview = true;
        }

        private void frmAddColumn_Load(object sender, EventArgs e)
        {
            PopulateLookup();
        }

      

        private void frmAddColumn_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }

        /// <summary>
        /// call from details fill combo of bank tab data on load and reload. 
        /// </summary>
        protected void PopulateLookup()
        {
            try
            {
               
                objCustomization.GetCustomizationField(ProductNo, ref dsResult, sCustId);

                cboDataType.ValueMember = "n_FieldTypeNo";
                cboDataType.DisplayMember = "s_FieldTypeName";
                cboDataType.DataSource = new BindingSource(dsResult.Tables[1], null );

                DataTable dt = new DataTable();
                DataTable dtTemp = null;
                dt.Columns.Add("n_FieldFormatNo");
                dt.Columns.Add("n_FieldTypeNo");
                dt.Columns.Add("s_FieldFormatName");
                dt.Columns.Add("n_FieldMandatory");

                dtTemp = dsResult.Tables[0].Copy();
                if (this.FieldNo == 0)
                {
                   
                    DataRow[] dr = dtTemp.Select("n_FieldTypeNo = 1");
                    DataRow row;
                    for (int iCnt = 0; iCnt <= dr.Length - 1; iCnt++)
                    {
                        row = dt.NewRow();
                        row = dr[iCnt];
                        dt.Rows.Add(new object[] { row[0], row[1], row[2], row[3] });

                    }

                    cboFormat.ValueMember = "n_FieldFormatNo";
                    cboFormat.DisplayMember = "s_FieldFormatName";
                    cboFormat.DataSource = new BindingSource(dt, null);

                    cboDataType.SelectedValue = 1;
                    cboFormat.SelectedIndex = 0;
                }
                else
                {
                    DataRow[] dr = dtTemp.Select("n_FieldTypeNo = " + FieldType);
                    DataRow row;
                    for (int iCnt = 0; iCnt <= dr.Length - 1; iCnt++)
                    {
                        row = dt.NewRow();
                        row = dr[iCnt];
                        dt.Rows.Add(new object[] { row[0], row[1], row[2], row[3] });

                    }
                  
                    cboFormat.ValueMember = "n_FieldFormatNo";
                    cboFormat.DisplayMember = "s_FieldFormatName";
                    cboFormat.DataSource = new BindingSource(dt, null);
                    cboDataType.SelectedValue = FieldType;
                    cboFormat.SelectedValue  = Format;
                
                    txtFieldName.Text = FieldName;
                    txtMaxLen.Text = this.MaxLen.ToString();
                    txtMinLen.Text = this.MinLen.ToString();
                    chkIsMandatory.Checked = isMandatory;

                    isEdit = true;
                    if (cboDataType.SelectedValue.ToString() == "5")
                        cboFormat.Enabled = false;

                    this.Text = "Edit Column";
                    cboDataType.Enabled = false;
                    txtFieldName.Enabled = false;
                    txtMaxLen.Enabled = false;
                    txtMinLen.Enabled = false;

                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex.Message);
                MessageBox.Show("Unable to populate column details", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        
        }

        private void cboDataType_SelectedIndexChanged(object sender, EventArgs e)
        {

            DataTable dt = new DataTable();
            DataTable dtTemp = null;
            dt.Columns.Add("n_FieldFormatNo");
            dt.Columns.Add("n_FieldTypeNo");
            dt.Columns.Add("s_FieldFormatName");
            dt.Columns.Add("n_FieldMandatory");

            dtTemp = dsResult.Tables[0].Copy();
            DataRow[] dr = dtTemp.Select("n_FieldTypeNo =" + (cboDataType.SelectedIndex + 1));
            DataRow row;
            for (int iCnt = 0; iCnt <= dr.Length - 1; iCnt++)
            {
                row = dt.NewRow();
                row = dr[iCnt];
                dt.Rows.Add(new object[] { row[0], row[1], row[2], row[3] });

            }

            cboFormat.ValueMember = "n_FieldFormatNo";
            cboFormat.DisplayMember = "s_FieldFormatName";
            cboFormat.DataSource = new BindingSource(dt, null);

            if (cboDataType.SelectedValue.ToString() == "9")
            {
                cboFormat.Visible = false;
                txtComboVal.Visible = true;
                lblFormat.Text = "Value";
                //txtMaxLen.Enabled = false;
                //txtMinLen.Enabled = false;
                txtComboVal.Text = this.sComboVal;
            }
            else
            {

                cboFormat.Visible = true;
                txtComboVal.Visible = false;
                lblFormat.Text = "Format";
                //txtMaxLen.Enabled = true;
                //txtMinLen.Enabled = true;
            }

            if (cboDataType.SelectedValue.ToString() == "1" || cboDataType.SelectedValue.ToString() == "2")
            {
                txtMaxLen.Enabled = true;
                txtMinLen.Enabled = true;
            }
            else
            {
                txtMaxLen.Enabled = false;
                txtMinLen.Enabled = false;
            }
        }


        private void btnSave_Click(object sender, EventArgs e)
        {
           
            if (txtFieldName.Text.Trim() == "")
            {
                MessageBox.Show("Kindly fill field name.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtFieldName.Focus();
                return;
            }

            if (txtMinLen.Text == "" && (Convert.ToInt32(cboDataType.SelectedValue)== 1 ||  Convert.ToInt32(cboDataType.SelectedValue)== 2))
            {
                MessageBox.Show("Min Length can not be blank.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtMinLen.Focus();
                return;
            }

            if (txtMaxLen.Text == "" && (Convert.ToInt32(cboDataType.SelectedValue) == 1 || Convert.ToInt32(cboDataType.SelectedValue) == 2))
            {
                MessageBox.Show("Max Length can not be blank.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtMaxLen.Focus();
                return;
            }
            if ((Convert.ToInt32(cboDataType.SelectedValue) == 1 || Convert.ToInt32(cboDataType.SelectedValue) == 2) && Convert.ToInt32(txtMinLen.Text) <= 0)
            {
                MessageBox.Show("Min length Should be greater than  0 ", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtMinLen.Focus();
                return;
            }
            if ((Convert.ToInt32(cboDataType.SelectedValue) == 1 || Convert.ToInt32(cboDataType.SelectedValue) == 2)&& Convert.ToInt32(txtMaxLen.Text) <= 0)
            {
                MessageBox.Show("Max length Should be greater than  0 ", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtMaxLen.Focus();
                return;
            }
            


            objCustomization.FieldName = txtFieldName.Text;
            objCustomization.FieldType = Convert.ToInt32(cboDataType.SelectedValue);
            objCustomization.ProductNo = this.ProductNo;
            
            objCustomization.isMandatory = chkIsMandatory.Checked;
            objCustomization.sMode = this.FieldNo==0 ? "I" : "U";
            objCustomization.FieldNo = this.FieldNo;
            objCustomization.sCustId = this.sCustId;

            if (Convert.ToInt32(cboDataType.SelectedValue) == 1 || Convert.ToInt32(cboDataType.SelectedValue) == 2)
            {

                if (Convert.ToInt32(txtMaxLen.Text) < Convert.ToInt32(txtMinLen.Text))
                {
                    MessageBox.Show("Max length. should not be less than Min length.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtMaxLen.Focus();
                    return;

                }
                else
                {
                    objCustomization.MaxLen = Convert.ToInt32(txtMaxLen.Text);
                    objCustomization.MinLen = Convert.ToInt32(txtMinLen.Text);

                }
            }
            else
            {
                objCustomization.sComboVal = txtComboVal.Text;
                objCustomization.MaxLen = cboDataType.MaxLength;
                // var filer = dsResult.Tables[1].AsEnumerable().Where(i => i.Table.Columns[0].ToString() == cboDataType.SelectedValue.ToString());
                //DataView datatype = new DataView(dsResult.Tables[1]);
                //datatype.RowFilter = "n_FieldTypeNo =" + cboDataType.SelectedValue;
                foreach (DataRow dr in dsResult.Tables[1].Rows)
                {
                    int FieldTypeNo = Convert.ToInt16(dr["n_FieldTypeNo"]);
                    if (FieldTypeNo == Convert.ToInt32(cboDataType.SelectedValue))
                    {
                        objCustomization.MaxLen = Convert.ToInt32(dr["n_FieldMaxLength"]);
                        objCustomization.MinLen = Convert.ToInt32(dr["n_FieldMinLength"]);
                    }
                }

            }
            
            if(Convert.ToInt32(cboDataType.SelectedValue) != 9 )
                objCustomization.Format = Convert.ToInt32(cboFormat.SelectedValue);

            objCustomization.AddEditField(this.ProductNo);

            

            if (objCustomization.nErrorNo == 0)
            {
                objCustomization.dtCustomization = this.dtCustomization;
                objCustomization.SetDataResult();
                if(!isEdit )
                    MessageBox.Show("New column added successfully.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Column updated successfully.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            else if (objCustomization.sErrorMsg != "" && objCustomization.sErrorMsg != null)
                MessageBox.Show(objCustomization.sErrorMsg, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void txtMaxLen_KeyPress(object sender, KeyPressEventArgs e)
        {

        }


    }
}
