﻿namespace FTIL.Match.CDD.UI.Forms
{
    partial class frmFilter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmFilter));
            this.pnlFilter = new System.Windows.Forms.Panel();
            this.btnClear = new MatchCommon.CustomControls.FTButton();
            this.cboAuthStatus = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel1 = new MatchCommon.CustomControls.FTLabel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpToDate = new MatchCommon.CustomControls.FTDateTimePicker();
            this.dtpFromDate = new MatchCommon.CustomControls.FTDateTimePicker();
            this.cboEntityType = new MatchCommon.CustomControls.FTComboBox();
            this.lblReportType = new MatchCommon.CustomControls.FTLabel();
            this.btnGo = new MatchCommon.CustomControls.FTButton();
            this.txtCode = new MatchCommon.CustomControls.FTTextBox();
            this.lblCode = new MatchCommon.CustomControls.FTLabel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pnlButtons = new System.Windows.Forms.Panel();
            this.pnlFilter.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlFilter
            // 
            this.pnlFilter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlFilter.Controls.Add(this.pnlButtons);
            this.pnlFilter.Controls.Add(this.btnClear);
            this.pnlFilter.Controls.Add(this.cboAuthStatus);
            this.pnlFilter.Controls.Add(this.ftLabel1);
            this.pnlFilter.Controls.Add(this.label2);
            this.pnlFilter.Controls.Add(this.label1);
            this.pnlFilter.Controls.Add(this.dtpToDate);
            this.pnlFilter.Controls.Add(this.dtpFromDate);
            this.pnlFilter.Controls.Add(this.cboEntityType);
            this.pnlFilter.Controls.Add(this.lblReportType);
            this.pnlFilter.Controls.Add(this.btnGo);
            this.pnlFilter.Controls.Add(this.txtCode);
            this.pnlFilter.Controls.Add(this.lblCode);
            this.pnlFilter.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlFilter.Location = new System.Drawing.Point(0, 0);
            this.pnlFilter.Name = "pnlFilter";
            this.pnlFilter.Size = new System.Drawing.Size(493, 149);
            this.pnlFilter.TabIndex = 0;
            // 
            // btnClear
            // 
            this.btnClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnClear.Image = ((System.Drawing.Image)(resources.GetObject("btnClear.Image")));
            this.btnClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClear.Location = new System.Drawing.Point(298, 111);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(79, 25);
            this.btnClear.TabIndex = 74;
            this.btnClear.Text = "&Clear";
            this.btnClear.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // cboAuthStatus
            // 
            this.cboAuthStatus.BackColor = System.Drawing.Color.White;
            this.cboAuthStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboAuthStatus.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboAuthStatus.ForeColor = System.Drawing.Color.Black;
            this.cboAuthStatus.FormattingEnabled = true;
            this.cboAuthStatus.Items.AddRange(new object[] {
            "All",
            "New",
            "Updated",
            "Final"});
            this.cboAuthStatus.Location = new System.Drawing.Point(387, 47);
            this.cboAuthStatus.Name = "cboAuthStatus";
            this.cboAuthStatus.ReadOnly = false;
            this.cboAuthStatus.Size = new System.Drawing.Size(92, 21);
            this.cboAuthStatus.TabIndex = 4;
            // 
            // ftLabel1
            // 
            this.ftLabel1.AllowForeColorChange = false;
            this.ftLabel1.AutoSize = true;
            this.ftLabel1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel1.ForeColor = System.Drawing.Color.Black;
            this.ftLabel1.Location = new System.Drawing.Point(313, 50);
            this.ftLabel1.Name = "ftLabel1";
            this.ftLabel1.OverrideDefault = false;
            this.ftLabel1.Size = new System.Drawing.Size(68, 13);
            this.ftLabel1.TabIndex = 73;
            this.ftLabel1.Text = "Auth. Status";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.label2.Location = new System.Drawing.Point(163, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(9, 12);
            this.label2.TabIndex = 71;
            this.label2.Text = "-";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.label1.Location = new System.Drawing.Point(10, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 12);
            this.label1.TabIndex = 70;
            this.label1.Text = "Date";
            // 
            // dtpToDate
            // 
            this.dtpToDate.BackColor = System.Drawing.Color.White;
            this.dtpToDate.CustomFormat = "dd/MM/yyyy";
            this.dtpToDate.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.dtpToDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpToDate.Location = new System.Drawing.Point(179, 12);
            this.dtpToDate.Name = "dtpToDate";
            this.dtpToDate.ReadOnly = false;
            this.dtpToDate.ShowCheckBox = true;
            this.dtpToDate.Size = new System.Drawing.Size(92, 20);
            this.dtpToDate.TabIndex = 1;
            // 
            // dtpFromDate
            // 
            this.dtpFromDate.BackColor = System.Drawing.Color.White;
            this.dtpFromDate.CustomFormat = "dd/MM/yyyy";
            this.dtpFromDate.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.dtpFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFromDate.Location = new System.Drawing.Point(64, 12);
            this.dtpFromDate.Name = "dtpFromDate";
            this.dtpFromDate.ReadOnly = false;
            this.dtpFromDate.ShowCheckBox = true;
            this.dtpFromDate.Size = new System.Drawing.Size(92, 20);
            this.dtpFromDate.TabIndex = 0;
            // 
            // cboEntityType
            // 
            this.cboEntityType.BackColor = System.Drawing.Color.White;
            this.cboEntityType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboEntityType.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboEntityType.ForeColor = System.Drawing.Color.Black;
            this.cboEntityType.FormattingEnabled = true;
            this.cboEntityType.Items.AddRange(new object[] {
            "All",
            "Individual",
            "Non-Individual"});
            this.cboEntityType.Location = new System.Drawing.Point(387, 12);
            this.cboEntityType.Name = "cboEntityType";
            this.cboEntityType.ReadOnly = false;
            this.cboEntityType.Size = new System.Drawing.Size(92, 21);
            this.cboEntityType.TabIndex = 2;
            // 
            // lblReportType
            // 
            this.lblReportType.AllowForeColorChange = false;
            this.lblReportType.AutoSize = true;
            this.lblReportType.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblReportType.ForeColor = System.Drawing.Color.Black;
            this.lblReportType.Location = new System.Drawing.Point(313, 12);
            this.lblReportType.Name = "lblReportType";
            this.lblReportType.OverrideDefault = false;
            this.lblReportType.Size = new System.Drawing.Size(62, 13);
            this.lblReportType.TabIndex = 67;
            this.lblReportType.Text = "Entity Type";
            // 
            // btnGo
            // 
            this.btnGo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGo.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnGo.Image = ((System.Drawing.Image)(resources.GetObject("btnGo.Image")));
            this.btnGo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGo.Location = new System.Drawing.Point(400, 111);
            this.btnGo.Name = "btnGo";
            this.btnGo.Size = new System.Drawing.Size(79, 25);
            this.btnGo.TabIndex = 5;
            this.btnGo.Text = "&Apply";
            this.btnGo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGo.UseVisualStyleBackColor = true;
            this.btnGo.Click += new System.EventHandler(this.btnGo_Click);
            // 
            // txtCode
            // 
            this.txtCode.AllowAlpha = true;
            this.txtCode.AllowDot = false;
            this.txtCode.AllowedCustomCharacters = null;
            this.txtCode.AllowNonASCII = false;
            this.txtCode.AllowNumeric = true;
            this.txtCode.AllowSpace = false;
            this.txtCode.AllowSpecialChars = false;
            this.txtCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCode.FocusColor = System.Drawing.Color.LightYellow;
            this.txtCode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtCode.ForeColor = System.Drawing.Color.Black;
            this.txtCode.IsEmailID = false;
            this.txtCode.IsEmailIdValid = false;
            this.txtCode.Location = new System.Drawing.Point(64, 47);
            this.txtCode.MaxLength = 10;
            this.txtCode.Name = "txtCode";
            this.txtCode.Size = new System.Drawing.Size(207, 20);
            this.txtCode.TabIndex = 3;
            this.txtCode.Tag = "Code";
            // 
            // lblCode
            // 
            this.lblCode.AllowForeColorChange = false;
            this.lblCode.AutoSize = true;
            this.lblCode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblCode.ForeColor = System.Drawing.Color.Black;
            this.lblCode.Location = new System.Drawing.Point(10, 50);
            this.lblCode.Name = "lblCode";
            this.lblCode.OverrideDefault = false;
            this.lblCode.Size = new System.Drawing.Size(32, 13);
            this.lblCode.TabIndex = 59;
            this.lblCode.Text = "Code";
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 149);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(493, 0);
            this.panel2.TabIndex = 4;
            // 
            // pnlButtons
            // 
            this.pnlButtons.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlButtons.Location = new System.Drawing.Point(-5, 57);
            this.pnlButtons.Name = "pnlButtons";
            this.pnlButtons.Size = new System.Drawing.Size(501, 32);
            this.pnlButtons.TabIndex = 75;
            // 
            // frmFilter
            // 
            this.AcceptButton = this.btnGo;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(493, 149);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pnlFilter);
            this.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmFilter";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Entity Filter";
            this.Load += new System.EventHandler(this.frmFilter_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmFilter_KeyUp);
            this.pnlFilter.ResumeLayout(false);
            this.pnlFilter.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlFilter;
        private System.Windows.Forms.Panel panel2;
        private MatchCommon.CustomControls.FTTextBox txtCode;
        private MatchCommon.CustomControls.FTLabel lblCode;
        private MatchCommon.CustomControls.FTButton btnGo;
        private MatchCommon.CustomControls.FTComboBox cboEntityType;
        private MatchCommon.CustomControls.FTLabel lblReportType;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private MatchCommon.CustomControls.FTDateTimePicker dtpToDate;
        private MatchCommon.CustomControls.FTDateTimePicker dtpFromDate;
        private MatchCommon.CustomControls.FTComboBox cboAuthStatus;
        private MatchCommon.CustomControls.FTLabel ftLabel1;
        private MatchCommon.CustomControls.FTButton btnClear;
        private System.Windows.Forms.Panel pnlButtons;
 
    }
}