using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Collections;
using System.Windows.Forms;
using MatchCommon;
using C1.Win.C1FlexGrid;
using FTIL.Match.Common;
using FTIL.Match.Common.Log;  
using C1.Win.C1TrueDBGrid; 
using System.Security.Cryptography;
using System.Configuration;
using FTIL.Match.CDD.BAL;


/// <summary>
///================================================================================          
/// File/Class/Custom Name    : frmAuditConfig.cs
/// Base CR No.               : 
/// Author                    : Kushal Sharma
/// DateCreated               : 16/10/2014
/// Reviewd By                :
/// Description               : Audit Details UI class
///================================================================================

///================================================================================
///                           Revision History
///================================================================================          
/// Author                    :
/// Revision/CR No.           :
/// Revision Date             :
/// Reviewd By                :          
/// Reason for Revision       :
///================================================================================
/// </summary>

namespace FTIL.Match.CDD.UI.Forms
{
    public partial class frmAuditTrailPopUp : MatchCommon.UI.Forms.frmMatchBase
    {
        #region Variables
         
        BindingSource m_bsGroupMgmt; 
        CListItem l_objNewList;   
        string ErrorMsg = string.Empty;
        DataSet dsAudit = new DataSet();
        DataSet l_dsLookup;
        BindingSource bsGrp = new BindingSource();
        public string EntityType { get; set; }

        CAudittrailPopUp m_objAuditpopup;
        public CAudittrailPopUp ObjAuditpopup
        {
            get { return m_objAuditpopup; }
            set { m_objAuditpopup = value; }
        }
        
        #endregion

        #region Constructor
        public frmAuditTrailPopUp()
        {
            InitializeComponent(); 
            m_bsGroupMgmt = new BindingSource(); 
            this.KeyPreview = true; 
        } 
        #endregion

        #region frmAuditTrail_Load
        private void frmAuditTrail_Load(object sender, EventArgs e)
        {
            dgvDelete.Cols.Fixed = 0;
            //dgvUpdate.Cols.Fixed = 0;
            m_objAuditpopup.OperationType = "T";
            m_objAuditpopup.FromDate = null;
            m_objAuditpopup.ToDate = null;
            m_objAuditpopup.AuditTrailOperation(ref l_dsLookup);

            /*cboTableName.DataSource = l_dsLookup.Tables[2];
            cboTableName.DisplayMember = CAudittrail.TABLEDESCRIPTION;
            cboTableName.ValueMember = CAudittrail.VIEWNAME;*/

            DataTable l_dtStatus = l_dsLookup.Tables[2];
            cboTableName.ValueMember = "DataValue";
            cboTableName.DisplayMember = "DisplayValue";
            for (int l_intRowCounter = 0; l_intRowCounter < l_dtStatus.Rows.Count; l_intRowCounter++)
            {
                CListItem l_objNewStatus = new CListItem();
                l_objNewStatus.DataValue = l_dtStatus.Rows[l_intRowCounter][CAudittrail.VIEWNAME].ToString();
                l_objNewStatus.DisplayValue = l_dtStatus.Rows[l_intRowCounter][CAudittrail.TABLEDESCRIPTION].ToString();
                l_objNewStatus.CustomValue1 = l_dtStatus.Rows[l_intRowCounter][CAudittrail.SUBMODULENAME].ToString(); 
                cboTableName.Items.Add(l_objNewStatus);
                if (l_dtStatus.Rows[l_intRowCounter][CAudittrail.SUBMODULENAME].ToString() == m_objAuditpopup.TableDescription)
                {
                    cboTableName.SelectedItem = l_objNewStatus;
                }
            }  
            
           AuditTrailFromClientMaster();
        }

        private void AuditTrailFromClientMaster()
        {
            m_objAuditpopup.FromDate = "";
            m_objAuditpopup.ToDate = "";
            txtCode.Text = m_objAuditpopup.ClientCode;
            FillGrid();

        }
        /// <summary>
        ///  Method to fill Audit Trail Grid
        /// </summary>
        private void FillGrid()
        { 
            DataTable  dtUpdate, dtdelete;
           try
            {
                m_objAuditpopup.OperationType = "G";
                try { m_objAuditpopup.FromDate = m_objAuditpopup.FromDate; }
                catch { }

                try { m_objAuditpopup.ToDate = m_objAuditpopup.ToDate; }
                catch { }

                CListItem ddlItem = (CListItem)cboTableName.SelectedItem;
                if (ddlItem != null)
                    m_objAuditpopup.TableDescription = ddlItem.DataValue; 

                m_objAuditpopup.RecordType = null;

                m_objAuditpopup.ClientCode = txtCode.Text.ToString();

                m_objAuditpopup.AuditTrailOperation(ref dsAudit);

                if (dsAudit != null || dsAudit.Tables.Count > 0)
                {
                    dtUpdate = dtdelete = dsAudit.Tables[0];

                    dtUpdate = dsAudit.Tables[0].Copy();
                    dtUpdate.DefaultView.RowFilter = "s_ChangeNature ='Modified' ";
                    dgvUpdate.DataSource = dtUpdate.DefaultView; 

                    RefreshGridColumn(dgvUpdate);

                    dtdelete = dsAudit.Tables[0].Copy();
                    dtdelete.DefaultView.RowFilter = "s_ChangeNature ='Deleted' ";
                    dgvDelete.DataSource = dtdelete.DefaultView;

                    //RefreshGridColumn(dgvDelete);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to Open Audit Trail");
                Logger.Instance.WriteLog(typeof(frmAuditTrail), ex.Message);
                this.Close();
            }
        }

        private void RefreshGridColumn(MatchCommon.CustomControls.FTTrueDBGrid grid)
        {
            //dgvUpdate.Cols[""].Name = "";
            try
            {
                grid.Splits[0].DisplayColumns["s_ChangeNature"].Visible = false;
                grid.Splits[0].DisplayColumns["RecordType"].Visible = false;
                grid.Splits[0].DisplayColumns["d_ChangeDateTime"].DataColumn.Caption = "Modified DateTime";
                grid.Splits[0].DisplayColumns["ClientNo"].Visible = false;
                grid.Splits[0].DisplayColumns["ClientCode"].Visible = false;


                if (EntityType == CCMConstants.INDIVIDUAL)
                {
                    grid.Splits[0].DisplayColumns["Place of Incorporation"].Visible = false;
                    grid.Splits[0].DisplayColumns["CorporateId No"].Visible = false;
                    grid.Splits[0].DisplayColumns["Comm Of Business"].Visible = false;
                    grid.Splits[0].DisplayColumns["PanNo"].Visible = false;
                    grid.Splits[0].DisplayColumns["DOB"].DataColumn.Caption = "DOB";
                }
                else if (EntityType == CCMConstants.NON_INDIVIDUAL)
                {
                    grid.Splits[0].DisplayColumns["Gender"].Visible = false;
                    grid.Splits[0].DisplayColumns["Marital Status"].Visible = false;
                    grid.Splits[0].DisplayColumns["Nationality"].Visible = false;
                    grid.Splits[0].DisplayColumns["Nationality Other"].Visible = false;
                    grid.Splits[0].DisplayColumns["DOB"].DataColumn.Caption = "DOI";  
                }

                grid.Splits[0].VerticalOffset = 0;
                
            }
            catch { }

        }
         
        #endregion

      

    
        #region GetErrorMessage
        private string GetErrorMessage(DataTable p_vdtLog)
        {
            if (p_vdtLog == null)
                return "";

            if ((p_vdtLog != null) && (p_vdtLog.Rows.Count > 0))
            {
                if (p_vdtLog.Columns.Contains("ErrorMsg"))
                {
                    return p_vdtLog.Rows[0]["ErrorMsg"].ToString();
                }
            }

            return "";
        }
        #endregion
         
        #region IMasterUI Members

        #region InitGrid
        public long InitGrid()
        {
            return -1;
        }
        #endregion

        #region BindFormField
        public long BindFormField()
        {
            return -1;
        }
        #endregion
        #endregion
          
        
        private void btnClose_Click(object sender, EventArgs e)
        { 
            this.Close();
        }
         private void btnCloseHdn_Click(object sender, EventArgs e)
         {
             this.Close();
         }

         private void btnView_Click(object sender, EventArgs e)
         { 
             FillGrid();
         }
         
         private void frmAuditTrail_KeyUp(object sender, KeyEventArgs e)
         {
             if (e.KeyCode == Keys.Escape) this.Close();
         }

         private void btnExport_Click(object sender, EventArgs e)
         {
             SaveFileDialog saveFileDialog = new SaveFileDialog();
             saveFileDialog.Filter = "xls files (*.xls)|*.xls";

             saveFileDialog.FileName = "AuditExport.xls";

             DialogResult result = saveFileDialog.ShowDialog();

             if (result != DialogResult.OK)
             {
                 return;
             }
             try
             {
                 dgvUpdate.ExportToExcel(saveFileDialog.FileName);

             }
             catch (Exception)
             {
                 MessageBox.Show("Unable to export Data. ", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
             }
         } 
         
 
    }
}
