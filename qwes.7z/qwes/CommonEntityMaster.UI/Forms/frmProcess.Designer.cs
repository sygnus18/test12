﻿namespace FTIL.Match.CDD.UI.Forms
{
    partial class frmProcess
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgvProduct = new MatchCommon.CustomControls.FTDataGrid();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblTotal = new MatchCommon.CustomControls.FTLabel();
            this.lblSuccess = new MatchCommon.CustomControls.FTLabel();
            this.lblError = new MatchCommon.CustomControls.FTLabel();
            this.lblWarning = new MatchCommon.CustomControls.FTLabel();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProduct)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvProduct
            // 
            this.dgvProduct.AllowEditing = false;
            this.dgvProduct.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
            this.dgvProduct.BackColor = System.Drawing.Color.White; //System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(234)))), ((int)(((byte)(234)))));
            this.dgvProduct.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.dgvProduct.ColumnInfo = "5,1,0,0,0,95,Columns:0{Width:30;}\t";
            this.dgvProduct.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
            this.dgvProduct.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dgvProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.dgvProduct.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
            this.dgvProduct.Location = new System.Drawing.Point(0, 2);
            this.dgvProduct.Name = "dgvProduct";
            this.dgvProduct.OverrideDefault = false;
            this.dgvProduct.Rows.Count = 10;
            this.dgvProduct.Rows.DefaultSize = 19;
            this.dgvProduct.Rows.MinSize = 25;
            this.dgvProduct.RowsFilter.AddFilterRow = false;
            this.dgvProduct.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Cell;
            this.dgvProduct.Size = new System.Drawing.Size(700, 331);
            this.dgvProduct.StyleInfo = "";
            this.dgvProduct.TabIndex = 0;
            this.dgvProduct.Text = "dgvProduct";
            this.dgvProduct.Styles.EmptyArea.BackColor = System.Drawing.Color.White;

            // 
            // timer1
            // 
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lblTotal
            // 
            this.lblTotal.AllowForeColorChange = false;
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblTotal.ForeColor = System.Drawing.Color.Black;
            this.lblTotal.Location = new System.Drawing.Point(418, 341);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.OverrideDefault = false;
            this.lblTotal.Size = new System.Drawing.Size(31, 13);
            this.lblTotal.TabIndex = 54;
            this.lblTotal.Text = "Total";
            // 
            // lblSuccess
            // 
            this.lblSuccess.AllowForeColorChange = false;
            this.lblSuccess.AutoSize = true;
            this.lblSuccess.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblSuccess.ForeColor = System.Drawing.Color.Black;
            this.lblSuccess.Location = new System.Drawing.Point(418, 363);
            this.lblSuccess.Name = "lblSuccess";
            this.lblSuccess.OverrideDefault = false;
            this.lblSuccess.Size = new System.Drawing.Size(45, 13);
            this.lblSuccess.TabIndex = 55;
            this.lblSuccess.Text = "Success";
            // 
            // lblError
            // 
            this.lblError.AllowForeColorChange = false;
            this.lblError.AutoSize = true;
            this.lblError.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblError.ForeColor = System.Drawing.Color.Black;
            this.lblError.Location = new System.Drawing.Point(568, 341);
            this.lblError.Name = "lblError";
            this.lblError.OverrideDefault = false;
            this.lblError.Size = new System.Drawing.Size(31, 13);
            this.lblError.TabIndex = 56;
            this.lblError.Text = "Error";
            // 
            // lblWarning
            // 
            this.lblWarning.AllowForeColorChange = false;
            this.lblWarning.AutoSize = true;
            this.lblWarning.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblWarning.ForeColor = System.Drawing.Color.Black;
            this.lblWarning.Location = new System.Drawing.Point(568, 363);
            this.lblWarning.Name = "lblWarning";
            this.lblWarning.OverrideDefault = false;
            this.lblWarning.Size = new System.Drawing.Size(47, 13);
            this.lblWarning.TabIndex = 57;
            this.lblWarning.Text = "Warning";
            // 
            // frmProcess
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(701, 382);
            this.Controls.Add(this.lblWarning);
            this.Controls.Add(this.lblError);
            this.Controls.Add(this.lblSuccess);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.dgvProduct);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmProcess";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Process";
            this.Activated += new System.EventHandler(this.frmProcess_Activated);
            this.Load += new System.EventHandler(this.frmProcess_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmProcess_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProduct)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MatchCommon.CustomControls.FTDataGrid dgvProduct;
        private System.Windows.Forms.Timer timer1;
        private MatchCommon.CustomControls.FTLabel lblTotal;
        private MatchCommon.CustomControls.FTLabel lblSuccess;
        private MatchCommon.CustomControls.FTLabel lblError;
        private MatchCommon.CustomControls.FTLabel lblWarning;

    }
}