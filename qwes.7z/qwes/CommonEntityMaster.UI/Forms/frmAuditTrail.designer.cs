namespace FTIL.Match.CDD.UI.Forms
{
    partial class frmAuditTrail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAuditTrail));
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnExport = new MatchCommon.CustomControls.FTButton();
            this.grpFilter = new System.Windows.Forms.GroupBox();
            this.btnView = new MatchCommon.CustomControls.FTButton();
            this.txtCode = new MatchCommon.CustomControls.FTTextBox();
            this.lblClientCode = new System.Windows.Forms.Label();
            this.cboTableName = new MatchCommon.CustomControls.FTComboBox();
            this.lblTableName = new MatchCommon.CustomControls.FTLabel();
            this.cboOperations = new MatchCommon.CustomControls.FTComboBox();
            this.lblOperations = new MatchCommon.CustomControls.FTLabel();
            this.cboScreenName = new MatchCommon.CustomControls.FTComboBox();
            this.lblScreenName = new MatchCommon.CustomControls.FTLabel();
            this.cboModuleName = new MatchCommon.CustomControls.FTComboBox();
            this.lblModulename = new MatchCommon.CustomControls.FTLabel();
            this.txtToDate = new MatchCommon.CustomControls.FTDateTimePicker();
            this.lblToDate = new MatchCommon.CustomControls.FTLabel();
            this.txtFromDate = new MatchCommon.CustomControls.FTDateTimePicker();
            this.lblFromDate = new MatchCommon.CustomControls.FTLabel();
            this.dgvAudit = new C1.Win.C1TrueDBGrid.C1TrueDBGrid();
            this.panel2.SuspendLayout();
            this.grpFilter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAudit)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnExport);
            this.panel2.Controls.Add(this.grpFilter);
            this.panel2.Location = new System.Drawing.Point(3, 1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1144, 118);
            this.panel2.TabIndex = 54;
            // 
            // btnExport
            // 
            this.btnExport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExport.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnExport.Image = ((System.Drawing.Image)(resources.GetObject("btnExport.Image")));
            this.btnExport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExport.Location = new System.Drawing.Point(980, 63);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(84, 25);
            this.btnExport.TabIndex = 88;
            this.btnExport.Text = "&Export      ";
            this.btnExport.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Visible = false;
            // 
            // grpFilter
            // 
            this.grpFilter.Controls.Add(this.btnView);
            this.grpFilter.Controls.Add(this.txtCode);
            this.grpFilter.Controls.Add(this.lblClientCode);
            this.grpFilter.Controls.Add(this.cboTableName);
            this.grpFilter.Controls.Add(this.lblTableName);
            this.grpFilter.Controls.Add(this.cboOperations);
            this.grpFilter.Controls.Add(this.lblOperations);
            this.grpFilter.Controls.Add(this.cboScreenName);
            this.grpFilter.Controls.Add(this.lblScreenName);
            this.grpFilter.Controls.Add(this.cboModuleName);
            this.grpFilter.Controls.Add(this.lblModulename);
            this.grpFilter.Controls.Add(this.txtToDate);
            this.grpFilter.Controls.Add(this.lblToDate);
            this.grpFilter.Controls.Add(this.txtFromDate);
            this.grpFilter.Controls.Add(this.lblFromDate);
            this.grpFilter.Location = new System.Drawing.Point(3, 3);
            this.grpFilter.Name = "grpFilter";
            this.grpFilter.Size = new System.Drawing.Size(962, 105);
            this.grpFilter.TabIndex = 73;
            this.grpFilter.TabStop = false;
            this.grpFilter.Text = "Filter Criteria";
            // 
            // btnView
            // 
            this.btnView.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnView.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnView.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnView.Image = ((System.Drawing.Image)(resources.GetObject("btnView.Image")));
            this.btnView.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnView.Location = new System.Drawing.Point(824, 63);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(84, 25);
            this.btnView.TabIndex = 87;
            this.btnView.Text = "&Retrieve";
            this.btnView.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnView.UseVisualStyleBackColor = true;
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // txtCode
            // 
            this.txtCode.AllowAlpha = true;
            this.txtCode.AllowDot = false;
            this.txtCode.AllowedCustomCharacters = null;
            this.txtCode.AllowNonASCII = false;
            this.txtCode.AllowNumeric = true;
            this.txtCode.AllowSpace = false;
            this.txtCode.AllowSpecialChars = false;
            this.txtCode.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCode.FocusColor = System.Drawing.Color.LightYellow;
            this.txtCode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtCode.ForeColor = System.Drawing.Color.Black;
            this.txtCode.IsEmailID = false;
            this.txtCode.IsEmailIdValid = false;
            this.txtCode.Location = new System.Drawing.Point(587, 65);
            this.txtCode.MaxLength = 10;
            this.txtCode.Name = "txtCode";
            this.txtCode.Size = new System.Drawing.Size(129, 20);
            this.txtCode.TabIndex = 85;
            this.txtCode.Tag = "Code";
            // 
            // lblClientCode
            // 
            this.lblClientCode.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblClientCode.AutoSize = true;
            this.lblClientCode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblClientCode.Location = new System.Drawing.Point(488, 69);
            this.lblClientCode.Name = "lblClientCode";
            this.lblClientCode.Size = new System.Drawing.Size(57, 12);
            this.lblClientCode.TabIndex = 86;
            this.lblClientCode.Text = "Cilent Code";
            // 
            // cboTableName
            // 
            this.cboTableName.BackColor = System.Drawing.Color.White;
            this.cboTableName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTableName.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboTableName.ForeColor = System.Drawing.Color.Black;
            this.cboTableName.FormattingEnabled = true;
            this.cboTableName.Location = new System.Drawing.Point(118, 65);
            this.cboTableName.Name = "cboTableName";
            this.cboTableName.ReadOnly = false;
            this.cboTableName.Size = new System.Drawing.Size(129, 21);
            this.cboTableName.TabIndex = 83;
            // 
            // lblTableName
            // 
            this.lblTableName.AllowForeColorChange = false;
            this.lblTableName.AutoSize = true;
            this.lblTableName.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblTableName.ForeColor = System.Drawing.Color.Black;
            this.lblTableName.Location = new System.Drawing.Point(19, 69);
            this.lblTableName.Name = "lblTableName";
            this.lblTableName.OverrideDefault = false;
            this.lblTableName.Size = new System.Drawing.Size(92, 13);
            this.lblTableName.TabIndex = 84;
            this.lblTableName.Text = "Sub Module Name";
            // 
            // cboOperations
            // 
            this.cboOperations.BackColor = System.Drawing.Color.White;
            this.cboOperations.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboOperations.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboOperations.ForeColor = System.Drawing.Color.Black;
            this.cboOperations.FormattingEnabled = true;
            this.cboOperations.Items.AddRange(new object[] {
            "Inserted",
            "Modified",
            "Deleted"});
            this.cboOperations.Location = new System.Drawing.Point(335, 65);
            this.cboOperations.Name = "cboOperations";
            this.cboOperations.ReadOnly = false;
            this.cboOperations.Size = new System.Drawing.Size(129, 21);
            this.cboOperations.TabIndex = 4;
            // 
            // lblOperations
            // 
            this.lblOperations.AllowForeColorChange = false;
            this.lblOperations.AutoSize = true;
            this.lblOperations.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblOperations.ForeColor = System.Drawing.Color.Black;
            this.lblOperations.Location = new System.Drawing.Point(264, 69);
            this.lblOperations.Name = "lblOperations";
            this.lblOperations.OverrideDefault = false;
            this.lblOperations.Size = new System.Drawing.Size(55, 13);
            this.lblOperations.TabIndex = 82;
            this.lblOperations.Text = "Operation";
            // 
            // cboScreenName
            // 
            this.cboScreenName.BackColor = System.Drawing.Color.White;
            this.cboScreenName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboScreenName.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboScreenName.ForeColor = System.Drawing.Color.Black;
            this.cboScreenName.FormattingEnabled = true;
            this.cboScreenName.Location = new System.Drawing.Point(824, 32);
            this.cboScreenName.Name = "cboScreenName";
            this.cboScreenName.ReadOnly = false;
            this.cboScreenName.Size = new System.Drawing.Size(129, 21);
            this.cboScreenName.TabIndex = 3;
            this.cboScreenName.SelectedIndexChanged += new System.EventHandler(this.cboScreenName_SelectedIndexChanged);
            // 
            // lblScreenName
            // 
            this.lblScreenName.AllowForeColorChange = false;
            this.lblScreenName.AutoSize = true;
            this.lblScreenName.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblScreenName.ForeColor = System.Drawing.Color.Black;
            this.lblScreenName.Location = new System.Drawing.Point(733, 34);
            this.lblScreenName.Name = "lblScreenName";
            this.lblScreenName.OverrideDefault = false;
            this.lblScreenName.Size = new System.Drawing.Size(70, 13);
            this.lblScreenName.TabIndex = 79;
            this.lblScreenName.Text = "Screen Name";
            // 
            // cboModuleName
            // 
            this.cboModuleName.BackColor = System.Drawing.Color.White;
            this.cboModuleName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboModuleName.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboModuleName.ForeColor = System.Drawing.Color.Black;
            this.cboModuleName.FormattingEnabled = true;
            this.cboModuleName.Location = new System.Drawing.Point(587, 31);
            this.cboModuleName.Name = "cboModuleName";
            this.cboModuleName.ReadOnly = false;
            this.cboModuleName.Size = new System.Drawing.Size(129, 21);
            this.cboModuleName.TabIndex = 2;
            this.cboModuleName.SelectedIndexChanged += new System.EventHandler(this.cboModuleName_SelectedIndexChanged);
            // 
            // lblModulename
            // 
            this.lblModulename.AllowForeColorChange = false;
            this.lblModulename.AutoSize = true;
            this.lblModulename.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblModulename.ForeColor = System.Drawing.Color.Black;
            this.lblModulename.Location = new System.Drawing.Point(488, 34);
            this.lblModulename.Name = "lblModulename";
            this.lblModulename.OverrideDefault = false;
            this.lblModulename.Size = new System.Drawing.Size(70, 13);
            this.lblModulename.TabIndex = 77;
            this.lblModulename.Text = "Module name";
            // 
            // txtToDate
            // 
            this.txtToDate.BackColor = System.Drawing.Color.White;
            this.txtToDate.CustomFormat = "dd/MM/yyyy HH:mm";
            this.txtToDate.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.txtToDate.ForeColor = System.Drawing.Color.Black;
            this.txtToDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtToDate.Location = new System.Drawing.Point(335, 30);
            this.txtToDate.Name = "txtToDate";
            this.txtToDate.ReadOnly = false;
            this.txtToDate.Size = new System.Drawing.Size(129, 20);
            this.txtToDate.TabIndex = 1;
            this.txtToDate.Tag = "Name";
            // 
            // lblToDate
            // 
            this.lblToDate.AllowForeColorChange = false;
            this.lblToDate.AutoSize = true;
            this.lblToDate.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblToDate.ForeColor = System.Drawing.Color.Black;
            this.lblToDate.Location = new System.Drawing.Point(264, 34);
            this.lblToDate.Name = "lblToDate";
            this.lblToDate.OverrideDefault = false;
            this.lblToDate.Size = new System.Drawing.Size(45, 13);
            this.lblToDate.TabIndex = 76;
            this.lblToDate.Text = "To Date";
            // 
            // txtFromDate
            // 
            this.txtFromDate.BackColor = System.Drawing.Color.White;
            this.txtFromDate.CustomFormat = "dd/MM/yyyy HH:mm";
            this.txtFromDate.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.txtFromDate.ForeColor = System.Drawing.Color.Black;
            this.txtFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtFromDate.Location = new System.Drawing.Point(118, 30);
            this.txtFromDate.Name = "txtFromDate";
            this.txtFromDate.ReadOnly = false;
            this.txtFromDate.Size = new System.Drawing.Size(129, 20);
            this.txtFromDate.TabIndex = 0;
            this.txtFromDate.Tag = "Name";
            // 
            // lblFromDate
            // 
            this.lblFromDate.AllowForeColorChange = false;
            this.lblFromDate.AutoSize = true;
            this.lblFromDate.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblFromDate.ForeColor = System.Drawing.Color.Black;
            this.lblFromDate.Location = new System.Drawing.Point(19, 34);
            this.lblFromDate.Name = "lblFromDate";
            this.lblFromDate.OverrideDefault = false;
            this.lblFromDate.Size = new System.Drawing.Size(57, 13);
            this.lblFromDate.TabIndex = 74;
            this.lblFromDate.Text = "From Date";
            // 
            // dgvAudit
            // 
            this.dgvAudit.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvAudit.FilterBar = true;
            this.dgvAudit.Images.Add(((System.Drawing.Image)(resources.GetObject("dgvAudit.Images"))));
            this.dgvAudit.Location = new System.Drawing.Point(3, 125);
            this.dgvAudit.Name = "dgvAudit";
            this.dgvAudit.PreviewInfo.Location = new System.Drawing.Point(0, 0);
            this.dgvAudit.PreviewInfo.Size = new System.Drawing.Size(0, 0);
            this.dgvAudit.PreviewInfo.ZoomFactor = 75D;
            this.dgvAudit.PrintInfo.PageSettings = ((System.Drawing.Printing.PageSettings)(resources.GetObject("dgvAudit.PrintInfo.PageSettings")));
            this.dgvAudit.PropBag = resources.GetString("dgvAudit.PropBag");
            this.dgvAudit.Size = new System.Drawing.Size(1014, 517);
            this.dgvAudit.TabIndex = 53;
            this.dgvAudit.Text = "UserMaster";
            // 
            // frmAuditTrail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1020, 644);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.dgvAudit);
            this.MaximizeBox = false;
            this.Name = "frmAuditTrail";
            this.Text = "Client Audit Trail";
            this.Load += new System.EventHandler(this.frmAuditTrail_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmAuditTrail_KeyUp);
            this.panel2.ResumeLayout(false);
            this.grpFilter.ResumeLayout(false);
            this.grpFilter.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAudit)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Panel panel2;
        private C1.Win.C1TrueDBGrid.C1TrueDBGrid dgvAudit;
        private System.Windows.Forms.GroupBox grpFilter;
        private MatchCommon.CustomControls.FTComboBox cboScreenName;
        private MatchCommon.CustomControls.FTLabel lblScreenName;
        private MatchCommon.CustomControls.FTComboBox cboModuleName;
        private MatchCommon.CustomControls.FTLabel lblModulename;
        private MatchCommon.CustomControls.FTDateTimePicker txtToDate;
        private MatchCommon.CustomControls.FTLabel lblToDate;
        private MatchCommon.CustomControls.FTDateTimePicker txtFromDate;
        private MatchCommon.CustomControls.FTLabel lblFromDate;
        private MatchCommon.CustomControls.FTLabel lblOperations;
        private MatchCommon.CustomControls.FTComboBox cboOperations;
        private MatchCommon.CustomControls.FTComboBox cboTableName;
        private MatchCommon.CustomControls.FTLabel lblTableName;
        protected MatchCommon.CustomControls.FTTextBox txtCode;
        private System.Windows.Forms.Label lblClientCode;
        protected MatchCommon.CustomControls.FTButton btnView;
        protected MatchCommon.CustomControls.FTButton btnExport;
    }
}