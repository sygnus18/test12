﻿namespace FTIL.Match.CDD.UI.Forms
{
    partial class frmEntitySearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEntitySearch));
            this.ftTop = new MatchCommon.CustomControls.FTPanel();
            this.btnApply = new MatchCommon.CustomControls.FTButton();
            this.ftlblGender = new MatchCommon.CustomControls.FTLabel();
            this.cboColumn = new MatchCommon.CustomControls.FTComboBox();
            this.txtSearch = new MatchCommon.CustomControls.FTTextBox();
            this.pnlSearchGrid = new MatchCommon.CustomControls.FTPanel();
            this.dgvSearchGrid = new MatchCommon.CustomControls.FTDataGrid();
            this.btnAdd = new MatchCommon.CustomControls.FTButton();
            this.ftTop.SuspendLayout();
            this.pnlSearchGrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSearchGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // ftTop
            // 
            this.ftTop.Controls.Add(this.btnApply);
            this.ftTop.Controls.Add(this.ftlblGender);
            this.ftTop.Controls.Add(this.cboColumn);
            this.ftTop.Controls.Add(this.txtSearch);
            this.ftTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.ftTop.Location = new System.Drawing.Point(0, 0);
            this.ftTop.Name = "ftTop";
            this.ftTop.Size = new System.Drawing.Size(491, 49);
            this.ftTop.TabIndex = 0;
            // 
            // btnApply
            // 
            this.btnApply.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnApply.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnApply.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnApply.Image = ((System.Drawing.Image)(resources.GetObject("btnApply.Image")));
            this.btnApply.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnApply.Location = new System.Drawing.Point(408, 11);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new System.Drawing.Size(69, 25);
            this.btnApply.TabIndex = 7;
            this.btnApply.Text = "&Search";
            this.btnApply.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnApply.UseVisualStyleBackColor = true;
            this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
            // 
            // ftlblGender
            // 
            this.ftlblGender.AllowForeColorChange = false;
            this.ftlblGender.AutoSize = true;
            this.ftlblGender.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftlblGender.ForeColor = System.Drawing.Color.Black;
            this.ftlblGender.Location = new System.Drawing.Point(12, 14);
            this.ftlblGender.Name = "ftlblGender";
            this.ftlblGender.OverrideDefault = false;
            this.ftlblGender.Size = new System.Drawing.Size(42, 13);
            this.ftlblGender.TabIndex = 99;
            this.ftlblGender.Text = "Column";
            // 
            // cboColumn
            // 
            this.cboColumn.BackColor = System.Drawing.Color.White;
            this.cboColumn.DisplayMember = "1,2";
            this.cboColumn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboColumn.DropDownWidth = 90;
            this.cboColumn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboColumn.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboColumn.ForeColor = System.Drawing.Color.Black;
            this.cboColumn.FormattingEnabled = true;
            this.cboColumn.Location = new System.Drawing.Point(60, 12);
            this.cboColumn.Name = "cboColumn";
            this.cboColumn.ReadOnly = false;
            this.cboColumn.Size = new System.Drawing.Size(159, 21);
            this.cboColumn.TabIndex = 1;
            this.cboColumn.ValueMember = "M,F";
            // 
            // txtSearch
            // 
            this.txtSearch.AllowAlpha = true;
            this.txtSearch.AllowDot = true;
            this.txtSearch.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtSearch.AllowedCustomCharacters")));
            this.txtSearch.AllowNonASCII = false;
            this.txtSearch.AllowNumeric = true;
            this.txtSearch.AllowSpace = true;
            this.txtSearch.AllowSpecialChars = true;
            this.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSearch.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtSearch.FocusColor = System.Drawing.Color.LightYellow;
            this.txtSearch.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtSearch.ForeColor = System.Drawing.Color.Black;
            this.txtSearch.IsEmailID = true;
            this.txtSearch.IsEmailIdValid = false;
            this.txtSearch.Location = new System.Drawing.Point(225, 12);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(175, 20);
            this.txtSearch.TabIndex = 2;
            this.txtSearch.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtSearch_KeyUp);
            // 
            // pnlSearchGrid
            // 
            this.pnlSearchGrid.BackColor = System.Drawing.Color.Transparent;
            this.pnlSearchGrid.Controls.Add(this.dgvSearchGrid);
            this.pnlSearchGrid.Location = new System.Drawing.Point(0, 49);
            this.pnlSearchGrid.Name = "pnlSearchGrid";
            this.pnlSearchGrid.Size = new System.Drawing.Size(491, 447);
            this.pnlSearchGrid.TabIndex = 6;
            // 
            // dgvSearchGrid
            // 
            this.dgvSearchGrid.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
            this.dgvSearchGrid.AllowEditing = false;
            this.dgvSearchGrid.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
            this.dgvSearchGrid.BackColor = System.Drawing.Color.White; //System.Drawing.Color.Transparent;
            this.dgvSearchGrid.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.dgvSearchGrid.ColumnInfo = "10,1,0,0,0,85,Columns:0{Width:30;}\t";
            this.dgvSearchGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSearchGrid.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
            this.dgvSearchGrid.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dgvSearchGrid.ForeColor = System.Drawing.Color.Black;
            this.dgvSearchGrid.KeyActionEnter = C1.Win.C1FlexGrid.KeyActionEnum.None;
            this.dgvSearchGrid.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
            this.dgvSearchGrid.Location = new System.Drawing.Point(0, 0);
            this.dgvSearchGrid.Name = "dgvSearchGrid";
            this.dgvSearchGrid.OverrideDefault = false;
            this.dgvSearchGrid.Rows.Count = 1;
            this.dgvSearchGrid.Rows.DefaultSize = 17;
            this.dgvSearchGrid.Rows.MinSize = 25;
            this.dgvSearchGrid.RowsFilter.AddFilterRow = false;
            this.dgvSearchGrid.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.ListBox;
            this.dgvSearchGrid.Size = new System.Drawing.Size(491, 447);
            this.dgvSearchGrid.StyleInfo = "";
            this.dgvSearchGrid.TabIndex = 4;
            this.dgvSearchGrid.DoubleClick += new System.EventHandler(this.dgvSearchGrid_DoubleClick);

            this.dgvSearchGrid.Styles.EmptyArea.BackColor = System.Drawing.Color.White;


            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Transparent;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAdd.Location = new System.Drawing.Point(408, 502);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 25);
            this.btnAdd.TabIndex = 98;
            this.btnAdd.Text = "&Add New";
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // frmEntitySearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(491, 535);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.pnlSearchGrid);
            this.Controls.Add(this.ftTop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmEntitySearch";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Search Window";
            this.Load += new System.EventHandler(this.frmSearch_Load);
            this.Shown += new System.EventHandler(this.frmSearch_Shown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmEntitySearch_KeyUp);
            this.ftTop.ResumeLayout(false);
            this.ftTop.PerformLayout();
            this.pnlSearchGrid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSearchGrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MatchCommon.CustomControls.FTPanel ftTop;
        private MatchCommon.CustomControls.FTTextBox txtSearch;
        private MatchCommon.CustomControls.FTLabel ftlblGender;
        private MatchCommon.CustomControls.FTComboBox cboColumn;
        private MatchCommon.CustomControls.FTPanel pnlSearchGrid;
        private MatchCommon.CustomControls.FTDataGrid dgvSearchGrid;
        protected MatchCommon.CustomControls.FTButton btnApply;
        private MatchCommon.CustomControls.FTButton btnAdd;

    }
}