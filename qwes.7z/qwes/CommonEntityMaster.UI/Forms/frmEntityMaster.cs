using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Collections;
using System.Windows.Forms;
using MatchCommon;
using FTIL.Match.Common.Log;
using System.IO;
using FTIL.Match.Common;
using FTIL.Match.CDD.BAL;
using UCC.Class;
using FTIL.Match.CDD.BAL.DataClasses;


/// <summary>
///======================================================================================
/// File/Class/Custom Name    : frmEntityMaster.cs
/// Base CR No.               : 
/// Author                    : Naveen S
/// DateCreated               : 16-10-2014
/// Reviewd By                :
/// Description               : Single sign on User FTIL.UM.BusinessLayer. Pushes user to all Match products.
///=====================================================================================

///=====================================================================================
///                           Revision History
///=====================================================================================
/// Author                    :
/// Revision/CR No.           :
/// Revision Date             :
/// Reviewd By                :
/// Reason for Revision       :
///=====================================================================================
/// </summary>

namespace FTIL.Match.CDD.UI.Forms
{
 
    
    public partial class frmEntityMaster : frmGridCommon
    {
        #region Variables

        //Database interactive class object
       
        private readonly string MsgBoxTitle = "Entity Master";
        private CEntityMaster m_CEntityMaster;
        private frmFilter frmFilterObj;
        internal static int deleteFlag = 0;
     
        #endregion

        #region Constructor
        public frmEntityMaster()
        {
            InitializeComponent();
        
               this.DeleteButtonText = "Freeze       "; 
             btnExport.Visible = true;

            m_CEntityMaster = new CEntityMaster();

            dtpFromDate.Checked = false;
            dtpToDate.Checked = false;

            this.WindowName = "Customer Due Diligence";

            UIConstants.ApplicationIcon = new Icon(this.Icon, this.Icon.Width, this.Icon.Height);

         }
        #endregion


        private void frmEntityMaster_Load(object sender, EventArgs e)
        {
            this.WindowName = "Customer Due Diligence";

            if (cboEntityType.SelectedItem == null)
                cboEntityType.SelectedIndex = 0;
            ApplyFilter();
        }

        /// <summary>
        /// To filter User Data from grid
        /// </summary> 
        private void Showfilter()
        {
            try
            {
                if(frmFilterObj == null)
                    frmFilterObj = new frmFilter();

                frmFilterObj.Icon = this.Icon;
                DialogResult result = frmFilterObj.ShowDialog();
                if (result == DialogResult.OK)
                {
                    m_CEntityMaster.Code = frmFilterObj.Code;
                    m_CEntityMaster.EntityType = frmFilterObj.EntityType;
                    m_CEntityMaster.FromDate = frmFilterObj.FromDate;
                    m_CEntityMaster.ToDate = frmFilterObj.ToDate;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to fetch data ", MsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                Logger.Instance.WriteLog(this, ex.Message);
            }
        }
       


        #region RefreshData 
       
        private bool GetData()
        {

            DataTable dtResult = new DataTable();
            MethodExecResult objMethodExecResult = m_CEntityMaster.GetAllEntities(ref dtResult);
            try
            {

                if (objMethodExecResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
                {
                    string sErrorMessage = "Unable to fetch data." + Environment.NewLine + objMethodExecResult.ErrorMessage;
                    Logger.Instance.WriteLog(this, sErrorMessage);
                    MessageBox.Show(sErrorMessage, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                } 
                               
                this.SourceDataTable = m_CEntityMaster.EntityDataTable;
                this.RefreshGrid();
               
                if (this.SourceDataTable != null)
                {

  
                    //GridColumnCollection[CEntityMaster.CLIENTNO].Visible = false;
                    //GridColumnCollection[CEntityMaster.PANEXEMPT].Visible = false;
                    //GridColumnCollection[CEntityMaster.LASTUSERNO].Visible = false;
                    //GridColumnCollection[CEntityMaster.MAKERUSER].Visible = false;
                    //GridColumnCollection[CEntityMaster.NATIONALITY].Visible = false;
                    //GridColumnCollection[CEntityMaster.NATIONALITYOTHER].Visible = false;
                    //GridColumnCollection[CEntityMaster.GENDER].Visible = false;
                    //GridColumnCollection[CEntityMaster.MARITALSTATUS].Visible = false;
                    //GridColumnCollection[CEntityMaster.CLIENTTYPE].Visible = false;
                    //GridColumnCollection[CEntityMaster.NETWORTH].Visible = false;
                    //GridColumnCollection[CEntityMaster.NETWORTHASONDATE].Visible = false;
                    //GridColumnCollection[CEntityMaster.GRANNINCRANGE].Visible = false;
                    //GridColumnCollection[CEntityMaster.GRANNINCASONDATE].Visible = false;
                    //GridColumnCollection[CEntityMaster.PEP].Visible = false;
                    //GridColumnCollection[CEntityMaster.LASTMODIFIEDDATETIME].Visible = false;
                    //GridColumnCollection[CEntityMaster.LASTUSERNO].Visible = false;
                    //GridColumnCollection[CEntityMaster.TYPEOFFACILITY].Visible = false;
                    //GridColumnCollection[CEntityMaster.OCCUPATIONTEXT].Visible = false;
                    //GridColumnCollection[CEntityMaster.OCCUPATIONOTHERS].Visible = false;
                    //GridColumnCollection[CEntityMaster.ROWNO].Visible = false;
                    //GridColumnCollection[CEntityMaster.ENTITYPHOTODOCNO].Visible = false;
                    //GridColumnCollection[CEntityMaster.CLIENTCODE].Visible = false;
                    //GridColumnCollection[CEntityMaster.CLIENTTYPETEXT].Visible = false;
                    //GridColumnCollection[CEntityMaster.PLACEOFINCORPORATION].Visible = false;
                    //GridColumnCollection[CEntityMaster.OCCUPATION].Visible = false;
                    //GridColumnCollection[CEntityMaster.COMMOFBUSINESS].Visible = false;
                    //GridColumnCollection[CEntityMaster.CINEXEMPT].Visible = false;
                    //GridColumnCollection[CEntityMaster.SAMECORRPERMADD].Visible = false;
                    //GridColumnCollection[CEntityMaster.STATUSCODE].Visible = false;
                    //GridColumnCollection[CEntityMaster.STATUSOTHER].Visible = false;
                    //GridColumnCollection[CEntityMaster.PEPDESC].Visible = false;
                    //GridColumnCollection[CEntityMaster.USERID].Visible = false;
                    //GridColumnCollection[CEntityMaster.AUTHORIZATIONREMARKS].Visible = false;
                    //GridColumnCollection[CEntityMaster.GUARDIANNAME].Visible = false;
                    //GridColumnCollection[CEntityMaster.MARITALSTATUSTEXT].Visible = false;
                    //GridColumnCollection[CEntityMaster.NATIONALITYTEXT].Visible = false;
                    //GridColumnCollection[CEntityMaster.CORPORATEIDNO].Visible = false;
                    //GridColumnCollection[CEntityMaster.DOB].Visible = false;
                    //GridColumnCollection[CEntityMaster.PANNO].Visible = false;
                    //GridColumnCollection[CEntityMaster.CITY].Visible = false;

                    //GridColumnCollection[CEntityMaster.n_Solutation].Visible = false;
                    //GridColumnCollection[CEntityMaster.SEBIRegistration].Visible = false;
                    //GridColumnCollection[CEntityMaster.StandingInstruction].Visible = false;
                    //GridColumnCollection[CEntityMaster.SelfAuth].Visible = false;
                    //GridColumnCollection[CEntityMaster.sTaxDeductionStatus].Visible = false;
                    //GridColumnCollection[CEntityMaster.SubType].Visible = false;
                    //GridColumnCollection[CEntityMaster.STATUSTEXT].Visible = false;
                    //GridColumnCollection[CEntityMaster.ParentAccNo].Visible = false;
                    //GridColumnCollection[CEntityMaster.IsParentAccount].Visible = false;
                    if (m_CEntityMaster.EntityType == CCMConstants.NON_INDIVIDUAL)
                    {
                        GridColumnCollection[CEntityMaster.GENDERTEXT].Visible = false;
                        GridColumnCollection[CEntityMaster.STATUSTEXT].Visible = true;
                        GridColumnCollection[CEntityMaster.STATUSTEXT].DataColumn.Caption = "Organization Type";
                        GridColumnCollection[CEntityMaster.STATUSTEXT].Width = 120;
                    }

                    GridColumnCollection[CEntityMaster.KYCREFCODE].Visible = true ;
                    GridColumnCollection[CEntityMaster.KYCFORMREFCODE].Visible = true;
                    GridColumnCollection[CEntityMaster.CUSTID].Visible = true;
                    GridColumnCollection[CEntityMaster.CLIENTNAME].Visible = true;
                    //GridColumnCollection[CEntityMaster.CLIENTNAME].Style.WrapText = true;
                    GridColumnCollection[CEntityMaster.CLIENTTYPETEXT].Visible = true;
                    GridColumnCollection[CEntityMaster.PANNO].Visible = true;
                    GridColumnCollection[CEntityMaster.GENDERTEXT].Visible = true;
                    GridColumnCollection[CEntityMaster.CREATIONDATE].Visible = true;
                    GridColumnCollection[CEntityMaster.AUTHORIZEDSTATUS].Visible = true;



                    GridColumnCollection[CEntityMaster.KYCREFCODE].DataColumn.Caption = "CDD No.";
                    GridColumnCollection[CEntityMaster.KYCFORMREFCODE].DataColumn.Caption = "Form No.";
                    GridColumnCollection[CEntityMaster.CUSTID].DataColumn.Caption = "Cust ID";
                    GridColumnCollection[CEntityMaster.CLIENTNAME].DataColumn.Caption = "Name";
                    GridColumnCollection[CEntityMaster.PANNO].DataColumn.Caption = "PAN No";
                    GridColumnCollection[CEntityMaster.GENDERTEXT].DataColumn.Caption = "Gender";
                    GridColumnCollection[CEntityMaster.CREATIONDATE].DataColumn.Caption = "Date Of Creation";
                    GridColumnCollection[CEntityMaster.DEFAULTIDDETAILS].DataColumn.Caption = "PAN No.";
                    GridColumnCollection[CEntityMaster.CITY].DataColumn.Caption = "City";
                    GridColumnCollection[CEntityMaster.AUTHORIZEDSTATUS].DataColumn.Caption = "Authorization Status";
                    GridColumnCollection[CEntityMaster.CLIENTTYPETEXT].DataColumn.Caption = "Client Type";


                    GridColumnCollection[CEntityMaster.KYCREFCODE].Width = 155;
                    GridColumnCollection[CEntityMaster.KYCFORMREFCODE].Width = 155;
                    GridColumnCollection[CEntityMaster.CUSTID].Width = 155;
                    GridColumnCollection[CEntityMaster.CLIENTNAME].Width = 300;
                    //GridColumnCollection[CEntityMaster.CLIENTNAME].Style.WrapText = true;
                    GridColumnCollection[CEntityMaster.CLIENTTYPETEXT].Width = 200;
                    GridColumnCollection[CEntityMaster.PANNO].Width = 100;
                    GridColumnCollection[CEntityMaster.GENDERTEXT].Width = 50;
                    GridColumnCollection[CEntityMaster.CREATIONDATE].Width = 90;
                    GridColumnCollection[CEntityMaster.AUTHORIZEDSTATUS].Width = 150;


                    //////GridColumnCollection[CEntityMaster.GUARDIANNAME].DataColumn.Caption = "Guardian Name";
                    //////GridColumnCollection[CEntityMaster.MARITALSTATUSTEXT].DataColumn.Caption = "MaritalStatus";
                    //////GridColumnCollection[CEntityMaster.NATIONALITYTEXT].DataColumn.Caption = "Nationality";
                    //////GridColumnCollection[CEntityMaster.NATIONALITYOTHER].DataColumn.Caption = "s_NationalityOther";
                    //////GridColumnCollection[CEntityMaster.CORPORATEIDNO].DataColumn.Caption = "CIN";
                    //////GridColumnCollection[CEntityMaster.DOB].DataColumn.Caption = "DOB/DOI";
                    //////GridColumnCollection[CEntityMaster.NETWORTH].DataColumn.Caption = "NetWorth";
                    //////GridColumnCollection[CEntityMaster.NETWORTHASONDATE].DataColumn.Caption = "NetWorthAsOnDate";
                    //////GridColumnCollection[CEntityMaster.PLACEOFINCORPORATION].DataColumn.Caption = "PlaceofIncorporation";
                    //////GridColumnCollection[CEntityMaster.OCCUPATIONTEXT].DataColumn.Caption = "Occupation";
                    //////GridColumnCollection[CEntityMaster.COMMOFBUSINESS].DataColumn.Caption = "Business Commencement Date";
                    //////GridColumnCollection[CEntityMaster.CINEXEMPT].DataColumn.Caption = "CINExempt";

              

                    //GridColumnCollection[CEntityMaster.CUSTID].DataColumn.Caption = "Customer#";
                    //GridColumnCollection[CEntityMaster.KYCREFCODE].DataColumn.Caption = "CDD#";
                    //GridColumnCollection[CEntityMaster.KYCFORMREFCODE].DataColumn.Caption = "KYC Form#";
                    //GridColumnCollection[CEntityMaster.CLIENTTYPETEXT].DataColumn.Caption = "Client Type";
                    //GridColumnCollection[CEntityMaster.CLIENTNAME].DataColumn.Caption = "Name";
                    //GridColumnCollection[CEntityMaster.PANNO].DataColumn.Caption = "PANNo";
                    //GridColumnCollection[CEntityMaster.GENDERTEXT].DataColumn.Caption = "Gender";
                    //GridColumnCollection[CEntityMaster.GUARDIANNAME].DataColumn.Caption = "Guardian Name";
                    //GridColumnCollection[CEntityMaster.MARITALSTATUSTEXT].DataColumn.Caption = "MaritalStatus";
                    //GridColumnCollection[CEntityMaster.NATIONALITYTEXTRecords].DataColumn.Caption = "Nationality";
                    //GridColumnCollection[CEntityMaster.NATIONALITYOTHER].DataColumn.Caption = "s_NationalityOther";
                    //GridColumnCollection[CEntityMaster.CORPORATEIDNO].DataColumn.Caption = "CIN";
                    //GridColumnCollection[CEntityMaster.DOB].DataColumn.Caption = "DOB/DOI";
                    //GridColumnCollection[CEntityMaster.CREATIONDATE].DataColumn.Caption = "CreationDate";
                    //GridColumnCollection[CEntityMaster.NETWORTH].DataColumn.Caption = "NetWorth";
                    //GridColumnCollection[CEntityMaster.NETWORTHASONDATE].DataColumn.Caption = "NetWorthAsOnDate";
                    //GridColumnCollection[CEntityMaster.PLACEOFINCORPORATION].DataColumn.Caption = "PlaceofIncorporation";
                    //GridColumnCollection[CEntityMaster.OCCUPATIONTEXT].DataColumn.Caption = "Occupation";
                    //GridColumnCollection[CEntityMaster.COMMOFBUSINESS].DataColumn.Caption = "Business Commencement Date";
                    //GridColumnCollection[CEntityMaster.COMMOFBUSINESS].DataColumn.Caption = "Business Commencement Date";
                    //GridColumnCollection[CEntityMaster.CINEXEMPT].DataColumn.Caption = "CINExempt";
                    //GridColumnCollection[CEntityMaster.AUTHORIZEDSTATUS].DataColumn.Caption = "AuthorizedStatus";

                    //  this.AutoResize();
                }
                
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                string sErrorMessage = "Unable to fetch data." + Environment.NewLine + objMethodExecResult.ErrorMessage;
                MessageBox.Show(sErrorMessage, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                Logger.Instance.WriteLog(typeof(frmEntityMaster), ex.Message);
            }

            return true;
        }

        #endregion

        ///// <summary>
        ///// This function is to show popup window.
        ///// </summary>
        ///// <param name="operation"></param>
        ///// <returns></returns>
        private DialogResult ShowEntityMasterModel(string clientType, bool IsNew = true)
        {
            DialogResult result;

                frmEntityDetail frmEntityDetailsObj = new frmEntityDetail();
                frmEntityDetailsObj.Icon = this.Icon;
                frmEntityDetailsObj.StartPosition = FormStartPosition.CenterParent;

                frmEntityDetailsObj.OperationFlag = IsNew ? "S" : "M";
                this.Cursor = Cursors.WaitCursor;

                if (IsNew)
                    m_CEntityMaster = new CEntityMaster();

                frmEntityDetailsObj.EntityManagerInstance.EntityMasterInstance = m_CEntityMaster;
                frmEntityDetailsObj.EntityManagerInstance.EntityMasterInstance.EntityType = clientType;
                frmEntityDetailsObj.EntityType = clientType;
                frmEntityDetailsObj.ChangeSelectedRow += this.OnChangeSelectedRow;

                if (m_CEntityMaster.EntityDataTable == null && SourceDataTable != null)
                    m_CEntityMaster.EntityDataTable = SourceDataTable;

                if (clientType == CCMConstants.NON_INDIVIDUAL)
                {
                    frmEntityDetailsObj.AddIndividualEventHander += addToolStripMenuItem_Click;
                }


                 result = frmEntityDetailsObj.ShowDialog();
            try
            {
                if (result.ToString() == "Cancel")
                {


                }
                //ApplyFilter();
                this.Cursor = Cursors.Default;
                if (frmEntityDetailsObj.EntityManagerInstance.EntityDetails == null || frmEntityDetailsObj.EntityManagerInstance.EntityDetails.ClientNo==0) 
                    return result;

                DataTable dtEntity = new DataTable();
                DataTable dtAdd = new DataTable();
                CEntityMaster.GetEntitybyClientNo(frmEntityDetailsObj.EntityManagerInstance.EntityDetails.ClientNo, ref dtEntity, ref dtAdd);
                if (dtEntity.Rows.Count == 0)
                {
                    GetData();
                }

                if (dtEntity.Rows.Count > 0 && !IsNew)
                {
                    SourceDataTable.Rows[frmEntityDetailsObj.CurrentRowNo - 1][CEntityMaster.KYCFORMREFCODE] = dtEntity.Rows[0]["s_KYCFormRefCode"];
                    SourceDataTable.Rows[frmEntityDetailsObj.CurrentRowNo - 1][CEntityMaster.CLIENTNAME] = dtEntity.Rows[0]["s_ClientName"];
                    SourceDataTable.Rows[frmEntityDetailsObj.CurrentRowNo - 1][CEntityMaster.CLIENTTYPETEXT] = dtEntity.Rows[0]["s_ClientTypeText"];
                    SourceDataTable.Rows[frmEntityDetailsObj.CurrentRowNo - 1][CEntityMaster.GENDERTEXT] = CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.GENDER, dtEntity.Rows[0]["s_Gender"].ToString());//dtEntity.Rows[0]["s_Gender"].ToString() == "M" ? "Male" : "Female";// dtEntity.Rows[0]["s_GenderText"];
                    SourceDataTable.Rows[frmEntityDetailsObj.CurrentRowNo - 1][CEntityMaster.PANNO] = dtEntity.Rows[0]["s_PANNo"];
                    SourceDataTable.Rows[frmEntityDetailsObj.CurrentRowNo - 1][CEntityMaster.AUTHORIZEDSTATUS] = dtEntity.Rows[0][CEntityMaster.AUTHORIZEDSTATUS];
                    SourceDataTable.Rows[frmEntityDetailsObj.CurrentRowNo - 1][CEntityMaster.DEFAULTIDDETAILS] = dtEntity.Rows[0][CEntityMaster.DEFAULTIDDETAILS];
                    SourceDataTable.Rows[frmEntityDetailsObj.CurrentRowNo - 1][CEntityMaster.CITY] = dtEntity.Rows[0][CEntityMaster.CITY];

                }

                if (dtEntity.Rows.Count > 0 && IsNew)
                {
                    if(dtEntity.Rows[0]["s_Gender"].ToString() != "")
                        dtEntity.Rows[0]["s_GenderText"] = dtEntity.Rows[0]["s_Gender"].ToString() == "M" ? "Male" : "Female";
                    //SourceDataTable.Rows.Add(new object[] {SourceDataTable.Rows.Count+1,m_EntityDetails.ClientNo ,m_EntityDetails.CustomerID ,m_EntityDetails.KYCCode,m_EntityDetails.KYCFormNo,
                    //            m_EntityDetails.EntityType,m_EntityDetails.EntityId,m_EntityDetails.EntityType,m_EntityDetails.Applicant_Name,
                    //            m_EntityDetails.PAN, m_EntityDetails.Gender,m_EntityDetails.Gender,m_EntityDetails.Guardian_Name,
                    //            m_EntityDetails.Marital_status,m_EntityDetails.Marital_status,m_EntityDetails.Nationality, m_EntityDetails.Nationality,
                    //            m_EntityDetails.NationalityOther,m_EntityDetails.PAN,m_EntityDetails.CIN,m_EntityDetails.DOB_OR_DOI,
                    //             System.DateTime.Now.Date, //m_EntityDetails.DateOfCreation,
                    //            m_EntityDetails.Networth, m_EntityDetails.NetworthDate,
                    //            m_EntityDetails.AnnualIncome, m_EntityDetails.AnnualIncomeDate, m_EntityDetails.PEP, m_EntityDetails.PlaceOfIncorpration,
                    //            1, //m_EntityDetails.Occupation, 
                    //            m_EntityDetails.Occupation ,m_EntityDetails.OccupationOther, m_EntityDetails.DateOfBusinessComm,
                    //            m_EntityDetails.CIN, m_EntityDetails.FacilityType, 1,//m_EntityDetails.UserId, 
                    //            System.DateTime.Now.Date,//d_LastModifiedDateTime
                    //            0,// n_MakerUser,
                    //            "",// s_AuthorizedStatus,
                    //            m_EntityDetails.SameCorrPermAdd, 1,// n_Status,
                    //            m_EntityDetails.StatusText, m_EntityDetails.PEPDesc, m_EntityDetails.UserId, m_EntityDetails.AuthRemarks, m_EntityDetails.EntityPhotoDocNo
                    //            });

                    SourceDataTable.Rows.Add(new object[] {dtEntity.Rows[0]["s_CustId"],
                                            dtEntity.Rows[0]["s_KYCRefCode"],
                                            dtEntity.Rows[0]["s_KYCFormRefCode"],
                                            dtEntity.Rows[0]["s_ClientTypeText"],
                                            dtEntity.Rows[0]["s_ClientName"],
                                            dtEntity.Rows[0]["s_DefaultIDDetails"],
                                            dtEntity.Rows[0]["s_PANNo"],
                                            dtEntity.Rows[0]["s_Gender"],
                                            dtEntity.Rows[0]["s_GenderText"],
                                            dtEntity.Rows[0]["s_GuardianName"],
                                            dtEntity.Rows[0]["s_MaritalStatus"],
                                            dtEntity.Rows[0]["s_MaritalStatusText"],
                                            dtEntity.Rows[0]["n_Nationality"],
                                            dtEntity.Rows[0]["s_Nationality"],
                                            dtEntity.Rows[0]["s_NationalityOther"],
                                            dtEntity.Rows[0]["s_PanExempt"],
                                            dtEntity.Rows[0]["s_CorporateIdNo"],
                                            dtEntity.Rows[0]["d_DOB"],
                                            dtEntity.Rows[0]["d_CreationDate"],
                                            dtEntity.Rows[0]["n_NetWorth"],
                                            dtEntity.Rows[0]["d_NetWorthAsOnDate"],
                                            dtEntity.Rows[0]["n_GrAnnIncRange"],
                                            dtEntity.Rows[0]["d_GrAnnIncAsOnDate"],
                                            dtEntity.Rows[0]["n_PEP"],
                                            dtEntity.Rows[0]["s_PlaceofIncorporation"],
                                            dtEntity.Rows[0]["n_Occupation"],
                                            dtEntity.Rows[0]["s_OccupationText"],
                                            dtEntity.Rows[0]["s_OccupationOthers"],
                                            dtEntity.Rows[0]["d_CommOfBusiness"],
                                            dtEntity.Rows[0]["s_CINExempt"],
                                            dtEntity.Rows[0]["s_TypeofFacility"],
                                            dtEntity.Rows[0]["n_LastUserNo"],
                                            dtEntity.Rows[0]["d_LastModifiedDateTime"],
                                            dtEntity.Rows[0]["n_MakerUser"],
                                             dtEntity.Rows[0]["s_City"],
                                            dtEntity.Rows[0]["s_AuthorizedStatus"],
                                            dtEntity.Rows[0]["s_SameCorrPermAdd"],
                                            dtEntity.Rows[0]["n_Status"],
                                            dtEntity.Rows[0]["s_StatusText"],
                                            dtEntity.Rows[0]["s_StatusOther"],
                                            dtEntity.Rows[0]["s_PEPDesc"],
                                            dtEntity.Rows[0]["s_UserId"],
                                            dtEntity.Rows[0]["s_AuthorizationRemarks"],
                                            dtEntity.Rows[0]["s_ClientType"],
                                            dtEntity.Rows[0]["s_ClientCode"],
                                            dtEntity.Rows[0]["n_EntityPhotoDocNo"],
                                            SourceDataTable.Rows.Count+1,
                                            dtEntity.Rows[0]["n_ClientNo"],
                                            dtEntity.Rows[0]["n_Solutation"],
                                            dtEntity.Rows[0]["SelfAuth"],
                                            dtEntity.Rows[0]["sTaxDeductionStatus"],
                                            dtEntity.Rows[0]["SEBIRegistration"],
                                            dtEntity.Rows[0]["StandingInstruction"],
                                            dtEntity.Rows[0]["SubType"],
                                            dtEntity.Rows[0]["Branch"],
                                            dtEntity.Rows[0]["ShortCode"],
                                            dtEntity.Rows[0]["ParentAccNo"],
                                            dtEntity.Rows[0]["IsParentAccount"]



                        });

                   
                    m_CEntityMaster.EntityDataTable = SourceDataTable;

                    frmEntityDetailsObj.CurrentRowNo = SourceDataTable.Rows.Count;
                    this.lblRecordCount.Text = SourceDataTable.Rows.Count.ToString();
                }
                
                this.SetCurrentRowSelected(frmEntityDetailsObj.CurrentRowNo);
                
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                Logger.Instance.WriteLog(typeof(frmEntityMaster), ex.Message);
                string sErrorMessage = "Unable to fetch data." + Environment.NewLine;
                MessageBox.Show(sErrorMessage, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return result;
        } 

     
        /// <summary>
        /// Event to add new entity
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">EventArgs</param>
        protected override void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult result = ShowEntityMasterModel(CCMConstants.INDIVIDUAL);
            
                if (result == System.Windows.Forms.DialogResult.OK)
                {
                     ApplyFilter();
                }
               
            }
            catch (Exception ex)
            {
                string sErrorMessage = "Unable to set selected record details." + Environment.NewLine + ex.Message;
                Logger.Instance.WriteLog(this, sErrorMessage);
                MessageBox.Show(sErrorMessage, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


            /// <summary>
        /// Event to add new entity
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">EventArgs</param>
        protected override void addNonIndividual_Click(object sender, EventArgs e)

        {
            try
            {
                DialogResult result = ShowEntityMasterModel(CCMConstants.NON_INDIVIDUAL);
            
                 if (result == System.Windows.Forms.DialogResult.OK)
                {
                    ApplyFilter();
                }
            }
            catch (Exception ex)
            {
                string sErrorMessage = "Unable to set selected record details." + Environment.NewLine + ex.Message;
                Logger.Instance.WriteLog(this, sErrorMessage);
                MessageBox.Show(sErrorMessage, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        

        /// <summary>
        /// Event to Modify existing entity Details
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">EventArgs</param>
        protected override void modifiyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                string sClientNo = GetSelected(CEntityMaster.CLIENTNO);
                string sEntityType = GetSelected(CEntityMaster.CLIENTTYPE);
                this.Cursor = Cursors.WaitCursor;

                if (sClientNo != null)
                {

                    m_CEntityMaster.ClientNo = Convert.ToInt32(sClientNo);

                    DialogResult result = ShowEntityMasterModel(sEntityType, false);

                    this.Cursor = Cursors.Default;

                }
                else
                {
                    MessageBox.Show("No records selected for modify", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);  
                    this.Cursor = Cursors.Default;
                    return;
                }
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                string sErrorMessage = "Unable to set selected record details." + Environment.NewLine + ex.Message; 
                Logger.Instance.WriteLog(this, sErrorMessage); 

            }
           
        }

        /// <summary>
        /// Event to freeze User 
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">EventArgs</param>
        protected override void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                string sClientNo = GetSelected(CEntityMaster.CLIENTNO);
                if (sClientNo != null)
                {
                    
                    if (MessageBox.Show("Do you want to freeze the record?", this.Text, MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        
                            MethodExecResult l_objMethodExceResult = m_CEntityMaster.FreezeEntity(Convert.ToInt32(sClientNo));
                        
                        if (l_objMethodExceResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
                        {
                            Logger.Instance.WriteLog(this, l_objMethodExceResult);
                            MessageBox.Show(l_objMethodExceResult.ErrorMessage, string.Empty, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        deleteFlag = SourceDataTable.Rows.Count;
                        GetData();

                        if (deleteFlag > SourceDataTable.Rows.Count)
                        {
                            MessageBox.Show(this, "record freezed succussfully!");
                            frmEntityMaster.deleteFlag = 0;
                        }

                    }
                    
                }
                else
                {
                    MessageBox.Show("No records selected for freeze", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);                  
                    this.Cursor = Cursors.Default;
                    return;
                }
            }
            catch (Exception ex)
            {
                string sErrorMessage = "Unable to set selected record details." + Environment.NewLine + ex.Message;
                Logger.Instance.WriteLog(this.GetType(), sErrorMessage);
            }
            
            
        }



        /// <summary>
        /// Event For import bulk Entities
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">EventArgs</param>
        protected override void btnImport_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    string ErrorMsg = string.Empty; 
            //    CUserManagementMaster m_objUserMngmt = new CUserManagementMaster();
            //    DataTable dtUser = ImportData();
            //    if (dtUser != null && dtUser.Rows.Count > 0)
            //    {
            //        long nRetCode = 0;

            //        DataSet ds = m_objUserMngmt.BulkUserSave(dtUser, ref ErrorMsg, ref nRetCode);
            //        if (nRetCode == FTIL.Match.Common.MethodExecResult.SuccessfulReturnCode)
            //        {
            //            if (ds != null)
            //            {
            //                if (ds.Tables[0].Rows.Count > 0)
            //                {
            //                    ShowErrorWindow(ds.Tables[0]);
            //                    return;
            //                }
            //            }
            //            MessageBox.Show("User successfully uploaded.", MsgBoxTitle, MessageBoxButtons.OK);
            //        }
            //        else
            //        {
            //            MessageBox.Show("Failed to upload. DB error : " + ErrorMsg, MsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            //        }
            //    }
            //    GetData(); 
            //}
            //catch (Exception ex)
            //{ 
            //    MessageBox.Show("Unable to save Data. ", MsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error); 
            //    Logger.Instance.WriteLog(typeof(frmUserMaster), ex.Message);
            //}
        }

        /// <summary>
        /// Event to Export Entity data grid to .csv file
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">EventArgs</param>
        protected override void btnExport_Click(object sender, EventArgs e)
        {
            base.btnExport_Click(sender, e);
        }


        /// <summary>
        /// This function is to show error window if error arives while uploading Entity.
        /// </summary>
        /// <param name="dt">DataTable</param>
        private void ShowErrorWindow(DataTable dt)
        {
          
            //frmDisplayRecordset validationScreen = new Forms.frmDisplayRecordset();
            //validationScreen.DataTitle = "User Import Error details";
            //validationScreen.InputData = dt;
            //validationScreen.WindowTitle = "User Import Error details";
            //validationScreen.Icon = this.Icon;

            //validationScreen.DisplayColumns.Add("s_EntityId", "Entity Code");
            //validationScreen.DisplayColumns.Add("s_EntityName", "Entity Name");
            //validationScreen.DisplayColumns.Add("Remarks", "Error Detail");

            //validationScreen.ShowDialog();

        }

        /// <summary>
        /// This Method is to bulk Upload entity.
        /// </summary>
        /// <returns></returns>
        private  DataTable ImportData()
        {
        //    OpenFileDialog openFileDialog1 = new OpenFileDialog();
        //    openFileDialog1.Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*";
        //    DialogResult result = openFileDialog1.ShowDialog();
        //    if (result == DialogResult.OK)
        //    {
        //      return m_objUserMgmt.ImportData(openFileDialog1.FileName, m_Dilimiter);
        //    }
            return null;
        }



        protected override void btnGo_Click(object sender, EventArgs e)
        {
            m_HasFindButtonPressed = true;
            ApplyFilter();
            
        }

        /// <summary>
        /// Trigger to Apply button, call database function to get all Entities as per filter  
        /// </summary>
        private void ApplyFilter()
        {
            if (cboEntityType.SelectedItem != null)
            {
                m_CEntityMaster.EntityType = cboEntityType.SelectedItem.ToString().ToUpper();

                switch (m_CEntityMaster.EntityType)
                {
                    case "ALL": m_CEntityMaster.EntityType = null;
                        break;
                    case "INDIVIDUAL": m_CEntityMaster.EntityType = CCMConstants.INDIVIDUAL;
                        break;
                    case "NON-INDIVIDUAL": m_CEntityMaster.EntityType = CCMConstants.NON_INDIVIDUAL;
                        break;
                }
            }
            else
            {
                m_CEntityMaster.EntityType = null;
            }

            if (cboAuthStatus.SelectedItem != null)
            {
                string sAuthStatus = cboAuthStatus.SelectedItem.ToString().ToUpper();
                switch (sAuthStatus)
                {
                    case "ALL": m_CEntityMaster.AuthType = null;
                        break;
                    case "AUTHORIZED": m_CEntityMaster.AuthType = "A";
                        break;
                    case "UN-AUTHORIZED": m_CEntityMaster.AuthType = "U";
                        break;
                }
            }
            else
            {
                m_CEntityMaster.AuthType = null;
            }
             

            if (dtpFromDate.Checked && dtpToDate.Checked)
            {
                if (dtpFromDate.Value.Date > dtpToDate.Value.Date)
                {
                    MessageBox.Show("From date cannot be greater than To date.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    dtpFromDate.Focus();
                    return;
                }

                m_CEntityMaster.FromDate = dtpFromDate.Value.Date;
                m_CEntityMaster.ToDate = dtpToDate.Value.Date;
            }
            else
            {
                m_CEntityMaster.FromDate = null;
                m_CEntityMaster.ToDate = null;
            }

            txtCode.Text = txtCode.Text.Trim();

            if (!string.IsNullOrEmpty(txtCode.Text))
                m_CEntityMaster.Code = txtCode.Text;
            else m_CEntityMaster.Code = null;


            GetData();
            if (SourceDataTable.Rows.Count == 0)
            {
                MessageBox.Show("No record found!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        //public void RefreshData()
        //{
        //    GetData();
        //}
        private void btnModify_Click(object sender, EventArgs e)
        {

        }
    }


}
