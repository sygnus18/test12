using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using C1.Win.C1FlexGrid;
using CommonEntityMaster.BAL;

namespace CommonEntityMaster.UI.Forms
{
    public partial class FrmUnAuthorizedDetails : Form
    {
        public DataSet dsUnAuthoDetails;
        public bool FirstDialog = true;
        public bool userRights = false;

        public FrmUnAuthorizedDetails(DataSet dsUnAuthoDetails)
        {
            InitializeComponent();

            //Naveen
            btnUserRights.Visible = false;

            this.dsUnAuthoDetails = dsUnAuthoDetails;
            DataTable dtTabCaptions = dsUnAuthoDetails.Tables[dsUnAuthoDetails.Tables.Count - 1];
            for (int i = 0; i < (dsUnAuthoDetails.Tables.Count-1); i++)
	        {
                DataTable dt = dsUnAuthoDetails.Tables[i];
                if (dtTabCaptions.Rows.Count < (i + 1))
                    break;
                TabPage tabPage = new TabPage();
                tabPage.Text = dtTabCaptions.Rows[i][0].ToString();

                C1FlexGrid c1FlexGrid = new C1FlexGrid();
                c1FlexGrid.AllowDragging = AllowDraggingEnum.Columns;
                c1FlexGrid.AllowEditing = false;
                c1FlexGrid.AllowDelete = false;
                c1FlexGrid.AllowAddNew = false;
                c1FlexGrid.AllowFreezing = AllowFreezingEnum.None;
                c1FlexGrid.AllowSorting = AllowSortingEnum.None;
                c1FlexGrid.Dock = DockStyle.Fill;
                C1.Win.C1FlexGrid.CellStyle s = c1FlexGrid.Styles.Add("OldValues");
                s.BackColor = Color.Yellow;
                s.Font = new Font(Font, FontStyle.Bold);
                
                tabPage.Controls.Add(c1FlexGrid);
                if (dt.Columns.Contains("EntityNo"))
                {
                    AuthoDetailNavigator navigator = new AuthoDetailNavigator(dt);
                    Panel pnlTop = new Panel();
                    pnlTop.Dock = DockStyle.Top;
                    pnlTop.Height = 30;


                    Button btnPrev = new Button();
                    btnPrev.Text = "&Previous";
                    btnPrev.Tag = c1FlexGrid;
                    btnPrev.Name = "btnPrevious";
                    btnPrev.Enabled = navigator.PreviousAllowed;
                    btnPrev.Click += new EventHandler(btnPrev_Click);
                    pnlTop.Controls.Add(btnPrev);

                    Button btnNext = new Button();
                    btnNext.Left = 300;
                    btnNext.Text = "&Next";
                    btnNext.Tag = c1FlexGrid;
                    btnNext.Name = "btnNext";
                    btnNext.Enabled = navigator.NextAllowed;
                    btnNext.Click += new EventHandler(btnNext_Click);
                    pnlTop.Controls.Add(btnNext);

                    createGrid(navigator.NavigatedDataSource, c1FlexGrid);
                    tabPage.Controls.Add(pnlTop);
                    c1FlexGrid.Tag = navigator;
                }
                else
                    createGrid(dt.DefaultView, c1FlexGrid);
                tabChildEntities.TabPages.Add(tabPage);
	        }
        }

        void btnNext_Click(object sender, EventArgs e)
        {
            Button btnSender = (Button)sender;
            C1FlexGrid grid = (C1FlexGrid)btnSender.Tag;
            AuthoDetailNavigator navigator = (AuthoDetailNavigator)grid.Tag;
            if (navigator.NextAllowed)
            {
                navigator.Next();
                btnSender.Enabled = navigator.NextAllowed;
                btnSender.Parent.Controls["btnPrevious"].Enabled = navigator.PreviousAllowed;
                createGrid(navigator.NavigatedDataSource,grid);
            }
        }

        void btnPrev_Click(object sender, EventArgs e)
        {
            Button btnSender = (Button)sender;
            C1FlexGrid grid = (C1FlexGrid)btnSender.Tag;
            AuthoDetailNavigator navigator = (AuthoDetailNavigator)grid.Tag;
            if (navigator.PreviousAllowed)
            {
                navigator.Previous();
                btnSender.Enabled = navigator.PreviousAllowed;
                btnSender.Parent.Controls["btnNext"].Enabled = navigator.NextAllowed;
                createGrid(navigator.NavigatedDataSource,grid);
            }
        }

        private void createGrid(DataView dvUnAuthoDetails,C1FlexGrid grid)
        {
            grid.Clear();
            grid.Rows.Count = dvUnAuthoDetails.Table.Columns.Contains("EntityNo")?(dvUnAuthoDetails.Table.Columns.Count-1):dvUnAuthoDetails.Table.Columns.Count;
            grid.Cols.Count = dvUnAuthoDetails.Count + 1;
            grid.Cols.Fixed = 1;
            grid.Rows.Fixed = 1;

            if (dvUnAuthoDetails != null)
            {
                for (int rowCtr = 0; rowCtr < dvUnAuthoDetails.Table.Columns.Count; rowCtr++)
                {
                    if (dvUnAuthoDetails.Table.Columns[rowCtr].Caption == "EntityNo") continue;
                    grid[rowCtr, 0] = dvUnAuthoDetails.Table.Columns[rowCtr].ToString();
                }

                int colCtr = 1;
                for (int i = 0; i < dvUnAuthoDetails.Count;i++)
                {
                    for (int rowCtr = 0; rowCtr < dvUnAuthoDetails.Table.Columns.Count; rowCtr++)
                    {
                        if (dvUnAuthoDetails.Table.Columns[rowCtr].Caption == "EntityNo") continue;
                        grid[rowCtr, colCtr] = dvUnAuthoDetails[i][rowCtr].ToString();
                    }
                    grid.Cols[colCtr].TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.RightCenter;
                    colCtr++;
                }

                for (int i = 1; i < grid.Rows.Count; i++)
                {
                    if (grid.Cols.Count > 2)
                    {
                        if (grid[i, 1]!=null && grid[i, 2]!=null && grid[i, 1].ToString() != grid[i, 2].ToString())
                        {
                            CellRange rg = grid.GetCellRange(i, 1, i, 1);
                            rg.Style = grid.Styles["OldValues"];
                            rg = grid.GetCellRange(i, 2, i, 2);
                            rg.Style = grid.Styles["OldValues"];
                        }
                    }
                }
            }
            else
            {
                grid[0, 0] = "Values";
                grid[0, 1] = "Old Values";
                grid[0, 2] = "New Values";
            }
            grid.Cols[0].Width = 182;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
            FirstDialog = false;
        }

        private void btnUserRights_Click(object sender, EventArgs e)
        {
            //FrmUnAuthorizedUserRights UUR = new FrmUnAuthorizedUserRights(dsUnAuthoDetails);
            //UUR.ShowDialog();
           
        }

        private void FrmUnAuthorizedDetails_Load(object sender, EventArgs e)
        {
            btnUserRights.Visible = userRights;
        }
    }
}