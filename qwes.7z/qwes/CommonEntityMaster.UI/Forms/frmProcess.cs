﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FTIL.Match.CDD.BAL;
using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.CDD.UI.Forms;
using FTIL.Match.Common.Log;
using FTIL.Match.Common;
using System.IO;
using System.Threading;

namespace FTIL.Match.CDD.UI.Forms
{
    public partial class frmProcess : Form
    {
        private CProductSync m_ObjProductSync;
        private EntityDetails m_EntityDetails;
        public int ClientNo { get; set; }
        public string CDDCode { get; set; }
        public string ClientName { get; set; }
        public string CustId { get; set; }
        public string EntityType { get; set; }
        public string EntityProductID { get; set; }
        public int ProductId { get; set; }

        public int BranchNo { get; set; }
        public int GroupNo { get; set; }
        public int UserId { get; set; }
        public int EntityTypeId { get; set; }

        public int nErrorNo { get; set; }
        public string sErrorMsg { get; set; }
        int iCheckCount = 0;
        public string DPType { get; set; }
        public string DPCode { get; set; }
        public DateTime? dFromDate { get; set; }
        public DataTable dtProduct  { get; set; }
        DataTable dtResult;

        private Logging objLogger;
        
        public frmProcess()
        {
            //Obj_Service = new PDServiceReference.Service1Client();
            m_ObjProductSync = new CProductSync();
            this.KeyPreview = true;
            InitializeComponent();
        }

        private void frmProcess_Load(object sender, EventArgs e)
        {
            //BindGrid();
             
        }

        public void BindGrid()
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;
                dtResult = new DataTable();

                dtResult.Columns.Add("n_ProductNo", typeof(int));
                dtResult.Columns.Add("n_RowNo", typeof(int));
                dtResult.Columns.Add("imgAct", typeof(string));
                dtResult.Columns.Add("s_ProductName", typeof(string));
                dtResult.Columns.Add("s_Status", typeof(string));
                dtResult.Columns.Add("s_Message", typeof(string));

                for (int iCnt = 0; iCnt <= dtProduct.Rows.Count - 1; iCnt++)
                {
                    if (dtProduct.Rows[iCnt]["b_Flag"].ToString() == "True")
                    {
                        dtResult.Rows.Add(new object[] { dtProduct.Rows[iCnt]["n_ProductNo"], iCnt , "", dtProduct.Rows[iCnt]["s_ProductName"] + " - Client Details ", "", "" });
                    }

                }

                if (dtResult.Rows.Count == 0) return;
                //m_ObjProductSync.GetEntityProducts(ClientNo, ref dtProduct);
                dgvProduct.Cols.Fixed = UIConstants.FlexGridLeftFixColumn;
                dgvProduct.DataSource = dtResult;
                dgvProduct.Cols["n_ProductNo"].Visible = false;
                dgvProduct.Cols["n_RowNo"].Visible = false;
                //this.dgvProduct.Cols["DPCode"].Visible = true;

                dgvProduct.Cols["imgAct"].Caption = "";
                dgvProduct.Cols["s_ProductName"].Caption = "Action";
                dgvProduct.Cols["s_Status"].Caption = "Status";
                dgvProduct.Cols["s_Message"].Caption = "Message";

                dgvProduct.Cols["imgAct"].Width = 30;
                dgvProduct.Cols["s_ProductName"].Width = 250;
                dgvProduct.Cols["s_Status"].Width = 160;
                dgvProduct.Cols["s_Message"].Width = 250;

                //dgvProduct.Cols["s_EntityProductID"].Width = 200;
                //dgvProduct.Cols["Description"].Width = 190;
                lblTotal.Text = dtResult.Rows.Count.ToString() + " " + lblTotal.Text;

               
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex.Message);
                MessageBox.Show("Product bind failure.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        /// <summary>
        ///  calling syn service for the selected products.
        ///  
        /// </summary>
        public void Proceed()
        {
            int iSuccessCount = 0;
             int iErrorCount = 0;
            string s_Products = "";
            int iLen;
            int iRowNo;
            int nCheckCount = 0;
            string sLogFileName;
            this.Cursor = Cursors.WaitCursor;

            sLogFileName = Environment.CurrentDirectory;
            try
            {
                if (dgvProduct.Rows.Count > 0)
                {

                    MethodExecResult l_objMethodExceResult = new MethodExecResult(0);
                    m_ObjProductSync.CDDCode = this.CDDCode;
                    m_ObjProductSync.ClientNo = this.ClientNo;
                    m_ObjProductSync.ClientName = this.ClientName;
                    m_ObjProductSync.CustId = this.CustId;
                    m_ObjProductSync.EntityType = this.EntityType;
                    
                    for (int iCnt = 0; iCnt <= dtResult.Rows.Count - 1; iCnt++)
                    {
                        
                        if (1 == 1)
                        {
                            nCheckCount += 1;
                            iRowNo = Convert.ToInt32(this.dtResult.Rows[iCnt]["n_RowNo"].ToString());
                            s_Products += this.dtProduct.Rows[iCnt]["n_ProductNo"].ToString() + ",";
                            m_ObjProductSync.ProductId = Convert.ToInt32(this.dtProduct.Rows[iRowNo]["n_ProductNo"].ToString());
                            m_ObjProductSync.EntityProductID = this.dtProduct.Rows[iRowNo]["s_EntityProductID"].ToString();
                            iLen = m_ObjProductSync.EntityProductID.Length;
                            if (m_ObjProductSync.EntityProductID == "")
                            {
                                m_ObjProductSync.sErrorMsg = "Code can not left blank.";
                                //this.dgvProduct.SetCellImage(iCnt + 1, 2, Image.FromFile(sLogFileName +  @"\Images\err.png"));
                                GridCellImageBind(iCnt, "Err");
                                //iErrorCount += 1;
                                //lblError.Text = iErrorCount.ToString() + " " + lblError.Text;
                                m_ObjProductSync.nErrorNo = 1;
                                
                            }
                            else
                            {
                                if (iLen > CCMConstants.CLIENT_CODE_MAX_LENGTH)
                                    m_ObjProductSync.EntityProductID = m_ObjProductSync.EntityProductID.Substring(iLen - CCMConstants.CLIENT_CODE_MAX_LENGTH,
                                        CCMConstants.CLIENT_CODE_MAX_LENGTH);

                                if (m_ObjProductSync.ProductId == 1 || m_ObjProductSync.ProductId == 2)
                                {
                                    GetServices(m_ObjProductSync.ProductId);
                                    //m_ObjProductSync.SyncProductsMatch(m_ObjProductSync.ProductId);
                                }
                                else if (m_ObjProductSync.ProductId == 17 || m_ObjProductSync.ProductId == 18)
                                {

                                    //if (m_ObjProductSync.nErrorNo == 0)
                                        GetServices(m_ObjProductSync.ProductId);

                                    m_ObjProductSync.DPCode = this.dtProduct.Rows[iRowNo]["DPCode"].ToString();
                                    m_ObjProductSync.DPType = this.dtProduct.Rows[iRowNo]["s_ProductName"].ToString();
                                    if (m_ObjProductSync.DPType.Length > 2)
                                        m_ObjProductSync.DPType = m_ObjProductSync.DPType.Substring(m_ObjProductSync.DPType.Length - 4, 4);
                                    m_ObjProductSync.dFromDate = dFromDate;

                                    //if (m_ObjProductSync.nErrorNo == 0)
                                    //m_ObjProductSync.SyncProductsMatchDP(m_ObjProductSync.ProductId);

                                    //if (m_ObjProductSync.DPCode == "")
                                    //{
                                    //    this.dgvProduct.SetCellImage(iCnt + 1, 2, Image.FromFile(sLogFileName + @"\Images\err.png"));
                                    //    m_ObjProductSync.nErrorNo = 1;
                                    //    m_ObjProductSync.sErrorMsg = "DPCode can not left blank.";
                                    //}
                                    //else
                                    //{
                                    //    m_ObjProductSync.SyncProductsMatchDP(m_ObjProductSync.ProductId);
                                    //    if(m_ObjProductSync.nErrorNo ==0)
                                    //        GetServices(m_ObjProductSync.ProductId);
                                    //}
                                }
                           


                          }


                            if (m_ObjProductSync.nErrorNo == 102)
                            {
                               // MessageBox.Show("Code " + m_ObjProductSync.EntityProductID + " is already exist.", string.Empty, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                dtProduct.Rows[iRowNo]["Status"] = "Error";
                                dtProduct.Rows[iRowNo]["Description"] = "Code " + m_ObjProductSync.EntityProductID + " is already exist.";

                                dtResult.Rows[iCnt]["s_Status"] = "Error";
                                dtResult.Rows[iCnt]["s_Message"] = "Code " + m_ObjProductSync.EntityProductID + " is already exist.";
                                //this.dgvProduct.SetCellImage(iCnt + 1, 2, Image.FromFile(sLogFileName +  @"\Images\err.png"));
                                GridCellImageBind(iCnt, "Err");
                                iErrorCount += 1;
                                lblError.Text = iErrorCount.ToString() + " Error" ;
                            }
                      
                            if (m_ObjProductSync.nErrorNo == 0)
                            {
                                
                                dtProduct.Rows[iRowNo]["Status"] = "Done";
                                dtProduct.Rows[iRowNo]["Description"] = "Successful";

                                dtResult.Rows[iCnt]["s_Status"] = "Successful";
                                dtResult.Rows[iCnt]["s_Message"] = "";
                                iSuccessCount += 1;
                                dtProduct.Rows[iRowNo]["Last Sync Date"] = System.DateTime.Now;
                                lblSuccess.Text = iSuccessCount.ToString() + " Success";
                                
                                //this.dgvProduct.SetCellImage(iCnt + 1, 2, Image.FromFile(sLogFileName + @"\Images\ok.png"));
                                GridCellImageBind(iCnt, "OK");
                            }
                            else
                            {
                                dtProduct.Rows[iRowNo]["Status"] = "Error";
                                dtProduct.Rows[iRowNo]["Description"] = m_ObjProductSync.sErrorMsg;

                                dtResult.Rows[iCnt]["s_Status"] = "Error";
                                dtResult.Rows[iCnt]["s_Message"] = m_ObjProductSync.sErrorMsg;
                                //this.dgvProduct.SetCellImage(iCnt + 1, 2, Image.FromFile(sLogFileName + @"\Images\err.png"));
                                GridCellImageBind(iCnt, "Err");
                                iErrorCount += 1;
                                lblError.Text = iErrorCount.ToString() + " Error" ;
                            }
                        }
                        dgvProduct.Refresh();
                        Thread.Sleep(200);
                    }

                    if (nCheckCount == 0)
                    {
                        //MessageBox.Show("Kindly select at least one product.", string.Empty, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //return;
                    }

                }
                this.Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                Logger.Instance.WriteLog(typeof(frmEntityDetail), ex.Message);
                MessageBox.Show(MatchCommon.CCommon.CommonUpdateFailureMessage, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void GridCellImageBind(int iCnt,string strImgType)
        {
            string sLogFileName = Environment.CurrentDirectory;
            try
            {
                if(strImgType=="OK")
                    this.dgvProduct.SetCellImage(iCnt + 1, 2, Image.FromFile(sLogFileName + @"\Images\ok.png"));
                else
                    this.dgvProduct.SetCellImage(iCnt + 1, 2, Image.FromFile(sLogFileName + @"\Images\err.png"));
            }
            catch { }
        }

        private void GetServices(int iProductCode)
        {
            string sXMLValue;
            try
            {

                if (iProductCode == 1 || iProductCode == 2 || iProductCode == 17 || iProductCode == 18)
                {
                    if (iProductCode == 1 || iProductCode == 2)
                        m_ObjProductSync.DPType =  "NSDL";
                    else
                        m_ObjProductSync.DPType = iProductCode == 17 ? "NSDL" : "CDSL";

                    m_ObjProductSync.DPXLMData();
                    sXMLValue = m_ObjProductSync.sXMLData;

                    FTIL.Match.CDD.UI.DPMaster.DPMasterClient obj_Service = new FTIL.Match.CDD.UI.DPMaster.DPMasterClient();
                    string str1 = obj_Service.GetDPMasterData(iProductCode, sXMLValue);

                    if (str1 == null)
                        str1 = "Successfull"; 
                        str1 = str1.Trim();

                    if (str1 == "Successfull" || str1 == "Message:")
                    {
                        m_ObjProductSync.SyncProducts(iProductCode);
                        m_ObjProductSync.sErrorMsg = "Successfull";
                    }
                    else
                    {
                        m_ObjProductSync.sErrorMsg = str1;
                        m_ObjProductSync.nErrorNo = 909;
                    }
                }
            }
            catch (Exception ex)
            {
                m_ObjProductSync.nErrorNo = 909;
                Logger.Instance.WriteLog(typeof(frmEntityDetail), ex.Message);
                MessageBox.Show("Data processing error in service.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                m_ObjProductSync.sErrorMsg = "Data processing error in service.";
                timer1.Stop();
            }
        }

        private void frmProcess_Activated(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (iCheckCount == 1)
            {
                iCheckCount += 1;
                Proceed();
            }
            iCheckCount += 1;
        }

        private void frmProcess_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }




    }
}
