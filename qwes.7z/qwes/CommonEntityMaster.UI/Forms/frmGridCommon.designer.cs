namespace FTIL.Match.CDD.UI.Forms
{
    partial class frmGridCommon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGridCommon));
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNonIndividual = new System.Windows.Forms.ToolStripMenuItem();
            this.modifiyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnGo = new MatchCommon.CustomControls.FTButton();
            this.panel3 = new MatchCommon.CustomControls.FTPanel();
            this.lblRecordCount = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel2 = new MatchCommon.CustomControls.FTLabel();
            this.gbFilter = new System.Windows.Forms.GroupBox();
            this.ftLabel4 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel3 = new MatchCommon.CustomControls.FTLabel();
            this.cboAuthStatus = new MatchCommon.CustomControls.FTComboBox();
            this.dtpFromDate = new MatchCommon.CustomControls.FTDateTimePicker();
            this.ftLabel1 = new MatchCommon.CustomControls.FTLabel();
            this.dtpToDate = new MatchCommon.CustomControls.FTDateTimePicker();
            this.txtCode = new MatchCommon.CustomControls.FTTextBox();
            this.cboEntityType = new MatchCommon.CustomControls.FTComboBox();
            this.lblReportType = new MatchCommon.CustomControls.FTLabel();
            this.label2 = new System.Windows.Forms.Label();
            this.pnlButtons = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.ftButton1 = new MatchCommon.CustomControls.FTButton();
            this.ftButton2 = new MatchCommon.CustomControls.FTButton();
            this.ftButton3 = new MatchCommon.CustomControls.FTButton();
            this.ftButton4 = new MatchCommon.CustomControls.FTButton();
            this.ftButton5 = new MatchCommon.CustomControls.FTButton();
            this.btnAddIndv = new MatchCommon.CustomControls.FTButton();
            this.btnExport = new MatchCommon.CustomControls.FTButton();
            this.btnModify = new MatchCommon.CustomControls.FTButton();
            this.btnAddNonIndv = new MatchCommon.CustomControls.FTButton();
            this.btnDelete = new MatchCommon.CustomControls.FTButton();
            this.dgvMasterData = new MatchCommon.CustomControls.FTTrueDBGrid();
            this.ToolTipForCode = new System.Windows.Forms.ToolTip(this.components);
            this.contextMenuStrip1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.gbFilter.SuspendLayout();
            this.pnlButtons.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMasterData)).BeginInit();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addToolStripMenuItem,
            this.addNonIndividual,
            this.modifiyToolStripMenuItem,
            this.deleteToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(219, 92);
            // 
            // addToolStripMenuItem
            // 
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.ShortcutKeyDisplayString = "";
            this.addToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.I)));
            this.addToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.addToolStripMenuItem.Text = "Add Individual";
            this.addToolStripMenuItem.Click += new System.EventHandler(this.addToolStripMenuItem_Click);
            // 
            // addNonIndividual
            // 
            this.addNonIndividual.Name = "addNonIndividual";
            this.addNonIndividual.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.N)));
            this.addNonIndividual.Size = new System.Drawing.Size(218, 22);
            this.addNonIndividual.Text = "Add Non-Individual";
            this.addNonIndividual.Click += new System.EventHandler(this.addNonIndividual_Click);
            // 
            // modifiyToolStripMenuItem
            // 
            this.modifiyToolStripMenuItem.Name = "modifiyToolStripMenuItem";
            this.modifiyToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.M)));
            this.modifiyToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.modifiyToolStripMenuItem.Text = "&Modify";
            this.modifiyToolStripMenuItem.Click += new System.EventHandler(this.modifiyToolStripMenuItem_Click);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.Delete)));
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // btnGo
            // 
            this.btnGo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnGo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGo.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnGo.Image = ((System.Drawing.Image)(resources.GetObject("btnGo.Image")));
            this.btnGo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGo.Location = new System.Drawing.Point(421, 46);
            this.btnGo.Name = "btnGo";
            this.btnGo.Size = new System.Drawing.Size(69, 25);
            this.btnGo.TabIndex = 5;
            this.btnGo.Text = "&Retrieve";
            this.btnGo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGo.UseVisualStyleBackColor = true;
            this.btnGo.Click += new System.EventHandler(this.btnGo_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.panel3.Controls.Add(this.lblRecordCount);
            this.panel3.Controls.Add(this.ftLabel2);
            this.panel3.Controls.Add(this.gbFilter);
            this.panel3.Controls.Add(this.pnlButtons);
            this.panel3.Controls.Add(this.dgvMasterData);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1020, 631);
            this.panel3.TabIndex = 0;
            // 
            // lblRecordCount
            // 
            this.lblRecordCount.AllowForeColorChange = false;
            this.lblRecordCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblRecordCount.AutoSize = true;
            this.lblRecordCount.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblRecordCount.ForeColor = System.Drawing.Color.Black;
            this.lblRecordCount.Location = new System.Drawing.Point(970, 544);
            this.lblRecordCount.Name = "lblRecordCount";
            this.lblRecordCount.OverrideDefault = false;
            this.lblRecordCount.Size = new System.Drawing.Size(0, 13);
            this.lblRecordCount.TabIndex = 85;
            // 
            // ftLabel2
            // 
            this.ftLabel2.AllowForeColorChange = false;
            this.ftLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ftLabel2.AutoSize = true;
            this.ftLabel2.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel2.ForeColor = System.Drawing.Color.Black;
            this.ftLabel2.Location = new System.Drawing.Point(921, 544);
            this.ftLabel2.Name = "ftLabel2";
            this.ftLabel2.OverrideDefault = false;
            this.ftLabel2.Size = new System.Drawing.Size(56, 13);
            this.ftLabel2.TabIndex = 82;
            this.ftLabel2.Text = "Records : ";
            // 
            // gbFilter
            // 
            this.gbFilter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.gbFilter.Controls.Add(this.ftLabel4);
            this.gbFilter.Controls.Add(this.ftLabel3);
            this.gbFilter.Controls.Add(this.btnGo);
            this.gbFilter.Controls.Add(this.cboAuthStatus);
            this.gbFilter.Controls.Add(this.dtpFromDate);
            this.gbFilter.Controls.Add(this.ftLabel1);
            this.gbFilter.Controls.Add(this.dtpToDate);
            this.gbFilter.Controls.Add(this.txtCode);
            this.gbFilter.Controls.Add(this.cboEntityType);
            this.gbFilter.Controls.Add(this.lblReportType);
            this.gbFilter.Controls.Add(this.label2);
            this.gbFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbFilter.Location = new System.Drawing.Point(6, 545);
            this.gbFilter.Name = "gbFilter";
            this.gbFilter.Size = new System.Drawing.Size(499, 78);
            this.gbFilter.TabIndex = 84;
            this.gbFilter.TabStop = false;
            this.gbFilter.Text = "Filter Criteria";
            // 
            // ftLabel4
            // 
            this.ftLabel4.AllowForeColorChange = false;
            this.ftLabel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ftLabel4.AutoSize = true;
            this.ftLabel4.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel4.ForeColor = System.Drawing.Color.Black;
            this.ftLabel4.Location = new System.Drawing.Point(6, 50);
            this.ftLabel4.Name = "ftLabel4";
            this.ftLabel4.OverrideDefault = false;
            this.ftLabel4.Size = new System.Drawing.Size(40, 13);
            this.ftLabel4.TabIndex = 84;
            this.ftLabel4.Text = "Search";
            // 
            // ftLabel3
            // 
            this.ftLabel3.AllowForeColorChange = false;
            this.ftLabel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ftLabel3.AutoSize = true;
            this.ftLabel3.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel3.ForeColor = System.Drawing.Color.Black;
            this.ftLabel3.Location = new System.Drawing.Point(7, 28);
            this.ftLabel3.Name = "ftLabel3";
            this.ftLabel3.OverrideDefault = false;
            this.ftLabel3.Size = new System.Drawing.Size(30, 13);
            this.ftLabel3.TabIndex = 83;
            this.ftLabel3.Text = "Date";
            // 
            // cboAuthStatus
            // 
            this.cboAuthStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cboAuthStatus.BackColor = System.Drawing.Color.White;
            this.cboAuthStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboAuthStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboAuthStatus.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboAuthStatus.ForeColor = System.Drawing.Color.Black;
            this.cboAuthStatus.FormattingEnabled = true;
            this.cboAuthStatus.Items.AddRange(new object[] {
            "All",
            "Authorized",
            "Un-Authorized"});
            this.cboAuthStatus.Location = new System.Drawing.Point(317, 49);
            this.cboAuthStatus.Name = "cboAuthStatus";
            this.cboAuthStatus.ReadOnly = false;
            this.cboAuthStatus.Size = new System.Drawing.Size(90, 21);
            this.cboAuthStatus.TabIndex = 4;
            // 
            // dtpFromDate
            // 
            this.dtpFromDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dtpFromDate.BackColor = System.Drawing.Color.White;
            this.dtpFromDate.CalendarFont = new System.Drawing.Font("Tahoma", 8F);
            this.dtpFromDate.CustomFormat = "dd/MM/yyyy";
            this.dtpFromDate.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.dtpFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFromDate.Location = new System.Drawing.Point(46, 24);
            this.dtpFromDate.Name = "dtpFromDate";
            this.dtpFromDate.ReadOnly = false;
            this.dtpFromDate.ShowCheckBox = true;
            this.dtpFromDate.Size = new System.Drawing.Size(92, 20);
            this.dtpFromDate.TabIndex = 0;
            // 
            // ftLabel1
            // 
            this.ftLabel1.AllowForeColorChange = false;
            this.ftLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ftLabel1.AutoSize = true;
            this.ftLabel1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel1.ForeColor = System.Drawing.Color.Black;
            this.ftLabel1.Location = new System.Drawing.Point(250, 50);
            this.ftLabel1.Name = "ftLabel1";
            this.ftLabel1.OverrideDefault = false;
            this.ftLabel1.Size = new System.Drawing.Size(68, 13);
            this.ftLabel1.TabIndex = 82;
            this.ftLabel1.Text = "Auth. Status";
            // 
            // dtpToDate
            // 
            this.dtpToDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dtpToDate.BackColor = System.Drawing.Color.White;
            this.dtpToDate.CalendarFont = new System.Drawing.Font("Tahoma", 8F);
            this.dtpToDate.CustomFormat = "dd/MM/yyyy";
            this.dtpToDate.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.dtpToDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpToDate.Location = new System.Drawing.Point(151, 24);
            this.dtpToDate.Name = "dtpToDate";
            this.dtpToDate.ReadOnly = false;
            this.dtpToDate.ShowCheckBox = true;
            this.dtpToDate.Size = new System.Drawing.Size(92, 20);
            this.dtpToDate.TabIndex = 1;
            // 
            // txtCode
            // 
            this.txtCode.AllowAlpha = true;
            this.txtCode.AllowDot = false;
            this.txtCode.AllowedCustomCharacters = null;
            this.txtCode.AllowNonASCII = false;
            this.txtCode.AllowNumeric = true;
            this.txtCode.AllowSpace = false;
            this.txtCode.AllowSpecialChars = false;
            this.txtCode.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtCode.FocusColor = System.Drawing.Color.LightYellow;
            this.txtCode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtCode.ForeColor = System.Drawing.Color.Black;
            this.txtCode.IsEmailID = false;
            this.txtCode.IsEmailIdValid = false;
            this.txtCode.Location = new System.Drawing.Point(46, 49);
            this.txtCode.MaxLength = 100;
            this.txtCode.Name = "txtCode";
            this.txtCode.Size = new System.Drawing.Size(197, 20);
            this.txtCode.TabIndex = 3;
            this.txtCode.Tag = "Code";
            this.ToolTipForCode.SetToolTip(this.txtCode, "Enter text to search.");
            // 
            // cboEntityType
            // 
            this.cboEntityType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cboEntityType.BackColor = System.Drawing.Color.White;
            this.cboEntityType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboEntityType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboEntityType.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboEntityType.ForeColor = System.Drawing.Color.Black;
            this.cboEntityType.FormattingEnabled = true;
            this.cboEntityType.Items.AddRange(new object[] {
            "Individual",
            "Non-Individual"});
            this.cboEntityType.Location = new System.Drawing.Point(317, 24);
            this.cboEntityType.Name = "cboEntityType";
            this.cboEntityType.ReadOnly = false;
            this.cboEntityType.Size = new System.Drawing.Size(90, 21);
            this.cboEntityType.TabIndex = 2;
            // 
            // lblReportType
            // 
            this.lblReportType.AllowForeColorChange = false;
            this.lblReportType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblReportType.AutoSize = true;
            this.lblReportType.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblReportType.ForeColor = System.Drawing.Color.Black;
            this.lblReportType.Location = new System.Drawing.Point(250, 28);
            this.lblReportType.Name = "lblReportType";
            this.lblReportType.OverrideDefault = false;
            this.lblReportType.Size = new System.Drawing.Size(62, 13);
            this.lblReportType.TabIndex = 81;
            this.lblReportType.Text = "Entity Type";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.label2.Location = new System.Drawing.Point(142, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(9, 12);
            this.label2.TabIndex = 74;
            this.label2.Text = "-";
            // 
            // pnlButtons
            // 
            this.pnlButtons.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlButtons.Controls.Add(this.panel2);
            this.pnlButtons.Controls.Add(this.panel1);
            this.pnlButtons.Controls.Add(this.btnAddIndv);
            this.pnlButtons.Controls.Add(this.btnExport);
            this.pnlButtons.Controls.Add(this.btnModify);
            this.pnlButtons.Controls.Add(this.btnAddNonIndv);
            this.pnlButtons.Controls.Add(this.btnDelete);
            this.pnlButtons.Location = new System.Drawing.Point(516, 588);
            this.pnlButtons.Name = "pnlButtons";
            this.pnlButtons.Size = new System.Drawing.Size(501, 32);
            this.pnlButtons.TabIndex = 4;
            this.pnlButtons.Click += new System.EventHandler(this.addToolStripMenuItem_Click);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Location = new System.Drawing.Point(-13, -53);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(522, 40);
            this.panel2.TabIndex = 10;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.ftButton1);
            this.panel1.Controls.Add(this.ftButton2);
            this.panel1.Controls.Add(this.ftButton3);
            this.panel1.Controls.Add(this.ftButton4);
            this.panel1.Controls.Add(this.ftButton5);
            this.panel1.Location = new System.Drawing.Point(-53, -46);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(522, 32);
            this.panel1.TabIndex = 9;
            // 
            // ftButton1
            // 
            this.ftButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ftButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ftButton1.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.ftButton1.Image = ((System.Drawing.Image)(resources.GetObject("ftButton1.Image")));
            this.ftButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ftButton1.Location = new System.Drawing.Point(102, 4);
            this.ftButton1.Name = "ftButton1";
            this.ftButton1.Size = new System.Drawing.Size(84, 25);
            this.ftButton1.TabIndex = 8;
            this.ftButton1.Text = "&Individual";
            this.ftButton1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ftButton1.UseVisualStyleBackColor = true;
            // 
            // ftButton2
            // 
            this.ftButton2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ftButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ftButton2.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.ftButton2.Image = ((System.Drawing.Image)(resources.GetObject("ftButton2.Image")));
            this.ftButton2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ftButton2.Location = new System.Drawing.Point(6, 4);
            this.ftButton2.Name = "ftButton2";
            this.ftButton2.Size = new System.Drawing.Size(84, 25);
            this.ftButton2.TabIndex = 7;
            this.ftButton2.Text = "&Export";
            this.ftButton2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ftButton2.UseVisualStyleBackColor = true;
            this.ftButton2.Visible = false;
            // 
            // ftButton3
            // 
            this.ftButton3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ftButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ftButton3.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.ftButton3.Image = ((System.Drawing.Image)(resources.GetObject("ftButton3.Image")));
            this.ftButton3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ftButton3.Location = new System.Drawing.Point(326, 4);
            this.ftButton3.Name = "ftButton3";
            this.ftButton3.Size = new System.Drawing.Size(84, 25);
            this.ftButton3.TabIndex = 2;
            this.ftButton3.Text = "&Modify";
            this.ftButton3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ftButton3.UseVisualStyleBackColor = true;
            // 
            // ftButton4
            // 
            this.ftButton4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ftButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ftButton4.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.ftButton4.Image = ((System.Drawing.Image)(resources.GetObject("ftButton4.Image")));
            this.ftButton4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ftButton4.Location = new System.Drawing.Point(198, 4);
            this.ftButton4.Name = "ftButton4";
            this.ftButton4.Size = new System.Drawing.Size(116, 25);
            this.ftButton4.TabIndex = 1;
            this.ftButton4.Text = "&Non-Individual";
            this.ftButton4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ftButton4.UseVisualStyleBackColor = true;
            // 
            // ftButton5
            // 
            this.ftButton5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ftButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ftButton5.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.ftButton5.Image = ((System.Drawing.Image)(resources.GetObject("ftButton5.Image")));
            this.ftButton5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ftButton5.Location = new System.Drawing.Point(422, 4);
            this.ftButton5.Name = "ftButton5";
            this.ftButton5.Size = new System.Drawing.Size(84, 25);
            this.ftButton5.TabIndex = 3;
            this.ftButton5.Text = "&Freeze";
            this.ftButton5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ftButton5.UseVisualStyleBackColor = true;
            // 
            // btnAddIndv
            // 
            this.btnAddIndv.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddIndv.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddIndv.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnAddIndv.Image = ((System.Drawing.Image)(resources.GetObject("btnAddIndv.Image")));
            this.btnAddIndv.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddIndv.Location = new System.Drawing.Point(104, 4);
            this.btnAddIndv.Name = "btnAddIndv";
            this.btnAddIndv.Size = new System.Drawing.Size(90, 25);
            this.btnAddIndv.TabIndex = 0;
            this.btnAddIndv.Text = "&Individual   ";
            this.btnAddIndv.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAddIndv.UseVisualStyleBackColor = true;
            this.btnAddIndv.Click += new System.EventHandler(this.addToolStripMenuItem_Click);
            // 
            // btnExport
            // 
            this.btnExport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExport.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnExport.Image = ((System.Drawing.Image)(resources.GetObject("btnExport.Image")));
            this.btnExport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExport.Location = new System.Drawing.Point(10, 4);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(84, 25);
            this.btnExport.TabIndex = 4;
            this.btnExport.Text = "&Export      ";
            this.btnExport.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Visible = false;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // btnModify
            // 
            this.btnModify.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnModify.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModify.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnModify.Image = ((System.Drawing.Image)(resources.GetObject("btnModify.Image")));
            this.btnModify.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnModify.Location = new System.Drawing.Point(316, 4);
            this.btnModify.Name = "btnModify";
            this.btnModify.Size = new System.Drawing.Size(84, 25);
            this.btnModify.TabIndex = 2;
            this.btnModify.Text = "&Modify     ";
            this.btnModify.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnModify.UseVisualStyleBackColor = true;
            this.btnModify.Click += new System.EventHandler(this.modifiyToolStripMenuItem_Click);
            // 
            // btnAddNonIndv
            // 
            this.btnAddNonIndv.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddNonIndv.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddNonIndv.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnAddNonIndv.Image = ((System.Drawing.Image)(resources.GetObject("btnAddNonIndv.Image")));
            this.btnAddNonIndv.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddNonIndv.Location = new System.Drawing.Point(204, 4);
            this.btnAddNonIndv.Name = "btnAddNonIndv";
            this.btnAddNonIndv.Size = new System.Drawing.Size(102, 25);
            this.btnAddNonIndv.TabIndex = 1;
            this.btnAddNonIndv.Text = "&Non-Individual";
            this.btnAddNonIndv.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAddNonIndv.UseVisualStyleBackColor = true;
            this.btnAddNonIndv.Click += new System.EventHandler(this.addNonIndividual_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.Location = new System.Drawing.Point(410, 4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(84, 25);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Text = "&Freeze      ";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // dgvMasterData
            // 
            this.dgvMasterData.AlternatingRows = true;
            this.dgvMasterData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvMasterData.BackColor = System.Drawing.Color.White;
            this.dgvMasterData.ContextMenuStrip = this.contextMenuStrip1;
            this.dgvMasterData.FilterBar = true;
            this.dgvMasterData.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvMasterData.Images.Add(((System.Drawing.Image)(resources.GetObject("dgvMasterData.Images"))));
            this.dgvMasterData.Location = new System.Drawing.Point(0, 0);
            this.dgvMasterData.MarqueeStyle = C1.Win.C1TrueDBGrid.MarqueeEnum.HighlightRow;
            this.dgvMasterData.Name = "dgvMasterData";
            this.dgvMasterData.PreviewInfo.Location = new System.Drawing.Point(0, 0);
            this.dgvMasterData.PreviewInfo.Size = new System.Drawing.Size(0, 0);
            this.dgvMasterData.PreviewInfo.ZoomFactor = 75D;
            this.dgvMasterData.PrintInfo.PageSettings = ((System.Drawing.Printing.PageSettings)(resources.GetObject("dgvMasterData.PrintInfo.PageSettings")));
            this.dgvMasterData.RowHeight = 20;
            this.dgvMasterData.Size = new System.Drawing.Size(1020, 530);
            this.dgvMasterData.TabIndex = 0;
            this.dgvMasterData.Text = "UserMaster";
            // 
            // frmGridCommon
            // 
            this.AcceptButton = this.btnGo;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1020, 631);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmGridCommon";
            this.Text = "Window Title";
            this.Load += new System.EventHandler(this.frmGridCommon_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmGridCommon_KeyUp);
            this.contextMenuStrip1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.gbFilter.ResumeLayout(false);
            this.gbFilter.PerformLayout();
            this.pnlButtons.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMasterData)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MatchCommon.CustomControls.FTPanel panel3;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modifiyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private MatchCommon.CustomControls.FTTrueDBGrid dgvMasterData;
        private System.Windows.Forms.Panel pnlButtons;
        protected MatchCommon.CustomControls.FTButton btnModify;
        protected MatchCommon.CustomControls.FTButton btnDelete;
        protected MatchCommon.CustomControls.FTButton btnAddNonIndv;
        protected MatchCommon.CustomControls.FTButton btnExport;
        protected MatchCommon.CustomControls.FTButton btnAddIndv;
        private System.Windows.Forms.ToolStripMenuItem addNonIndividual;
        protected MatchCommon.CustomControls.FTDateTimePicker dtpToDate;
        protected MatchCommon.CustomControls.FTDateTimePicker dtpFromDate;
        protected MatchCommon.CustomControls.FTTextBox txtCode;
        protected MatchCommon.CustomControls.FTComboBox cboAuthStatus;
        protected MatchCommon.CustomControls.FTLabel ftLabel1;
        protected MatchCommon.CustomControls.FTComboBox cboEntityType;
        protected MatchCommon.CustomControls.FTLabel lblReportType;
        protected MatchCommon.CustomControls.FTButton btnGo;
        private System.Windows.Forms.Panel panel2;
         private System.Windows.Forms.Panel panel1;
        protected MatchCommon.CustomControls.FTButton ftButton1;
        protected MatchCommon.CustomControls.FTButton ftButton2;
        protected MatchCommon.CustomControls.FTButton ftButton3;
        protected MatchCommon.CustomControls.FTButton ftButton4;
        protected MatchCommon.CustomControls.FTButton ftButton5;
        private System.Windows.Forms.GroupBox gbFilter;
        protected MatchCommon.CustomControls.FTLabel lblRecordCount;
        private System.Windows.Forms.Label label2;
        protected MatchCommon.CustomControls.FTLabel ftLabel2;
        private System.Windows.Forms.ToolTip ToolTipForCode;
        protected MatchCommon.CustomControls.FTLabel ftLabel4;
        protected MatchCommon.CustomControls.FTLabel ftLabel3;
    }
}