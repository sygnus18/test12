﻿namespace FTIL.Match.CDD.UI.Forms
{
    partial class frmAddColumn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAddColumn));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtComboVal = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel36 = new MatchCommon.CustomControls.FTLabel();
            this.chkIsMandatory = new MatchCommon.CustomControls.FTCheckBox();
            this.ftLabel4 = new MatchCommon.CustomControls.FTLabel();
            this.txtMaxLen = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel3 = new MatchCommon.CustomControls.FTLabel();
            this.txtMinLen = new MatchCommon.CustomControls.FTTextBox();
            this.lblFormat = new MatchCommon.CustomControls.FTLabel();
            this.cboFormat = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel1 = new MatchCommon.CustomControls.FTLabel();
            this.cboDataType = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel54 = new MatchCommon.CustomControls.FTLabel();
            this.txtFieldName = new MatchCommon.CustomControls.FTTextBox();
            this.btnSave = new MatchCommon.CustomControls.FTButton();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtComboVal);
            this.groupBox1.Controls.Add(this.ftLabel36);
            this.groupBox1.Controls.Add(this.chkIsMandatory);
            this.groupBox1.Controls.Add(this.ftLabel4);
            this.groupBox1.Controls.Add(this.txtMaxLen);
            this.groupBox1.Controls.Add(this.ftLabel3);
            this.groupBox1.Controls.Add(this.txtMinLen);
            this.groupBox1.Controls.Add(this.lblFormat);
            this.groupBox1.Controls.Add(this.cboFormat);
            this.groupBox1.Controls.Add(this.ftLabel1);
            this.groupBox1.Controls.Add(this.cboDataType);
            this.groupBox1.Controls.Add(this.ftLabel54);
            this.groupBox1.Controls.Add(this.txtFieldName);
            this.groupBox1.Location = new System.Drawing.Point(5, 1);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(311, 142);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // txtComboVal
            // 
            this.txtComboVal.AllowAlpha = true;
            this.txtComboVal.AllowDot = false;
            this.txtComboVal.AllowedCustomCharacters = null;
            this.txtComboVal.AllowNonASCII = false;
            this.txtComboVal.AllowNumeric = true;
            this.txtComboVal.AllowSpace = true;
            this.txtComboVal.AllowSpecialChars = true;
            this.txtComboVal.BackColor = System.Drawing.SystemColors.Window;
            this.txtComboVal.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtComboVal.FocusColor = System.Drawing.Color.LightYellow;
            this.txtComboVal.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtComboVal.ForeColor = System.Drawing.Color.Black;
            this.txtComboVal.IsEmailID = false;
            this.txtComboVal.IsEmailIdValid = false;
            this.txtComboVal.Location = new System.Drawing.Point(82, 66);
            this.txtComboVal.MaxLength = 255;
            this.txtComboVal.Name = "txtComboVal";
            this.txtComboVal.Size = new System.Drawing.Size(221, 20);
            this.txtComboVal.TabIndex = 113;
            this.txtComboVal.Tag = "Code";
            this.txtComboVal.Visible = false;
            // 
            // ftLabel36
            // 
            this.ftLabel36.AllowForeColorChange = false;
            this.ftLabel36.AutoSize = true;
            this.ftLabel36.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel36.ForeColor = System.Drawing.Color.Black;
            this.ftLabel36.Location = new System.Drawing.Point(7, 120);
            this.ftLabel36.Name = "ftLabel36";
            this.ftLabel36.OverrideDefault = false;
            this.ftLabel36.Size = new System.Drawing.Size(71, 13);
            this.ftLabel36.TabIndex = 121;
            this.ftLabel36.Text = "Is Mandatory";
            // 
            // chkIsMandatory
            // 
            this.chkIsMandatory.AutoSize = true;
            this.chkIsMandatory.Font = new System.Drawing.Font("Tahoma", 8F);
            this.chkIsMandatory.ForeColor = System.Drawing.Color.Black;
            this.chkIsMandatory.Location = new System.Drawing.Point(82, 120);
            this.chkIsMandatory.Name = "chkIsMandatory";
            this.chkIsMandatory.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.chkIsMandatory.Size = new System.Drawing.Size(15, 14);
            this.chkIsMandatory.TabIndex = 122;
            this.chkIsMandatory.UseVisualStyleBackColor = true;
            // 
            // ftLabel4
            // 
            this.ftLabel4.AllowForeColorChange = false;
            this.ftLabel4.AutoSize = true;
            this.ftLabel4.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel4.ForeColor = System.Drawing.Color.Black;
            this.ftLabel4.Location = new System.Drawing.Point(173, 97);
            this.ftLabel4.Name = "ftLabel4";
            this.ftLabel4.OverrideDefault = false;
            this.ftLabel4.Size = new System.Drawing.Size(63, 13);
            this.ftLabel4.TabIndex = 119;
            this.ftLabel4.Text = "Max Length";
            // 
            // txtMaxLen
            // 
            this.txtMaxLen.AllowAlpha = false;
            this.txtMaxLen.AllowDot = false;
            this.txtMaxLen.AllowedCustomCharacters = null;
            this.txtMaxLen.AllowNonASCII = false;
            this.txtMaxLen.AllowNumeric = true;
            this.txtMaxLen.AllowSpace = false;
            this.txtMaxLen.AllowSpecialChars = false;
            this.txtMaxLen.BackColor = System.Drawing.SystemColors.Window;
            this.txtMaxLen.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMaxLen.FocusColor = System.Drawing.Color.LightYellow;
            this.txtMaxLen.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtMaxLen.ForeColor = System.Drawing.Color.Black;
            this.txtMaxLen.IsEmailID = false;
            this.txtMaxLen.IsEmailIdValid = false;
            this.txtMaxLen.Location = new System.Drawing.Point(252, 94);
            this.txtMaxLen.MaxLength = 3;
            this.txtMaxLen.Name = "txtMaxLen";
            this.txtMaxLen.Size = new System.Drawing.Size(51, 20);
            this.txtMaxLen.TabIndex = 120;
            this.txtMaxLen.Tag = "Code";
            this.txtMaxLen.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMaxLen_KeyPress);
            // 
            // ftLabel3
            // 
            this.ftLabel3.AllowForeColorChange = false;
            this.ftLabel3.AutoSize = true;
            this.ftLabel3.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel3.ForeColor = System.Drawing.Color.Black;
            this.ftLabel3.Location = new System.Drawing.Point(7, 97);
            this.ftLabel3.Name = "ftLabel3";
            this.ftLabel3.OverrideDefault = false;
            this.ftLabel3.Size = new System.Drawing.Size(59, 13);
            this.ftLabel3.TabIndex = 117;
            this.ftLabel3.Text = "Min Length";
            // 
            // txtMinLen
            // 
            this.txtMinLen.AllowAlpha = false;
            this.txtMinLen.AllowDot = false;
            this.txtMinLen.AllowedCustomCharacters = null;
            this.txtMinLen.AllowNonASCII = false;
            this.txtMinLen.AllowNumeric = true;
            this.txtMinLen.AllowSpace = false;
            this.txtMinLen.AllowSpecialChars = false;
            this.txtMinLen.BackColor = System.Drawing.SystemColors.Window;
            this.txtMinLen.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMinLen.FocusColor = System.Drawing.Color.LightYellow;
            this.txtMinLen.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtMinLen.ForeColor = System.Drawing.Color.Black;
            this.txtMinLen.IsEmailID = false;
            this.txtMinLen.IsEmailIdValid = false;
            this.txtMinLen.Location = new System.Drawing.Point(82, 94);
            this.txtMinLen.MaxLength = 2;
            this.txtMinLen.Name = "txtMinLen";
            this.txtMinLen.Size = new System.Drawing.Size(51, 20);
            this.txtMinLen.TabIndex = 118;
            this.txtMinLen.Tag = "Code";
            // 
            // lblFormat
            // 
            this.lblFormat.AllowForeColorChange = false;
            this.lblFormat.AutoSize = true;
            this.lblFormat.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblFormat.ForeColor = System.Drawing.Color.Black;
            this.lblFormat.Location = new System.Drawing.Point(7, 70);
            this.lblFormat.Name = "lblFormat";
            this.lblFormat.OverrideDefault = false;
            this.lblFormat.Size = new System.Drawing.Size(41, 13);
            this.lblFormat.TabIndex = 111;
            this.lblFormat.Text = "Format";
            // 
            // cboFormat
            // 
            this.cboFormat.BackColor = System.Drawing.Color.White;
            this.cboFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboFormat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboFormat.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboFormat.ForeColor = System.Drawing.Color.Black;
            this.cboFormat.FormattingEnabled = true;
            this.cboFormat.Location = new System.Drawing.Point(82, 66);
            this.cboFormat.Name = "cboFormat";
            this.cboFormat.ReadOnly = false;
            this.cboFormat.Size = new System.Drawing.Size(221, 21);
            this.cboFormat.TabIndex = 112;
            // 
            // ftLabel1
            // 
            this.ftLabel1.AllowForeColorChange = false;
            this.ftLabel1.AutoSize = true;
            this.ftLabel1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel1.ForeColor = System.Drawing.Color.Black;
            this.ftLabel1.Location = new System.Drawing.Point(7, 42);
            this.ftLabel1.Name = "ftLabel1";
            this.ftLabel1.OverrideDefault = false;
            this.ftLabel1.Size = new System.Drawing.Size(31, 13);
            this.ftLabel1.TabIndex = 109;
            this.ftLabel1.Text = "Type";
            // 
            // cboDataType
            // 
            this.cboDataType.BackColor = System.Drawing.Color.White;
            this.cboDataType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDataType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboDataType.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboDataType.ForeColor = System.Drawing.Color.Black;
            this.cboDataType.FormattingEnabled = true;
            this.cboDataType.Location = new System.Drawing.Point(82, 38);
            this.cboDataType.Name = "cboDataType";
            this.cboDataType.ReadOnly = false;
            this.cboDataType.Size = new System.Drawing.Size(221, 21);
            this.cboDataType.TabIndex = 110;
            this.cboDataType.SelectedIndexChanged += new System.EventHandler(this.cboDataType_SelectedIndexChanged);
            // 
            // ftLabel54
            // 
            this.ftLabel54.AllowForeColorChange = false;
            this.ftLabel54.AutoSize = true;
            this.ftLabel54.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel54.ForeColor = System.Drawing.Color.Black;
            this.ftLabel54.Location = new System.Drawing.Point(7, 15);
            this.ftLabel54.Name = "ftLabel54";
            this.ftLabel54.OverrideDefault = false;
            this.ftLabel54.Size = new System.Drawing.Size(59, 13);
            this.ftLabel54.TabIndex = 107;
            this.ftLabel54.Text = "Field Name";
            // 
            // txtFieldName
            // 
            this.txtFieldName.AllowAlpha = true;
            this.txtFieldName.AllowDot = false;
            this.txtFieldName.AllowedCustomCharacters = null;
            this.txtFieldName.AllowNonASCII = false;
            this.txtFieldName.AllowNumeric = true;
            this.txtFieldName.AllowSpace = true;
            this.txtFieldName.AllowSpecialChars = true;
            this.txtFieldName.BackColor = System.Drawing.SystemColors.Window;
            this.txtFieldName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtFieldName.FocusColor = System.Drawing.Color.LightYellow;
            this.txtFieldName.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtFieldName.ForeColor = System.Drawing.Color.Black;
            this.txtFieldName.IsEmailID = false;
            this.txtFieldName.IsEmailIdValid = false;
            this.txtFieldName.Location = new System.Drawing.Point(82, 12);
            this.txtFieldName.MaxLength = 255;
            this.txtFieldName.Name = "txtFieldName";
            this.txtFieldName.Size = new System.Drawing.Size(221, 20);
            this.txtFieldName.TabIndex = 108;
            this.txtFieldName.Tag = "Code";
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Location = new System.Drawing.Point(225, 149);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(84, 25);
            this.btnSave.TabIndex = 142;
            this.btnSave.Text = "&Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // frmAddColumn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(323, 178);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAddColumn";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "New Column";
            this.Load += new System.EventHandler(this.frmAddColumn_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmAddColumn_KeyUp);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private MatchCommon.CustomControls.FTLabel ftLabel4;
        private MatchCommon.CustomControls.FTTextBox txtMaxLen;
        private MatchCommon.CustomControls.FTLabel ftLabel3;
        private MatchCommon.CustomControls.FTTextBox txtMinLen;
        private MatchCommon.CustomControls.FTLabel lblFormat;
        private MatchCommon.CustomControls.FTComboBox cboFormat;
        private MatchCommon.CustomControls.FTLabel ftLabel1;
        private MatchCommon.CustomControls.FTComboBox cboDataType;
        private MatchCommon.CustomControls.FTLabel ftLabel54;
        private MatchCommon.CustomControls.FTTextBox txtFieldName;
        private MatchCommon.CustomControls.FTLabel ftLabel36;
        private MatchCommon.CustomControls.FTCheckBox chkIsMandatory;
        private MatchCommon.CustomControls.FTButton btnSave;
        private MatchCommon.CustomControls.FTTextBox txtComboVal;
    }
}