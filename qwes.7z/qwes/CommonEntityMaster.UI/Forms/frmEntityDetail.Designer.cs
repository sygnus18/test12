﻿namespace FTIL.Match.CDD.UI.Forms
{
    partial class frmEntityDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEntityDetail));
            this.btnMakerCancel = new MatchCommon.CustomControls.FTButton();
            this.pnlButtons = new System.Windows.Forms.Panel();
            this.lblMobileNo = new MatchCommon.CustomControls.FTLabel();
            this.lblAuthStatus = new MatchCommon.CustomControls.FTLabel();
            this.btnAuditTrail = new MatchCommon.CustomControls.FTButton();
            this.ImgPhoto = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtCreated = new MatchCommon.CustomControls.FTTextBox();
            this.lblBranch = new System.Windows.Forms.Label();
            this.txtBranchCode = new MatchCommon.CustomControls.FTTextBox();
            this.txtShortCode = new MatchCommon.CustomControls.FTTextBox();
            this.lblShortCode = new System.Windows.Forms.Label();
            this.ftCreated = new MatchCommon.CustomControls.FTLabel();
            this.cboTitle = new MatchCommon.CustomControls.FTComboBox();
            this.txtDefaultID = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel3 = new MatchCommon.CustomControls.FTLabel();
            this.txtNameHead = new MatchCommon.CustomControls.FTTextBox();
            this.txtFormId = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel2 = new MatchCommon.CustomControls.FTLabel();
            this.txtCustId = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel1 = new MatchCommon.CustomControls.FTLabel();
            this.txtEntityCode = new System.Windows.Forms.TextBox();
            this.ftlblEntityCode = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel78 = new MatchCommon.CustomControls.FTLabel();
            this.btnApply = new MatchCommon.CustomControls.FTButton();
            this.tbCustomization = new System.Windows.Forms.TabPage();
            this.tbNote = new System.Windows.Forms.TabPage();
            this.tbProduct = new System.Windows.Forms.TabPage();
            this.tbDocUpload = new System.Windows.Forms.TabPage();
            this.tbOthers = new System.Windows.Forms.TabPage();
            this.tbAuthorisedSignatories = new System.Windows.Forms.TabPage();
            this.tbBank = new System.Windows.Forms.TabPage();
            this.tbAccount = new System.Windows.Forms.TabPage();
            this.tbEntity1 = new System.Windows.Forms.TabControl();
            this.tbTrading = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tbDetails = new System.Windows.Forms.TabPage();
            this.tbDeposits = new System.Windows.Forms.TabPage();
            this.tbOperations = new System.Windows.Forms.TabPage();
            this.tbEntityOperations = new System.Windows.Forms.TabControl();
            this.tbPreferences = new System.Windows.Forms.TabPage();
            this.tbCustodian = new System.Windows.Forms.TabPage();
            this.pnlButtons.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImgPhoto)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tbEntity1.SuspendLayout();
            this.tbTrading.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tbOperations.SuspendLayout();
            this.tbEntityOperations.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnMakerCancel
            // 
            this.btnMakerCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMakerCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMakerCancel.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnMakerCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnMakerCancel.Image")));
            this.btnMakerCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMakerCancel.Location = new System.Drawing.Point(520, 641);
            this.btnMakerCancel.Name = "btnMakerCancel";
            this.btnMakerCancel.Size = new System.Drawing.Size(95, 25);
            this.btnMakerCancel.TabIndex = 146;
            this.btnMakerCancel.Text = "Maker Cancel";
            this.btnMakerCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMakerCancel.UseVisualStyleBackColor = true;
            this.btnMakerCancel.Click += new System.EventHandler(this.btnMakerCancel_Click);
            // 
            // pnlButtons
            // 
            this.pnlButtons.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlButtons.Controls.Add(this.lblMobileNo);
            this.pnlButtons.Controls.Add(this.lblAuthStatus);
            this.pnlButtons.Location = new System.Drawing.Point(5, 637);
            this.pnlButtons.Name = "pnlButtons";
            this.pnlButtons.Size = new System.Drawing.Size(409, 32);
            this.pnlButtons.TabIndex = 145;
            // 
            // lblMobileNo
            // 
            this.lblMobileNo.AllowForeColorChange = false;
            this.lblMobileNo.AutoSize = true;
            this.lblMobileNo.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblMobileNo.ForeColor = System.Drawing.Color.Black;
            this.lblMobileNo.Location = new System.Drawing.Point(4, 9);
            this.lblMobileNo.Name = "lblMobileNo";
            this.lblMobileNo.OverrideDefault = false;
            this.lblMobileNo.Size = new System.Drawing.Size(42, 13);
            this.lblMobileNo.TabIndex = 93;
            this.lblMobileNo.Text = "Status:";
            // 
            // lblAuthStatus
            // 
            this.lblAuthStatus.AllowForeColorChange = false;
            this.lblAuthStatus.AutoSize = true;
            this.lblAuthStatus.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblAuthStatus.ForeColor = System.Drawing.Color.Black;
            this.lblAuthStatus.Location = new System.Drawing.Point(44, 9);
            this.lblAuthStatus.Name = "lblAuthStatus";
            this.lblAuthStatus.OverrideDefault = false;
            this.lblAuthStatus.Size = new System.Drawing.Size(28, 13);
            this.lblAuthStatus.TabIndex = 144;
            this.lblAuthStatus.Text = "New";
            // 
            // btnAuditTrail
            // 
            this.btnAuditTrail.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAuditTrail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAuditTrail.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnAuditTrail.Image = ((System.Drawing.Image)(resources.GetObject("btnAuditTrail.Image")));
            this.btnAuditTrail.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAuditTrail.Location = new System.Drawing.Point(621, 641);
            this.btnAuditTrail.Name = "btnAuditTrail";
            this.btnAuditTrail.Size = new System.Drawing.Size(84, 25);
            this.btnAuditTrail.TabIndex = 141;
            this.btnAuditTrail.Text = "Audit &Trail  ";
            this.btnAuditTrail.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAuditTrail.UseVisualStyleBackColor = true;
            this.btnAuditTrail.Click += new System.EventHandler(this.btnAuditTrail_Click);
            // 
            // ImgPhoto
            // 
            this.ImgPhoto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ImgPhoto.InitialImage = null;
            this.ImgPhoto.Location = new System.Drawing.Point(690, 6);
            this.ImgPhoto.Name = "ImgPhoto";
            this.ImgPhoto.Size = new System.Drawing.Size(101, 101);
            this.ImgPhoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.ImgPhoto.TabIndex = 142;
            this.ImgPhoto.TabStop = false;
            this.ImgPhoto.DoubleClick += new System.EventHandler(this.ImgPhoto_DoubleClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtCreated);
            this.groupBox1.Controls.Add(this.lblBranch);
            this.groupBox1.Controls.Add(this.txtBranchCode);
            this.groupBox1.Controls.Add(this.txtShortCode);
            this.groupBox1.Controls.Add(this.lblShortCode);
            this.groupBox1.Controls.Add(this.ftCreated);
            this.groupBox1.Controls.Add(this.cboTitle);
            this.groupBox1.Controls.Add(this.txtDefaultID);
            this.groupBox1.Controls.Add(this.ftLabel3);
            this.groupBox1.Controls.Add(this.txtNameHead);
            this.groupBox1.Controls.Add(this.txtFormId);
            this.groupBox1.Controls.Add(this.ftLabel2);
            this.groupBox1.Controls.Add(this.txtCustId);
            this.groupBox1.Controls.Add(this.ftLabel1);
            this.groupBox1.Controls.Add(this.txtEntityCode);
            this.groupBox1.Controls.Add(this.ftlblEntityCode);
            this.groupBox1.Controls.Add(this.ftLabel78);
            this.groupBox1.Location = new System.Drawing.Point(3, 1);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(681, 106);
            this.groupBox1.TabIndex = 143;
            this.groupBox1.TabStop = false;
            // 
            // txtCreated
            // 
            this.txtCreated.AllowAlpha = true;
            this.txtCreated.AllowDot = true;
            this.txtCreated.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtCreated.AllowedCustomCharacters")));
            this.txtCreated.AllowNonASCII = false;
            this.txtCreated.AllowNumeric = true;
            this.txtCreated.AllowSpace = true;
            this.txtCreated.AllowSpecialChars = true;
            this.txtCreated.Enabled = false;
            this.txtCreated.FocusColor = System.Drawing.Color.LightYellow;
            this.txtCreated.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtCreated.ForeColor = System.Drawing.Color.Black;
            this.txtCreated.IsEmailID = false;
            this.txtCreated.IsEmailIdValid = false;
            this.txtCreated.Location = new System.Drawing.Point(561, 20);
            this.txtCreated.Name = "txtCreated";
            this.txtCreated.Size = new System.Drawing.Size(94, 20);
            this.txtCreated.TabIndex = 110;
            // 
            // lblBranch
            // 
            this.lblBranch.AutoSize = true;
            this.lblBranch.Location = new System.Drawing.Point(494, 75);
            this.lblBranch.Name = "lblBranch";
            this.lblBranch.Size = new System.Drawing.Size(41, 13);
            this.lblBranch.TabIndex = 109;
            this.lblBranch.Text = "Branch";
            // 
            // txtBranchCode
            // 
            this.txtBranchCode.AllowAlpha = true;
            this.txtBranchCode.AllowDot = true;
            this.txtBranchCode.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtBranchCode.AllowedCustomCharacters")));
            this.txtBranchCode.AllowNonASCII = false;
            this.txtBranchCode.AllowNumeric = true;
            this.txtBranchCode.AllowSpace = true;
            this.txtBranchCode.AllowSpecialChars = true;
            this.txtBranchCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtBranchCode.FocusColor = System.Drawing.Color.LightYellow;
            this.txtBranchCode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtBranchCode.ForeColor = System.Drawing.Color.Black;
            this.txtBranchCode.IsEmailID = false;
            this.txtBranchCode.IsEmailIdValid = false;
            this.txtBranchCode.Location = new System.Drawing.Point(561, 71);
            this.txtBranchCode.Name = "txtBranchCode";
            this.txtBranchCode.Size = new System.Drawing.Size(94, 20);
            this.txtBranchCode.TabIndex = 108;
            this.txtBranchCode.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtBranchCode_KeyUp);
            this.txtBranchCode.Leave += new System.EventHandler(this.txtBranchCode_Leave);
            // 
            // txtShortCode
            // 
            this.txtShortCode.AllowAlpha = true;
            this.txtShortCode.AllowDot = true;
            this.txtShortCode.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtShortCode.AllowedCustomCharacters")));
            this.txtShortCode.AllowNonASCII = false;
            this.txtShortCode.AllowNumeric = true;
            this.txtShortCode.AllowSpace = true;
            this.txtShortCode.AllowSpecialChars = true;
            this.txtShortCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtShortCode.FocusColor = System.Drawing.Color.LightYellow;
            this.txtShortCode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtShortCode.ForeColor = System.Drawing.Color.Black;
            this.txtShortCode.IsEmailID = false;
            this.txtShortCode.IsEmailIdValid = false;
            this.txtShortCode.Location = new System.Drawing.Point(561, 45);
            this.txtShortCode.Name = "txtShortCode";
            this.txtShortCode.Size = new System.Drawing.Size(94, 20);
            this.txtShortCode.TabIndex = 103;
            // 
            // lblShortCode
            // 
            this.lblShortCode.AutoSize = true;
            this.lblShortCode.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShortCode.Location = new System.Drawing.Point(494, 50);
            this.lblShortCode.Name = "lblShortCode";
            this.lblShortCode.Size = new System.Drawing.Size(61, 13);
            this.lblShortCode.TabIndex = 102;
            this.lblShortCode.Text = "Short Code";
            // 
            // ftCreated
            // 
            this.ftCreated.AllowForeColorChange = false;
            this.ftCreated.AutoSize = true;
            this.ftCreated.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftCreated.ForeColor = System.Drawing.Color.Black;
            this.ftCreated.Location = new System.Drawing.Point(494, 24);
            this.ftCreated.Name = "ftCreated";
            this.ftCreated.OverrideDefault = false;
            this.ftCreated.Size = new System.Drawing.Size(46, 13);
            this.ftCreated.TabIndex = 100;
            this.ftCreated.Text = "Created";
            // 
            // cboTitle
            // 
            this.cboTitle.BackColor = System.Drawing.Color.White;
            this.cboTitle.DisplayMember = "1,2";
            this.cboTitle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTitle.DropDownWidth = 90;
            this.cboTitle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboTitle.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboTitle.ForeColor = System.Drawing.Color.Black;
            this.cboTitle.FormattingEnabled = true;
            this.cboTitle.Location = new System.Drawing.Point(450, 70);
            this.cboTitle.Name = "cboTitle";
            this.cboTitle.ReadOnly = false;
            this.cboTitle.Size = new System.Drawing.Size(10, 21);
            this.cboTitle.TabIndex = 98;
            this.cboTitle.ValueMember = "M,F";
            this.cboTitle.Visible = false;
            // 
            // txtDefaultID
            // 
            this.txtDefaultID.AllowAlpha = true;
            this.txtDefaultID.AllowDot = true;
            this.txtDefaultID.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtDefaultID.AllowedCustomCharacters")));
            this.txtDefaultID.AllowNonASCII = false;
            this.txtDefaultID.AllowNumeric = true;
            this.txtDefaultID.AllowSpace = true;
            this.txtDefaultID.AllowSpecialChars = true;
            this.txtDefaultID.Enabled = false;
            this.txtDefaultID.FocusColor = System.Drawing.Color.LightYellow;
            this.txtDefaultID.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtDefaultID.ForeColor = System.Drawing.Color.Black;
            this.txtDefaultID.IsEmailID = false;
            this.txtDefaultID.IsEmailIdValid = false;
            this.txtDefaultID.Location = new System.Drawing.Point(299, 45);
            this.txtDefaultID.MaxLength = 50;
            this.txtDefaultID.Name = "txtDefaultID";
            this.txtDefaultID.Size = new System.Drawing.Size(149, 20);
            this.txtDefaultID.TabIndex = 96;
            // 
            // ftLabel3
            // 
            this.ftLabel3.AllowForeColorChange = false;
            this.ftLabel3.AutoSize = true;
            this.ftLabel3.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel3.ForeColor = System.Drawing.Color.Black;
            this.ftLabel3.Location = new System.Drawing.Point(244, 50);
            this.ftLabel3.Name = "ftLabel3";
            this.ftLabel3.OverrideDefault = false;
            this.ftLabel3.Size = new System.Drawing.Size(18, 13);
            this.ftLabel3.TabIndex = 97;
            this.ftLabel3.Text = "ID";
            // 
            // txtNameHead
            // 
            this.txtNameHead.AllowAlpha = true;
            this.txtNameHead.AllowDot = true;
            this.txtNameHead.AllowedCustomCharacters = null;
            this.txtNameHead.AllowNonASCII = true;
            this.txtNameHead.AllowNumeric = true;
            this.txtNameHead.AllowSpace = true;
            this.txtNameHead.AllowSpecialChars = true;
            this.txtNameHead.BackColor = System.Drawing.SystemColors.Window;
            this.txtNameHead.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNameHead.FocusColor = System.Drawing.Color.LightYellow;
            this.txtNameHead.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtNameHead.ForeColor = System.Drawing.Color.Black;
            this.txtNameHead.IsEmailID = false;
            this.txtNameHead.IsEmailIdValid = false;
            this.txtNameHead.Location = new System.Drawing.Point(61, 71);
            this.txtNameHead.MaxLength = 150;
            this.txtNameHead.Name = "txtNameHead";
            this.txtNameHead.Size = new System.Drawing.Size(387, 20);
            this.txtNameHead.TabIndex = 88;
            this.txtNameHead.Tag = "Code";
            // 
            // txtFormId
            // 
            this.txtFormId.AllowAlpha = true;
            this.txtFormId.AllowDot = true;
            this.txtFormId.AllowedCustomCharacters = null;
            this.txtFormId.AllowNonASCII = false;
            this.txtFormId.AllowNumeric = true;
            this.txtFormId.AllowSpace = true;
            this.txtFormId.AllowSpecialChars = true;
            this.txtFormId.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtFormId.FocusColor = System.Drawing.Color.LightYellow;
            this.txtFormId.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtFormId.ForeColor = System.Drawing.Color.Black;
            this.txtFormId.IsEmailID = false;
            this.txtFormId.IsEmailIdValid = false;
            this.txtFormId.Location = new System.Drawing.Point(61, 45);
            this.txtFormId.MaxLength = 30;
            this.txtFormId.Name = "txtFormId";
            this.txtFormId.Size = new System.Drawing.Size(149, 20);
            this.txtFormId.TabIndex = 87;
            this.txtFormId.Tag = "Code";
            // 
            // ftLabel2
            // 
            this.ftLabel2.AllowForeColorChange = false;
            this.ftLabel2.AutoSize = true;
            this.ftLabel2.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel2.ForeColor = System.Drawing.Color.Black;
            this.ftLabel2.Location = new System.Drawing.Point(6, 50);
            this.ftLabel2.Name = "ftLabel2";
            this.ftLabel2.OverrideDefault = false;
            this.ftLabel2.Size = new System.Drawing.Size(47, 13);
            this.ftLabel2.TabIndex = 95;
            this.ftLabel2.Text = "Form No";
            // 
            // txtCustId
            // 
            this.txtCustId.AllowAlpha = true;
            this.txtCustId.AllowDot = true;
            this.txtCustId.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtCustId.AllowedCustomCharacters")));
            this.txtCustId.AllowNonASCII = false;
            this.txtCustId.AllowNumeric = true;
            this.txtCustId.AllowSpace = true;
            this.txtCustId.AllowSpecialChars = true;
            this.txtCustId.Enabled = false;
            this.txtCustId.FocusColor = System.Drawing.Color.LightYellow;
            this.txtCustId.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtCustId.ForeColor = System.Drawing.Color.Black;
            this.txtCustId.IsEmailID = false;
            this.txtCustId.IsEmailIdValid = false;
            this.txtCustId.Location = new System.Drawing.Point(299, 20);
            this.txtCustId.MaxLength = 50;
            this.txtCustId.Name = "txtCustId";
            this.txtCustId.Size = new System.Drawing.Size(149, 20);
            this.txtCustId.TabIndex = 92;
            // 
            // ftLabel1
            // 
            this.ftLabel1.AllowForeColorChange = false;
            this.ftLabel1.AutoSize = true;
            this.ftLabel1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel1.ForeColor = System.Drawing.Color.Black;
            this.ftLabel1.Location = new System.Drawing.Point(244, 24);
            this.ftLabel1.Name = "ftLabel1";
            this.ftLabel1.OverrideDefault = false;
            this.ftLabel1.Size = new System.Drawing.Size(43, 13);
            this.ftLabel1.TabIndex = 93;
            this.ftLabel1.Text = "Cust ID";
            // 
            // txtEntityCode
            // 
            this.txtEntityCode.Enabled = false;
            this.txtEntityCode.Location = new System.Drawing.Point(61, 20);
            this.txtEntityCode.MaxLength = 50;
            this.txtEntityCode.Name = "txtEntityCode";
            this.txtEntityCode.Size = new System.Drawing.Size(149, 20);
            this.txtEntityCode.TabIndex = 87;
            this.txtEntityCode.TextChanged += new System.EventHandler(this.txtEntityCode_TextChanged);
            // 
            // ftlblEntityCode
            // 
            this.ftlblEntityCode.AllowForeColorChange = false;
            this.ftlblEntityCode.AutoSize = true;
            this.ftlblEntityCode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftlblEntityCode.ForeColor = System.Drawing.Color.Black;
            this.ftlblEntityCode.Location = new System.Drawing.Point(6, 24);
            this.ftlblEntityCode.Name = "ftlblEntityCode";
            this.ftlblEntityCode.OverrideDefault = false;
            this.ftlblEntityCode.Size = new System.Drawing.Size(44, 13);
            this.ftlblEntityCode.TabIndex = 90;
            this.ftlblEntityCode.Text = "CDD No";
            // 
            // ftLabel78
            // 
            this.ftLabel78.AllowForeColorChange = false;
            this.ftLabel78.AutoSize = true;
            this.ftLabel78.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel78.ForeColor = System.Drawing.Color.Black;
            this.ftLabel78.Location = new System.Drawing.Point(6, 75);
            this.ftLabel78.Name = "ftLabel78";
            this.ftLabel78.OverrideDefault = false;
            this.ftLabel78.Size = new System.Drawing.Size(34, 13);
            this.ftLabel78.TabIndex = 91;
            this.ftLabel78.Text = "Name";
            // 
            // btnApply
            // 
            this.btnApply.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnApply.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnApply.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnApply.Image = ((System.Drawing.Image)(resources.GetObject("btnApply.Image")));
            this.btnApply.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnApply.Location = new System.Drawing.Point(711, 641);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new System.Drawing.Size(84, 25);
            this.btnApply.TabIndex = 140;
            this.btnApply.Text = "&Save";
            this.btnApply.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnApply.UseVisualStyleBackColor = true;
            this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
            // 
            // tbCustomization
            // 
            this.tbCustomization.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.tbCustomization.Location = new System.Drawing.Point(4, 22);
            this.tbCustomization.Name = "tbCustomization";
            this.tbCustomization.Size = new System.Drawing.Size(787, 499);
            this.tbCustomization.TabIndex = 7;
            this.tbCustomization.Text = "Customization";
            // 
            // tbNote
            // 
            this.tbNote.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.tbNote.Location = new System.Drawing.Point(4, 22);
            this.tbNote.Margin = new System.Windows.Forms.Padding(1);
            this.tbNote.Name = "tbNote";
            this.tbNote.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.tbNote.Size = new System.Drawing.Size(787, 499);
            this.tbNote.TabIndex = 6;
            this.tbNote.Text = "Note";
            // 
            // tbProduct
            // 
            this.tbProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.tbProduct.Location = new System.Drawing.Point(4, 22);
            this.tbProduct.Name = "tbProduct";
            this.tbProduct.Padding = new System.Windows.Forms.Padding(3);
            this.tbProduct.Size = new System.Drawing.Size(787, 499);
            this.tbProduct.TabIndex = 4;
            this.tbProduct.Text = "Product";
            // 
            // tbDocUpload
            // 
            this.tbDocUpload.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.tbDocUpload.Location = new System.Drawing.Point(4, 22);
            this.tbDocUpload.Name = "tbDocUpload";
            this.tbDocUpload.Padding = new System.Windows.Forms.Padding(3);
            this.tbDocUpload.Size = new System.Drawing.Size(787, 499);
            this.tbDocUpload.TabIndex = 3;
            this.tbDocUpload.Text = "Doc Upload";
            // 
            // tbOthers
            // 
            this.tbOthers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.tbOthers.Location = new System.Drawing.Point(4, 22);
            this.tbOthers.Name = "tbOthers";
            this.tbOthers.Padding = new System.Windows.Forms.Padding(3);
            this.tbOthers.Size = new System.Drawing.Size(787, 499);
            this.tbOthers.TabIndex = 2;
            this.tbOthers.Text = "Others";
            // 
            // tbAuthorisedSignatories
            // 
            this.tbAuthorisedSignatories.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.tbAuthorisedSignatories.Location = new System.Drawing.Point(4, 22);
            this.tbAuthorisedSignatories.Name = "tbAuthorisedSignatories";
            this.tbAuthorisedSignatories.Padding = new System.Windows.Forms.Padding(3);
            this.tbAuthorisedSignatories.Size = new System.Drawing.Size(787, 499);
            this.tbAuthorisedSignatories.TabIndex = 1;
            this.tbAuthorisedSignatories.Text = "Related Party";
            // 
            // tbBank
            // 
            this.tbBank.Location = new System.Drawing.Point(4, 22);
            this.tbBank.Name = "tbBank";
            this.tbBank.Size = new System.Drawing.Size(787, 499);
            this.tbBank.TabIndex = 5;
            this.tbBank.Text = "Bank";
            this.tbBank.UseVisualStyleBackColor = true;
            // 
            // tbAccount
            // 
            this.tbAccount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.tbAccount.Location = new System.Drawing.Point(4, 22);
            this.tbAccount.Margin = new System.Windows.Forms.Padding(0);
            this.tbAccount.Name = "tbAccount";
            this.tbAccount.Padding = new System.Windows.Forms.Padding(3, 2, 0, 0);
            this.tbAccount.Size = new System.Drawing.Size(787, 499);
            this.tbAccount.TabIndex = 0;
            this.tbAccount.Text = "Account";
            // 
            // tbEntity1
            // 
            this.tbEntity1.AccessibleDescription = "";
            this.tbEntity1.AccessibleName = "";
            this.tbEntity1.Controls.Add(this.tbAccount);
            this.tbEntity1.Controls.Add(this.tbBank);
            this.tbEntity1.Controls.Add(this.tbAuthorisedSignatories);
            this.tbEntity1.Controls.Add(this.tbOthers);
            this.tbEntity1.Controls.Add(this.tbDocUpload);
            this.tbEntity1.Controls.Add(this.tbProduct);
            this.tbEntity1.Controls.Add(this.tbTrading);
            this.tbEntity1.Controls.Add(this.tbOperations);
            this.tbEntity1.Controls.Add(this.tbNote);
            this.tbEntity1.Controls.Add(this.tbCustomization);
            this.tbEntity1.Location = new System.Drawing.Point(3, 110);
            this.tbEntity1.Name = "tbEntity1";
            this.tbEntity1.SelectedIndex = 0;
            this.tbEntity1.Size = new System.Drawing.Size(795, 525);
            this.tbEntity1.TabIndex = 89;
            this.tbEntity1.SelectedIndexChanged += new System.EventHandler(this.tbEntity1_SelectedIndexChanged);
            this.tbEntity1.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tbEntity1_Selecting);
            // 
            // tbTrading
            // 
            this.tbTrading.AutoScroll = true;
            this.tbTrading.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.tbTrading.Controls.Add(this.tabControl2);
            this.tbTrading.Location = new System.Drawing.Point(4, 22);
            this.tbTrading.Name = "tbTrading";
            this.tbTrading.Padding = new System.Windows.Forms.Padding(3);
            this.tbTrading.Size = new System.Drawing.Size(787, 499);
            this.tbTrading.TabIndex = 9;
            this.tbTrading.Text = "Trading";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tbDetails);
            this.tabControl2.Controls.Add(this.tbDeposits);
            this.tabControl2.Location = new System.Drawing.Point(1, 1);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(783, 494);
            this.tabControl2.TabIndex = 0;
            // 
            // tbDetails
            // 
            this.tbDetails.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.tbDetails.Location = new System.Drawing.Point(4, 22);
            this.tbDetails.Name = "tbDetails";
            this.tbDetails.Padding = new System.Windows.Forms.Padding(3);
            this.tbDetails.Size = new System.Drawing.Size(775, 468);
            this.tbDetails.TabIndex = 0;
            this.tbDetails.Text = "Details";
            // 
            // tbDeposits
            // 
            this.tbDeposits.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.tbDeposits.Location = new System.Drawing.Point(4, 22);
            this.tbDeposits.Name = "tbDeposits";
            this.tbDeposits.Padding = new System.Windows.Forms.Padding(3);
            this.tbDeposits.Size = new System.Drawing.Size(775, 468);
            this.tbDeposits.TabIndex = 1;
            this.tbDeposits.Text = "Deposits";
            // 
            // tbOperations
            // 
            this.tbOperations.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.tbOperations.Controls.Add(this.tbEntityOperations);
            this.tbOperations.Location = new System.Drawing.Point(4, 22);
            this.tbOperations.Name = "tbOperations";
            this.tbOperations.Size = new System.Drawing.Size(787, 499);
            this.tbOperations.TabIndex = 10;
            this.tbOperations.Text = "Operations";
            // 
            // tbEntityOperations
            // 
            this.tbEntityOperations.Controls.Add(this.tbPreferences);
            this.tbEntityOperations.Controls.Add(this.tbCustodian);
            this.tbEntityOperations.Location = new System.Drawing.Point(0, 0);
            this.tbEntityOperations.Name = "tbEntityOperations";
            this.tbEntityOperations.SelectedIndex = 0;
            this.tbEntityOperations.Size = new System.Drawing.Size(784, 496);
            this.tbEntityOperations.TabIndex = 0;
            // 
            // tbPreferences
            // 
            this.tbPreferences.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.tbPreferences.Location = new System.Drawing.Point(4, 22);
            this.tbPreferences.Name = "tbPreferences";
            this.tbPreferences.Padding = new System.Windows.Forms.Padding(3);
            this.tbPreferences.Size = new System.Drawing.Size(776, 470);
            this.tbPreferences.TabIndex = 0;
            this.tbPreferences.Text = "Preferences";
            // 
            // tbCustodian
            // 
            this.tbCustodian.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.tbCustodian.Location = new System.Drawing.Point(4, 22);
            this.tbCustodian.Name = "tbCustodian";
            this.tbCustodian.Padding = new System.Windows.Forms.Padding(3);
            this.tbCustodian.Size = new System.Drawing.Size(776, 470);
            this.tbCustodian.TabIndex = 1;
            this.tbCustodian.Text = "Custodian";
            // 
            // frmEntityDetail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(802, 672);
            this.Controls.Add(this.btnApply);
            this.Controls.Add(this.btnAuditTrail);
            this.Controls.Add(this.btnMakerCancel);
            this.Controls.Add(this.pnlButtons);
            this.Controls.Add(this.ImgPhoto);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tbEntity1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmEntityDetail";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Individual";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmEntityDetail_FormClosing);
            this.Load += new System.EventHandler(this.frmEntityNew_Load);
            this.pnlButtons.ResumeLayout(false);
            this.pnlButtons.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImgPhoto)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tbEntity1.ResumeLayout(false);
            this.tbTrading.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tbOperations.ResumeLayout(false);
            this.tbEntityOperations.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private MatchCommon.CustomControls.FTButton btnApply;
        private MatchCommon.CustomControls.FTLabel lblMobileNo;
        private System.Windows.Forms.PictureBox ImgPhoto;
        private System.Windows.Forms.GroupBox groupBox1;
        private MatchCommon.CustomControls.FTLabel ftLabel2;
        private MatchCommon.CustomControls.FTTextBox txtCustId;
        private MatchCommon.CustomControls.FTLabel ftLabel1;
        private System.Windows.Forms.TextBox txtEntityCode;
        private MatchCommon.CustomControls.FTLabel ftlblEntityCode;
        private MatchCommon.CustomControls.FTLabel ftLabel78;
        private MatchCommon.CustomControls.FTTextBox txtNameHead;
        private MatchCommon.CustomControls.FTTextBox txtFormId;
        private MatchCommon.CustomControls.FTLabel lblAuthStatus;
        private System.Windows.Forms.Panel pnlButtons;
        private MatchCommon.CustomControls.FTTextBox txtDefaultID;
        private MatchCommon.CustomControls.FTLabel ftLabel3;
        protected MatchCommon.CustomControls.FTButton btnAuditTrail;
        protected MatchCommon.CustomControls.FTButton btnMakerCancel;
        private MatchCommon.CustomControls.FTComboBox cboTitle;
        private System.Windows.Forms.TabPage tbCustomization;
        private System.Windows.Forms.TabPage tbNote;
        private System.Windows.Forms.TabPage tbProduct;
        private System.Windows.Forms.TabPage tbDocUpload;
        private System.Windows.Forms.TabPage tbOthers;
        private System.Windows.Forms.TabPage tbAuthorisedSignatories;
        private System.Windows.Forms.TabPage tbBank;
        private System.Windows.Forms.TabPage tbAccount;
        private System.Windows.Forms.TabControl tbEntity1;
        private System.Windows.Forms.TabPage tbTrading;
        private System.Windows.Forms.TabPage tbOperations;
        private MatchCommon.CustomControls.FTLabel ftCreated;
        private System.Windows.Forms.Label lblShortCode;
        private MatchCommon.CustomControls.FTTextBox txtShortCode;
        private System.Windows.Forms.Label lblBranch;
        private MatchCommon.CustomControls.FTTextBox txtBranchCode;
        private System.Windows.Forms.TabControl tbEntityOperations;
        private System.Windows.Forms.TabPage tbPreferences;
        private System.Windows.Forms.TabPage tbCustodian;
        private MatchCommon.CustomControls.FTTextBox txtCreated;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tbDetails;
        private System.Windows.Forms.TabPage tbDeposits;
    }
    
}