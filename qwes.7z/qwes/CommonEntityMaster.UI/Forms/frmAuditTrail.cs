using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Collections;
using System.Windows.Forms;
using MatchCommon;
using C1.Win.C1FlexGrid;
using FTIL.Match.Common;
using FTIL.Match.Common.Log;  
using C1.Win.C1TrueDBGrid; 
using System.Security.Cryptography;
using System.Configuration;
using FTIL.Match.CDD.BAL;


/// <summary>
///================================================================================          
/// File/Class/Custom Name    : frmAuditConfig.cs
/// Base CR No.               : 
/// Author                    : Kushal Sharma
/// DateCreated               : 16/10/2014
/// Reviewd By                :
/// Description               : Audit Details UI class
///================================================================================

///================================================================================
///                           Revision History
///================================================================================          
/// Author                    :
/// Revision/CR No.           :
/// Revision Date             :
/// Reviewd By                :          
/// Reason for Revision       :
///================================================================================
/// </summary>

namespace FTIL.Match.CDD.UI.Forms
{
    public partial class frmAuditTrail : MatchCommon.UI.Forms.frmMatchBase
    {
        #region Variables

        CAudittrail m_objAudittrail; 
        BindingSource m_bsGroupMgmt; 
        CListItem l_objNewList;   
        string ErrorMsg = string.Empty;
        DataSet dsAudit = new DataSet();
        DataSet l_dsLookup;
        BindingSource bsGrp = new BindingSource();
        string AuditEntityCode;
        string Audittablename;
       /* public int ClientNo
        {
            get { return m_objClientNo; }
            set { m_objClientNo = value; }
        }*/
        #endregion

        #region Constructor
        public frmAuditTrail()
        {
            InitializeComponent();
            m_objAudittrail = new CAudittrail();
            m_bsGroupMgmt = new BindingSource(); 
            this.KeyPreview = true; 
        }
        public frmAuditTrail( string EntityCode,string TableName)
        {
            InitializeComponent();
            m_objAudittrail = new CAudittrail();
            m_bsGroupMgmt = new BindingSource();
            this.KeyPreview = true; 
            Audittablename = TableName;
            AuditEntityCode = EntityCode;
            txtCode.Text = EntityCode;
        }  
        #endregion

        #region frmAuditTrail_Load
        private void frmAuditTrail_Load(object sender, EventArgs e)
        {
            m_objAudittrail.OperationType = "T";
            m_objAudittrail.FromDate = null;
            m_objAudittrail.ToDate = null;
            m_objAudittrail.AuditTrailOperation(ref l_dsLookup);
            cboOperations.SelectedIndex = 0;

            foreach (DataRow dr in l_dsLookup.Tables[0].Rows)
            {
                l_objNewList = new CListItem();
                l_objNewList.DataValue = dr[CAudittrail.MODULENAME].ToString();
                l_objNewList.DisplayValue = dr[CAudittrail.MODULENAME].ToString();
                cboModuleName.Items.Add(l_objNewList);
            } 
            if (cboModuleName.Items.Count > 0)
                cboModuleName.SelectedIndex = 0;

            if (Audittablename != null)
                    AuditTrailFromClientMaster();
        }

        private void AuditTrailFromClientMaster()
        { 
            cboModuleName.Enabled = false;
            cboScreenName.Enabled = false; 
            FillGrid();

        }
        /// <summary>
        ///  Method to fill Audit Trail Grid
        /// </summary>
        private void FillGrid()
        {
            try
            {
                m_objAudittrail.OperationType = "G";
                CListItem ddlItem;
                try { m_objAudittrail.FromDate = txtFromDate.Text.ToString(); }
                catch { }

                try { m_objAudittrail.ToDate = txtToDate.Text.ToString(); }
                catch { }

                ddlItem = (CListItem)cboScreenName.SelectedItem;
                if (ddlItem != null)
                    m_objAudittrail.SubModuleName = ddlItem.DisplayValue;
                else
                    m_objAudittrail.SubModuleName = null;

                ddlItem = (CListItem)cboTableName.SelectedItem;
                if (ddlItem != null)
                    m_objAudittrail.TableDescription = ddlItem.DataValue;
                else
                    m_objAudittrail.TableDescription = null;

                m_objAudittrail.Type = cboOperations.SelectedItem.ToString();

                m_objAudittrail.ClientCode = txtCode.Text.ToString();

                m_objAudittrail.AuditTrailOperation(ref dsAudit);
                BindingSource bs = new BindingSource();
                bs.DataSource = dsAudit.Tables[0];
                dgvAudit.DataSource = bs;
                
                foreach (C1DisplayColumn col1 in dgvAudit.Splits[0].DisplayColumns)
                    col1.AutoSize();
     
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to Open report");
                Logger.Instance.WriteLog(typeof(frmAuditTrail), ex.Message);
                this.Close();
            }
        }
        #endregion

      

    
        #region GetErrorMessage
        private string GetErrorMessage(DataTable p_vdtLog)
        {
            if (p_vdtLog == null)
                return "";

            if ((p_vdtLog != null) && (p_vdtLog.Rows.Count > 0))
            {
                if (p_vdtLog.Columns.Contains("ErrorMsg"))
                {
                    return p_vdtLog.Rows[0]["ErrorMsg"].ToString();
                }
            }

            return "";
        }
        #endregion
         
        #region IMasterUI Members

        #region InitGrid
        public long InitGrid()
        {
            return -1;
        }
        #endregion

        #region BindFormField
        public long BindFormField()
        {
            return -1;
        }
        #endregion
        #endregion
          
        
        private void btnClose_Click(object sender, EventArgs e)
        { 
            this.Close();
        }
         private void btnCloseHdn_Click(object sender, EventArgs e)
         {
             this.Close();
         }

         private void cboModuleName_SelectedIndexChanged(object sender, EventArgs e)
         {
            /* if (isSelectedChange == true)
             { */
                 cboScreenName.Items.Clear();
                 DataRow[] Rows = l_dsLookup.Tables[1].Select(CAudittrail.MODULENAME + " = '" + ((CListItem)(cboModuleName.SelectedItem)).DataValue + "'");
                   
                 foreach (DataRow dr in Rows)
                 {
                     l_objNewList = new CListItem();
                     l_objNewList.DataValue = dr[CAudittrail.SUBMODULENAME].ToString();
                     l_objNewList.DisplayValue = dr[CAudittrail.SUBMODULENAME].ToString();
                     cboScreenName.Items.Add(l_objNewList);
                 }

                 if (cboScreenName.Items.Count > 0)
                     cboScreenName.SelectedIndex = 0; 
           //  }
         }

         private void btnView_Click(object sender, EventArgs e)
         {
             FillGrid();
         }

         private void cboScreenName_SelectedIndexChanged(object sender, EventArgs e)
         {
             cboTableName.Items.Clear();
             DataRow[] Rows = l_dsLookup.Tables[2].Select(CAudittrail.SUBMODULENAME + " = '" + ((CListItem)(cboScreenName.SelectedItem)).DataValue + "'");
              
             foreach (DataRow dr in Rows)
             {
                 l_objNewList = new CListItem();
                 l_objNewList.DataValue = dr[CAudittrail.VIEWNAME].ToString();
                 l_objNewList.DisplayValue = dr[CAudittrail.TABLEDESCRIPTION].ToString();
                 cboTableName.Items.Add(l_objNewList);

                 if (dr[CAudittrail.TABLEDESCRIPTION].ToString() == Audittablename)
                 {
                     cboTableName.SelectedItem = l_objNewList; 
                 }   
             }

             if (cboTableName.SelectedIndex < 0)
                     cboTableName.SelectedIndex = 0; 
         }

         private void frmAuditTrail_KeyUp(object sender, KeyEventArgs e)
         {
             if (e.KeyCode == Keys.Escape) this.Close();
         }

         private void btnExport_Click(object sender, EventArgs e)
         {
             SaveFileDialog saveFileDialog = new SaveFileDialog();
             saveFileDialog.Filter = "xls files (*.xls)|*.xls";

             saveFileDialog.FileName = "AuditExport.xls";

             DialogResult result = saveFileDialog.ShowDialog();

             if (result != DialogResult.OK)
             {
                 return;
             }
             try
             {
                 dgvAudit.ExportToExcel(saveFileDialog.FileName);

             }
             catch (Exception)
             {
                 MessageBox.Show("Unable to export Data. ", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
             }
         } 

        
 
    }
}
