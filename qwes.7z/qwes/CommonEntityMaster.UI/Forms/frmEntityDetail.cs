﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.CDD.UI.UserControls;
using FTIL.Match.CDD.BAL;
using FTIL.Match.Common;
using FTIL.Match.Common.Log;
using System.IO;
using System.Threading;
using C1.Win.C1FlexGrid;

namespace FTIL.Match.CDD.UI.Forms
{
    /// <summary>
    /// Form to show Entity details 
    /// </summary>
    public partial class frmEntityDetail : MatchCommon.UI.Forms.frmMatchBase
    {
        private int m_CurrentRowNo = -1;
        private long m_DocumentUploadMaxLimit;
        byte[] imgBytes = null;

        /// <summary>
        /// Event handler to add individual
        /// </summary>
        public EventHandler AddIndividualEventHander { get; set; }


        public int CurrentRowNo
        {
            get { return m_CurrentRowNo; }
            set { m_CurrentRowNo = value; }
        }

        internal event EventHandler<SelectRowEventArg> ChangeSelectedRow;

        public string OperationFlag { get; set; }
        public string OperationTagFlag { get; set; }

        internal EntityManager EntityManagerInstance { get; set; }
        CExchangeMap m_ObjExchange = new CExchangeMap();
        public DataTable dtExchange = null;


        public frmEntityDetail()
        {
            InitializeComponent();

            this.KeyPreview = true;

            EntityManagerInstance = new EntityManager();

            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmEntityDetail_KeyUp);

            ImgPhoto.Image = null;  // SetDefaultImg();
          
            m_DocumentUploadMaxLimit =
                   Convert.ToInt64(System.Configuration.ConfigurationManager.AppSettings["PhotoUploadMaxLimitBytes"]);
        }

        private ucBaseEntity objEntityAccount;
        private ucBaseEntity objEntityAccountNonInd;
        private ucBaseEntity objEntityOthers;
        private ucBaseEntity objEntityDocUpload;
        private ucBaseEntity objBank;        
        private ucBaseEntity objEntityAuthSign;
        private ucEntityProduct objucEntityProduct;
        private ucNote objucNote;
        private ucCustomization objCustom;        
        private ucODINPreferences objODINPreferences;
        private ucDeposits objDeposits;
        private ucClientPreferences objucClientPreferences;
        private ucCustodian objCustodian;
   

        /// <summary>
        /// Entity type for switching the controls
        /// </summary>
        public string EntityType { get; set; }


        private void frmEntityNew_Load(object sender, EventArgs e)
        {
            try
            {

                txtCreated.Text = DateTime.Today.ToShortDateString();

                BindUserControls(false);

                if (OperationFlag != "M")
                {
                    btnMakerCancel.Enabled = false;
                    btnAuditTrail.Enabled = false;

                }


                this.Cursor = Cursors.Default;

                this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));            

            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                Logger.Instance.WriteLog(typeof(frmEntityDetail), ex.Message);
            }

            txtFormId.SelectionStart = 0;
            txtFormId.SelectionLength = txtFormId.Text.Length;
            txtFormId.Focus();
            txtFormId.Select();

        }


        /// <summary>
        /// Bind controls with Entity Data
        /// </summary>
        /// <param name="byRowNo"></param>
        private void BindUserControls(bool byRowNo)
        {
            frmEntityMaster.deleteFlag = 0;
            try
            {
                OperationTagFlag = OperationFlag;

                ImgPhoto.Image = null;
                //Edit mode
                if (OperationFlag == "M")
                {
                    if (byRowNo)
                        EntityManagerInstance.SetEntityDetails(m_CurrentRowNo, byRowNo);
                    else // By ClientNo
                        EntityManagerInstance.SetEntityDetails(-1, byRowNo);

                    //EntityManagerInstance.SetGuardianDetails(m_CurrentRowNo, byRowNo);

                    EntityType = EntityManagerInstance.EntityDetails.EntityType;
                }

                //cboTitle.ValueMember = "s_ReferenceCode";
                //cboTitle.DisplayMember = "s_ReferenceName";
                //cboTitle.DataSource = UCC.Class.CReferenceDataProvider.Instance[UCC.Class.CReferenceDataProvider.ReferenceType.GENDER]; //l_dsPopulateClientDetails.Tables[1];
                cboTitle.Items.Clear();
                cboTitle.Items.Add("Mr");
                cboTitle.Items.Add("Mrs");
                cboTitle.Items.Add("Ms");


                if (EntityType == CCMConstants.INDIVIDUAL)
                {

                    if (objEntityAccountNonInd != null)
                        tbAccount.Controls.Remove(objEntityAccountNonInd);

                    objEntityAccountNonInd = null;

                    if (objEntityAccount == null)
                    {
                        objEntityAccount = new ucEntityAccount();
                        objEntityAccount.Dock = DockStyle.Fill;
                        tbAccount.Controls.Add(objEntityAccount);

                        ((ucEntityAccount)objEntityAccount).GenderSelectionChange =
                            this.cboGender_SelectedIndexChanged;

                        tbAccount.Tag = objEntityAccount;

                        this.Text = "Individual";
                        ImgPhoto.Visible = true;
                        //ImgPhoto.Image= Image.FromFile(@".\Images\Individual.jpg");//change for CDD Phase2
                        txtNameHead.BackColor = UIConstants.CtrlBackColorMandatory;
                        objEntityAccount.sClientHeaderName = this.Text;


                    }


                }
                else if (EntityType == CCMConstants.NON_INDIVIDUAL)
                {
                    if (objEntityAccount != null)
                        tbAccount.Controls.Remove(objEntityAccount);

                    if (objEntityAccountNonInd == null)
                    {
                        objEntityAccountNonInd = new ucEntityAcountNonInd();

                        objEntityAccountNonInd.Dock = DockStyle.Fill;

                        tbAccount.Controls.Add(objEntityAccountNonInd);
                        tbAccount.Tag = objEntityAccountNonInd;
                        this.Text = "Non-Individual";
                        groupBox1.Width = 779;
                        ImgPhoto.Visible = true;
                        SetDefaultImg();
                        // ImgPhoto.Image = Image.FromFile(@".\Images\NonIndividual.jpg");
                        // txtNameHead.BackColor = objEntityAccountNonInd.ctrlBackColor;
                        objEntityAccountNonInd.sClientHeaderName = "Non-Individual";

                    }

                    objEntityAccount = null;
                }

                if (objEntityAuthSign == null)
                {

                    objEntityAuthSign = new ucEntityAuthSign();
                    objEntityAuthSign.EntityType = EntityType;
                    objEntityAuthSign.OnAddIndividual += AddIndividualEventHander;
                    objEntityAuthSign.Dock = DockStyle.Fill;
                    tbAuthorisedSignatories.Controls.Add(objEntityAuthSign);
                    tbAuthorisedSignatories.Tag = objEntityAuthSign;
                }

                if (objEntityOthers == null)
                {
                    objEntityOthers = new ucEntityOthers();
                    objEntityOthers.EntityType = EntityType;
                    objEntityOthers.Dock = DockStyle.Fill;
                    tbOthers.Controls.Add(objEntityOthers);
                    tbOthers.Tag = objEntityOthers;
                }
                if (objEntityDocUpload == null)
                {
                    objEntityDocUpload = new ucEntityDocUpload();
                    objEntityDocUpload.Dock = DockStyle.Fill;
                    tbDocUpload.Controls.Add(objEntityDocUpload);
                    tbDocUpload.Tag = objEntityDocUpload;
                }
                if (objBank == null)
                {
                    objBank = new ucBank();
                    objBank.Dock = DockStyle.Fill;
                    //objBank.sName = EntityManagerInstance.EntityDetails.Applicant_Name;
                    tbBank.Controls.Add(objBank);
                    tbBank.Tag = objBank;
                }

                if (objucEntityProduct == null)
                {
                    objucEntityProduct = new ucEntityProduct();
                    objucEntityProduct.Dock = DockStyle.Fill;
                    tbProduct.Controls.Add(objucEntityProduct);
                    tbProduct.Tag = objucEntityProduct;
                }
                if (objucNote == null)
                {
                    objucNote = new ucNote();
                    objucNote.NoteDescription = "CDD NOTE";
                    objucNote.Dock = DockStyle.Fill;
                    tbNote.Controls.Add(objucNote);
                    tbNote.Tag = objucNote;
                }
                if (objCustom == null)
                {
                    objCustom = new ucCustomization();
                    objCustom.Dock = DockStyle.Fill;
                    tbCustomization.Controls.Add(objCustom);
                    tbCustomization.Tag = objCustom;

                }
                

                if (objODINPreferences == null)
                {
                    objODINPreferences = new ucODINPreferences();
                    objODINPreferences.Dock = DockStyle.Top;
                    tbDetails.Controls.Add(objODINPreferences);
                    tbDetails.Tag = objODINPreferences;
                }
                if (objDeposits == null)
                {
                    objDeposits = new ucDeposits();
                    objDeposits.Dock = DockStyle.Top;
                    tbDeposits.Controls.Add(objDeposits);
                    tbDeposits.Tag = objODINPreferences;
                }


                if (objucClientPreferences == null)
                {
                    objucClientPreferences = new ucClientPreferences();
                    objucClientPreferences.Dock = DockStyle.Fill;
                    tbPreferences.Controls.Add(objucClientPreferences);
                    tbPreferences.Tag = objucClientPreferences;
                    objucClientPreferences.EntityType = EntityType;
                }

                if (objCustodian == null)
                {
                    objCustodian = new ucCustodian();
                    objCustodian.Dock = DockStyle.Fill;
                    tbCustodian.Controls.Add(objCustodian);
                    tbCustodian.Tag = objCustodian;

                }

           

                ////Edit mode
                if (OperationFlag == "M")
                {
                    PopulateFields();
                }

                btnMakerCancel.Enabled = CanEnableMakerCancel();


                objBank.sClientHeaderName = this.Text;
                objCustom.sClientHeaderName = this.Text;
                objEntityAuthSign.sClientHeaderName = this.Text;
                objEntityDocUpload.sClientHeaderName = this.Text;
                objEntityOthers.sClientHeaderName = this.Text;
                objucEntityProduct.sClientHeaderName = this.Text;
                objCustodian.sClientHeaderName = this.Text;
                this.Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                Logger.Instance.WriteLog(typeof(frmEntityDetail), ex.Message);
            }
        }

        /// <summary>
        /// Apply button event handler to save EntityDetails
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnApply_Click(object sender, EventArgs e)
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;
                if (tbEntity1.SelectedTab.Name.ToUpper() == "TBNOTE")
                {
                    objucNote.UpdateNote();
                    this.Cursor = Cursors.Default;
                    return;
                }

                //-------------Anil Added for saving details for the exchange-----------------
                //if (tbEntity1.SelectedTab.Name.ToUpper() == "TBPRODUCT")
                //{
                //    objucEntityProduct.Save();
                //}
                //----------------------------------------------------------------------------

                if (EntityType == CCMConstants.INDIVIDUAL)
                {

                    objEntityAccount.sName = txtNameHead.Text;
                    //change for CDD Phase 2
                    objEntityAccount.sBranch = txtBranchCode.Text;
                    objEntityAccount.sShortCode = txtShortCode.Text;

                    objEntityAccount.n_Solutation = cboTitle.SelectedIndex + 1;
                    EntityManagerInstance.EntityDetails = objEntityAccount.GetEntityDetails();
                    EntityManagerInstance.AccDetailUpdatedFlag = objEntityAccount.HasUpdated;
                    EntityManagerInstance.PerAddressUpdated = objEntityAccount.PerAddressUpdated;
                    EntityManagerInstance.CorrAddressUpdated = objEntityAccount.CorrAddressUpdated;

                }
                else if (EntityType == CCMConstants.NON_INDIVIDUAL)
                {
                    objEntityAccountNonInd.sName = txtNameHead.Text;
                    //change for CDD Phase 2
                    objEntityAccountNonInd.sBranch = txtBranchCode.Text;
                    objEntityAccountNonInd.sShortCode = txtShortCode.Text;
                    


                    objEntityAccountNonInd.n_Solutation = cboTitle.SelectedIndex + 1;
                    EntityManagerInstance.EntityDetails = objEntityAccountNonInd.GetEntityDetails();
                    EntityManagerInstance.AccDetailUpdatedFlag = objEntityAccountNonInd.HasUpdated;
                    EntityManagerInstance.PerAddressUpdated = objEntityAccountNonInd.PerAddressUpdated;
                    EntityManagerInstance.CorrAddressUpdated = objEntityAccountNonInd.CorrAddressUpdated;
    
                }

                if (EntityManagerInstance.EntityDetails.IsValid != false)
                    EntityManagerInstance.EntityAuthSignDetail = ((ucEntityAuthSign)objEntityAuthSign).EntityAuthSignDetails;

                //EntityManagerInstance.EntityDetails.DateOfCreation = dtCreated.Value; //change for CDD Phase 2
                EntityManagerInstance.EntityDetails.DateOfCreation = DateTime.Now;
                EntityManagerInstance.EntityDetails.Applicant_Name = txtNameHead.Text;


                EntityManagerInstance.EntityDetails.Branch = txtBranchCode.Text;
                EntityManagerInstance.EntityDetails.Short_Code = txtShortCode.Text;

                EntityManagerInstance.EntityDetails.KYCFormNo = txtFormId.Text;
                EntityManagerInstance.EntityDetails.n_Solutation = cboTitle.SelectedIndex + 1;
                //Other Tab
                if (EntityManagerInstance.EntityDetails.IsValid != false && tbEntity1.SelectedTab.Name.ToUpper() == "TBOTHERS"
                    )
                {
                    EntityManagerInstance.EntityOtherDetails = ((ucEntityOthers)objEntityOthers).EntityDocDetails;
                    ((ucEntityOthers)objEntityOthers).EntityAccountInstance = EntityManagerInstance.EntityDetails;
                    EntityManagerInstance.EntityDetails = ((ucEntityOthers)objEntityOthers).GetEntityDetails();
                    EntityManagerInstance.AccDocDetailUpdatedFlag = ((ucEntityOthers)objEntityOthers).HasUpdated;                 
                }
                else
                {
                    EntityManagerInstance.EntityOtherDetails = ((ucEntityOthers)objEntityOthers).EntityDocDetails;
                    ((ucEntityOthers)objEntityOthers).EntityAccountInstance = EntityManagerInstance.EntityDetails;
                    EntityManagerInstance.EntityDetails = ((ucEntityOthers)objEntityOthers).GetEntityDetails(true);
                    EntityManagerInstance.AccDocDetailUpdatedFlag = ((ucEntityOthers)objEntityOthers).HasUpdated;
                }


                //Bank tab
                if (EntityManagerInstance.EntityDetails.IsValid != false && tbEntity1.SelectedTab.Name.ToUpper() == "TBBANK")
                {
                    EntityManagerInstance.EntityBankDetails = ((ucBank)objBank).EntityBankDetails;
                    //EntityManagerInstance.EntityDetails = ((ucEntityOthers)objEntityOthers).GetEntityDetails();
                    EntityManagerInstance.AccBankDetailUpdatedFlag = ((ucBank)objBank).HasUpdated;                    
                }

                if (tbEntity1.SelectedTab.Name.ToUpper() == "TBOPERATIONS")
                {
					//custodian Tab
                    if (EntityManagerInstance.EntityDetails.IsValid != false && tbEntityOperations.SelectedTab.Name.ToUpper() == "TBCUSTODIAN")
                    {
                        objCustodian.SyncDataTable();
                        EntityManagerInstance.EntityCustodianDetails = ((ucCustodian)objCustodian).EntityCustodianDetails;
                        EntityManagerInstance.CustodianDetailUpdatedFlag = ((ucCustodian)objCustodian).HasUpdated;
                        
                    }
				//Operations tab
                	if (EntityManagerInstance.EntityDetails.IsValid != false && tbEntityOperations.SelectedTab.Name.ToUpper() == "TBPREFERENCES")
                	{
                    	//EntityManagerInstance.OperationPreference = ((ucClientPreferences)objucClientPreferences).OperationPreference;
                    	EntityManagerInstance.OperationPreference = ((ucClientPreferences)objucClientPreferences).GetEntityPreferenceDetails();
                    	EntityManagerInstance.EntityDetails.IsValid = true;
                	}
                }

                //******************************** ANIL ADDED Product Tab ******************************************************************
                if (EntityManagerInstance.EntityDetails.IsValid != false && tbEntity1.SelectedTab.Name.ToUpper() == "TBPRODUCT")
                {
                    objucEntityProduct.Save();
                    EntityManagerInstance.EntityProductDetails = ((ucEntityProduct)objucEntityProduct).EntityProductDetails;
                    //EntityManagerInstance.EntityDetails = ((ucEntityOthers)objEntityOthers).GetEntityDetails();
                    EntityManagerInstance.AccBankDetailUpdatedFlag = ((ucEntityProduct)objucEntityProduct).HasUpdated;
                   
                }
                //***************************************************************************************************************




                    if (EntityManagerInstance.EntityDetails.IsValid != false)
                {
                    if (tbEntity1.SelectedTab.Name.ToUpper() == "TBOPERATIONS")
                    {
                        EntityManagerInstance.ApplyChanges(OperationFlag, tbEntityOperations.SelectedTab.Name.ToUpper());
                    }
                    else
                    {
                        EntityManagerInstance.ApplyChanges(OperationFlag, tbEntity1.SelectedTab.Name.ToUpper());
                    }
                    objEntityAuthSign.EntityAccountInstance = EntityManagerInstance.EntityDetails;
                    if (EntityManagerInstance.sError != "E")
                    {
                        if (tbEntity1.SelectedTab.Name.ToUpper() == "TBBANK")
                        {
                            objBank.ResetDt();
                            objBank.IsGridUpdated = false;
                        }
                        if (tbEntity1.SelectedTab.Name.ToUpper() == "TBOTHERS")
						{
                            objEntityOthers.ResetDt();
                            objEntityOthers.IsGridUpdated = false;
                        }
                        if (tbEntity1.SelectedTab.Name.ToUpper() == "TBAUTHORISEDSIGNATORIES")
                        {
                            objEntityAuthSign.ResetDt();
                            objEntityAuthSign.IsGridUpdated = false;
                        }
                    }
                    if (tbEntity1.SelectedTab.Name.ToUpper() == "TBOPERATIONS")
                    {
                        objCustodian.BindGrid();
                    }
                        if (OperationFlag == "S")
                    {
                        OperationTagFlag = "M";
                        objCustom.ClientId = EntityManagerInstance.EntityDetails.ClientNo;
                        objCustom.ModifyMode = true;
                        ((ucBank)objBank).sName = EntityManagerInstance.EntityDetails.Applicant_Name;
                    }
                }
                this.Cursor = Cursors.Default;

            }

            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(frmEntityDetail), ex.Message);
                this.Cursor = Cursors.Default;
            }

        }



        /// <summary>
        /// Populate controls (Custom etc.) 
        /// </summary>
        private void PopulateFields()
        {
            try
            {
                if (objEntityAccount != null)
                {
                    objEntityAccount.ModifyMode = true;
                    objEntityAccount.EntityAccountInstance = EntityManagerInstance.EntityDetails;
                    objEntityAccount.PopulateControls();
                    LoadPhotoImage();
                }
                else if (EntityManagerInstance.EntityDetails.sErrorMsg != "" && EntityManagerInstance.EntityDetails.sErrorMsg != null)
                {

                    MessageBox.Show(EntityManagerInstance.EntityDetails.sErrorMsg, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                }
                if (objEntityAccountNonInd != null)
                {
                   
                    objEntityAccountNonInd.ModifyMode = true;
                    objEntityAccountNonInd.EntityAccountInstance = EntityManagerInstance.EntityDetails;
                    objEntityAccountNonInd.PopulateControls();
                    LoadPhotoImage();
                    SetDefaultImg();
                }
                else if (EntityManagerInstance.EntityDetails.sErrorMsg != "" && EntityManagerInstance.EntityDetails.sErrorMsg != null)
                {

                    MessageBox.Show(EntityManagerInstance.EntityDetails.sErrorMsg, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                }

                objEntityAuthSign.ModifyMode = true;
                objEntityAuthSign.EntityAccountInstance = EntityManagerInstance.EntityDetails;
                objEntityAuthSign.PopulateControls();


                objEntityOthers.EntityAccountInstance = EntityManagerInstance.EntityDetails;
                objEntityOthers.ModifyMode = true;
                objEntityOthers.PopulateControls();

                ((ucBank)objBank).ClientId = EntityManagerInstance.EntityDetails.ClientNo;
                ((ucBank)objBank).sName = EntityManagerInstance.EntityDetails.Applicant_Name;
                objBank.ModifyMode = true;
                objBank.PopulateControls();

                m_CurrentRowNo = EntityManagerInstance.EntityDetails.RowNo;
                txtNameHead.Text = EntityManagerInstance.EntityDetails.Applicant_Name;

                txtShortCode.Text = EntityManagerInstance.EntityDetails.Short_Code;
                txtBranchCode.Text = EntityManagerInstance.EntityDetails.Branch;
                if (FormUtil.IsValidDate(EntityManagerInstance.EntityDetails.DateOfCreation))    //change for CDD phase 2
                {
                    //dtCreated.Value = EntityManagerInstance.EntityDetails.DateOfCreation.Value;    //change for CDD phase 2
                    txtCreated.Text = EntityManagerInstance.EntityDetails.DateOfCreation.Value.ToShortDateString();
                }
                txtEntityCode.Text = EntityManagerInstance.EntityDetails.KYCCode;
                txtDefaultID.Text = EntityManagerInstance.EntityDetails.DefaultIDDetails;

                txtCustId.Text = EntityManagerInstance.EntityDetails.CustomerID;
                txtFormId.Text = EntityManagerInstance.EntityDetails.KYCFormNo;
                lblAuthStatus.Text = EntityManagerInstance.EntityDetails.AuthrizationStatus + ". " + EntityManagerInstance.EntityDetails.AuthRemarks;
                cboTitle.SelectedIndex = (EntityManagerInstance.EntityDetails.n_Solutation - 1);

                if (EntityManagerInstance.EntityDetails.LastUpdatedUserNo != AppEnvironment.AppUser.UserNo)
                    btnApply.Enabled = EntityManagerInstance.EntityDetails.IsAuthorized;

                ((ucEntityDocUpload)objEntityDocUpload).ClientNo = EntityManagerInstance.EntityDetails.ClientNo;
                objEntityDocUpload.PopulateControls();

                objucEntityProduct.ClientNo = EntityManagerInstance.EntityDetails.ClientNo;
                objucEntityProduct.CDDCode = EntityManagerInstance.EntityDetails.KYCCode;
                objucEntityProduct.CustId = EntityManagerInstance.EntityDetails.CustomerID;
                objucEntityProduct.ClientName = EntityManagerInstance.EntityDetails.Applicant_Name;
                objucEntityProduct.EntityType = EntityManagerInstance.EntityDetails.EntityType;
                objucEntityProduct.dFromDate = EntityManagerInstance.EntityDetails.DateOfCreation;
                objucEntityProduct.ExNo = EntityManagerInstance.EntityDetails.ClientNo;
                objucEntityProduct.PopulateControls();


                objucEntityProduct.EntityDetails = EntityManagerInstance.EntityDetails;

                objucNote.EntityNo = EntityManagerInstance.EntityDetails.ClientNo;
                objucNote.PopulateControls();

                //Custodian Tab
                objCustodian.ClientNo = EntityManagerInstance.EntityDetails.ClientNo;
                objCustodian.ModifyMode = true;
                objCustodian.PopulateControls();


                ((ucCustomization)objCustom).ClientId = EntityManagerInstance.EntityDetails.ClientNo;
                ((ucCustomization)objCustom).sCustId = EntityManagerInstance.EntityDetails.CustomerID;
                ((ucCustomization)objCustom).ProductNo = 1;
                objCustom.ModifyMode = true;
                objCustom.PopulateControls();



                ((ucClientPreferences)objucClientPreferences).ClientId = EntityManagerInstance.EntityDetails.ClientNo;
                ((ucClientPreferences)objucClientPreferences).sName = EntityManagerInstance.EntityDetails.Applicant_Name;
                objucClientPreferences.ModifyMode = true;
                //objucClientPreferences.PopulateControls();


            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(frmEntityDetail), ex.Message);
            }
        }



        /// <summary>
        /// for KeyUp event 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmEntityDetail_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Escape)
                {
                    this.Close();
                }

                /************************** Navigate Entity Details if PageDown/PageUp press by RowNo ************************************/

                if (e.KeyCode == Keys.PageDown && e.Control == false)
                {
                    if (m_CurrentRowNo == EntityManagerInstance.EntityMasterRecordCount) return;

                    //if (HasUpdated())
                    //{

                    //    DialogResult result = MessageBox.Show("Data have been changed, Do you still want to continue to navigate?"
                    //        , MsgBoxTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    //    if (result != System.Windows.Forms.DialogResult.Yes)
                    //        return;
                    //}

                    m_CurrentRowNo++;

                    BindUserControls(true);

                    //SetValuesFromControls();

                    SelectRowEventArg arg = new SelectRowEventArg();
                    arg.RowNo = m_CurrentRowNo;
                    arg.MoveTo = MoveDirection.Forward;

                    if (ChangeSelectedRow != null)
                        ChangeSelectedRow(this, arg);
                }

                if (e.KeyCode == Keys.PageUp && e.Control == false)
                {
                    if (m_CurrentRowNo == 1) return;

                    //if (HasUpdated())
                    //{

                    //    DialogResult result = MessageBox.Show("Data have been changed, Do you still want to continue to navigate?"
                    //        , MsgBoxTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    //    if (result != System.Windows.Forms.DialogResult.Yes)
                    //        return;
                    //}

                    m_CurrentRowNo--;

                    BindUserControls(true);
                    // SetValuesFromControls();

                    SelectRowEventArg arg = new SelectRowEventArg();
                    arg.RowNo = m_CurrentRowNo;
                    arg.MoveTo = MoveDirection.Backward;

                    if (ChangeSelectedRow != null)
                        ChangeSelectedRow(this, arg);
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(frmEntityDetail), ex.Message);
            }
            /**********************************************************************************************************************/
        }


        private void tbEntity1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (EntityManagerInstance.EntityDetails.LastUpdatedUserNo == AppEnvironment.AppUser.UserNo)
                    btnApply.Enabled = true;
                else
                    btnApply.Enabled = EntityManagerInstance.EntityDetails.IsAuthorized;

                if (tbEntity1.SelectedTab.Name == "tbCustomization")
                    btnApply.Enabled = false;

                if (tbEntity1.SelectedTab.Name == "tbProduct")
                {
                    ////-------------for Save Button Enable and Disable----------------------------
                    //if (EntityManagerInstance.EntityDetails.AuthrizationStatus == "Authorized")
                    //{
                    //    btnApply.Enabled = true;
                    //}
                    //else
                    //{
                    //    btnApply.Enabled = false;
                    //}
                    ////---------------------------------------------------------------------------
                    //  btnApply.Enabled = true;
                }
                if (tbEntity1.SelectedTab.Name == "tbDocUpload")
                {
                    btnApply.Enabled = false;
                    if (EntityManagerInstance.AccDocDetailUpdatedFlag)
                    {
                        ((ucEntityDocUpload)objEntityDocUpload).ClientNo = EntityManagerInstance.EntityDetails.ClientNo;
                        objEntityDocUpload.ModifyMode = true;
                        objEntityDocUpload.PopulateControls();

                        EntityManagerInstance.AccDocDetailUpdatedFlag = false;
                    }
                }

                if (tbEntity1.SelectedTab.Name == "tbOthers" && objEntityDocUpload.RequiredSync)
                {
                    objEntityOthers.ModifyMode = true;
                    objEntityOthers.PopulateControls();
                    objEntityDocUpload.RequiredSync = false;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(frmEntityDetail), ex.Message);
            }
        }

        /// <summary>
        /// Event to upload Individual photo
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgPhoto_DoubleClick(object sender, EventArgs e)
        {

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image files  |*.jpg;*.bmp;*.dib;*.jpg;*.jpeg ;*.jpe;*.jfif ;*.gif;*.tif;*.tiff";


            DialogResult result = openFileDialog.ShowDialog();

            if (result != DialogResult.OK)
            {
                return;
            }
            try
            {

                FileInfo fInfo = new FileInfo(openFileDialog.FileName);

                if (fInfo.Length > m_DocumentUploadMaxLimit)
                {
                    MessageBox.Show("Image can not be larger than " + m_DocumentUploadMaxLimit / 1024 + " KB.",
                     this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                EntityManagerInstance.EntityUploadedPhotoBin = File.ReadAllBytes(openFileDialog.FileName);
                EntityManagerInstance.UploadedPhotoFileName = Path.GetFileName(openFileDialog.FileName);
                EntityManagerInstance.UploadedPhotoModifedDT = fInfo.LastWriteTime;
                EntityManagerInstance.UploadedPhotoSizeByte = fInfo.Length;

                ImgPhoto.Image = FormUtil.byteArrayToImage(EntityManagerInstance.EntityUploadedPhotoBin);

                EntityManagerInstance.HasPhotoUpdated = true;

                EntityManagerInstance.UploadPhoto();

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this.GetType(), ex.Message);
                MessageBox.Show("Unable to upload image Data. Error :" + ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        /// <summary>
        /// Load Photo image form backend
        /// </summary>
        private void LoadPhotoImage()
        {
            EntityManagerInstance.HasPhotoUpdated = false;

            //if (ImgPhoto.Image == null)
            //{

                DataTable resultDataTable = new DataTable();
                CEntityMaster.GetUploadedDocumentImage(EntityManagerInstance.EntityDetails.ClientNo, 'C', ref resultDataTable);

            //byte[] imgBytes = null;
            imgBytes = null;
            try
                {
                if (resultDataTable.Rows.Count > 0)
                {
                    imgBytes = (byte[])resultDataTable.Rows[0]["b_BinaryDoc"];

                }
                }
                catch
                { }

                if (imgBytes != null)
                {
                    ImgPhoto.Image = FormUtil.byteArrayToImage(imgBytes);
                    EntityManagerInstance.HasPhotoUpdated = true;
                }
             //}

            //Load Default image
            //if (ImgPhoto.Image == null)
            //{
                //if (EntityType == CCMConstants.INDIVIDUAL)
                //    ImgPhoto.Image = Image.FromFile(@".\Images\Individual.jpg");

            //     if (EntityType == CCMConstants.NON_INDIVIDUAL)
            //        ImgPhoto.Image = Image.FromFile(@".\Images\NonIndividual.jpg");
            //}

        }

        /// <summary>
        /// Tab Selection event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbEntity1_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (OperationTagFlag == "S")
            {
                if (EntityManagerInstance.ClientNo == 0)
                    e.Cancel = true;
            }
        }

        private void frmEntityDetail_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.EntityManagerInstance.EntityDetails == null || this.EntityManagerInstance.EntityDetails.ClientNo == 0)
            {
                this.DialogResult = System.Windows.Forms.DialogResult.Abort;
                return;
            }

            if (objBank.CheckChanges() == true || objEntityOthers.CheckChanges() == true
                || objEntityAuthSign.CheckChanges() == true || objCustom.CheckChanges() == true)
            {
                if (MessageBox.Show("Some changes has not saved. Do you want continue?", this.Text,
                                               MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    e.Cancel = true;
                }
            }


        }

        private void btnAuditTrail_Click(object sender, EventArgs e)
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;

                CAudittrailPopUp objCAudit = new CAudittrailPopUp();
                objCAudit.TableDescription = tbEntity1.SelectedTab.Name.ToUpper();
                objCAudit.ClientCode = txtEntityCode.Text.Trim();

                //frmAuditTrailPopUp objfrmAuditTrail = new frmAuditTrailPopUp();
                //objfrmAuditTrail.ObjAuditpopup = objCAudit;
                //objfrmAuditTrail.EntityType = EntityType;
                //objfrmAuditTrail.Icon = this.Icon;
                //objfrmAuditTrail.ShowDialog();

                objCAudit.OperationType = "A";
                objCAudit.FromDate = null;
                objCAudit.ToDate = null;
                objCAudit.TableDescription = "vw_UCCAuditClient";
                DataSet dsAudit = new DataSet();
                objCAudit.AuditTrailOperation(ref dsAudit);

                Match.AuditTrail.Forms.frmAuditTrailNew objfrmAuditTrail = new Match.AuditTrail.Forms.frmAuditTrailNew(dsAudit);
                //objfrmAuditTrail.Height = 500;
                //objfrmAuditTrail.Width = 800;
                //objfrmAuditTrail.nTabWidth = 792;
                //objfrmAuditTrail.nTabHeight = 460;
                objfrmAuditTrail.StartPosition = FormStartPosition.CenterParent;
                if (EntityType == CCMConstants.INDIVIDUAL)
                    objfrmAuditTrail.s_CDDApp = "Yes";
                else
                    objfrmAuditTrail.s_CDDApp = "YesN";

                objfrmAuditTrail.Icon = this.Icon;
                objfrmAuditTrail.ShowDialog();

                this.Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
                this.Cursor = Cursors.Default;
            }
        }

        private string getTableNamefromSelectedTab(string tabName)
        {
            switch (tabName)
            {
                case "TBACCOUNT":
                    return "Account";

                case "TBBANK":
                    return "Bank";

                case "TBAUTHORISEDSIGNATORIES":
                    return "RelatedParty";

                case "TBOTHERS":
                    return "Other";

                case "TBDOCUPLOAD":
                    return "Documents";

                case "TBPRODUCT":
                    return "Product";
                default:
                    return null;

            }
        }


        /// <summary>
        /// Check Maker Cancel status
        /// </summary>
        /// <returns></returns>
        private bool CanEnableMakerCancel()
        {
            if (!UIConstants.IsMakerCheckerOn) return false;

            bool flag = false;

            flag = AppEnvironment.AppUser.UserNo == EntityManagerInstance.EntityDetails.MakerUserNo;

            if (!flag) return false;

            flag = !EntityManagerInstance.EntityDetails.IsAuthorized;

            if (!flag) return false;

            return flag;
        }

        /// <summary>
        /// Cancel Maker Changes 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnMakerCancel_Click(object sender, EventArgs e)
        {
            long responseCode = EntityManagerInstance.CancelMakerChanges();
            btnMakerCancel.Enabled = !(responseCode == 0);
            btnApply.Enabled = responseCode == 0;

        }



        private void AddNewtab(Form frm)
        {
            TabPage tab = new TabPage(frm.Text);
            frm.TopLevel = false;
            frm.Parent = tab;
            frm.Visible = true;
            tbEntity1.TabPages.Add(tab);
            frm.Location = new Point((tab.Width - frm.Width) / 2, (tab.Height - frm.Height) / 2);
            tbEntity1.SelectedTab = tab;
        }

        private void txtEntityCode_TextChanged(object sender, EventArgs e)
        {

        }


        private void cboGender_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (EntityManagerInstance.HasPhotoUpdated == false)
            {
                MatchCommon.CustomControls.FTComboBox cboGender = (MatchCommon.CustomControls.FTComboBox)sender;
                if (EntityType == CCMConstants.INDIVIDUAL)
                {
                    try
                    {
                        if (cboGender.SelectedIndex > 0)//0
                        {
                            string a = cboGender.SelectedValue.ToString();
                            if (cboGender.SelectedValue.ToString() == "F")//(cboGender.SelectedIndex == 2)
                            {
                                ImgPhoto.Image = Image.FromFile(@".\Images\female.jpg");
                            }
                            else if (cboGender.SelectedValue.ToString() == "M")//(cboGender.SelectedIndex == 1)
                            {
                                ImgPhoto.Image = Image.FromFile(@".\Images\male.jpg");
                            }
                            else if (cboGender.SelectedValue.ToString() == "U")//(cboGender.SelectedIndex == 1)
                            {
                                ImgPhoto.Image = Image.FromFile(@".\Images\other.jpg");
                            }
                        }
                        else if (cboGender.SelectedIndex == 0)
                        {
                            ImgPhoto.Image = null;// Image.FromFile(@".\Images\Individual.jpg");
                        }
                    }

                    catch (Exception ex)
                    {
                        Logger.Instance.WriteLog(typeof(frmEntityDetail), ex.Message);
                        this.Cursor = Cursors.Default;
                    }
                }
            }                      
        }

        //Set Default Image if user not provide 
        public void SetDefaultImg()
        {
            try
            {
                if (ImgPhoto.Image == null)
                {
                    Image img;
                    //if (EntityType == CCMConstants.INDIVIDUAL)
                    //{
                    //    ImgPhoto.Image = Image.FromFile(@".\Images\female.jpg");
                    //}
                    if (EntityType == CCMConstants.NON_INDIVIDUAL)
                    {
                        ImgPhoto.Image = Image.FromFile(@".\Images\NonIndividual.jpg");
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(frmEntityDetail), ex.Message);
                this.Cursor = Cursors.Default;
            }
        }

        private void txtBranchCode_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.F3)
                {
                    Row dr = ShowHelp(txtBranchCode.Text.Trim(), true, 6, new string[] { "BranchCode", "BranchName" });
                    if (dr != null)
                        txtBranchCode.Text = Convert.ToString(dr["BranchCode"]);
                        
                    else
                        txtBranchCode.Text = "";
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(frmEntityDetail), ex.Message);
            }

        }



        /// <summary>
        /// To Show Help
        /// </summary>
        /// <param name="key">Search Key</param>
        /// <param name="AdvanceSearch">Flag for advance Search</param>
        /// <returns></returns>
        private Row ShowHelp(string key, bool AdvanceSearch, int HelpType, string[] SearchColumnList)
        {
            string GroupCode = string.Empty;
            Row selectedRow = null;
            try
            {
                frmEntitySearch frmSearch = new frmEntitySearch();
                frmSearch.SearchKey = key;
                frmSearch.HelpType = HelpType;
                frmSearch.AllowAdvanceSearch = AdvanceSearch;
                frmSearch.Columns = SearchColumnList;
                frmSearch.DefaultSearchColumnIndex = 0;
                frmSearch.IsAddNewEnable = false;

                DialogResult resultDia = frmSearch.ShowDialog();

                if (resultDia == DialogResult.OK)
                {
                    selectedRow = frmSearch.SelectedRow;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(frmEntityDetail), ex.Message);
            }
            return selectedRow;
        }

        private void txtBranchCode_Leave(object sender, EventArgs e)
        {
            Row dr = ShowHelp(txtBranchCode.Text.Trim(), false, 6, new string[] { "BranchCode", "BranchName" });
            if (dr != null)
                txtBranchCode.Text = Convert.ToString(dr["BranchCode"]);
            else
                txtBranchCode.Text = "";
        }
    }
}

   
    
