﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.CDD.UI.UserControls;
using FTIL.Match.CDD.BAL;
using FTIL.Match.Common;
using FTIL.Match.Common.Log;


namespace FTIL.Match.CDD.UI.Forms
{
    /// <summary>
    /// Form to views Image in enlarge form
    /// </summary>
    public partial class frmImageViewer : Form
    {
   

        public frmImageViewer()
        {
            InitializeComponent();
            this.KeyPreview = true;
        }


        private void frmEntityNew_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Load Image object to Picture box control
        /// </summary>
        /// <param name="img"></param>
        public void LoadImage(Image img)
        {
            this.picDocument.Image = img;
        }

   

        /// <summary>
        /// KeyUp event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmImageViewer_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) this.Close();
        }

    }
}
