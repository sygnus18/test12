﻿using FTIL.Match.Common.Constants;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MatchCommon;

namespace FTIL.Match.CDD.UI.Forms
{
    public partial class frmFilter : Form
    {
        
        #region Variables

        #endregion

        #region Constructor
        public frmFilter()
        {
            InitializeComponent();
         
            cboEntityType.SelectedIndex= 0; 
        }
        #endregion
          
        #region frmFilter_Load
        private void frmFilter_Load(object sender, EventArgs e)
        {
        
        }

      
        #endregion
  
        #region btnClose_Click
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion
            
        #region Properties

        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string EntityType { get; set; }
        public string Code { get; set; }

        #endregion

        #region frmFilter_KeyUp
        private void frmFilter_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                this.Close();
        }
        #endregion

        private void btnGo_Click(object sender, EventArgs e)
        {

            if (cboEntityType.SelectedItem != null)
            {
                EntityType = cboEntityType.SelectedItem.ToString().ToUpper();

                switch (EntityType)
                {
                    case "ALL": EntityType = null;
                        break;
                    case "INDIVIDUAL": EntityType = "I";
                        break;
                    case "NON-INDIVIDUAL": EntityType = "NI";
                        break;
                }
            }
            else
            {
                EntityType = null;
            }


            if (dtpFromDate.Checked && dtpToDate.Checked)
            {
                if (dtpFromDate.Value.Date > dtpToDate.Value.Date)
                {
                    MessageBox.Show("From date cannot be greater than To date.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    dtpFromDate.Focus();
                    return;
                }

                FromDate = dtpFromDate.Value.Date;
                ToDate = dtpToDate.Value.Date;
            }
            else
            {
                FromDate = null;
                ToDate = null;
            }

            txtCode.Text = txtCode.Text.Trim();

            if (!string.IsNullOrEmpty(txtCode.Text))
                Code = txtCode.Text;
            else Code = null;

            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            dtpFromDate.Checked = false;
            dtpToDate.Checked = false;
            txtCode.Text = string.Empty;
            cboAuthStatus.SelectedIndex = 0;
            cboEntityType.SelectedIndex = 0;
        }

    }
}
