﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using FTIL.Match.Common;
using FTIL.Match.CDD.BAL;
using UCC.Class;

namespace FTIL.Match.CDD.UI.Forms
{


    /// <summary>
    /// Event argument for Selected Row
    /// </summary>
    public class SelectRowEventArg : EventArgs
    {
        public int RowNo { get; set; }

        public MoveDirection MoveTo { get; set; }
    }


    /// <summary>
    /// Move Direction for SelectRowEventArg
    /// </summary>
    public enum MoveDirection
    {
        Forward = 0,
        Backward = 1
    }


    /// <summary>
    /// Form operation mode
    /// </summary>
    public enum FormModeEnum
    {
        SELECT = 0,
        INSERT = 1,
        UPDATE = 2
    }


    /// <summary>
    /// Class for common UI Constants
    /// </summary>
    public class UIConstants
    {
         static UIConstants()
        {
            try
            {
                FTIL.Match.Authorization.Class.CAuthorization authorization = new FTIL.Match.Authorization.Class.CAuthorization();
                // Return if Maker/Checker is on as records will be Authorized from Authorization Screen
                IsMakerCheckerOn = authorization.IsMakerCheckerOn();
            }
            catch
            {
              IsMakerCheckerOn = true;
            }
          

        }

        /// <summary>
        /// Color for non-Mandatory controls
        /// </summary>
        public static  Color CtrlBackColor = System.Drawing.Color.White;



        /// <summary>
        /// Color for Mandatory controls
        /// </summary>
        public static Color CtrlBackColorMandatory = System.Drawing.Color.LightYellow;

        /// <summary>
        /// Flex grid Left Fix column should be show or not 
        /// </summary>
        public static int FlexGridLeftFixColumn = 0;


        /// <summary>
        /// Flag for MakerChecker On
        /// </summary>
        public static bool IsMakerCheckerOn { get;  private set; }


        /// <summary>
        /// Application Icon object: will be used in all form 
        /// </summary>
        public static Icon ApplicationIcon {get;set;}

    }


    /// <summary>
    /// Class for UI utilities
    /// </summary>
    public static class FormUtil
    {
        /// <summary>
        /// Extenstion method, Return value by checking null
        /// </summary>
        /// <param name="ddl"></param>
        /// <returns></returns>
        public static string GetSelectedValue(this MatchCommon.CustomControls.FTComboBox ddl)
        {
            if (ddl.SelectedValue == null) return null;

            return ddl.SelectedValue.ToString();
        }


        /// <summary>
        /// Extenstion method, Return value by checking null
        /// </summary>
        /// <param name="ddl"></param>
        /// <returns></returns>
        public static void SetSelectedValue(this MatchCommon.CustomControls.FTComboBox ddl, string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                ddl.SelectedIndex = -1;
                return;
            }
            try
            {
                ddl.SelectedValue = value;
               
            }
            catch
            {

            }

        }

        /// <summary>
        /// Extension method on DataTable to return DataTable with first record as blank
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static DataTable WithFirstBlank(this DataTable dt)
        {
            if (dt == null)
                return null;

            if( string.IsNullOrEmpty(dt.Rows[0][0].ToString()))
                return dt;

            DataRow dr = dt.NewRow();

            dt.Rows.InsertAt(dr, 0);

            return dt;
        }

        /// <summary>
        /// Check date is vaild or not
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static bool IsValidDate(DateTime? dt)
        {
            if (dt == null) return false;

            if (!dt.HasValue) return false;

            return !(dt == DateTime.MaxValue || dt == DateTime.MinValue);
        }


        /// <summary>
        /// Compare text values 
        /// </summary>
        /// <param name="text1">First text value</param>
        /// <param name="text2">Secord text value</param>
        /// <returns>Return true if equal</returns>
        public static bool IsEqual(string text1, string text2)
        {
            if (string.IsNullOrEmpty(text1) && string.IsNullOrEmpty(text2))
                return true;

            return text1 == text2;
        }

        /// <summary>
        /// Get Image object for byte array
        /// </summary>
        /// <param name="byteArrayIn">Source byte array</param>
        /// <returns>Image object</returns>
        public static Image byteArrayToImage(byte[] byteArrayIn)
        {
            MemoryStream ms = new MemoryStream(byteArrayIn);
            Image returnImage = Image.FromStream(ms);
            return returnImage;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public static void chkBox_Enter(object sender, EventArgs e)
        {
            CheckBox chkBox = sender as CheckBox;
            chkBox.BackColor = Color.Blue;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public static void chkBox_Leave(object sender, EventArgs e)
        {
            CheckBox chkBox = sender as CheckBox;
            chkBox.BackColor = Color.White;
        }

    }
}
