using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Collections;
using System.Windows.Forms;
using C1.Win.C1TrueDBGrid;
using UCC.Class;

/// <summary>
///======================================================================================
/// File/Class/Custom Name    : frmGridCommon.cs
/// Base CR No.               : 
/// Author                    : Naveen S
/// DateCreated               : 16-10-2014
/// Reviewd By                :
/// Description               : Common Form for grid operations
///=====================================================================================

namespace FTIL.Match.CDD.UI.Forms
{
    /// <summary>
    /// Common form for showing data in Grid format and perform operation(Update/Insert/Delete)
    /// </summary>
    public partial class frmGridCommon : MatchCommon.UI.Forms.frmMatchBase
    {

        public bool m_HasFindButtonPressed = true;


        #region Constructor
       public  frmGridCommon()
        {
            InitializeComponent();

            dgvMasterData.DoubleClick += this.modifiyToolStripMenuItem_Click;
              
            dgvMasterData.MarqueeStyle = MarqueeEnum.HighlightRow;

            dgvMasterData.FilterBarStyle.HorizontalAlignment = AlignHorzEnum.Center;


            this.KeyPreview = true;

          
     
        }
        #endregion


        #region frmGridCommon_Load
        private void frmGridCommon_Load(object sender, EventArgs e)
        {
            dgvMasterData.FilterActive = true;

            dgvMasterData.AllowUpdate = false;
            dgvMasterData.RecordSelectors = false;
        }
        #endregion

        /// <summary>
        /// Source DataTable for data grid view 
        /// </summary>
        protected DataTable SourceDataTable { get; set; }


        /// <summary>
        /// Set Windows Title name
        /// </summary>
        protected string WindowName
        {
            set
            {
                this.Text = value;
            }
        }

        /// <summary>
        /// Set Delete button text---
        /// </summary>
        protected string DeleteButtonText
        {
            get { return btnDelete.Text; }
            set
            {
                btnDelete.Text = value;
                this.deleteToolStripMenuItem.Text = value; 
            }
        }


        /// <summary>
        /// C1TrueDBGrid column collection
        /// </summary>
        protected C1DisplayColumnCollection GridColumnCollection
        {
            get { return dgvMasterData.Splits[0].DisplayColumns; }
        }



        #region RefreshData
        /// <summary>
        /// Method to bind dataset to grid
        /// </summary>
        /// <returns></returns>
        protected bool RefreshGrid()
        {
            if (SourceDataTable != null)
            {


                BindingSource bs = new BindingSource();
                bs.DataSource = SourceDataTable;
                dgvMasterData.DataSource = bs;
                

                //if (frmEntityMaster.deleteFlag >SourceDataTable.Rows.Count)
                //{
                //    MessageBox.Show(this, "record freezed succussfully!");
                //    frmEntityMaster.deleteFlag = 0;
                //}
                lblRecordCount.Text = SourceDataTable.Rows.Count.ToString();

                        dgvMasterData.Splits[0].VerticalOffset = 0;

                        dgvMasterData.Focus();
                

                //frmEntityMaster.deleteFlag = 0;



            }
            else
            {
                throw new Exception("SourceDataTable can not be null");
            }

            foreach (C1DisplayColumn col1 in dgvMasterData.Splits[0].DisplayColumns)
                col1.Visible = false;
  
            return true;
        }

        #endregion

        /// <summary>
        /// Make grid column according to their size
        /// </summary>
        protected void AutoResize()
        {
            foreach (C1DisplayColumn col1 in dgvMasterData.Splits[0].DisplayColumns)
                col1.AutoSize();
        }


        /// <summary>
        /// Get column value of a selected row
        /// </summary>
        /// <param name="column"></param>
        /// <returns></returns>
        protected string GetSelected(string column)
        {
            int iRow = dgvMasterData.Row;
            if (iRow >= 0 && iRow < dgvMasterData.Splits[0].Rows.Count)
            {
                return dgvMasterData.Splits[0].
                    DisplayColumns[column].DataColumn.CellText(iRow);
            }
            return null;
        }

        /// <summary>
        /// This Method is to highlight the select grid row
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">SelectRowEventArg</param>
        protected void OnChangeSelectedRow(object sender, SelectRowEventArg e)
        {
            dgvMasterData.MarqueeStyle = MarqueeEnum.NoMarquee;

            if (e.MoveTo == MoveDirection.Forward)
                dgvMasterData.MoveNext();

            if (e.MoveTo == MoveDirection.Backward)
                dgvMasterData.MovePrevious();

            dgvMasterData.MarqueeStyle = MarqueeEnum.HighlightRow;
        }


        protected void SetCurrentRowSelected(int RowNo)
        {
            dgvMasterData.Focus();
            dgvMasterData.Row = RowNo - 1;
        }


        #region Grid Operations

        /// <summary>
        /// Event of menu strip Add button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected virtual void addToolStripMenuItem_Click(object sender, EventArgs e) { }

        /// <summary>
        /// Event of menu strip Modify button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected virtual void modifiyToolStripMenuItem_Click(object sender, EventArgs e) { }

        /// <summary>
        /// Event of menu strip Delete button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected virtual void deleteToolStripMenuItem_Click(object sender, EventArgs e) { }


        /// <summary>
        /// Event for Access right
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected virtual void accessRightToolStripMenuItem_Click(object sender, EventArgs e) { }

        /// <summary>
        /// Event for selecting grid row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected  void OnGridRowClick_Click(object sender, EventArgs e) { }


        #endregion

        /// <summary>
        /// Event for Import data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected virtual void btnImport_Click(object sender, EventArgs e) { } 
        
        protected virtual void btnAddSubUser_Click(object sender, EventArgs e) { } 


        /// <summary>
        /// Event for Exporting data from grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected virtual void btnExport_Click(object sender, EventArgs e)
        {
            if (dgvMasterData.RowCount > 0)
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Filter = "xls files (*.xls)|*.xls";

                saveFileDialog.FileName = "CDDExport.xls";

                DialogResult result = saveFileDialog.ShowDialog();

                if (result != DialogResult.OK)
                {
                    return;
                }
                try
                {
                    dgvMasterData.ExportToExcel(saveFileDialog.FileName);
                    // m_objUserMgmt.ExportData(this.SourceDataTable, saveFileDialog.FileName, m_Dilimiter[0].ToString());
                    // MessageBox.Show("User exported on path : " + saveFileDialog.FileName, "", MessageBoxButtons.OK);
                }
                catch (Exception)
                {
                    MessageBox.Show("Unable to export Data. ", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show(this, "No records found to export");
                this.Cursor = Cursors.Default;
                return;
            }
        } 



       protected virtual void addNonIndividual_Click(object sender, EventArgs e)
        {

        }


       protected virtual void btnGo_Click(object sender, EventArgs e) { }


       private void frmGridCommon_KeyUp(object sender, KeyEventArgs e)
       {
           
           if (e.KeyCode == Keys.Enter && !m_HasFindButtonPressed)
            {
               modifiyToolStripMenuItem_Click(this, e);
            }
            m_HasFindButtonPressed = false;
            
           if (e.KeyCode == Keys.Escape)
               this.Close();
            //if (e.Alt && e.KeyCode == Keys.F)
            //{
            //    deleteToolStripMenuItem_Click(this, e);
            //}

        }


     
       
    }



    
}
