﻿namespace FTIL.Match.CDD.UI.Forms
{
    partial class frmImageViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picDocument = new MatchCommon.CustomControls.FTPictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picDocument)).BeginInit();
            this.SuspendLayout();
            // 
            // picDocument
            // 
            this.picDocument.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picDocument.Location = new System.Drawing.Point(0, 0);
            this.picDocument.Name = "picDocument";
            this.picDocument.Size = new System.Drawing.Size(968, 742);
            this.picDocument.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDocument.TabIndex = 1;
            this.picDocument.TabStop = false;
            // 
            // frmImageViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(968, 742);
            this.Controls.Add(this.picDocument);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmImageViewer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Entity";
            this.Load += new System.EventHandler(this.frmEntityNew_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmImageViewer_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.picDocument)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MatchCommon.CustomControls.FTPictureBox picDocument;


    }
}