namespace FTIL.Match.CDD.UI.Forms
{
    partial class frmAuditTrailPopUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAuditTrailPopUp));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tbUpdate = new System.Windows.Forms.TabPage();
            this.dgvUpdate = new MatchCommon.CustomControls.FTTrueDBGrid();
            this.tbDelete = new System.Windows.Forms.TabPage();
            this.dgvDelete = new MatchCommon.CustomControls.FTDataGrid();
            this.pnltab = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnExport = new MatchCommon.CustomControls.FTButton();
            this.btnView = new MatchCommon.CustomControls.FTButton();
            this.txtCode = new MatchCommon.CustomControls.FTTextBox();
            this.lblClientCode = new System.Windows.Forms.Label();
            this.cboTableName = new MatchCommon.CustomControls.FTComboBox();
            this.tabControl1.SuspendLayout();
            this.tbUpdate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUpdate)).BeginInit();
            this.tbDelete.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDelete)).BeginInit();
            this.pnltab.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tbUpdate);
            this.tabControl1.Controls.Add(this.tbDelete);
            this.tabControl1.Location = new System.Drawing.Point(3, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(968, 418);
            this.tabControl1.TabIndex = 56;
            // 
            // tbUpdate
            // 
            this.tbUpdate.Controls.Add(this.dgvUpdate);
            this.tbUpdate.Location = new System.Drawing.Point(4, 22);
            this.tbUpdate.Name = "tbUpdate";
            this.tbUpdate.Padding = new System.Windows.Forms.Padding(3);
            this.tbUpdate.Size = new System.Drawing.Size(960, 392);
            this.tbUpdate.TabIndex = 1;
            this.tbUpdate.Text = "Updated";
            this.tbUpdate.UseVisualStyleBackColor = true;
            // 
            // dgvUpdate
            // 
            this.dgvUpdate.AlternatingRows = true;
            this.dgvUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(234)))), ((int)(((byte)(234)))));
            this.dgvUpdate.FilterBar = true;
            this.dgvUpdate.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dgvUpdate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.dgvUpdate.Location = new System.Drawing.Point(3, 3);
            this.dgvUpdate.MarqueeStyle = C1.Win.C1TrueDBGrid.MarqueeEnum.HighlightRow;
            this.dgvUpdate.Name = "dgvUpdate";
            this.dgvUpdate.PreviewInfo.Location = new System.Drawing.Point(0, 0);
            this.dgvUpdate.PreviewInfo.Size = new System.Drawing.Size(0, 0);
            this.dgvUpdate.PreviewInfo.ZoomFactor = 75D;
            this.dgvUpdate.PrintInfo.PageSettings = ((System.Drawing.Printing.PageSettings)(resources.GetObject("dgvUpdate.PrintInfo.PageSettings")));
            this.dgvUpdate.RowHeight = 20;
            this.dgvUpdate.Size = new System.Drawing.Size(960, 385);
            this.dgvUpdate.TabIndex = 1;
            // 
            // tbDelete
            // 
            this.tbDelete.Controls.Add(this.dgvDelete);
            this.tbDelete.Location = new System.Drawing.Point(4, 22);
            this.tbDelete.Name = "tbDelete";
            this.tbDelete.Size = new System.Drawing.Size(960, 392);
            this.tbDelete.TabIndex = 2;
            this.tbDelete.Text = "Deleted";
            this.tbDelete.UseVisualStyleBackColor = true;
            // 
            // dgvDelete
            // 
            this.dgvDelete.AllowEditing = false;
            this.dgvDelete.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
            this.dgvDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(234)))), ((int)(((byte)(234)))));
            this.dgvDelete.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.dgvDelete.ColumnInfo = "5,1,0,0,0,95,Columns:0{Width:30;}\t";
            this.dgvDelete.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
            this.dgvDelete.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dgvDelete.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.dgvDelete.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
            this.dgvDelete.Location = new System.Drawing.Point(3, 3);
            this.dgvDelete.Name = "dgvDelete";
            this.dgvDelete.OverrideDefault = false;
            this.dgvDelete.Rows.Count = 10;
            this.dgvDelete.Rows.DefaultSize = 19;
            this.dgvDelete.Rows.MinSize = 25;
            this.dgvDelete.RowsFilter.AddFilterRow = false;
            this.dgvDelete.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.ListBox;
            this.dgvDelete.Size = new System.Drawing.Size(960, 385);
            this.dgvDelete.StyleInfo = "";
            this.dgvDelete.TabIndex = 2;
            // 
            // pnltab
            // 
            this.pnltab.Controls.Add(this.tabControl1);
            this.pnltab.Location = new System.Drawing.Point(3, 50);
            this.pnltab.Name = "pnltab";
            this.pnltab.Size = new System.Drawing.Size(975, 422);
            this.pnltab.TabIndex = 74;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnExport);
            this.panel2.Controls.Add(this.btnView);
            this.panel2.Controls.Add(this.txtCode);
            this.panel2.Controls.Add(this.lblClientCode);
            this.panel2.Controls.Add(this.cboTableName);
            this.panel2.Location = new System.Drawing.Point(3, 1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(975, 43);
            this.panel2.TabIndex = 54;
            // 
            // btnExport
            // 
            this.btnExport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExport.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnExport.Image = ((System.Drawing.Image)(resources.GetObject("btnExport.Image")));
            this.btnExport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExport.Location = new System.Drawing.Point(549, 10);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(84, 25);
            this.btnExport.TabIndex = 93;
            this.btnExport.Text = "&Export      ";
            this.btnExport.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // btnView
            // 
            this.btnView.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnView.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnView.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnView.Image = ((System.Drawing.Image)(resources.GetObject("btnView.Image")));
            this.btnView.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnView.Location = new System.Drawing.Point(445, 9);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(84, 25);
            this.btnView.TabIndex = 92;
            this.btnView.Text = "&Retrieve";
            this.btnView.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnView.UseVisualStyleBackColor = true;
            // 
            // txtCode
            // 
            this.txtCode.AllowAlpha = true;
            this.txtCode.AllowDot = false;
            this.txtCode.AllowedCustomCharacters = null;
            this.txtCode.AllowNonASCII = false;
            this.txtCode.AllowNumeric = true;
            this.txtCode.AllowSpace = false;
            this.txtCode.AllowSpecialChars = false;
            this.txtCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCode.FocusColor = System.Drawing.Color.LightYellow;
            this.txtCode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtCode.ForeColor = System.Drawing.Color.Black;
            this.txtCode.IsEmailID = false;
            this.txtCode.IsEmailIdValid = false;
            this.txtCode.Location = new System.Drawing.Point(214, 12);
            this.txtCode.MaxLength = 20;
            this.txtCode.Name = "txtCode";
            this.txtCode.Size = new System.Drawing.Size(209, 20);
            this.txtCode.TabIndex = 90;
            this.txtCode.Tag = "Code";
            // 
            // lblClientCode
            // 
            this.lblClientCode.AutoSize = true;
            this.lblClientCode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblClientCode.Location = new System.Drawing.Point(144, 17);
            this.lblClientCode.Name = "lblClientCode";
            this.lblClientCode.Size = new System.Drawing.Size(57, 12);
            this.lblClientCode.TabIndex = 91;
            this.lblClientCode.Text = "Cilent Code";
            // 
            // cboTableName
            // 
            this.cboTableName.BackColor = System.Drawing.Color.White;
            this.cboTableName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTableName.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboTableName.ForeColor = System.Drawing.Color.Black;
            this.cboTableName.FormattingEnabled = true;
            this.cboTableName.Location = new System.Drawing.Point(6, 11);
            this.cboTableName.Name = "cboTableName";
            this.cboTableName.ReadOnly = false;
            this.cboTableName.Size = new System.Drawing.Size(129, 21);
            this.cboTableName.TabIndex = 88;
            // 
            // frmAuditTrailPopUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(980, 476);
            this.Controls.Add(this.pnltab);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmAuditTrailPopUp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Audit Trail";
            this.Load += new System.EventHandler(this.frmAuditTrail_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmAuditTrail_KeyUp);
            this.tabControl1.ResumeLayout(false);
            this.tbUpdate.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUpdate)).EndInit();
            this.tbDelete.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDelete)).EndInit();
            this.pnltab.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tbUpdate;
        private MatchCommon.CustomControls.FTTrueDBGrid dgvUpdate;
        private System.Windows.Forms.TabPage tbDelete;
        private MatchCommon.CustomControls.FTDataGrid dgvDelete;
        private System.Windows.Forms.Panel pnltab;
        private System.Windows.Forms.Panel panel2;
        protected MatchCommon.CustomControls.FTTextBox txtCode;
        private System.Windows.Forms.Label lblClientCode;
        private MatchCommon.CustomControls.FTComboBox cboTableName;
        protected MatchCommon.CustomControls.FTButton btnView;
        protected MatchCommon.CustomControls.FTButton btnExport;
    }
}