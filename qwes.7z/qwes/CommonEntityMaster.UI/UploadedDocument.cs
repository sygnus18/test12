﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace FTIL.Match.CDD.UI
{
    class UploadedDocument
    {
        public UploadedDocument()
        {

        }

        public Image ImageFile { get; set; }

        public string FileName { get; set; }

        public long SizeBytes { get; set; }

        public DateTime? ModifiedTime { get; set; }

    }
}
