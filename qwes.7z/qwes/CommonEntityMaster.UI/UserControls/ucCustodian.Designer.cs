﻿namespace FTIL.Match.CDD.UI.UserControls
{
    partial class ucCustodian
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvCustodian = new MatchCommon.CustomControls.FTDataGrid();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustodian)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvCustodian
            // 
            this.dgvCustodian.AllowEditing = false;
            this.dgvCustodian.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
            this.dgvCustodian.BackColor = System.Drawing.Color.White;
            this.dgvCustodian.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.dgvCustodian.ColumnInfo = "5,1,0,0,0,95,Columns:0{Width:30;}\t";
            this.dgvCustodian.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
            this.dgvCustodian.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dgvCustodian.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.dgvCustodian.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
            this.dgvCustodian.Location = new System.Drawing.Point(0, 2);
            this.dgvCustodian.Name = "dgvCustodian";
            this.dgvCustodian.Styles.EmptyArea.BackColor = System.Drawing.Color.White;
            this.dgvCustodian.OverrideDefault = false;
            this.dgvCustodian.Rows.Count = 10;
            this.dgvCustodian.Rows.DefaultSize = 19;
            this.dgvCustodian.Rows.MinSize = 25;
            this.dgvCustodian.RowsFilter.AddFilterRow = false;
            this.dgvCustodian.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Cell;
            this.dgvCustodian.Size = new System.Drawing.Size(770, 331);
            this.dgvCustodian.StyleInfo = "";
            this.dgvCustodian.TabIndex = 0;
            this.dgvCustodian.Text = "dgvCustodian";
            this.dgvCustodian.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.dgvCustodian_AfterEdit);
            this.dgvCustodian.KeyDownEdit += new C1.Win.C1FlexGrid.KeyEditEventHandler(this.dgvCustodian_KeyDownEdit);
            this.dgvCustodian.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.dgvCustodian_KeyPressEdit);
            // 
            // ucCustodian
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.dgvCustodian);
            this.Name = "ucCustodian";
            this.Size = new System.Drawing.Size(773, 508);
            this.Load += new System.EventHandler(this.ucCustodian_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustodian)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private MatchCommon.CustomControls.FTDataGrid dgvCustodian;
    }
}
