﻿namespace FTIL.Match.CDD.UI.UserControls
{
    partial class ucGuardian
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucGuardian));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnDelete = new MatchCommon.CustomControls.FTButton();
            this.ftLabel1 = new MatchCommon.CustomControls.FTLabel();
            this.txtGuardianName = new MatchCommon.CustomControls.FTTextBox();
            this.cboNationality = new MatchCommon.CustomControls.FTComboBox();
            this.txtNationalityName = new MatchCommon.CustomControls.FTTextBox();
            this.ftLblNationality = new MatchCommon.CustomControls.FTLabel();
            this.dtDOB = new System.Windows.Forms.DateTimePicker();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.pnlParmanentAdd = new System.Windows.Forms.Panel();
            this.ftLabel13 = new MatchCommon.CustomControls.FTLabel();
            this.chkSameAsCorrs = new MatchCommon.CustomControls.FTCheckBox();
            this.ftlblGender = new MatchCommon.CustomControls.FTLabel();
            this.ftlblDOB = new MatchCommon.CustomControls.FTLabel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.pnlCorrespondenceAdd = new System.Windows.Forms.Panel();
            this.cboGender = new MatchCommon.CustomControls.FTComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ftLabel34 = new MatchCommon.CustomControls.FTLabel();
            this.txtFather_SpouseName = new MatchCommon.CustomControls.FTTextBox();
            this.panel1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnDelete);
            this.panel1.Controls.Add(this.ftLabel1);
            this.panel1.Controls.Add(this.txtGuardianName);
            this.panel1.Controls.Add(this.cboNationality);
            this.panel1.Controls.Add(this.txtNationalityName);
            this.panel1.Controls.Add(this.ftLblNationality);
            this.panel1.Controls.Add(this.dtDOB);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.ftlblGender);
            this.panel1.Controls.Add(this.ftlblDOB);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.cboGender);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.panel1.Size = new System.Drawing.Size(768, 513);
            this.panel1.TabIndex = 1;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Transparent;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.Location = new System.Drawing.Point(690, 480);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 25);
            this.btnDelete.TabIndex = 105;
            this.btnDelete.Text = "&Remove";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // ftLabel1
            // 
            this.ftLabel1.AllowForeColorChange = false;
            this.ftLabel1.AutoSize = true;
            this.ftLabel1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel1.ForeColor = System.Drawing.Color.Black;
            this.ftLabel1.Location = new System.Drawing.Point(4, 6);
            this.ftLabel1.Name = "ftLabel1";
            this.ftLabel1.OverrideDefault = false;
            this.ftLabel1.Size = new System.Drawing.Size(34, 13);
            this.ftLabel1.TabIndex = 104;
            this.ftLabel1.Text = "Name";
            // 
            // txtGuardianName
            // 
            this.txtGuardianName.AllowAlpha = true;
            this.txtGuardianName.AllowDot = false;
            this.txtGuardianName.AllowedCustomCharacters = null;
            this.txtGuardianName.AllowNonASCII = false;
            this.txtGuardianName.AllowNumeric = true;
            this.txtGuardianName.AllowSpace = true;
            this.txtGuardianName.AllowSpecialChars = true;
            this.txtGuardianName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtGuardianName.FocusColor = System.Drawing.Color.LightYellow;
            this.txtGuardianName.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtGuardianName.ForeColor = System.Drawing.Color.Black;
            this.txtGuardianName.IsEmailID = false;
            this.txtGuardianName.IsEmailIdValid = false;
            this.txtGuardianName.Location = new System.Drawing.Point(65, 3);
            this.txtGuardianName.MaxLength = 200;
            this.txtGuardianName.Name = "txtGuardianName";
            this.txtGuardianName.Size = new System.Drawing.Size(693, 20);
            this.txtGuardianName.TabIndex = 91;
            this.txtGuardianName.Tag = "Code";
            // 
            // cboNationality
            // 
            this.cboNationality.BackColor = System.Drawing.Color.White;
            this.cboNationality.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNationality.DropDownWidth = 90;
            this.cboNationality.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboNationality.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboNationality.ForeColor = System.Drawing.Color.Black;
            this.cboNationality.FormattingEnabled = true;
            this.cboNationality.Location = new System.Drawing.Point(422, 28);
            this.cboNationality.Name = "cboNationality";
            this.cboNationality.ReadOnly = false;
            this.cboNationality.Size = new System.Drawing.Size(129, 21);
            this.cboNationality.TabIndex = 95;
            this.cboNationality.SelectedIndexChanged += new System.EventHandler(this.cboNationality_SelectedIndexChanged);
            // 
            // txtNationalityName
            // 
            this.txtNationalityName.AllowAlpha = true;
            this.txtNationalityName.AllowDot = true;
            this.txtNationalityName.AllowedCustomCharacters = null;
            this.txtNationalityName.AllowNonASCII = false;
            this.txtNationalityName.AllowNumeric = true;
            this.txtNationalityName.AllowSpace = true;
            this.txtNationalityName.AllowSpecialChars = true;
            this.txtNationalityName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNationalityName.FocusColor = System.Drawing.Color.LightYellow;
            this.txtNationalityName.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtNationalityName.ForeColor = System.Drawing.Color.Black;
            this.txtNationalityName.IsEmailID = false;
            this.txtNationalityName.IsEmailIdValid = false;
            this.txtNationalityName.Location = new System.Drawing.Point(558, 29);
            this.txtNationalityName.MaxLength = 50;
            this.txtNationalityName.Name = "txtNationalityName";
            this.txtNationalityName.Size = new System.Drawing.Size(200, 20);
            this.txtNationalityName.TabIndex = 96;
            this.txtNationalityName.Tag = "Code";
            // 
            // ftLblNationality
            // 
            this.ftLblNationality.AllowForeColorChange = false;
            this.ftLblNationality.AutoSize = true;
            this.ftLblNationality.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLblNationality.ForeColor = System.Drawing.Color.Black;
            this.ftLblNationality.Location = new System.Drawing.Point(364, 32);
            this.ftLblNationality.Name = "ftLblNationality";
            this.ftLblNationality.OverrideDefault = false;
            this.ftLblNationality.Size = new System.Drawing.Size(58, 13);
            this.ftLblNationality.TabIndex = 103;
            this.ftLblNationality.Text = "Nationality";
            // 
            // dtDOB
            // 
            this.dtDOB.CustomFormat = "dd/MM/yyyy";
            this.dtDOB.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtDOB.Location = new System.Drawing.Point(65, 27);
            this.dtDOB.Name = "dtDOB";
            this.dtDOB.Size = new System.Drawing.Size(92, 20);
            this.dtDOB.TabIndex = 92;
            this.dtDOB.Value = new System.DateTime(2015, 2, 25, 12, 2, 20, 0);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.pnlParmanentAdd);
            this.groupBox3.Controls.Add(this.ftLabel13);
            this.groupBox3.Controls.Add(this.chkSameAsCorrs);
            this.groupBox3.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox3.Location = new System.Drawing.Point(5, 304);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(760, 172);
            this.groupBox3.TabIndex = 100;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Permanent Address";
            // 
            // pnlParmanentAdd
            // 
            this.pnlParmanentAdd.Location = new System.Drawing.Point(3, 20);
            this.pnlParmanentAdd.Name = "pnlParmanentAdd";
            this.pnlParmanentAdd.Size = new System.Drawing.Size(753, 150);
            this.pnlParmanentAdd.TabIndex = 48;
            // 
            // ftLabel13
            // 
            this.ftLabel13.AllowForeColorChange = false;
            this.ftLabel13.AutoSize = true;
            this.ftLabel13.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel13.ForeColor = System.Drawing.Color.Black;
            this.ftLabel13.Location = new System.Drawing.Point(223, 0);
            this.ftLabel13.Name = "ftLabel13";
            this.ftLabel13.OverrideDefault = false;
            this.ftLabel13.Size = new System.Drawing.Size(80, 13);
            this.ftLabel13.TabIndex = 47;
            this.ftLabel13.Text = "Same as above";
            // 
            // chkSameAsCorrs
            // 
            this.chkSameAsCorrs.AutoSize = true;
            this.chkSameAsCorrs.Font = new System.Drawing.Font("Tahoma", 8F);
            this.chkSameAsCorrs.ForeColor = System.Drawing.Color.Black;
            this.chkSameAsCorrs.Location = new System.Drawing.Point(206, 0);
            this.chkSameAsCorrs.Name = "chkSameAsCorrs";
            this.chkSameAsCorrs.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.chkSameAsCorrs.Size = new System.Drawing.Size(15, 14);
            this.chkSameAsCorrs.TabIndex = 41;
            this.chkSameAsCorrs.UseVisualStyleBackColor = true;
            this.chkSameAsCorrs.CheckedChanged += new System.EventHandler(this.chkSameAsCorrs_CheckedChanged);
            // 
            // ftlblGender
            // 
            this.ftlblGender.AllowForeColorChange = false;
            this.ftlblGender.AutoSize = true;
            this.ftlblGender.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftlblGender.ForeColor = System.Drawing.Color.Black;
            this.ftlblGender.Location = new System.Drawing.Point(187, 31);
            this.ftlblGender.Name = "ftlblGender";
            this.ftlblGender.OverrideDefault = false;
            this.ftlblGender.Size = new System.Drawing.Size(42, 13);
            this.ftlblGender.TabIndex = 97;
            this.ftlblGender.Text = "Gender";
            // 
            // ftlblDOB
            // 
            this.ftlblDOB.AllowForeColorChange = false;
            this.ftlblDOB.AutoSize = true;
            this.ftlblDOB.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftlblDOB.ForeColor = System.Drawing.Color.Black;
            this.ftlblDOB.Location = new System.Drawing.Point(4, 32);
            this.ftlblDOB.Name = "ftlblDOB";
            this.ftlblDOB.OverrideDefault = false;
            this.ftlblDOB.Size = new System.Drawing.Size(28, 13);
            this.ftlblDOB.TabIndex = 96;
            this.ftlblDOB.Text = "DOB";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.pnlCorrespondenceAdd);
            this.groupBox2.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox2.Location = new System.Drawing.Point(5, 115);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(760, 172);
            this.groupBox2.TabIndex = 98;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Correspondence Address";
            // 
            // pnlCorrespondenceAdd
            // 
            this.pnlCorrespondenceAdd.Location = new System.Drawing.Point(3, 19);
            this.pnlCorrespondenceAdd.Name = "pnlCorrespondenceAdd";
            this.pnlCorrespondenceAdd.Size = new System.Drawing.Size(753, 150);
            this.pnlCorrespondenceAdd.TabIndex = 0;
            // 
            // cboGender
            // 
            this.cboGender.BackColor = System.Drawing.Color.White;
            this.cboGender.DisplayMember = "1,2";
            this.cboGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboGender.DropDownWidth = 90;
            this.cboGender.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboGender.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboGender.ForeColor = System.Drawing.Color.Black;
            this.cboGender.FormattingEnabled = true;
            this.cboGender.Location = new System.Drawing.Point(239, 27);
            this.cboGender.Name = "cboGender";
            this.cboGender.ReadOnly = false;
            this.cboGender.Size = new System.Drawing.Size(93, 21);
            this.cboGender.TabIndex = 93;
            this.cboGender.ValueMember = "M,F";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ftLabel34);
            this.groupBox1.Controls.Add(this.txtFather_SpouseName);
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox1.Location = new System.Drawing.Point(5, 55);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(760, 46);
            this.groupBox1.TabIndex = 97;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Father/Mother/Spouse";
            // 
            // ftLabel34
            // 
            this.ftLabel34.AllowForeColorChange = false;
            this.ftLabel34.AutoSize = true;
            this.ftLabel34.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel34.ForeColor = System.Drawing.Color.Black;
            this.ftLabel34.Location = new System.Drawing.Point(7, 21);
            this.ftLabel34.Name = "ftLabel34";
            this.ftLabel34.OverrideDefault = false;
            this.ftLabel34.Size = new System.Drawing.Size(34, 13);
            this.ftLabel34.TabIndex = 24;
            this.ftLabel34.Text = "Name";
            // 
            // txtFather_SpouseName
            // 
            this.txtFather_SpouseName.AllowAlpha = true;
            this.txtFather_SpouseName.AllowDot = false;
            this.txtFather_SpouseName.AllowedCustomCharacters = null;
            this.txtFather_SpouseName.AllowNonASCII = false;
            this.txtFather_SpouseName.AllowNumeric = true;
            this.txtFather_SpouseName.AllowSpace = true;
            this.txtFather_SpouseName.AllowSpecialChars = true;
            this.txtFather_SpouseName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtFather_SpouseName.FocusColor = System.Drawing.Color.LightYellow;
            this.txtFather_SpouseName.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtFather_SpouseName.ForeColor = System.Drawing.Color.Black;
            this.txtFather_SpouseName.IsEmailID = false;
            this.txtFather_SpouseName.IsEmailIdValid = false;
            this.txtFather_SpouseName.Location = new System.Drawing.Point(60, 17);
            this.txtFather_SpouseName.MaxLength = 200;
            this.txtFather_SpouseName.Name = "txtFather_SpouseName";
            this.txtFather_SpouseName.Size = new System.Drawing.Size(693, 20);
            this.txtFather_SpouseName.TabIndex = 97;
            this.txtFather_SpouseName.Tag = "Code";
            // 
            // ucGuardian
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.panel1);
            this.Name = "ucGuardian";
            this.Size = new System.Drawing.Size(768, 513);
            this.Load += new System.EventHandler(this.ucGuardian_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private MatchCommon.CustomControls.FTComboBox cboNationality;
        private MatchCommon.CustomControls.FTTextBox txtNationalityName;
        private MatchCommon.CustomControls.FTLabel ftLblNationality;
        private System.Windows.Forms.DateTimePicker dtDOB;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Panel pnlParmanentAdd;
        private MatchCommon.CustomControls.FTLabel ftLabel13;
        private MatchCommon.CustomControls.FTCheckBox chkSameAsCorrs;
        private MatchCommon.CustomControls.FTLabel ftlblGender;
        private MatchCommon.CustomControls.FTLabel ftlblDOB;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Panel pnlCorrespondenceAdd;
        private MatchCommon.CustomControls.FTComboBox cboGender;
        private System.Windows.Forms.GroupBox groupBox1;
        private MatchCommon.CustomControls.FTLabel ftLabel34;
        private MatchCommon.CustomControls.FTTextBox txtFather_SpouseName;
        private MatchCommon.CustomControls.FTLabel ftLabel1;
        private MatchCommon.CustomControls.FTTextBox txtGuardianName;
        private MatchCommon.CustomControls.FTButton btnDelete;
    }
}
