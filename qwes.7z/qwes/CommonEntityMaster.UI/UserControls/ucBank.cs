﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using UCC.Class;
using FTIL.Match.CDD.BAL;
using FTIL.Match.CDD.UI.Forms;
using FTIL.Match.CDD.BAL.DataClasses;
using C1.Win.C1FlexGrid;
using FTIL.Match.Common.Log;
using FTIL.Match.Common;

namespace FTIL.Match.CDD.UI.UserControls
{
    /// <summary>
    /// user cntrol for accessing and modifying bank details tab
    /// </summary>
    public partial class ucBank : FTIL.Match.CDD.UI.UserControls.ucBaseEntity
    {
        private int ColIndex { get; set; }
        private int RowIndex { get; set; }
        public int ClientId { get; set; }
        private int iCount { get; set; }
        private BankDtls objBankDtl;
        DataTable dtBankMaster = null;
        //public string sName { get; set; }

        public ucBank()
        {
            InitializeComponent();
            objBankDtl = new BankDtls();

            this.dgBankData.Cols.Fixed = UIConstants.FlexGridLeftFixColumn;
        }

        private void ucBank_Load(object sender, EventArgs e)
        {
            txtNameOnCheck.Text = sName;
            PopulateLookup();
        }
        /// <summary>
        /// base intity method for intity details 
        /// </summary>
        /// <returns></returns>
        public override EntityDetails GetEntityDetails()
        {
            if (m_EntityDetailsInstance == null) return m_EntityDetailsInstance;
            HasUpdated = true;
            return m_EntityDetailsInstance;
        }
        /// <summary>
        /// call from frmEntity details return bank tab data for submit bank details. 
        /// </summary>
        public BankDtls EntityBankDetails
        {
            get { return objBankDtl; }
        }

        /// <summary>
        /// call from frmEntity details fill bank tab data on load and reload. 
        /// </summary>
        public override void PopulateControls()
        {
            if (ModifyMode == false) return;
            try
            {
                ResetCtrl();
                
                DataTable dtResult = null;
               
                //CEntityMaster.GetEntityBankDetails(m_EntityDetailsInstance.ClientNo, ref dtResult);
                CEntityMaster.GetEntityBankDetails(ClientId, ref dtResult, AppEnvironment.AppUser.UserNo, ref dtBankMaster);
                PopulateLookup();

                objBankDtl.dtBankResult = dtResult;
                GridBind(dtResult);
                DataRow[] dr = dtResult.Select("d_LastModifiedDateTime=Max(d_LastModifiedDateTime)");

                if (dtResult.Rows.Count > 0)
                    if (dr.Length > 0)
                        objBankDtl.dLastUpdatedDate = Convert.ToDateTime(dr[0]["d_LastModifiedDateTime"]);
                

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucBank), ex.Message);
                MessageBox.Show(ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// call from frmEntity details fill combo of bank tab data on load and reload. 
        /// </summary>
        protected override void PopulateLookup()
        {
            if (m_HasAllDropDownListBind) return;
            try
            {
                cboAccountOf.ValueMember = "s_ReferenceCode";
                cboAccountOf.DisplayMember = "s_ReferenceName";
                cboAccountOf.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.BANKACCTYP];

                cboBankCode.ValueMember = "BankCode";
                cboBankCode.DisplayMember = "BankCode";
                cboBankCode.DataSource = dtBankMaster;

                txtAccount.BackColor = UIConstants.CtrlBackColorMandatory;
                txtBankCode.BackColor = ctrlBackColor;
                txtBankName.BackColor = UIConstants.CtrlBackColorMandatory;
                txtBranch.BackColor = ctrlBackColor;
                txtCustId.BackColor = ctrlBackColor;
                txtIFCSCode.BackColor = ctrlBackColor;
                txtMICR.BackColor = ctrlBackColor;
                cboAccountOf.BackColor = UIConstants.CtrlBackColorMandatory;

                                      
                if (ModifyMode == false)
                {
                    DataTable dtResult = new DataTable();

                    CEntityMaster.GetEntityBankDetails(ClientId, ref dtResult, AppEnvironment.AppUser.UserNo,  ref dtBankMaster);
                    objBankDtl.dtBankResult = dtResult;
                    GridBind(objBankDtl.dtBankResult);

                    cboBankCode.ValueMember = "BankCode";
                    cboBankCode.DisplayMember = "BankName";
                    cboBankCode.DataSource = dtBankMaster;

                    return;
                }

                cboAccountOf.SelectedValue = 0;

             }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucBank), ex.Message);
                MessageBox.Show("Unable to populate bank details", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            m_HasAllDropDownListBind = true;
        }

        /// <summary>
        /// call from click on add and modify button to refresh grid data. 
        /// </summary>
        /// 
        private void SyncDataTable()
        {
            RowIndex = 0;
            try
            {
                if (isAddValid())
                {
                    
                    objBankDtl.AccountType = cboAccountOf.Text;
                    objBankDtl.AccountTypeVal = Convert.ToInt32(cboAccountOf.GetSelectedValue());
                    objBankDtl.AccountNo = txtAccount.Text.Trim();
                    //objBankDtl.BankCode = txtBankCode.Text;
                    objBankDtl.BankCode = cboBankCode.GetSelectedValue();
                    objBankDtl.BankName = txtBankName.Text;
                    objBankDtl.MICR = txtMICR.Text;
                    objBankDtl.Branch = txtBranch.Text;
                    objBankDtl.CustNo = txtCustId.Text;
                    objBankDtl.IFSCCode = txtIFCSCode.Text;
                    objBankDtl.NameOnCheque = txtNameOnCheck.Text;
                    objBankDtl.sDefault = chkDefault.Checked == true ? "Y" : "N";
                    if (btnAdd.Text == "Add")
                    {
                        DataRow[] dr = objBankDtl.dtBankResult.Select("s_AccountNo = '" + objBankDtl.AccountNo + "'");
                        if (dr.Length > 0)
                        {
                            MessageBox.Show( "Account# " + objBankDtl.AccountNo +  " already exist", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            return;
                        }

                        objBankDtl.ClientBankNo = 0;
                        objBankDtl.FlagAccountNo = objBankDtl.AccountNo;
                    }
                    //if (objBankDtl.FlagAccountNo == "" || objBankDtl.FlagAccountNo ==null )
                    //    objBankDtl.FlagAccountNo = objBankDtl.AccountNo;
                    objBankDtl.SetDataResult();
                    GridBind(objBankDtl.dtBankResult);

                    cboBankCode.Enabled = true;
                    btnAdd.Text = "Add";
                    ResetCtrl();
                    txtNameOnCheck.Text = sName;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucBank), ex.Message);
                MessageBox.Show("Unable to sync bank details grid", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Grid bind method call on every refresh event for grid 
        /// </summary>
        private void GridBind(DataTable dt)
        {
            try
            {
                dgBankData.DataSource = dt;


                foreach (Column col1 in dgBankData.Cols)
                    col1.Visible = false;


                dgBankData.Cols["s_BankCode"].Visible = true;
                dgBankData.Cols["s_BankName"].Visible = true;
                dgBankData.Cols["s_MICRCode"].Visible = true;
                dgBankData.Cols["s_Branch"].Visible = true;
                dgBankData.Cols["s_AccountType"].Visible = true;
                dgBankData.Cols["s_AccountNo"].Visible = true;
                dgBankData.Cols["s_CustomerID"].Visible = true;
                dgBankData.Cols["s_IFSCCode"].Visible = true;
                dgBankData.Cols["s_NameOnCheque"].Visible = true;
                dgBankData.Cols["s_Default"].Visible = true;


 
                dgBankData.Cols["s_BankCode"].Caption = "Bank Code";
                dgBankData.Cols["s_BankName"].Caption = "Bank Name";
                dgBankData.Cols["s_MICRCode"].Caption = "MICR";
                dgBankData.Cols["s_Branch"].Caption = "Branch";
                dgBankData.Cols["s_AccountType"].Caption = "Account";
                dgBankData.Cols["s_AccountNo"].Caption = "Account#";
                dgBankData.Cols["s_CustomerID"].Caption = "Cus ID";
                dgBankData.Cols["s_IFSCCode"].Caption = "IFSC Code";
                dgBankData.Cols["s_NameOnCheque"].Caption = "Name On Cheque";
                dgBankData.Cols["s_Default"].Caption = "Default";

                dgBankData.Cols["s_AccountType"].DataMap = CReferenceDataProvider.Instance.GetHashTable(CReferenceDataProvider.ReferenceType.BANKACCTYP,
                    CReferenceDataProvider.ReferenceFields.ReferenceName, CReferenceDataProvider.ReferenceFields.ReferenceCode);

                if (objBankDtl.dtBankResult.Rows.Count == 0) objBankDtl.isValid = false;
                else objBankDtl.isValid = true;

                DataRow[] dr = objBankDtl.dtBankResult.Select("s_Default = 'Y'");
                if (dr.Length >= 1)
                    chkDefault.Enabled = false;
                else
                    chkDefault.Enabled = true;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucBank), ex.Message);
                MessageBox.Show("Unable to fetch data for bind bank grid", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Validation method validate add record and modify record. 
        /// </summary>
        private bool isAddValid()
        {
            string Msg = "";
            string FieldMsg = "";
            try
            {
                  iCount = 0;
                  objBankDtl.isValid = true;
                  FieldMsg += ValidateField(cboAccountOf.SelectedIndex.ToString(), "-1", " Account,", ref Msg);
                  if(cboBankCode.SelectedValue==null)
                      FieldMsg += ValidateField("", "", " BankCode,", ref Msg);
                  else
                      FieldMsg += ValidateField(cboBankCode.SelectedValue.ToString(), "", " BankCode,", ref Msg);
                //FieldMsg += ValidateField(txtBankCode.Text, "", " BankCode,", ref Msg);
               // FieldMsg += ValidateField(txtBankName.Text, "", " Bank Name,", ref Msg);
               // FieldMsg += ValidateField(txtBranch.Text, "", " Branch,", ref Msg);
               // FieldMsg += ValidateField(txtIFCSCode.Text, "", " IFCS Code,", ref Msg);
               // FieldMsg += ValidateField(txtMICR.Text, "", " MICR,", ref Msg);
               // FieldMsg += ValidateField(txtCustId.Text, "", " Cust Id,", ref Msg);

                FieldMsg += ValidateField(txtAccount.Text, "", " Account#,", ref Msg);

                if (FieldMsg != "")
                {
                    FieldMsg = FieldMsg.Remove(FieldMsg.Length - 1);
                    objBankDtl.isValid = false;
                    MessageBox.Show(FieldMsg + Msg, sClientHeaderName, MessageBoxButtons.OK);

                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucBank), ex.Message);
                MessageBox.Show(ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return FieldMsg == "";
        }

        /// <summary>
        ///
        /// </summary>
        public string ValidateField(string FieldVal, string InvalidCiteria, string FieldName, ref string sMsg)
        {
            bool IsVaild;
            string RetVal;
            RetVal = "";
            IsVaild = FieldVal != InvalidCiteria;
            if (!IsVaild)
            {
                iCount += 1;
                RetVal = FieldName;
                if (iCount == 1) sMsg = " is mandatory.";
                else sMsg = " are mandatory.";
            }

            return RetVal;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            SyncDataTable();
        }

        /// <summary>
        /// Grid selection changed event. 
        /// </summary>
        private void dgBankData_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (dgBankData.Rows.Selected.Count > 0)
                {
                    Row l_objRow = dgBankData.Rows.Selected[0];
                    
                    cboAccountOf.SetSelectedValue(l_objRow["s_AccountType"].ToString());
                    //txtBankCode.Text = l_objRow["s_BankCode"].ToString();
                    cboBankCode.SetSelectedValue(l_objRow["s_BankCode"].ToString());                    
                    txtBankName.Text = l_objRow["s_BankName"].ToString();
                    txtMICR.Text = l_objRow["s_MICRCode"].ToString();
                    txtBranch.Text = l_objRow["s_Branch"].ToString();
                    txtAccount.Text = l_objRow["s_AccountNo"].ToString();
                    txtCustId.Text = l_objRow["s_CustomerID"].ToString();
                    txtIFCSCode.Text = l_objRow["s_IFSCCode"].ToString();
                    if (l_objRow["s_NameOnCheque"].ToString() == null)
                    {

                    }
                    else
                    {
                        txtNameOnCheck.Text = l_objRow["s_NameOnCheque"].ToString();
                    }
                    chkDefault.Checked = l_objRow["s_Default"].ToString() == "Y";
                    objBankDtl.ClientBankNo = Convert.ToInt32(l_objRow["n_ClientBankNo"]);
                    objBankDtl.FlagAccountNo = l_objRow["s_AccountNo"].ToString();

                    btnAdd.Text = "Modify";

                    txtBankName.Enabled = false;
                    cboBankCode.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucBank), ex.Message);
            }
        }

        /// <summary>
        /// Grid click event. 
        /// </summary>
        private void dgBankData_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgBankData.Rows.Selected.Count > 0)
                {
                    Row l_objRow = dgBankData.Rows.Selected[0];

                    cboAccountOf.SetSelectedValue(l_objRow["n_AccountTypeVal"].ToString());
                    //txtBankCode.Text = l_objRow["s_BankCode"].ToString();
                    cboBankCode.SetSelectedValue(l_objRow["s_BankCode"].ToString());
                    txtBankName.Text = l_objRow["s_BankName"].ToString();
                    txtMICR.Text = l_objRow["s_MICRCode"].ToString();
                    txtBranch.Text = l_objRow["s_Branch"].ToString();
                    txtAccount.Text = l_objRow["s_AccountNo"].ToString();
                    txtCustId.Text = l_objRow["s_CustomerID"].ToString();
                    txtIFCSCode.Text = l_objRow["s_IFSCCode"].ToString();
                    txtNameOnCheck.Text = l_objRow["s_NameOnCheque"].ToString();
                    chkDefault.Checked = l_objRow["s_Default"].ToString() == "Y";
                    objBankDtl.ClientBankNo = Convert.ToInt32(l_objRow["n_ClientBankNo"]);
                    objBankDtl.FlagAccountNo = l_objRow["s_AccountNo"].ToString();
                    btnAdd.Text = "Modify";
                    cboBankCode.Enabled = false;

                    if (l_objRow["s_Default"].ToString() == "Y")
                        chkDefault.Enabled = true;

                    DataRow[] dr = objBankDtl.dtBankResult.Select("s_Default = 'Y'");
                    if (dr.Length == 0)
                        chkDefault.Enabled = true;
                    else if (l_objRow["s_Default"].ToString() != "Y")
                        chkDefault.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucBank), ex.Message);
                MessageBox.Show("Unable to fetch data.", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// remove data from grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (cboAccountOf.SelectedIndex >= 0 && txtAccount.Text != "")
                {
                    if (MessageBox.Show("Do you want to delete Account# <" + txtAccount.Text + ">?", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        //DataRow[] dr = objBankDtl.dtBankResult.Select("s_AccountNo = '" + txtAccount.Text + "'");
                        DataRow[] dr;
                        if ( objBankDtl.ClientBankNo==0)
                            dr = objBankDtl.dtBankResult.Select("s_AccountNo = " + "'" + objBankDtl.FlagAccountNo + "'");
                        else
                            dr = objBankDtl.dtBankResult.Select("n_ClientBankNo = " + objBankDtl.ClientBankNo + "");

                        if (dr.Length > 0)
                        {
                            objBankDtl.dtBankResult.Rows.Remove(dr[0]);
                            GridBind(objBankDtl.dtBankResult);

                            ResetCtrl();
                            IsBankGridUpdated = true;
                            this.IsGridUpdated = true;
                            btnAdd.Text = "Add";
                            cboBankCode.Enabled = true;
                        }
                    }
                }
                else
                {
                    ResetCtrl();
                    IsBankGridUpdated = true;
                    this.IsGridUpdated = true;
                    btnAdd.Text = "Add";
                    cboBankCode.Enabled = true;
                    txtBankCode.Focus();
                }

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucBank), ex.Message);
                MessageBox.Show(MatchCommon.CCommon.CommonDeleteFailureMessage, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// check changes made in active grid tab
        /// </summary>
        /// <returns></returns>
        public override bool CheckChanges()
        {

            if (this.IsGridUpdated == true) return true;
            try
            {
                if (objBankDtl.dtBankResult.Rows.Count == 0) return false;

                DataRow[] dr = objBankDtl.dtBankResult.Select("s_HasChanged = 'Y'");
                if (dr.Length > 0)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucBank), ex.Message);
                return false;
            }
        }

        /// <summary>
        /// reset data on submit bank changes.
        /// </summary>
        public override void ResetDt()
        {
            try
            {
                DataTable dtResult = new DataTable();
                dtResult = objBankDtl.dtBankResult;
                for (int iCnt = 0; iCnt <= dtResult.Rows.Count - 1; iCnt++)
                {
                    dtResult.Rows[iCnt]["s_HasChanged"] = "N";

                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucBank), ex.Message);
            }
        }
        private void ResetCtrl()
        {
            objBankDtl.dLastUpdatedDate = null;
            chkDefault.Enabled = true;
            btnAdd.Text = "Add";
            cboBankCode.Enabled = true;
            txtBankCode.Text = string.Empty;
            txtBankName.Text = string.Empty;
            txtIFCSCode.Text = string.Empty;
            txtAccount.Text = string.Empty;
            txtMICR.Text = string.Empty;
            txtCustId.Text = string.Empty;
            txtBranch.Text = string.Empty;
            txtNameOnCheck.Text = string.Empty;
            cboAccountOf.SelectedIndex = -1;
            cboBankCode.SelectedIndex = -1;
            chkDefault.Checked = false;

            DataRow[] dr = objBankDtl.dtBankResult.Select("s_Default = 'Y'");
            if (dr.Length == 0)
                chkDefault.Enabled = true;
            else
                chkDefault.Enabled = false;
        }

        private void cboBankCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sVal = cboBankCode.GetSelectedValue();
            if (sVal != "")
            {
                DataRow[] dr = dtBankMaster.Select("BankCode = '" + sVal + "'");
                if (dr.Length > 0)
                    txtBankName.Text = dr[0]["BankName"].ToString();

                txtBankName.Enabled = false;
            }
        }
        
    }
}
