﻿namespace FTIL.Match.CDD.UI.UserControls
{
    partial class ucNote
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtComment = new MatchCommon.CustomControls.FTTextBox();
            this.lblUserInfo = new MatchCommon.CustomControls.FTLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Type";
            this.dataGridViewTextBoxColumn4.MaxInputLength = 100;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // Date
            // 
            this.Date.HeaderText = "Date";
            this.Date.Name = "Date";
            // 
            // txtComment
            // 
            this.txtComment.AcceptsTab = true;
            this.txtComment.AllowAlpha = true;
            this.txtComment.AllowDot = true;
            this.txtComment.AllowedCustomCharacters = null;
            this.txtComment.AllowNonASCII = false;
            this.txtComment.AllowNumeric = true;
            this.txtComment.AllowSpace = true;
            this.txtComment.AllowSpecialChars = true;
            this.txtComment.FocusColor = System.Drawing.Color.White;
            this.txtComment.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtComment.ForeColor = System.Drawing.Color.Black;
            this.txtComment.IsEmailID = false;
            this.txtComment.IsEmailIdValid = false;
            this.txtComment.Location = new System.Drawing.Point(3, 5);
            this.txtComment.MaxLength = 2000;
            this.txtComment.Multiline = true;
            this.txtComment.Name = "txtComment";
            this.txtComment.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtComment.Size = new System.Drawing.Size(761, 452);
            this.txtComment.TabIndex = 5;
            this.txtComment.Tag = "Code";
            // 
            // lblUserInfo
            // 
            this.lblUserInfo.AllowForeColorChange = false;
            this.lblUserInfo.AutoSize = true;
            this.lblUserInfo.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblUserInfo.ForeColor = System.Drawing.Color.Black;
            this.lblUserInfo.Location = new System.Drawing.Point(3, 475);
            this.lblUserInfo.Name = "lblUserInfo";
            this.lblUserInfo.OverrideDefault = false;
            this.lblUserInfo.Size = new System.Drawing.Size(59, 13);
            this.lblUserInfo.TabIndex = 92;
            this.lblUserInfo.Text = "lblUserInfo";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtComment);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(767, 458);
            this.panel1.TabIndex = 93;
            // 
            // ucNote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblUserInfo);
            this.Name = "ucNote";
            this.Size = new System.Drawing.Size(772, 508);
            this.Load += new System.EventHandler(this.ucNote_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion


        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date;
        private MatchCommon.CustomControls.FTTextBox txtComment;
        private MatchCommon.CustomControls.FTLabel lblUserInfo;
        private System.Windows.Forms.Panel panel1;
    }
}
