﻿namespace FTIL.Match.CDD.UI.UserControls
{
    partial class ucEntityProduct
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucEntityProduct));
            this.btnSync = new System.Windows.Forms.Button();
            this.dgvProduct = new MatchCommon.CustomControls.FTDataGrid();
            this.pnlProduct = new System.Windows.Forms.Panel();
            this.pnlExchangeMap = new System.Windows.Forms.Panel();
            this.dgvClientExchange = new MatchCommon.CustomControls.FTDataGrid();
            this.chkSelectAll = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProduct)).BeginInit();
            this.pnlProduct.SuspendLayout();
            this.pnlExchangeMap.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClientExchange)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSync
            // 
            this.btnSync.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSync.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSync.Image = ((System.Drawing.Image)(resources.GetObject("btnSync.Image")));
            this.btnSync.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSync.Location = new System.Drawing.Point(681, 194);
            this.btnSync.Name = "btnSync";
            this.btnSync.Size = new System.Drawing.Size(85, 23);
            this.btnSync.TabIndex = 1;
            this.btnSync.Text = "Sync";
            this.btnSync.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSync.UseVisualStyleBackColor = true;
            this.btnSync.Click += new System.EventHandler(this.btnSync_Click);
            // 
            // dgvProduct
            // 
            this.dgvProduct.AllowEditing = false;
            this.dgvProduct.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
            this.dgvProduct.BackColor = System.Drawing.Color.White;
            this.dgvProduct.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.dgvProduct.ColumnInfo = "5,1,0,0,0,95,Columns:0{Width:30;}\t";
            this.dgvProduct.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
            this.dgvProduct.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dgvProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.dgvProduct.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
            this.dgvProduct.Location = new System.Drawing.Point(0, 2);
            this.dgvProduct.Name = "dgvProduct";
            this.dgvProduct.Styles.EmptyArea.BackColor = System.Drawing.Color.White;
            this.dgvProduct.OverrideDefault = false;
            this.dgvProduct.Rows.Count = 10;
            this.dgvProduct.Rows.DefaultSize = 19;
            this.dgvProduct.Rows.MinSize = 25;
            this.dgvProduct.RowsFilter.AddFilterRow = false;
            this.dgvProduct.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Cell;
            this.dgvProduct.Size = new System.Drawing.Size(770, 180);
            this.dgvProduct.StyleInfo = "";
            this.dgvProduct.TabIndex = 0;
            this.dgvProduct.Text = "dgvProduct";
            this.dgvProduct.Click += new System.EventHandler(this.dgvProduct_Click);
            this.dgvProduct.DoubleClick += new System.EventHandler(this.dgvProduct_DoubleClick);
            // 
            // pnlProduct
            // 
            this.pnlProduct.Controls.Add(this.dgvProduct);
            this.pnlProduct.Controls.Add(this.btnSync);
            this.pnlProduct.Location = new System.Drawing.Point(3, 250);
            this.pnlProduct.Name = "pnlProduct";
            this.pnlProduct.Size = new System.Drawing.Size(863, 270);
            this.pnlProduct.TabIndex = 2;
            // 
            // pnlExchangeMap
            // 
            this.pnlExchangeMap.Controls.Add(this.dgvClientExchange);
            this.pnlExchangeMap.Controls.Add(this.chkSelectAll);
            this.pnlExchangeMap.Location = new System.Drawing.Point(3, 4);
            this.pnlExchangeMap.Name = "pnlExchangeMap";
            this.pnlExchangeMap.Size = new System.Drawing.Size(860, 239);
            this.pnlExchangeMap.TabIndex = 5;
            // 
            // dgvClientExchange
            // 
            this.dgvClientExchange.AllowEditing = false;
            this.dgvClientExchange.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
            this.dgvClientExchange.BackColor = System.Drawing.Color.White;
            this.dgvClientExchange.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.dgvClientExchange.ColumnInfo = "5,1,0,0,0,95,Columns:0{Width:30;}\t";
            this.dgvClientExchange.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
            this.dgvClientExchange.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dgvClientExchange.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.dgvClientExchange.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
            this.dgvClientExchange.Location = new System.Drawing.Point(0, 2);
            this.dgvClientExchange.Name = "dgvProduct";
            this.dgvClientExchange.Styles.EmptyArea.BackColor = System.Drawing.Color.White;
            this.dgvClientExchange.OverrideDefault = false;
            this.dgvClientExchange.Rows.Count = 10;
            this.dgvClientExchange.Rows.DefaultSize = 19;
            this.dgvClientExchange.Rows.MinSize = 25;
            this.dgvClientExchange.RowsFilter.AddFilterRow = false;
            this.dgvClientExchange.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Cell;
            this.dgvClientExchange.Size = new System.Drawing.Size(770, 180);
            this.dgvClientExchange.StyleInfo = "";
            this.dgvClientExchange.TabIndex = 0;
            this.dgvClientExchange.Text = "dgvProduct";
            // 
            // chkSelectAll
            // 
            this.chkSelectAll.AutoSize = true;
            this.chkSelectAll.Location = new System.Drawing.Point(21, 242);
            this.chkSelectAll.Name = "chkSelectAll";
            this.chkSelectAll.Size = new System.Drawing.Size(70, 17);
            this.chkSelectAll.TabIndex = 2;
            this.chkSelectAll.Text = "Select All";
            this.chkSelectAll.UseVisualStyleBackColor = true;
            this.chkSelectAll.Visible = false;
            // 
            // ucEntityProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.pnlExchangeMap);
            this.Controls.Add(this.pnlProduct);
            this.Name = "ucEntityProduct";
            this.Size = new System.Drawing.Size(866, 521);
            this.Load += new System.EventHandler(this.ucEntityProduct_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProduct)).EndInit();
            this.pnlProduct.ResumeLayout(false);
            this.pnlExchangeMap.ResumeLayout(false);
            this.pnlExchangeMap.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClientExchange)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSync;
        private  MatchCommon.CustomControls.FTDataGrid dgvProduct;
        private System.Windows.Forms.Panel pnlProduct;
        private System.Windows.Forms.Panel pnlExchangeMap;
        private MatchCommon.CustomControls.FTDataGrid dgvClientExchange;
        private System.Windows.Forms.CheckBox chkSelectAll;
    }
}
