﻿namespace FTIL.Match.CDD.UI.UserControls
{
    partial class ucBank
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucBank));
            this.pnlBank = new System.Windows.Forms.Panel();
            this.dgBankData = new MatchCommon.CustomControls.FTDataGrid();
            this.btnDelete = new MatchCommon.CustomControls.FTButton();
            this.btnAdd = new MatchCommon.CustomControls.FTButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtNameOnCheck = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel35 = new MatchCommon.CustomControls.FTLabel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.cboBankCode = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel5 = new MatchCommon.CustomControls.FTLabel();
            this.txtIFCSCode = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel4 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel3 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel2 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel1 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel36 = new MatchCommon.CustomControls.FTLabel();
            this.chkDefault = new MatchCommon.CustomControls.FTCheckBox();
            this.txtMICR = new MatchCommon.CustomControls.FTTextBox();
            this.txtBankName = new MatchCommon.CustomControls.FTTextBox();
            this.txtCustId = new MatchCommon.CustomControls.FTTextBox();
            this.txtBranch = new MatchCommon.CustomControls.FTTextBox();
            this.txtBankCode = new MatchCommon.CustomControls.FTTextBox();
            this.txtAccount = new MatchCommon.CustomControls.FTTextBox();
            this.cboAccountOf = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel37 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel38 = new MatchCommon.CustomControls.FTLabel();
            this.ftLblBank = new MatchCommon.CustomControls.FTLabel();
            this.pnlBank.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgBankData)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlBank
            // 
            this.pnlBank.Controls.Add(this.dgBankData);
            this.pnlBank.Location = new System.Drawing.Point(-1, 62);
            this.pnlBank.Name = "pnlBank";
            this.pnlBank.Size = new System.Drawing.Size(766, 199);
            this.pnlBank.TabIndex = 102;
            // 
            // dgBankData
            // 
            this.dgBankData.AllowEditing = false;
            this.dgBankData.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
            this.dgBankData.BackColor = System.Drawing.Color.White;
            this.dgBankData.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.dgBankData.ColumnInfo = "5,1,0,0,0,95,Columns:0{Width:30;}\t";
            this.dgBankData.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
            this.dgBankData.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dgBankData.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.dgBankData.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
            this.dgBankData.Location = new System.Drawing.Point(3, 5);
            this.dgBankData.Name = "dgBankData";
            this.dgBankData.Styles.EmptyArea.BackColor = System.Drawing.Color.White;
            this.dgBankData.OverrideDefault = false;
            this.dgBankData.Rows.Count = 10;
            this.dgBankData.Rows.DefaultSize = 19;
            this.dgBankData.Rows.MinSize = 25;
            this.dgBankData.RowsFilter.AddFilterRow = false;
            this.dgBankData.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.ListBox;
            this.dgBankData.Size = new System.Drawing.Size(770, 195);
            this.dgBankData.StyleInfo = "";
            this.dgBankData.TabIndex = 4;
            this.dgBankData.Click += new System.EventHandler(this.dgBankData_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Transparent;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.Location = new System.Drawing.Point(689, 472);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 25);
            this.btnDelete.TabIndex = 101;
            this.btnDelete.Text = "&Remove";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Transparent;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAdd.Location = new System.Drawing.Point(607, 472);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 25);
            this.btnAdd.TabIndex = 100;
            this.btnAdd.Text = "&Add";
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txtNameOnCheck);
            this.groupBox5.Controls.Add(this.ftLabel35);
            this.groupBox5.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox5.Location = new System.Drawing.Point(3, 8);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(762, 48);
            this.groupBox5.TabIndex = 57;
            this.groupBox5.TabStop = false;
            // 
            // txtNameOnCheck
            // 
            this.txtNameOnCheck.AllowAlpha = true;
            this.txtNameOnCheck.AllowDot = false;
            this.txtNameOnCheck.AllowedCustomCharacters = null;
            this.txtNameOnCheck.AllowNonASCII = false;
            this.txtNameOnCheck.AllowNumeric = true;
            this.txtNameOnCheck.AllowSpace = true;
            this.txtNameOnCheck.AllowSpecialChars = true;
            this.txtNameOnCheck.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNameOnCheck.FocusColor = System.Drawing.Color.LightYellow;
            this.txtNameOnCheck.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtNameOnCheck.ForeColor = System.Drawing.Color.Black;
            this.txtNameOnCheck.IsEmailID = false;
            this.txtNameOnCheck.IsEmailIdValid = false;
            this.txtNameOnCheck.Location = new System.Drawing.Point(99, 18);
            this.txtNameOnCheck.MaxLength = 50;
            this.txtNameOnCheck.Name = "txtNameOnCheck";
            this.txtNameOnCheck.Size = new System.Drawing.Size(404, 20);
            this.txtNameOnCheck.TabIndex = 99;
            this.txtNameOnCheck.Tag = "Code";
            // 
            // ftLabel35
            // 
            this.ftLabel35.AllowForeColorChange = false;
            this.ftLabel35.AutoSize = true;
            this.ftLabel35.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel35.ForeColor = System.Drawing.Color.Black;
            this.ftLabel35.Location = new System.Drawing.Point(4, 21);
            this.ftLabel35.Name = "ftLabel35";
            this.ftLabel35.OverrideDefault = false;
            this.ftLabel35.Size = new System.Drawing.Size(89, 13);
            this.ftLabel35.TabIndex = 26;
            this.ftLabel35.Text = "Name on Cheque";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.cboBankCode);
            this.groupBox4.Controls.Add(this.ftLabel5);
            this.groupBox4.Controls.Add(this.txtIFCSCode);
            this.groupBox4.Controls.Add(this.ftLabel4);
            this.groupBox4.Controls.Add(this.ftLabel3);
            this.groupBox4.Controls.Add(this.ftLabel2);
            this.groupBox4.Controls.Add(this.ftLabel1);
            this.groupBox4.Controls.Add(this.ftLabel36);
            this.groupBox4.Controls.Add(this.chkDefault);
            this.groupBox4.Controls.Add(this.txtMICR);
            this.groupBox4.Controls.Add(this.txtBankName);
            this.groupBox4.Controls.Add(this.txtCustId);
            this.groupBox4.Controls.Add(this.txtBranch);
            this.groupBox4.Controls.Add(this.txtBankCode);
            this.groupBox4.Controls.Add(this.txtAccount);
            this.groupBox4.Controls.Add(this.cboAccountOf);
            this.groupBox4.Controls.Add(this.ftLabel37);
            this.groupBox4.Controls.Add(this.ftLabel38);
            this.groupBox4.Controls.Add(this.ftLblBank);
            this.groupBox4.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox4.Location = new System.Drawing.Point(3, 262);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(762, 150);
            this.groupBox4.TabIndex = 56;
            this.groupBox4.TabStop = false;
            // 
            // cboBankCode
            // 
            this.cboBankCode.BackColor = System.Drawing.Color.White;
            this.cboBankCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboBankCode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboBankCode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboBankCode.ForeColor = System.Drawing.Color.Black;
            this.cboBankCode.FormattingEnabled = true;
            this.cboBankCode.Location = new System.Drawing.Point(72, 18);
            this.cboBankCode.Name = "cboBankCode";
            this.cboBankCode.ReadOnly = false;
            this.cboBankCode.Size = new System.Drawing.Size(96, 21);
            this.cboBankCode.TabIndex = 102;
            this.cboBankCode.SelectedIndexChanged += new System.EventHandler(this.cboBankCode_SelectedIndexChanged);
            // 
            // ftLabel5
            // 
            this.ftLabel5.AllowForeColorChange = false;
            this.ftLabel5.AutoSize = true;
            this.ftLabel5.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel5.ForeColor = System.Drawing.Color.Black;
            this.ftLabel5.Location = new System.Drawing.Point(6, 98);
            this.ftLabel5.Name = "ftLabel5";
            this.ftLabel5.OverrideDefault = false;
            this.ftLabel5.Size = new System.Drawing.Size(58, 13);
            this.ftLabel5.TabIndex = 58;
            this.ftLabel5.Text = "IFSC Code";
            // 
            // txtIFCSCode
            // 
            this.txtIFCSCode.AllowAlpha = true;
            this.txtIFCSCode.AllowDot = false;
            this.txtIFCSCode.AllowedCustomCharacters = null;
            this.txtIFCSCode.AllowNonASCII = false;
            this.txtIFCSCode.AllowNumeric = true;
            this.txtIFCSCode.AllowSpace = false;
            this.txtIFCSCode.AllowSpecialChars = true;
            this.txtIFCSCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtIFCSCode.FocusColor = System.Drawing.Color.LightYellow;
            this.txtIFCSCode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtIFCSCode.ForeColor = System.Drawing.Color.Black;
            this.txtIFCSCode.IsEmailID = false;
            this.txtIFCSCode.IsEmailIdValid = false;
            this.txtIFCSCode.Location = new System.Drawing.Point(71, 95);
            this.txtIFCSCode.MaxLength = 20;
            this.txtIFCSCode.Name = "txtIFCSCode";
            this.txtIFCSCode.Size = new System.Drawing.Size(97, 20);
            this.txtIFCSCode.TabIndex = 97;
            this.txtIFCSCode.Tag = "Code";
            // 
            // ftLabel4
            // 
            this.ftLabel4.AllowForeColorChange = false;
            this.ftLabel4.AutoSize = true;
            this.ftLabel4.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel4.ForeColor = System.Drawing.Color.Black;
            this.ftLabel4.Location = new System.Drawing.Point(441, 74);
            this.ftLabel4.Name = "ftLabel4";
            this.ftLabel4.OverrideDefault = false;
            this.ftLabel4.Size = new System.Drawing.Size(54, 13);
            this.ftLabel4.TabIndex = 56;
            this.ftLabel4.Text = "Account#";
            // 
            // ftLabel3
            // 
            this.ftLabel3.AllowForeColorChange = false;
            this.ftLabel3.AutoSize = true;
            this.ftLabel3.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel3.ForeColor = System.Drawing.Color.Black;
            this.ftLabel3.Location = new System.Drawing.Point(207, 73);
            this.ftLabel3.Name = "ftLabel3";
            this.ftLabel3.OverrideDefault = false;
            this.ftLabel3.Size = new System.Drawing.Size(42, 13);
            this.ftLabel3.TabIndex = 55;
            this.ftLabel3.Text = "Cust Id";
            // 
            // ftLabel2
            // 
            this.ftLabel2.AllowForeColorChange = false;
            this.ftLabel2.AutoSize = true;
            this.ftLabel2.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel2.ForeColor = System.Drawing.Color.Black;
            this.ftLabel2.Location = new System.Drawing.Point(207, 24);
            this.ftLabel2.Name = "ftLabel2";
            this.ftLabel2.OverrideDefault = false;
            this.ftLabel2.Size = new System.Drawing.Size(60, 13);
            this.ftLabel2.TabIndex = 54;
            this.ftLabel2.Text = "Bank Name";
            // 
            // ftLabel1
            // 
            this.ftLabel1.AllowForeColorChange = false;
            this.ftLabel1.AutoSize = true;
            this.ftLabel1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel1.ForeColor = System.Drawing.Color.Black;
            this.ftLabel1.Location = new System.Drawing.Point(6, 47);
            this.ftLabel1.Name = "ftLabel1";
            this.ftLabel1.OverrideDefault = false;
            this.ftLabel1.Size = new System.Drawing.Size(33, 13);
            this.ftLabel1.TabIndex = 53;
            this.ftLabel1.Text = "MICR";
            // 
            // ftLabel36
            // 
            this.ftLabel36.AllowForeColorChange = false;
            this.ftLabel36.AutoSize = true;
            this.ftLabel36.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel36.ForeColor = System.Drawing.Color.Black;
            this.ftLabel36.Location = new System.Drawing.Point(6, 124);
            this.ftLabel36.Name = "ftLabel36";
            this.ftLabel36.OverrideDefault = false;
            this.ftLabel36.Size = new System.Drawing.Size(42, 13);
            this.ftLabel36.TabIndex = 50;
            this.ftLabel36.Text = "Default";
            // 
            // chkDefault
            // 
            this.chkDefault.AutoSize = true;
            this.chkDefault.Font = new System.Drawing.Font("Tahoma", 8F);
            this.chkDefault.ForeColor = System.Drawing.Color.Black;
            this.chkDefault.Location = new System.Drawing.Point(71, 124);
            this.chkDefault.Name = "chkDefault";
            this.chkDefault.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.chkDefault.Size = new System.Drawing.Size(15, 14);
            this.chkDefault.TabIndex = 98;
            this.chkDefault.UseVisualStyleBackColor = true;
            // 
            // txtMICR
            // 
            this.txtMICR.AllowAlpha = true;
            this.txtMICR.AllowDot = false;
            this.txtMICR.AllowedCustomCharacters = null;
            this.txtMICR.AllowNonASCII = false;
            this.txtMICR.AllowNumeric = true;
            this.txtMICR.AllowSpace = false;
            this.txtMICR.AllowSpecialChars = true;
            this.txtMICR.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMICR.FocusColor = System.Drawing.Color.LightYellow;
            this.txtMICR.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtMICR.ForeColor = System.Drawing.Color.Black;
            this.txtMICR.IsEmailID = false;
            this.txtMICR.IsEmailIdValid = false;
            this.txtMICR.Location = new System.Drawing.Point(71, 44);
            this.txtMICR.MaxLength = 20;
            this.txtMICR.Name = "txtMICR";
            this.txtMICR.Size = new System.Drawing.Size(97, 20);
            this.txtMICR.TabIndex = 91;
            this.txtMICR.Tag = "Code";
            // 
            // txtBankName
            // 
            this.txtBankName.AllowAlpha = true;
            this.txtBankName.AllowDot = false;
            this.txtBankName.AllowedCustomCharacters = null;
            this.txtBankName.AllowNonASCII = false;
            this.txtBankName.AllowNumeric = true;
            this.txtBankName.AllowSpace = true;
            this.txtBankName.AllowSpecialChars = true;
            this.txtBankName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtBankName.Enabled = false;
            this.txtBankName.FocusColor = System.Drawing.Color.LightYellow;
            this.txtBankName.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtBankName.ForeColor = System.Drawing.Color.Black;
            this.txtBankName.IsEmailID = false;
            this.txtBankName.IsEmailIdValid = false;
            this.txtBankName.Location = new System.Drawing.Point(279, 20);
            this.txtBankName.MaxLength = 50;
            this.txtBankName.Name = "txtBankName";
            this.txtBankName.Size = new System.Drawing.Size(474, 20);
            this.txtBankName.TabIndex = 90;
            this.txtBankName.Tag = "Code";
            // 
            // txtCustId
            // 
            this.txtCustId.AllowAlpha = true;
            this.txtCustId.AllowDot = false;
            this.txtCustId.AllowedCustomCharacters = null;
            this.txtCustId.AllowNonASCII = false;
            this.txtCustId.AllowNumeric = true;
            this.txtCustId.AllowSpace = false;
            this.txtCustId.AllowSpecialChars = true;
            this.txtCustId.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCustId.FocusColor = System.Drawing.Color.LightYellow;
            this.txtCustId.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtCustId.ForeColor = System.Drawing.Color.Black;
            this.txtCustId.IsEmailID = false;
            this.txtCustId.IsEmailIdValid = false;
            this.txtCustId.Location = new System.Drawing.Point(279, 70);
            this.txtCustId.MaxLength = 20;
            this.txtCustId.Name = "txtCustId";
            this.txtCustId.Size = new System.Drawing.Size(149, 20);
            this.txtCustId.TabIndex = 95;
            this.txtCustId.Tag = "Code";
            // 
            // txtBranch
            // 
            this.txtBranch.AllowAlpha = true;
            this.txtBranch.AllowDot = false;
            this.txtBranch.AllowedCustomCharacters = null;
            this.txtBranch.AllowNonASCII = false;
            this.txtBranch.AllowNumeric = true;
            this.txtBranch.AllowSpace = true;
            this.txtBranch.AllowSpecialChars = true;
            this.txtBranch.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtBranch.FocusColor = System.Drawing.Color.LightYellow;
            this.txtBranch.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtBranch.ForeColor = System.Drawing.Color.Black;
            this.txtBranch.IsEmailID = false;
            this.txtBranch.IsEmailIdValid = false;
            this.txtBranch.Location = new System.Drawing.Point(279, 45);
            this.txtBranch.MaxLength = 100;
            this.txtBranch.Name = "txtBranch";
            this.txtBranch.Size = new System.Drawing.Size(474, 20);
            this.txtBranch.TabIndex = 92;
            this.txtBranch.Tag = "Code";
            // 
            // txtBankCode
            // 
            this.txtBankCode.AllowAlpha = true;
            this.txtBankCode.AllowDot = false;
            this.txtBankCode.AllowedCustomCharacters = null;
            this.txtBankCode.AllowNonASCII = false;
            this.txtBankCode.AllowNumeric = true;
            this.txtBankCode.AllowSpace = false;
            this.txtBankCode.AllowSpecialChars = true;
            this.txtBankCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtBankCode.FocusColor = System.Drawing.Color.LightYellow;
            this.txtBankCode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtBankCode.ForeColor = System.Drawing.Color.Black;
            this.txtBankCode.IsEmailID = false;
            this.txtBankCode.IsEmailIdValid = false;
            this.txtBankCode.Location = new System.Drawing.Point(72, 20);
            this.txtBankCode.MaxLength = 15;
            this.txtBankCode.Name = "txtBankCode";
            this.txtBankCode.Size = new System.Drawing.Size(96, 20);
            this.txtBankCode.TabIndex = 89;
            this.txtBankCode.Tag = "Code";
            this.txtBankCode.Visible = false;
            // 
            // txtAccount
            // 
            this.txtAccount.AllowAlpha = true;
            this.txtAccount.AllowDot = false;
            this.txtAccount.AllowedCustomCharacters = null;
            this.txtAccount.AllowNonASCII = false;
            this.txtAccount.AllowNumeric = true;
            this.txtAccount.AllowSpace = false;
            this.txtAccount.AllowSpecialChars = false;
            this.txtAccount.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtAccount.FocusColor = System.Drawing.Color.LightYellow;
            this.txtAccount.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtAccount.ForeColor = System.Drawing.Color.Black;
            this.txtAccount.IsEmailID = false;
            this.txtAccount.IsEmailIdValid = false;
            this.txtAccount.Location = new System.Drawing.Point(503, 71);
            this.txtAccount.MaxLength = 20;
            this.txtAccount.Name = "txtAccount";
            this.txtAccount.Size = new System.Drawing.Size(250, 20);
            this.txtAccount.TabIndex = 96;
            this.txtAccount.Tag = "Code";
            // 
            // cboAccountOf
            // 
            this.cboAccountOf.BackColor = System.Drawing.Color.White;
            this.cboAccountOf.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboAccountOf.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboAccountOf.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboAccountOf.ForeColor = System.Drawing.Color.Black;
            this.cboAccountOf.FormattingEnabled = true;
            this.cboAccountOf.Location = new System.Drawing.Point(72, 69);
            this.cboAccountOf.Name = "cboAccountOf";
            this.cboAccountOf.ReadOnly = false;
            this.cboAccountOf.Size = new System.Drawing.Size(96, 21);
            this.cboAccountOf.TabIndex = 93;
            // 
            // ftLabel37
            // 
            this.ftLabel37.AllowForeColorChange = false;
            this.ftLabel37.AutoSize = true;
            this.ftLabel37.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel37.ForeColor = System.Drawing.Color.Black;
            this.ftLabel37.Location = new System.Drawing.Point(207, 48);
            this.ftLabel37.Name = "ftLabel37";
            this.ftLabel37.OverrideDefault = false;
            this.ftLabel37.Size = new System.Drawing.Size(40, 13);
            this.ftLabel37.TabIndex = 26;
            this.ftLabel37.Text = "Branch";
            // 
            // ftLabel38
            // 
            this.ftLabel38.AllowForeColorChange = false;
            this.ftLabel38.AutoSize = true;
            this.ftLabel38.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel38.ForeColor = System.Drawing.Color.Black;
            this.ftLabel38.Location = new System.Drawing.Point(6, 72);
            this.ftLabel38.Name = "ftLabel38";
            this.ftLabel38.OverrideDefault = false;
            this.ftLabel38.Size = new System.Drawing.Size(46, 13);
            this.ftLabel38.TabIndex = 31;
            this.ftLabel38.Text = "Account";
            // 
            // ftLblBank
            // 
            this.ftLblBank.AllowForeColorChange = false;
            this.ftLblBank.AutoSize = true;
            this.ftLblBank.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLblBank.ForeColor = System.Drawing.Color.Black;
            this.ftLblBank.Location = new System.Drawing.Point(6, 24);
            this.ftLblBank.Name = "ftLblBank";
            this.ftLblBank.OverrideDefault = false;
            this.ftLblBank.Size = new System.Drawing.Size(58, 13);
            this.ftLblBank.TabIndex = 36;
            this.ftLblBank.Text = "Bank Code";
            // 
            // ucBank
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.pnlBank);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Name = "ucBank";
            this.Size = new System.Drawing.Size(768, 558);
            this.Load += new System.EventHandler(this.ucBank_Load);
            this.pnlBank.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgBankData)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        //private System.Windows.Forms.DataGridView dgBankDetails;
        private System.Windows.Forms.GroupBox groupBox5;
        private MatchCommon.CustomControls.FTTextBox txtNameOnCheck;
        private MatchCommon.CustomControls.FTLabel ftLabel35;
        private System.Windows.Forms.GroupBox groupBox4;
        private MatchCommon.CustomControls.FTLabel ftLabel36;
        private MatchCommon.CustomControls.FTCheckBox chkDefault;
        private MatchCommon.CustomControls.FTTextBox txtMICR;
        private MatchCommon.CustomControls.FTTextBox txtBankName;
        private MatchCommon.CustomControls.FTTextBox txtCustId;
        private MatchCommon.CustomControls.FTTextBox txtBranch;
        private MatchCommon.CustomControls.FTTextBox txtBankCode;
        private MatchCommon.CustomControls.FTTextBox txtAccount;
        private MatchCommon.CustomControls.FTComboBox cboAccountOf;
        private MatchCommon.CustomControls.FTLabel ftLabel37;
        private MatchCommon.CustomControls.FTLabel ftLabel38;
        private MatchCommon.CustomControls.FTLabel ftLblBank;
        private MatchCommon.CustomControls.FTLabel ftLabel5;
        private MatchCommon.CustomControls.FTTextBox txtIFCSCode;
        private MatchCommon.CustomControls.FTLabel ftLabel4;
        private MatchCommon.CustomControls.FTLabel ftLabel3;
        private MatchCommon.CustomControls.FTLabel ftLabel2;
        private MatchCommon.CustomControls.FTLabel ftLabel1;
        private MatchCommon.CustomControls.FTButton btnDelete;
        private MatchCommon.CustomControls.FTButton btnAdd;
        private MatchCommon.CustomControls.FTDataGrid dgBankData;
        private MatchCommon.CustomControls.FTComboBox cboBankCode;
        private System.Windows.Forms.Panel pnlBank;
    }
}
