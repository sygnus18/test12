﻿namespace CommonEntityMaster.UI.UserControls
{
    partial class ucEntityNonInd
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucEntityNonInd));
            this.ftLabel78 = new MatchCommon.CustomControls.FTLabel();
            this.tbEntity = new System.Windows.Forms.TabControl();
            this.tbAccount = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.ftTextBox1 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox2 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox3 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox4 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel17 = new MatchCommon.CustomControls.FTLabel();
            this.ftTextBox5 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel18 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel19 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel20 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel21 = new MatchCommon.CustomControls.FTLabel();
            this.ftTextBox6 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox7 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox17 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox19 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel22 = new MatchCommon.CustomControls.FTLabel();
            this.ftTextBox20 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel23 = new MatchCommon.CustomControls.FTLabel();
            this.ftComboBox7 = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel33 = new MatchCommon.CustomControls.FTLabel();
            this.ftComboBox9 = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel35 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel36 = new MatchCommon.CustomControls.FTLabel();
            this.ftComboBox10 = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel37 = new MatchCommon.CustomControls.FTLabel();
            this.ftCheckBox2 = new MatchCommon.CustomControls.FTCheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ftTextBox21 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox22 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox23 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox24 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel38 = new MatchCommon.CustomControls.FTLabel();
            this.ftTextBox28 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel48 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel49 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel50 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel51 = new MatchCommon.CustomControls.FTLabel();
            this.ftTextBox29 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox30 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox31 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox32 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel52 = new MatchCommon.CustomControls.FTLabel();
            this.ftTextBox33 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel55 = new MatchCommon.CustomControls.FTLabel();
            this.ftComboBox11 = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel56 = new MatchCommon.CustomControls.FTLabel();
            this.ftComboBox12 = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel57 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel58 = new MatchCommon.CustomControls.FTLabel();
            this.ftComboBox13 = new MatchCommon.CustomControls.FTComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtStatus = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel63 = new MatchCommon.CustomControls.FTLabel();
            this.ftCmbStatus = new MatchCommon.CustomControls.FTComboBox();
            this.txtPAN = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel62 = new MatchCommon.CustomControls.FTLabel();
            this.dateTimePicker9 = new System.Windows.Forms.DateTimePicker();
            this.ftLabel61 = new MatchCommon.CustomControls.FTLabel();
            this.ftTxtCINNo = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel60 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel59 = new MatchCommon.CustomControls.FTLabel();
            this.ftTextBox34 = new MatchCommon.CustomControls.FTTextBox();
            this.ftCreated = new MatchCommon.CustomControls.FTLabel();
            this.dateTimePicker8 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.ftlblDOB = new MatchCommon.CustomControls.FTLabel();
            this.tbOthers = new System.Windows.Forms.TabPage();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Relationship = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ftLabel74 = new MatchCommon.CustomControls.FTLabel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.ftTextBox35 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox36 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox37 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox38 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel64 = new MatchCommon.CustomControls.FTLabel();
            this.ftTextBox39 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel65 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel66 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel67 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel68 = new MatchCommon.CustomControls.FTLabel();
            this.ftTextBox40 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox41 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox42 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox43 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel69 = new MatchCommon.CustomControls.FTLabel();
            this.ftTextBox44 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel70 = new MatchCommon.CustomControls.FTLabel();
            this.ftComboBox14 = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel71 = new MatchCommon.CustomControls.FTLabel();
            this.ftComboBox15 = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel72 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel73 = new MatchCommon.CustomControls.FTLabel();
            this.ftComboBox16 = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel53 = new MatchCommon.CustomControls.FTLabel();
            this.DocUpload = new System.Windows.Forms.TabPage();
            this.ftLabel54 = new MatchCommon.CustomControls.FTLabel();
            this.ftTxtUserId = new MatchCommon.CustomControls.FTTextBox();
            this.ftTxtPEP = new MatchCommon.CustomControls.FTTextBox();
            this.ftTxtOccupation = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel39 = new MatchCommon.CustomControls.FTLabel();
            this.ftCmbPEP = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel40 = new MatchCommon.CustomControls.FTLabel();
            this.ftCmbOccupation = new MatchCommon.CustomControls.FTComboBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker6 = new System.Windows.Forms.DateTimePicker();
            this.ftCmbGrossAnnual = new MatchCommon.CustomControls.FTComboBox();
            this.dateTimePicker5 = new System.Windows.Forms.DateTimePicker();
            this.ftTextBox25 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel41 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel42 = new MatchCommon.CustomControls.FTLabel();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.ftBtnSaveIdentity = new MatchCommon.CustomControls.FTButton();
            this.btnDelete = new MatchCommon.CustomControls.FTButton();
            this.btnAdd = new MatchCommon.CustomControls.FTButton();
            this.ftLabel43 = new MatchCommon.CustomControls.FTLabel();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.ftLabel44 = new MatchCommon.CustomControls.FTLabel();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.ftLabel45 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel46 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel47 = new MatchCommon.CustomControls.FTLabel();
            this.ftTextBox26 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox27 = new MatchCommon.CustomControls.FTTextBox();
            this.ftComboBox8 = new MatchCommon.CustomControls.FTComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.ftBtnRemoveDoc = new MatchCommon.CustomControls.FTButton();
            this.ftLabel77 = new MatchCommon.CustomControls.FTLabel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.btnImport = new System.Windows.Forms.Button();
            this.ftLabel81 = new MatchCommon.CustomControls.FTLabel();
            this.ftCmbTypeofDocument = new MatchCommon.CustomControls.FTComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.chkProtector = new System.Windows.Forms.CheckBox();
            this.chkMatch = new System.Windows.Forms.CheckBox();
            this.chkDP = new System.Windows.Forms.CheckBox();
            this.chkODIN = new System.Windows.Forms.CheckBox();
            this.btnApply = new MatchCommon.CustomControls.FTButton();
            this.lblMobileNo = new MatchCommon.CustomControls.FTLabel();
            this.ftlblEntityCode = new MatchCommon.CustomControls.FTLabel();
            this.lblHeading = new System.Windows.Forms.Label();
            this.txtNameHead = new System.Windows.Forms.TextBox();
            this.txtEntityCode = new System.Windows.Forms.TextBox();
            this.ftTxtCIN = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel34 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel11 = new MatchCommon.CustomControls.FTLabel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.ftTxtPAN = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel15 = new MatchCommon.CustomControls.FTLabel();
            this.ftCmbSattus = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel12 = new MatchCommon.CustomControls.FTLabel();
            this.dateTimePicker7 = new System.Windows.Forms.DateTimePicker();
            this.ftLabel16 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel14 = new MatchCommon.CustomControls.FTLabel();
            this.ftTxtStatus = new MatchCommon.CustomControls.FTTextBox();
            this.ftTxtPoI = new MatchCommon.CustomControls.FTTextBox();
            this.ftComboBox6 = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel31 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel30 = new MatchCommon.CustomControls.FTLabel();
            this.ftComboBox5 = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel29 = new MatchCommon.CustomControls.FTLabel();
            this.ftComboBox4 = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel28 = new MatchCommon.CustomControls.FTLabel();
            this.ftTextBox16 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel27 = new MatchCommon.CustomControls.FTLabel();
            this.ftTextBox15 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox14 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox13 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox12 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel26 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel25 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel24 = new MatchCommon.CustomControls.FTLabel();
            this.lblAddressLine1 = new MatchCommon.CustomControls.FTLabel();
            this.ftTxtMail = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel32 = new MatchCommon.CustomControls.FTLabel();
            this.ftTxtAddress1 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTxtAddress3 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTxtAddress2 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTxtAddress4 = new MatchCommon.CustomControls.FTTextBox();
            this.ftCheckBox1 = new MatchCommon.CustomControls.FTCheckBox();
            this.ftLabel13 = new MatchCommon.CustomControls.FTLabel();
            this.ftComboBox3 = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel10 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel9 = new MatchCommon.CustomControls.FTLabel();
            this.ftComboBox2 = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel8 = new MatchCommon.CustomControls.FTLabel();
            this.ftComboBox1 = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel7 = new MatchCommon.CustomControls.FTLabel();
            this.ftTextBox18 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel6 = new MatchCommon.CustomControls.FTLabel();
            this.ftTextBox11 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox10 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox9 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox8 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel5 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel4 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel3 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel2 = new MatchCommon.CustomControls.FTLabel();
            this.ftTxtMail2 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel1 = new MatchCommon.CustomControls.FTLabel();
            this.ftTxtAddress21 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTxtAddress23 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTxtAddress22 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTxtAddress24 = new MatchCommon.CustomControls.FTTextBox();
            this.tbEntity.SuspendLayout();
            this.tbAccount.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tbOthers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.DocUpload.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.groupBox11.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.SuspendLayout();
            // 
            // ftLabel78
            // 
            this.ftLabel78.AllowForeColorChange = false;
            this.ftLabel78.AutoSize = true;
            this.ftLabel78.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel78.ForeColor = System.Drawing.Color.Black;
            this.ftLabel78.IsMandatory = true;
            this.ftLabel78.Location = new System.Drawing.Point(7, 64);
            this.ftLabel78.Name = "ftLabel78";
            this.ftLabel78.OverrideDefault = false;
            this.ftLabel78.Size = new System.Drawing.Size(36, 12);
            this.ftLabel78.TabIndex = 84;
            this.ftLabel78.Text = "Name*";
            // 
            // tbEntity
            // 
            this.tbEntity.Controls.Add(this.tbAccount);
            this.tbEntity.Controls.Add(this.tbOthers);
            this.tbEntity.Controls.Add(this.DocUpload);
            this.tbEntity.Controls.Add(this.tabPage1);
            this.tbEntity.Controls.Add(this.tabPage2);
            this.tbEntity.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.tbEntity.Location = new System.Drawing.Point(5, 92);
            this.tbEntity.Name = "tbEntity";
            this.tbEntity.SelectedIndex = 0;
            this.tbEntity.Size = new System.Drawing.Size(789, 560);
            this.tbEntity.TabIndex = 83;
            // 
            // tbAccount
            // 
            this.tbAccount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.tbAccount.Controls.Add(this.groupBox3);
            this.tbAccount.Controls.Add(this.groupBox2);
            this.tbAccount.Controls.Add(this.groupBox1);
            this.tbAccount.Location = new System.Drawing.Point(4, 23);
            this.tbAccount.Name = "tbAccount";
            this.tbAccount.Padding = new System.Windows.Forms.Padding(3);
            this.tbAccount.Size = new System.Drawing.Size(781, 533);
            this.tbAccount.TabIndex = 0;
            this.tbAccount.Text = "Account";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.ftTextBox1);
            this.groupBox3.Controls.Add(this.ftTextBox2);
            this.groupBox3.Controls.Add(this.ftTextBox3);
            this.groupBox3.Controls.Add(this.ftTextBox4);
            this.groupBox3.Controls.Add(this.ftLabel17);
            this.groupBox3.Controls.Add(this.ftTextBox5);
            this.groupBox3.Controls.Add(this.ftLabel18);
            this.groupBox3.Controls.Add(this.ftLabel19);
            this.groupBox3.Controls.Add(this.ftLabel20);
            this.groupBox3.Controls.Add(this.ftLabel21);
            this.groupBox3.Controls.Add(this.ftTextBox6);
            this.groupBox3.Controls.Add(this.ftTextBox7);
            this.groupBox3.Controls.Add(this.ftTextBox17);
            this.groupBox3.Controls.Add(this.ftTextBox19);
            this.groupBox3.Controls.Add(this.ftLabel22);
            this.groupBox3.Controls.Add(this.ftTextBox20);
            this.groupBox3.Controls.Add(this.ftLabel23);
            this.groupBox3.Controls.Add(this.ftComboBox7);
            this.groupBox3.Controls.Add(this.ftLabel33);
            this.groupBox3.Controls.Add(this.ftComboBox9);
            this.groupBox3.Controls.Add(this.ftLabel35);
            this.groupBox3.Controls.Add(this.ftLabel36);
            this.groupBox3.Controls.Add(this.ftComboBox10);
            this.groupBox3.Controls.Add(this.ftLabel37);
            this.groupBox3.Controls.Add(this.ftCheckBox2);
            this.groupBox3.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox3.Location = new System.Drawing.Point(14, 338);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(753, 179);
            this.groupBox3.TabIndex = 72;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Registered Address";
            // 
            // ftTextBox1
            // 
            this.ftTextBox1.AllowAlpha = true;
            this.ftTextBox1.AllowDot = false;
            this.ftTextBox1.AllowedCustomCharacters = null;
            this.ftTextBox1.AllowNonASCII = false;
            this.ftTextBox1.AllowNumeric = true;
            this.ftTextBox1.AllowSpace = false;
            this.ftTextBox1.AllowSpecialChars = true;
            this.ftTextBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox1.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox1.IsEmailID = false;
            this.ftTextBox1.IsEmailIdValid = false;
            this.ftTextBox1.Location = new System.Drawing.Point(394, 55);
            this.ftTextBox1.MaxLength = 10;
            this.ftTextBox1.Name = "ftTextBox1";
            this.ftTextBox1.Size = new System.Drawing.Size(353, 20);
            this.ftTextBox1.TabIndex = 83;
            this.ftTextBox1.Tag = "Code";
            // 
            // ftTextBox2
            // 
            this.ftTextBox2.AllowAlpha = true;
            this.ftTextBox2.AllowDot = false;
            this.ftTextBox2.AllowedCustomCharacters = null;
            this.ftTextBox2.AllowNonASCII = false;
            this.ftTextBox2.AllowNumeric = true;
            this.ftTextBox2.AllowSpace = false;
            this.ftTextBox2.AllowSpecialChars = true;
            this.ftTextBox2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox2.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox2.IsEmailID = false;
            this.ftTextBox2.IsEmailIdValid = false;
            this.ftTextBox2.Location = new System.Drawing.Point(394, 24);
            this.ftTextBox2.MaxLength = 10;
            this.ftTextBox2.Name = "ftTextBox2";
            this.ftTextBox2.Size = new System.Drawing.Size(353, 20);
            this.ftTextBox2.TabIndex = 82;
            this.ftTextBox2.Tag = "Code";
            // 
            // ftTextBox3
            // 
            this.ftTextBox3.AllowAlpha = true;
            this.ftTextBox3.AllowDot = false;
            this.ftTextBox3.AllowedCustomCharacters = null;
            this.ftTextBox3.AllowNonASCII = false;
            this.ftTextBox3.AllowNumeric = true;
            this.ftTextBox3.AllowSpace = false;
            this.ftTextBox3.AllowSpecialChars = true;
            this.ftTextBox3.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox3.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox3.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox3.IsEmailID = false;
            this.ftTextBox3.IsEmailIdValid = false;
            this.ftTextBox3.Location = new System.Drawing.Point(51, 54);
            this.ftTextBox3.MaxLength = 10;
            this.ftTextBox3.Name = "ftTextBox3";
            this.ftTextBox3.Size = new System.Drawing.Size(337, 20);
            this.ftTextBox3.TabIndex = 81;
            this.ftTextBox3.Tag = "Code";
            // 
            // ftTextBox4
            // 
            this.ftTextBox4.AllowAlpha = true;
            this.ftTextBox4.AllowDot = false;
            this.ftTextBox4.AllowedCustomCharacters = null;
            this.ftTextBox4.AllowNonASCII = false;
            this.ftTextBox4.AllowNumeric = true;
            this.ftTextBox4.AllowSpace = false;
            this.ftTextBox4.AllowSpecialChars = true;
            this.ftTextBox4.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox4.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox4.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox4.IsEmailID = false;
            this.ftTextBox4.IsEmailIdValid = false;
            this.ftTextBox4.Location = new System.Drawing.Point(51, 23);
            this.ftTextBox4.MaxLength = 10;
            this.ftTextBox4.Name = "ftTextBox4";
            this.ftTextBox4.Size = new System.Drawing.Size(337, 20);
            this.ftTextBox4.TabIndex = 80;
            this.ftTextBox4.Tag = "Code";
            // 
            // ftLabel17
            // 
            this.ftLabel17.AllowForeColorChange = false;
            this.ftLabel17.AutoSize = true;
            this.ftLabel17.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel17.ForeColor = System.Drawing.Color.Black;
            this.ftLabel17.Location = new System.Drawing.Point(4, 87);
            this.ftLabel17.Name = "ftLabel17";
            this.ftLabel17.OverrideDefault = false;
            this.ftLabel17.Size = new System.Drawing.Size(32, 12);
            this.ftLabel17.TabIndex = 79;
            this.ftLabel17.Text = "E-Mail";
            // 
            // ftTextBox5
            // 
            this.ftTextBox5.AllowAlpha = true;
            this.ftTextBox5.AllowDot = false;
            this.ftTextBox5.AllowedCustomCharacters = null;
            this.ftTextBox5.AllowNonASCII = false;
            this.ftTextBox5.AllowNumeric = true;
            this.ftTextBox5.AllowSpace = false;
            this.ftTextBox5.AllowSpecialChars = true;
            this.ftTextBox5.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox5.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox5.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox5.IsEmailID = false;
            this.ftTextBox5.IsEmailIdValid = false;
            this.ftTextBox5.Location = new System.Drawing.Point(51, 84);
            this.ftTextBox5.MaxLength = 10;
            this.ftTextBox5.Name = "ftTextBox5";
            this.ftTextBox5.Size = new System.Drawing.Size(337, 20);
            this.ftTextBox5.TabIndex = 78;
            this.ftTextBox5.Tag = "Code";
            // 
            // ftLabel18
            // 
            this.ftLabel18.AllowForeColorChange = false;
            this.ftLabel18.AutoSize = true;
            this.ftLabel18.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel18.ForeColor = System.Drawing.Color.Black;
            this.ftLabel18.Location = new System.Drawing.Point(5, 26);
            this.ftLabel18.Name = "ftLabel18";
            this.ftLabel18.OverrideDefault = false;
            this.ftLabel18.Size = new System.Drawing.Size(41, 12);
            this.ftLabel18.TabIndex = 73;
            this.ftLabel18.Text = "Address";
            // 
            // ftLabel19
            // 
            this.ftLabel19.AllowForeColorChange = false;
            this.ftLabel19.AutoSize = true;
            this.ftLabel19.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel19.ForeColor = System.Drawing.Color.Black;
            this.ftLabel19.Location = new System.Drawing.Point(602, 149);
            this.ftLabel19.Name = "ftLabel19";
            this.ftLabel19.OverrideDefault = false;
            this.ftLabel19.Size = new System.Drawing.Size(21, 12);
            this.ftLabel19.TabIndex = 72;
            this.ftLabel19.Text = "Fax";
            // 
            // ftLabel20
            // 
            this.ftLabel20.AllowForeColorChange = false;
            this.ftLabel20.AutoSize = true;
            this.ftLabel20.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel20.ForeColor = System.Drawing.Color.Black;
            this.ftLabel20.Location = new System.Drawing.Point(406, 151);
            this.ftLabel20.Name = "ftLabel20";
            this.ftLabel20.OverrideDefault = false;
            this.ftLabel20.Size = new System.Drawing.Size(26, 12);
            this.ftLabel20.TabIndex = 71;
            this.ftLabel20.Text = "Tel.2";
            // 
            // ftLabel21
            // 
            this.ftLabel21.AllowForeColorChange = false;
            this.ftLabel21.AutoSize = true;
            this.ftLabel21.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel21.ForeColor = System.Drawing.Color.Black;
            this.ftLabel21.Location = new System.Drawing.Point(214, 150);
            this.ftLabel21.Name = "ftLabel21";
            this.ftLabel21.OverrideDefault = false;
            this.ftLabel21.Size = new System.Drawing.Size(26, 12);
            this.ftLabel21.TabIndex = 70;
            this.ftLabel21.Text = "Tel.1";
            // 
            // ftTextBox6
            // 
            this.ftTextBox6.AllowAlpha = true;
            this.ftTextBox6.AllowDot = false;
            this.ftTextBox6.AllowedCustomCharacters = null;
            this.ftTextBox6.AllowNonASCII = false;
            this.ftTextBox6.AllowNumeric = true;
            this.ftTextBox6.AllowSpace = false;
            this.ftTextBox6.AllowSpecialChars = true;
            this.ftTextBox6.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox6.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox6.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox6.IsEmailID = false;
            this.ftTextBox6.IsEmailIdValid = false;
            this.ftTextBox6.Location = new System.Drawing.Point(626, 146);
            this.ftTextBox6.MaxLength = 10;
            this.ftTextBox6.Name = "ftTextBox6";
            this.ftTextBox6.Size = new System.Drawing.Size(122, 20);
            this.ftTextBox6.TabIndex = 69;
            this.ftTextBox6.Tag = "Code";
            // 
            // ftTextBox7
            // 
            this.ftTextBox7.AllowAlpha = true;
            this.ftTextBox7.AllowDot = false;
            this.ftTextBox7.AllowedCustomCharacters = null;
            this.ftTextBox7.AllowNonASCII = false;
            this.ftTextBox7.AllowNumeric = true;
            this.ftTextBox7.AllowSpace = false;
            this.ftTextBox7.AllowSpecialChars = true;
            this.ftTextBox7.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox7.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox7.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox7.IsEmailID = false;
            this.ftTextBox7.IsEmailIdValid = false;
            this.ftTextBox7.Location = new System.Drawing.Point(441, 146);
            this.ftTextBox7.MaxLength = 10;
            this.ftTextBox7.Name = "ftTextBox7";
            this.ftTextBox7.Size = new System.Drawing.Size(140, 20);
            this.ftTextBox7.TabIndex = 68;
            this.ftTextBox7.Tag = "Code";
            // 
            // ftTextBox17
            // 
            this.ftTextBox17.AllowAlpha = true;
            this.ftTextBox17.AllowDot = false;
            this.ftTextBox17.AllowedCustomCharacters = null;
            this.ftTextBox17.AllowNonASCII = false;
            this.ftTextBox17.AllowNumeric = true;
            this.ftTextBox17.AllowSpace = false;
            this.ftTextBox17.AllowSpecialChars = true;
            this.ftTextBox17.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox17.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox17.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox17.IsEmailID = false;
            this.ftTextBox17.IsEmailIdValid = false;
            this.ftTextBox17.Location = new System.Drawing.Point(247, 146);
            this.ftTextBox17.MaxLength = 10;
            this.ftTextBox17.Name = "ftTextBox17";
            this.ftTextBox17.Size = new System.Drawing.Size(140, 20);
            this.ftTextBox17.TabIndex = 67;
            this.ftTextBox17.Tag = "Code";
            // 
            // ftTextBox19
            // 
            this.ftTextBox19.AllowAlpha = true;
            this.ftTextBox19.AllowDot = false;
            this.ftTextBox19.AllowedCustomCharacters = null;
            this.ftTextBox19.AllowNonASCII = false;
            this.ftTextBox19.AllowNumeric = true;
            this.ftTextBox19.AllowSpace = false;
            this.ftTextBox19.AllowSpecialChars = true;
            this.ftTextBox19.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox19.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox19.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox19.IsEmailID = false;
            this.ftTextBox19.IsEmailIdValid = false;
            this.ftTextBox19.Location = new System.Drawing.Point(51, 146);
            this.ftTextBox19.MaxLength = 10;
            this.ftTextBox19.Name = "ftTextBox19";
            this.ftTextBox19.Size = new System.Drawing.Size(140, 20);
            this.ftTextBox19.TabIndex = 62;
            this.ftTextBox19.Tag = "Code";
            // 
            // ftLabel22
            // 
            this.ftLabel22.AllowForeColorChange = false;
            this.ftLabel22.AutoSize = true;
            this.ftLabel22.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel22.ForeColor = System.Drawing.Color.Black;
            this.ftLabel22.Location = new System.Drawing.Point(4, 150);
            this.ftLabel22.Name = "ftLabel22";
            this.ftLabel22.OverrideDefault = false;
            this.ftLabel22.Size = new System.Drawing.Size(34, 12);
            this.ftLabel22.TabIndex = 66;
            this.ftLabel22.Text = "Mobile";
            // 
            // ftTextBox20
            // 
            this.ftTextBox20.AllowAlpha = true;
            this.ftTextBox20.AllowDot = false;
            this.ftTextBox20.AllowedCustomCharacters = null;
            this.ftTextBox20.AllowNonASCII = false;
            this.ftTextBox20.AllowNumeric = true;
            this.ftTextBox20.AllowSpace = false;
            this.ftTextBox20.AllowSpecialChars = true;
            this.ftTextBox20.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox20.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox20.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox20.IsEmailID = false;
            this.ftTextBox20.IsEmailIdValid = false;
            this.ftTextBox20.Location = new System.Drawing.Point(626, 114);
            this.ftTextBox20.MaxLength = 10;
            this.ftTextBox20.Name = "ftTextBox20";
            this.ftTextBox20.Size = new System.Drawing.Size(122, 20);
            this.ftTextBox20.TabIndex = 59;
            this.ftTextBox20.Tag = "Code";
            // 
            // ftLabel23
            // 
            this.ftLabel23.AllowForeColorChange = false;
            this.ftLabel23.AutoSize = true;
            this.ftLabel23.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel23.ForeColor = System.Drawing.Color.Black;
            this.ftLabel23.Location = new System.Drawing.Point(598, 118);
            this.ftLabel23.Name = "ftLabel23";
            this.ftLabel23.OverrideDefault = false;
            this.ftLabel23.Size = new System.Drawing.Size(22, 12);
            this.ftLabel23.TabIndex = 65;
            this.ftLabel23.Text = "PIN";
            // 
            // ftComboBox7
            // 
            this.ftComboBox7.BackColor = System.Drawing.Color.White;
            this.ftComboBox7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftComboBox7.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftComboBox7.ForeColor = System.Drawing.Color.Black;
            this.ftComboBox7.FormattingEnabled = true;
            this.ftComboBox7.Location = new System.Drawing.Point(441, 115);
            this.ftComboBox7.Name = "ftComboBox7";
            this.ftComboBox7.ReadOnly = false;
            this.ftComboBox7.Size = new System.Drawing.Size(140, 20);
            this.ftComboBox7.TabIndex = 63;
            // 
            // ftLabel33
            // 
            this.ftLabel33.AllowForeColorChange = false;
            this.ftLabel33.AutoSize = true;
            this.ftLabel33.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel33.ForeColor = System.Drawing.Color.Black;
            this.ftLabel33.Location = new System.Drawing.Point(406, 118);
            this.ftLabel33.Name = "ftLabel33";
            this.ftLabel33.OverrideDefault = false;
            this.ftLabel33.Size = new System.Drawing.Size(23, 12);
            this.ftLabel33.TabIndex = 64;
            this.ftLabel33.Text = "City";
            // 
            // ftComboBox9
            // 
            this.ftComboBox9.BackColor = System.Drawing.Color.White;
            this.ftComboBox9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftComboBox9.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftComboBox9.ForeColor = System.Drawing.Color.Black;
            this.ftComboBox9.FormattingEnabled = true;
            this.ftComboBox9.Location = new System.Drawing.Point(247, 115);
            this.ftComboBox9.Name = "ftComboBox9";
            this.ftComboBox9.ReadOnly = false;
            this.ftComboBox9.Size = new System.Drawing.Size(140, 20);
            this.ftComboBox9.TabIndex = 58;
            // 
            // ftLabel35
            // 
            this.ftLabel35.AllowForeColorChange = false;
            this.ftLabel35.AutoSize = true;
            this.ftLabel35.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel35.ForeColor = System.Drawing.Color.Black;
            this.ftLabel35.Location = new System.Drawing.Point(214, 118);
            this.ftLabel35.Name = "ftLabel35";
            this.ftLabel35.OverrideDefault = false;
            this.ftLabel35.Size = new System.Drawing.Size(27, 12);
            this.ftLabel35.TabIndex = 61;
            this.ftLabel35.Text = "State";
            // 
            // ftLabel36
            // 
            this.ftLabel36.AllowForeColorChange = false;
            this.ftLabel36.AutoSize = true;
            this.ftLabel36.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel36.ForeColor = System.Drawing.Color.Black;
            this.ftLabel36.Location = new System.Drawing.Point(5, 118);
            this.ftLabel36.Name = "ftLabel36";
            this.ftLabel36.OverrideDefault = false;
            this.ftLabel36.Size = new System.Drawing.Size(43, 12);
            this.ftLabel36.TabIndex = 60;
            this.ftLabel36.Text = "Country";
            // 
            // ftComboBox10
            // 
            this.ftComboBox10.BackColor = System.Drawing.Color.White;
            this.ftComboBox10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftComboBox10.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftComboBox10.ForeColor = System.Drawing.Color.Black;
            this.ftComboBox10.FormattingEnabled = true;
            this.ftComboBox10.Location = new System.Drawing.Point(51, 115);
            this.ftComboBox10.Name = "ftComboBox10";
            this.ftComboBox10.ReadOnly = false;
            this.ftComboBox10.Size = new System.Drawing.Size(140, 20);
            this.ftComboBox10.TabIndex = 57;
            // 
            // ftLabel37
            // 
            this.ftLabel37.AllowForeColorChange = false;
            this.ftLabel37.AutoSize = true;
            this.ftLabel37.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel37.ForeColor = System.Drawing.Color.Black;
            this.ftLabel37.Location = new System.Drawing.Point(223, 0);
            this.ftLabel37.Name = "ftLabel37";
            this.ftLabel37.OverrideDefault = false;
            this.ftLabel37.Size = new System.Drawing.Size(72, 12);
            this.ftLabel37.TabIndex = 47;
            this.ftLabel37.Text = "Same as above";
            // 
            // ftCheckBox2
            // 
            this.ftCheckBox2.AutoSize = true;
            this.ftCheckBox2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftCheckBox2.ForeColor = System.Drawing.Color.Black;
            this.ftCheckBox2.Location = new System.Drawing.Point(206, 0);
            this.ftCheckBox2.Name = "ftCheckBox2";
            this.ftCheckBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ftCheckBox2.Size = new System.Drawing.Size(15, 14);
            this.ftCheckBox2.TabIndex = 41;
            this.ftCheckBox2.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ftTextBox21);
            this.groupBox2.Controls.Add(this.ftTextBox22);
            this.groupBox2.Controls.Add(this.ftTextBox23);
            this.groupBox2.Controls.Add(this.ftTextBox24);
            this.groupBox2.Controls.Add(this.ftLabel38);
            this.groupBox2.Controls.Add(this.ftTextBox28);
            this.groupBox2.Controls.Add(this.ftLabel48);
            this.groupBox2.Controls.Add(this.ftLabel49);
            this.groupBox2.Controls.Add(this.ftLabel50);
            this.groupBox2.Controls.Add(this.ftLabel51);
            this.groupBox2.Controls.Add(this.ftTextBox29);
            this.groupBox2.Controls.Add(this.ftTextBox30);
            this.groupBox2.Controls.Add(this.ftTextBox31);
            this.groupBox2.Controls.Add(this.ftTextBox32);
            this.groupBox2.Controls.Add(this.ftLabel52);
            this.groupBox2.Controls.Add(this.ftTextBox33);
            this.groupBox2.Controls.Add(this.ftLabel55);
            this.groupBox2.Controls.Add(this.ftComboBox11);
            this.groupBox2.Controls.Add(this.ftLabel56);
            this.groupBox2.Controls.Add(this.ftComboBox12);
            this.groupBox2.Controls.Add(this.ftLabel57);
            this.groupBox2.Controls.Add(this.ftLabel58);
            this.groupBox2.Controls.Add(this.ftComboBox13);
            this.groupBox2.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox2.Location = new System.Drawing.Point(14, 144);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(753, 181);
            this.groupBox2.TabIndex = 71;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Correspondence Address";
            // 
            // ftTextBox21
            // 
            this.ftTextBox21.AllowAlpha = true;
            this.ftTextBox21.AllowDot = false;
            this.ftTextBox21.AllowedCustomCharacters = null;
            this.ftTextBox21.AllowNonASCII = false;
            this.ftTextBox21.AllowNumeric = true;
            this.ftTextBox21.AllowSpace = false;
            this.ftTextBox21.AllowSpecialChars = true;
            this.ftTextBox21.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox21.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox21.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox21.IsEmailID = false;
            this.ftTextBox21.IsEmailIdValid = false;
            this.ftTextBox21.Location = new System.Drawing.Point(392, 56);
            this.ftTextBox21.MaxLength = 10;
            this.ftTextBox21.Name = "ftTextBox21";
            this.ftTextBox21.Size = new System.Drawing.Size(353, 20);
            this.ftTextBox21.TabIndex = 60;
            this.ftTextBox21.Tag = "Code";
            // 
            // ftTextBox22
            // 
            this.ftTextBox22.AllowAlpha = true;
            this.ftTextBox22.AllowDot = false;
            this.ftTextBox22.AllowedCustomCharacters = null;
            this.ftTextBox22.AllowNonASCII = false;
            this.ftTextBox22.AllowNumeric = true;
            this.ftTextBox22.AllowSpace = false;
            this.ftTextBox22.AllowSpecialChars = true;
            this.ftTextBox22.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox22.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox22.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox22.IsEmailID = false;
            this.ftTextBox22.IsEmailIdValid = false;
            this.ftTextBox22.Location = new System.Drawing.Point(392, 25);
            this.ftTextBox22.MaxLength = 10;
            this.ftTextBox22.Name = "ftTextBox22";
            this.ftTextBox22.Size = new System.Drawing.Size(353, 20);
            this.ftTextBox22.TabIndex = 59;
            this.ftTextBox22.Tag = "Code";
            // 
            // ftTextBox23
            // 
            this.ftTextBox23.AllowAlpha = true;
            this.ftTextBox23.AllowDot = false;
            this.ftTextBox23.AllowedCustomCharacters = null;
            this.ftTextBox23.AllowNonASCII = false;
            this.ftTextBox23.AllowNumeric = true;
            this.ftTextBox23.AllowSpace = false;
            this.ftTextBox23.AllowSpecialChars = true;
            this.ftTextBox23.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox23.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox23.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox23.IsEmailID = false;
            this.ftTextBox23.IsEmailIdValid = false;
            this.ftTextBox23.Location = new System.Drawing.Point(49, 56);
            this.ftTextBox23.MaxLength = 10;
            this.ftTextBox23.Name = "ftTextBox23";
            this.ftTextBox23.Size = new System.Drawing.Size(337, 20);
            this.ftTextBox23.TabIndex = 58;
            this.ftTextBox23.Tag = "Code";
            // 
            // ftTextBox24
            // 
            this.ftTextBox24.AllowAlpha = true;
            this.ftTextBox24.AllowDot = false;
            this.ftTextBox24.AllowedCustomCharacters = null;
            this.ftTextBox24.AllowNonASCII = false;
            this.ftTextBox24.AllowNumeric = true;
            this.ftTextBox24.AllowSpace = false;
            this.ftTextBox24.AllowSpecialChars = true;
            this.ftTextBox24.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox24.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox24.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox24.IsEmailID = false;
            this.ftTextBox24.IsEmailIdValid = false;
            this.ftTextBox24.Location = new System.Drawing.Point(49, 25);
            this.ftTextBox24.MaxLength = 10;
            this.ftTextBox24.Name = "ftTextBox24";
            this.ftTextBox24.Size = new System.Drawing.Size(337, 20);
            this.ftTextBox24.TabIndex = 57;
            this.ftTextBox24.Tag = "Code";
            // 
            // ftLabel38
            // 
            this.ftLabel38.AllowForeColorChange = false;
            this.ftLabel38.AutoSize = true;
            this.ftLabel38.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel38.ForeColor = System.Drawing.Color.Black;
            this.ftLabel38.Location = new System.Drawing.Point(2, 90);
            this.ftLabel38.Name = "ftLabel38";
            this.ftLabel38.OverrideDefault = false;
            this.ftLabel38.Size = new System.Drawing.Size(32, 12);
            this.ftLabel38.TabIndex = 56;
            this.ftLabel38.Text = "E-Mail";
            // 
            // ftTextBox28
            // 
            this.ftTextBox28.AllowAlpha = true;
            this.ftTextBox28.AllowDot = false;
            this.ftTextBox28.AllowedCustomCharacters = null;
            this.ftTextBox28.AllowNonASCII = false;
            this.ftTextBox28.AllowNumeric = true;
            this.ftTextBox28.AllowSpace = false;
            this.ftTextBox28.AllowSpecialChars = true;
            this.ftTextBox28.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox28.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox28.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox28.IsEmailID = false;
            this.ftTextBox28.IsEmailIdValid = false;
            this.ftTextBox28.Location = new System.Drawing.Point(49, 87);
            this.ftTextBox28.MaxLength = 10;
            this.ftTextBox28.Name = "ftTextBox28";
            this.ftTextBox28.Size = new System.Drawing.Size(337, 20);
            this.ftTextBox28.TabIndex = 55;
            this.ftTextBox28.Tag = "Code";
            // 
            // ftLabel48
            // 
            this.ftLabel48.AllowForeColorChange = false;
            this.ftLabel48.AutoSize = true;
            this.ftLabel48.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel48.ForeColor = System.Drawing.Color.Black;
            this.ftLabel48.Location = new System.Drawing.Point(3, 29);
            this.ftLabel48.Name = "ftLabel48";
            this.ftLabel48.OverrideDefault = false;
            this.ftLabel48.Size = new System.Drawing.Size(41, 12);
            this.ftLabel48.TabIndex = 50;
            this.ftLabel48.Text = "Address";
            // 
            // ftLabel49
            // 
            this.ftLabel49.AllowForeColorChange = false;
            this.ftLabel49.AutoSize = true;
            this.ftLabel49.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel49.ForeColor = System.Drawing.Color.Black;
            this.ftLabel49.Location = new System.Drawing.Point(600, 152);
            this.ftLabel49.Name = "ftLabel49";
            this.ftLabel49.OverrideDefault = false;
            this.ftLabel49.Size = new System.Drawing.Size(21, 12);
            this.ftLabel49.TabIndex = 49;
            this.ftLabel49.Text = "Fax";
            // 
            // ftLabel50
            // 
            this.ftLabel50.AllowForeColorChange = false;
            this.ftLabel50.AutoSize = true;
            this.ftLabel50.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel50.ForeColor = System.Drawing.Color.Black;
            this.ftLabel50.Location = new System.Drawing.Point(404, 154);
            this.ftLabel50.Name = "ftLabel50";
            this.ftLabel50.OverrideDefault = false;
            this.ftLabel50.Size = new System.Drawing.Size(26, 12);
            this.ftLabel50.TabIndex = 48;
            this.ftLabel50.Text = "Tel.2";
            // 
            // ftLabel51
            // 
            this.ftLabel51.AllowForeColorChange = false;
            this.ftLabel51.AutoSize = true;
            this.ftLabel51.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel51.ForeColor = System.Drawing.Color.Black;
            this.ftLabel51.Location = new System.Drawing.Point(212, 153);
            this.ftLabel51.Name = "ftLabel51";
            this.ftLabel51.OverrideDefault = false;
            this.ftLabel51.Size = new System.Drawing.Size(26, 12);
            this.ftLabel51.TabIndex = 47;
            this.ftLabel51.Text = "Tel.1";
            // 
            // ftTextBox29
            // 
            this.ftTextBox29.AllowAlpha = true;
            this.ftTextBox29.AllowDot = false;
            this.ftTextBox29.AllowedCustomCharacters = null;
            this.ftTextBox29.AllowNonASCII = false;
            this.ftTextBox29.AllowNumeric = true;
            this.ftTextBox29.AllowSpace = false;
            this.ftTextBox29.AllowSpecialChars = true;
            this.ftTextBox29.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox29.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox29.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox29.IsEmailID = false;
            this.ftTextBox29.IsEmailIdValid = false;
            this.ftTextBox29.Location = new System.Drawing.Point(624, 149);
            this.ftTextBox29.MaxLength = 10;
            this.ftTextBox29.Name = "ftTextBox29";
            this.ftTextBox29.Size = new System.Drawing.Size(122, 20);
            this.ftTextBox29.TabIndex = 41;
            this.ftTextBox29.Tag = "Code";
            // 
            // ftTextBox30
            // 
            this.ftTextBox30.AllowAlpha = true;
            this.ftTextBox30.AllowDot = false;
            this.ftTextBox30.AllowedCustomCharacters = null;
            this.ftTextBox30.AllowNonASCII = false;
            this.ftTextBox30.AllowNumeric = true;
            this.ftTextBox30.AllowSpace = false;
            this.ftTextBox30.AllowSpecialChars = true;
            this.ftTextBox30.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox30.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox30.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox30.IsEmailID = false;
            this.ftTextBox30.IsEmailIdValid = false;
            this.ftTextBox30.Location = new System.Drawing.Point(439, 149);
            this.ftTextBox30.MaxLength = 10;
            this.ftTextBox30.Name = "ftTextBox30";
            this.ftTextBox30.Size = new System.Drawing.Size(140, 20);
            this.ftTextBox30.TabIndex = 39;
            this.ftTextBox30.Tag = "Code";
            // 
            // ftTextBox31
            // 
            this.ftTextBox31.AllowAlpha = true;
            this.ftTextBox31.AllowDot = false;
            this.ftTextBox31.AllowedCustomCharacters = null;
            this.ftTextBox31.AllowNonASCII = false;
            this.ftTextBox31.AllowNumeric = true;
            this.ftTextBox31.AllowSpace = false;
            this.ftTextBox31.AllowSpecialChars = true;
            this.ftTextBox31.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox31.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox31.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox31.IsEmailID = false;
            this.ftTextBox31.IsEmailIdValid = false;
            this.ftTextBox31.Location = new System.Drawing.Point(245, 149);
            this.ftTextBox31.MaxLength = 10;
            this.ftTextBox31.Name = "ftTextBox31";
            this.ftTextBox31.Size = new System.Drawing.Size(140, 20);
            this.ftTextBox31.TabIndex = 37;
            this.ftTextBox31.Tag = "Code";
            // 
            // ftTextBox32
            // 
            this.ftTextBox32.AllowAlpha = true;
            this.ftTextBox32.AllowDot = false;
            this.ftTextBox32.AllowedCustomCharacters = null;
            this.ftTextBox32.AllowNonASCII = false;
            this.ftTextBox32.AllowNumeric = true;
            this.ftTextBox32.AllowSpace = false;
            this.ftTextBox32.AllowSpecialChars = true;
            this.ftTextBox32.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox32.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox32.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox32.IsEmailID = false;
            this.ftTextBox32.IsEmailIdValid = false;
            this.ftTextBox32.Location = new System.Drawing.Point(49, 149);
            this.ftTextBox32.MaxLength = 10;
            this.ftTextBox32.Name = "ftTextBox32";
            this.ftTextBox32.Size = new System.Drawing.Size(140, 20);
            this.ftTextBox32.TabIndex = 32;
            this.ftTextBox32.Tag = "Code";
            // 
            // ftLabel52
            // 
            this.ftLabel52.AllowForeColorChange = false;
            this.ftLabel52.AutoSize = true;
            this.ftLabel52.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel52.ForeColor = System.Drawing.Color.Black;
            this.ftLabel52.Location = new System.Drawing.Point(2, 153);
            this.ftLabel52.Name = "ftLabel52";
            this.ftLabel52.OverrideDefault = false;
            this.ftLabel52.Size = new System.Drawing.Size(34, 12);
            this.ftLabel52.TabIndex = 36;
            this.ftLabel52.Text = "Mobile";
            // 
            // ftTextBox33
            // 
            this.ftTextBox33.AllowAlpha = true;
            this.ftTextBox33.AllowDot = false;
            this.ftTextBox33.AllowedCustomCharacters = null;
            this.ftTextBox33.AllowNonASCII = false;
            this.ftTextBox33.AllowNumeric = true;
            this.ftTextBox33.AllowSpace = false;
            this.ftTextBox33.AllowSpecialChars = true;
            this.ftTextBox33.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox33.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox33.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox33.IsEmailID = false;
            this.ftTextBox33.IsEmailIdValid = false;
            this.ftTextBox33.Location = new System.Drawing.Point(624, 117);
            this.ftTextBox33.MaxLength = 10;
            this.ftTextBox33.Name = "ftTextBox33";
            this.ftTextBox33.Size = new System.Drawing.Size(122, 20);
            this.ftTextBox33.TabIndex = 31;
            this.ftTextBox33.Tag = "Code";
            // 
            // ftLabel55
            // 
            this.ftLabel55.AllowForeColorChange = false;
            this.ftLabel55.AutoSize = true;
            this.ftLabel55.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel55.ForeColor = System.Drawing.Color.Black;
            this.ftLabel55.Location = new System.Drawing.Point(596, 121);
            this.ftLabel55.Name = "ftLabel55";
            this.ftLabel55.OverrideDefault = false;
            this.ftLabel55.Size = new System.Drawing.Size(22, 12);
            this.ftLabel55.TabIndex = 35;
            this.ftLabel55.Text = "PIN";
            // 
            // ftComboBox11
            // 
            this.ftComboBox11.BackColor = System.Drawing.Color.White;
            this.ftComboBox11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftComboBox11.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftComboBox11.ForeColor = System.Drawing.Color.Black;
            this.ftComboBox11.FormattingEnabled = true;
            this.ftComboBox11.Location = new System.Drawing.Point(439, 118);
            this.ftComboBox11.Name = "ftComboBox11";
            this.ftComboBox11.ReadOnly = false;
            this.ftComboBox11.Size = new System.Drawing.Size(140, 20);
            this.ftComboBox11.TabIndex = 33;
            // 
            // ftLabel56
            // 
            this.ftLabel56.AllowForeColorChange = false;
            this.ftLabel56.AutoSize = true;
            this.ftLabel56.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel56.ForeColor = System.Drawing.Color.Black;
            this.ftLabel56.Location = new System.Drawing.Point(404, 121);
            this.ftLabel56.Name = "ftLabel56";
            this.ftLabel56.OverrideDefault = false;
            this.ftLabel56.Size = new System.Drawing.Size(23, 12);
            this.ftLabel56.TabIndex = 34;
            this.ftLabel56.Text = "City";
            // 
            // ftComboBox12
            // 
            this.ftComboBox12.BackColor = System.Drawing.Color.White;
            this.ftComboBox12.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftComboBox12.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftComboBox12.ForeColor = System.Drawing.Color.Black;
            this.ftComboBox12.FormattingEnabled = true;
            this.ftComboBox12.Location = new System.Drawing.Point(245, 118);
            this.ftComboBox12.Name = "ftComboBox12";
            this.ftComboBox12.ReadOnly = false;
            this.ftComboBox12.Size = new System.Drawing.Size(140, 20);
            this.ftComboBox12.TabIndex = 31;
            // 
            // ftLabel57
            // 
            this.ftLabel57.AllowForeColorChange = false;
            this.ftLabel57.AutoSize = true;
            this.ftLabel57.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel57.ForeColor = System.Drawing.Color.Black;
            this.ftLabel57.Location = new System.Drawing.Point(212, 121);
            this.ftLabel57.Name = "ftLabel57";
            this.ftLabel57.OverrideDefault = false;
            this.ftLabel57.Size = new System.Drawing.Size(27, 12);
            this.ftLabel57.TabIndex = 32;
            this.ftLabel57.Text = "State";
            // 
            // ftLabel58
            // 
            this.ftLabel58.AllowForeColorChange = false;
            this.ftLabel58.AutoSize = true;
            this.ftLabel58.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel58.ForeColor = System.Drawing.Color.Black;
            this.ftLabel58.Location = new System.Drawing.Point(3, 121);
            this.ftLabel58.Name = "ftLabel58";
            this.ftLabel58.OverrideDefault = false;
            this.ftLabel58.Size = new System.Drawing.Size(43, 12);
            this.ftLabel58.TabIndex = 31;
            this.ftLabel58.Text = "Country";
            // 
            // ftComboBox13
            // 
            this.ftComboBox13.BackColor = System.Drawing.Color.White;
            this.ftComboBox13.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftComboBox13.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftComboBox13.ForeColor = System.Drawing.Color.Black;
            this.ftComboBox13.FormattingEnabled = true;
            this.ftComboBox13.Location = new System.Drawing.Point(49, 118);
            this.ftComboBox13.Name = "ftComboBox13";
            this.ftComboBox13.ReadOnly = false;
            this.ftComboBox13.Size = new System.Drawing.Size(140, 20);
            this.ftComboBox13.TabIndex = 29;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtStatus);
            this.groupBox1.Controls.Add(this.ftLabel63);
            this.groupBox1.Controls.Add(this.ftCmbStatus);
            this.groupBox1.Controls.Add(this.txtPAN);
            this.groupBox1.Controls.Add(this.ftLabel62);
            this.groupBox1.Controls.Add(this.dateTimePicker9);
            this.groupBox1.Controls.Add(this.ftLabel61);
            this.groupBox1.Controls.Add(this.ftTxtCINNo);
            this.groupBox1.Controls.Add(this.ftLabel60);
            this.groupBox1.Controls.Add(this.ftLabel59);
            this.groupBox1.Controls.Add(this.ftTextBox34);
            this.groupBox1.Controls.Add(this.ftCreated);
            this.groupBox1.Controls.Add(this.dateTimePicker8);
            this.groupBox1.Controls.Add(this.dateTimePicker2);
            this.groupBox1.Controls.Add(this.ftlblDOB);
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox1.Location = new System.Drawing.Point(14, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(753, 125);
            this.groupBox1.TabIndex = 46;
            this.groupBox1.TabStop = false;
            // 
            // txtStatus
            // 
            this.txtStatus.AllowAlpha = true;
            this.txtStatus.AllowDot = false;
            this.txtStatus.AllowedCustomCharacters = null;
            this.txtStatus.AllowNonASCII = false;
            this.txtStatus.AllowNumeric = true;
            this.txtStatus.AllowSpace = false;
            this.txtStatus.AllowSpecialChars = true;
            this.txtStatus.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtStatus.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtStatus.ForeColor = System.Drawing.Color.Black;
            this.txtStatus.IsEmailID = false;
            this.txtStatus.IsEmailIdValid = false;
            this.txtStatus.Location = new System.Drawing.Point(206, 87);
            this.txtStatus.MaxLength = 10;
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(538, 20);
            this.txtStatus.TabIndex = 86;
            this.txtStatus.Tag = "Code";
            // 
            // ftLabel63
            // 
            this.ftLabel63.AllowForeColorChange = false;
            this.ftLabel63.AutoSize = true;
            this.ftLabel63.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel63.ForeColor = System.Drawing.Color.Black;
            this.ftLabel63.Location = new System.Drawing.Point(6, 90);
            this.ftLabel63.Name = "ftLabel63";
            this.ftLabel63.OverrideDefault = false;
            this.ftLabel63.Size = new System.Drawing.Size(32, 12);
            this.ftLabel63.TabIndex = 85;
            this.ftLabel63.Text = "Status";
            // 
            // ftCmbStatus
            // 
            this.ftCmbStatus.BackColor = System.Drawing.Color.White;
            this.ftCmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftCmbStatus.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftCmbStatus.ForeColor = System.Drawing.Color.Black;
            this.ftCmbStatus.FormattingEnabled = true;
            this.ftCmbStatus.Location = new System.Drawing.Point(49, 87);
            this.ftCmbStatus.Name = "ftCmbStatus";
            this.ftCmbStatus.ReadOnly = false;
            this.ftCmbStatus.Size = new System.Drawing.Size(140, 20);
            this.ftCmbStatus.TabIndex = 84;
            // 
            // txtPAN
            // 
            this.txtPAN.AllowAlpha = true;
            this.txtPAN.AllowDot = false;
            this.txtPAN.AllowedCustomCharacters = null;
            this.txtPAN.AllowNonASCII = false;
            this.txtPAN.AllowNumeric = true;
            this.txtPAN.AllowSpace = false;
            this.txtPAN.AllowSpecialChars = true;
            this.txtPAN.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPAN.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtPAN.ForeColor = System.Drawing.Color.Black;
            this.txtPAN.IsEmailID = false;
            this.txtPAN.IsEmailIdValid = false;
            this.txtPAN.Location = new System.Drawing.Point(624, 55);
            this.txtPAN.MaxLength = 10;
            this.txtPAN.Name = "txtPAN";
            this.txtPAN.Size = new System.Drawing.Size(120, 20);
            this.txtPAN.TabIndex = 83;
            this.txtPAN.Tag = "Code";
            // 
            // ftLabel62
            // 
            this.ftLabel62.AllowForeColorChange = false;
            this.ftLabel62.AutoSize = true;
            this.ftLabel62.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel62.ForeColor = System.Drawing.Color.Black;
            this.ftLabel62.Location = new System.Drawing.Point(573, 61);
            this.ftLabel62.Name = "ftLabel62";
            this.ftLabel62.OverrideDefault = false;
            this.ftLabel62.Size = new System.Drawing.Size(25, 12);
            this.ftLabel62.TabIndex = 82;
            this.ftLabel62.Text = "PAN";
            // 
            // dateTimePicker9
            // 
            this.dateTimePicker9.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker9.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker9.Location = new System.Drawing.Point(307, 53);
            this.dateTimePicker9.Name = "dateTimePicker9";
            this.dateTimePicker9.Size = new System.Drawing.Size(140, 21);
            this.dateTimePicker9.TabIndex = 81;
            // 
            // ftLabel61
            // 
            this.ftLabel61.AllowForeColorChange = false;
            this.ftLabel61.AutoSize = true;
            this.ftLabel61.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel61.ForeColor = System.Drawing.Color.Black;
            this.ftLabel61.Location = new System.Drawing.Point(204, 58);
            this.ftLabel61.Name = "ftLabel61";
            this.ftLabel61.OverrideDefault = false;
            this.ftLabel61.Size = new System.Drawing.Size(77, 12);
            this.ftLabel61.TabIndex = 80;
            this.ftLabel61.Text = "Commencement";
            // 
            // ftTxtCINNo
            // 
            this.ftTxtCINNo.AllowAlpha = true;
            this.ftTxtCINNo.AllowDot = false;
            this.ftTxtCINNo.AllowedCustomCharacters = null;
            this.ftTxtCINNo.AllowNonASCII = false;
            this.ftTxtCINNo.AllowNumeric = true;
            this.ftTxtCINNo.AllowSpace = false;
            this.ftTxtCINNo.AllowSpecialChars = true;
            this.ftTxtCINNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtCINNo.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtCINNo.ForeColor = System.Drawing.Color.Black;
            this.ftTxtCINNo.IsEmailID = false;
            this.ftTxtCINNo.IsEmailIdValid = false;
            this.ftTxtCINNo.Location = new System.Drawing.Point(49, 55);
            this.ftTxtCINNo.MaxLength = 10;
            this.ftTxtCINNo.Name = "ftTxtCINNo";
            this.ftTxtCINNo.Size = new System.Drawing.Size(140, 20);
            this.ftTxtCINNo.TabIndex = 79;
            this.ftTxtCINNo.Tag = "Code";
            // 
            // ftLabel60
            // 
            this.ftLabel60.AllowForeColorChange = false;
            this.ftLabel60.AutoSize = true;
            this.ftLabel60.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel60.ForeColor = System.Drawing.Color.Black;
            this.ftLabel60.Location = new System.Drawing.Point(6, 58);
            this.ftLabel60.Name = "ftLabel60";
            this.ftLabel60.OverrideDefault = false;
            this.ftLabel60.Size = new System.Drawing.Size(23, 12);
            this.ftLabel60.TabIndex = 78;
            this.ftLabel60.Text = "CIN";
            // 
            // ftLabel59
            // 
            this.ftLabel59.AllowForeColorChange = false;
            this.ftLabel59.AutoSize = true;
            this.ftLabel59.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel59.ForeColor = System.Drawing.Color.Black;
            this.ftLabel59.Location = new System.Drawing.Point(204, 27);
            this.ftLabel59.Name = "ftLabel59";
            this.ftLabel59.OverrideDefault = false;
            this.ftLabel59.Size = new System.Drawing.Size(97, 12);
            this.ftLabel59.TabIndex = 77;
            this.ftLabel59.Text = "Place of Incorporate";
            // 
            // ftTextBox34
            // 
            this.ftTextBox34.AllowAlpha = true;
            this.ftTextBox34.AllowDot = false;
            this.ftTextBox34.AllowedCustomCharacters = null;
            this.ftTextBox34.AllowNonASCII = false;
            this.ftTextBox34.AllowNumeric = true;
            this.ftTextBox34.AllowSpace = false;
            this.ftTextBox34.AllowSpecialChars = true;
            this.ftTextBox34.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox34.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox34.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox34.IsEmailID = false;
            this.ftTextBox34.IsEmailIdValid = false;
            this.ftTextBox34.Location = new System.Drawing.Point(307, 22);
            this.ftTextBox34.MaxLength = 10;
            this.ftTextBox34.Name = "ftTextBox34";
            this.ftTextBox34.Size = new System.Drawing.Size(260, 20);
            this.ftTextBox34.TabIndex = 76;
            this.ftTextBox34.Tag = "Code";
            // 
            // ftCreated
            // 
            this.ftCreated.AllowForeColorChange = false;
            this.ftCreated.AutoSize = true;
            this.ftCreated.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftCreated.ForeColor = System.Drawing.Color.Black;
            this.ftCreated.Location = new System.Drawing.Point(573, 28);
            this.ftCreated.Name = "ftCreated";
            this.ftCreated.OverrideDefault = false;
            this.ftCreated.Size = new System.Drawing.Size(40, 12);
            this.ftCreated.TabIndex = 75;
            this.ftCreated.Text = "Created";
            // 
            // dateTimePicker8
            // 
            this.dateTimePicker8.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker8.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker8.Location = new System.Drawing.Point(624, 22);
            this.dateTimePicker8.Name = "dateTimePicker8";
            this.dateTimePicker8.Size = new System.Drawing.Size(120, 21);
            this.dateTimePicker8.TabIndex = 74;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(49, 22);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(140, 21);
            this.dateTimePicker2.TabIndex = 73;
            // 
            // ftlblDOB
            // 
            this.ftlblDOB.AllowForeColorChange = false;
            this.ftlblDOB.AutoSize = true;
            this.ftlblDOB.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftlblDOB.ForeColor = System.Drawing.Color.Black;
            this.ftlblDOB.Location = new System.Drawing.Point(5, 28);
            this.ftlblDOB.Name = "ftlblDOB";
            this.ftlblDOB.OverrideDefault = false;
            this.ftlblDOB.Size = new System.Drawing.Size(24, 12);
            this.ftlblDOB.TabIndex = 72;
            this.ftlblDOB.Text = "DOI";
            // 
            // tbOthers
            // 
            this.tbOthers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.tbOthers.Controls.Add(this.dataGridView3);
            this.tbOthers.Controls.Add(this.ftLabel74);
            this.tbOthers.Controls.Add(this.textBox2);
            this.tbOthers.Controls.Add(this.groupBox4);
            this.tbOthers.Controls.Add(this.ftLabel53);
            this.tbOthers.Location = new System.Drawing.Point(4, 23);
            this.tbOthers.Name = "tbOthers";
            this.tbOthers.Padding = new System.Windows.Forms.Padding(3);
            this.tbOthers.Size = new System.Drawing.Size(781, 533);
            this.tbOthers.TabIndex = 2;
            this.tbOthers.Text = "Authorised Signatories";
            // 
            // dataGridView3
            // 
            this.dataGridView3.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView3.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.Relationship,
            this.Address});
            this.dataGridView3.Location = new System.Drawing.Point(7, 6);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersVisible = false;
            this.dataGridView3.Size = new System.Drawing.Size(760, 235);
            this.dataGridView3.TabIndex = 87;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Cust Id";
            this.dataGridViewTextBoxColumn5.MaxInputLength = 20;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Name";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 260;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "DIN";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // Relationship
            // 
            this.Relationship.HeaderText = "Relationship";
            this.Relationship.Name = "Relationship";
            // 
            // Address
            // 
            this.Address.HeaderText = "Address";
            this.Address.Name = "Address";
            this.Address.Width = 200;
            // 
            // ftLabel74
            // 
            this.ftLabel74.AllowForeColorChange = false;
            this.ftLabel74.AutoSize = true;
            this.ftLabel74.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel74.ForeColor = System.Drawing.Color.Black;
            this.ftLabel74.Location = new System.Drawing.Point(9, 260);
            this.ftLabel74.Name = "ftLabel74";
            this.ftLabel74.OverrideDefault = false;
            this.ftLabel74.Size = new System.Drawing.Size(30, 12);
            this.ftLabel74.TabIndex = 86;
            this.ftLabel74.Text = "Name";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(63, 255);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(704, 22);
            this.textBox2.TabIndex = 85;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.ftTextBox35);
            this.groupBox4.Controls.Add(this.ftTextBox36);
            this.groupBox4.Controls.Add(this.ftTextBox37);
            this.groupBox4.Controls.Add(this.ftTextBox38);
            this.groupBox4.Controls.Add(this.ftLabel64);
            this.groupBox4.Controls.Add(this.ftTextBox39);
            this.groupBox4.Controls.Add(this.ftLabel65);
            this.groupBox4.Controls.Add(this.ftLabel66);
            this.groupBox4.Controls.Add(this.ftLabel67);
            this.groupBox4.Controls.Add(this.ftLabel68);
            this.groupBox4.Controls.Add(this.ftTextBox40);
            this.groupBox4.Controls.Add(this.ftTextBox41);
            this.groupBox4.Controls.Add(this.ftTextBox42);
            this.groupBox4.Controls.Add(this.ftTextBox43);
            this.groupBox4.Controls.Add(this.ftLabel69);
            this.groupBox4.Controls.Add(this.ftTextBox44);
            this.groupBox4.Controls.Add(this.ftLabel70);
            this.groupBox4.Controls.Add(this.ftComboBox14);
            this.groupBox4.Controls.Add(this.ftLabel71);
            this.groupBox4.Controls.Add(this.ftComboBox15);
            this.groupBox4.Controls.Add(this.ftLabel72);
            this.groupBox4.Controls.Add(this.ftLabel73);
            this.groupBox4.Controls.Add(this.ftComboBox16);
            this.groupBox4.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox4.Location = new System.Drawing.Point(14, 337);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(753, 181);
            this.groupBox4.TabIndex = 72;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Temporary/Correspondence Address";
            // 
            // ftTextBox35
            // 
            this.ftTextBox35.AllowAlpha = true;
            this.ftTextBox35.AllowDot = false;
            this.ftTextBox35.AllowedCustomCharacters = null;
            this.ftTextBox35.AllowNonASCII = false;
            this.ftTextBox35.AllowNumeric = true;
            this.ftTextBox35.AllowSpace = false;
            this.ftTextBox35.AllowSpecialChars = true;
            this.ftTextBox35.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox35.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox35.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox35.IsEmailID = false;
            this.ftTextBox35.IsEmailIdValid = false;
            this.ftTextBox35.Location = new System.Drawing.Point(392, 56);
            this.ftTextBox35.MaxLength = 10;
            this.ftTextBox35.Name = "ftTextBox35";
            this.ftTextBox35.Size = new System.Drawing.Size(353, 20);
            this.ftTextBox35.TabIndex = 60;
            this.ftTextBox35.Tag = "Code";
            // 
            // ftTextBox36
            // 
            this.ftTextBox36.AllowAlpha = true;
            this.ftTextBox36.AllowDot = false;
            this.ftTextBox36.AllowedCustomCharacters = null;
            this.ftTextBox36.AllowNonASCII = false;
            this.ftTextBox36.AllowNumeric = true;
            this.ftTextBox36.AllowSpace = false;
            this.ftTextBox36.AllowSpecialChars = true;
            this.ftTextBox36.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox36.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox36.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox36.IsEmailID = false;
            this.ftTextBox36.IsEmailIdValid = false;
            this.ftTextBox36.Location = new System.Drawing.Point(392, 25);
            this.ftTextBox36.MaxLength = 10;
            this.ftTextBox36.Name = "ftTextBox36";
            this.ftTextBox36.Size = new System.Drawing.Size(353, 20);
            this.ftTextBox36.TabIndex = 59;
            this.ftTextBox36.Tag = "Code";
            // 
            // ftTextBox37
            // 
            this.ftTextBox37.AllowAlpha = true;
            this.ftTextBox37.AllowDot = false;
            this.ftTextBox37.AllowedCustomCharacters = null;
            this.ftTextBox37.AllowNonASCII = false;
            this.ftTextBox37.AllowNumeric = true;
            this.ftTextBox37.AllowSpace = false;
            this.ftTextBox37.AllowSpecialChars = true;
            this.ftTextBox37.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox37.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox37.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox37.IsEmailID = false;
            this.ftTextBox37.IsEmailIdValid = false;
            this.ftTextBox37.Location = new System.Drawing.Point(49, 56);
            this.ftTextBox37.MaxLength = 10;
            this.ftTextBox37.Name = "ftTextBox37";
            this.ftTextBox37.Size = new System.Drawing.Size(337, 20);
            this.ftTextBox37.TabIndex = 58;
            this.ftTextBox37.Tag = "Code";
            // 
            // ftTextBox38
            // 
            this.ftTextBox38.AllowAlpha = true;
            this.ftTextBox38.AllowDot = false;
            this.ftTextBox38.AllowedCustomCharacters = null;
            this.ftTextBox38.AllowNonASCII = false;
            this.ftTextBox38.AllowNumeric = true;
            this.ftTextBox38.AllowSpace = false;
            this.ftTextBox38.AllowSpecialChars = true;
            this.ftTextBox38.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox38.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox38.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox38.IsEmailID = false;
            this.ftTextBox38.IsEmailIdValid = false;
            this.ftTextBox38.Location = new System.Drawing.Point(49, 25);
            this.ftTextBox38.MaxLength = 10;
            this.ftTextBox38.Name = "ftTextBox38";
            this.ftTextBox38.Size = new System.Drawing.Size(337, 20);
            this.ftTextBox38.TabIndex = 57;
            this.ftTextBox38.Tag = "Code";
            // 
            // ftLabel64
            // 
            this.ftLabel64.AllowForeColorChange = false;
            this.ftLabel64.AutoSize = true;
            this.ftLabel64.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel64.ForeColor = System.Drawing.Color.Black;
            this.ftLabel64.Location = new System.Drawing.Point(2, 90);
            this.ftLabel64.Name = "ftLabel64";
            this.ftLabel64.OverrideDefault = false;
            this.ftLabel64.Size = new System.Drawing.Size(32, 12);
            this.ftLabel64.TabIndex = 56;
            this.ftLabel64.Text = "E-Mail";
            // 
            // ftTextBox39
            // 
            this.ftTextBox39.AllowAlpha = true;
            this.ftTextBox39.AllowDot = false;
            this.ftTextBox39.AllowedCustomCharacters = null;
            this.ftTextBox39.AllowNonASCII = false;
            this.ftTextBox39.AllowNumeric = true;
            this.ftTextBox39.AllowSpace = false;
            this.ftTextBox39.AllowSpecialChars = true;
            this.ftTextBox39.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox39.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox39.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox39.IsEmailID = false;
            this.ftTextBox39.IsEmailIdValid = false;
            this.ftTextBox39.Location = new System.Drawing.Point(49, 87);
            this.ftTextBox39.MaxLength = 10;
            this.ftTextBox39.Name = "ftTextBox39";
            this.ftTextBox39.Size = new System.Drawing.Size(337, 20);
            this.ftTextBox39.TabIndex = 55;
            this.ftTextBox39.Tag = "Code";
            // 
            // ftLabel65
            // 
            this.ftLabel65.AllowForeColorChange = false;
            this.ftLabel65.AutoSize = true;
            this.ftLabel65.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel65.ForeColor = System.Drawing.Color.Black;
            this.ftLabel65.Location = new System.Drawing.Point(3, 29);
            this.ftLabel65.Name = "ftLabel65";
            this.ftLabel65.OverrideDefault = false;
            this.ftLabel65.Size = new System.Drawing.Size(41, 12);
            this.ftLabel65.TabIndex = 50;
            this.ftLabel65.Text = "Address";
            // 
            // ftLabel66
            // 
            this.ftLabel66.AllowForeColorChange = false;
            this.ftLabel66.AutoSize = true;
            this.ftLabel66.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel66.ForeColor = System.Drawing.Color.Black;
            this.ftLabel66.Location = new System.Drawing.Point(600, 152);
            this.ftLabel66.Name = "ftLabel66";
            this.ftLabel66.OverrideDefault = false;
            this.ftLabel66.Size = new System.Drawing.Size(21, 12);
            this.ftLabel66.TabIndex = 49;
            this.ftLabel66.Text = "Fax";
            // 
            // ftLabel67
            // 
            this.ftLabel67.AllowForeColorChange = false;
            this.ftLabel67.AutoSize = true;
            this.ftLabel67.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel67.ForeColor = System.Drawing.Color.Black;
            this.ftLabel67.Location = new System.Drawing.Point(404, 154);
            this.ftLabel67.Name = "ftLabel67";
            this.ftLabel67.OverrideDefault = false;
            this.ftLabel67.Size = new System.Drawing.Size(26, 12);
            this.ftLabel67.TabIndex = 48;
            this.ftLabel67.Text = "Tel.2";
            // 
            // ftLabel68
            // 
            this.ftLabel68.AllowForeColorChange = false;
            this.ftLabel68.AutoSize = true;
            this.ftLabel68.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel68.ForeColor = System.Drawing.Color.Black;
            this.ftLabel68.Location = new System.Drawing.Point(212, 153);
            this.ftLabel68.Name = "ftLabel68";
            this.ftLabel68.OverrideDefault = false;
            this.ftLabel68.Size = new System.Drawing.Size(26, 12);
            this.ftLabel68.TabIndex = 47;
            this.ftLabel68.Text = "Tel.1";
            // 
            // ftTextBox40
            // 
            this.ftTextBox40.AllowAlpha = true;
            this.ftTextBox40.AllowDot = false;
            this.ftTextBox40.AllowedCustomCharacters = null;
            this.ftTextBox40.AllowNonASCII = false;
            this.ftTextBox40.AllowNumeric = true;
            this.ftTextBox40.AllowSpace = false;
            this.ftTextBox40.AllowSpecialChars = true;
            this.ftTextBox40.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox40.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox40.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox40.IsEmailID = false;
            this.ftTextBox40.IsEmailIdValid = false;
            this.ftTextBox40.Location = new System.Drawing.Point(624, 149);
            this.ftTextBox40.MaxLength = 10;
            this.ftTextBox40.Name = "ftTextBox40";
            this.ftTextBox40.Size = new System.Drawing.Size(122, 20);
            this.ftTextBox40.TabIndex = 41;
            this.ftTextBox40.Tag = "Code";
            // 
            // ftTextBox41
            // 
            this.ftTextBox41.AllowAlpha = true;
            this.ftTextBox41.AllowDot = false;
            this.ftTextBox41.AllowedCustomCharacters = null;
            this.ftTextBox41.AllowNonASCII = false;
            this.ftTextBox41.AllowNumeric = true;
            this.ftTextBox41.AllowSpace = false;
            this.ftTextBox41.AllowSpecialChars = true;
            this.ftTextBox41.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox41.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox41.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox41.IsEmailID = false;
            this.ftTextBox41.IsEmailIdValid = false;
            this.ftTextBox41.Location = new System.Drawing.Point(439, 149);
            this.ftTextBox41.MaxLength = 10;
            this.ftTextBox41.Name = "ftTextBox41";
            this.ftTextBox41.Size = new System.Drawing.Size(140, 20);
            this.ftTextBox41.TabIndex = 39;
            this.ftTextBox41.Tag = "Code";
            // 
            // ftTextBox42
            // 
            this.ftTextBox42.AllowAlpha = true;
            this.ftTextBox42.AllowDot = false;
            this.ftTextBox42.AllowedCustomCharacters = null;
            this.ftTextBox42.AllowNonASCII = false;
            this.ftTextBox42.AllowNumeric = true;
            this.ftTextBox42.AllowSpace = false;
            this.ftTextBox42.AllowSpecialChars = true;
            this.ftTextBox42.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox42.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox42.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox42.IsEmailID = false;
            this.ftTextBox42.IsEmailIdValid = false;
            this.ftTextBox42.Location = new System.Drawing.Point(245, 149);
            this.ftTextBox42.MaxLength = 10;
            this.ftTextBox42.Name = "ftTextBox42";
            this.ftTextBox42.Size = new System.Drawing.Size(140, 20);
            this.ftTextBox42.TabIndex = 37;
            this.ftTextBox42.Tag = "Code";
            // 
            // ftTextBox43
            // 
            this.ftTextBox43.AllowAlpha = true;
            this.ftTextBox43.AllowDot = false;
            this.ftTextBox43.AllowedCustomCharacters = null;
            this.ftTextBox43.AllowNonASCII = false;
            this.ftTextBox43.AllowNumeric = true;
            this.ftTextBox43.AllowSpace = false;
            this.ftTextBox43.AllowSpecialChars = true;
            this.ftTextBox43.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox43.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox43.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox43.IsEmailID = false;
            this.ftTextBox43.IsEmailIdValid = false;
            this.ftTextBox43.Location = new System.Drawing.Point(49, 149);
            this.ftTextBox43.MaxLength = 10;
            this.ftTextBox43.Name = "ftTextBox43";
            this.ftTextBox43.Size = new System.Drawing.Size(140, 20);
            this.ftTextBox43.TabIndex = 32;
            this.ftTextBox43.Tag = "Code";
            // 
            // ftLabel69
            // 
            this.ftLabel69.AllowForeColorChange = false;
            this.ftLabel69.AutoSize = true;
            this.ftLabel69.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel69.ForeColor = System.Drawing.Color.Black;
            this.ftLabel69.Location = new System.Drawing.Point(2, 153);
            this.ftLabel69.Name = "ftLabel69";
            this.ftLabel69.OverrideDefault = false;
            this.ftLabel69.Size = new System.Drawing.Size(34, 12);
            this.ftLabel69.TabIndex = 36;
            this.ftLabel69.Text = "Mobile";
            // 
            // ftTextBox44
            // 
            this.ftTextBox44.AllowAlpha = true;
            this.ftTextBox44.AllowDot = false;
            this.ftTextBox44.AllowedCustomCharacters = null;
            this.ftTextBox44.AllowNonASCII = false;
            this.ftTextBox44.AllowNumeric = true;
            this.ftTextBox44.AllowSpace = false;
            this.ftTextBox44.AllowSpecialChars = true;
            this.ftTextBox44.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox44.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox44.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox44.IsEmailID = false;
            this.ftTextBox44.IsEmailIdValid = false;
            this.ftTextBox44.Location = new System.Drawing.Point(624, 117);
            this.ftTextBox44.MaxLength = 10;
            this.ftTextBox44.Name = "ftTextBox44";
            this.ftTextBox44.Size = new System.Drawing.Size(122, 20);
            this.ftTextBox44.TabIndex = 31;
            this.ftTextBox44.Tag = "Code";
            // 
            // ftLabel70
            // 
            this.ftLabel70.AllowForeColorChange = false;
            this.ftLabel70.AutoSize = true;
            this.ftLabel70.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel70.ForeColor = System.Drawing.Color.Black;
            this.ftLabel70.Location = new System.Drawing.Point(596, 121);
            this.ftLabel70.Name = "ftLabel70";
            this.ftLabel70.OverrideDefault = false;
            this.ftLabel70.Size = new System.Drawing.Size(22, 12);
            this.ftLabel70.TabIndex = 35;
            this.ftLabel70.Text = "PIN";
            // 
            // ftComboBox14
            // 
            this.ftComboBox14.BackColor = System.Drawing.Color.White;
            this.ftComboBox14.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftComboBox14.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftComboBox14.ForeColor = System.Drawing.Color.Black;
            this.ftComboBox14.FormattingEnabled = true;
            this.ftComboBox14.Location = new System.Drawing.Point(439, 118);
            this.ftComboBox14.Name = "ftComboBox14";
            this.ftComboBox14.ReadOnly = false;
            this.ftComboBox14.Size = new System.Drawing.Size(140, 20);
            this.ftComboBox14.TabIndex = 33;
            // 
            // ftLabel71
            // 
            this.ftLabel71.AllowForeColorChange = false;
            this.ftLabel71.AutoSize = true;
            this.ftLabel71.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel71.ForeColor = System.Drawing.Color.Black;
            this.ftLabel71.Location = new System.Drawing.Point(404, 121);
            this.ftLabel71.Name = "ftLabel71";
            this.ftLabel71.OverrideDefault = false;
            this.ftLabel71.Size = new System.Drawing.Size(23, 12);
            this.ftLabel71.TabIndex = 34;
            this.ftLabel71.Text = "City";
            // 
            // ftComboBox15
            // 
            this.ftComboBox15.BackColor = System.Drawing.Color.White;
            this.ftComboBox15.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftComboBox15.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftComboBox15.ForeColor = System.Drawing.Color.Black;
            this.ftComboBox15.FormattingEnabled = true;
            this.ftComboBox15.Location = new System.Drawing.Point(245, 118);
            this.ftComboBox15.Name = "ftComboBox15";
            this.ftComboBox15.ReadOnly = false;
            this.ftComboBox15.Size = new System.Drawing.Size(140, 20);
            this.ftComboBox15.TabIndex = 31;
            // 
            // ftLabel72
            // 
            this.ftLabel72.AllowForeColorChange = false;
            this.ftLabel72.AutoSize = true;
            this.ftLabel72.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel72.ForeColor = System.Drawing.Color.Black;
            this.ftLabel72.Location = new System.Drawing.Point(212, 121);
            this.ftLabel72.Name = "ftLabel72";
            this.ftLabel72.OverrideDefault = false;
            this.ftLabel72.Size = new System.Drawing.Size(27, 12);
            this.ftLabel72.TabIndex = 32;
            this.ftLabel72.Text = "State";
            // 
            // ftLabel73
            // 
            this.ftLabel73.AllowForeColorChange = false;
            this.ftLabel73.AutoSize = true;
            this.ftLabel73.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel73.ForeColor = System.Drawing.Color.Black;
            this.ftLabel73.Location = new System.Drawing.Point(3, 121);
            this.ftLabel73.Name = "ftLabel73";
            this.ftLabel73.OverrideDefault = false;
            this.ftLabel73.Size = new System.Drawing.Size(43, 12);
            this.ftLabel73.TabIndex = 31;
            this.ftLabel73.Text = "Country";
            // 
            // ftComboBox16
            // 
            this.ftComboBox16.BackColor = System.Drawing.Color.White;
            this.ftComboBox16.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftComboBox16.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftComboBox16.ForeColor = System.Drawing.Color.Black;
            this.ftComboBox16.FormattingEnabled = true;
            this.ftComboBox16.Location = new System.Drawing.Point(49, 118);
            this.ftComboBox16.Name = "ftComboBox16";
            this.ftComboBox16.ReadOnly = false;
            this.ftComboBox16.Size = new System.Drawing.Size(140, 20);
            this.ftComboBox16.TabIndex = 29;
            // 
            // ftLabel53
            // 
            this.ftLabel53.AllowForeColorChange = false;
            this.ftLabel53.AutoSize = true;
            this.ftLabel53.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel53.ForeColor = System.Drawing.Color.Black;
            this.ftLabel53.Location = new System.Drawing.Point(9, 533);
            this.ftLabel53.Name = "ftLabel53";
            this.ftLabel53.OverrideDefault = false;
            this.ftLabel53.Size = new System.Drawing.Size(59, 12);
            this.ftLabel53.TabIndex = 65;
            this.ftLabel53.Text = "FacilityType";
            // 
            // DocUpload
            // 
            this.DocUpload.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.DocUpload.Controls.Add(this.ftLabel54);
            this.DocUpload.Controls.Add(this.ftTxtUserId);
            this.DocUpload.Controls.Add(this.ftTxtPEP);
            this.DocUpload.Controls.Add(this.ftTxtOccupation);
            this.DocUpload.Controls.Add(this.ftLabel39);
            this.DocUpload.Controls.Add(this.ftCmbPEP);
            this.DocUpload.Controls.Add(this.ftLabel40);
            this.DocUpload.Controls.Add(this.ftCmbOccupation);
            this.DocUpload.Controls.Add(this.groupBox7);
            this.DocUpload.Controls.Add(this.groupBox6);
            this.DocUpload.Controls.Add(this.dataGridView1);
            this.DocUpload.Location = new System.Drawing.Point(4, 23);
            this.DocUpload.Name = "DocUpload";
            this.DocUpload.Padding = new System.Windows.Forms.Padding(3);
            this.DocUpload.Size = new System.Drawing.Size(781, 533);
            this.DocUpload.TabIndex = 4;
            this.DocUpload.Text = "Others";
            // 
            // ftLabel54
            // 
            this.ftLabel54.AllowForeColorChange = false;
            this.ftLabel54.AutoSize = true;
            this.ftLabel54.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel54.ForeColor = System.Drawing.Color.Black;
            this.ftLabel54.Location = new System.Drawing.Point(8, 426);
            this.ftLabel54.Name = "ftLabel54";
            this.ftLabel54.OverrideDefault = false;
            this.ftLabel54.Size = new System.Drawing.Size(38, 12);
            this.ftLabel54.TabIndex = 78;
            this.ftLabel54.Text = "User Id";
            // 
            // ftTxtUserId
            // 
            this.ftTxtUserId.AllowAlpha = true;
            this.ftTxtUserId.AllowDot = false;
            this.ftTxtUserId.AllowedCustomCharacters = null;
            this.ftTxtUserId.AllowNonASCII = false;
            this.ftTxtUserId.AllowNumeric = true;
            this.ftTxtUserId.AllowSpace = false;
            this.ftTxtUserId.AllowSpecialChars = true;
            this.ftTxtUserId.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtUserId.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtUserId.ForeColor = System.Drawing.Color.Black;
            this.ftTxtUserId.IsEmailID = false;
            this.ftTxtUserId.IsEmailIdValid = false;
            this.ftTxtUserId.Location = new System.Drawing.Point(70, 423);
            this.ftTxtUserId.MaxLength = 10;
            this.ftTxtUserId.Name = "ftTxtUserId";
            this.ftTxtUserId.Size = new System.Drawing.Size(308, 20);
            this.ftTxtUserId.TabIndex = 77;
            this.ftTxtUserId.Tag = "Code";
            // 
            // ftTxtPEP
            // 
            this.ftTxtPEP.AllowAlpha = true;
            this.ftTxtPEP.AllowDot = false;
            this.ftTxtPEP.AllowedCustomCharacters = null;
            this.ftTxtPEP.AllowNonASCII = false;
            this.ftTxtPEP.AllowNumeric = true;
            this.ftTxtPEP.AllowSpace = false;
            this.ftTxtPEP.AllowSpecialChars = true;
            this.ftTxtPEP.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtPEP.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtPEP.ForeColor = System.Drawing.Color.Black;
            this.ftTxtPEP.IsEmailID = false;
            this.ftTxtPEP.IsEmailIdValid = false;
            this.ftTxtPEP.Location = new System.Drawing.Point(218, 393);
            this.ftTxtPEP.MaxLength = 10;
            this.ftTxtPEP.Name = "ftTxtPEP";
            this.ftTxtPEP.Size = new System.Drawing.Size(556, 20);
            this.ftTxtPEP.TabIndex = 75;
            this.ftTxtPEP.Tag = "Code";
            // 
            // ftTxtOccupation
            // 
            this.ftTxtOccupation.AllowAlpha = true;
            this.ftTxtOccupation.AllowDot = false;
            this.ftTxtOccupation.AllowedCustomCharacters = null;
            this.ftTxtOccupation.AllowNonASCII = false;
            this.ftTxtOccupation.AllowNumeric = true;
            this.ftTxtOccupation.AllowSpace = false;
            this.ftTxtOccupation.AllowSpecialChars = true;
            this.ftTxtOccupation.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtOccupation.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtOccupation.ForeColor = System.Drawing.Color.Black;
            this.ftTxtOccupation.IsEmailID = false;
            this.ftTxtOccupation.IsEmailIdValid = false;
            this.ftTxtOccupation.Location = new System.Drawing.Point(218, 364);
            this.ftTxtOccupation.MaxLength = 10;
            this.ftTxtOccupation.Name = "ftTxtOccupation";
            this.ftTxtOccupation.Size = new System.Drawing.Size(556, 20);
            this.ftTxtOccupation.TabIndex = 72;
            this.ftTxtOccupation.Tag = "Code";
            // 
            // ftLabel39
            // 
            this.ftLabel39.AllowForeColorChange = false;
            this.ftLabel39.AutoSize = true;
            this.ftLabel39.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel39.ForeColor = System.Drawing.Color.Black;
            this.ftLabel39.Location = new System.Drawing.Point(8, 396);
            this.ftLabel39.Name = "ftLabel39";
            this.ftLabel39.OverrideDefault = false;
            this.ftLabel39.Size = new System.Drawing.Size(23, 12);
            this.ftLabel39.TabIndex = 76;
            this.ftLabel39.Text = "PEP";
            // 
            // ftCmbPEP
            // 
            this.ftCmbPEP.BackColor = System.Drawing.Color.White;
            this.ftCmbPEP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftCmbPEP.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftCmbPEP.ForeColor = System.Drawing.Color.Black;
            this.ftCmbPEP.FormattingEnabled = true;
            this.ftCmbPEP.Location = new System.Drawing.Point(70, 393);
            this.ftCmbPEP.Name = "ftCmbPEP";
            this.ftCmbPEP.ReadOnly = false;
            this.ftCmbPEP.Size = new System.Drawing.Size(142, 20);
            this.ftCmbPEP.TabIndex = 74;
            // 
            // ftLabel40
            // 
            this.ftLabel40.AllowForeColorChange = false;
            this.ftLabel40.AutoSize = true;
            this.ftLabel40.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel40.ForeColor = System.Drawing.Color.Black;
            this.ftLabel40.Location = new System.Drawing.Point(8, 367);
            this.ftLabel40.Name = "ftLabel40";
            this.ftLabel40.OverrideDefault = false;
            this.ftLabel40.Size = new System.Drawing.Size(57, 12);
            this.ftLabel40.TabIndex = 73;
            this.ftLabel40.Text = "Occupation";
            // 
            // ftCmbOccupation
            // 
            this.ftCmbOccupation.BackColor = System.Drawing.Color.White;
            this.ftCmbOccupation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftCmbOccupation.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftCmbOccupation.ForeColor = System.Drawing.Color.Black;
            this.ftCmbOccupation.FormattingEnabled = true;
            this.ftCmbOccupation.Location = new System.Drawing.Point(70, 364);
            this.ftCmbOccupation.Name = "ftCmbOccupation";
            this.ftCmbOccupation.ReadOnly = false;
            this.ftCmbOccupation.Size = new System.Drawing.Size(142, 20);
            this.ftCmbOccupation.TabIndex = 71;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.dateTimePicker6);
            this.groupBox7.Controls.Add(this.ftCmbGrossAnnual);
            this.groupBox7.Controls.Add(this.dateTimePicker5);
            this.groupBox7.Controls.Add(this.ftTextBox25);
            this.groupBox7.Controls.Add(this.ftLabel41);
            this.groupBox7.Controls.Add(this.ftLabel42);
            this.groupBox7.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox7.Location = new System.Drawing.Point(8, 295);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(766, 54);
            this.groupBox7.TabIndex = 70;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Income/Networth";
            // 
            // dateTimePicker6
            // 
            this.dateTimePicker6.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker6.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker6.Location = new System.Drawing.Point(640, 21);
            this.dateTimePicker6.Name = "dateTimePicker6";
            this.dateTimePicker6.Size = new System.Drawing.Size(120, 21);
            this.dateTimePicker6.TabIndex = 62;
            // 
            // ftCmbGrossAnnual
            // 
            this.ftCmbGrossAnnual.BackColor = System.Drawing.Color.White;
            this.ftCmbGrossAnnual.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftCmbGrossAnnual.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftCmbGrossAnnual.ForeColor = System.Drawing.Color.Black;
            this.ftCmbGrossAnnual.FormattingEnabled = true;
            this.ftCmbGrossAnnual.Location = new System.Drawing.Point(76, 22);
            this.ftCmbGrossAnnual.Name = "ftCmbGrossAnnual";
            this.ftCmbGrossAnnual.ReadOnly = false;
            this.ftCmbGrossAnnual.Size = new System.Drawing.Size(168, 20);
            this.ftCmbGrossAnnual.TabIndex = 61;
            // 
            // dateTimePicker5
            // 
            this.dateTimePicker5.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker5.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker5.Location = new System.Drawing.Point(250, 21);
            this.dateTimePicker5.Name = "dateTimePicker5";
            this.dateTimePicker5.Size = new System.Drawing.Size(120, 21);
            this.dateTimePicker5.TabIndex = 60;
            // 
            // ftTextBox25
            // 
            this.ftTextBox25.AllowAlpha = true;
            this.ftTextBox25.AllowDot = false;
            this.ftTextBox25.AllowedCustomCharacters = null;
            this.ftTextBox25.AllowNonASCII = false;
            this.ftTextBox25.AllowNumeric = true;
            this.ftTextBox25.AllowSpace = false;
            this.ftTextBox25.AllowSpecialChars = true;
            this.ftTextBox25.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox25.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox25.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox25.IsEmailID = false;
            this.ftTextBox25.IsEmailIdValid = false;
            this.ftTextBox25.Location = new System.Drawing.Point(480, 22);
            this.ftTextBox25.MaxLength = 10;
            this.ftTextBox25.Name = "ftTextBox25";
            this.ftTextBox25.Size = new System.Drawing.Size(149, 20);
            this.ftTextBox25.TabIndex = 25;
            this.ftTextBox25.Tag = "Code";
            // 
            // ftLabel41
            // 
            this.ftLabel41.AllowForeColorChange = false;
            this.ftLabel41.AutoSize = true;
            this.ftLabel41.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel41.ForeColor = System.Drawing.Color.Black;
            this.ftLabel41.Location = new System.Drawing.Point(5, 25);
            this.ftLabel41.Name = "ftLabel41";
            this.ftLabel41.OverrideDefault = false;
            this.ftLabel41.Size = new System.Drawing.Size(65, 12);
            this.ftLabel41.TabIndex = 59;
            this.ftLabel41.Text = "Gross Annual";
            // 
            // ftLabel42
            // 
            this.ftLabel42.AllowForeColorChange = false;
            this.ftLabel42.AutoSize = true;
            this.ftLabel42.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel42.ForeColor = System.Drawing.Color.Black;
            this.ftLabel42.Location = new System.Drawing.Point(427, 26);
            this.ftLabel42.Name = "ftLabel42";
            this.ftLabel42.OverrideDefault = false;
            this.ftLabel42.Size = new System.Drawing.Size(47, 12);
            this.ftLabel42.TabIndex = 26;
            this.ftLabel42.Text = "Networth";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.ftBtnSaveIdentity);
            this.groupBox6.Controls.Add(this.btnDelete);
            this.groupBox6.Controls.Add(this.btnAdd);
            this.groupBox6.Controls.Add(this.ftLabel43);
            this.groupBox6.Controls.Add(this.dateTimePicker4);
            this.groupBox6.Controls.Add(this.ftLabel44);
            this.groupBox6.Controls.Add(this.dateTimePicker3);
            this.groupBox6.Controls.Add(this.ftLabel45);
            this.groupBox6.Controls.Add(this.ftLabel46);
            this.groupBox6.Controls.Add(this.ftLabel47);
            this.groupBox6.Controls.Add(this.ftTextBox26);
            this.groupBox6.Controls.Add(this.ftTextBox27);
            this.groupBox6.Controls.Add(this.ftComboBox8);
            this.groupBox6.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox6.Location = new System.Drawing.Point(263, 9);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(511, 282);
            this.groupBox6.TabIndex = 69;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Identification";
            // 
            // ftBtnSaveIdentity
            // 
            this.ftBtnSaveIdentity.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ftBtnSaveIdentity.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ftBtnSaveIdentity.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.ftBtnSaveIdentity.Image = ((System.Drawing.Image)(resources.GetObject("ftBtnSaveIdentity.Image")));
            this.ftBtnSaveIdentity.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ftBtnSaveIdentity.Location = new System.Drawing.Point(338, 251);
            this.ftBtnSaveIdentity.Name = "ftBtnSaveIdentity";
            this.ftBtnSaveIdentity.Size = new System.Drawing.Size(84, 25);
            this.ftBtnSaveIdentity.TabIndex = 75;
            this.ftBtnSaveIdentity.Text = "&Save";
            this.ftBtnSaveIdentity.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ftBtnSaveIdentity.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Transparent;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.Location = new System.Drawing.Point(429, 251);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 25);
            this.btnDelete.TabIndex = 74;
            this.btnDelete.Text = "&Delete";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.UseVisualStyleBackColor = false;
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Transparent;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAdd.Location = new System.Drawing.Point(257, 251);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 25);
            this.btnAdd.TabIndex = 73;
            this.btnAdd.Text = "&New";
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAdd.UseVisualStyleBackColor = false;
            // 
            // ftLabel43
            // 
            this.ftLabel43.AllowForeColorChange = false;
            this.ftLabel43.AutoSize = true;
            this.ftLabel43.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel43.ForeColor = System.Drawing.Color.Black;
            this.ftLabel43.Location = new System.Drawing.Point(6, 83);
            this.ftLabel43.Name = "ftLabel43";
            this.ftLabel43.OverrideDefault = false;
            this.ftLabel43.Size = new System.Drawing.Size(66, 12);
            this.ftLabel43.TabIndex = 59;
            this.ftLabel43.Text = "Place of Issue";
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker4.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker4.Location = new System.Drawing.Point(333, 49);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(120, 21);
            this.dateTimePicker4.TabIndex = 58;
            // 
            // ftLabel44
            // 
            this.ftLabel44.AllowForeColorChange = false;
            this.ftLabel44.AutoSize = true;
            this.ftLabel44.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel44.ForeColor = System.Drawing.Color.Black;
            this.ftLabel44.Location = new System.Drawing.Point(264, 55);
            this.ftLabel44.Name = "ftLabel44";
            this.ftLabel44.OverrideDefault = false;
            this.ftLabel44.Size = new System.Drawing.Size(57, 12);
            this.ftLabel44.TabIndex = 57;
            this.ftLabel44.Text = "Expiry Date";
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker3.Location = new System.Drawing.Point(82, 49);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(120, 21);
            this.dateTimePicker3.TabIndex = 56;
            // 
            // ftLabel45
            // 
            this.ftLabel45.AllowForeColorChange = false;
            this.ftLabel45.AutoSize = true;
            this.ftLabel45.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel45.ForeColor = System.Drawing.Color.Black;
            this.ftLabel45.Location = new System.Drawing.Point(6, 55);
            this.ftLabel45.Name = "ftLabel45";
            this.ftLabel45.OverrideDefault = false;
            this.ftLabel45.Size = new System.Drawing.Size(63, 12);
            this.ftLabel45.TabIndex = 55;
            this.ftLabel45.Text = "Date of Issue";
            // 
            // ftLabel46
            // 
            this.ftLabel46.AllowForeColorChange = false;
            this.ftLabel46.AutoSize = true;
            this.ftLabel46.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel46.ForeColor = System.Drawing.Color.Black;
            this.ftLabel46.Location = new System.Drawing.Point(264, 23);
            this.ftLabel46.Name = "ftLabel46";
            this.ftLabel46.OverrideDefault = false;
            this.ftLabel46.Size = new System.Drawing.Size(33, 12);
            this.ftLabel46.TabIndex = 54;
            this.ftLabel46.Text = "Details";
            // 
            // ftLabel47
            // 
            this.ftLabel47.AllowForeColorChange = false;
            this.ftLabel47.AutoSize = true;
            this.ftLabel47.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel47.ForeColor = System.Drawing.Color.Black;
            this.ftLabel47.Location = new System.Drawing.Point(6, 23);
            this.ftLabel47.Name = "ftLabel47";
            this.ftLabel47.OverrideDefault = false;
            this.ftLabel47.Size = new System.Drawing.Size(28, 12);
            this.ftLabel47.TabIndex = 53;
            this.ftLabel47.Text = "Type";
            // 
            // ftTextBox26
            // 
            this.ftTextBox26.AllowAlpha = true;
            this.ftTextBox26.AllowDot = false;
            this.ftTextBox26.AllowedCustomCharacters = null;
            this.ftTextBox26.AllowNonASCII = false;
            this.ftTextBox26.AllowNumeric = true;
            this.ftTextBox26.AllowSpace = false;
            this.ftTextBox26.AllowSpecialChars = true;
            this.ftTextBox26.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox26.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox26.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox26.IsEmailID = false;
            this.ftTextBox26.IsEmailIdValid = false;
            this.ftTextBox26.Location = new System.Drawing.Point(82, 80);
            this.ftTextBox26.MaxLength = 10;
            this.ftTextBox26.Name = "ftTextBox26";
            this.ftTextBox26.Size = new System.Drawing.Size(151, 20);
            this.ftTextBox26.TabIndex = 39;
            this.ftTextBox26.Tag = "Code";
            // 
            // ftTextBox27
            // 
            this.ftTextBox27.AllowAlpha = true;
            this.ftTextBox27.AllowDot = false;
            this.ftTextBox27.AllowedCustomCharacters = null;
            this.ftTextBox27.AllowNonASCII = false;
            this.ftTextBox27.AllowNumeric = true;
            this.ftTextBox27.AllowSpace = false;
            this.ftTextBox27.AllowSpecialChars = true;
            this.ftTextBox27.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox27.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox27.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox27.IsEmailID = false;
            this.ftTextBox27.IsEmailIdValid = false;
            this.ftTextBox27.Location = new System.Drawing.Point(333, 20);
            this.ftTextBox27.MaxLength = 10;
            this.ftTextBox27.Name = "ftTextBox27";
            this.ftTextBox27.Size = new System.Drawing.Size(170, 20);
            this.ftTextBox27.TabIndex = 32;
            this.ftTextBox27.Tag = "Code";
            // 
            // ftComboBox8
            // 
            this.ftComboBox8.BackColor = System.Drawing.Color.White;
            this.ftComboBox8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftComboBox8.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftComboBox8.ForeColor = System.Drawing.Color.Black;
            this.ftComboBox8.FormattingEnabled = true;
            this.ftComboBox8.Location = new System.Drawing.Point(82, 20);
            this.ftComboBox8.Name = "ftComboBox8";
            this.ftComboBox8.ReadOnly = false;
            this.ftComboBox8.Size = new System.Drawing.Size(120, 20);
            this.ftComboBox8.TabIndex = 29;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.dataGridView1.Location = new System.Drawing.Point(7, 9);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.Size = new System.Drawing.Size(243, 282);
            this.dataGridView1.TabIndex = 68;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Type";
            this.dataGridViewTextBoxColumn1.MaxInputLength = 20;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 60;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Details";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 105;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Date";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 75;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.tabPage1.Controls.Add(this.ftBtnRemoveDoc);
            this.tabPage1.Controls.Add(this.ftLabel77);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.dataGridView2);
            this.tabPage1.Controls.Add(this.groupBox11);
            this.tabPage1.Location = new System.Drawing.Point(4, 23);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(781, 533);
            this.tabPage1.TabIndex = 5;
            this.tabPage1.Text = "Doc Upload";
            // 
            // ftBtnRemoveDoc
            // 
            this.ftBtnRemoveDoc.BackColor = System.Drawing.Color.Transparent;
            this.ftBtnRemoveDoc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ftBtnRemoveDoc.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.ftBtnRemoveDoc.Image = ((System.Drawing.Image)(resources.GetObject("ftBtnRemoveDoc.Image")));
            this.ftBtnRemoveDoc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ftBtnRemoveDoc.Location = new System.Drawing.Point(699, 93);
            this.ftBtnRemoveDoc.Name = "ftBtnRemoveDoc";
            this.ftBtnRemoveDoc.Size = new System.Drawing.Size(75, 25);
            this.ftBtnRemoveDoc.TabIndex = 68;
            this.ftBtnRemoveDoc.Text = "&Delete";
            this.ftBtnRemoveDoc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ftBtnRemoveDoc.UseVisualStyleBackColor = false;
            // 
            // ftLabel77
            // 
            this.ftLabel77.AllowForeColorChange = false;
            this.ftLabel77.AutoSize = true;
            this.ftLabel77.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel77.ForeColor = System.Drawing.Color.Black;
            this.ftLabel77.Location = new System.Drawing.Point(239, 403);
            this.ftLabel77.Name = "ftLabel77";
            this.ftLabel77.OverrideDefault = false;
            this.ftLabel77.Size = new System.Drawing.Size(48, 12);
            this.ftLabel77.TabIndex = 67;
            this.ftLabel77.Text = "Comment";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(240, 423);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(534, 93);
            this.textBox1.TabIndex = 66;
            // 
            // dataGridView2
            // 
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4,
            this.Date});
            this.dataGridView2.Location = new System.Drawing.Point(6, 93);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.Size = new System.Drawing.Size(208, 423);
            this.dataGridView2.TabIndex = 64;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Type";
            this.dataGridViewTextBoxColumn4.MaxInputLength = 100;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // Date
            // 
            this.Date.HeaderText = "Date";
            this.Date.Name = "Date";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.btnImport);
            this.groupBox11.Controls.Add(this.ftLabel81);
            this.groupBox11.Controls.Add(this.ftCmbTypeofDocument);
            this.groupBox11.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox11.Location = new System.Drawing.Point(6, 16);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(768, 60);
            this.groupBox11.TabIndex = 63;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Identification";
            // 
            // btnImport
            // 
            this.btnImport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnImport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnImport.Image = ((System.Drawing.Image)(resources.GetObject("btnImport.Image")));
            this.btnImport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnImport.Location = new System.Drawing.Point(287, 20);
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(85, 23);
            this.btnImport.TabIndex = 69;
            this.btnImport.Text = "Upload";
            this.btnImport.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnImport.UseVisualStyleBackColor = true;
            // 
            // ftLabel81
            // 
            this.ftLabel81.AllowForeColorChange = false;
            this.ftLabel81.AutoSize = true;
            this.ftLabel81.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel81.ForeColor = System.Drawing.Color.Black;
            this.ftLabel81.Location = new System.Drawing.Point(6, 26);
            this.ftLabel81.Name = "ftLabel81";
            this.ftLabel81.OverrideDefault = false;
            this.ftLabel81.Size = new System.Drawing.Size(89, 12);
            this.ftLabel81.TabIndex = 53;
            this.ftLabel81.Text = "Type of Document";
            // 
            // ftCmbTypeofDocument
            // 
            this.ftCmbTypeofDocument.BackColor = System.Drawing.Color.White;
            this.ftCmbTypeofDocument.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftCmbTypeofDocument.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftCmbTypeofDocument.ForeColor = System.Drawing.Color.Black;
            this.ftCmbTypeofDocument.FormattingEnabled = true;
            this.ftCmbTypeofDocument.Location = new System.Drawing.Point(102, 23);
            this.ftCmbTypeofDocument.Name = "ftCmbTypeofDocument";
            this.ftCmbTypeofDocument.ReadOnly = false;
            this.ftCmbTypeofDocument.Size = new System.Drawing.Size(169, 20);
            this.ftCmbTypeofDocument.TabIndex = 29;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.tabPage2.Controls.Add(this.groupBox12);
            this.tabPage2.Location = new System.Drawing.Point(4, 23);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(781, 533);
            this.tabPage2.TabIndex = 6;
            this.tabPage2.Text = "Product";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.chkProtector);
            this.groupBox12.Controls.Add(this.chkMatch);
            this.groupBox12.Controls.Add(this.chkDP);
            this.groupBox12.Controls.Add(this.chkODIN);
            this.groupBox12.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox12.Location = new System.Drawing.Point(13, 6);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(164, 139);
            this.groupBox12.TabIndex = 59;
            this.groupBox12.TabStop = false;
            // 
            // chkProtector
            // 
            this.chkProtector.AutoSize = true;
            this.chkProtector.Location = new System.Drawing.Point(29, 89);
            this.chkProtector.Name = "chkProtector";
            this.chkProtector.Size = new System.Drawing.Size(71, 17);
            this.chkProtector.TabIndex = 60;
            this.chkProtector.Text = "Protector";
            this.chkProtector.UseVisualStyleBackColor = true;
            // 
            // chkMatch
            // 
            this.chkMatch.AutoSize = true;
            this.chkMatch.Location = new System.Drawing.Point(29, 66);
            this.chkMatch.Name = "chkMatch";
            this.chkMatch.Size = new System.Drawing.Size(55, 17);
            this.chkMatch.TabIndex = 60;
            this.chkMatch.Text = "Match";
            this.chkMatch.UseVisualStyleBackColor = true;
            // 
            // chkDP
            // 
            this.chkDP.AutoSize = true;
            this.chkDP.Location = new System.Drawing.Point(29, 43);
            this.chkDP.Name = "chkDP";
            this.chkDP.Size = new System.Drawing.Size(39, 17);
            this.chkDP.TabIndex = 60;
            this.chkDP.Text = "DP";
            this.chkDP.UseVisualStyleBackColor = true;
            // 
            // chkODIN
            // 
            this.chkODIN.AutoSize = true;
            this.chkODIN.Location = new System.Drawing.Point(29, 20);
            this.chkODIN.Name = "chkODIN";
            this.chkODIN.Size = new System.Drawing.Size(52, 17);
            this.chkODIN.TabIndex = 59;
            this.chkODIN.Text = "ODIN";
            this.chkODIN.UseVisualStyleBackColor = true;
            // 
            // btnApply
            // 
            this.btnApply.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnApply.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnApply.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.btnApply.Image = ((System.Drawing.Image)(resources.GetObject("btnApply.Image")));
            this.btnApply.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnApply.Location = new System.Drawing.Point(706, 663);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new System.Drawing.Size(84, 25);
            this.btnApply.TabIndex = 81;
            this.btnApply.Text = "&Apply";
            this.btnApply.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnApply.UseVisualStyleBackColor = true;
            this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
            // 
            // lblMobileNo
            // 
            this.lblMobileNo.AllowForeColorChange = false;
            this.lblMobileNo.AutoSize = true;
            this.lblMobileNo.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblMobileNo.ForeColor = System.Drawing.Color.Black;
            this.lblMobileNo.Location = new System.Drawing.Point(21, 676);
            this.lblMobileNo.Name = "lblMobileNo";
            this.lblMobileNo.OverrideDefault = false;
            this.lblMobileNo.Size = new System.Drawing.Size(39, 12);
            this.lblMobileNo.TabIndex = 80;
            this.lblMobileNo.Text = "Status: ";
            // 
            // ftlblEntityCode
            // 
            this.ftlblEntityCode.AllowForeColorChange = false;
            this.ftlblEntityCode.AutoSize = true;
            this.ftlblEntityCode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftlblEntityCode.ForeColor = System.Drawing.Color.Black;
            this.ftlblEntityCode.IsMandatory = true;
            this.ftlblEntityCode.Location = new System.Drawing.Point(7, 32);
            this.ftlblEntityCode.Name = "ftlblEntityCode";
            this.ftlblEntityCode.OverrideDefault = false;
            this.ftlblEntityCode.Size = new System.Drawing.Size(35, 12);
            this.ftlblEntityCode.TabIndex = 79;
            this.ftlblEntityCode.Text = "Code*";
            // 
            // lblHeading
            // 
            this.lblHeading.AutoSize = true;
            this.lblHeading.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.lblHeading.ForeColor = System.Drawing.Color.Red;
            this.lblHeading.Location = new System.Drawing.Point(358, 3);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.Size = new System.Drawing.Size(95, 14);
            this.lblHeading.TabIndex = 78;
            this.lblHeading.Text = "Non Individual";
            // 
            // txtNameHead
            // 
            this.txtNameHead.Location = new System.Drawing.Point(78, 60);
            this.txtNameHead.Name = "txtNameHead";
            this.txtNameHead.Size = new System.Drawing.Size(693, 20);
            this.txtNameHead.TabIndex = 77;
            // 
            // txtEntityCode
            // 
            this.txtEntityCode.Location = new System.Drawing.Point(78, 28);
            this.txtEntityCode.Name = "txtEntityCode";
            this.txtEntityCode.Size = new System.Drawing.Size(143, 20);
            this.txtEntityCode.TabIndex = 76;
            // 
            // ftTxtCIN
            // 
            this.ftTxtCIN.AllowAlpha = true;
            this.ftTxtCIN.AllowDot = false;
            this.ftTxtCIN.AllowedCustomCharacters = null;
            this.ftTxtCIN.AllowNonASCII = false;
            this.ftTxtCIN.AllowNumeric = true;
            this.ftTxtCIN.AllowSpace = false;
            this.ftTxtCIN.AllowSpecialChars = true;
            this.ftTxtCIN.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtCIN.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtCIN.ForeColor = System.Drawing.Color.Black;
            this.ftTxtCIN.IsEmailID = false;
            this.ftTxtCIN.IsEmailIdValid = false;
            this.ftTxtCIN.Location = new System.Drawing.Point(49, 56);
            this.ftTxtCIN.MaxLength = 10;
            this.ftTxtCIN.Name = "ftTxtCIN";
            this.ftTxtCIN.Size = new System.Drawing.Size(149, 20);
            this.ftTxtCIN.TabIndex = 23;
            this.ftTxtCIN.Tag = "Code";
            // 
            // ftLabel34
            // 
            this.ftLabel34.AllowForeColorChange = false;
            this.ftLabel34.AutoSize = true;
            this.ftLabel34.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel34.ForeColor = System.Drawing.Color.Black;
            this.ftLabel34.Location = new System.Drawing.Point(3, 60);
            this.ftLabel34.Name = "ftLabel34";
            this.ftLabel34.OverrideDefault = false;
            this.ftLabel34.Size = new System.Drawing.Size(23, 12);
            this.ftLabel34.TabIndex = 24;
            // 
            // ftLabel11
            // 
            this.ftLabel11.AllowForeColorChange = false;
            this.ftLabel11.AutoSize = true;
            this.ftLabel11.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel11.ForeColor = System.Drawing.Color.Black;
            this.ftLabel11.Location = new System.Drawing.Point(275, 60);
            this.ftLabel11.Name = "ftLabel11";
            this.ftLabel11.OverrideDefault = false;
            this.ftLabel11.Size = new System.Drawing.Size(77, 12);
            this.ftLabel11.TabIndex = 89;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(358, 55);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(106, 20);
            this.dateTimePicker1.TabIndex = 90;
            // 
            // ftTxtPAN
            // 
            this.ftTxtPAN.AllowAlpha = true;
            this.ftTxtPAN.AllowDot = false;
            this.ftTxtPAN.AllowedCustomCharacters = null;
            this.ftTxtPAN.AllowNonASCII = false;
            this.ftTxtPAN.AllowNumeric = true;
            this.ftTxtPAN.AllowSpace = false;
            this.ftTxtPAN.AllowSpecialChars = true;
            this.ftTxtPAN.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtPAN.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtPAN.ForeColor = System.Drawing.Color.Black;
            this.ftTxtPAN.IsEmailID = false;
            this.ftTxtPAN.IsEmailIdValid = false;
            this.ftTxtPAN.Location = new System.Drawing.Point(624, 56);
            this.ftTxtPAN.MaxLength = 10;
            this.ftTxtPAN.Name = "ftTxtPAN";
            this.ftTxtPAN.Size = new System.Drawing.Size(122, 20);
            this.ftTxtPAN.TabIndex = 91;
            this.ftTxtPAN.Tag = "Code";
            // 
            // ftLabel15
            // 
            this.ftLabel15.AllowForeColorChange = false;
            this.ftLabel15.AutoSize = true;
            this.ftLabel15.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel15.ForeColor = System.Drawing.Color.Black;
            this.ftLabel15.Location = new System.Drawing.Point(595, 60);
            this.ftLabel15.Name = "ftLabel15";
            this.ftLabel15.OverrideDefault = false;
            this.ftLabel15.Size = new System.Drawing.Size(25, 12);
            this.ftLabel15.TabIndex = 92;
            // 
            // ftCmbSattus
            // 
            this.ftCmbSattus.BackColor = System.Drawing.Color.White;
            this.ftCmbSattus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftCmbSattus.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftCmbSattus.ForeColor = System.Drawing.Color.Black;
            this.ftCmbSattus.FormattingEnabled = true;
            this.ftCmbSattus.Location = new System.Drawing.Point(49, 89);
            this.ftCmbSattus.Name = "ftCmbSattus";
            this.ftCmbSattus.ReadOnly = false;
            this.ftCmbSattus.Size = new System.Drawing.Size(149, 20);
            this.ftCmbSattus.TabIndex = 93;
            // 
            // ftLabel12
            // 
            this.ftLabel12.AllowForeColorChange = false;
            this.ftLabel12.AutoSize = true;
            this.ftLabel12.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel12.ForeColor = System.Drawing.Color.Black;
            this.ftLabel12.IsMandatory = true;
            this.ftLabel12.Location = new System.Drawing.Point(6, 27);
            this.ftLabel12.Name = "ftLabel12";
            this.ftLabel12.OverrideDefault = false;
            this.ftLabel12.Size = new System.Drawing.Size(30, 12);
            this.ftLabel12.TabIndex = 87;
            this.ftLabel12.Text = "*";
            // 
            // dateTimePicker7
            // 
            this.dateTimePicker7.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker7.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker7.Location = new System.Drawing.Point(51, 22);
            this.dateTimePicker7.Name = "dateTimePicker7";
            this.dateTimePicker7.Size = new System.Drawing.Size(143, 20);
            this.dateTimePicker7.TabIndex = 88;
            // 
            // ftLabel16
            // 
            this.ftLabel16.AllowForeColorChange = false;
            this.ftLabel16.AutoSize = true;
            this.ftLabel16.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel16.ForeColor = System.Drawing.Color.Black;
            this.ftLabel16.Location = new System.Drawing.Point(2, 92);
            this.ftLabel16.Name = "ftLabel16";
            this.ftLabel16.OverrideDefault = false;
            this.ftLabel16.Size = new System.Drawing.Size(32, 12);
            this.ftLabel16.TabIndex = 94;
            // 
            // ftLabel14
            // 
            this.ftLabel14.AllowForeColorChange = false;
            this.ftLabel14.AutoSize = true;
            this.ftLabel14.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel14.ForeColor = System.Drawing.Color.Black;
            this.ftLabel14.Location = new System.Drawing.Point(275, 27);
            this.ftLabel14.Name = "ftLabel14";
            this.ftLabel14.OverrideDefault = false;
            this.ftLabel14.Size = new System.Drawing.Size(106, 12);
            this.ftLabel14.TabIndex = 46;
            // 
            // ftTxtStatus
            // 
            this.ftTxtStatus.AllowAlpha = true;
            this.ftTxtStatus.AllowDot = false;
            this.ftTxtStatus.AllowedCustomCharacters = null;
            this.ftTxtStatus.AllowNonASCII = false;
            this.ftTxtStatus.AllowNumeric = true;
            this.ftTxtStatus.AllowSpace = false;
            this.ftTxtStatus.AllowSpecialChars = true;
            this.ftTxtStatus.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtStatus.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtStatus.ForeColor = System.Drawing.Color.Black;
            this.ftTxtStatus.IsEmailID = false;
            this.ftTxtStatus.IsEmailIdValid = false;
            this.ftTxtStatus.Location = new System.Drawing.Point(206, 89);
            this.ftTxtStatus.MaxLength = 10;
            this.ftTxtStatus.Name = "ftTxtStatus";
            this.ftTxtStatus.Size = new System.Drawing.Size(540, 20);
            this.ftTxtStatus.TabIndex = 95;
            this.ftTxtStatus.Tag = "Code";
            // 
            // ftTxtPoI
            // 
            this.ftTxtPoI.AllowAlpha = true;
            this.ftTxtPoI.AllowDot = false;
            this.ftTxtPoI.AllowedCustomCharacters = null;
            this.ftTxtPoI.AllowNonASCII = false;
            this.ftTxtPoI.AllowNumeric = true;
            this.ftTxtPoI.AllowSpace = false;
            this.ftTxtPoI.AllowSpecialChars = true;
            this.ftTxtPoI.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtPoI.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtPoI.ForeColor = System.Drawing.Color.Black;
            this.ftTxtPoI.IsEmailID = false;
            this.ftTxtPoI.IsEmailIdValid = false;
            this.ftTxtPoI.Location = new System.Drawing.Point(385, 23);
            this.ftTxtPoI.MaxLength = 10;
            this.ftTxtPoI.Name = "ftTxtPoI";
            this.ftTxtPoI.Size = new System.Drawing.Size(362, 20);
            this.ftTxtPoI.TabIndex = 89;
            this.ftTxtPoI.Tag = "Code";
            // 
            // ftComboBox6
            // 
            this.ftComboBox6.BackColor = System.Drawing.Color.White;
            this.ftComboBox6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftComboBox6.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftComboBox6.ForeColor = System.Drawing.Color.Black;
            this.ftComboBox6.FormattingEnabled = true;
            this.ftComboBox6.Location = new System.Drawing.Point(49, 118);
            this.ftComboBox6.Name = "ftComboBox6";
            this.ftComboBox6.ReadOnly = false;
            this.ftComboBox6.Size = new System.Drawing.Size(140, 20);
            this.ftComboBox6.TabIndex = 29;
            // 
            // ftLabel31
            // 
            this.ftLabel31.AllowForeColorChange = false;
            this.ftLabel31.AutoSize = true;
            this.ftLabel31.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel31.ForeColor = System.Drawing.Color.Black;
            this.ftLabel31.Location = new System.Drawing.Point(3, 121);
            this.ftLabel31.Name = "ftLabel31";
            this.ftLabel31.OverrideDefault = false;
            this.ftLabel31.Size = new System.Drawing.Size(43, 12);
            this.ftLabel31.TabIndex = 31;
            // 
            // ftLabel30
            // 
            this.ftLabel30.AllowForeColorChange = false;
            this.ftLabel30.AutoSize = true;
            this.ftLabel30.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel30.ForeColor = System.Drawing.Color.Black;
            this.ftLabel30.Location = new System.Drawing.Point(212, 121);
            this.ftLabel30.Name = "ftLabel30";
            this.ftLabel30.OverrideDefault = false;
            this.ftLabel30.Size = new System.Drawing.Size(27, 12);
            this.ftLabel30.TabIndex = 32;
            // 
            // ftComboBox5
            // 
            this.ftComboBox5.BackColor = System.Drawing.Color.White;
            this.ftComboBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftComboBox5.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftComboBox5.ForeColor = System.Drawing.Color.Black;
            this.ftComboBox5.FormattingEnabled = true;
            this.ftComboBox5.Location = new System.Drawing.Point(245, 118);
            this.ftComboBox5.Name = "ftComboBox5";
            this.ftComboBox5.ReadOnly = false;
            this.ftComboBox5.Size = new System.Drawing.Size(140, 20);
            this.ftComboBox5.TabIndex = 31;
            // 
            // ftLabel29
            // 
            this.ftLabel29.AllowForeColorChange = false;
            this.ftLabel29.AutoSize = true;
            this.ftLabel29.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel29.ForeColor = System.Drawing.Color.Black;
            this.ftLabel29.Location = new System.Drawing.Point(404, 121);
            this.ftLabel29.Name = "ftLabel29";
            this.ftLabel29.OverrideDefault = false;
            this.ftLabel29.Size = new System.Drawing.Size(23, 12);
            this.ftLabel29.TabIndex = 34;
            // 
            // ftComboBox4
            // 
            this.ftComboBox4.BackColor = System.Drawing.Color.White;
            this.ftComboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftComboBox4.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftComboBox4.ForeColor = System.Drawing.Color.Black;
            this.ftComboBox4.FormattingEnabled = true;
            this.ftComboBox4.Location = new System.Drawing.Point(439, 118);
            this.ftComboBox4.Name = "ftComboBox4";
            this.ftComboBox4.ReadOnly = false;
            this.ftComboBox4.Size = new System.Drawing.Size(140, 20);
            this.ftComboBox4.TabIndex = 33;
            // 
            // ftLabel28
            // 
            this.ftLabel28.AllowForeColorChange = false;
            this.ftLabel28.AutoSize = true;
            this.ftLabel28.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel28.ForeColor = System.Drawing.Color.Black;
            this.ftLabel28.Location = new System.Drawing.Point(596, 121);
            this.ftLabel28.Name = "ftLabel28";
            this.ftLabel28.OverrideDefault = false;
            this.ftLabel28.Size = new System.Drawing.Size(22, 12);
            this.ftLabel28.TabIndex = 35;
            // 
            // ftTextBox16
            // 
            this.ftTextBox16.AllowAlpha = true;
            this.ftTextBox16.AllowDot = false;
            this.ftTextBox16.AllowedCustomCharacters = null;
            this.ftTextBox16.AllowNonASCII = false;
            this.ftTextBox16.AllowNumeric = true;
            this.ftTextBox16.AllowSpace = false;
            this.ftTextBox16.AllowSpecialChars = true;
            this.ftTextBox16.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox16.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox16.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox16.IsEmailID = false;
            this.ftTextBox16.IsEmailIdValid = false;
            this.ftTextBox16.Location = new System.Drawing.Point(624, 117);
            this.ftTextBox16.MaxLength = 10;
            this.ftTextBox16.Name = "ftTextBox16";
            this.ftTextBox16.Size = new System.Drawing.Size(122, 20);
            this.ftTextBox16.TabIndex = 31;
            this.ftTextBox16.Tag = "Code";
            // 
            // ftLabel27
            // 
            this.ftLabel27.AllowForeColorChange = false;
            this.ftLabel27.AutoSize = true;
            this.ftLabel27.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel27.ForeColor = System.Drawing.Color.Black;
            this.ftLabel27.Location = new System.Drawing.Point(2, 153);
            this.ftLabel27.Name = "ftLabel27";
            this.ftLabel27.OverrideDefault = false;
            this.ftLabel27.Size = new System.Drawing.Size(34, 12);
            this.ftLabel27.TabIndex = 36;
            // 
            // ftTextBox15
            // 
            this.ftTextBox15.AllowAlpha = true;
            this.ftTextBox15.AllowDot = false;
            this.ftTextBox15.AllowedCustomCharacters = null;
            this.ftTextBox15.AllowNonASCII = false;
            this.ftTextBox15.AllowNumeric = true;
            this.ftTextBox15.AllowSpace = false;
            this.ftTextBox15.AllowSpecialChars = true;
            this.ftTextBox15.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox15.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox15.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox15.IsEmailID = false;
            this.ftTextBox15.IsEmailIdValid = false;
            this.ftTextBox15.Location = new System.Drawing.Point(49, 149);
            this.ftTextBox15.MaxLength = 10;
            this.ftTextBox15.Name = "ftTextBox15";
            this.ftTextBox15.Size = new System.Drawing.Size(140, 20);
            this.ftTextBox15.TabIndex = 32;
            this.ftTextBox15.Tag = "Code";
            // 
            // ftTextBox14
            // 
            this.ftTextBox14.AllowAlpha = true;
            this.ftTextBox14.AllowDot = false;
            this.ftTextBox14.AllowedCustomCharacters = null;
            this.ftTextBox14.AllowNonASCII = false;
            this.ftTextBox14.AllowNumeric = true;
            this.ftTextBox14.AllowSpace = false;
            this.ftTextBox14.AllowSpecialChars = true;
            this.ftTextBox14.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox14.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox14.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox14.IsEmailID = false;
            this.ftTextBox14.IsEmailIdValid = false;
            this.ftTextBox14.Location = new System.Drawing.Point(245, 149);
            this.ftTextBox14.MaxLength = 10;
            this.ftTextBox14.Name = "ftTextBox14";
            this.ftTextBox14.Size = new System.Drawing.Size(140, 20);
            this.ftTextBox14.TabIndex = 37;
            this.ftTextBox14.Tag = "Code";
            // 
            // ftTextBox13
            // 
            this.ftTextBox13.AllowAlpha = true;
            this.ftTextBox13.AllowDot = false;
            this.ftTextBox13.AllowedCustomCharacters = null;
            this.ftTextBox13.AllowNonASCII = false;
            this.ftTextBox13.AllowNumeric = true;
            this.ftTextBox13.AllowSpace = false;
            this.ftTextBox13.AllowSpecialChars = true;
            this.ftTextBox13.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox13.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox13.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox13.IsEmailID = false;
            this.ftTextBox13.IsEmailIdValid = false;
            this.ftTextBox13.Location = new System.Drawing.Point(439, 149);
            this.ftTextBox13.MaxLength = 10;
            this.ftTextBox13.Name = "ftTextBox13";
            this.ftTextBox13.Size = new System.Drawing.Size(140, 20);
            this.ftTextBox13.TabIndex = 39;
            this.ftTextBox13.Tag = "Code";
            // 
            // ftTextBox12
            // 
            this.ftTextBox12.AllowAlpha = true;
            this.ftTextBox12.AllowDot = false;
            this.ftTextBox12.AllowedCustomCharacters = null;
            this.ftTextBox12.AllowNonASCII = false;
            this.ftTextBox12.AllowNumeric = true;
            this.ftTextBox12.AllowSpace = false;
            this.ftTextBox12.AllowSpecialChars = true;
            this.ftTextBox12.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox12.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox12.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox12.IsEmailID = false;
            this.ftTextBox12.IsEmailIdValid = false;
            this.ftTextBox12.Location = new System.Drawing.Point(624, 149);
            this.ftTextBox12.MaxLength = 10;
            this.ftTextBox12.Name = "ftTextBox12";
            this.ftTextBox12.Size = new System.Drawing.Size(122, 20);
            this.ftTextBox12.TabIndex = 41;
            this.ftTextBox12.Tag = "Code";
            // 
            // ftLabel26
            // 
            this.ftLabel26.AllowForeColorChange = false;
            this.ftLabel26.AutoSize = true;
            this.ftLabel26.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel26.ForeColor = System.Drawing.Color.Black;
            this.ftLabel26.Location = new System.Drawing.Point(212, 153);
            this.ftLabel26.Name = "ftLabel26";
            this.ftLabel26.OverrideDefault = false;
            this.ftLabel26.Size = new System.Drawing.Size(26, 12);
            this.ftLabel26.TabIndex = 47;
            // 
            // ftLabel25
            // 
            this.ftLabel25.AllowForeColorChange = false;
            this.ftLabel25.AutoSize = true;
            this.ftLabel25.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel25.ForeColor = System.Drawing.Color.Black;
            this.ftLabel25.Location = new System.Drawing.Point(404, 154);
            this.ftLabel25.Name = "ftLabel25";
            this.ftLabel25.OverrideDefault = false;
            this.ftLabel25.Size = new System.Drawing.Size(26, 12);
            this.ftLabel25.TabIndex = 48;
            // 
            // ftLabel24
            // 
            this.ftLabel24.AllowForeColorChange = false;
            this.ftLabel24.AutoSize = true;
            this.ftLabel24.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel24.ForeColor = System.Drawing.Color.Black;
            this.ftLabel24.Location = new System.Drawing.Point(600, 152);
            this.ftLabel24.Name = "ftLabel24";
            this.ftLabel24.OverrideDefault = false;
            this.ftLabel24.Size = new System.Drawing.Size(21, 12);
            this.ftLabel24.TabIndex = 49;
            // 
            // lblAddressLine1
            // 
            this.lblAddressLine1.AllowForeColorChange = false;
            this.lblAddressLine1.AutoSize = true;
            this.lblAddressLine1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblAddressLine1.ForeColor = System.Drawing.Color.Black;
            this.lblAddressLine1.Location = new System.Drawing.Point(3, 29);
            this.lblAddressLine1.Name = "lblAddressLine1";
            this.lblAddressLine1.OverrideDefault = false;
            this.lblAddressLine1.Size = new System.Drawing.Size(41, 12);
            this.lblAddressLine1.TabIndex = 50;
            // 
            // ftTxtMail
            // 
            this.ftTxtMail.AllowAlpha = true;
            this.ftTxtMail.AllowDot = false;
            this.ftTxtMail.AllowedCustomCharacters = null;
            this.ftTxtMail.AllowNonASCII = false;
            this.ftTxtMail.AllowNumeric = true;
            this.ftTxtMail.AllowSpace = false;
            this.ftTxtMail.AllowSpecialChars = true;
            this.ftTxtMail.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtMail.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtMail.ForeColor = System.Drawing.Color.Black;
            this.ftTxtMail.IsEmailID = false;
            this.ftTxtMail.IsEmailIdValid = false;
            this.ftTxtMail.Location = new System.Drawing.Point(49, 87);
            this.ftTxtMail.MaxLength = 10;
            this.ftTxtMail.Name = "ftTxtMail";
            this.ftTxtMail.Size = new System.Drawing.Size(337, 20);
            this.ftTxtMail.TabIndex = 55;
            this.ftTxtMail.Tag = "Code";
            // 
            // ftLabel32
            // 
            this.ftLabel32.AllowForeColorChange = false;
            this.ftLabel32.AutoSize = true;
            this.ftLabel32.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel32.ForeColor = System.Drawing.Color.Black;
            this.ftLabel32.Location = new System.Drawing.Point(2, 90);
            this.ftLabel32.Name = "ftLabel32";
            this.ftLabel32.OverrideDefault = false;
            this.ftLabel32.Size = new System.Drawing.Size(32, 12);
            this.ftLabel32.TabIndex = 56;
            // 
            // ftTxtAddress1
            // 
            this.ftTxtAddress1.AllowAlpha = true;
            this.ftTxtAddress1.AllowDot = false;
            this.ftTxtAddress1.AllowedCustomCharacters = null;
            this.ftTxtAddress1.AllowNonASCII = false;
            this.ftTxtAddress1.AllowNumeric = true;
            this.ftTxtAddress1.AllowSpace = false;
            this.ftTxtAddress1.AllowSpecialChars = true;
            this.ftTxtAddress1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtAddress1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtAddress1.ForeColor = System.Drawing.Color.Black;
            this.ftTxtAddress1.IsEmailID = false;
            this.ftTxtAddress1.IsEmailIdValid = false;
            this.ftTxtAddress1.Location = new System.Drawing.Point(49, 25);
            this.ftTxtAddress1.MaxLength = 10;
            this.ftTxtAddress1.Name = "ftTxtAddress1";
            this.ftTxtAddress1.Size = new System.Drawing.Size(337, 20);
            this.ftTxtAddress1.TabIndex = 57;
            this.ftTxtAddress1.Tag = "Code";
            // 
            // ftTxtAddress3
            // 
            this.ftTxtAddress3.AllowAlpha = true;
            this.ftTxtAddress3.AllowDot = false;
            this.ftTxtAddress3.AllowedCustomCharacters = null;
            this.ftTxtAddress3.AllowNonASCII = false;
            this.ftTxtAddress3.AllowNumeric = true;
            this.ftTxtAddress3.AllowSpace = false;
            this.ftTxtAddress3.AllowSpecialChars = true;
            this.ftTxtAddress3.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtAddress3.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtAddress3.ForeColor = System.Drawing.Color.Black;
            this.ftTxtAddress3.IsEmailID = false;
            this.ftTxtAddress3.IsEmailIdValid = false;
            this.ftTxtAddress3.Location = new System.Drawing.Point(49, 56);
            this.ftTxtAddress3.MaxLength = 10;
            this.ftTxtAddress3.Name = "ftTxtAddress3";
            this.ftTxtAddress3.Size = new System.Drawing.Size(337, 20);
            this.ftTxtAddress3.TabIndex = 58;
            this.ftTxtAddress3.Tag = "Code";
            // 
            // ftTxtAddress2
            // 
            this.ftTxtAddress2.AllowAlpha = true;
            this.ftTxtAddress2.AllowDot = false;
            this.ftTxtAddress2.AllowedCustomCharacters = null;
            this.ftTxtAddress2.AllowNonASCII = false;
            this.ftTxtAddress2.AllowNumeric = true;
            this.ftTxtAddress2.AllowSpace = false;
            this.ftTxtAddress2.AllowSpecialChars = true;
            this.ftTxtAddress2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtAddress2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtAddress2.ForeColor = System.Drawing.Color.Black;
            this.ftTxtAddress2.IsEmailID = false;
            this.ftTxtAddress2.IsEmailIdValid = false;
            this.ftTxtAddress2.Location = new System.Drawing.Point(392, 25);
            this.ftTxtAddress2.MaxLength = 10;
            this.ftTxtAddress2.Name = "ftTxtAddress2";
            this.ftTxtAddress2.Size = new System.Drawing.Size(353, 20);
            this.ftTxtAddress2.TabIndex = 59;
            this.ftTxtAddress2.Tag = "Code";
            // 
            // ftTxtAddress4
            // 
            this.ftTxtAddress4.AllowAlpha = true;
            this.ftTxtAddress4.AllowDot = false;
            this.ftTxtAddress4.AllowedCustomCharacters = null;
            this.ftTxtAddress4.AllowNonASCII = false;
            this.ftTxtAddress4.AllowNumeric = true;
            this.ftTxtAddress4.AllowSpace = false;
            this.ftTxtAddress4.AllowSpecialChars = true;
            this.ftTxtAddress4.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtAddress4.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtAddress4.ForeColor = System.Drawing.Color.Black;
            this.ftTxtAddress4.IsEmailID = false;
            this.ftTxtAddress4.IsEmailIdValid = false;
            this.ftTxtAddress4.Location = new System.Drawing.Point(392, 56);
            this.ftTxtAddress4.MaxLength = 10;
            this.ftTxtAddress4.Name = "ftTxtAddress4";
            this.ftTxtAddress4.Size = new System.Drawing.Size(353, 20);
            this.ftTxtAddress4.TabIndex = 60;
            this.ftTxtAddress4.Tag = "Code";
            // 
            // ftCheckBox1
            // 
            this.ftCheckBox1.AutoSize = true;
            this.ftCheckBox1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftCheckBox1.ForeColor = System.Drawing.Color.Black;
            this.ftCheckBox1.Location = new System.Drawing.Point(206, 0);
            this.ftCheckBox1.Name = "ftCheckBox1";
            this.ftCheckBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ftCheckBox1.Size = new System.Drawing.Size(15, 14);
            this.ftCheckBox1.TabIndex = 41;
            this.ftCheckBox1.UseVisualStyleBackColor = true;
            // 
            // ftLabel13
            // 
            this.ftLabel13.AllowForeColorChange = false;
            this.ftLabel13.AutoSize = true;
            this.ftLabel13.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel13.ForeColor = System.Drawing.Color.Black;
            this.ftLabel13.Location = new System.Drawing.Point(223, 0);
            this.ftLabel13.Name = "ftLabel13";
            this.ftLabel13.OverrideDefault = false;
            this.ftLabel13.Size = new System.Drawing.Size(72, 12);
            this.ftLabel13.TabIndex = 47;
            // 
            // ftComboBox3
            // 
            this.ftComboBox3.BackColor = System.Drawing.Color.White;
            this.ftComboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftComboBox3.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftComboBox3.ForeColor = System.Drawing.Color.Black;
            this.ftComboBox3.FormattingEnabled = true;
            this.ftComboBox3.Location = new System.Drawing.Point(51, 115);
            this.ftComboBox3.Name = "ftComboBox3";
            this.ftComboBox3.ReadOnly = false;
            this.ftComboBox3.Size = new System.Drawing.Size(140, 20);
            this.ftComboBox3.TabIndex = 57;
            // 
            // ftLabel10
            // 
            this.ftLabel10.AllowForeColorChange = false;
            this.ftLabel10.AutoSize = true;
            this.ftLabel10.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel10.ForeColor = System.Drawing.Color.Black;
            this.ftLabel10.Location = new System.Drawing.Point(5, 118);
            this.ftLabel10.Name = "ftLabel10";
            this.ftLabel10.OverrideDefault = false;
            this.ftLabel10.Size = new System.Drawing.Size(43, 12);
            this.ftLabel10.TabIndex = 60;
            // 
            // ftLabel9
            // 
            this.ftLabel9.AllowForeColorChange = false;
            this.ftLabel9.AutoSize = true;
            this.ftLabel9.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel9.ForeColor = System.Drawing.Color.Black;
            this.ftLabel9.Location = new System.Drawing.Point(214, 118);
            this.ftLabel9.Name = "ftLabel9";
            this.ftLabel9.OverrideDefault = false;
            this.ftLabel9.Size = new System.Drawing.Size(27, 12);
            this.ftLabel9.TabIndex = 61;
            // 
            // ftComboBox2
            // 
            this.ftComboBox2.BackColor = System.Drawing.Color.White;
            this.ftComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftComboBox2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftComboBox2.ForeColor = System.Drawing.Color.Black;
            this.ftComboBox2.FormattingEnabled = true;
            this.ftComboBox2.Location = new System.Drawing.Point(247, 115);
            this.ftComboBox2.Name = "ftComboBox2";
            this.ftComboBox2.ReadOnly = false;
            this.ftComboBox2.Size = new System.Drawing.Size(140, 20);
            this.ftComboBox2.TabIndex = 58;
            // 
            // ftLabel8
            // 
            this.ftLabel8.AllowForeColorChange = false;
            this.ftLabel8.AutoSize = true;
            this.ftLabel8.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel8.ForeColor = System.Drawing.Color.Black;
            this.ftLabel8.Location = new System.Drawing.Point(406, 118);
            this.ftLabel8.Name = "ftLabel8";
            this.ftLabel8.OverrideDefault = false;
            this.ftLabel8.Size = new System.Drawing.Size(23, 12);
            this.ftLabel8.TabIndex = 64;
            // 
            // ftComboBox1
            // 
            this.ftComboBox1.BackColor = System.Drawing.Color.White;
            this.ftComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftComboBox1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftComboBox1.ForeColor = System.Drawing.Color.Black;
            this.ftComboBox1.FormattingEnabled = true;
            this.ftComboBox1.Location = new System.Drawing.Point(441, 115);
            this.ftComboBox1.Name = "ftComboBox1";
            this.ftComboBox1.ReadOnly = false;
            this.ftComboBox1.Size = new System.Drawing.Size(140, 20);
            this.ftComboBox1.TabIndex = 63;
            // 
            // ftLabel7
            // 
            this.ftLabel7.AllowForeColorChange = false;
            this.ftLabel7.AutoSize = true;
            this.ftLabel7.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel7.ForeColor = System.Drawing.Color.Black;
            this.ftLabel7.Location = new System.Drawing.Point(598, 118);
            this.ftLabel7.Name = "ftLabel7";
            this.ftLabel7.OverrideDefault = false;
            this.ftLabel7.Size = new System.Drawing.Size(22, 12);
            this.ftLabel7.TabIndex = 65;
            // 
            // ftTextBox18
            // 
            this.ftTextBox18.AllowAlpha = true;
            this.ftTextBox18.AllowDot = false;
            this.ftTextBox18.AllowedCustomCharacters = null;
            this.ftTextBox18.AllowNonASCII = false;
            this.ftTextBox18.AllowNumeric = true;
            this.ftTextBox18.AllowSpace = false;
            this.ftTextBox18.AllowSpecialChars = true;
            this.ftTextBox18.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox18.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox18.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox18.IsEmailID = false;
            this.ftTextBox18.IsEmailIdValid = false;
            this.ftTextBox18.Location = new System.Drawing.Point(626, 114);
            this.ftTextBox18.MaxLength = 10;
            this.ftTextBox18.Name = "ftTextBox18";
            this.ftTextBox18.Size = new System.Drawing.Size(122, 20);
            this.ftTextBox18.TabIndex = 59;
            this.ftTextBox18.Tag = "Code";
            // 
            // ftLabel6
            // 
            this.ftLabel6.AllowForeColorChange = false;
            this.ftLabel6.AutoSize = true;
            this.ftLabel6.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel6.ForeColor = System.Drawing.Color.Black;
            this.ftLabel6.Location = new System.Drawing.Point(4, 150);
            this.ftLabel6.Name = "ftLabel6";
            this.ftLabel6.OverrideDefault = false;
            this.ftLabel6.Size = new System.Drawing.Size(34, 12);
            this.ftLabel6.TabIndex = 66;
            // 
            // ftTextBox11
            // 
            this.ftTextBox11.AllowAlpha = true;
            this.ftTextBox11.AllowDot = false;
            this.ftTextBox11.AllowedCustomCharacters = null;
            this.ftTextBox11.AllowNonASCII = false;
            this.ftTextBox11.AllowNumeric = true;
            this.ftTextBox11.AllowSpace = false;
            this.ftTextBox11.AllowSpecialChars = true;
            this.ftTextBox11.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox11.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox11.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox11.IsEmailID = false;
            this.ftTextBox11.IsEmailIdValid = false;
            this.ftTextBox11.Location = new System.Drawing.Point(51, 146);
            this.ftTextBox11.MaxLength = 10;
            this.ftTextBox11.Name = "ftTextBox11";
            this.ftTextBox11.Size = new System.Drawing.Size(140, 20);
            this.ftTextBox11.TabIndex = 62;
            this.ftTextBox11.Tag = "Code";
            // 
            // ftTextBox10
            // 
            this.ftTextBox10.AllowAlpha = true;
            this.ftTextBox10.AllowDot = false;
            this.ftTextBox10.AllowedCustomCharacters = null;
            this.ftTextBox10.AllowNonASCII = false;
            this.ftTextBox10.AllowNumeric = true;
            this.ftTextBox10.AllowSpace = false;
            this.ftTextBox10.AllowSpecialChars = true;
            this.ftTextBox10.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox10.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox10.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox10.IsEmailID = false;
            this.ftTextBox10.IsEmailIdValid = false;
            this.ftTextBox10.Location = new System.Drawing.Point(247, 146);
            this.ftTextBox10.MaxLength = 10;
            this.ftTextBox10.Name = "ftTextBox10";
            this.ftTextBox10.Size = new System.Drawing.Size(140, 20);
            this.ftTextBox10.TabIndex = 67;
            this.ftTextBox10.Tag = "Code";
            // 
            // ftTextBox9
            // 
            this.ftTextBox9.AllowAlpha = true;
            this.ftTextBox9.AllowDot = false;
            this.ftTextBox9.AllowedCustomCharacters = null;
            this.ftTextBox9.AllowNonASCII = false;
            this.ftTextBox9.AllowNumeric = true;
            this.ftTextBox9.AllowSpace = false;
            this.ftTextBox9.AllowSpecialChars = true;
            this.ftTextBox9.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox9.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox9.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox9.IsEmailID = false;
            this.ftTextBox9.IsEmailIdValid = false;
            this.ftTextBox9.Location = new System.Drawing.Point(441, 146);
            this.ftTextBox9.MaxLength = 10;
            this.ftTextBox9.Name = "ftTextBox9";
            this.ftTextBox9.Size = new System.Drawing.Size(140, 20);
            this.ftTextBox9.TabIndex = 68;
            this.ftTextBox9.Tag = "Code";
            // 
            // ftTextBox8
            // 
            this.ftTextBox8.AllowAlpha = true;
            this.ftTextBox8.AllowDot = false;
            this.ftTextBox8.AllowedCustomCharacters = null;
            this.ftTextBox8.AllowNonASCII = false;
            this.ftTextBox8.AllowNumeric = true;
            this.ftTextBox8.AllowSpace = false;
            this.ftTextBox8.AllowSpecialChars = true;
            this.ftTextBox8.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox8.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox8.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox8.IsEmailID = false;
            this.ftTextBox8.IsEmailIdValid = false;
            this.ftTextBox8.Location = new System.Drawing.Point(626, 146);
            this.ftTextBox8.MaxLength = 10;
            this.ftTextBox8.Name = "ftTextBox8";
            this.ftTextBox8.Size = new System.Drawing.Size(122, 20);
            this.ftTextBox8.TabIndex = 69;
            this.ftTextBox8.Tag = "Code";
            // 
            // ftLabel5
            // 
            this.ftLabel5.AllowForeColorChange = false;
            this.ftLabel5.AutoSize = true;
            this.ftLabel5.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel5.ForeColor = System.Drawing.Color.Black;
            this.ftLabel5.Location = new System.Drawing.Point(214, 150);
            this.ftLabel5.Name = "ftLabel5";
            this.ftLabel5.OverrideDefault = false;
            this.ftLabel5.Size = new System.Drawing.Size(26, 12);
            this.ftLabel5.TabIndex = 70;
            // 
            // ftLabel4
            // 
            this.ftLabel4.AllowForeColorChange = false;
            this.ftLabel4.AutoSize = true;
            this.ftLabel4.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel4.ForeColor = System.Drawing.Color.Black;
            this.ftLabel4.Location = new System.Drawing.Point(406, 151);
            this.ftLabel4.Name = "ftLabel4";
            this.ftLabel4.OverrideDefault = false;
            this.ftLabel4.Size = new System.Drawing.Size(26, 12);
            this.ftLabel4.TabIndex = 71;
            // 
            // ftLabel3
            // 
            this.ftLabel3.AllowForeColorChange = false;
            this.ftLabel3.AutoSize = true;
            this.ftLabel3.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel3.ForeColor = System.Drawing.Color.Black;
            this.ftLabel3.Location = new System.Drawing.Point(602, 149);
            this.ftLabel3.Name = "ftLabel3";
            this.ftLabel3.OverrideDefault = false;
            this.ftLabel3.Size = new System.Drawing.Size(21, 12);
            this.ftLabel3.TabIndex = 72;
            // 
            // ftLabel2
            // 
            this.ftLabel2.AllowForeColorChange = false;
            this.ftLabel2.AutoSize = true;
            this.ftLabel2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel2.ForeColor = System.Drawing.Color.Black;
            this.ftLabel2.Location = new System.Drawing.Point(5, 26);
            this.ftLabel2.Name = "ftLabel2";
            this.ftLabel2.OverrideDefault = false;
            this.ftLabel2.Size = new System.Drawing.Size(41, 12);
            this.ftLabel2.TabIndex = 73;
            // 
            // ftTxtMail2
            // 
            this.ftTxtMail2.AllowAlpha = true;
            this.ftTxtMail2.AllowDot = false;
            this.ftTxtMail2.AllowedCustomCharacters = null;
            this.ftTxtMail2.AllowNonASCII = false;
            this.ftTxtMail2.AllowNumeric = true;
            this.ftTxtMail2.AllowSpace = false;
            this.ftTxtMail2.AllowSpecialChars = true;
            this.ftTxtMail2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtMail2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtMail2.ForeColor = System.Drawing.Color.Black;
            this.ftTxtMail2.IsEmailID = false;
            this.ftTxtMail2.IsEmailIdValid = false;
            this.ftTxtMail2.Location = new System.Drawing.Point(51, 84);
            this.ftTxtMail2.MaxLength = 10;
            this.ftTxtMail2.Name = "ftTxtMail2";
            this.ftTxtMail2.Size = new System.Drawing.Size(337, 20);
            this.ftTxtMail2.TabIndex = 78;
            this.ftTxtMail2.Tag = "Code";
            // 
            // ftLabel1
            // 
            this.ftLabel1.AllowForeColorChange = false;
            this.ftLabel1.AutoSize = true;
            this.ftLabel1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel1.ForeColor = System.Drawing.Color.Black;
            this.ftLabel1.Location = new System.Drawing.Point(4, 87);
            this.ftLabel1.Name = "ftLabel1";
            this.ftLabel1.OverrideDefault = false;
            this.ftLabel1.Size = new System.Drawing.Size(32, 12);
            this.ftLabel1.TabIndex = 79;
            // 
            // ftTxtAddress21
            // 
            this.ftTxtAddress21.AllowAlpha = true;
            this.ftTxtAddress21.AllowDot = false;
            this.ftTxtAddress21.AllowedCustomCharacters = null;
            this.ftTxtAddress21.AllowNonASCII = false;
            this.ftTxtAddress21.AllowNumeric = true;
            this.ftTxtAddress21.AllowSpace = false;
            this.ftTxtAddress21.AllowSpecialChars = true;
            this.ftTxtAddress21.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtAddress21.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtAddress21.ForeColor = System.Drawing.Color.Black;
            this.ftTxtAddress21.IsEmailID = false;
            this.ftTxtAddress21.IsEmailIdValid = false;
            this.ftTxtAddress21.Location = new System.Drawing.Point(51, 23);
            this.ftTxtAddress21.MaxLength = 10;
            this.ftTxtAddress21.Name = "ftTxtAddress21";
            this.ftTxtAddress21.Size = new System.Drawing.Size(337, 20);
            this.ftTxtAddress21.TabIndex = 80;
            this.ftTxtAddress21.Tag = "Code";
            // 
            // ftTxtAddress23
            // 
            this.ftTxtAddress23.AllowAlpha = true;
            this.ftTxtAddress23.AllowDot = false;
            this.ftTxtAddress23.AllowedCustomCharacters = null;
            this.ftTxtAddress23.AllowNonASCII = false;
            this.ftTxtAddress23.AllowNumeric = true;
            this.ftTxtAddress23.AllowSpace = false;
            this.ftTxtAddress23.AllowSpecialChars = true;
            this.ftTxtAddress23.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtAddress23.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtAddress23.ForeColor = System.Drawing.Color.Black;
            this.ftTxtAddress23.IsEmailID = false;
            this.ftTxtAddress23.IsEmailIdValid = false;
            this.ftTxtAddress23.Location = new System.Drawing.Point(51, 54);
            this.ftTxtAddress23.MaxLength = 10;
            this.ftTxtAddress23.Name = "ftTxtAddress23";
            this.ftTxtAddress23.Size = new System.Drawing.Size(337, 20);
            this.ftTxtAddress23.TabIndex = 81;
            this.ftTxtAddress23.Tag = "Code";
            // 
            // ftTxtAddress22
            // 
            this.ftTxtAddress22.AllowAlpha = true;
            this.ftTxtAddress22.AllowDot = false;
            this.ftTxtAddress22.AllowedCustomCharacters = null;
            this.ftTxtAddress22.AllowNonASCII = false;
            this.ftTxtAddress22.AllowNumeric = true;
            this.ftTxtAddress22.AllowSpace = false;
            this.ftTxtAddress22.AllowSpecialChars = true;
            this.ftTxtAddress22.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtAddress22.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtAddress22.ForeColor = System.Drawing.Color.Black;
            this.ftTxtAddress22.IsEmailID = false;
            this.ftTxtAddress22.IsEmailIdValid = false;
            this.ftTxtAddress22.Location = new System.Drawing.Point(394, 24);
            this.ftTxtAddress22.MaxLength = 10;
            this.ftTxtAddress22.Name = "ftTxtAddress22";
            this.ftTxtAddress22.Size = new System.Drawing.Size(353, 20);
            this.ftTxtAddress22.TabIndex = 82;
            this.ftTxtAddress22.Tag = "Code";
            // 
            // ftTxtAddress24
            // 
            this.ftTxtAddress24.AllowAlpha = true;
            this.ftTxtAddress24.AllowDot = false;
            this.ftTxtAddress24.AllowedCustomCharacters = null;
            this.ftTxtAddress24.AllowNonASCII = false;
            this.ftTxtAddress24.AllowNumeric = true;
            this.ftTxtAddress24.AllowSpace = false;
            this.ftTxtAddress24.AllowSpecialChars = true;
            this.ftTxtAddress24.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtAddress24.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtAddress24.ForeColor = System.Drawing.Color.Black;
            this.ftTxtAddress24.IsEmailID = false;
            this.ftTxtAddress24.IsEmailIdValid = false;
            this.ftTxtAddress24.Location = new System.Drawing.Point(394, 55);
            this.ftTxtAddress24.MaxLength = 10;
            this.ftTxtAddress24.Name = "ftTxtAddress24";
            this.ftTxtAddress24.Size = new System.Drawing.Size(353, 20);
            this.ftTxtAddress24.TabIndex = 83;
            this.ftTxtAddress24.Tag = "Code";
            // 
            // ucEntityNonInd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.ftLabel78);
            this.Controls.Add(this.tbEntity);
            this.Controls.Add(this.btnApply);
            this.Controls.Add(this.lblMobileNo);
            this.Controls.Add(this.ftlblEntityCode);
            this.Controls.Add(this.lblHeading);
            this.Controls.Add(this.txtNameHead);
            this.Controls.Add(this.txtEntityCode);
            this.Name = "ucEntityNonInd";
            this.Size = new System.Drawing.Size(798, 696);
            this.tbEntity.ResumeLayout(false);
            this.tbAccount.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tbOthers.ResumeLayout(false);
            this.tbOthers.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.DocUpload.ResumeLayout(false);
            this.DocUpload.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MatchCommon.CustomControls.FTLabel ftLabel78;
        private System.Windows.Forms.TabControl tbEntity;
        private System.Windows.Forms.TabPage tbOthers;
        private MatchCommon.CustomControls.FTLabel ftLabel53;
        private System.Windows.Forms.TabPage DocUpload;
        private System.Windows.Forms.TabPage tabPage1;
        private MatchCommon.CustomControls.FTButton btnApply;
        private MatchCommon.CustomControls.FTLabel lblMobileNo;
        private MatchCommon.CustomControls.FTLabel ftlblEntityCode;
        private System.Windows.Forms.Label lblHeading;
        private System.Windows.Forms.TextBox txtNameHead;
        private System.Windows.Forms.TextBox txtEntityCode;
        private System.Windows.Forms.TabPage tbAccount;
        private System.Windows.Forms.GroupBox groupBox1;
        private MatchCommon.CustomControls.FTTextBox ftTxtCIN;
        private MatchCommon.CustomControls.FTLabel ftLabel34;
        private MatchCommon.CustomControls.FTLabel ftLabel11;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private MatchCommon.CustomControls.FTTextBox ftTxtPAN;
        private MatchCommon.CustomControls.FTLabel ftLabel15;
        private MatchCommon.CustomControls.FTComboBox ftCmbSattus;
        private MatchCommon.CustomControls.FTLabel ftLabel12;
        private System.Windows.Forms.DateTimePicker dateTimePicker7;
        private MatchCommon.CustomControls.FTLabel ftLabel16;
        private MatchCommon.CustomControls.FTLabel ftLabel14;
        private MatchCommon.CustomControls.FTTextBox ftTxtStatus;
        private MatchCommon.CustomControls.FTTextBox ftTxtPoI;
        private MatchCommon.CustomControls.FTComboBox ftComboBox6;
        private MatchCommon.CustomControls.FTLabel ftLabel31;
        private MatchCommon.CustomControls.FTLabel ftLabel30;
        private MatchCommon.CustomControls.FTComboBox ftComboBox5;
        private MatchCommon.CustomControls.FTLabel ftLabel29;
        private MatchCommon.CustomControls.FTComboBox ftComboBox4;
        private MatchCommon.CustomControls.FTLabel ftLabel28;
        private MatchCommon.CustomControls.FTTextBox ftTextBox16;
        private MatchCommon.CustomControls.FTLabel ftLabel27;
        private MatchCommon.CustomControls.FTTextBox ftTextBox15;
        private MatchCommon.CustomControls.FTTextBox ftTextBox14;
        private MatchCommon.CustomControls.FTTextBox ftTextBox13;
        private MatchCommon.CustomControls.FTTextBox ftTextBox12;
        private MatchCommon.CustomControls.FTLabel ftLabel26;
        private MatchCommon.CustomControls.FTLabel ftLabel25;
        private MatchCommon.CustomControls.FTLabel ftLabel24;
        private MatchCommon.CustomControls.FTLabel lblAddressLine1;
        private MatchCommon.CustomControls.FTTextBox ftTxtMail;
        private MatchCommon.CustomControls.FTLabel ftLabel32;
        private MatchCommon.CustomControls.FTTextBox ftTxtAddress1;
        private MatchCommon.CustomControls.FTTextBox ftTxtAddress3;
        private MatchCommon.CustomControls.FTTextBox ftTxtAddress2;
        private MatchCommon.CustomControls.FTTextBox ftTxtAddress4;
        private MatchCommon.CustomControls.FTCheckBox ftCheckBox1;
        private MatchCommon.CustomControls.FTLabel ftLabel13;
        private MatchCommon.CustomControls.FTComboBox ftComboBox3;
        private MatchCommon.CustomControls.FTLabel ftLabel10;
        private MatchCommon.CustomControls.FTLabel ftLabel9;
        private MatchCommon.CustomControls.FTComboBox ftComboBox2;
        private MatchCommon.CustomControls.FTLabel ftLabel8;
        private MatchCommon.CustomControls.FTComboBox ftComboBox1;
        private MatchCommon.CustomControls.FTLabel ftLabel7;
        private MatchCommon.CustomControls.FTTextBox ftTextBox18;
        private MatchCommon.CustomControls.FTLabel ftLabel6;
        private MatchCommon.CustomControls.FTTextBox ftTextBox11;
        private MatchCommon.CustomControls.FTTextBox ftTextBox10;
        private MatchCommon.CustomControls.FTTextBox ftTextBox9;
        private MatchCommon.CustomControls.FTTextBox ftTextBox8;
        private MatchCommon.CustomControls.FTLabel ftLabel5;
        private MatchCommon.CustomControls.FTLabel ftLabel4;
        private MatchCommon.CustomControls.FTLabel ftLabel3;
        private MatchCommon.CustomControls.FTLabel ftLabel2;
        private MatchCommon.CustomControls.FTTextBox ftTxtMail2;
        private MatchCommon.CustomControls.FTLabel ftLabel1;
        private MatchCommon.CustomControls.FTTextBox ftTxtAddress21;
        private MatchCommon.CustomControls.FTTextBox ftTxtAddress23;
        private MatchCommon.CustomControls.FTTextBox ftTxtAddress22;
        private MatchCommon.CustomControls.FTTextBox ftTxtAddress24;
        private System.Windows.Forms.GroupBox groupBox3;
        private MatchCommon.CustomControls.FTTextBox ftTextBox1;
        private MatchCommon.CustomControls.FTTextBox ftTextBox2;
        private MatchCommon.CustomControls.FTTextBox ftTextBox3;
        private MatchCommon.CustomControls.FTTextBox ftTextBox4;
        private MatchCommon.CustomControls.FTLabel ftLabel17;
        private MatchCommon.CustomControls.FTTextBox ftTextBox5;
        private MatchCommon.CustomControls.FTLabel ftLabel18;
        private MatchCommon.CustomControls.FTLabel ftLabel19;
        private MatchCommon.CustomControls.FTLabel ftLabel20;
        private MatchCommon.CustomControls.FTLabel ftLabel21;
        private MatchCommon.CustomControls.FTTextBox ftTextBox6;
        private MatchCommon.CustomControls.FTTextBox ftTextBox7;
        private MatchCommon.CustomControls.FTTextBox ftTextBox17;
        private MatchCommon.CustomControls.FTTextBox ftTextBox19;
        private MatchCommon.CustomControls.FTLabel ftLabel22;
        private MatchCommon.CustomControls.FTTextBox ftTextBox20;
        private MatchCommon.CustomControls.FTLabel ftLabel23;
        private MatchCommon.CustomControls.FTComboBox ftComboBox7;
        private MatchCommon.CustomControls.FTLabel ftLabel33;
        private MatchCommon.CustomControls.FTComboBox ftComboBox9;
        private MatchCommon.CustomControls.FTLabel ftLabel35;
        private MatchCommon.CustomControls.FTLabel ftLabel36;
        private MatchCommon.CustomControls.FTComboBox ftComboBox10;
        private MatchCommon.CustomControls.FTLabel ftLabel37;
        private MatchCommon.CustomControls.FTCheckBox ftCheckBox2;
        private System.Windows.Forms.GroupBox groupBox2;
        private MatchCommon.CustomControls.FTTextBox ftTextBox21;
        private MatchCommon.CustomControls.FTTextBox ftTextBox22;
        private MatchCommon.CustomControls.FTTextBox ftTextBox23;
        private MatchCommon.CustomControls.FTTextBox ftTextBox24;
        private MatchCommon.CustomControls.FTLabel ftLabel38;
        private MatchCommon.CustomControls.FTTextBox ftTextBox28;
        private MatchCommon.CustomControls.FTLabel ftLabel48;
        private MatchCommon.CustomControls.FTLabel ftLabel49;
        private MatchCommon.CustomControls.FTLabel ftLabel50;
        private MatchCommon.CustomControls.FTLabel ftLabel51;
        private MatchCommon.CustomControls.FTTextBox ftTextBox29;
        private MatchCommon.CustomControls.FTTextBox ftTextBox30;
        private MatchCommon.CustomControls.FTTextBox ftTextBox31;
        private MatchCommon.CustomControls.FTTextBox ftTextBox32;
        private MatchCommon.CustomControls.FTLabel ftLabel52;
        private MatchCommon.CustomControls.FTTextBox ftTextBox33;
        private MatchCommon.CustomControls.FTLabel ftLabel55;
        private MatchCommon.CustomControls.FTComboBox ftComboBox11;
        private MatchCommon.CustomControls.FTLabel ftLabel56;
        private MatchCommon.CustomControls.FTComboBox ftComboBox12;
        private MatchCommon.CustomControls.FTLabel ftLabel57;
        private MatchCommon.CustomControls.FTLabel ftLabel58;
        private MatchCommon.CustomControls.FTComboBox ftComboBox13;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private MatchCommon.CustomControls.FTLabel ftlblDOB;
        private MatchCommon.CustomControls.FTTextBox txtStatus;
        private MatchCommon.CustomControls.FTLabel ftLabel63;
        private MatchCommon.CustomControls.FTComboBox ftCmbStatus;
        private MatchCommon.CustomControls.FTTextBox txtPAN;
        private MatchCommon.CustomControls.FTLabel ftLabel62;
        private System.Windows.Forms.DateTimePicker dateTimePicker9;
        private MatchCommon.CustomControls.FTLabel ftLabel61;
        private MatchCommon.CustomControls.FTTextBox ftTxtCINNo;
        private MatchCommon.CustomControls.FTLabel ftLabel60;
        private MatchCommon.CustomControls.FTLabel ftLabel59;
        private MatchCommon.CustomControls.FTTextBox ftTextBox34;
        private MatchCommon.CustomControls.FTLabel ftCreated;
        private System.Windows.Forms.DateTimePicker dateTimePicker8;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Relationship;
        private System.Windows.Forms.DataGridViewTextBoxColumn Address;
        private MatchCommon.CustomControls.FTLabel ftLabel74;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.GroupBox groupBox4;
        private MatchCommon.CustomControls.FTTextBox ftTextBox35;
        private MatchCommon.CustomControls.FTTextBox ftTextBox36;
        private MatchCommon.CustomControls.FTTextBox ftTextBox37;
        private MatchCommon.CustomControls.FTTextBox ftTextBox38;
        private MatchCommon.CustomControls.FTLabel ftLabel64;
        private MatchCommon.CustomControls.FTTextBox ftTextBox39;
        private MatchCommon.CustomControls.FTLabel ftLabel65;
        private MatchCommon.CustomControls.FTLabel ftLabel66;
        private MatchCommon.CustomControls.FTLabel ftLabel67;
        private MatchCommon.CustomControls.FTLabel ftLabel68;
        private MatchCommon.CustomControls.FTTextBox ftTextBox40;
        private MatchCommon.CustomControls.FTTextBox ftTextBox41;
        private MatchCommon.CustomControls.FTTextBox ftTextBox42;
        private MatchCommon.CustomControls.FTTextBox ftTextBox43;
        private MatchCommon.CustomControls.FTLabel ftLabel69;
        private MatchCommon.CustomControls.FTTextBox ftTextBox44;
        private MatchCommon.CustomControls.FTLabel ftLabel70;
        private MatchCommon.CustomControls.FTComboBox ftComboBox14;
        private MatchCommon.CustomControls.FTLabel ftLabel71;
        private MatchCommon.CustomControls.FTComboBox ftComboBox15;
        private MatchCommon.CustomControls.FTLabel ftLabel72;
        private MatchCommon.CustomControls.FTLabel ftLabel73;
        private MatchCommon.CustomControls.FTComboBox ftComboBox16;
        private MatchCommon.CustomControls.FTLabel ftLabel54;
        private MatchCommon.CustomControls.FTTextBox ftTxtUserId;
        private MatchCommon.CustomControls.FTTextBox ftTxtPEP;
        private MatchCommon.CustomControls.FTTextBox ftTxtOccupation;
        private MatchCommon.CustomControls.FTLabel ftLabel39;
        private MatchCommon.CustomControls.FTComboBox ftCmbPEP;
        private MatchCommon.CustomControls.FTLabel ftLabel40;
        private MatchCommon.CustomControls.FTComboBox ftCmbOccupation;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.DateTimePicker dateTimePicker6;
        private MatchCommon.CustomControls.FTComboBox ftCmbGrossAnnual;
        private System.Windows.Forms.DateTimePicker dateTimePicker5;
        private MatchCommon.CustomControls.FTTextBox ftTextBox25;
        private MatchCommon.CustomControls.FTLabel ftLabel41;
        private MatchCommon.CustomControls.FTLabel ftLabel42;
        private System.Windows.Forms.GroupBox groupBox6;
        private MatchCommon.CustomControls.FTLabel ftLabel43;
        private System.Windows.Forms.DateTimePicker dateTimePicker4;
        private MatchCommon.CustomControls.FTLabel ftLabel44;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private MatchCommon.CustomControls.FTLabel ftLabel45;
        private MatchCommon.CustomControls.FTLabel ftLabel46;
        private MatchCommon.CustomControls.FTLabel ftLabel47;
        private MatchCommon.CustomControls.FTTextBox ftTextBox26;
        private MatchCommon.CustomControls.FTTextBox ftTextBox27;
        private MatchCommon.CustomControls.FTComboBox ftComboBox8;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private MatchCommon.CustomControls.FTLabel ftLabel77;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date;
        private System.Windows.Forms.GroupBox groupBox11;
        private MatchCommon.CustomControls.FTLabel ftLabel81;
        private MatchCommon.CustomControls.FTComboBox ftCmbTypeofDocument;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.CheckBox chkProtector;
        private System.Windows.Forms.CheckBox chkMatch;
        private System.Windows.Forms.CheckBox chkDP;
        private System.Windows.Forms.CheckBox chkODIN;
        private MatchCommon.CustomControls.FTButton ftBtnSaveIdentity;
        private MatchCommon.CustomControls.FTButton btnDelete;
        private MatchCommon.CustomControls.FTButton btnAdd;
        private MatchCommon.CustomControls.FTButton ftBtnRemoveDoc;
        private System.Windows.Forms.Button btnImport;
    }
}
