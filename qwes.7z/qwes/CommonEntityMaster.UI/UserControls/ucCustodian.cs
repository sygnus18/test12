﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FTIL.Match.CDD.BAL;
using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.CDD.UI.Forms;
using FTIL.Match.Common.Log;
using FTIL.Match.Common;
using UCC.Class;
using C1.Win.C1FlexGrid;
using FTIL.MATCH.CDD.UI.Class;

namespace FTIL.Match.CDD.UI.UserControls
{
    public partial class ucCustodian : FTIL.Match.CDD.UI.UserControls.ucBaseEntity
    {
        #region Variables
        private cCustodian m_ObjCustodian;
        private EntityDetails m_EntityDetails;       
        private CucOperation m_ObjCucCustodian;
        private MatchCommon.CustomControls.FTTextBox txtCDDCustNameForGrid;
        private MatchCommon.CustomControls.FTTextBox txtCDDCustCodeForGrid;
        private MatchCommon.CustomControls.FTComboBox cboCDDCustCodeForGrid;
        DataTable dtCustodianDetails = null;
        DataTable dtCustodianMaster = null;
        TextBox txtCDDCustName;
        public int ClientNo { get; set; }
        public string sClientHeaderName { get; set; }
        //public int ExNo { get; set; }
        //public int ExMapingNo { get; set; }
        //public int TradingCode { get; set; }
        //public int CtclId { get; set; }
        //public int ExchangeNo { get; set; }
        //public int AddModifyFlag { get; set; }
        //CheckBox HeaderCheckBox = null;
        //DataTable dtExchange = null;
        //TextBox txtCDDCustodianNo;
        //private frmProcess objProcess;  

        #endregion
        
        public EntityDetails EntityDetails
        {
            get { return m_EntityDetails; }
            set { m_EntityDetails = value; }
        }

        /// <summary>
        /// call from frmEntity details return custodian tab data for submit custodian details. 
        /// </summary>
        public cCustodian EntityCustodianDetails
        {
            get { return m_ObjCustodian; }
        }
        public ucCustodian()
        {
            InitializeComponent();
            m_ObjCustodian = new cCustodian();
            m_ObjCucCustodian = new CucOperation();
            
            dgvCustodian.Cols.Fixed = UIConstants.FlexGridLeftFixColumn;
            dgvCustodian.AllowEditing = true;
            dgvCustodian.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;

            txtCDDCustName = new TextBox();


            cboCDDCustCodeForGrid = new MatchCommon.CustomControls.FTComboBox();
            cboCDDCustCodeForGrid.ReadOnly = false;
            

            txtCDDCustNameForGrid = new MatchCommon.CustomControls.FTTextBox();
            txtCDDCustNameForGrid.MaxLength = 30;
            txtCDDCustNameForGrid.AllowAlpha = true;
            txtCDDCustNameForGrid.AllowDot = false;
            txtCDDCustNameForGrid.AllowNonASCII = false;
            txtCDDCustNameForGrid.AllowSpace = false;
            txtCDDCustNameForGrid.AllowSpecialChars = false;
            txtCDDCustNameForGrid.AllowNumeric = true;
           
            txtCDDCustCodeForGrid = new MatchCommon.CustomControls.FTTextBox();
            txtCDDCustCodeForGrid.MaxLength = 30;
            txtCDDCustCodeForGrid.AllowAlpha = true;
            txtCDDCustCodeForGrid.AllowDot = false;
            txtCDDCustCodeForGrid.AllowNonASCII = false;
            txtCDDCustCodeForGrid.AllowSpace = false;
            txtCDDCustCodeForGrid.AllowSpecialChars = false;
            txtCDDCustCodeForGrid.AllowNumeric = true;
        }

        public EventHandler CustCode_SelectionChange
        {
            set
            {
                cboCDDCustCodeForGrid.SelectedIndexChanged += value;
            }
        }
        private void cboCDDCustCodeForGridSelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int custNo = 0;
                DataRow[] l_objRows = dtCustodianMaster.Select("CustodianNo = " + cboCDDCustCodeForGrid.SelectedValue.ToString());
                custNo = Convert.ToInt32(cboCDDCustCodeForGrid.SelectedValue.ToString());
                int a = txtCDDCustNameForGrid.TextLength;
                txtCDDCustName.Text = l_objRows[0]["CustodianName"].ToString();
                //txtCDDCustNameForGrid.Text= l_objRows[0]["CustodianName"].ToString();
                int SelRow = this.dgvCustodian.RowSel;
                int SelCol = this.dgvCustodian.ColSel;
                if (SelCol > 0)
                {
                    this.dgvCustodian.Rows[SelRow][dgvCustodian.Cols["s_CustodianName"].Index] = txtCDDCustName.Text;//txtCDDCustNameForGrid.Text;[SelCol + 1]
                    this.dgvCustodian.Rows[SelRow][dgvCustodian.Cols["n_CustodianNo"].Index] = custNo;// [SelCol - 1]
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucCustodian), ex.Message);
                MessageBox.Show(ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }


        /// <summary>
        /// Populate controls (Grid)
        /// </summary>
        public override void PopulateControls()
        {
            BindGrid();
           
        }


        private void ucCustodian_Load(object sender, EventArgs e)
        {
            BindGrid();
           // PopulateLookup();
            CustCode_SelectionChange = this.cboCDDCustCodeForGridSelectedIndexChanged;


        }

       


        /// <summary>
        /// Grid bind method call on every refresh event for grid 
        /// </summary>
        public void BindGrid()
        {
            try
            {
                m_ObjCucCustodian.GetCustodianDetails(ClientNo, ref dtCustodianDetails, AppEnvironment.AppUser.UserNo, ref dtCustodianMaster);

                dgvCustodian.DataSource = dtCustodianDetails;
                cboCDDCustCodeForGrid.ValueMember = "CustodianNo";
                cboCDDCustCodeForGrid.DisplayMember = "CustodianCode";
                cboCDDCustCodeForGrid.DataSource = dtCustodianMaster;

               
                dgvCustodian.Cols["n_ClientCustodianNo"].Visible = false;
                this.dgvCustodian.Cols["n_ExchangeNo"].Visible = false;
                this.dgvCustodian.Cols["n_ClientNo"].Visible = false;
                this.dgvCustodian.Cols["n_CustodianNo"].Visible = false;
                this.dgvCustodian.Cols["s_AuthorizedStatus"].Visible = false;
                this.dgvCustodian.Cols["s_ChangeNature"].Visible = false;
                this.dgvCustodian.Cols["n_MakerUser"].Visible = false;               
                this.dgvCustodian.Cols["d_MakerDatetime"].Visible = false;
                this.dgvCustodian.Cols["n_AuthorizeUser"].Visible = false;
                this.dgvCustodian.Cols["d_AuthorizeDatetime"].Visible = false;
                this.dgvCustodian.Cols["s_AuthorizationRemarks"].Visible = false;

               
                dgvCustodian.Cols["s_ExCode"].Caption = "Exchange";              
                dgvCustodian.Cols["s_CustodianCode"].Caption = "Cust Code";
                dgvCustodian.Cols["s_CustodianName"].Caption = "Custodian Name";
                dgvCustodian.Cols["s_ParticipentId"].Caption = "Participant Id";
                dgvCustodian.Cols["d_FromDate"].Caption = "From Date";
                dgvCustodian.Cols["d_ToDate"].Caption = "To Date";

                
                dgvCustodian.Cols["s_ExCode"].Width = 100;              
                dgvCustodian.Cols["s_CustodianCode"].Width = 100;
                dgvCustodian.Cols["s_CustodianCode"].Editor = cboCDDCustCodeForGrid;
                dgvCustodian.Cols["s_CustodianName"].Editor = txtCDDCustNameForGrid;
                dgvCustodian.Cols["s_CustodianName"].Width = 100;
                dgvCustodian.Cols["s_ParticipentId"].Width = 100;
                dgvCustodian.Cols["d_FromDate"].Width = 100;
                dgvCustodian.Cols["d_ToDate"].Width = 100;

                
                this.dgvCustodian.Cols["s_ExCode"].AllowEditing = false;               
                this.dgvCustodian.Cols["s_CustodianCode"].AllowEditing = true;
                this.dgvCustodian.Cols["s_CustodianName"].AllowEditing = false;
                this.dgvCustodian.Cols["s_ParticipentId"].AllowEditing = true;               
                this.dgvCustodian.Cols["d_FromDate"].AllowEditing = true;
                this.dgvCustodian.Cols["d_ToDate"].AllowEditing = true;


                C1.Win.C1FlexGrid.CellStyle cs;
                cs = dgvCustodian.Styles.Add("Blue");
                cs.Font = new Font(Font, FontStyle.Underline);
                cs.ForeColor = System.Drawing.Color.Blue;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucCustodian), ex.Message);
                MessageBox.Show("Unable to fetch data for bind Custodian grid", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

    
        public void SyncDataTable()
        {
            try
            {
                m_ObjCustodian.dtCustodianResult = (DataTable)this.dgvCustodian.DataSource; ;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucCustodian), ex.Message);
                MessageBox.Show("Unable to sync Custodian details grid", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnSave_Click(object sender, EventArgs e)
        {} 

        private void dgvCustodian_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            string str = e.KeyChar.ToString();
            if (!System.Text.RegularExpressions.Regex.IsMatch(str.Trim(), @"^[A-Z0-9\b]$"))
            {
                e.Handled = true;
                //MessageBox.Show("Kindly Enter Participent Id  in UPPER Case alphnumeric value", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void dgvCustodian_KeyDownEdit(object sender, KeyEditEventArgs e)
        {
            if (e.KeyCode == Keys.Delete || e.KeyCode == Keys.Left || e.KeyCode == Keys.Right)
            {
                e.Handled = false;
            }
            else { e.Handled = true; }
        }

     

        private void dgvCustodian_AfterEdit(object sender, RowColEventArgs e)
        {
            try
            {

                int SelRow = this.dgvCustodian.RowSel;
                int SelCol = this.dgvCustodian.ColSel;
                if (SelCol == dgvCustodian.Cols["d_FromDate"].Index)//8
                {                    
                    if (Convert.ToDateTime(this.dgvCustodian[SelRow, SelCol]) > Convert.ToDateTime(DateTime.Today.ToShortDateString()))
                    {
                        MessageBox.Show("Kindly fill the Correct Date.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.dgvCustodian.Rows[SelRow][SelCol] = DBNull.Value;
                        return;
                    }
                }

                if (SelCol == dgvCustodian.Cols["d_ToDate"].Index)//9
                {
                    if (this.dgvCustodian[SelRow, dgvCustodian.Cols["d_FromDate"].Index ].ToString() != "")//SeCol-1
                    {
                        if (Convert.ToDateTime(this.dgvCustodian[SelRow, dgvCustodian.Cols["d_FromDate"].Index]) >= Convert.ToDateTime(this.dgvCustodian[SelRow, SelCol]))
                        {
                            MessageBox.Show("Kindly fill the Date greater than 'From Date'.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.dgvCustodian.Rows[SelRow][SelCol] = DBNull.Value;
                            return;
                        }
                    }
                }
                if (SelCol == dgvCustodian.Cols["s_ParticipentId"].Index)//7
                {
                    string sParticipantId;
                    sParticipantId = this.dgvCustodian.Rows[SelRow][SelCol].ToString();
                    if (sParticipantId.Length > 24)                        
                    {                       
                        MessageBox.Show("Kindly fill the Correct Participant Id.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.dgvCustodian.Rows[SelRow][SelCol] = DBNull.Value;
                        return;
                    }
                }
                if (SelCol >= dgvCustodian.Cols["s_ParticipentId"].Index)//7
                {
                    string sCustName;
                    sCustName = this.dgvCustodian.Rows[SelRow][this.dgvCustodian.Cols["s_CustodianName"].Index].ToString();//6
                    if (sCustName == "")
                    {
                        MessageBox.Show("Kindly fill the Custodian Code .", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.dgvCustodian.Rows[SelRow][SelCol] = DBNull.Value;
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucCustodian), ex.Message);
                MessageBox.Show(ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
 
    }
   
}






