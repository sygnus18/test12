﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using UCC.Class;
using FTIL.Match.Common;
using FTIL.Match.CDD.BAL;
using System.IO;
using FTIL.Match.CDD.UI.Forms;
using FTIL.Match.Common.Log;
using C1.Win.C1FlexGrid;

namespace FTIL.Match.CDD.UI.UserControls
{


    /// <summary>
    /// User Control for showing/storing note for Entity.
    /// </summary>
    public partial class ucNote : UserControl
    {

        public int EntityNo { get; set; }

        /// <summary>
        /// Note Description
        /// </summary>
        public string NoteDescription { get; set; }


        private CNote m_CNote;


        private void ucNote_Load(object sender, EventArgs e)
        {
            PopulateControls();
        }


        
        public ucNote()
        {
            InitializeComponent();
            m_CNote = new CNote();
        }

   
        /// <summary>
        /// Bind controls from backend note details
        /// </summary>
        public void PopulateControls()
        {
            m_CNote.GetNote(EntityNo);
            txtComment.Text = m_CNote.NoteText;

            if (string.IsNullOrEmpty(m_CNote.UserName))
                lblUserInfo.Text = string.Empty;
            else
                lblUserInfo.Text = "Last Updated Details: " +  m_CNote.UserName + " - [ " + m_CNote.NoteDateTime + "]";
        }


        /// <summary>
        /// Update Entity note in the backend
        /// </summary>
        public void UpdateNote()
        {
            m_CNote.NoteText = txtComment.Text;
            m_CNote.EntityNo = EntityNo;
            m_CNote.Description = NoteDescription;
            MethodExecResult m_MethodExecResult = m_CNote.UpdateNote();
            if (m_MethodExecResult.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                MessageBox.Show("Note updated successfully.", string.Empty, MessageBoxButtons.OK);
             }
            else
            {
                Logger.Instance.WriteLog(this, m_MethodExecResult);
                MessageBox.Show("Failed to update Note.", string.Empty, MessageBoxButtons.OK, MessageBoxIcon.Error);
             } 
        }

    }
}
