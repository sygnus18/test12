﻿namespace FTIL.Match.CDD.UI.UserControls
{
    partial class ucDeposits
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucDeposits));
            this.gbSettlementLmt = new System.Windows.Forms.GroupBox();
            this.tblLayoutSettlementLmt = new System.Windows.Forms.TableLayoutPanel();
            this.txtSettlLtMTMLt = new MatchCommon.CustomControls.FTTextBox();
            this.txtMultiplierMTMLt = new MatchCommon.CustomControls.FTTextBox();
            this.txtSettlLtNetTurnOver = new MatchCommon.CustomControls.FTTextBox();
            this.txtMultiplierNetTurnOver = new MatchCommon.CustomControls.FTTextBox();
            this.txtSettlLtNetPos = new MatchCommon.CustomControls.FTTextBox();
            this.txtMultiplierNetPos = new MatchCommon.CustomControls.FTTextBox();
            this.txtSettlLtNetQty = new MatchCommon.CustomControls.FTTextBox();
            this.txtmultiplierNetQty = new MatchCommon.CustomControls.FTTextBox();
            this.txtSettlLtNetSale = new MatchCommon.CustomControls.FTTextBox();
            this.txtMultiplierNetSale = new MatchCommon.CustomControls.FTTextBox();
            this.chkSettlLtNetPurchase = new System.Windows.Forms.CheckBox();
            this.txtsettlLtNetPurchase = new MatchCommon.CustomControls.FTTextBox();
            this.txtMultiplierNetPurchase = new MatchCommon.CustomControls.FTTextBox();
            this.txtSettleLtGrossExposure = new MatchCommon.CustomControls.FTTextBox();
            this.txtMultiplierGrossExposure = new MatchCommon.CustomControls.FTTextBox();
            this.chkSettlLtNetSale = new System.Windows.Forms.CheckBox();
            this.chkSettlLtNetQty = new System.Windows.Forms.CheckBox();
            this.chkSettlLtNetPos = new System.Windows.Forms.CheckBox();
            this.chkSettlLtNetTurnOver = new System.Windows.Forms.CheckBox();
            this.chkSettlLtMTMLt = new System.Windows.Forms.CheckBox();
            this.chkSettlLtMargin = new System.Windows.Forms.CheckBox();
            this.txtSettlLtMargin = new MatchCommon.CustomControls.FTTextBox();
            this.txtMultiplierMargin = new MatchCommon.CustomControls.FTTextBox();
            this.lblMultiplier = new System.Windows.Forms.Label();
            this.chkSettleLtGrossExposure = new System.Windows.Forms.CheckBox();
            this.lblGrossExposure = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.lblsetLmtOpt = new System.Windows.Forms.Label();
            this.lblNetPos = new System.Windows.Forms.Label();
            this.lblNetTurnOver = new System.Windows.Forms.Label();
            this.lblMTMLmt = new System.Windows.Forms.Label();
            this.lblMargin = new System.Windows.Forms.Label();
            this.lblSettlements = new System.Windows.Forms.Label();
            this.lblNetPurchase = new System.Windows.Forms.Label();
            this.lblNetSale = new System.Windows.Forms.Label();
            this.lblNetQty = new System.Windows.Forms.Label();
            this.chkDefaultSurviellance = new System.Windows.Forms.CheckBox();
            this.gbGeneralOptions = new System.Windows.Forms.GroupBox();
            this.chkRetailMultiplier = new System.Windows.Forms.CheckBox();
            this.chkGrossCheck = new System.Windows.Forms.CheckBox();
            this.gbDeposits = new System.Windows.Forms.GroupBox();
            this.txtCreditForSale = new MatchCommon.CustomControls.FTTextBox();
            this.lblCreditForSale = new System.Windows.Forms.Label();
            this.txtSecurityCollateral = new MatchCommon.CustomControls.FTTextBox();
            this.lblSecurityCollateral = new System.Windows.Forms.Label();
            this.txtAdhocDeposit = new MatchCommon.CustomControls.FTTextBox();
            this.lblAdhocDeposit = new System.Windows.Forms.Label();
            this.txtDeposit = new MatchCommon.CustomControls.FTTextBox();
            this.lblDeposit = new System.Windows.Forms.Label();
            this.gbSettlementLmt.SuspendLayout();
            this.tblLayoutSettlementLmt.SuspendLayout();
            this.gbGeneralOptions.SuspendLayout();
            this.gbDeposits.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbSettlementLmt
            // 
            this.gbSettlementLmt.Controls.Add(this.tblLayoutSettlementLmt);
            this.gbSettlementLmt.Controls.Add(this.chkDefaultSurviellance);
            this.gbSettlementLmt.Controls.Add(this.gbGeneralOptions);
            this.gbSettlementLmt.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.gbSettlementLmt.Location = new System.Drawing.Point(380, 10);
            this.gbSettlementLmt.Name = "gbSettlementLmt";
            this.gbSettlementLmt.Size = new System.Drawing.Size(340, 389);
            this.gbSettlementLmt.TabIndex = 45;
            this.gbSettlementLmt.TabStop = false;
            this.gbSettlementLmt.Text = "Settlement Limits";
            // 
            // tblLayoutSettlementLmt
            // 
            this.tblLayoutSettlementLmt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tblLayoutSettlementLmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.tblLayoutSettlementLmt.ColumnCount = 5;
            this.tblLayoutSettlementLmt.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 89F));
            this.tblLayoutSettlementLmt.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tblLayoutSettlementLmt.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tblLayoutSettlementLmt.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tblLayoutSettlementLmt.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tblLayoutSettlementLmt.Controls.Add(this.txtSettlLtMTMLt, 3, 7);
            this.tblLayoutSettlementLmt.Controls.Add(this.txtMultiplierMTMLt, 1, 7);
            this.tblLayoutSettlementLmt.Controls.Add(this.txtSettlLtNetTurnOver, 3, 6);
            this.tblLayoutSettlementLmt.Controls.Add(this.txtMultiplierNetTurnOver, 1, 6);
            this.tblLayoutSettlementLmt.Controls.Add(this.txtSettlLtNetPos, 3, 5);
            this.tblLayoutSettlementLmt.Controls.Add(this.txtMultiplierNetPos, 1, 5);
            this.tblLayoutSettlementLmt.Controls.Add(this.txtSettlLtNetQty, 3, 4);
            this.tblLayoutSettlementLmt.Controls.Add(this.txtmultiplierNetQty, 1, 4);
            this.tblLayoutSettlementLmt.Controls.Add(this.txtSettlLtNetSale, 3, 3);
            this.tblLayoutSettlementLmt.Controls.Add(this.txtMultiplierNetSale, 1, 3);
            this.tblLayoutSettlementLmt.Controls.Add(this.chkSettlLtNetPurchase, 4, 2);
            this.tblLayoutSettlementLmt.Controls.Add(this.txtsettlLtNetPurchase, 3, 2);
            this.tblLayoutSettlementLmt.Controls.Add(this.txtMultiplierNetPurchase, 1, 2);
            this.tblLayoutSettlementLmt.Controls.Add(this.txtSettleLtGrossExposure, 3, 1);
            this.tblLayoutSettlementLmt.Controls.Add(this.txtMultiplierGrossExposure, 1, 1);
            this.tblLayoutSettlementLmt.Controls.Add(this.chkSettlLtNetSale, 4, 3);
            this.tblLayoutSettlementLmt.Controls.Add(this.chkSettlLtNetQty, 4, 4);
            this.tblLayoutSettlementLmt.Controls.Add(this.chkSettlLtNetPos, 4, 5);
            this.tblLayoutSettlementLmt.Controls.Add(this.chkSettlLtNetTurnOver, 4, 6);
            this.tblLayoutSettlementLmt.Controls.Add(this.chkSettlLtMTMLt, 4, 7);
            this.tblLayoutSettlementLmt.Controls.Add(this.chkSettlLtMargin, 4, 8);
            this.tblLayoutSettlementLmt.Controls.Add(this.txtSettlLtMargin, 3, 8);
            this.tblLayoutSettlementLmt.Controls.Add(this.txtMultiplierMargin, 1, 8);
            this.tblLayoutSettlementLmt.Controls.Add(this.lblMultiplier, 1, 0);
            this.tblLayoutSettlementLmt.Controls.Add(this.chkSettleLtGrossExposure, 4, 1);
            this.tblLayoutSettlementLmt.Controls.Add(this.lblGrossExposure, 0, 1);
            this.tblLayoutSettlementLmt.Controls.Add(this.label51, 2, 1);
            this.tblLayoutSettlementLmt.Controls.Add(this.label52, 2, 2);
            this.tblLayoutSettlementLmt.Controls.Add(this.label53, 2, 3);
            this.tblLayoutSettlementLmt.Controls.Add(this.label54, 2, 4);
            this.tblLayoutSettlementLmt.Controls.Add(this.label55, 2, 5);
            this.tblLayoutSettlementLmt.Controls.Add(this.label56, 2, 6);
            this.tblLayoutSettlementLmt.Controls.Add(this.label57, 2, 7);
            this.tblLayoutSettlementLmt.Controls.Add(this.label58, 2, 8);
            this.tblLayoutSettlementLmt.Controls.Add(this.lblsetLmtOpt, 4, 0);
            this.tblLayoutSettlementLmt.Controls.Add(this.lblNetPos, 0, 5);
            this.tblLayoutSettlementLmt.Controls.Add(this.lblNetTurnOver, 0, 6);
            this.tblLayoutSettlementLmt.Controls.Add(this.lblMTMLmt, 0, 7);
            this.tblLayoutSettlementLmt.Controls.Add(this.lblMargin, 0, 8);
            this.tblLayoutSettlementLmt.Controls.Add(this.lblSettlements, 3, 0);
            this.tblLayoutSettlementLmt.Controls.Add(this.lblNetPurchase, 0, 2);
            this.tblLayoutSettlementLmt.Controls.Add(this.lblNetSale, 0, 3);
            this.tblLayoutSettlementLmt.Controls.Add(this.lblNetQty, 0, 4);
            this.tblLayoutSettlementLmt.GrowStyle = System.Windows.Forms.TableLayoutPanelGrowStyle.FixedSize;
            this.tblLayoutSettlementLmt.Location = new System.Drawing.Point(8, 20);
            this.tblLayoutSettlementLmt.Name = "tblLayoutSettlementLmt";
            this.tblLayoutSettlementLmt.RowCount = 9;
            this.tblLayoutSettlementLmt.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44F));
            this.tblLayoutSettlementLmt.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.tblLayoutSettlementLmt.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tblLayoutSettlementLmt.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tblLayoutSettlementLmt.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tblLayoutSettlementLmt.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tblLayoutSettlementLmt.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tblLayoutSettlementLmt.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tblLayoutSettlementLmt.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tblLayoutSettlementLmt.Size = new System.Drawing.Size(328, 256);
            this.tblLayoutSettlementLmt.TabIndex = 69;
            // 
            // txtSettlLtMTMLt
            // 
            this.txtSettlLtMTMLt.AllowAlpha = false;
            this.txtSettlLtMTMLt.AllowDot = true;
            this.txtSettlLtMTMLt.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtSettlLtMTMLt.AllowedCustomCharacters")));
            this.txtSettlLtMTMLt.AllowNonASCII = false;
            this.txtSettlLtMTMLt.AllowNumeric = true;
            this.txtSettlLtMTMLt.AllowSpace = false;
            this.txtSettlLtMTMLt.AllowSpecialChars = false;
            this.txtSettlLtMTMLt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtSettlLtMTMLt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.txtSettlLtMTMLt.Enabled = false;
            this.txtSettlLtMTMLt.FocusColor = System.Drawing.Color.LightYellow;
            this.txtSettlLtMTMLt.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtSettlLtMTMLt.ForeColor = System.Drawing.Color.Black;
            this.txtSettlLtMTMLt.IsEmailID = false;
            this.txtSettlLtMTMLt.IsEmailIdValid = false;
            this.txtSettlLtMTMLt.Location = new System.Drawing.Point(182, 205);
            this.txtSettlLtMTMLt.Name = "txtSettlLtMTMLt";
            this.txtSettlLtMTMLt.Size = new System.Drawing.Size(73, 20);
            this.txtSettlLtMTMLt.TabIndex = 95;
            this.txtSettlLtMTMLt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtMultiplierMTMLt
            // 
            this.txtMultiplierMTMLt.AllowAlpha = false;
            this.txtMultiplierMTMLt.AllowDot = true;
            this.txtMultiplierMTMLt.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtMultiplierMTMLt.AllowedCustomCharacters")));
            this.txtMultiplierMTMLt.AllowNonASCII = false;
            this.txtMultiplierMTMLt.AllowNumeric = true;
            this.txtMultiplierMTMLt.AllowSpace = false;
            this.txtMultiplierMTMLt.AllowSpecialChars = false;
            this.txtMultiplierMTMLt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtMultiplierMTMLt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.txtMultiplierMTMLt.Enabled = false;
            this.txtMultiplierMTMLt.FocusColor = System.Drawing.Color.LightYellow;
            this.txtMultiplierMTMLt.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtMultiplierMTMLt.ForeColor = System.Drawing.Color.Black;
            this.txtMultiplierMTMLt.IsEmailID = false;
            this.txtMultiplierMTMLt.IsEmailIdValid = false;
            this.txtMultiplierMTMLt.Location = new System.Drawing.Point(92, 205);
            this.txtMultiplierMTMLt.Name = "txtMultiplierMTMLt";
            this.txtMultiplierMTMLt.Size = new System.Drawing.Size(51, 20);
            this.txtMultiplierMTMLt.TabIndex = 93;
            this.txtMultiplierMTMLt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtSettlLtNetTurnOver
            // 
            this.txtSettlLtNetTurnOver.AllowAlpha = false;
            this.txtSettlLtNetTurnOver.AllowDot = true;
            this.txtSettlLtNetTurnOver.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtSettlLtNetTurnOver.AllowedCustomCharacters")));
            this.txtSettlLtNetTurnOver.AllowNonASCII = false;
            this.txtSettlLtNetTurnOver.AllowNumeric = true;
            this.txtSettlLtNetTurnOver.AllowSpace = false;
            this.txtSettlLtNetTurnOver.AllowSpecialChars = false;
            this.txtSettlLtNetTurnOver.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtSettlLtNetTurnOver.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.txtSettlLtNetTurnOver.Enabled = false;
            this.txtSettlLtNetTurnOver.FocusColor = System.Drawing.Color.LightYellow;
            this.txtSettlLtNetTurnOver.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtSettlLtNetTurnOver.ForeColor = System.Drawing.Color.Black;
            this.txtSettlLtNetTurnOver.IsEmailID = false;
            this.txtSettlLtNetTurnOver.IsEmailIdValid = false;
            this.txtSettlLtNetTurnOver.Location = new System.Drawing.Point(182, 179);
            this.txtSettlLtNetTurnOver.Name = "txtSettlLtNetTurnOver";
            this.txtSettlLtNetTurnOver.Size = new System.Drawing.Size(73, 20);
            this.txtSettlLtNetTurnOver.TabIndex = 92;
            this.txtSettlLtNetTurnOver.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtMultiplierNetTurnOver
            // 
            this.txtMultiplierNetTurnOver.AllowAlpha = false;
            this.txtMultiplierNetTurnOver.AllowDot = true;
            this.txtMultiplierNetTurnOver.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtMultiplierNetTurnOver.AllowedCustomCharacters")));
            this.txtMultiplierNetTurnOver.AllowNonASCII = false;
            this.txtMultiplierNetTurnOver.AllowNumeric = true;
            this.txtMultiplierNetTurnOver.AllowSpace = false;
            this.txtMultiplierNetTurnOver.AllowSpecialChars = false;
            this.txtMultiplierNetTurnOver.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtMultiplierNetTurnOver.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.txtMultiplierNetTurnOver.Enabled = false;
            this.txtMultiplierNetTurnOver.FocusColor = System.Drawing.Color.LightYellow;
            this.txtMultiplierNetTurnOver.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtMultiplierNetTurnOver.ForeColor = System.Drawing.Color.Black;
            this.txtMultiplierNetTurnOver.IsEmailID = false;
            this.txtMultiplierNetTurnOver.IsEmailIdValid = false;
            this.txtMultiplierNetTurnOver.Location = new System.Drawing.Point(92, 179);
            this.txtMultiplierNetTurnOver.Name = "txtMultiplierNetTurnOver";
            this.txtMultiplierNetTurnOver.Size = new System.Drawing.Size(51, 20);
            this.txtMultiplierNetTurnOver.TabIndex = 90;
            this.txtMultiplierNetTurnOver.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtSettlLtNetPos
            // 
            this.txtSettlLtNetPos.AllowAlpha = false;
            this.txtSettlLtNetPos.AllowDot = true;
            this.txtSettlLtNetPos.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtSettlLtNetPos.AllowedCustomCharacters")));
            this.txtSettlLtNetPos.AllowNonASCII = false;
            this.txtSettlLtNetPos.AllowNumeric = true;
            this.txtSettlLtNetPos.AllowSpace = false;
            this.txtSettlLtNetPos.AllowSpecialChars = false;
            this.txtSettlLtNetPos.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtSettlLtNetPos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.txtSettlLtNetPos.Enabled = false;
            this.txtSettlLtNetPos.FocusColor = System.Drawing.Color.LightYellow;
            this.txtSettlLtNetPos.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtSettlLtNetPos.ForeColor = System.Drawing.Color.Black;
            this.txtSettlLtNetPos.IsEmailID = false;
            this.txtSettlLtNetPos.IsEmailIdValid = false;
            this.txtSettlLtNetPos.Location = new System.Drawing.Point(182, 153);
            this.txtSettlLtNetPos.Name = "txtSettlLtNetPos";
            this.txtSettlLtNetPos.Size = new System.Drawing.Size(73, 20);
            this.txtSettlLtNetPos.TabIndex = 89;
            this.txtSettlLtNetPos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtMultiplierNetPos
            // 
            this.txtMultiplierNetPos.AllowAlpha = false;
            this.txtMultiplierNetPos.AllowDot = true;
            this.txtMultiplierNetPos.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtMultiplierNetPos.AllowedCustomCharacters")));
            this.txtMultiplierNetPos.AllowNonASCII = false;
            this.txtMultiplierNetPos.AllowNumeric = true;
            this.txtMultiplierNetPos.AllowSpace = false;
            this.txtMultiplierNetPos.AllowSpecialChars = false;
            this.txtMultiplierNetPos.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtMultiplierNetPos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.txtMultiplierNetPos.Enabled = false;
            this.txtMultiplierNetPos.FocusColor = System.Drawing.Color.LightYellow;
            this.txtMultiplierNetPos.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtMultiplierNetPos.ForeColor = System.Drawing.Color.Black;
            this.txtMultiplierNetPos.IsEmailID = false;
            this.txtMultiplierNetPos.IsEmailIdValid = false;
            this.txtMultiplierNetPos.Location = new System.Drawing.Point(92, 153);
            this.txtMultiplierNetPos.Name = "txtMultiplierNetPos";
            this.txtMultiplierNetPos.Size = new System.Drawing.Size(51, 20);
            this.txtMultiplierNetPos.TabIndex = 87;
            this.txtMultiplierNetPos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtSettlLtNetQty
            // 
            this.txtSettlLtNetQty.AllowAlpha = false;
            this.txtSettlLtNetQty.AllowDot = true;
            this.txtSettlLtNetQty.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtSettlLtNetQty.AllowedCustomCharacters")));
            this.txtSettlLtNetQty.AllowNonASCII = false;
            this.txtSettlLtNetQty.AllowNumeric = true;
            this.txtSettlLtNetQty.AllowSpace = false;
            this.txtSettlLtNetQty.AllowSpecialChars = false;
            this.txtSettlLtNetQty.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtSettlLtNetQty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.txtSettlLtNetQty.Enabled = false;
            this.txtSettlLtNetQty.FocusColor = System.Drawing.Color.LightYellow;
            this.txtSettlLtNetQty.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtSettlLtNetQty.ForeColor = System.Drawing.Color.Black;
            this.txtSettlLtNetQty.IsEmailID = false;
            this.txtSettlLtNetQty.IsEmailIdValid = false;
            this.txtSettlLtNetQty.Location = new System.Drawing.Point(182, 126);
            this.txtSettlLtNetQty.Name = "txtSettlLtNetQty";
            this.txtSettlLtNetQty.Size = new System.Drawing.Size(73, 20);
            this.txtSettlLtNetQty.TabIndex = 86;
            this.txtSettlLtNetQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtmultiplierNetQty
            // 
            this.txtmultiplierNetQty.AllowAlpha = false;
            this.txtmultiplierNetQty.AllowDot = true;
            this.txtmultiplierNetQty.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtmultiplierNetQty.AllowedCustomCharacters")));
            this.txtmultiplierNetQty.AllowNonASCII = false;
            this.txtmultiplierNetQty.AllowNumeric = true;
            this.txtmultiplierNetQty.AllowSpace = false;
            this.txtmultiplierNetQty.AllowSpecialChars = false;
            this.txtmultiplierNetQty.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtmultiplierNetQty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.txtmultiplierNetQty.Enabled = false;
            this.txtmultiplierNetQty.FocusColor = System.Drawing.Color.LightYellow;
            this.txtmultiplierNetQty.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtmultiplierNetQty.ForeColor = System.Drawing.Color.Black;
            this.txtmultiplierNetQty.IsEmailID = false;
            this.txtmultiplierNetQty.IsEmailIdValid = false;
            this.txtmultiplierNetQty.Location = new System.Drawing.Point(92, 126);
            this.txtmultiplierNetQty.Name = "txtmultiplierNetQty";
            this.txtmultiplierNetQty.Size = new System.Drawing.Size(51, 20);
            this.txtmultiplierNetQty.TabIndex = 84;
            this.txtmultiplierNetQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtSettlLtNetSale
            // 
            this.txtSettlLtNetSale.AllowAlpha = false;
            this.txtSettlLtNetSale.AllowDot = true;
            this.txtSettlLtNetSale.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtSettlLtNetSale.AllowedCustomCharacters")));
            this.txtSettlLtNetSale.AllowNonASCII = false;
            this.txtSettlLtNetSale.AllowNumeric = true;
            this.txtSettlLtNetSale.AllowSpace = false;
            this.txtSettlLtNetSale.AllowSpecialChars = false;
            this.txtSettlLtNetSale.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtSettlLtNetSale.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.txtSettlLtNetSale.Enabled = false;
            this.txtSettlLtNetSale.FocusColor = System.Drawing.Color.LightYellow;
            this.txtSettlLtNetSale.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtSettlLtNetSale.ForeColor = System.Drawing.Color.Black;
            this.txtSettlLtNetSale.IsEmailID = false;
            this.txtSettlLtNetSale.IsEmailIdValid = false;
            this.txtSettlLtNetSale.Location = new System.Drawing.Point(182, 100);
            this.txtSettlLtNetSale.Name = "txtSettlLtNetSale";
            this.txtSettlLtNetSale.Size = new System.Drawing.Size(73, 20);
            this.txtSettlLtNetSale.TabIndex = 83;
            this.txtSettlLtNetSale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtMultiplierNetSale
            // 
            this.txtMultiplierNetSale.AllowAlpha = false;
            this.txtMultiplierNetSale.AllowDot = true;
            this.txtMultiplierNetSale.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtMultiplierNetSale.AllowedCustomCharacters")));
            this.txtMultiplierNetSale.AllowNonASCII = false;
            this.txtMultiplierNetSale.AllowNumeric = true;
            this.txtMultiplierNetSale.AllowSpace = false;
            this.txtMultiplierNetSale.AllowSpecialChars = false;
            this.txtMultiplierNetSale.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtMultiplierNetSale.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.txtMultiplierNetSale.Enabled = false;
            this.txtMultiplierNetSale.FocusColor = System.Drawing.Color.LightYellow;
            this.txtMultiplierNetSale.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtMultiplierNetSale.ForeColor = System.Drawing.Color.Black;
            this.txtMultiplierNetSale.IsEmailID = false;
            this.txtMultiplierNetSale.IsEmailIdValid = false;
            this.txtMultiplierNetSale.Location = new System.Drawing.Point(92, 100);
            this.txtMultiplierNetSale.Name = "txtMultiplierNetSale";
            this.txtMultiplierNetSale.Size = new System.Drawing.Size(51, 20);
            this.txtMultiplierNetSale.TabIndex = 81;
            this.txtMultiplierNetSale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // chkSettlLtNetPurchase
            // 
            this.chkSettlLtNetPurchase.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chkSettlLtNetPurchase.AutoSize = true;
            this.chkSettlLtNetPurchase.Location = new System.Drawing.Point(290, 77);
            this.chkSettlLtNetPurchase.Name = "chkSettlLtNetPurchase";
            this.chkSettlLtNetPurchase.Size = new System.Drawing.Size(15, 14);
            this.chkSettlLtNetPurchase.TabIndex = 74;
            this.chkSettlLtNetPurchase.UseVisualStyleBackColor = true;
            this.chkSettlLtNetPurchase.CheckedChanged += new System.EventHandler(this.chkSettlLtNetPurchase_CheckedChanged);
            // 
            // txtsettlLtNetPurchase
            // 
            this.txtsettlLtNetPurchase.AllowAlpha = false;
            this.txtsettlLtNetPurchase.AllowDot = true;
            this.txtsettlLtNetPurchase.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtsettlLtNetPurchase.AllowedCustomCharacters")));
            this.txtsettlLtNetPurchase.AllowNonASCII = false;
            this.txtsettlLtNetPurchase.AllowNumeric = true;
            this.txtsettlLtNetPurchase.AllowSpace = false;
            this.txtsettlLtNetPurchase.AllowSpecialChars = false;
            this.txtsettlLtNetPurchase.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtsettlLtNetPurchase.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.txtsettlLtNetPurchase.Enabled = false;
            this.txtsettlLtNetPurchase.FocusColor = System.Drawing.Color.LightYellow;
            this.txtsettlLtNetPurchase.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtsettlLtNetPurchase.ForeColor = System.Drawing.Color.Black;
            this.txtsettlLtNetPurchase.IsEmailID = false;
            this.txtsettlLtNetPurchase.IsEmailIdValid = false;
            this.txtsettlLtNetPurchase.Location = new System.Drawing.Point(182, 75);
            this.txtsettlLtNetPurchase.Name = "txtsettlLtNetPurchase";
            this.txtsettlLtNetPurchase.Size = new System.Drawing.Size(73, 20);
            this.txtsettlLtNetPurchase.TabIndex = 73;
            this.txtsettlLtNetPurchase.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtMultiplierNetPurchase
            // 
            this.txtMultiplierNetPurchase.AllowAlpha = false;
            this.txtMultiplierNetPurchase.AllowDot = true;
            this.txtMultiplierNetPurchase.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtMultiplierNetPurchase.AllowedCustomCharacters")));
            this.txtMultiplierNetPurchase.AllowNonASCII = false;
            this.txtMultiplierNetPurchase.AllowNumeric = true;
            this.txtMultiplierNetPurchase.AllowSpace = false;
            this.txtMultiplierNetPurchase.AllowSpecialChars = false;
            this.txtMultiplierNetPurchase.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtMultiplierNetPurchase.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.txtMultiplierNetPurchase.Enabled = false;
            this.txtMultiplierNetPurchase.FocusColor = System.Drawing.Color.LightYellow;
            this.txtMultiplierNetPurchase.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtMultiplierNetPurchase.ForeColor = System.Drawing.Color.Black;
            this.txtMultiplierNetPurchase.IsEmailID = false;
            this.txtMultiplierNetPurchase.IsEmailIdValid = false;
            this.txtMultiplierNetPurchase.Location = new System.Drawing.Point(92, 75);
            this.txtMultiplierNetPurchase.Name = "txtMultiplierNetPurchase";
            this.txtMultiplierNetPurchase.Size = new System.Drawing.Size(51, 20);
            this.txtMultiplierNetPurchase.TabIndex = 71;
            this.txtMultiplierNetPurchase.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtSettleLtGrossExposure
            // 
            this.txtSettleLtGrossExposure.AllowAlpha = false;
            this.txtSettleLtGrossExposure.AllowDot = true;
            this.txtSettleLtGrossExposure.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtSettleLtGrossExposure.AllowedCustomCharacters")));
            this.txtSettleLtGrossExposure.AllowNonASCII = false;
            this.txtSettleLtGrossExposure.AllowNumeric = true;
            this.txtSettleLtGrossExposure.AllowSpace = false;
            this.txtSettleLtGrossExposure.AllowSpecialChars = false;
            this.txtSettleLtGrossExposure.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtSettleLtGrossExposure.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.txtSettleLtGrossExposure.Enabled = false;
            this.txtSettleLtGrossExposure.FocusColor = System.Drawing.Color.LightYellow;
            this.txtSettleLtGrossExposure.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtSettleLtGrossExposure.ForeColor = System.Drawing.Color.Black;
            this.txtSettleLtGrossExposure.IsEmailID = false;
            this.txtSettleLtGrossExposure.IsEmailIdValid = false;
            this.txtSettleLtGrossExposure.Location = new System.Drawing.Point(182, 48);
            this.txtSettleLtGrossExposure.Name = "txtSettleLtGrossExposure";
            this.txtSettleLtGrossExposure.Size = new System.Drawing.Size(73, 20);
            this.txtSettleLtGrossExposure.TabIndex = 70;
            this.txtSettleLtGrossExposure.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtMultiplierGrossExposure
            // 
            this.txtMultiplierGrossExposure.AllowAlpha = false;
            this.txtMultiplierGrossExposure.AllowDot = true;
            this.txtMultiplierGrossExposure.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtMultiplierGrossExposure.AllowedCustomCharacters")));
            this.txtMultiplierGrossExposure.AllowNonASCII = false;
            this.txtMultiplierGrossExposure.AllowNumeric = true;
            this.txtMultiplierGrossExposure.AllowSpace = false;
            this.txtMultiplierGrossExposure.AllowSpecialChars = false;
            this.txtMultiplierGrossExposure.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtMultiplierGrossExposure.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.txtMultiplierGrossExposure.Enabled = false;
            this.txtMultiplierGrossExposure.FocusColor = System.Drawing.Color.LightYellow;
            this.txtMultiplierGrossExposure.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtMultiplierGrossExposure.ForeColor = System.Drawing.Color.Black;
            this.txtMultiplierGrossExposure.IsEmailID = false;
            this.txtMultiplierGrossExposure.IsEmailIdValid = false;
            this.txtMultiplierGrossExposure.Location = new System.Drawing.Point(92, 48);
            this.txtMultiplierGrossExposure.Name = "txtMultiplierGrossExposure";
            this.txtMultiplierGrossExposure.Size = new System.Drawing.Size(51, 20);
            this.txtMultiplierGrossExposure.TabIndex = 68;
            this.txtMultiplierGrossExposure.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // chkSettlLtNetSale
            // 
            this.chkSettlLtNetSale.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chkSettlLtNetSale.AutoSize = true;
            this.chkSettlLtNetSale.Location = new System.Drawing.Point(290, 103);
            this.chkSettlLtNetSale.Name = "chkSettlLtNetSale";
            this.chkSettlLtNetSale.Size = new System.Drawing.Size(15, 14);
            this.chkSettlLtNetSale.TabIndex = 75;
            this.chkSettlLtNetSale.UseVisualStyleBackColor = true;
            this.chkSettlLtNetSale.CheckedChanged += new System.EventHandler(this.chkSettlLtNetSale_CheckedChanged);
            // 
            // chkSettlLtNetQty
            // 
            this.chkSettlLtNetQty.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chkSettlLtNetQty.AutoSize = true;
            this.chkSettlLtNetQty.Location = new System.Drawing.Point(290, 129);
            this.chkSettlLtNetQty.Name = "chkSettlLtNetQty";
            this.chkSettlLtNetQty.Size = new System.Drawing.Size(15, 14);
            this.chkSettlLtNetQty.TabIndex = 76;
            this.chkSettlLtNetQty.UseVisualStyleBackColor = true;
            this.chkSettlLtNetQty.CheckedChanged += new System.EventHandler(this.chkSettlLtNetQty_CheckedChanged);
            // 
            // chkSettlLtNetPos
            // 
            this.chkSettlLtNetPos.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chkSettlLtNetPos.AutoSize = true;
            this.chkSettlLtNetPos.Location = new System.Drawing.Point(290, 156);
            this.chkSettlLtNetPos.Name = "chkSettlLtNetPos";
            this.chkSettlLtNetPos.Size = new System.Drawing.Size(15, 14);
            this.chkSettlLtNetPos.TabIndex = 77;
            this.chkSettlLtNetPos.UseVisualStyleBackColor = true;
            this.chkSettlLtNetPos.CheckedChanged += new System.EventHandler(this.chkSettlLtNetPos_CheckedChanged);
            // 
            // chkSettlLtNetTurnOver
            // 
            this.chkSettlLtNetTurnOver.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chkSettlLtNetTurnOver.AutoSize = true;
            this.chkSettlLtNetTurnOver.Location = new System.Drawing.Point(290, 182);
            this.chkSettlLtNetTurnOver.Name = "chkSettlLtNetTurnOver";
            this.chkSettlLtNetTurnOver.Size = new System.Drawing.Size(15, 14);
            this.chkSettlLtNetTurnOver.TabIndex = 78;
            this.chkSettlLtNetTurnOver.UseVisualStyleBackColor = true;
            this.chkSettlLtNetTurnOver.CheckedChanged += new System.EventHandler(this.chkSettlLtNetTurnOver_CheckedChanged);
            // 
            // chkSettlLtMTMLt
            // 
            this.chkSettlLtMTMLt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chkSettlLtMTMLt.AutoSize = true;
            this.chkSettlLtMTMLt.Location = new System.Drawing.Point(290, 208);
            this.chkSettlLtMTMLt.Name = "chkSettlLtMTMLt";
            this.chkSettlLtMTMLt.Size = new System.Drawing.Size(15, 14);
            this.chkSettlLtMTMLt.TabIndex = 79;
            this.chkSettlLtMTMLt.UseVisualStyleBackColor = true;
            this.chkSettlLtMTMLt.CheckedChanged += new System.EventHandler(this.chkSettlLtMTMLt_CheckedChanged);
            // 
            // chkSettlLtMargin
            // 
            this.chkSettlLtMargin.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chkSettlLtMargin.AutoSize = true;
            this.chkSettlLtMargin.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkSettlLtMargin.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkSettlLtMargin.Location = new System.Drawing.Point(290, 235);
            this.chkSettlLtMargin.Name = "chkSettlLtMargin";
            this.chkSettlLtMargin.Size = new System.Drawing.Size(15, 14);
            this.chkSettlLtMargin.TabIndex = 80;
            this.chkSettlLtMargin.UseVisualStyleBackColor = true;
            this.chkSettlLtMargin.CheckedChanged += new System.EventHandler(this.chkSettlLtMargin_CheckedChanged);
            // 
            // txtSettlLtMargin
            // 
            this.txtSettlLtMargin.AllowAlpha = false;
            this.txtSettlLtMargin.AllowDot = true;
            this.txtSettlLtMargin.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtSettlLtMargin.AllowedCustomCharacters")));
            this.txtSettlLtMargin.AllowNonASCII = false;
            this.txtSettlLtMargin.AllowNumeric = true;
            this.txtSettlLtMargin.AllowSpace = false;
            this.txtSettlLtMargin.AllowSpecialChars = false;
            this.txtSettlLtMargin.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtSettlLtMargin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.txtSettlLtMargin.Enabled = false;
            this.txtSettlLtMargin.FocusColor = System.Drawing.Color.LightYellow;
            this.txtSettlLtMargin.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtSettlLtMargin.ForeColor = System.Drawing.Color.Black;
            this.txtSettlLtMargin.IsEmailID = false;
            this.txtSettlLtMargin.IsEmailIdValid = false;
            this.txtSettlLtMargin.Location = new System.Drawing.Point(182, 232);
            this.txtSettlLtMargin.Name = "txtSettlLtMargin";
            this.txtSettlLtMargin.Size = new System.Drawing.Size(73, 20);
            this.txtSettlLtMargin.TabIndex = 96;
            this.txtSettlLtMargin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtMultiplierMargin
            // 
            this.txtMultiplierMargin.AllowAlpha = false;
            this.txtMultiplierMargin.AllowDot = true;
            this.txtMultiplierMargin.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtMultiplierMargin.AllowedCustomCharacters")));
            this.txtMultiplierMargin.AllowNonASCII = false;
            this.txtMultiplierMargin.AllowNumeric = true;
            this.txtMultiplierMargin.AllowSpace = false;
            this.txtMultiplierMargin.AllowSpecialChars = false;
            this.txtMultiplierMargin.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtMultiplierMargin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.txtMultiplierMargin.Enabled = false;
            this.txtMultiplierMargin.FocusColor = System.Drawing.Color.LightYellow;
            this.txtMultiplierMargin.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtMultiplierMargin.ForeColor = System.Drawing.Color.Black;
            this.txtMultiplierMargin.IsEmailID = false;
            this.txtMultiplierMargin.IsEmailIdValid = false;
            this.txtMultiplierMargin.Location = new System.Drawing.Point(92, 232);
            this.txtMultiplierMargin.Name = "txtMultiplierMargin";
            this.txtMultiplierMargin.Size = new System.Drawing.Size(51, 20);
            this.txtMultiplierMargin.TabIndex = 99;
            this.txtMultiplierMargin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblMultiplier
            // 
            this.lblMultiplier.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblMultiplier.AutoSize = true;
            this.lblMultiplier.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMultiplier.Location = new System.Drawing.Point(93, 9);
            this.lblMultiplier.Name = "lblMultiplier";
            this.lblMultiplier.Size = new System.Drawing.Size(49, 26);
            this.lblMultiplier.TabIndex = 98;
            this.lblMultiplier.Text = "(B) Multiplier\r\n";
            this.lblMultiplier.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkSettleLtGrossExposure
            // 
            this.chkSettleLtGrossExposure.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chkSettleLtGrossExposure.AutoSize = true;
            this.chkSettleLtGrossExposure.Location = new System.Drawing.Point(290, 51);
            this.chkSettleLtGrossExposure.Name = "chkSettleLtGrossExposure";
            this.chkSettleLtGrossExposure.Size = new System.Drawing.Size(15, 14);
            this.chkSettleLtGrossExposure.TabIndex = 66;
            this.chkSettleLtGrossExposure.UseVisualStyleBackColor = true;
            this.chkSettleLtGrossExposure.CheckedChanged += new System.EventHandler(this.chkSettleLtGrossExposure_CheckedChanged);
            // 
            // lblGrossExposure
            // 
            this.lblGrossExposure.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblGrossExposure.AutoSize = true;
            this.lblGrossExposure.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGrossExposure.Location = new System.Drawing.Point(3, 51);
            this.lblGrossExposure.Name = "lblGrossExposure";
            this.lblGrossExposure.Size = new System.Drawing.Size(82, 13);
            this.lblGrossExposure.TabIndex = 100;
            this.lblGrossExposure.Text = "Gross Exposure\r\n";
            this.lblGrossExposure.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label51
            // 
            this.label51.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(150, 51);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(15, 13);
            this.label51.TabIndex = 102;
            this.label51.Text = "=\r\n";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label52
            // 
            this.label52.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(150, 78);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(15, 13);
            this.label52.TabIndex = 103;
            this.label52.Text = "=\r\n";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label53
            // 
            this.label53.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(150, 103);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(15, 13);
            this.label53.TabIndex = 104;
            this.label53.Text = "=\r\n";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label54
            // 
            this.label54.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(150, 130);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(15, 13);
            this.label54.TabIndex = 105;
            this.label54.Text = "=\r\n";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label55
            // 
            this.label55.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(150, 156);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(15, 13);
            this.label55.TabIndex = 106;
            this.label55.Text = "=\r\n";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label56
            // 
            this.label56.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(150, 182);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(15, 13);
            this.label56.TabIndex = 107;
            this.label56.Text = "=\r\n";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label57
            // 
            this.label57.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(150, 209);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(15, 13);
            this.label57.TabIndex = 108;
            this.label57.Text = "=\r\n";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label58
            // 
            this.label58.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(150, 236);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(15, 13);
            this.label58.TabIndex = 109;
            this.label58.Text = "=\r\n";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblsetLmtOpt
            // 
            this.lblsetLmtOpt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblsetLmtOpt.AutoSize = true;
            this.lblsetLmtOpt.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsetLmtOpt.Location = new System.Drawing.Point(284, 15);
            this.lblsetLmtOpt.Name = "lblsetLmtOpt";
            this.lblsetLmtOpt.Size = new System.Drawing.Size(27, 13);
            this.lblsetLmtOpt.TabIndex = 110;
            this.lblsetLmtOpt.Text = "Y/ N";
            this.lblsetLmtOpt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNetPos
            // 
            this.lblNetPos.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblNetPos.AutoSize = true;
            this.lblNetPos.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNetPos.Location = new System.Drawing.Point(3, 156);
            this.lblNetPos.Name = "lblNetPos";
            this.lblNetPos.Size = new System.Drawing.Size(64, 13);
            this.lblNetPos.TabIndex = 113;
            this.lblNetPos.Text = "Net Position";
            this.lblNetPos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNetTurnOver
            // 
            this.lblNetTurnOver.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblNetTurnOver.AutoSize = true;
            this.lblNetTurnOver.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNetTurnOver.Location = new System.Drawing.Point(3, 182);
            this.lblNetTurnOver.Name = "lblNetTurnOver";
            this.lblNetTurnOver.Size = new System.Drawing.Size(73, 13);
            this.lblNetTurnOver.TabIndex = 114;
            this.lblNetTurnOver.Text = "Net TurnOver";
            this.lblNetTurnOver.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMTMLmt
            // 
            this.lblMTMLmt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblMTMLmt.AutoSize = true;
            this.lblMTMLmt.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMTMLmt.Location = new System.Drawing.Point(3, 209);
            this.lblMTMLmt.Name = "lblMTMLmt";
            this.lblMTMLmt.Size = new System.Drawing.Size(53, 13);
            this.lblMTMLmt.TabIndex = 115;
            this.lblMTMLmt.Text = "MTM Limit";
            this.lblMTMLmt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMargin
            // 
            this.lblMargin.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblMargin.AutoSize = true;
            this.lblMargin.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMargin.Location = new System.Drawing.Point(3, 236);
            this.lblMargin.Name = "lblMargin";
            this.lblMargin.Size = new System.Drawing.Size(39, 13);
            this.lblMargin.TabIndex = 116;
            this.lblMargin.Text = "Margin";
            this.lblMargin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSettlements
            // 
            this.lblSettlements.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSettlements.AutoSize = true;
            this.lblSettlements.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSettlements.Location = new System.Drawing.Point(172, 2);
            this.lblSettlements.Name = "lblSettlements";
            this.lblSettlements.Size = new System.Drawing.Size(93, 39);
            this.lblSettlements.TabIndex = 117;
            this.lblSettlements.Text = "Settlements\r\n(A+C+D+E)xB=Limit\r\n";
            this.lblSettlements.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNetPurchase
            // 
            this.lblNetPurchase.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblNetPurchase.AutoSize = true;
            this.lblNetPurchase.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNetPurchase.Location = new System.Drawing.Point(3, 78);
            this.lblNetPurchase.Name = "lblNetPurchase";
            this.lblNetPurchase.Size = new System.Drawing.Size(71, 13);
            this.lblNetPurchase.TabIndex = 101;
            this.lblNetPurchase.Text = "Net Purchase\r\n";
            this.lblNetPurchase.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNetSale
            // 
            this.lblNetSale.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblNetSale.AutoSize = true;
            this.lblNetSale.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNetSale.Location = new System.Drawing.Point(3, 103);
            this.lblNetSale.Name = "lblNetSale";
            this.lblNetSale.Size = new System.Drawing.Size(43, 13);
            this.lblNetSale.TabIndex = 111;
            this.lblNetSale.Text = "Net Sell";
            this.lblNetSale.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNetQty
            // 
            this.lblNetQty.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblNetQty.AutoSize = true;
            this.lblNetQty.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNetQty.Location = new System.Drawing.Point(3, 130);
            this.lblNetQty.Name = "lblNetQty";
            this.lblNetQty.Size = new System.Drawing.Size(45, 13);
            this.lblNetQty.TabIndex = 112;
            this.lblNetQty.Text = "Net Qty";
            this.lblNetQty.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkDefaultSurviellance
            // 
            this.chkDefaultSurviellance.AutoSize = true;
            this.chkDefaultSurviellance.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDefaultSurviellance.Location = new System.Drawing.Point(18, 347);
            this.chkDefaultSurviellance.Name = "chkDefaultSurviellance";
            this.chkDefaultSurviellance.Size = new System.Drawing.Size(121, 17);
            this.chkDefaultSurviellance.TabIndex = 68;
            this.chkDefaultSurviellance.Text = "Default Surviellance";
            this.chkDefaultSurviellance.UseVisualStyleBackColor = true;
            // 
            // gbGeneralOptions
            // 
            this.gbGeneralOptions.Controls.Add(this.chkRetailMultiplier);
            this.gbGeneralOptions.Controls.Add(this.chkGrossCheck);
            this.gbGeneralOptions.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.gbGeneralOptions.Location = new System.Drawing.Point(8, 284);
            this.gbGeneralOptions.Name = "gbGeneralOptions";
            this.gbGeneralOptions.Size = new System.Drawing.Size(325, 50);
            this.gbGeneralOptions.TabIndex = 1;
            this.gbGeneralOptions.TabStop = false;
            this.gbGeneralOptions.Text = "General Options";
            // 
            // chkRetailMultiplier
            // 
            this.chkRetailMultiplier.AutoSize = true;
            this.chkRetailMultiplier.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkRetailMultiplier.Location = new System.Drawing.Point(142, 28);
            this.chkRetailMultiplier.Name = "chkRetailMultiplier";
            this.chkRetailMultiplier.Size = new System.Drawing.Size(102, 17);
            this.chkRetailMultiplier.TabIndex = 67;
            this.chkRetailMultiplier.Text = "Retain Multiplier";
            this.chkRetailMultiplier.UseVisualStyleBackColor = true;
            // 
            // chkGrossCheck
            // 
            this.chkGrossCheck.AutoSize = true;
            this.chkGrossCheck.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkGrossCheck.Location = new System.Drawing.Point(10, 28);
            this.chkGrossCheck.Name = "chkGrossCheck";
            this.chkGrossCheck.Size = new System.Drawing.Size(85, 17);
            this.chkGrossCheck.TabIndex = 66;
            this.chkGrossCheck.Text = "Gross Check";
            this.chkGrossCheck.UseVisualStyleBackColor = true;
            // 
            // gbDeposits
            // 
            this.gbDeposits.Controls.Add(this.txtCreditForSale);
            this.gbDeposits.Controls.Add(this.lblCreditForSale);
            this.gbDeposits.Controls.Add(this.txtSecurityCollateral);
            this.gbDeposits.Controls.Add(this.lblSecurityCollateral);
            this.gbDeposits.Controls.Add(this.txtAdhocDeposit);
            this.gbDeposits.Controls.Add(this.lblAdhocDeposit);
            this.gbDeposits.Controls.Add(this.txtDeposit);
            this.gbDeposits.Controls.Add(this.lblDeposit);
            this.gbDeposits.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.gbDeposits.Location = new System.Drawing.Point(5, 8);
            this.gbDeposits.Name = "gbDeposits";
            this.gbDeposits.Size = new System.Drawing.Size(349, 124);
            this.gbDeposits.TabIndex = 44;
            this.gbDeposits.TabStop = false;
            this.gbDeposits.Text = "Deposits";
            // 
            // txtCreditForSale
            // 
            this.txtCreditForSale.AllowAlpha = false;
            this.txtCreditForSale.AllowDot = true;
            this.txtCreditForSale.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtCreditForSale.AllowedCustomCharacters")));
            this.txtCreditForSale.AllowNonASCII = false;
            this.txtCreditForSale.AllowNumeric = true;
            this.txtCreditForSale.AllowSpace = false;
            this.txtCreditForSale.AllowSpecialChars = false;
            this.txtCreditForSale.FocusColor = System.Drawing.Color.LightYellow;
            this.txtCreditForSale.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtCreditForSale.ForeColor = System.Drawing.Color.Black;
            this.txtCreditForSale.IsEmailID = false;
            this.txtCreditForSale.IsEmailIdValid = false;
            this.txtCreditForSale.Location = new System.Drawing.Point(177, 87);
            this.txtCreditForSale.Name = "txtCreditForSale";
            this.txtCreditForSale.Size = new System.Drawing.Size(134, 20);
            this.txtCreditForSale.TabIndex = 50;
            this.txtCreditForSale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblCreditForSale
            // 
            this.lblCreditForSale.AutoSize = true;
            this.lblCreditForSale.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCreditForSale.Location = new System.Drawing.Point(174, 68);
            this.lblCreditForSale.Name = "lblCreditForSale";
            this.lblCreditForSale.Size = new System.Drawing.Size(89, 13);
            this.lblCreditForSale.TabIndex = 49;
            this.lblCreditForSale.Text = "Credit for Sell (E)";
            // 
            // txtSecurityCollateral
            // 
            this.txtSecurityCollateral.AllowAlpha = false;
            this.txtSecurityCollateral.AllowDot = true;
            this.txtSecurityCollateral.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtSecurityCollateral.AllowedCustomCharacters")));
            this.txtSecurityCollateral.AllowNonASCII = false;
            this.txtSecurityCollateral.AllowNumeric = true;
            this.txtSecurityCollateral.AllowSpace = false;
            this.txtSecurityCollateral.AllowSpecialChars = false;
            this.txtSecurityCollateral.FocusColor = System.Drawing.Color.LightYellow;
            this.txtSecurityCollateral.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtSecurityCollateral.ForeColor = System.Drawing.Color.Black;
            this.txtSecurityCollateral.IsEmailID = false;
            this.txtSecurityCollateral.IsEmailIdValid = false;
            this.txtSecurityCollateral.Location = new System.Drawing.Point(6, 87);
            this.txtSecurityCollateral.Name = "txtSecurityCollateral";
            this.txtSecurityCollateral.Size = new System.Drawing.Size(134, 20);
            this.txtSecurityCollateral.TabIndex = 48;
            this.txtSecurityCollateral.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblSecurityCollateral
            // 
            this.lblSecurityCollateral.AutoSize = true;
            this.lblSecurityCollateral.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecurityCollateral.Location = new System.Drawing.Point(6, 68);
            this.lblSecurityCollateral.Name = "lblSecurityCollateral";
            this.lblSecurityCollateral.Size = new System.Drawing.Size(112, 13);
            this.lblSecurityCollateral.TabIndex = 47;
            this.lblSecurityCollateral.Text = "Security Collateral (D)";
            // 
            // txtAdhocDeposit
            // 
            this.txtAdhocDeposit.AllowAlpha = false;
            this.txtAdhocDeposit.AllowDot = true;
            this.txtAdhocDeposit.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtAdhocDeposit.AllowedCustomCharacters")));
            this.txtAdhocDeposit.AllowNonASCII = false;
            this.txtAdhocDeposit.AllowNumeric = true;
            this.txtAdhocDeposit.AllowSpace = false;
            this.txtAdhocDeposit.AllowSpecialChars = false;
            this.txtAdhocDeposit.FocusColor = System.Drawing.Color.LightYellow;
            this.txtAdhocDeposit.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtAdhocDeposit.ForeColor = System.Drawing.Color.Black;
            this.txtAdhocDeposit.IsEmailID = false;
            this.txtAdhocDeposit.IsEmailIdValid = false;
            this.txtAdhocDeposit.Location = new System.Drawing.Point(177, 42);
            this.txtAdhocDeposit.Name = "txtAdhocDeposit";
            this.txtAdhocDeposit.Size = new System.Drawing.Size(134, 20);
            this.txtAdhocDeposit.TabIndex = 46;
            this.txtAdhocDeposit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblAdhocDeposit
            // 
            this.lblAdhocDeposit.AutoSize = true;
            this.lblAdhocDeposit.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdhocDeposit.Location = new System.Drawing.Point(174, 23);
            this.lblAdhocDeposit.Name = "lblAdhocDeposit";
            this.lblAdhocDeposit.Size = new System.Drawing.Size(94, 13);
            this.lblAdhocDeposit.TabIndex = 45;
            this.lblAdhocDeposit.Text = "Adhoc Deposit (C)";
            // 
            // txtDeposit
            // 
            this.txtDeposit.AllowAlpha = false;
            this.txtDeposit.AllowDot = true;
            this.txtDeposit.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtDeposit.AllowedCustomCharacters")));
            this.txtDeposit.AllowNonASCII = false;
            this.txtDeposit.AllowNumeric = true;
            this.txtDeposit.AllowSpace = false;
            this.txtDeposit.AllowSpecialChars = false;
            this.txtDeposit.FocusColor = System.Drawing.Color.LightYellow;
            this.txtDeposit.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtDeposit.ForeColor = System.Drawing.Color.Black;
            this.txtDeposit.IsEmailID = false;
            this.txtDeposit.IsEmailIdValid = false;
            this.txtDeposit.Location = new System.Drawing.Point(5, 38);
            this.txtDeposit.Name = "txtDeposit";
            this.txtDeposit.Size = new System.Drawing.Size(134, 20);
            this.txtDeposit.TabIndex = 44;
            this.txtDeposit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblDeposit
            // 
            this.lblDeposit.AutoSize = true;
            this.lblDeposit.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDeposit.Location = new System.Drawing.Point(5, 22);
            this.lblDeposit.Name = "lblDeposit";
            this.lblDeposit.Size = new System.Drawing.Size(61, 13);
            this.lblDeposit.TabIndex = 43;
            this.lblDeposit.Text = "Deposit (A)";
            // 
            // ucDeposits
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.gbSettlementLmt);
            this.Controls.Add(this.gbDeposits);
            this.Name = "ucDeposits";
            this.Size = new System.Drawing.Size(780, 650);
            this.gbSettlementLmt.ResumeLayout(false);
            this.gbSettlementLmt.PerformLayout();
            this.tblLayoutSettlementLmt.ResumeLayout(false);
            this.tblLayoutSettlementLmt.PerformLayout();
            this.gbGeneralOptions.ResumeLayout(false);
            this.gbGeneralOptions.PerformLayout();
            this.gbDeposits.ResumeLayout(false);
            this.gbDeposits.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbSettlementLmt;
        private System.Windows.Forms.TableLayoutPanel tblLayoutSettlementLmt;
        private MatchCommon.CustomControls.FTTextBox txtSettlLtMTMLt;
        private MatchCommon.CustomControls.FTTextBox txtMultiplierMTMLt;
        private MatchCommon.CustomControls.FTTextBox txtSettlLtNetTurnOver;
        private MatchCommon.CustomControls.FTTextBox txtMultiplierNetTurnOver;
        private MatchCommon.CustomControls.FTTextBox txtSettlLtNetPos;
        private MatchCommon.CustomControls.FTTextBox txtMultiplierNetPos;
        private MatchCommon.CustomControls.FTTextBox txtSettlLtNetQty;
        private MatchCommon.CustomControls.FTTextBox txtmultiplierNetQty;
        private MatchCommon.CustomControls.FTTextBox txtSettlLtNetSale;
        private MatchCommon.CustomControls.FTTextBox txtMultiplierNetSale;
        private System.Windows.Forms.CheckBox chkSettlLtNetPurchase;
        private MatchCommon.CustomControls.FTTextBox txtsettlLtNetPurchase;
        private MatchCommon.CustomControls.FTTextBox txtMultiplierNetPurchase;
        private MatchCommon.CustomControls.FTTextBox txtSettleLtGrossExposure;
        private MatchCommon.CustomControls.FTTextBox txtMultiplierGrossExposure;
        private System.Windows.Forms.CheckBox chkSettlLtNetSale;
        private System.Windows.Forms.CheckBox chkSettlLtNetQty;
        private System.Windows.Forms.CheckBox chkSettlLtNetPos;
        private System.Windows.Forms.CheckBox chkSettlLtNetTurnOver;
        private System.Windows.Forms.CheckBox chkSettlLtMTMLt;
        private System.Windows.Forms.CheckBox chkSettlLtMargin;
        private MatchCommon.CustomControls.FTTextBox txtSettlLtMargin;
        private MatchCommon.CustomControls.FTTextBox txtMultiplierMargin;
        private System.Windows.Forms.Label lblMultiplier;
        private System.Windows.Forms.CheckBox chkSettleLtGrossExposure;
        private System.Windows.Forms.Label lblGrossExposure;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label lblsetLmtOpt;
        private System.Windows.Forms.Label lblNetPos;
        private System.Windows.Forms.Label lblNetTurnOver;
        private System.Windows.Forms.Label lblMTMLmt;
        private System.Windows.Forms.Label lblMargin;
        private System.Windows.Forms.Label lblSettlements;
        private System.Windows.Forms.Label lblNetPurchase;
        private System.Windows.Forms.Label lblNetSale;
        private System.Windows.Forms.Label lblNetQty;
        private System.Windows.Forms.CheckBox chkDefaultSurviellance;
        private System.Windows.Forms.GroupBox gbGeneralOptions;
        private System.Windows.Forms.CheckBox chkRetailMultiplier;
        private System.Windows.Forms.CheckBox chkGrossCheck;
        private System.Windows.Forms.GroupBox gbDeposits;
        private MatchCommon.CustomControls.FTTextBox txtCreditForSale;
        private System.Windows.Forms.Label lblCreditForSale;
        private MatchCommon.CustomControls.FTTextBox txtSecurityCollateral;
        private System.Windows.Forms.Label lblSecurityCollateral;
        private MatchCommon.CustomControls.FTTextBox txtAdhocDeposit;
        private System.Windows.Forms.Label lblAdhocDeposit;
        private MatchCommon.CustomControls.FTTextBox txtDeposit;
        private System.Windows.Forms.Label lblDeposit;
    }
}
