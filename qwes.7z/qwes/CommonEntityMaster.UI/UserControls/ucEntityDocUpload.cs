﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using UCC.Class;
using FTIL.Match.Common;
using FTIL.Match.CDD.BAL;
using System.IO;
using FTIL.Match.CDD.UI.Forms;
using FTIL.Match.Common.Log;
using C1.Win.C1FlexGrid;

namespace FTIL.Match.CDD.UI.UserControls
{
   

    public partial class ucEntityDocUpload : ucBaseEntity
    {

       public int ClientNo {get;set;}

       private int m_CurrentClientDocNo;
       private DataTable m_UploadDocumentDetails;
       private frmImageViewer m_frmImgViewer;
      
       private long m_DocumentUploadMaxLimit;
       private string m_CurrentImgName ;


       private Dictionary<int, UploadedDocument> m_DocumentImage;

        private void ucEntityDocUpload_Load(object sender, EventArgs e)
        {
            try
            {
                PopulateLookup();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this.GetType(), ex.Message);
            }
            btnExport.Enabled = false;
            ftBtnRemoveDoc.Enabled = false;
        }


        public ucEntityDocUpload()
        {
            InitializeComponent();

            dgvDocUpload.DoubleClick += this.dgvDocUpload_Click;
            m_DocumentImage = new Dictionary<int, UploadedDocument>();

            m_DocumentUploadMaxLimit =
                   Convert.ToInt64(System.Configuration.ConfigurationManager.AppSettings["DocumentUploadMaxLimitBytes"]);


            RequiredSync = false;

            dgvDocUpload.Cols.Fixed = UIConstants.FlexGridLeftFixColumn;
        }

        protected  override void PopulateLookup() 
        {
            try
            {
                DataTable dtDocDetail = null;
                DataSet dsDoc = null;

                CEntityMaster.GetEntityDocDetails(ClientNo, "DOC_UPLOAD", ref dsDoc);
                dtDocDetail = dsDoc.Tables[0];
                if (dtDocDetail == null)
                {
                    btnImport.Enabled = false;
                    return;
                }


                btnImport.Enabled = dtDocDetail.Rows.Count > 0;

                ftCmbTypeofDocument.ValueMember = "n_ClientDocNo";
                ftCmbTypeofDocument.DisplayMember = "s_DocType";
                ftCmbTypeofDocument.DataSource = dtDocDetail;

                BindGrid();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this.GetType(), ex.Message);
            }

        }

        public override void PopulateControls()
        {
            picDocument.Image = null;
            PopulateLookup();
        }

        private void btnImport_Click(object sender, EventArgs e)
        {

            int nClientDocNo = Convert.ToInt32(ftCmbTypeofDocument.SelectedValue.ToString());

            
            if (HasDocUploaded(nClientDocNo))
            {
                DialogResult resultUpd = MessageBox.Show("Document already uploaded, do you want to overwrite?"
                    , sClientHeaderName, MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (resultUpd != DialogResult.Yes)
                    return;
            }


            OpenFileDialog openFileDialog = new OpenFileDialog();
           //openFileDialog.Filter = "Image files (*.jpg)|*.jpg|All files (*.*)|*.*";
            openFileDialog.Filter = "Image files  |*.jpg;*.bmp;*.dib;*.jpg;*.jpeg ;*.jpe;*.jfif ;*.gif;*.tif;*.tiff";

     
            DialogResult result = openFileDialog.ShowDialog();

            if (result != DialogResult.OK)
            {
                return;
            }
            try
            {

                FileInfo fInfo = new FileInfo(openFileDialog.FileName);

                if (fInfo.Length > m_DocumentUploadMaxLimit && m_DocumentUploadMaxLimit > 0)
                {
                    lblUploadLog.Text = "Image can not be larger than " + (m_DocumentUploadMaxLimit / 1024) + " KB.";
                    return;
                }

                
         
                MethodExecResult resultMethod = CEntityMaster.UploadDocument(
                                                     "U", nClientDocNo, Path.GetFileName(openFileDialog.FileName),
                                                      File.ReadAllBytes(openFileDialog.FileName), txtComment.Text.Trim(),
                                                     fInfo.Length,
                                                     fInfo.LastWriteTime,
                                                     ClientNo,
                                                     'D',null
                                                      );

                if (resultMethod.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    EntityManager.AutoAuthorized(ClientNo);
                    
                    BindGrid();

                    MessageBox.Show("Document uploaded successfully.", sClientHeaderName, MessageBoxButtons.OK);

                    try
                    {
                        m_DocumentImage.Remove(nClientDocNo);
                    }
                    catch { }

                    RequiredSync = true;

                }
                else
                    MessageBox.Show("Unable to upload image Data. " + resultMethod.ErrorMessage,
                        sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this.GetType(), ex.Message);
                MessageBox.Show("Unable to upload image Data. Error :" + ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void BindGrid()
        {
            try
            {
                CEntityMaster.GetUploadedDocumentDetail(ClientNo, ref  m_UploadDocumentDetails);
                dgvDocUpload.DataSource = m_UploadDocumentDetails;

                dgvDocUpload.Cols["n_ClientDocNo"].Visible = false;
                dgvDocUpload.Cols["n_Type"].Visible = false;
                dgvDocUpload.Cols["s_Remarks"].Visible = false;



                dgvDocUpload.Cols["s_DocType"].Caption = "Document";
                dgvDocUpload.Cols["s_Details"].Caption = "Details";

                dgvDocUpload.Cols["s_FileName"].Caption = "File Name";
                dgvDocUpload.Cols["n_FileSizeKB"].Caption = "Size(KB)";
                dgvDocUpload.Cols["d_FileModifiedDateTime"].Caption = "Last Updated Date";
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this.GetType(), ex.Message);
            }
        }


        private bool HasDocUploaded(int ClientDocNo)
        {
            try
            {
                if (m_UploadDocumentDetails == null) return false;

                if (m_UploadDocumentDetails.Rows.Count == 0) return false;

                DataRow[] dr = m_UploadDocumentDetails.Select("n_ClientDocNo=" + ClientDocNo);

                if (dr == null) return false;

                if (dr.Length > 0) return true;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this.GetType(), ex.Message);
            }
           return false;
        }


      

        private void dgvDocUpload_Click(object sender, EventArgs e)
        {
            LoadImage();
        }


        private void LoadImage()
        {
            try
            {
                Row l_objRow = dgvDocUpload.Rows.Selected[0];

                string sClientDocNo = l_objRow["n_ClientDocNo"].ToString();
                ftCmbTypeofDocument.Text = l_objRow["s_DocType"].ToString();
                txtComment.Text = l_objRow["s_Remarks"].ToString();
            
            int nClientDocNo = 0;

            if (!int.TryParse(sClientDocNo, out nClientDocNo))
                return;

            UploadedDocument img = null;
            try
            {
                img = m_DocumentImage[nClientDocNo];

                if (img.ImageFile == null) img = null;

            }
            catch
            { }


            if (img == null)
            {
                img = new UploadedDocument();

                DataTable resultDataTable = new DataTable();
                CEntityMaster.GetUploadedDocumentImage(nClientDocNo, 'D', ref  resultDataTable);
                byte[] imgBytes = null;

                try
                {
                    imgBytes = (byte[])resultDataTable.Rows[0]["b_BinaryDoc"];
                    img.FileName = Convert.ToString(resultDataTable.Rows[0]["s_FileName"]);
                }
                catch
                { }

                if (imgBytes != null)
                {
                    img.ImageFile = FormUtil.byteArrayToImage(imgBytes);

              
                    btnExport.Enabled = true;
                    ftBtnRemoveDoc.Enabled = true;

                }
            }

            picDocument.Image = img.ImageFile;
            m_CurrentClientDocNo = nClientDocNo;
            m_CurrentImgName = img.FileName;
            m_DocumentImage[nClientDocNo] = img;
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Kindly select the Image Data. ", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                Logger.Instance.WriteLog(this.GetType(), ex.Message);
            }

        }


        private void DeleteImage()
        {
            try
            {

                MethodExecResult resultMethod = CEntityMaster.UploadDocument(
                                                     "D", m_CurrentClientDocNo, null,null, txtComment.Text.Trim(), -1, null, ClientNo, 'D',null);

                if (resultMethod.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {

                    EntityManager.AutoAuthorized(ClientNo);

                    BindGrid();

                    MessageBox.Show("Document delete successfully.", sClientHeaderName, MessageBoxButtons.OK);

                    btnExport.Enabled = false;
                    ftBtnRemoveDoc.Enabled = false;

                    try
                    {
                        m_DocumentImage.Remove(m_CurrentClientDocNo);
                    }
                    catch { }


                    RequiredSync = true;

                }
                else
                    MessageBox.Show("Unable to delete image. " + resultMethod.ErrorMessage,
                        sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to upload image Data. " + ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                Logger.Instance.WriteLog(this.GetType(), ex.Message);
            }
        }

        private void ftBtnRemoveDoc_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(MatchCommon.CCommon.DeleteWarningMessage, sClientHeaderName,
                                                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result != System.Windows.Forms.DialogResult.Yes)
                return;

            picDocument.Image = null;
            DeleteImage();

        }

        private void picDocument_DoubleClick(object sender, EventArgs e)
        {
            ShowImageDialog();
        }

        private void ShowImageDialog()
        {
            if (m_frmImgViewer == null)
            {
                m_frmImgViewer = new frmImageViewer();
             }
            if (picDocument.Image != null)
            {
                m_frmImgViewer.Text = m_CurrentImgName;
                m_frmImgViewer.LoadImage(picDocument.Image);
                m_frmImgViewer.ShowDialog();
            }
 
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            if (picDocument.Image == null)
                return;

            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Image files  |*.jpg;*.bmp;*.dib;*.jpg;*.jpeg ;*.jpe;*.jfif ;*.gif;*.tif;*.tiff";

        
            saveFileDialog.FileName = m_DocumentImage[m_CurrentClientDocNo].FileName;

            DialogResult result = saveFileDialog.ShowDialog();

       
            if (result != DialogResult.OK)
            {
                return;
            }
            try
            {

                picDocument.Image.Save(saveFileDialog.FileName);

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this.GetType(), ex.Message);
                MessageBox.Show("Unable to save image. ", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void ucEntityDocUpload_MouseClick(object sender, MouseEventArgs e)
        {
            lblUploadLog.Text = string.Empty;
        }

        private void dgvDocUpload_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
           
            if (e.KeyCode == Keys.Enter)
            {
                LoadImage();
                dgvDocUpload.Row = dgvDocUpload.Row - 1;
            }

        }

    
      
    }
}
