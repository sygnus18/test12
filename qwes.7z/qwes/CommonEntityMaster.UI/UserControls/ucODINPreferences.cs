﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FTIL.Match.CDD.UI.UserControls
{
    public partial class ucODINPreferences : UserControl
    {
        public bool cboParentAC_StateChanged { get; set; }
        private ucClientPreferences objClientPreferences;
        public ucODINPreferences()
        {
            InitializeComponent();
        }

        private void ucQDINPreferences_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void gbUserDetails_Enter(object sender, EventArgs e)
        {

        }

        private void textBox16_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox24_TextChanged(object sender, EventArgs e)
        {

        }

        private void gbDeposits_Enter(object sender, EventArgs e)
        {

        }

        private void gbSecurities_Enter(object sender, EventArgs e)
        {

        }

        private void gbOrdrLmt_Enter(object sender, EventArgs e)
        {

        }
        private void BindUserControls()
        {
            //if (objClientPreferences == null)
            //{
            //    objClientPreferences = new ucClientPreferences();
            //    objClientPreferences.Dock = DockStyle.Top;
            //    tbTrading.Controls.Add(objClientPreferences);
            //    tbTrading.Tag = objODINPreferences;
            //}
        }

        private void gbUserDetails_Enter_1(object sender, EventArgs e)
        {

        }

        private void gbUserDetails_Enter_2(object sender, EventArgs e)
        {

        }

        private void gbTradingDetails_Enter(object sender, EventArgs e)
        {

        }

        private void tblLayoutSettlementLmt_Paint(object sender, PaintEventArgs e)
        {

        }

        private void cboParentAC_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (objClientPreferences.chkIsParentAc_Checked == true)
            //{
            //    cboParentAC.FormattingEnabled = false;
            //}
        }

       
       
    }    
}
