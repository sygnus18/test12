﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FTIL.Match.CDD.BAL;
using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.CDD.UI.Forms;
using FTIL.Match.Common.Log;
using FTIL.Match.Common;
using UCC.Class;
using C1.Win.C1FlexGrid;

namespace FTIL.Match.CDD.UI.UserControls
{
    public partial class ucEntityExchangeMap : UserControl
    {
        #region Variables
        
        private CExchangeMap m_ObjExchange;
        private EntityDetails m_EntityDetails;
        private frmProcess objProcess;
        private MatchCommon.CustomControls.FTTextBox txtCDDCustCodeForGrid;
        private MatchCommon.CustomControls.FTTextBox txtDPCodeForGrid;
        CheckBox HeaderCheckBox = null;

//-------------------------------------------------------------------------------


        private FTIL.Match.CDD.ProductSync.Forms.frmFrame objFrame;
        //private CDD.ProductSync.Forms.frmFrame objFrame;

        private CProductSync m_ObjProductSync;
        private EntityDetails m_EntityDetails1;
        private frmProcess objProcess1;
        private MatchCommon.CustomControls.FTTextBox txtCDDCustCodeForGrid1;
        private MatchCommon.CustomControls.FTTextBox txtDPCodeForGrid1;
        DataTable dtProduct = null;

        public string sClientHeaderName { get; set; }

        public int ExNo { get; set; }
        public int ExMapingNo { get; set; }
        public int TradingCode { get; set; }
        public int CtclId { get; set; }
        public int TradingBranchId { get; set; }
        public int ExchangeNo { get; set; }
        public int AddModifyFlag { get; set; }
        public int ClientNo { get; set; }
        DataTable dtExchange = null;
        static int length = 0;
        #endregion

        public EntityDetails EntityDetails
        {
            get { return m_EntityDetails; }
            set { m_EntityDetails = value; }
        }

        public ucEntityExchangeMap()
        {
            InitializeComponent();
            m_ObjExchange = new CExchangeMap();
            dgvClientExchange.Cols.Fixed = UIConstants.FlexGridLeftFixColumn;
            dgvClientExchange.AllowEditing = true;
            dgvClientExchange.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;

            txtCDDCustCodeForGrid = new MatchCommon.CustomControls.FTTextBox();
            txtCDDCustCodeForGrid.MaxLength = 30;
            txtCDDCustCodeForGrid.AllowAlpha = true;
            txtCDDCustCodeForGrid.AllowDot = false;
            txtCDDCustCodeForGrid.AllowNonASCII = false;
            txtCDDCustCodeForGrid.AllowSpace = false;
            txtCDDCustCodeForGrid.AllowSpecialChars = false;
            txtCDDCustCodeForGrid.AllowNumeric = true;

            txtDPCodeForGrid = new MatchCommon.CustomControls.FTTextBox();
            txtDPCodeForGrid.MaxLength = 30;
            txtDPCodeForGrid.AllowAlpha = true;
            txtDPCodeForGrid.AllowDot = false;
            txtDPCodeForGrid.AllowNonASCII = false;
            txtDPCodeForGrid.AllowSpace = false;
            txtDPCodeForGrid.AllowSpecialChars = false;
            txtDPCodeForGrid.AllowNumeric = true;


//-------------------------------------------------------------------------------------------


            //InitializeComponent();
            m_ObjProductSync = new CProductSync();
            dgvProduct.Cols.Fixed = UIConstants.FlexGridLeftFixColumn;
            dgvProduct.AllowEditing = true;
            dgvProduct.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;

            txtCDDCustCodeForGrid1 = new MatchCommon.CustomControls.FTTextBox();
            txtCDDCustCodeForGrid1.MaxLength = 30;
            txtCDDCustCodeForGrid1.AllowAlpha = true;
            txtCDDCustCodeForGrid1.AllowDot = false;
            txtCDDCustCodeForGrid1.AllowNonASCII = false;
            txtCDDCustCodeForGrid1.AllowSpace = false;
            txtCDDCustCodeForGrid1.AllowSpecialChars = false;
            txtCDDCustCodeForGrid1.AllowNumeric = true;

            txtDPCodeForGrid1 = new MatchCommon.CustomControls.FTTextBox();
            txtDPCodeForGrid1.MaxLength = 30;
            txtDPCodeForGrid1.AllowAlpha = true;
            txtDPCodeForGrid1.AllowDot = false;
            txtDPCodeForGrid1.AllowNonASCII = false;
            txtDPCodeForGrid1.AllowSpace = false;
            txtDPCodeForGrid1.AllowSpecialChars = false;
            txtDPCodeForGrid1.AllowNumeric = true;
        }

        private void dgvClientExchange_Click(object sender, EventArgs e)
        {
            int SelRow = this.dgvClientExchange.RowSel;
            int SelCol = this.dgvClientExchange.ColSel;
            if (SelCol == 0)
            {
                int chkCount = 1;
                if (!chkSelectAll.Checked)
                {
                    int ctr = 1;
                    for (ctr = 1; ctr < this.dgvClientExchange.Rows.Count; ctr++)
                    {
                        if (Convert.ToInt32(this.dgvClientExchange[ctr, 0]) == 1)
                        {
                            chkCount++;
                        }
                    }
                    if (this.dgvClientExchange.Rows.Count == chkCount)
                    {
                        chkSelectAll.Checked = true;
                    }
                }
                else if (chkSelectAll.Checked)
                {
                    int ctr = 1;
                    for (ctr = 1; ctr < this.dgvClientExchange.Rows.Count; ctr++)
                    {
                        if (Convert.ToInt32(this.dgvClientExchange[ctr, 0]) == 1)
                        {
                            chkCount++;
                        }
                    }
                    if (chkCount < this.dgvClientExchange.Rows.Count)
                    {
                        chkSelectAll.Checked = false;
                    }
                }
            }
        }

        private void ucEntityExchangeMap_Load(object sender, EventArgs e)
        {
            BindGrid();
            if (!chkSelectAll.Checked)
            {
                int chkCount = 1;
                for (int ctr = 1; ctr < this.dgvClientExchange.Rows.Count; ctr++)
                {
                    if (Convert.ToInt32(this.dgvClientExchange[ctr, 0]) == 1)
                    {
                        chkCount++;
                    }
                }
                if (this.dgvClientExchange.Rows.Count == chkCount)
                {
                    chkSelectAll.Checked = true;
                }
            }


        }

        public void PopulateControls()
        {
            BindGrid();
        }

        private void BindGrid()
        {
            //m_ObjExchange.GetExchangeDetails(ExNo, ref dtExchange);

            dgvClientExchange.DataSource = dtExchange;

            this.dgvClientExchange.Cols["n_ExchangeNo"].Visible = false;
            this.dgvClientExchange.Cols["n_ExMapNo"].Visible = false;
            this.dgvClientExchange.Cols["n_ClientNo"].Visible = false;

            //this.dgvClientExchange.Cols["b_Flag"]= C1.Win.C1FlexGrid.CheckEnum.Unchecked;
            dgvClientExchange.Cols["b_Flag"].Caption = "";
            dgvClientExchange.Cols["s_ExchangeCode"].Caption = "Exchange";
            dgvClientExchange.Cols["s_ExchangeName"].Caption = "Exchange Name"; 
            dgvClientExchange.Cols["n_TradingCode"].Caption = "Trading Code";
            dgvClientExchange.Cols["n_CtclId"].Caption = "Ctcl/Tws Id";
            dgvClientExchange.Cols["n_TradingBranchId"].Caption = "Trading Branch Id";

            dgvClientExchange.Cols["b_Flag"].Width = 75;
            dgvClientExchange.Cols["s_ExchangeCode"].Width = 80;
            dgvClientExchange.Cols["s_ExchangeName"].Width = 180;
            dgvClientExchange.Cols["n_TradingCode"].Width = 140;
            dgvClientExchange.Cols["n_CtclId"].Width = 140;
            dgvClientExchange.Cols["n_TradingBranchId"].Width = 140;

            //dgvClientExchange.Cols["b_Flag"].AllowEditing = false;
            this.dgvClientExchange.Cols["s_ExchangeCode"].AllowEditing = false;
            this.dgvClientExchange.Cols["s_ExchangeName"].AllowEditing = false;
            this.dgvClientExchange.Cols["n_TradingCode"].AllowEditing = true;
            this.dgvClientExchange.Cols["n_CtclId"].AllowEditing = true;
            this.dgvClientExchange.Cols["n_TradingBranchId"].AllowEditing = true;

           C1.Win.C1FlexGrid.CellStyle cs;
            cs = dgvClientExchange.Styles.Add("Blue");
            cs.Font = new Font(Font, FontStyle.Underline);
            cs.ForeColor = System.Drawing.Color.Blue;



//-----------------------------------------------------------------------------------------------------




            m_ObjProductSync.GetEntityProducts(ClientNo, ref dtProduct);

            dgvProduct.DataSource = dtProduct;
            dgvProduct.Cols["n_ProductNo"].Visible = false;
            this.dgvProduct.Cols["n_LinkRequired"].Visible = false;
            this.dgvProduct.Cols["DPCode"].Visible = false;


            dgvProduct.Cols["b_Flag"].Caption = "";
            dgvProduct.Cols["s_ProductName"].Caption = "Product";
            dgvProduct.Cols["s_EntityProductID"].Caption = "Code";

            dgvProduct.Cols["b_Flag"].Width = 40;
            dgvProduct.Cols["s_ProductName"].Width = 150;
            dgvProduct.Cols["s_EntityProductID"].Width = 170;
            dgvProduct.Cols["Status"].Width = 90;
            dgvProduct.Cols["Last Sync Date"].Width = 150;
            dgvProduct.Cols["Description"].Width = 180;// 180;
            dgvProduct.Cols["s_EntityProductID"].Editor = txtCDDCustCodeForGrid;
            dgvProduct.Cols["DPCode"].Editor = txtDPCodeForGrid;

            dgvProduct.Cols["s_ProductName"].AllowEditing = false;
            this.dgvProduct.Cols["DPCode"].AllowEditing = false;
            this.dgvProduct.Cols["Description"].AllowEditing = false;
            this.dgvProduct.Cols["Status"].AllowEditing = false;
            this.dgvProduct.Cols["Last Sync Date"].AllowEditing = false;
            this.dgvProduct.Cols["Last Sync Date"].Format = "dd/MM/yy hh:mm tt";

           C1.Win.C1FlexGrid.CellStyle cs1;
            cs1 = dgvProduct.Styles.Add("Blue");
            cs1.Font = new Font(Font, FontStyle.Underline);
            cs1.ForeColor = System.Drawing.Color.Blue;
            for (int iCnt = 1; iCnt <= dgvProduct.Rows.Count - 1; iCnt++)
            {
                if (this.dgvProduct.Rows[iCnt]["Description"].ToString() == "Successfull" && this.dgvProduct.Rows[iCnt]["n_LinkRequired"].ToString() == "1")
                {
                    //dgvProduct.SetCellStyle(iCnt, 1, cs1);
                }
            }

        }


        public void UpdateExchangeData(DataRow dt)
        {
            if (dt["n_TradingCode"] != DBNull.Value)
            {
                this.TradingCode = Convert.ToInt32(dt["n_TradingCode"]);
            }
            else
            {
                this.TradingCode = 0;
                //this.TradingCode =null ;
            }
            
            if(dt["n_CtclId"] != DBNull.Value)
            {
                this.CtclId = Convert.ToInt32(dt["n_CtclId"]);
            }
            else
            {
                this.CtclId = 0;
            }

            if (dt["n_TradingBranchId"] != DBNull.Value)
            {
                this.TradingBranchId = Convert.ToInt32(dt["n_TradingBranchId"]);
            }
            else
            {
                this.TradingBranchId = 0;
            }

            DataRow[] dr = dtExchange.Select("b_Flag = true");
            
            if (dt["n_ExMapNo"] == DBNull.Value)
            {
                m_ObjExchange.AddModifyFlag = 1;
                m_ObjExchange.ExMapingNo = this.ExMapingNo;
            }
            else
            {
                m_ObjExchange.AddModifyFlag = 2;
                m_ObjExchange.ExMapingNo = Convert.ToInt32(dt[4]);
            }
                m_ObjExchange.EntityType = Convert.ToString(dt[1]);
                m_ObjExchange.ExchangeNo = Convert.ToInt32(dt[2]);
               
                m_ObjExchange.ClientNo = this.ClientNo;
                m_ObjExchange.TradingCode = this.TradingCode;
                m_ObjExchange.CtclId =this.CtclId;
                m_ObjExchange.TradingBranchId = this.TradingBranchId;
                     
            MethodExecResult m_MethodExecResult = m_ObjExchange.UpdateExchangeData();
            if (m_MethodExecResult.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                length++;
                if (dr.Length == length)
                {
                    MessageBox.Show("Entity Exchange Data updated successfully.", string.Empty, MessageBoxButtons.OK);
                    length = 0;
                }
            }
            else
            {
                Logger.Instance.WriteLog(this, m_MethodExecResult);
                MessageBox.Show("Failed to update Entity Exchange Data.", string.Empty, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
           
        }
        
        private void dgvClientExchange_CellChanged(object sender, RowColEventArgs e)
        {
        }
        private void chkSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            //chkCount = Convert.ToInt32(this.dgvClientExchange.Rows.Count);
            int chkCount = 1;
            for (int ctr = 1; ctr < this.dgvClientExchange.Rows.Count; ctr++)
            {
                if (Convert.ToInt32(this.dgvClientExchange[ctr, 0]) == 1)
                {
                    chkCount++;
                }
            }
            
            if (chkSelectAll.Checked)
            {
                for (int ctr = 1; ctr < this.dgvClientExchange.Rows.Count; ctr++)
                {
                    this.dgvClientExchange[ctr, 0] = 1;
                }
            }
            else if (!chkSelectAll.Checked)
            {
                if (Convert.ToInt32(this.dgvClientExchange.Rows.Count) == chkCount)
                {
                    for (int ctr = 1; ctr < this.dgvClientExchange.Rows.Count; ctr++)
                    {
                        this.dgvClientExchange[ctr, 0] = 0;
                    }
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //this.Cursor = Cursors.WaitCursor;
            try
            {
                DataRow[] dr = dtExchange.Select("b_Flag = true");
                if (dr.Length == 0)
                {
                    MessageBox.Show("Kindly select at least one Exchange.", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Cursor = Cursors.Default;
                    return;
                }
                else if (dr.Length != 0)
                {
                    foreach (DataRow ds in dr)
                    {
                        UpdateExchangeData(ds);
                    }
                    BindGrid();
                }
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                Logger.Instance.WriteLog(typeof(frmEntityDetail), ex.Message);
                MessageBox.Show(MatchCommon.CCommon.CommonUpdateFailureMessage, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

   // internal class CExchangeMap
   // {
   // }
}
    

