﻿namespace FTIL.Match.CDD.UI.UserControls
{
    partial class ucClientPreferences
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucClientPreferences));
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.chkAllowtoBrok = new MatchCommon.CustomControls.FTCheckBox();
            this.lblMethod = new MatchCommon.CustomControls.FTLabel();
            this.cboBrokMethod = new MatchCommon.CustomControls.FTComboBox();
            this.txtBrokSlab = new MatchCommon.CustomControls.FTTextBox();
            this.lblScheme = new MatchCommon.CustomControls.FTLabel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtAfterPayoutSecurities = new MatchCommon.CustomControls.FTTextBox();
            this.txtAfterPayoutFunds = new MatchCommon.CustomControls.FTTextBox();
            this.label4 = new MatchCommon.CustomControls.FTLabel();
            this.label3 = new MatchCommon.CustomControls.FTLabel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtBeforePayinSecurities = new MatchCommon.CustomControls.FTTextBox();
            this.txtBeforePayinFunds = new MatchCommon.CustomControls.FTTextBox();
            this.label2 = new MatchCommon.CustomControls.FTLabel();
            this.label1 = new MatchCommon.CustomControls.FTLabel();
            this.gbDemat = new System.Windows.Forms.GroupBox();
            this.cboRegionMapping = new MatchCommon.CustomControls.FTComboBox();
            this.cboChargeDeliveryCharges = new MatchCommon.CustomControls.FTComboBox();
            this.cboStockTransfer = new MatchCommon.CustomControls.FTComboBox();
            this.cboContractNoGen = new MatchCommon.CustomControls.FTComboBox();
            this.cboContractFormType = new MatchCommon.CustomControls.FTComboBox();
            this.lblRegionMapping = new MatchCommon.CustomControls.FTLabel();
            this.lblChargeDeliveryCharges = new MatchCommon.CustomControls.FTLabel();
            this.lblStockTransfer = new MatchCommon.CustomControls.FTLabel();
            this.lblContractNoGen = new MatchCommon.CustomControls.FTLabel();
            this.lblContractFormType = new MatchCommon.CustomControls.FTLabel();
            this.cboSettDateOnContract = new MatchCommon.CustomControls.FTComboBox();
            this.lblSettleDt = new MatchCommon.CustomControls.FTLabel();
            this.gbOtherPreferences = new System.Windows.Forms.GroupBox();
            this.cbIncludeSEBIInBrok = new MatchCommon.CustomControls.FTCheckBox();
            this.cbIncludeTOInBrok = new MatchCommon.CustomControls.FTCheckBox();
            this.cbIncludeAuctionPenalInBrkg = new MatchCommon.CustomControls.FTCheckBox();
            this.cbIncludeCCinBrok = new MatchCommon.CustomControls.FTCheckBox();
            this.cbIncludeCFinBrok = new MatchCommon.CustomControls.FTCheckBox();
            this.cbIncludeSDinBrok = new MatchCommon.CustomControls.FTCheckBox();
            this.cbIncludeSTTinBrok = new MatchCommon.CustomControls.FTCheckBox();
            this.cbIncludeSTinBrok = new MatchCommon.CustomControls.FTCheckBox();
            this.cboGlobalPreference = new MatchCommon.CustomControls.FTComboBox();
            this.cboPaymentMode = new MatchCommon.CustomControls.FTComboBox();
            this.cboTradeClub = new MatchCommon.CustomControls.FTComboBox();
            this.lblGlobalPreferences = new MatchCommon.CustomControls.FTLabel();
            this.lblPaymentMode = new MatchCommon.CustomControls.FTLabel();
            this.lblTradeClub = new MatchCommon.CustomControls.FTLabel();
            this.cbRunningClient = new MatchCommon.CustomControls.FTCheckBox();
            this.cbPOA = new MatchCommon.CustomControls.FTCheckBox();
            this.txtIntRate = new MatchCommon.CustomControls.FTTextBox();
            this.lblIntRate = new MatchCommon.CustomControls.FTLabel();
            this.gbSTPDetails = new System.Windows.Forms.GroupBox();
            this.cboFlatISO = new MatchCommon.CustomControls.FTComboBox();
            this.cboDownloadFor = new MatchCommon.CustomControls.FTComboBox();
            this.cboFormat = new MatchCommon.CustomControls.FTComboBox();
            this.cboServProvider = new MatchCommon.CustomControls.FTComboBox();
            this.lblDownloadFor = new MatchCommon.CustomControls.FTLabel();
            this.lblFormat = new MatchCommon.CustomControls.FTLabel();
            this.lblServProvider = new MatchCommon.CustomControls.FTLabel();
            this.txtPreferenceCode = new MatchCommon.CustomControls.FTTextBox();
            this.lblPreferenceCode = new MatchCommon.CustomControls.FTLabel();
            this.lblChargeSlab = new MatchCommon.CustomControls.FTLabel();
            this.txtCharge = new MatchCommon.CustomControls.FTTextBox();
            this.cboSettlementOn = new MatchCommon.CustomControls.FTComboBox();
            this.lblSettlementOn = new MatchCommon.CustomControls.FTLabel();
            this.gbPrintingAllowedFor = new System.Windows.Forms.GroupBox();
            this.cbContracts = new MatchCommon.CustomControls.FTCheckBox();
            this.cbBills = new MatchCommon.CustomControls.FTCheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtFmlyGroupName = new System.Windows.Forms.TextBox();
            this.txtFmlyGroupCode = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtG3 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cboBillNoGen = new MatchCommon.CustomControls.FTComboBox();
            this.cboBillGeneration = new MatchCommon.CustomControls.FTComboBox();
            this.lblBillNoGen = new MatchCommon.CustomControls.FTLabel();
            this.lblBillGeneration = new MatchCommon.CustomControls.FTLabel();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.gbDemat.SuspendLayout();
            this.gbOtherPreferences.SuspendLayout();
            this.gbSTPDetails.SuspendLayout();
            this.gbPrintingAllowedFor.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.chkAllowtoBrok);
            this.groupBox3.Controls.Add(this.lblMethod);
            this.groupBox3.Controls.Add(this.cboBrokMethod);
            this.groupBox3.Controls.Add(this.txtBrokSlab);
            this.groupBox3.Controls.Add(this.lblScheme);
            this.groupBox3.Location = new System.Drawing.Point(5, 69);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(690, 43);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Brokerage ";
            // 
            // chkAllowtoBrok
            // 
            this.chkAllowtoBrok.AutoSize = true;
            this.chkAllowtoBrok.ForeColor = System.Drawing.Color.Black;
            this.chkAllowtoBrok.Location = new System.Drawing.Point(590, 19);
            this.chkAllowtoBrok.Name = "chkAllowtoBrok";
            this.chkAllowtoBrok.Size = new System.Drawing.Size(92, 17);
            this.chkAllowtoBrok.TabIndex = 2;
            this.chkAllowtoBrok.Text = "Allow To Brok";
            this.chkAllowtoBrok.UseVisualStyleBackColor = true;
            // 
            // lblMethod
            // 
            this.lblMethod.AllowForeColorChange = false;
            this.lblMethod.AutoSize = true;
            this.lblMethod.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblMethod.ForeColor = System.Drawing.Color.Black;
            this.lblMethod.Location = new System.Drawing.Point(6, 18);
            this.lblMethod.Name = "lblMethod";
            this.lblMethod.OverrideDefault = false;
            this.lblMethod.Size = new System.Drawing.Size(43, 13);
            this.lblMethod.TabIndex = 5;
            this.lblMethod.Text = "Method";
            // 
            // cboBrokMethod
            // 
            this.cboBrokMethod.BackColor = System.Drawing.Color.White;
            this.cboBrokMethod.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboBrokMethod.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboBrokMethod.ForeColor = System.Drawing.Color.Black;
            this.cboBrokMethod.FormattingEnabled = true;
            this.cboBrokMethod.Location = new System.Drawing.Point(120, 15);
            this.cboBrokMethod.Name = "cboBrokMethod";
            this.cboBrokMethod.ReadOnly = false;
            this.cboBrokMethod.Size = new System.Drawing.Size(130, 21);
            this.cboBrokMethod.TabIndex = 0;
            // 
            // txtBrokSlab
            // 
            this.txtBrokSlab.AllowAlpha = true;
            this.txtBrokSlab.AllowDot = true;
            this.txtBrokSlab.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtBrokSlab.AllowedCustomCharacters")));
            this.txtBrokSlab.AllowNonASCII = false;
            this.txtBrokSlab.AllowNumeric = true;
            this.txtBrokSlab.AllowSpace = true;
            this.txtBrokSlab.AllowSpecialChars = true;
            this.txtBrokSlab.FocusColor = System.Drawing.Color.LightYellow;
            this.txtBrokSlab.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtBrokSlab.ForeColor = System.Drawing.Color.Black;
            this.txtBrokSlab.IsEmailID = false;
            this.txtBrokSlab.IsEmailIdValid = false;
            this.txtBrokSlab.Location = new System.Drawing.Point(454, 16);
            this.txtBrokSlab.Name = "txtBrokSlab";
            this.txtBrokSlab.Size = new System.Drawing.Size(130, 20);
            this.txtBrokSlab.TabIndex = 1;
            this.txtBrokSlab.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtBrokSlab_KeyUp);
            this.txtBrokSlab.Leave += new System.EventHandler(this.txtBrokSlab_Leave);
            // 
            // lblScheme
            // 
            this.lblScheme.AllowForeColorChange = false;
            this.lblScheme.AutoSize = true;
            this.lblScheme.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblScheme.ForeColor = System.Drawing.Color.Black;
            this.lblScheme.Location = new System.Drawing.Point(304, 18);
            this.lblScheme.Name = "lblScheme";
            this.lblScheme.OverrideDefault = false;
            this.lblScheme.Size = new System.Drawing.Size(44, 13);
            this.lblScheme.TabIndex = 1;
            this.lblScheme.Text = "Scheme";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtAfterPayoutSecurities);
            this.groupBox2.Controls.Add(this.txtAfterPayoutFunds);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(302, 398);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(393, 64);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "(After Payout) of Demat";
            this.groupBox2.Visible = false;
            // 
            // txtAfterPayoutSecurities
            // 
            this.txtAfterPayoutSecurities.AllowAlpha = true;
            this.txtAfterPayoutSecurities.AllowDot = true;
            this.txtAfterPayoutSecurities.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtAfterPayoutSecurities.AllowedCustomCharacters")));
            this.txtAfterPayoutSecurities.AllowNonASCII = false;
            this.txtAfterPayoutSecurities.AllowNumeric = true;
            this.txtAfterPayoutSecurities.AllowSpace = true;
            this.txtAfterPayoutSecurities.AllowSpecialChars = true;
            this.txtAfterPayoutSecurities.FocusColor = System.Drawing.Color.LightYellow;
            this.txtAfterPayoutSecurities.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtAfterPayoutSecurities.ForeColor = System.Drawing.Color.Black;
            this.txtAfterPayoutSecurities.IsEmailID = false;
            this.txtAfterPayoutSecurities.IsEmailIdValid = false;
            this.txtAfterPayoutSecurities.Location = new System.Drawing.Point(157, 39);
            this.txtAfterPayoutSecurities.Name = "txtAfterPayoutSecurities";
            this.txtAfterPayoutSecurities.Size = new System.Drawing.Size(130, 20);
            this.txtAfterPayoutSecurities.TabIndex = 1;
            this.txtAfterPayoutSecurities.Text = "0";
            // 
            // txtAfterPayoutFunds
            // 
            this.txtAfterPayoutFunds.AllowAlpha = true;
            this.txtAfterPayoutFunds.AllowDot = true;
            this.txtAfterPayoutFunds.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtAfterPayoutFunds.AllowedCustomCharacters")));
            this.txtAfterPayoutFunds.AllowNonASCII = false;
            this.txtAfterPayoutFunds.AllowNumeric = true;
            this.txtAfterPayoutFunds.AllowSpace = true;
            this.txtAfterPayoutFunds.AllowSpecialChars = true;
            this.txtAfterPayoutFunds.FocusColor = System.Drawing.Color.LightYellow;
            this.txtAfterPayoutFunds.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtAfterPayoutFunds.ForeColor = System.Drawing.Color.Black;
            this.txtAfterPayoutFunds.IsEmailID = false;
            this.txtAfterPayoutFunds.IsEmailIdValid = false;
            this.txtAfterPayoutFunds.Location = new System.Drawing.Point(157, 15);
            this.txtAfterPayoutFunds.Name = "txtAfterPayoutFunds";
            this.txtAfterPayoutFunds.Size = new System.Drawing.Size(130, 20);
            this.txtAfterPayoutFunds.TabIndex = 0;
            this.txtAfterPayoutFunds.Text = "0";
            // 
            // label4
            // 
            this.label4.AllowForeColorChange = false;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 8F);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(7, 42);
            this.label4.Name = "label4";
            this.label4.OverrideDefault = false;
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Securities";
            // 
            // label3
            // 
            this.label3.AllowForeColorChange = false;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 8F);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(7, 18);
            this.label3.Name = "label3";
            this.label3.OverrideDefault = false;
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Funds";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtBeforePayinSecurities);
            this.groupBox1.Controls.Add(this.txtBeforePayinFunds);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(5, 398);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(281, 64);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "(Before Payin) of Demat";
            this.groupBox1.Visible = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // txtBeforePayinSecurities
            // 
            this.txtBeforePayinSecurities.AllowAlpha = true;
            this.txtBeforePayinSecurities.AllowDot = true;
            this.txtBeforePayinSecurities.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtBeforePayinSecurities.AllowedCustomCharacters")));
            this.txtBeforePayinSecurities.AllowNonASCII = false;
            this.txtBeforePayinSecurities.AllowNumeric = true;
            this.txtBeforePayinSecurities.AllowSpace = true;
            this.txtBeforePayinSecurities.AllowSpecialChars = true;
            this.txtBeforePayinSecurities.FocusColor = System.Drawing.Color.LightYellow;
            this.txtBeforePayinSecurities.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtBeforePayinSecurities.ForeColor = System.Drawing.Color.Black;
            this.txtBeforePayinSecurities.IsEmailID = false;
            this.txtBeforePayinSecurities.IsEmailIdValid = false;
            this.txtBeforePayinSecurities.Location = new System.Drawing.Point(120, 39);
            this.txtBeforePayinSecurities.Name = "txtBeforePayinSecurities";
            this.txtBeforePayinSecurities.Size = new System.Drawing.Size(130, 20);
            this.txtBeforePayinSecurities.TabIndex = 1;
            this.txtBeforePayinSecurities.Text = "0";
            // 
            // txtBeforePayinFunds
            // 
            this.txtBeforePayinFunds.AllowAlpha = true;
            this.txtBeforePayinFunds.AllowDot = true;
            this.txtBeforePayinFunds.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtBeforePayinFunds.AllowedCustomCharacters")));
            this.txtBeforePayinFunds.AllowNonASCII = false;
            this.txtBeforePayinFunds.AllowNumeric = true;
            this.txtBeforePayinFunds.AllowSpace = true;
            this.txtBeforePayinFunds.AllowSpecialChars = true;
            this.txtBeforePayinFunds.FocusColor = System.Drawing.Color.LightYellow;
            this.txtBeforePayinFunds.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtBeforePayinFunds.ForeColor = System.Drawing.Color.Black;
            this.txtBeforePayinFunds.IsEmailID = false;
            this.txtBeforePayinFunds.IsEmailIdValid = false;
            this.txtBeforePayinFunds.Location = new System.Drawing.Point(120, 15);
            this.txtBeforePayinFunds.Name = "txtBeforePayinFunds";
            this.txtBeforePayinFunds.Size = new System.Drawing.Size(130, 20);
            this.txtBeforePayinFunds.TabIndex = 0;
            this.txtBeforePayinFunds.Text = "0";
            // 
            // label2
            // 
            this.label2.AllowForeColorChange = false;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 8F);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(7, 42);
            this.label2.Name = "label2";
            this.label2.OverrideDefault = false;
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Securities";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AllowForeColorChange = false;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(7, 18);
            this.label1.Name = "label1";
            this.label1.OverrideDefault = false;
            this.label1.Size = new System.Drawing.Size(36, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Funds";
            // 
            // gbDemat
            // 
            this.gbDemat.Controls.Add(this.cboRegionMapping);
            this.gbDemat.Controls.Add(this.cboChargeDeliveryCharges);
            this.gbDemat.Controls.Add(this.cboStockTransfer);
            this.gbDemat.Controls.Add(this.cboContractNoGen);
            this.gbDemat.Controls.Add(this.cboContractFormType);
            this.gbDemat.Controls.Add(this.lblRegionMapping);
            this.gbDemat.Controls.Add(this.lblChargeDeliveryCharges);
            this.gbDemat.Controls.Add(this.lblStockTransfer);
            this.gbDemat.Controls.Add(this.lblContractNoGen);
            this.gbDemat.Controls.Add(this.lblContractFormType);
            this.gbDemat.Location = new System.Drawing.Point(302, 210);
            this.gbDemat.Name = "gbDemat";
            this.gbDemat.Size = new System.Drawing.Size(393, 151);
            this.gbDemat.TabIndex = 6;
            this.gbDemat.TabStop = false;
            this.gbDemat.Text = "Demat";
            // 
            // cboRegionMapping
            // 
            this.cboRegionMapping.BackColor = System.Drawing.Color.White;
            this.cboRegionMapping.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboRegionMapping.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboRegionMapping.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboRegionMapping.ForeColor = System.Drawing.Color.Black;
            this.cboRegionMapping.FormattingEnabled = true;
            this.cboRegionMapping.Location = new System.Drawing.Point(157, 123);
            this.cboRegionMapping.Name = "cboRegionMapping";
            this.cboRegionMapping.ReadOnly = false;
            this.cboRegionMapping.Size = new System.Drawing.Size(130, 21);
            this.cboRegionMapping.TabIndex = 4;
            // 
            // cboChargeDeliveryCharges
            // 
            this.cboChargeDeliveryCharges.BackColor = System.Drawing.Color.White;
            this.cboChargeDeliveryCharges.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboChargeDeliveryCharges.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboChargeDeliveryCharges.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboChargeDeliveryCharges.ForeColor = System.Drawing.Color.Black;
            this.cboChargeDeliveryCharges.FormattingEnabled = true;
            this.cboChargeDeliveryCharges.Location = new System.Drawing.Point(157, 96);
            this.cboChargeDeliveryCharges.Name = "cboChargeDeliveryCharges";
            this.cboChargeDeliveryCharges.ReadOnly = false;
            this.cboChargeDeliveryCharges.Size = new System.Drawing.Size(130, 21);
            this.cboChargeDeliveryCharges.TabIndex = 3;
            // 
            // cboStockTransfer
            // 
            this.cboStockTransfer.BackColor = System.Drawing.Color.White;
            this.cboStockTransfer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboStockTransfer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboStockTransfer.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboStockTransfer.ForeColor = System.Drawing.Color.Black;
            this.cboStockTransfer.FormattingEnabled = true;
            this.cboStockTransfer.Location = new System.Drawing.Point(157, 69);
            this.cboStockTransfer.Name = "cboStockTransfer";
            this.cboStockTransfer.ReadOnly = false;
            this.cboStockTransfer.Size = new System.Drawing.Size(130, 21);
            this.cboStockTransfer.TabIndex = 2;
            // 
            // cboContractNoGen
            // 
            this.cboContractNoGen.BackColor = System.Drawing.Color.White;
            this.cboContractNoGen.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboContractNoGen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboContractNoGen.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboContractNoGen.ForeColor = System.Drawing.Color.Black;
            this.cboContractNoGen.FormattingEnabled = true;
            this.cboContractNoGen.Location = new System.Drawing.Point(157, 42);
            this.cboContractNoGen.Name = "cboContractNoGen";
            this.cboContractNoGen.ReadOnly = false;
            this.cboContractNoGen.Size = new System.Drawing.Size(130, 21);
            this.cboContractNoGen.TabIndex = 1;
            // 
            // cboContractFormType
            // 
            this.cboContractFormType.BackColor = System.Drawing.Color.White;
            this.cboContractFormType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboContractFormType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboContractFormType.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboContractFormType.ForeColor = System.Drawing.Color.Black;
            this.cboContractFormType.FormattingEnabled = true;
            this.cboContractFormType.Location = new System.Drawing.Point(157, 15);
            this.cboContractFormType.Name = "cboContractFormType";
            this.cboContractFormType.ReadOnly = false;
            this.cboContractFormType.Size = new System.Drawing.Size(130, 21);
            this.cboContractFormType.TabIndex = 0;
            // 
            // lblRegionMapping
            // 
            this.lblRegionMapping.AllowForeColorChange = false;
            this.lblRegionMapping.AutoSize = true;
            this.lblRegionMapping.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblRegionMapping.ForeColor = System.Drawing.Color.Black;
            this.lblRegionMapping.Location = new System.Drawing.Point(7, 126);
            this.lblRegionMapping.Name = "lblRegionMapping";
            this.lblRegionMapping.OverrideDefault = false;
            this.lblRegionMapping.Size = new System.Drawing.Size(83, 13);
            this.lblRegionMapping.TabIndex = 8;
            this.lblRegionMapping.Text = "Region Mapping";
            // 
            // lblChargeDeliveryCharges
            // 
            this.lblChargeDeliveryCharges.AllowForeColorChange = false;
            this.lblChargeDeliveryCharges.AutoSize = true;
            this.lblChargeDeliveryCharges.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblChargeDeliveryCharges.ForeColor = System.Drawing.Color.Black;
            this.lblChargeDeliveryCharges.Location = new System.Drawing.Point(7, 98);
            this.lblChargeDeliveryCharges.Name = "lblChargeDeliveryCharges";
            this.lblChargeDeliveryCharges.OverrideDefault = false;
            this.lblChargeDeliveryCharges.Size = new System.Drawing.Size(127, 13);
            this.lblChargeDeliveryCharges.TabIndex = 6;
            this.lblChargeDeliveryCharges.Text = "Charge Delivery Charges";
            // 
            // lblStockTransfer
            // 
            this.lblStockTransfer.AllowForeColorChange = false;
            this.lblStockTransfer.AutoSize = true;
            this.lblStockTransfer.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblStockTransfer.ForeColor = System.Drawing.Color.Black;
            this.lblStockTransfer.Location = new System.Drawing.Point(7, 71);
            this.lblStockTransfer.Name = "lblStockTransfer";
            this.lblStockTransfer.OverrideDefault = false;
            this.lblStockTransfer.Size = new System.Drawing.Size(77, 13);
            this.lblStockTransfer.TabIndex = 5;
            this.lblStockTransfer.Text = "Stock Transfer";
            // 
            // lblContractNoGen
            // 
            this.lblContractNoGen.AllowForeColorChange = false;
            this.lblContractNoGen.AutoSize = true;
            this.lblContractNoGen.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblContractNoGen.ForeColor = System.Drawing.Color.Black;
            this.lblContractNoGen.Location = new System.Drawing.Point(7, 45);
            this.lblContractNoGen.Name = "lblContractNoGen";
            this.lblContractNoGen.OverrideDefault = false;
            this.lblContractNoGen.Size = new System.Drawing.Size(91, 13);
            this.lblContractNoGen.TabIndex = 1;
            this.lblContractNoGen.Text = "Contract No. Gen";
            // 
            // lblContractFormType
            // 
            this.lblContractFormType.AllowForeColorChange = false;
            this.lblContractFormType.AutoSize = true;
            this.lblContractFormType.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblContractFormType.ForeColor = System.Drawing.Color.Black;
            this.lblContractFormType.Location = new System.Drawing.Point(7, 18);
            this.lblContractFormType.Name = "lblContractFormType";
            this.lblContractFormType.OverrideDefault = false;
            this.lblContractFormType.Size = new System.Drawing.Size(103, 13);
            this.lblContractFormType.TabIndex = 0;
            this.lblContractFormType.Text = "Contract Form Type";
            // 
            // cboSettDateOnContract
            // 
            this.cboSettDateOnContract.BackColor = System.Drawing.Color.White;
            this.cboSettDateOnContract.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSettDateOnContract.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboSettDateOnContract.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboSettDateOnContract.ForeColor = System.Drawing.Color.Black;
            this.cboSettDateOnContract.FormattingEnabled = true;
            this.cboSettDateOnContract.Location = new System.Drawing.Point(125, 550);
            this.cboSettDateOnContract.Name = "cboSettDateOnContract";
            this.cboSettDateOnContract.ReadOnly = false;
            this.cboSettDateOnContract.Size = new System.Drawing.Size(130, 21);
            this.cboSettDateOnContract.TabIndex = 5;
            this.cboSettDateOnContract.Visible = false;
            // 
            // lblSettleDt
            // 
            this.lblSettleDt.AllowForeColorChange = false;
            this.lblSettleDt.AutoSize = true;
            this.lblSettleDt.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblSettleDt.ForeColor = System.Drawing.Color.Black;
            this.lblSettleDt.Location = new System.Drawing.Point(12, 553);
            this.lblSettleDt.Name = "lblSettleDt";
            this.lblSettleDt.OverrideDefault = false;
            this.lblSettleDt.Size = new System.Drawing.Size(85, 26);
            this.lblSettleDt.TabIndex = 7;
            this.lblSettleDt.Text = "Settlement Date\r\n on Contract ";
            this.lblSettleDt.Visible = false;
            // 
            // gbOtherPreferences
            // 
            this.gbOtherPreferences.Controls.Add(this.cbIncludeSEBIInBrok);
            this.gbOtherPreferences.Controls.Add(this.cbIncludeTOInBrok);
            this.gbOtherPreferences.Controls.Add(this.cbIncludeAuctionPenalInBrkg);
            this.gbOtherPreferences.Controls.Add(this.cbIncludeCCinBrok);
            this.gbOtherPreferences.Controls.Add(this.cbIncludeCFinBrok);
            this.gbOtherPreferences.Controls.Add(this.cbIncludeSDinBrok);
            this.gbOtherPreferences.Controls.Add(this.cbIncludeSTTinBrok);
            this.gbOtherPreferences.Controls.Add(this.cbIncludeSTinBrok);
            this.gbOtherPreferences.Controls.Add(this.cboGlobalPreference);
            this.gbOtherPreferences.Controls.Add(this.cboPaymentMode);
            this.gbOtherPreferences.Controls.Add(this.cboTradeClub);
            this.gbOtherPreferences.Controls.Add(this.lblGlobalPreferences);
            this.gbOtherPreferences.Controls.Add(this.lblPaymentMode);
            this.gbOtherPreferences.Controls.Add(this.lblTradeClub);
            this.gbOtherPreferences.Controls.Add(this.cbRunningClient);
            this.gbOtherPreferences.Controls.Add(this.cbPOA);
            this.gbOtherPreferences.Controls.Add(this.txtIntRate);
            this.gbOtherPreferences.Controls.Add(this.lblIntRate);
            this.gbOtherPreferences.Location = new System.Drawing.Point(5, 114);
            this.gbOtherPreferences.Name = "gbOtherPreferences";
            this.gbOtherPreferences.Size = new System.Drawing.Size(281, 277);
            this.gbOtherPreferences.TabIndex = 5;
            this.gbOtherPreferences.TabStop = false;
            this.gbOtherPreferences.Text = "Other Preferences";
            // 
            // cbIncludeSEBIInBrok
            // 
            this.cbIncludeSEBIInBrok.AutoSize = true;
            this.cbIncludeSEBIInBrok.ForeColor = System.Drawing.Color.Black;
            this.cbIncludeSEBIInBrok.Location = new System.Drawing.Point(155, 159);
            this.cbIncludeSEBIInBrok.Name = "cbIncludeSEBIInBrok";
            this.cbIncludeSEBIInBrok.Size = new System.Drawing.Size(124, 17);
            this.cbIncludeSEBIInBrok.TabIndex = 8;
            this.cbIncludeSEBIInBrok.Text = "Include SEBI in Brok";
            this.cbIncludeSEBIInBrok.UseVisualStyleBackColor = true;
            // 
            // cbIncludeTOInBrok
            // 
            this.cbIncludeTOInBrok.AutoSize = true;
            this.cbIncludeTOInBrok.ForeColor = System.Drawing.Color.Black;
            this.cbIncludeTOInBrok.Location = new System.Drawing.Point(155, 135);
            this.cbIncludeTOInBrok.Name = "cbIncludeTOInBrok";
            this.cbIncludeTOInBrok.Size = new System.Drawing.Size(115, 17);
            this.cbIncludeTOInBrok.TabIndex = 6;
            this.cbIncludeTOInBrok.Text = "Include TO in Brok";
            this.cbIncludeTOInBrok.UseVisualStyleBackColor = true;
            // 
            // cbIncludeAuctionPenalInBrkg
            // 
            this.cbIncludeAuctionPenalInBrkg.AutoSize = true;
            this.cbIncludeAuctionPenalInBrkg.ForeColor = System.Drawing.Color.Black;
            this.cbIncludeAuctionPenalInBrkg.Location = new System.Drawing.Point(9, 254);
            this.cbIncludeAuctionPenalInBrkg.Name = "cbIncludeAuctionPenalInBrkg";
            this.cbIncludeAuctionPenalInBrkg.Size = new System.Drawing.Size(166, 17);
            this.cbIncludeAuctionPenalInBrkg.TabIndex = 12;
            this.cbIncludeAuctionPenalInBrkg.Text = "Include Auction Penal in Brkg";
            this.cbIncludeAuctionPenalInBrkg.UseVisualStyleBackColor = true;
            this.cbIncludeAuctionPenalInBrkg.CheckedChanged += new System.EventHandler(this.checkBox6_CheckedChanged);
            // 
            // cbIncludeCCinBrok
            // 
            this.cbIncludeCCinBrok.AutoSize = true;
            this.cbIncludeCCinBrok.ForeColor = System.Drawing.Color.Black;
            this.cbIncludeCCinBrok.Location = new System.Drawing.Point(9, 230);
            this.cbIncludeCCinBrok.Name = "cbIncludeCCinBrok";
            this.cbIncludeCCinBrok.Size = new System.Drawing.Size(114, 17);
            this.cbIncludeCCinBrok.TabIndex = 11;
            this.cbIncludeCCinBrok.Text = "Include CC in Brok";
            this.cbIncludeCCinBrok.UseVisualStyleBackColor = true;
            // 
            // cbIncludeCFinBrok
            // 
            this.cbIncludeCFinBrok.AutoSize = true;
            this.cbIncludeCFinBrok.ForeColor = System.Drawing.Color.Black;
            this.cbIncludeCFinBrok.Location = new System.Drawing.Point(9, 206);
            this.cbIncludeCFinBrok.Name = "cbIncludeCFinBrok";
            this.cbIncludeCFinBrok.Size = new System.Drawing.Size(113, 17);
            this.cbIncludeCFinBrok.TabIndex = 10;
            this.cbIncludeCFinBrok.Text = "Include CF in Brok";
            this.cbIncludeCFinBrok.UseVisualStyleBackColor = true;
            // 
            // cbIncludeSDinBrok
            // 
            this.cbIncludeSDinBrok.AutoSize = true;
            this.cbIncludeSDinBrok.ForeColor = System.Drawing.Color.Black;
            this.cbIncludeSDinBrok.Location = new System.Drawing.Point(9, 182);
            this.cbIncludeSDinBrok.Name = "cbIncludeSDinBrok";
            this.cbIncludeSDinBrok.Size = new System.Drawing.Size(115, 17);
            this.cbIncludeSDinBrok.TabIndex = 9;
            this.cbIncludeSDinBrok.Text = "Include SD in Brok";
            this.cbIncludeSDinBrok.UseVisualStyleBackColor = true;
            // 
            // cbIncludeSTTinBrok
            // 
            this.cbIncludeSTTinBrok.AutoSize = true;
            this.cbIncludeSTTinBrok.ForeColor = System.Drawing.Color.Black;
            this.cbIncludeSTTinBrok.Location = new System.Drawing.Point(9, 158);
            this.cbIncludeSTTinBrok.Name = "cbIncludeSTTinBrok";
            this.cbIncludeSTTinBrok.Size = new System.Drawing.Size(124, 17);
            this.cbIncludeSTTinBrok.TabIndex = 7;
            this.cbIncludeSTTinBrok.Text = "Include STT in Brok.";
            this.cbIncludeSTTinBrok.UseVisualStyleBackColor = true;
            // 
            // cbIncludeSTinBrok
            // 
            this.cbIncludeSTinBrok.AutoSize = true;
            this.cbIncludeSTinBrok.ForeColor = System.Drawing.Color.Black;
            this.cbIncludeSTinBrok.Location = new System.Drawing.Point(9, 135);
            this.cbIncludeSTinBrok.Name = "cbIncludeSTinBrok";
            this.cbIncludeSTinBrok.Size = new System.Drawing.Size(123, 17);
            this.cbIncludeSTinBrok.TabIndex = 5;
            this.cbIncludeSTinBrok.Text = "Include S.T. in Brok.";
            this.cbIncludeSTinBrok.UseVisualStyleBackColor = true;
            // 
            // cboGlobalPreference
            // 
            this.cboGlobalPreference.BackColor = System.Drawing.Color.White;
            this.cboGlobalPreference.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboGlobalPreference.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboGlobalPreference.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboGlobalPreference.ForeColor = System.Drawing.Color.Black;
            this.cboGlobalPreference.FormattingEnabled = true;
            this.cboGlobalPreference.Location = new System.Drawing.Point(120, 104);
            this.cboGlobalPreference.Name = "cboGlobalPreference";
            this.cboGlobalPreference.ReadOnly = false;
            this.cboGlobalPreference.Size = new System.Drawing.Size(130, 21);
            this.cboGlobalPreference.TabIndex = 4;
            // 
            // cboPaymentMode
            // 
            this.cboPaymentMode.BackColor = System.Drawing.Color.White;
            this.cboPaymentMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPaymentMode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboPaymentMode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboPaymentMode.ForeColor = System.Drawing.Color.Black;
            this.cboPaymentMode.FormattingEnabled = true;
            this.cboPaymentMode.Location = new System.Drawing.Point(120, 75);
            this.cboPaymentMode.Name = "cboPaymentMode";
            this.cboPaymentMode.ReadOnly = false;
            this.cboPaymentMode.Size = new System.Drawing.Size(130, 21);
            this.cboPaymentMode.TabIndex = 3;
            // 
            // cboTradeClub
            // 
            this.cboTradeClub.BackColor = System.Drawing.Color.White;
            this.cboTradeClub.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTradeClub.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboTradeClub.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboTradeClub.ForeColor = System.Drawing.Color.Black;
            this.cboTradeClub.FormattingEnabled = true;
            this.cboTradeClub.Location = new System.Drawing.Point(120, 46);
            this.cboTradeClub.Name = "cboTradeClub";
            this.cboTradeClub.ReadOnly = false;
            this.cboTradeClub.Size = new System.Drawing.Size(130, 21);
            this.cboTradeClub.TabIndex = 2;
            // 
            // lblGlobalPreferences
            // 
            this.lblGlobalPreferences.AllowForeColorChange = false;
            this.lblGlobalPreferences.AutoSize = true;
            this.lblGlobalPreferences.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblGlobalPreferences.ForeColor = System.Drawing.Color.Black;
            this.lblGlobalPreferences.Location = new System.Drawing.Point(6, 107);
            this.lblGlobalPreferences.Name = "lblGlobalPreferences";
            this.lblGlobalPreferences.OverrideDefault = false;
            this.lblGlobalPreferences.Size = new System.Drawing.Size(97, 13);
            this.lblGlobalPreferences.TabIndex = 6;
            this.lblGlobalPreferences.Text = "Global Preferences";
            // 
            // lblPaymentMode
            // 
            this.lblPaymentMode.AllowForeColorChange = false;
            this.lblPaymentMode.AutoSize = true;
            this.lblPaymentMode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblPaymentMode.ForeColor = System.Drawing.Color.Black;
            this.lblPaymentMode.Location = new System.Drawing.Point(6, 78);
            this.lblPaymentMode.Name = "lblPaymentMode";
            this.lblPaymentMode.OverrideDefault = false;
            this.lblPaymentMode.Size = new System.Drawing.Size(78, 13);
            this.lblPaymentMode.TabIndex = 5;
            this.lblPaymentMode.Text = "Payment Mode";
            // 
            // lblTradeClub
            // 
            this.lblTradeClub.AllowForeColorChange = false;
            this.lblTradeClub.AutoSize = true;
            this.lblTradeClub.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblTradeClub.ForeColor = System.Drawing.Color.Black;
            this.lblTradeClub.Location = new System.Drawing.Point(6, 49);
            this.lblTradeClub.Name = "lblTradeClub";
            this.lblTradeClub.OverrideDefault = false;
            this.lblTradeClub.Size = new System.Drawing.Size(59, 13);
            this.lblTradeClub.TabIndex = 4;
            this.lblTradeClub.Text = "Trade Club";
            // 
            // cbRunningClient
            // 
            this.cbRunningClient.AutoSize = true;
            this.cbRunningClient.ForeColor = System.Drawing.Color.Black;
            this.cbRunningClient.Location = new System.Drawing.Point(155, 20);
            this.cbRunningClient.Name = "cbRunningClient";
            this.cbRunningClient.Size = new System.Drawing.Size(95, 17);
            this.cbRunningClient.TabIndex = 1;
            this.cbRunningClient.Text = "Running Client";
            this.cbRunningClient.UseVisualStyleBackColor = true;
            // 
            // cbPOA
            // 
            this.cbPOA.AutoSize = true;
            this.cbPOA.ForeColor = System.Drawing.Color.Black;
            this.cbPOA.Location = new System.Drawing.Point(99, 20);
            this.cbPOA.Name = "cbPOA";
            this.cbPOA.Size = new System.Drawing.Size(48, 17);
            this.cbPOA.TabIndex = 2;
            this.cbPOA.Text = "POA";
            this.cbPOA.UseVisualStyleBackColor = true;
            // 
            // txtIntRate
            // 
            this.txtIntRate.AllowAlpha = true;
            this.txtIntRate.AllowDot = true;
            this.txtIntRate.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtIntRate.AllowedCustomCharacters")));
            this.txtIntRate.AllowNonASCII = false;
            this.txtIntRate.AllowNumeric = true;
            this.txtIntRate.AllowSpace = true;
            this.txtIntRate.AllowSpecialChars = true;
            this.txtIntRate.FocusColor = System.Drawing.Color.LightYellow;
            this.txtIntRate.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtIntRate.ForeColor = System.Drawing.Color.Black;
            this.txtIntRate.IsEmailID = false;
            this.txtIntRate.IsEmailIdValid = false;
            this.txtIntRate.Location = new System.Drawing.Point(54, 17);
            this.txtIntRate.Name = "txtIntRate";
            this.txtIntRate.Size = new System.Drawing.Size(37, 20);
            this.txtIntRate.TabIndex = 0;
            this.txtIntRate.Text = "0.00";
            this.txtIntRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblIntRate
            // 
            this.lblIntRate.AllowForeColorChange = false;
            this.lblIntRate.AutoSize = true;
            this.lblIntRate.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblIntRate.ForeColor = System.Drawing.Color.Black;
            this.lblIntRate.Location = new System.Drawing.Point(6, 20);
            this.lblIntRate.Name = "lblIntRate";
            this.lblIntRate.OverrideDefault = false;
            this.lblIntRate.Size = new System.Drawing.Size(48, 13);
            this.lblIntRate.TabIndex = 0;
            this.lblIntRate.Text = "Int.Rate";
            this.lblIntRate.Click += new System.EventHandler(this.lblIntRate_Click);
            // 
            // gbSTPDetails
            // 
            this.gbSTPDetails.Controls.Add(this.cboFlatISO);
            this.gbSTPDetails.Controls.Add(this.cboDownloadFor);
            this.gbSTPDetails.Controls.Add(this.cboFormat);
            this.gbSTPDetails.Controls.Add(this.cboServProvider);
            this.gbSTPDetails.Controls.Add(this.lblDownloadFor);
            this.gbSTPDetails.Controls.Add(this.lblFormat);
            this.gbSTPDetails.Controls.Add(this.lblServProvider);
            this.gbSTPDetails.Location = new System.Drawing.Point(302, 114);
            this.gbSTPDetails.Name = "gbSTPDetails";
            this.gbSTPDetails.Size = new System.Drawing.Size(393, 96);
            this.gbSTPDetails.TabIndex = 3;
            this.gbSTPDetails.TabStop = false;
            this.gbSTPDetails.Text = "STP Details";
            this.gbSTPDetails.Enter += new System.EventHandler(this.gbSTPDetails_Enter);
            // 
            // cboFlatISO
            // 
            this.cboFlatISO.BackColor = System.Drawing.Color.White;
            this.cboFlatISO.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboFlatISO.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboFlatISO.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboFlatISO.ForeColor = System.Drawing.Color.Black;
            this.cboFlatISO.FormattingEnabled = true;
            this.cboFlatISO.Location = new System.Drawing.Point(292, 17);
            this.cboFlatISO.Name = "cboFlatISO";
            this.cboFlatISO.ReadOnly = false;
            this.cboFlatISO.Size = new System.Drawing.Size(95, 21);
            this.cboFlatISO.TabIndex = 1;
            // 
            // cboDownloadFor
            // 
            this.cboDownloadFor.BackColor = System.Drawing.Color.White;
            this.cboDownloadFor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDownloadFor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboDownloadFor.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboDownloadFor.ForeColor = System.Drawing.Color.Black;
            this.cboDownloadFor.FormattingEnabled = true;
            this.cboDownloadFor.Location = new System.Drawing.Point(157, 69);
            this.cboDownloadFor.Name = "cboDownloadFor";
            this.cboDownloadFor.ReadOnly = false;
            this.cboDownloadFor.Size = new System.Drawing.Size(130, 21);
            this.cboDownloadFor.TabIndex = 3;
            // 
            // cboFormat
            // 
            this.cboFormat.BackColor = System.Drawing.Color.White;
            this.cboFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboFormat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboFormat.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboFormat.ForeColor = System.Drawing.Color.Black;
            this.cboFormat.FormattingEnabled = true;
            this.cboFormat.Location = new System.Drawing.Point(157, 43);
            this.cboFormat.Name = "cboFormat";
            this.cboFormat.ReadOnly = false;
            this.cboFormat.Size = new System.Drawing.Size(130, 21);
            this.cboFormat.TabIndex = 2;
            // 
            // cboServProvider
            // 
            this.cboServProvider.BackColor = System.Drawing.Color.White;
            this.cboServProvider.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboServProvider.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboServProvider.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboServProvider.ForeColor = System.Drawing.Color.Black;
            this.cboServProvider.FormattingEnabled = true;
            this.cboServProvider.Location = new System.Drawing.Point(157, 17);
            this.cboServProvider.Name = "cboServProvider";
            this.cboServProvider.ReadOnly = false;
            this.cboServProvider.Size = new System.Drawing.Size(130, 21);
            this.cboServProvider.TabIndex = 0;
            // 
            // lblDownloadFor
            // 
            this.lblDownloadFor.AllowForeColorChange = false;
            this.lblDownloadFor.AutoSize = true;
            this.lblDownloadFor.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblDownloadFor.ForeColor = System.Drawing.Color.Black;
            this.lblDownloadFor.Location = new System.Drawing.Point(7, 73);
            this.lblDownloadFor.Name = "lblDownloadFor";
            this.lblDownloadFor.OverrideDefault = false;
            this.lblDownloadFor.Size = new System.Drawing.Size(73, 13);
            this.lblDownloadFor.TabIndex = 2;
            this.lblDownloadFor.Text = "Download For";
            // 
            // lblFormat
            // 
            this.lblFormat.AllowForeColorChange = false;
            this.lblFormat.AutoSize = true;
            this.lblFormat.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblFormat.ForeColor = System.Drawing.Color.Black;
            this.lblFormat.Location = new System.Drawing.Point(7, 46);
            this.lblFormat.Name = "lblFormat";
            this.lblFormat.OverrideDefault = false;
            this.lblFormat.Size = new System.Drawing.Size(41, 13);
            this.lblFormat.TabIndex = 1;
            this.lblFormat.Text = "Format";
            // 
            // lblServProvider
            // 
            this.lblServProvider.AllowForeColorChange = false;
            this.lblServProvider.AutoSize = true;
            this.lblServProvider.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblServProvider.ForeColor = System.Drawing.Color.Black;
            this.lblServProvider.Location = new System.Drawing.Point(7, 20);
            this.lblServProvider.Name = "lblServProvider";
            this.lblServProvider.OverrideDefault = false;
            this.lblServProvider.Size = new System.Drawing.Size(76, 13);
            this.lblServProvider.TabIndex = 0;
            this.lblServProvider.Text = "Serv. Provider";
            // 
            // txtPreferenceCode
            // 
            this.txtPreferenceCode.AllowAlpha = true;
            this.txtPreferenceCode.AllowDot = true;
            this.txtPreferenceCode.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtPreferenceCode.AllowedCustomCharacters")));
            this.txtPreferenceCode.AllowNonASCII = false;
            this.txtPreferenceCode.AllowNumeric = true;
            this.txtPreferenceCode.AllowSpace = true;
            this.txtPreferenceCode.AllowSpecialChars = true;
            this.txtPreferenceCode.FocusColor = System.Drawing.Color.LightYellow;
            this.txtPreferenceCode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtPreferenceCode.ForeColor = System.Drawing.Color.Black;
            this.txtPreferenceCode.IsEmailID = false;
            this.txtPreferenceCode.IsEmailIdValid = false;
            this.txtPreferenceCode.Location = new System.Drawing.Point(125, 50);
            this.txtPreferenceCode.Name = "txtPreferenceCode";
            this.txtPreferenceCode.Size = new System.Drawing.Size(130, 20);
            this.txtPreferenceCode.TabIndex = 0;
            this.txtPreferenceCode.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtPreferenceCode_KeyUp);
            this.txtPreferenceCode.Leave += new System.EventHandler(this.txtPreferenceCode_Leave);
            // 
            // lblPreferenceCode
            // 
            this.lblPreferenceCode.AllowForeColorChange = false;
            this.lblPreferenceCode.AutoSize = true;
            this.lblPreferenceCode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblPreferenceCode.ForeColor = System.Drawing.Color.Black;
            this.lblPreferenceCode.Location = new System.Drawing.Point(12, 53);
            this.lblPreferenceCode.Name = "lblPreferenceCode";
            this.lblPreferenceCode.OverrideDefault = false;
            this.lblPreferenceCode.Size = new System.Drawing.Size(88, 13);
            this.lblPreferenceCode.TabIndex = 0;
            this.lblPreferenceCode.Text = "Preference Code";
            // 
            // lblChargeSlab
            // 
            this.lblChargeSlab.AllowForeColorChange = false;
            this.lblChargeSlab.AutoSize = true;
            this.lblChargeSlab.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblChargeSlab.ForeColor = System.Drawing.Color.Black;
            this.lblChargeSlab.Location = new System.Drawing.Point(309, 53);
            this.lblChargeSlab.Name = "lblChargeSlab";
            this.lblChargeSlab.OverrideDefault = false;
            this.lblChargeSlab.Size = new System.Drawing.Size(65, 13);
            this.lblChargeSlab.TabIndex = 11;
            this.lblChargeSlab.Text = "Charge Slab";
            // 
            // txtCharge
            // 
            this.txtCharge.AllowAlpha = true;
            this.txtCharge.AllowDot = true;
            this.txtCharge.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtCharge.AllowedCustomCharacters")));
            this.txtCharge.AllowNonASCII = false;
            this.txtCharge.AllowNumeric = true;
            this.txtCharge.AllowSpace = true;
            this.txtCharge.AllowSpecialChars = true;
            this.txtCharge.FocusColor = System.Drawing.Color.LightYellow;
            this.txtCharge.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtCharge.ForeColor = System.Drawing.Color.Black;
            this.txtCharge.IsEmailID = false;
            this.txtCharge.IsEmailIdValid = false;
            this.txtCharge.Location = new System.Drawing.Point(459, 50);
            this.txtCharge.Name = "txtCharge";
            this.txtCharge.Size = new System.Drawing.Size(130, 20);
            this.txtCharge.TabIndex = 1;
            this.txtCharge.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtCharge_KeyUp);
            this.txtCharge.Leave += new System.EventHandler(this.txtCharge_Leave);
            // 
            // cboSettlementOn
            // 
            this.cboSettlementOn.BackColor = System.Drawing.Color.White;
            this.cboSettlementOn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSettlementOn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboSettlementOn.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboSettlementOn.ForeColor = System.Drawing.Color.Black;
            this.cboSettlementOn.FormattingEnabled = true;
            this.cboSettlementOn.Location = new System.Drawing.Point(125, 466);
            this.cboSettlementOn.Name = "cboSettlementOn";
            this.cboSettlementOn.ReadOnly = false;
            this.cboSettlementOn.Size = new System.Drawing.Size(130, 21);
            this.cboSettlementOn.TabIndex = 2;
            this.cboSettlementOn.Visible = false;
            // 
            // lblSettlementOn
            // 
            this.lblSettlementOn.AllowForeColorChange = false;
            this.lblSettlementOn.AutoSize = true;
            this.lblSettlementOn.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblSettlementOn.ForeColor = System.Drawing.Color.Black;
            this.lblSettlementOn.Location = new System.Drawing.Point(11, 470);
            this.lblSettlementOn.Name = "lblSettlementOn";
            this.lblSettlementOn.OverrideDefault = false;
            this.lblSettlementOn.Size = new System.Drawing.Size(76, 13);
            this.lblSettlementOn.TabIndex = 14;
            this.lblSettlementOn.Text = "Settlement On";
            this.lblSettlementOn.Visible = false;
            // 
            // gbPrintingAllowedFor
            // 
            this.gbPrintingAllowedFor.Controls.Add(this.cbContracts);
            this.gbPrintingAllowedFor.Controls.Add(this.cbBills);
            this.gbPrintingAllowedFor.Location = new System.Drawing.Point(302, 471);
            this.gbPrintingAllowedFor.Name = "gbPrintingAllowedFor";
            this.gbPrintingAllowedFor.Size = new System.Drawing.Size(281, 41);
            this.gbPrintingAllowedFor.TabIndex = 16;
            this.gbPrintingAllowedFor.TabStop = false;
            this.gbPrintingAllowedFor.Text = "Printing Allowed For";
            this.gbPrintingAllowedFor.Visible = false;
            // 
            // cbContracts
            // 
            this.cbContracts.AutoSize = true;
            this.cbContracts.Checked = true;
            this.cbContracts.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbContracts.ForeColor = System.Drawing.Color.Black;
            this.cbContracts.Location = new System.Drawing.Point(99, 18);
            this.cbContracts.Name = "cbContracts";
            this.cbContracts.Size = new System.Drawing.Size(71, 17);
            this.cbContracts.TabIndex = 0;
            this.cbContracts.Text = "Contracts";
            this.cbContracts.UseVisualStyleBackColor = true;
            // 
            // cbBills
            // 
            this.cbBills.AutoSize = true;
            this.cbBills.Checked = true;
            this.cbBills.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbBills.ForeColor = System.Drawing.Color.Black;
            this.cbBills.Location = new System.Drawing.Point(10, 19);
            this.cbBills.Name = "cbBills";
            this.cbBills.Size = new System.Drawing.Size(44, 17);
            this.cbBills.TabIndex = 1;
            this.cbBills.Text = "Bills";
            this.cbBills.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtFmlyGroupName);
            this.groupBox4.Controls.Add(this.txtFmlyGroupCode);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.txtG3);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Location = new System.Drawing.Point(5, 2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(691, 43);
            this.groupBox4.TabIndex = 17;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Client Grouping";
            // 
            // txtFmlyGroupName
            // 
            this.txtFmlyGroupName.Enabled = false;
            this.txtFmlyGroupName.Location = new System.Drawing.Point(589, 15);
            this.txtFmlyGroupName.Name = "txtFmlyGroupName";
            this.txtFmlyGroupName.Size = new System.Drawing.Size(95, 20);
            this.txtFmlyGroupName.TabIndex = 2;
            // 
            // txtFmlyGroupCode
            // 
            this.txtFmlyGroupCode.Location = new System.Drawing.Point(454, 15);
            this.txtFmlyGroupCode.Name = "txtFmlyGroupCode";
            this.txtFmlyGroupCode.Size = new System.Drawing.Size(130, 20);
            this.txtFmlyGroupCode.TabIndex = 1;
            this.txtFmlyGroupCode.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtFmlyGroupCode_KeyUp);
            this.txtFmlyGroupCode.Leave += new System.EventHandler(this.txtFmlyGroupCode_Leave);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(304, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Family Group";
            // 
            // txtG3
            // 
            this.txtG3.Location = new System.Drawing.Point(120, 15);
            this.txtG3.Name = "txtG3";
            this.txtG3.Size = new System.Drawing.Size(130, 20);
            this.txtG3.TabIndex = 0;
            this.txtG3.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtG3_KeyUp);
            this.txtG3.Leave += new System.EventHandler(this.txtG3_Leave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 18);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(21, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "G3";
            // 
            // cboBillNoGen
            // 
            this.cboBillNoGen.BackColor = System.Drawing.Color.White;
            this.cboBillNoGen.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboBillNoGen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboBillNoGen.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboBillNoGen.ForeColor = System.Drawing.Color.Black;
            this.cboBillNoGen.FormattingEnabled = true;
            this.cboBillNoGen.Location = new System.Drawing.Point(125, 523);
            this.cboBillNoGen.Name = "cboBillNoGen";
            this.cboBillNoGen.ReadOnly = false;
            this.cboBillNoGen.Size = new System.Drawing.Size(130, 21);
            this.cboBillNoGen.TabIndex = 4;
            this.cboBillNoGen.Visible = false;
            // 
            // cboBillGeneration
            // 
            this.cboBillGeneration.BackColor = System.Drawing.Color.White;
            this.cboBillGeneration.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboBillGeneration.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboBillGeneration.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboBillGeneration.ForeColor = System.Drawing.Color.Black;
            this.cboBillGeneration.FormattingEnabled = true;
            this.cboBillGeneration.Location = new System.Drawing.Point(125, 496);
            this.cboBillGeneration.Name = "cboBillGeneration";
            this.cboBillGeneration.ReadOnly = false;
            this.cboBillGeneration.Size = new System.Drawing.Size(130, 21);
            this.cboBillGeneration.TabIndex = 3;
            this.cboBillGeneration.Visible = false;
            // 
            // lblBillNoGen
            // 
            this.lblBillNoGen.AllowForeColorChange = false;
            this.lblBillNoGen.AutoSize = true;
            this.lblBillNoGen.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblBillNoGen.ForeColor = System.Drawing.Color.Black;
            this.lblBillNoGen.Location = new System.Drawing.Point(11, 526);
            this.lblBillNoGen.Name = "lblBillNoGen";
            this.lblBillNoGen.OverrideDefault = false;
            this.lblBillNoGen.Size = new System.Drawing.Size(65, 13);
            this.lblBillNoGen.TabIndex = 20;
            this.lblBillNoGen.Text = "Bill No. Gen.";
            this.lblBillNoGen.Visible = false;
            // 
            // lblBillGeneration
            // 
            this.lblBillGeneration.AllowForeColorChange = false;
            this.lblBillGeneration.AutoSize = true;
            this.lblBillGeneration.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblBillGeneration.ForeColor = System.Drawing.Color.Black;
            this.lblBillGeneration.Location = new System.Drawing.Point(11, 499);
            this.lblBillGeneration.Name = "lblBillGeneration";
            this.lblBillGeneration.OverrideDefault = false;
            this.lblBillGeneration.Size = new System.Drawing.Size(75, 13);
            this.lblBillGeneration.TabIndex = 19;
            this.lblBillGeneration.Text = "Bill Generation";
            this.lblBillGeneration.Visible = false;
            // 
            // ucClientPreferences
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.cboBillNoGen);
            this.Controls.Add(this.cboSettDateOnContract);
            this.Controls.Add(this.cboBillGeneration);
            this.Controls.Add(this.lblBillNoGen);
            this.Controls.Add(this.lblBillGeneration);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.gbPrintingAllowedFor);
            this.Controls.Add(this.cboSettlementOn);
            this.Controls.Add(this.lblSettleDt);
            this.Controls.Add(this.lblSettlementOn);
            this.Controls.Add(this.lblChargeSlab);
            this.Controls.Add(this.txtCharge);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gbDemat);
            this.Controls.Add(this.gbOtherPreferences);
            this.Controls.Add(this.gbSTPDetails);
            this.Controls.Add(this.txtPreferenceCode);
            this.Controls.Add(this.lblPreferenceCode);
            this.Name = "ucClientPreferences";
            this.Size = new System.Drawing.Size(780, 950);
            this.Load += new System.EventHandler(this.ucClientPreferences_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gbDemat.ResumeLayout(false);
            this.gbDemat.PerformLayout();
            this.gbOtherPreferences.ResumeLayout(false);
            this.gbOtherPreferences.PerformLayout();
            this.gbSTPDetails.ResumeLayout(false);
            this.gbSTPDetails.PerformLayout();
            this.gbPrintingAllowedFor.ResumeLayout(false);
            this.gbPrintingAllowedFor.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MatchCommon.CustomControls.FTLabel lblPreferenceCode;
        private MatchCommon.CustomControls.FTTextBox txtPreferenceCode;
        private System.Windows.Forms.GroupBox gbSTPDetails;
        private MatchCommon.CustomControls.FTComboBox cboFlatISO;
        private MatchCommon.CustomControls.FTComboBox cboDownloadFor;
        private MatchCommon.CustomControls.FTComboBox cboFormat;
        private MatchCommon.CustomControls.FTComboBox cboServProvider;
        private MatchCommon.CustomControls.FTLabel lblDownloadFor;
        private MatchCommon.CustomControls.FTLabel lblFormat;
        private MatchCommon.CustomControls.FTLabel lblServProvider;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.GroupBox gbOtherPreferences;
        private MatchCommon.CustomControls.FTTextBox txtIntRate;
        private MatchCommon.CustomControls.FTLabel lblIntRate;
        private MatchCommon.CustomControls.FTComboBox cboGlobalPreference;
        private MatchCommon.CustomControls.FTComboBox cboPaymentMode;
        private MatchCommon.CustomControls.FTComboBox cboTradeClub;
        private MatchCommon.CustomControls.FTLabel lblGlobalPreferences;
        private MatchCommon.CustomControls.FTLabel lblPaymentMode;
        private MatchCommon.CustomControls.FTLabel lblTradeClub;
        private MatchCommon.CustomControls.FTCheckBox cbRunningClient;
        private MatchCommon.CustomControls.FTCheckBox cbPOA;
        private MatchCommon.CustomControls.FTCheckBox cbIncludeAuctionPenalInBrkg;
        private MatchCommon.CustomControls.FTCheckBox cbIncludeCCinBrok;
        private MatchCommon.CustomControls.FTCheckBox cbIncludeCFinBrok;
        private MatchCommon.CustomControls.FTCheckBox cbIncludeSDinBrok;
        private MatchCommon.CustomControls.FTCheckBox cbIncludeSTTinBrok;
        private MatchCommon.CustomControls.FTCheckBox cbIncludeSTinBrok;
        private System.Windows.Forms.GroupBox gbDemat;
        private MatchCommon.CustomControls.FTLabel lblRegionMapping;
        private MatchCommon.CustomControls.FTLabel lblSettleDt;
        private MatchCommon.CustomControls.FTLabel lblChargeDeliveryCharges;
        private MatchCommon.CustomControls.FTLabel lblStockTransfer;
        private MatchCommon.CustomControls.FTLabel lblContractNoGen;
        private MatchCommon.CustomControls.FTLabel lblContractFormType;
        private MatchCommon.CustomControls.FTComboBox cboRegionMapping;
        private MatchCommon.CustomControls.FTComboBox cboSettDateOnContract;
        private MatchCommon.CustomControls.FTComboBox cboChargeDeliveryCharges;
        private MatchCommon.CustomControls.FTComboBox cboStockTransfer;
        private MatchCommon.CustomControls.FTComboBox cboContractNoGen;
        private MatchCommon.CustomControls.FTComboBox cboContractFormType;
        private System.Windows.Forms.GroupBox groupBox1;
        private MatchCommon.CustomControls.FTTextBox txtBeforePayinSecurities;
        private MatchCommon.CustomControls.FTTextBox txtBeforePayinFunds;
        private MatchCommon.CustomControls.FTLabel label2;
        private MatchCommon.CustomControls.FTLabel label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private MatchCommon.CustomControls.FTTextBox txtAfterPayoutSecurities;
        private MatchCommon.CustomControls.FTTextBox txtAfterPayoutFunds;
        private MatchCommon.CustomControls.FTLabel label4;
        //private System.Windows.Forms.Label label3;
        private MatchCommon.CustomControls.FTLabel label3;
        private System.Windows.Forms.GroupBox groupBox3;
        private MatchCommon.CustomControls.FTCheckBox chkAllowtoBrok;
        private MatchCommon.CustomControls.FTLabel lblMethod;
        private MatchCommon.CustomControls.FTComboBox cboBrokMethod;
        private MatchCommon.CustomControls.FTTextBox txtBrokSlab;
        private MatchCommon.CustomControls.FTLabel lblScheme;
        private MatchCommon.CustomControls.FTDataGrid dgvPreference;
        private MatchCommon.CustomControls.FTLabel lblChargeSlab;
        private MatchCommon.CustomControls.FTTextBox txtCharge;
        private MatchCommon.CustomControls.FTCheckBox cbIncludeSEBIInBrok;
        private MatchCommon.CustomControls.FTCheckBox cbIncludeTOInBrok;
        private MatchCommon.CustomControls.FTComboBox cboSettlementOn;
        private MatchCommon.CustomControls.FTLabel lblSettlementOn;
        private System.Windows.Forms.GroupBox gbPrintingAllowedFor;
        private MatchCommon.CustomControls.FTCheckBox cbContracts;
        private MatchCommon.CustomControls.FTCheckBox cbBills;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtFmlyGroupName;
        private System.Windows.Forms.TextBox txtFmlyGroupCode;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtG3;
        private System.Windows.Forms.Label label5;
        private MatchCommon.CustomControls.FTComboBox cboBillNoGen;
        private MatchCommon.CustomControls.FTComboBox cboBillGeneration;
        private MatchCommon.CustomControls.FTLabel lblBillNoGen;
        private MatchCommon.CustomControls.FTLabel lblBillGeneration;
    }
}
