﻿namespace EntityMaster.UCC
{
    partial class EntityInd
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EntityInd));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ftLabel78 = new MatchCommon.CustomControls.FTLabel();
            this.btnApply = new MatchCommon.CustomControls.FTButton();
            this.lblMobileNo = new MatchCommon.CustomControls.FTLabel();
            this.ftlblEntityCode = new MatchCommon.CustomControls.FTLabel();
            this.lblHeading = new System.Windows.Forms.Label();
            this.txtNameHead = new System.Windows.Forms.TextBox();
            this.txtEntityCode = new System.Windows.Forms.TextBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.chkProtector = new System.Windows.Forms.CheckBox();
            this.chkMatch = new System.Windows.Forms.CheckBox();
            this.chkDP = new System.Windows.Forms.CheckBox();
            this.chkODIN = new System.Windows.Forms.CheckBox();
            this.DocUpload = new System.Windows.Forms.TabPage();
            this.ftLabel77 = new MatchCommon.CustomControls.FTLabel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.ftLabel81 = new MatchCommon.CustomControls.FTLabel();
            this.ftCmbTypeofDocument = new MatchCommon.CustomControls.FTComboBox();
            this.tbOthers = new System.Windows.Forms.TabPage();
            this.ftLabel54 = new MatchCommon.CustomControls.FTLabel();
            this.ftTxtUserId = new MatchCommon.CustomControls.FTTextBox();
            this.ftTxtPEP = new MatchCommon.CustomControls.FTTextBox();
            this.ftTxtOccupation = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel53 = new MatchCommon.CustomControls.FTLabel();
            this.ftCmbFacilityType = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel39 = new MatchCommon.CustomControls.FTLabel();
            this.ftCmbPEP = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel40 = new MatchCommon.CustomControls.FTLabel();
            this.ftCmbOccupation = new MatchCommon.CustomControls.FTComboBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker6 = new System.Windows.Forms.DateTimePicker();
            this.ftCmbGrossAnnual = new MatchCommon.CustomControls.FTComboBox();
            this.dateTimePicker5 = new System.Windows.Forms.DateTimePicker();
            this.ftTextBox25 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel41 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel42 = new MatchCommon.CustomControls.FTLabel();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.ftLabel43 = new MatchCommon.CustomControls.FTLabel();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.ftLabel44 = new MatchCommon.CustomControls.FTLabel();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.ftLabel45 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel46 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel47 = new MatchCommon.CustomControls.FTLabel();
            this.ftTextBox26 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox27 = new MatchCommon.CustomControls.FTTextBox();
            this.ftComboBox8 = new MatchCommon.CustomControls.FTComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbAccount = new System.Windows.Forms.TabPage();
            this.ftTextBox4 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox3 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLblOccupation = new MatchCommon.CustomControls.FTLabel();
            this.ftLblNationality = new MatchCommon.CustomControls.FTLabel();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.ftTxtAddress24 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTxtAddress22 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTxtAddress23 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTxtAddress21 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel1 = new MatchCommon.CustomControls.FTLabel();
            this.ftTxtMail2 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel2 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel3 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel4 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel5 = new MatchCommon.CustomControls.FTLabel();
            this.ftTextBox8 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox9 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox10 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox11 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel6 = new MatchCommon.CustomControls.FTLabel();
            this.ftTextBox18 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel7 = new MatchCommon.CustomControls.FTLabel();
            this.ftComboBox1 = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel8 = new MatchCommon.CustomControls.FTLabel();
            this.ftComboBox2 = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel9 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel10 = new MatchCommon.CustomControls.FTLabel();
            this.ftComboBox3 = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel13 = new MatchCommon.CustomControls.FTLabel();
            this.ftCheckBox1 = new MatchCommon.CustomControls.FTCheckBox();
            this.ftCreated = new MatchCommon.CustomControls.FTLabel();
            this.ftlblMarried = new MatchCommon.CustomControls.FTLabel();
            this.ftlblGender = new MatchCommon.CustomControls.FTLabel();
            this.ftlblDOB = new MatchCommon.CustomControls.FTLabel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ftTxtAddress4 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTxtAddress2 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTxtAddress3 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTxtAddress1 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel32 = new MatchCommon.CustomControls.FTLabel();
            this.ftTxtMail = new MatchCommon.CustomControls.FTTextBox();
            this.lblAddressLine1 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel24 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel25 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel26 = new MatchCommon.CustomControls.FTLabel();
            this.ftTextBox12 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox13 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox14 = new MatchCommon.CustomControls.FTTextBox();
            this.ftTextBox15 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel27 = new MatchCommon.CustomControls.FTLabel();
            this.ftTextBox16 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel28 = new MatchCommon.CustomControls.FTLabel();
            this.ftComboBox4 = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel29 = new MatchCommon.CustomControls.FTLabel();
            this.ftComboBox5 = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel30 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel31 = new MatchCommon.CustomControls.FTLabel();
            this.ftComboBox6 = new MatchCommon.CustomControls.FTComboBox();
            this.ftCmbMarried = new MatchCommon.CustomControls.FTComboBox();
            this.ftCmbGender = new MatchCommon.CustomControls.FTComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ftLabel34 = new MatchCommon.CustomControls.FTLabel();
            this.ftTextBox19 = new MatchCommon.CustomControls.FTTextBox();
            this.tbEntity = new System.Windows.Forms.TabControl();
            this.btnDelete = new MatchCommon.CustomControls.FTButton();
            this.btnAdd = new MatchCommon.CustomControls.FTButton();
            this.ftBtnSaveIdentity = new MatchCommon.CustomControls.FTButton();
            this.btnImport = new System.Windows.Forms.Button();
            this.ftBtnRemoveDoc = new MatchCommon.CustomControls.FTButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.DocUpload.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.groupBox11.SuspendLayout();
            this.tbOthers.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tbAccount.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tbEntity.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(691, 11);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(97, 99);
            this.pictureBox1.TabIndex = 75;
            this.pictureBox1.TabStop = false;
            // 
            // ftLabel78
            // 
            this.ftLabel78.AllowForeColorChange = false;
            this.ftLabel78.AutoSize = true;
            this.ftLabel78.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel78.ForeColor = System.Drawing.Color.Black;
            this.ftLabel78.IsMandatory = true;
            this.ftLabel78.Location = new System.Drawing.Point(7, 67);
            this.ftLabel78.Name = "ftLabel78";
            this.ftLabel78.OverrideDefault = false;
            this.ftLabel78.Size = new System.Drawing.Size(36, 12);
            this.ftLabel78.TabIndex = 74;
            this.ftLabel78.Text = "Name*";
            // 
            // btnApply
            // 
            this.btnApply.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnApply.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnApply.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.btnApply.Image = ((System.Drawing.Image)(resources.GetObject("btnApply.Image")));
            this.btnApply.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnApply.Location = new System.Drawing.Point(706, 671);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new System.Drawing.Size(84, 25);
            this.btnApply.TabIndex = 71;
            this.btnApply.Text = "&Apply";
            this.btnApply.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnApply.UseVisualStyleBackColor = true;
            // 
            // lblMobileNo
            // 
            this.lblMobileNo.AllowForeColorChange = false;
            this.lblMobileNo.AutoSize = true;
            this.lblMobileNo.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblMobileNo.ForeColor = System.Drawing.Color.Black;
            this.lblMobileNo.Location = new System.Drawing.Point(14, 684);
            this.lblMobileNo.Name = "lblMobileNo";
            this.lblMobileNo.OverrideDefault = false;
            this.lblMobileNo.Size = new System.Drawing.Size(39, 12);
            this.lblMobileNo.TabIndex = 70;
            this.lblMobileNo.Text = "Status: ";
            // 
            // ftlblEntityCode
            // 
            this.ftlblEntityCode.AllowForeColorChange = false;
            this.ftlblEntityCode.AutoSize = true;
            this.ftlblEntityCode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftlblEntityCode.ForeColor = System.Drawing.Color.Black;
            this.ftlblEntityCode.IsMandatory = true;
            this.ftlblEntityCode.Location = new System.Drawing.Point(7, 35);
            this.ftlblEntityCode.Name = "ftlblEntityCode";
            this.ftlblEntityCode.OverrideDefault = false;
            this.ftlblEntityCode.Size = new System.Drawing.Size(35, 12);
            this.ftlblEntityCode.TabIndex = 67;
            this.ftlblEntityCode.Text = "Code*";
            // 
            // lblHeading
            // 
            this.lblHeading.AutoSize = true;
            this.lblHeading.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.lblHeading.ForeColor = System.Drawing.Color.Red;
            this.lblHeading.Location = new System.Drawing.Point(366, 3);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.Size = new System.Drawing.Size(67, 14);
            this.lblHeading.TabIndex = 64;
            this.lblHeading.Text = "Individual";
            // 
            // txtNameHead
            // 
            this.txtNameHead.Location = new System.Drawing.Point(62, 63);
            this.txtNameHead.Name = "txtNameHead";
            this.txtNameHead.Size = new System.Drawing.Size(586, 20);
            this.txtNameHead.TabIndex = 63;
            // 
            // txtEntityCode
            // 
            this.txtEntityCode.Location = new System.Drawing.Point(62, 31);
            this.txtEntityCode.Name = "txtEntityCode";
            this.txtEntityCode.Size = new System.Drawing.Size(149, 20);
            this.txtEntityCode.TabIndex = 62;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.tabPage1.Controls.Add(this.groupBox12);
            this.tabPage1.Location = new System.Drawing.Point(4, 23);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(781, 528);
            this.tabPage1.TabIndex = 5;
            this.tabPage1.Text = "Product";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.chkProtector);
            this.groupBox12.Controls.Add(this.chkMatch);
            this.groupBox12.Controls.Add(this.chkDP);
            this.groupBox12.Controls.Add(this.chkODIN);
            this.groupBox12.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox12.Location = new System.Drawing.Point(10, 7);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(164, 139);
            this.groupBox12.TabIndex = 58;
            this.groupBox12.TabStop = false;
            // 
            // chkProtector
            // 
            this.chkProtector.AutoSize = true;
            this.chkProtector.Location = new System.Drawing.Point(29, 89);
            this.chkProtector.Name = "chkProtector";
            this.chkProtector.Size = new System.Drawing.Size(71, 17);
            this.chkProtector.TabIndex = 60;
            this.chkProtector.Text = "Protector";
            this.chkProtector.UseVisualStyleBackColor = true;
            // 
            // chkMatch
            // 
            this.chkMatch.AutoSize = true;
            this.chkMatch.Location = new System.Drawing.Point(29, 66);
            this.chkMatch.Name = "chkMatch";
            this.chkMatch.Size = new System.Drawing.Size(55, 17);
            this.chkMatch.TabIndex = 60;
            this.chkMatch.Text = "Match";
            this.chkMatch.UseVisualStyleBackColor = true;
            // 
            // chkDP
            // 
            this.chkDP.AutoSize = true;
            this.chkDP.Location = new System.Drawing.Point(29, 43);
            this.chkDP.Name = "chkDP";
            this.chkDP.Size = new System.Drawing.Size(39, 17);
            this.chkDP.TabIndex = 60;
            this.chkDP.Text = "DP";
            this.chkDP.UseVisualStyleBackColor = true;
            // 
            // chkODIN
            // 
            this.chkODIN.AutoSize = true;
            this.chkODIN.Location = new System.Drawing.Point(29, 20);
            this.chkODIN.Name = "chkODIN";
            this.chkODIN.Size = new System.Drawing.Size(52, 17);
            this.chkODIN.TabIndex = 59;
            this.chkODIN.Text = "ODIN";
            this.chkODIN.UseVisualStyleBackColor = true;
            // 
            // DocUpload
            // 
            this.DocUpload.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.DocUpload.Controls.Add(this.ftBtnRemoveDoc);
            this.DocUpload.Controls.Add(this.ftLabel77);
            this.DocUpload.Controls.Add(this.textBox1);
            this.DocUpload.Controls.Add(this.dataGridView2);
            this.DocUpload.Controls.Add(this.groupBox11);
            this.DocUpload.Location = new System.Drawing.Point(4, 23);
            this.DocUpload.Name = "DocUpload";
            this.DocUpload.Padding = new System.Windows.Forms.Padding(3);
            this.DocUpload.Size = new System.Drawing.Size(781, 528);
            this.DocUpload.TabIndex = 4;
            this.DocUpload.Text = "Doc Upload";
            // 
            // ftLabel77
            // 
            this.ftLabel77.AllowForeColorChange = false;
            this.ftLabel77.AutoSize = true;
            this.ftLabel77.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel77.ForeColor = System.Drawing.Color.Black;
            this.ftLabel77.Location = new System.Drawing.Point(240, 403);
            this.ftLabel77.Name = "ftLabel77";
            this.ftLabel77.OverrideDefault = false;
            this.ftLabel77.Size = new System.Drawing.Size(48, 12);
            this.ftLabel77.TabIndex = 62;
            this.ftLabel77.Text = "Comment";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(241, 423);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(534, 93);
            this.textBox1.TabIndex = 61;
            // 
            // dataGridView2
            // 
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4,
            this.Date});
            this.dataGridView2.Location = new System.Drawing.Point(7, 93);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.Size = new System.Drawing.Size(208, 423);
            this.dataGridView2.TabIndex = 58;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Type";
            this.dataGridViewTextBoxColumn4.MaxInputLength = 100;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // Date
            // 
            this.Date.HeaderText = "Date";
            this.Date.Name = "Date";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.btnImport);
            this.groupBox11.Controls.Add(this.ftLabel81);
            this.groupBox11.Controls.Add(this.ftCmbTypeofDocument);
            this.groupBox11.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox11.Location = new System.Drawing.Point(7, 16);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(768, 60);
            this.groupBox11.TabIndex = 57;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Identification";
            // 
            // ftLabel81
            // 
            this.ftLabel81.AllowForeColorChange = false;
            this.ftLabel81.AutoSize = true;
            this.ftLabel81.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel81.ForeColor = System.Drawing.Color.Black;
            this.ftLabel81.Location = new System.Drawing.Point(6, 26);
            this.ftLabel81.Name = "ftLabel81";
            this.ftLabel81.OverrideDefault = false;
            this.ftLabel81.Size = new System.Drawing.Size(89, 12);
            this.ftLabel81.TabIndex = 53;
            this.ftLabel81.Text = "Type of Document";
            // 
            // ftCmbTypeofDocument
            // 
            this.ftCmbTypeofDocument.BackColor = System.Drawing.Color.White;
            this.ftCmbTypeofDocument.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftCmbTypeofDocument.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftCmbTypeofDocument.ForeColor = System.Drawing.Color.Black;
            this.ftCmbTypeofDocument.FormattingEnabled = true;
            this.ftCmbTypeofDocument.Location = new System.Drawing.Point(102, 23);
            this.ftCmbTypeofDocument.Name = "ftCmbTypeofDocument";
            this.ftCmbTypeofDocument.ReadOnly = false;
            this.ftCmbTypeofDocument.Size = new System.Drawing.Size(169, 20);
            this.ftCmbTypeofDocument.TabIndex = 29;
            // 
            // tbOthers
            // 
            this.tbOthers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.tbOthers.Controls.Add(this.ftLabel54);
            this.tbOthers.Controls.Add(this.ftTxtUserId);
            this.tbOthers.Controls.Add(this.ftTxtPEP);
            this.tbOthers.Controls.Add(this.ftTxtOccupation);
            this.tbOthers.Controls.Add(this.ftLabel53);
            this.tbOthers.Controls.Add(this.ftCmbFacilityType);
            this.tbOthers.Controls.Add(this.ftLabel39);
            this.tbOthers.Controls.Add(this.ftCmbPEP);
            this.tbOthers.Controls.Add(this.ftLabel40);
            this.tbOthers.Controls.Add(this.ftCmbOccupation);
            this.tbOthers.Controls.Add(this.groupBox7);
            this.tbOthers.Controls.Add(this.groupBox6);
            this.tbOthers.Controls.Add(this.dataGridView1);
            this.tbOthers.Location = new System.Drawing.Point(4, 23);
            this.tbOthers.Name = "tbOthers";
            this.tbOthers.Padding = new System.Windows.Forms.Padding(3);
            this.tbOthers.Size = new System.Drawing.Size(781, 528);
            this.tbOthers.TabIndex = 2;
            this.tbOthers.Text = "Others";
            // 
            // ftLabel54
            // 
            this.ftLabel54.AllowForeColorChange = false;
            this.ftLabel54.AutoSize = true;
            this.ftLabel54.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel54.ForeColor = System.Drawing.Color.Black;
            this.ftLabel54.Location = new System.Drawing.Point(9, 427);
            this.ftLabel54.Name = "ftLabel54";
            this.ftLabel54.OverrideDefault = false;
            this.ftLabel54.Size = new System.Drawing.Size(38, 12);
            this.ftLabel54.TabIndex = 67;
            this.ftLabel54.Text = "User Id";
            // 
            // ftTxtUserId
            // 
            this.ftTxtUserId.AllowAlpha = true;
            this.ftTxtUserId.AllowDot = false;
            this.ftTxtUserId.AllowedCustomCharacters = null;
            this.ftTxtUserId.AllowNonASCII = false;
            this.ftTxtUserId.AllowNumeric = true;
            this.ftTxtUserId.AllowSpace = false;
            this.ftTxtUserId.AllowSpecialChars = true;
            this.ftTxtUserId.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtUserId.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtUserId.ForeColor = System.Drawing.Color.Black;
            this.ftTxtUserId.IsEmailID = false;
            this.ftTxtUserId.IsEmailIdValid = false;
            this.ftTxtUserId.Location = new System.Drawing.Point(71, 424);
            this.ftTxtUserId.MaxLength = 10;
            this.ftTxtUserId.Name = "ftTxtUserId";
            this.ftTxtUserId.Size = new System.Drawing.Size(308, 20);
            this.ftTxtUserId.TabIndex = 66;
            this.ftTxtUserId.Tag = "Code";
            // 
            // ftTxtPEP
            // 
            this.ftTxtPEP.AllowAlpha = true;
            this.ftTxtPEP.AllowDot = false;
            this.ftTxtPEP.AllowedCustomCharacters = null;
            this.ftTxtPEP.AllowNonASCII = false;
            this.ftTxtPEP.AllowNumeric = true;
            this.ftTxtPEP.AllowSpace = false;
            this.ftTxtPEP.AllowSpecialChars = true;
            this.ftTxtPEP.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtPEP.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtPEP.ForeColor = System.Drawing.Color.Black;
            this.ftTxtPEP.IsEmailID = false;
            this.ftTxtPEP.IsEmailIdValid = false;
            this.ftTxtPEP.Location = new System.Drawing.Point(219, 394);
            this.ftTxtPEP.MaxLength = 10;
            this.ftTxtPEP.Name = "ftTxtPEP";
            this.ftTxtPEP.Size = new System.Drawing.Size(556, 20);
            this.ftTxtPEP.TabIndex = 62;
            this.ftTxtPEP.Tag = "Code";
            // 
            // ftTxtOccupation
            // 
            this.ftTxtOccupation.AllowAlpha = true;
            this.ftTxtOccupation.AllowDot = false;
            this.ftTxtOccupation.AllowedCustomCharacters = null;
            this.ftTxtOccupation.AllowNonASCII = false;
            this.ftTxtOccupation.AllowNumeric = true;
            this.ftTxtOccupation.AllowSpace = false;
            this.ftTxtOccupation.AllowSpecialChars = true;
            this.ftTxtOccupation.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtOccupation.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtOccupation.ForeColor = System.Drawing.Color.Black;
            this.ftTxtOccupation.IsEmailID = false;
            this.ftTxtOccupation.IsEmailIdValid = false;
            this.ftTxtOccupation.Location = new System.Drawing.Point(219, 365);
            this.ftTxtOccupation.MaxLength = 10;
            this.ftTxtOccupation.Name = "ftTxtOccupation";
            this.ftTxtOccupation.Size = new System.Drawing.Size(556, 20);
            this.ftTxtOccupation.TabIndex = 59;
            this.ftTxtOccupation.Tag = "Code";
            // 
            // ftLabel53
            // 
            this.ftLabel53.AllowForeColorChange = false;
            this.ftLabel53.AutoSize = true;
            this.ftLabel53.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel53.ForeColor = System.Drawing.Color.Black;
            this.ftLabel53.Location = new System.Drawing.Point(9, 533);
            this.ftLabel53.Name = "ftLabel53";
            this.ftLabel53.OverrideDefault = false;
            this.ftLabel53.Size = new System.Drawing.Size(59, 12);
            this.ftLabel53.TabIndex = 65;
            this.ftLabel53.Text = "FacilityType";
            // 
            // ftCmbFacilityType
            // 
            this.ftCmbFacilityType.BackColor = System.Drawing.Color.White;
            this.ftCmbFacilityType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftCmbFacilityType.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftCmbFacilityType.ForeColor = System.Drawing.Color.Black;
            this.ftCmbFacilityType.FormattingEnabled = true;
            this.ftCmbFacilityType.Location = new System.Drawing.Point(71, 530);
            this.ftCmbFacilityType.Name = "ftCmbFacilityType";
            this.ftCmbFacilityType.ReadOnly = false;
            this.ftCmbFacilityType.Size = new System.Drawing.Size(142, 20);
            this.ftCmbFacilityType.TabIndex = 64;
            // 
            // ftLabel39
            // 
            this.ftLabel39.AllowForeColorChange = false;
            this.ftLabel39.AutoSize = true;
            this.ftLabel39.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel39.ForeColor = System.Drawing.Color.Black;
            this.ftLabel39.Location = new System.Drawing.Point(9, 397);
            this.ftLabel39.Name = "ftLabel39";
            this.ftLabel39.OverrideDefault = false;
            this.ftLabel39.Size = new System.Drawing.Size(23, 12);
            this.ftLabel39.TabIndex = 63;
            this.ftLabel39.Text = "PEP";
            // 
            // ftCmbPEP
            // 
            this.ftCmbPEP.BackColor = System.Drawing.Color.White;
            this.ftCmbPEP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftCmbPEP.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftCmbPEP.ForeColor = System.Drawing.Color.Black;
            this.ftCmbPEP.FormattingEnabled = true;
            this.ftCmbPEP.Location = new System.Drawing.Point(71, 394);
            this.ftCmbPEP.Name = "ftCmbPEP";
            this.ftCmbPEP.ReadOnly = false;
            this.ftCmbPEP.Size = new System.Drawing.Size(142, 20);
            this.ftCmbPEP.TabIndex = 61;
            // 
            // ftLabel40
            // 
            this.ftLabel40.AllowForeColorChange = false;
            this.ftLabel40.AutoSize = true;
            this.ftLabel40.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel40.ForeColor = System.Drawing.Color.Black;
            this.ftLabel40.Location = new System.Drawing.Point(9, 368);
            this.ftLabel40.Name = "ftLabel40";
            this.ftLabel40.OverrideDefault = false;
            this.ftLabel40.Size = new System.Drawing.Size(57, 12);
            this.ftLabel40.TabIndex = 60;
            this.ftLabel40.Text = "Occupation";
            // 
            // ftCmbOccupation
            // 
            this.ftCmbOccupation.BackColor = System.Drawing.Color.White;
            this.ftCmbOccupation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftCmbOccupation.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftCmbOccupation.ForeColor = System.Drawing.Color.Black;
            this.ftCmbOccupation.FormattingEnabled = true;
            this.ftCmbOccupation.Location = new System.Drawing.Point(71, 365);
            this.ftCmbOccupation.Name = "ftCmbOccupation";
            this.ftCmbOccupation.ReadOnly = false;
            this.ftCmbOccupation.Size = new System.Drawing.Size(142, 20);
            this.ftCmbOccupation.TabIndex = 58;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.dateTimePicker6);
            this.groupBox7.Controls.Add(this.ftCmbGrossAnnual);
            this.groupBox7.Controls.Add(this.dateTimePicker5);
            this.groupBox7.Controls.Add(this.ftTextBox25);
            this.groupBox7.Controls.Add(this.ftLabel41);
            this.groupBox7.Controls.Add(this.ftLabel42);
            this.groupBox7.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox7.Location = new System.Drawing.Point(9, 296);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(766, 54);
            this.groupBox7.TabIndex = 57;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Income/Networth";
            // 
            // dateTimePicker6
            // 
            this.dateTimePicker6.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker6.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker6.Location = new System.Drawing.Point(640, 21);
            this.dateTimePicker6.Name = "dateTimePicker6";
            this.dateTimePicker6.Size = new System.Drawing.Size(120, 21);
            this.dateTimePicker6.TabIndex = 62;
            // 
            // ftCmbGrossAnnual
            // 
            this.ftCmbGrossAnnual.BackColor = System.Drawing.Color.White;
            this.ftCmbGrossAnnual.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftCmbGrossAnnual.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftCmbGrossAnnual.ForeColor = System.Drawing.Color.Black;
            this.ftCmbGrossAnnual.FormattingEnabled = true;
            this.ftCmbGrossAnnual.Location = new System.Drawing.Point(76, 22);
            this.ftCmbGrossAnnual.Name = "ftCmbGrossAnnual";
            this.ftCmbGrossAnnual.ReadOnly = false;
            this.ftCmbGrossAnnual.Size = new System.Drawing.Size(168, 20);
            this.ftCmbGrossAnnual.TabIndex = 61;
            // 
            // dateTimePicker5
            // 
            this.dateTimePicker5.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker5.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker5.Location = new System.Drawing.Point(250, 21);
            this.dateTimePicker5.Name = "dateTimePicker5";
            this.dateTimePicker5.Size = new System.Drawing.Size(120, 21);
            this.dateTimePicker5.TabIndex = 60;
            // 
            // ftTextBox25
            // 
            this.ftTextBox25.AllowAlpha = true;
            this.ftTextBox25.AllowDot = false;
            this.ftTextBox25.AllowedCustomCharacters = null;
            this.ftTextBox25.AllowNonASCII = false;
            this.ftTextBox25.AllowNumeric = true;
            this.ftTextBox25.AllowSpace = false;
            this.ftTextBox25.AllowSpecialChars = true;
            this.ftTextBox25.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox25.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox25.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox25.IsEmailID = false;
            this.ftTextBox25.IsEmailIdValid = false;
            this.ftTextBox25.Location = new System.Drawing.Point(480, 22);
            this.ftTextBox25.MaxLength = 10;
            this.ftTextBox25.Name = "ftTextBox25";
            this.ftTextBox25.Size = new System.Drawing.Size(149, 20);
            this.ftTextBox25.TabIndex = 25;
            this.ftTextBox25.Tag = "Code";
            // 
            // ftLabel41
            // 
            this.ftLabel41.AllowForeColorChange = false;
            this.ftLabel41.AutoSize = true;
            this.ftLabel41.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel41.ForeColor = System.Drawing.Color.Black;
            this.ftLabel41.Location = new System.Drawing.Point(5, 25);
            this.ftLabel41.Name = "ftLabel41";
            this.ftLabel41.OverrideDefault = false;
            this.ftLabel41.Size = new System.Drawing.Size(65, 12);
            this.ftLabel41.TabIndex = 59;
            this.ftLabel41.Text = "Gross Annual";
            // 
            // ftLabel42
            // 
            this.ftLabel42.AllowForeColorChange = false;
            this.ftLabel42.AutoSize = true;
            this.ftLabel42.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel42.ForeColor = System.Drawing.Color.Black;
            this.ftLabel42.Location = new System.Drawing.Point(427, 26);
            this.ftLabel42.Name = "ftLabel42";
            this.ftLabel42.OverrideDefault = false;
            this.ftLabel42.Size = new System.Drawing.Size(47, 12);
            this.ftLabel42.TabIndex = 26;
            this.ftLabel42.Text = "Networth";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.ftBtnSaveIdentity);
            this.groupBox6.Controls.Add(this.btnDelete);
            this.groupBox6.Controls.Add(this.btnAdd);
            this.groupBox6.Controls.Add(this.ftLabel43);
            this.groupBox6.Controls.Add(this.dateTimePicker4);
            this.groupBox6.Controls.Add(this.ftLabel44);
            this.groupBox6.Controls.Add(this.dateTimePicker3);
            this.groupBox6.Controls.Add(this.ftLabel45);
            this.groupBox6.Controls.Add(this.ftLabel46);
            this.groupBox6.Controls.Add(this.ftLabel47);
            this.groupBox6.Controls.Add(this.ftTextBox26);
            this.groupBox6.Controls.Add(this.ftTextBox27);
            this.groupBox6.Controls.Add(this.ftComboBox8);
            this.groupBox6.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox6.Location = new System.Drawing.Point(264, 10);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(511, 282);
            this.groupBox6.TabIndex = 56;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Identification";
            // 
            // ftLabel43
            // 
            this.ftLabel43.AllowForeColorChange = false;
            this.ftLabel43.AutoSize = true;
            this.ftLabel43.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel43.ForeColor = System.Drawing.Color.Black;
            this.ftLabel43.Location = new System.Drawing.Point(6, 83);
            this.ftLabel43.Name = "ftLabel43";
            this.ftLabel43.OverrideDefault = false;
            this.ftLabel43.Size = new System.Drawing.Size(66, 12);
            this.ftLabel43.TabIndex = 59;
            this.ftLabel43.Text = "Place of Issue";
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker4.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker4.Location = new System.Drawing.Point(333, 49);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(120, 21);
            this.dateTimePicker4.TabIndex = 58;
            // 
            // ftLabel44
            // 
            this.ftLabel44.AllowForeColorChange = false;
            this.ftLabel44.AutoSize = true;
            this.ftLabel44.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel44.ForeColor = System.Drawing.Color.Black;
            this.ftLabel44.Location = new System.Drawing.Point(264, 55);
            this.ftLabel44.Name = "ftLabel44";
            this.ftLabel44.OverrideDefault = false;
            this.ftLabel44.Size = new System.Drawing.Size(57, 12);
            this.ftLabel44.TabIndex = 57;
            this.ftLabel44.Text = "Expiry Date";
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker3.Location = new System.Drawing.Point(82, 49);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(120, 21);
            this.dateTimePicker3.TabIndex = 56;
            // 
            // ftLabel45
            // 
            this.ftLabel45.AllowForeColorChange = false;
            this.ftLabel45.AutoSize = true;
            this.ftLabel45.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel45.ForeColor = System.Drawing.Color.Black;
            this.ftLabel45.Location = new System.Drawing.Point(6, 55);
            this.ftLabel45.Name = "ftLabel45";
            this.ftLabel45.OverrideDefault = false;
            this.ftLabel45.Size = new System.Drawing.Size(63, 12);
            this.ftLabel45.TabIndex = 55;
            this.ftLabel45.Text = "Date of Issue";
            // 
            // ftLabel46
            // 
            this.ftLabel46.AllowForeColorChange = false;
            this.ftLabel46.AutoSize = true;
            this.ftLabel46.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel46.ForeColor = System.Drawing.Color.Black;
            this.ftLabel46.Location = new System.Drawing.Point(264, 23);
            this.ftLabel46.Name = "ftLabel46";
            this.ftLabel46.OverrideDefault = false;
            this.ftLabel46.Size = new System.Drawing.Size(33, 12);
            this.ftLabel46.TabIndex = 54;
            this.ftLabel46.Text = "Details";
            // 
            // ftLabel47
            // 
            this.ftLabel47.AllowForeColorChange = false;
            this.ftLabel47.AutoSize = true;
            this.ftLabel47.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel47.ForeColor = System.Drawing.Color.Black;
            this.ftLabel47.Location = new System.Drawing.Point(6, 23);
            this.ftLabel47.Name = "ftLabel47";
            this.ftLabel47.OverrideDefault = false;
            this.ftLabel47.Size = new System.Drawing.Size(28, 12);
            this.ftLabel47.TabIndex = 53;
            this.ftLabel47.Text = "Type";
            // 
            // ftTextBox26
            // 
            this.ftTextBox26.AllowAlpha = true;
            this.ftTextBox26.AllowDot = false;
            this.ftTextBox26.AllowedCustomCharacters = null;
            this.ftTextBox26.AllowNonASCII = false;
            this.ftTextBox26.AllowNumeric = true;
            this.ftTextBox26.AllowSpace = false;
            this.ftTextBox26.AllowSpecialChars = true;
            this.ftTextBox26.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox26.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox26.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox26.IsEmailID = false;
            this.ftTextBox26.IsEmailIdValid = false;
            this.ftTextBox26.Location = new System.Drawing.Point(82, 80);
            this.ftTextBox26.MaxLength = 10;
            this.ftTextBox26.Name = "ftTextBox26";
            this.ftTextBox26.Size = new System.Drawing.Size(151, 20);
            this.ftTextBox26.TabIndex = 39;
            this.ftTextBox26.Tag = "Code";
            // 
            // ftTextBox27
            // 
            this.ftTextBox27.AllowAlpha = true;
            this.ftTextBox27.AllowDot = false;
            this.ftTextBox27.AllowedCustomCharacters = null;
            this.ftTextBox27.AllowNonASCII = false;
            this.ftTextBox27.AllowNumeric = true;
            this.ftTextBox27.AllowSpace = false;
            this.ftTextBox27.AllowSpecialChars = true;
            this.ftTextBox27.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox27.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox27.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox27.IsEmailID = false;
            this.ftTextBox27.IsEmailIdValid = false;
            this.ftTextBox27.Location = new System.Drawing.Point(333, 20);
            this.ftTextBox27.MaxLength = 10;
            this.ftTextBox27.Name = "ftTextBox27";
            this.ftTextBox27.Size = new System.Drawing.Size(170, 20);
            this.ftTextBox27.TabIndex = 32;
            this.ftTextBox27.Tag = "Code";
            // 
            // ftComboBox8
            // 
            this.ftComboBox8.BackColor = System.Drawing.Color.White;
            this.ftComboBox8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftComboBox8.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftComboBox8.ForeColor = System.Drawing.Color.Black;
            this.ftComboBox8.FormattingEnabled = true;
            this.ftComboBox8.Location = new System.Drawing.Point(82, 20);
            this.ftComboBox8.Name = "ftComboBox8";
            this.ftComboBox8.ReadOnly = false;
            this.ftComboBox8.Size = new System.Drawing.Size(120, 20);
            this.ftComboBox8.TabIndex = 29;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.dataGridView1.Location = new System.Drawing.Point(8, 10);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.Size = new System.Drawing.Size(243, 282);
            this.dataGridView1.TabIndex = 55;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Type";
            this.dataGridViewTextBoxColumn1.MaxInputLength = 20;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 60;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Details";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 105;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Date";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 75;
            // 
            // tbAccount
            // 
            this.tbAccount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.tbAccount.Controls.Add(this.ftTextBox4);
            this.tbAccount.Controls.Add(this.ftTextBox3);
            this.tbAccount.Controls.Add(this.ftLblOccupation);
            this.tbAccount.Controls.Add(this.ftLblNationality);
            this.tbAccount.Controls.Add(this.dateTimePicker2);
            this.tbAccount.Controls.Add(this.groupBox3);
            this.tbAccount.Controls.Add(this.ftCreated);
            this.tbAccount.Controls.Add(this.ftlblMarried);
            this.tbAccount.Controls.Add(this.ftlblGender);
            this.tbAccount.Controls.Add(this.ftlblDOB);
            this.tbAccount.Controls.Add(this.groupBox2);
            this.tbAccount.Controls.Add(this.ftCmbMarried);
            this.tbAccount.Controls.Add(this.ftCmbGender);
            this.tbAccount.Controls.Add(this.dateTimePicker1);
            this.tbAccount.Controls.Add(this.groupBox1);
            this.tbAccount.Location = new System.Drawing.Point(4, 23);
            this.tbAccount.Name = "tbAccount";
            this.tbAccount.Padding = new System.Windows.Forms.Padding(3);
            this.tbAccount.Size = new System.Drawing.Size(781, 528);
            this.tbAccount.TabIndex = 0;
            this.tbAccount.Text = "Account";
            // 
            // ftTextBox4
            // 
            this.ftTextBox4.AllowAlpha = true;
            this.ftTextBox4.AllowDot = false;
            this.ftTextBox4.AllowedCustomCharacters = null;
            this.ftTextBox4.AllowNonASCII = false;
            this.ftTextBox4.AllowNumeric = true;
            this.ftTextBox4.AllowSpace = false;
            this.ftTextBox4.AllowSpecialChars = true;
            this.ftTextBox4.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox4.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox4.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox4.IsEmailID = false;
            this.ftTextBox4.IsEmailIdValid = false;
            this.ftTextBox4.Location = new System.Drawing.Point(325, 46);
            this.ftTextBox4.MaxLength = 10;
            this.ftTextBox4.Name = "ftTextBox4";
            this.ftTextBox4.Size = new System.Drawing.Size(204, 20);
            this.ftTextBox4.TabIndex = 74;
            this.ftTextBox4.Tag = "Code";
            // 
            // ftTextBox3
            // 
            this.ftTextBox3.AllowAlpha = true;
            this.ftTextBox3.AllowDot = false;
            this.ftTextBox3.AllowedCustomCharacters = null;
            this.ftTextBox3.AllowNonASCII = false;
            this.ftTextBox3.AllowNumeric = true;
            this.ftTextBox3.AllowSpace = false;
            this.ftTextBox3.AllowSpecialChars = true;
            this.ftTextBox3.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox3.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox3.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox3.IsEmailID = false;
            this.ftTextBox3.IsEmailIdValid = false;
            this.ftTextBox3.Location = new System.Drawing.Point(74, 46);
            this.ftTextBox3.MaxLength = 10;
            this.ftTextBox3.Name = "ftTextBox3";
            this.ftTextBox3.Size = new System.Drawing.Size(129, 20);
            this.ftTextBox3.TabIndex = 72;
            this.ftTextBox3.Tag = "Code";
            // 
            // ftLblOccupation
            // 
            this.ftLblOccupation.AllowForeColorChange = false;
            this.ftLblOccupation.AutoSize = true;
            this.ftLblOccupation.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLblOccupation.ForeColor = System.Drawing.Color.Black;
            this.ftLblOccupation.Location = new System.Drawing.Point(262, 49);
            this.ftLblOccupation.Name = "ftLblOccupation";
            this.ftLblOccupation.OverrideDefault = false;
            this.ftLblOccupation.Size = new System.Drawing.Size(57, 12);
            this.ftLblOccupation.TabIndex = 75;
            this.ftLblOccupation.Text = "Occupation";
            // 
            // ftLblNationality
            // 
            this.ftLblNationality.AllowForeColorChange = false;
            this.ftLblNationality.AutoSize = true;
            this.ftLblNationality.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLblNationality.ForeColor = System.Drawing.Color.Black;
            this.ftLblNationality.Location = new System.Drawing.Point(16, 49);
            this.ftLblNationality.Name = "ftLblNationality";
            this.ftLblNationality.OverrideDefault = false;
            this.ftLblNationality.Size = new System.Drawing.Size(52, 12);
            this.ftLblNationality.TabIndex = 73;
            this.ftLblNationality.Text = "Nationality";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(74, 13);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(129, 22);
            this.dateTimePicker2.TabIndex = 71;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.ftTxtAddress24);
            this.groupBox3.Controls.Add(this.ftTxtAddress22);
            this.groupBox3.Controls.Add(this.ftTxtAddress23);
            this.groupBox3.Controls.Add(this.ftTxtAddress21);
            this.groupBox3.Controls.Add(this.ftLabel1);
            this.groupBox3.Controls.Add(this.ftTxtMail2);
            this.groupBox3.Controls.Add(this.ftLabel2);
            this.groupBox3.Controls.Add(this.ftLabel3);
            this.groupBox3.Controls.Add(this.ftLabel4);
            this.groupBox3.Controls.Add(this.ftLabel5);
            this.groupBox3.Controls.Add(this.ftTextBox8);
            this.groupBox3.Controls.Add(this.ftTextBox9);
            this.groupBox3.Controls.Add(this.ftTextBox10);
            this.groupBox3.Controls.Add(this.ftTextBox11);
            this.groupBox3.Controls.Add(this.ftLabel6);
            this.groupBox3.Controls.Add(this.ftTextBox18);
            this.groupBox3.Controls.Add(this.ftLabel7);
            this.groupBox3.Controls.Add(this.ftComboBox1);
            this.groupBox3.Controls.Add(this.ftLabel8);
            this.groupBox3.Controls.Add(this.ftComboBox2);
            this.groupBox3.Controls.Add(this.ftLabel9);
            this.groupBox3.Controls.Add(this.ftLabel10);
            this.groupBox3.Controls.Add(this.ftComboBox3);
            this.groupBox3.Controls.Add(this.ftLabel13);
            this.groupBox3.Controls.Add(this.ftCheckBox1);
            this.groupBox3.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox3.Location = new System.Drawing.Point(14, 334);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(753, 179);
            this.groupBox3.TabIndex = 70;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Permanent Address";
            // 
            // ftTxtAddress24
            // 
            this.ftTxtAddress24.AllowAlpha = true;
            this.ftTxtAddress24.AllowDot = false;
            this.ftTxtAddress24.AllowedCustomCharacters = null;
            this.ftTxtAddress24.AllowNonASCII = false;
            this.ftTxtAddress24.AllowNumeric = true;
            this.ftTxtAddress24.AllowSpace = false;
            this.ftTxtAddress24.AllowSpecialChars = true;
            this.ftTxtAddress24.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtAddress24.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtAddress24.ForeColor = System.Drawing.Color.Black;
            this.ftTxtAddress24.IsEmailID = false;
            this.ftTxtAddress24.IsEmailIdValid = false;
            this.ftTxtAddress24.Location = new System.Drawing.Point(394, 55);
            this.ftTxtAddress24.MaxLength = 10;
            this.ftTxtAddress24.Name = "ftTxtAddress24";
            this.ftTxtAddress24.Size = new System.Drawing.Size(353, 20);
            this.ftTxtAddress24.TabIndex = 83;
            this.ftTxtAddress24.Tag = "Code";
            // 
            // ftTxtAddress22
            // 
            this.ftTxtAddress22.AllowAlpha = true;
            this.ftTxtAddress22.AllowDot = false;
            this.ftTxtAddress22.AllowedCustomCharacters = null;
            this.ftTxtAddress22.AllowNonASCII = false;
            this.ftTxtAddress22.AllowNumeric = true;
            this.ftTxtAddress22.AllowSpace = false;
            this.ftTxtAddress22.AllowSpecialChars = true;
            this.ftTxtAddress22.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtAddress22.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtAddress22.ForeColor = System.Drawing.Color.Black;
            this.ftTxtAddress22.IsEmailID = false;
            this.ftTxtAddress22.IsEmailIdValid = false;
            this.ftTxtAddress22.Location = new System.Drawing.Point(394, 24);
            this.ftTxtAddress22.MaxLength = 10;
            this.ftTxtAddress22.Name = "ftTxtAddress22";
            this.ftTxtAddress22.Size = new System.Drawing.Size(353, 20);
            this.ftTxtAddress22.TabIndex = 82;
            this.ftTxtAddress22.Tag = "Code";
            // 
            // ftTxtAddress23
            // 
            this.ftTxtAddress23.AllowAlpha = true;
            this.ftTxtAddress23.AllowDot = false;
            this.ftTxtAddress23.AllowedCustomCharacters = null;
            this.ftTxtAddress23.AllowNonASCII = false;
            this.ftTxtAddress23.AllowNumeric = true;
            this.ftTxtAddress23.AllowSpace = false;
            this.ftTxtAddress23.AllowSpecialChars = true;
            this.ftTxtAddress23.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtAddress23.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtAddress23.ForeColor = System.Drawing.Color.Black;
            this.ftTxtAddress23.IsEmailID = false;
            this.ftTxtAddress23.IsEmailIdValid = false;
            this.ftTxtAddress23.Location = new System.Drawing.Point(51, 54);
            this.ftTxtAddress23.MaxLength = 10;
            this.ftTxtAddress23.Name = "ftTxtAddress23";
            this.ftTxtAddress23.Size = new System.Drawing.Size(337, 20);
            this.ftTxtAddress23.TabIndex = 81;
            this.ftTxtAddress23.Tag = "Code";
            // 
            // ftTxtAddress21
            // 
            this.ftTxtAddress21.AllowAlpha = true;
            this.ftTxtAddress21.AllowDot = false;
            this.ftTxtAddress21.AllowedCustomCharacters = null;
            this.ftTxtAddress21.AllowNonASCII = false;
            this.ftTxtAddress21.AllowNumeric = true;
            this.ftTxtAddress21.AllowSpace = false;
            this.ftTxtAddress21.AllowSpecialChars = true;
            this.ftTxtAddress21.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtAddress21.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtAddress21.ForeColor = System.Drawing.Color.Black;
            this.ftTxtAddress21.IsEmailID = false;
            this.ftTxtAddress21.IsEmailIdValid = false;
            this.ftTxtAddress21.Location = new System.Drawing.Point(51, 23);
            this.ftTxtAddress21.MaxLength = 10;
            this.ftTxtAddress21.Name = "ftTxtAddress21";
            this.ftTxtAddress21.Size = new System.Drawing.Size(337, 20);
            this.ftTxtAddress21.TabIndex = 80;
            this.ftTxtAddress21.Tag = "Code";
            // 
            // ftLabel1
            // 
            this.ftLabel1.AllowForeColorChange = false;
            this.ftLabel1.AutoSize = true;
            this.ftLabel1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel1.ForeColor = System.Drawing.Color.Black;
            this.ftLabel1.Location = new System.Drawing.Point(4, 87);
            this.ftLabel1.Name = "ftLabel1";
            this.ftLabel1.OverrideDefault = false;
            this.ftLabel1.Size = new System.Drawing.Size(32, 12);
            this.ftLabel1.TabIndex = 79;
            this.ftLabel1.Text = "E-Mail";
            // 
            // ftTxtMail2
            // 
            this.ftTxtMail2.AllowAlpha = true;
            this.ftTxtMail2.AllowDot = false;
            this.ftTxtMail2.AllowedCustomCharacters = null;
            this.ftTxtMail2.AllowNonASCII = false;
            this.ftTxtMail2.AllowNumeric = true;
            this.ftTxtMail2.AllowSpace = false;
            this.ftTxtMail2.AllowSpecialChars = true;
            this.ftTxtMail2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtMail2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtMail2.ForeColor = System.Drawing.Color.Black;
            this.ftTxtMail2.IsEmailID = false;
            this.ftTxtMail2.IsEmailIdValid = false;
            this.ftTxtMail2.Location = new System.Drawing.Point(51, 84);
            this.ftTxtMail2.MaxLength = 10;
            this.ftTxtMail2.Name = "ftTxtMail2";
            this.ftTxtMail2.Size = new System.Drawing.Size(337, 20);
            this.ftTxtMail2.TabIndex = 78;
            this.ftTxtMail2.Tag = "Code";
            // 
            // ftLabel2
            // 
            this.ftLabel2.AllowForeColorChange = false;
            this.ftLabel2.AutoSize = true;
            this.ftLabel2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel2.ForeColor = System.Drawing.Color.Black;
            this.ftLabel2.Location = new System.Drawing.Point(5, 26);
            this.ftLabel2.Name = "ftLabel2";
            this.ftLabel2.OverrideDefault = false;
            this.ftLabel2.Size = new System.Drawing.Size(41, 12);
            this.ftLabel2.TabIndex = 73;
            this.ftLabel2.Text = "Address";
            // 
            // ftLabel3
            // 
            this.ftLabel3.AllowForeColorChange = false;
            this.ftLabel3.AutoSize = true;
            this.ftLabel3.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel3.ForeColor = System.Drawing.Color.Black;
            this.ftLabel3.Location = new System.Drawing.Point(602, 149);
            this.ftLabel3.Name = "ftLabel3";
            this.ftLabel3.OverrideDefault = false;
            this.ftLabel3.Size = new System.Drawing.Size(21, 12);
            this.ftLabel3.TabIndex = 72;
            this.ftLabel3.Text = "Fax";
            // 
            // ftLabel4
            // 
            this.ftLabel4.AllowForeColorChange = false;
            this.ftLabel4.AutoSize = true;
            this.ftLabel4.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel4.ForeColor = System.Drawing.Color.Black;
            this.ftLabel4.Location = new System.Drawing.Point(406, 151);
            this.ftLabel4.Name = "ftLabel4";
            this.ftLabel4.OverrideDefault = false;
            this.ftLabel4.Size = new System.Drawing.Size(26, 12);
            this.ftLabel4.TabIndex = 71;
            this.ftLabel4.Text = "Tel.2";
            // 
            // ftLabel5
            // 
            this.ftLabel5.AllowForeColorChange = false;
            this.ftLabel5.AutoSize = true;
            this.ftLabel5.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel5.ForeColor = System.Drawing.Color.Black;
            this.ftLabel5.Location = new System.Drawing.Point(214, 150);
            this.ftLabel5.Name = "ftLabel5";
            this.ftLabel5.OverrideDefault = false;
            this.ftLabel5.Size = new System.Drawing.Size(26, 12);
            this.ftLabel5.TabIndex = 70;
            this.ftLabel5.Text = "Tel.1";
            // 
            // ftTextBox8
            // 
            this.ftTextBox8.AllowAlpha = true;
            this.ftTextBox8.AllowDot = false;
            this.ftTextBox8.AllowedCustomCharacters = null;
            this.ftTextBox8.AllowNonASCII = false;
            this.ftTextBox8.AllowNumeric = true;
            this.ftTextBox8.AllowSpace = false;
            this.ftTextBox8.AllowSpecialChars = true;
            this.ftTextBox8.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox8.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox8.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox8.IsEmailID = false;
            this.ftTextBox8.IsEmailIdValid = false;
            this.ftTextBox8.Location = new System.Drawing.Point(626, 146);
            this.ftTextBox8.MaxLength = 10;
            this.ftTextBox8.Name = "ftTextBox8";
            this.ftTextBox8.Size = new System.Drawing.Size(122, 20);
            this.ftTextBox8.TabIndex = 69;
            this.ftTextBox8.Tag = "Code";
            // 
            // ftTextBox9
            // 
            this.ftTextBox9.AllowAlpha = true;
            this.ftTextBox9.AllowDot = false;
            this.ftTextBox9.AllowedCustomCharacters = null;
            this.ftTextBox9.AllowNonASCII = false;
            this.ftTextBox9.AllowNumeric = true;
            this.ftTextBox9.AllowSpace = false;
            this.ftTextBox9.AllowSpecialChars = true;
            this.ftTextBox9.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox9.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox9.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox9.IsEmailID = false;
            this.ftTextBox9.IsEmailIdValid = false;
            this.ftTextBox9.Location = new System.Drawing.Point(441, 146);
            this.ftTextBox9.MaxLength = 10;
            this.ftTextBox9.Name = "ftTextBox9";
            this.ftTextBox9.Size = new System.Drawing.Size(140, 20);
            this.ftTextBox9.TabIndex = 68;
            this.ftTextBox9.Tag = "Code";
            // 
            // ftTextBox10
            // 
            this.ftTextBox10.AllowAlpha = true;
            this.ftTextBox10.AllowDot = false;
            this.ftTextBox10.AllowedCustomCharacters = null;
            this.ftTextBox10.AllowNonASCII = false;
            this.ftTextBox10.AllowNumeric = true;
            this.ftTextBox10.AllowSpace = false;
            this.ftTextBox10.AllowSpecialChars = true;
            this.ftTextBox10.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox10.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox10.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox10.IsEmailID = false;
            this.ftTextBox10.IsEmailIdValid = false;
            this.ftTextBox10.Location = new System.Drawing.Point(247, 146);
            this.ftTextBox10.MaxLength = 10;
            this.ftTextBox10.Name = "ftTextBox10";
            this.ftTextBox10.Size = new System.Drawing.Size(140, 20);
            this.ftTextBox10.TabIndex = 67;
            this.ftTextBox10.Tag = "Code";
            // 
            // ftTextBox11
            // 
            this.ftTextBox11.AllowAlpha = true;
            this.ftTextBox11.AllowDot = false;
            this.ftTextBox11.AllowedCustomCharacters = null;
            this.ftTextBox11.AllowNonASCII = false;
            this.ftTextBox11.AllowNumeric = true;
            this.ftTextBox11.AllowSpace = false;
            this.ftTextBox11.AllowSpecialChars = true;
            this.ftTextBox11.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox11.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox11.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox11.IsEmailID = false;
            this.ftTextBox11.IsEmailIdValid = false;
            this.ftTextBox11.Location = new System.Drawing.Point(51, 146);
            this.ftTextBox11.MaxLength = 10;
            this.ftTextBox11.Name = "ftTextBox11";
            this.ftTextBox11.Size = new System.Drawing.Size(140, 20);
            this.ftTextBox11.TabIndex = 62;
            this.ftTextBox11.Tag = "Code";
            // 
            // ftLabel6
            // 
            this.ftLabel6.AllowForeColorChange = false;
            this.ftLabel6.AutoSize = true;
            this.ftLabel6.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel6.ForeColor = System.Drawing.Color.Black;
            this.ftLabel6.Location = new System.Drawing.Point(4, 150);
            this.ftLabel6.Name = "ftLabel6";
            this.ftLabel6.OverrideDefault = false;
            this.ftLabel6.Size = new System.Drawing.Size(34, 12);
            this.ftLabel6.TabIndex = 66;
            this.ftLabel6.Text = "Mobile";
            // 
            // ftTextBox18
            // 
            this.ftTextBox18.AllowAlpha = true;
            this.ftTextBox18.AllowDot = false;
            this.ftTextBox18.AllowedCustomCharacters = null;
            this.ftTextBox18.AllowNonASCII = false;
            this.ftTextBox18.AllowNumeric = true;
            this.ftTextBox18.AllowSpace = false;
            this.ftTextBox18.AllowSpecialChars = true;
            this.ftTextBox18.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox18.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox18.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox18.IsEmailID = false;
            this.ftTextBox18.IsEmailIdValid = false;
            this.ftTextBox18.Location = new System.Drawing.Point(626, 114);
            this.ftTextBox18.MaxLength = 10;
            this.ftTextBox18.Name = "ftTextBox18";
            this.ftTextBox18.Size = new System.Drawing.Size(122, 20);
            this.ftTextBox18.TabIndex = 59;
            this.ftTextBox18.Tag = "Code";
            // 
            // ftLabel7
            // 
            this.ftLabel7.AllowForeColorChange = false;
            this.ftLabel7.AutoSize = true;
            this.ftLabel7.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel7.ForeColor = System.Drawing.Color.Black;
            this.ftLabel7.Location = new System.Drawing.Point(598, 118);
            this.ftLabel7.Name = "ftLabel7";
            this.ftLabel7.OverrideDefault = false;
            this.ftLabel7.Size = new System.Drawing.Size(22, 12);
            this.ftLabel7.TabIndex = 65;
            this.ftLabel7.Text = "PIN";
            // 
            // ftComboBox1
            // 
            this.ftComboBox1.BackColor = System.Drawing.Color.White;
            this.ftComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftComboBox1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftComboBox1.ForeColor = System.Drawing.Color.Black;
            this.ftComboBox1.FormattingEnabled = true;
            this.ftComboBox1.Location = new System.Drawing.Point(441, 115);
            this.ftComboBox1.Name = "ftComboBox1";
            this.ftComboBox1.ReadOnly = false;
            this.ftComboBox1.Size = new System.Drawing.Size(140, 20);
            this.ftComboBox1.TabIndex = 63;
            // 
            // ftLabel8
            // 
            this.ftLabel8.AllowForeColorChange = false;
            this.ftLabel8.AutoSize = true;
            this.ftLabel8.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel8.ForeColor = System.Drawing.Color.Black;
            this.ftLabel8.Location = new System.Drawing.Point(406, 118);
            this.ftLabel8.Name = "ftLabel8";
            this.ftLabel8.OverrideDefault = false;
            this.ftLabel8.Size = new System.Drawing.Size(23, 12);
            this.ftLabel8.TabIndex = 64;
            this.ftLabel8.Text = "City";
            // 
            // ftComboBox2
            // 
            this.ftComboBox2.BackColor = System.Drawing.Color.White;
            this.ftComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftComboBox2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftComboBox2.ForeColor = System.Drawing.Color.Black;
            this.ftComboBox2.FormattingEnabled = true;
            this.ftComboBox2.Location = new System.Drawing.Point(247, 115);
            this.ftComboBox2.Name = "ftComboBox2";
            this.ftComboBox2.ReadOnly = false;
            this.ftComboBox2.Size = new System.Drawing.Size(140, 20);
            this.ftComboBox2.TabIndex = 58;
            // 
            // ftLabel9
            // 
            this.ftLabel9.AllowForeColorChange = false;
            this.ftLabel9.AutoSize = true;
            this.ftLabel9.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel9.ForeColor = System.Drawing.Color.Black;
            this.ftLabel9.Location = new System.Drawing.Point(214, 118);
            this.ftLabel9.Name = "ftLabel9";
            this.ftLabel9.OverrideDefault = false;
            this.ftLabel9.Size = new System.Drawing.Size(27, 12);
            this.ftLabel9.TabIndex = 61;
            this.ftLabel9.Text = "State";
            // 
            // ftLabel10
            // 
            this.ftLabel10.AllowForeColorChange = false;
            this.ftLabel10.AutoSize = true;
            this.ftLabel10.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel10.ForeColor = System.Drawing.Color.Black;
            this.ftLabel10.Location = new System.Drawing.Point(5, 118);
            this.ftLabel10.Name = "ftLabel10";
            this.ftLabel10.OverrideDefault = false;
            this.ftLabel10.Size = new System.Drawing.Size(43, 12);
            this.ftLabel10.TabIndex = 60;
            this.ftLabel10.Text = "Country";
            // 
            // ftComboBox3
            // 
            this.ftComboBox3.BackColor = System.Drawing.Color.White;
            this.ftComboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftComboBox3.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftComboBox3.ForeColor = System.Drawing.Color.Black;
            this.ftComboBox3.FormattingEnabled = true;
            this.ftComboBox3.Location = new System.Drawing.Point(51, 115);
            this.ftComboBox3.Name = "ftComboBox3";
            this.ftComboBox3.ReadOnly = false;
            this.ftComboBox3.Size = new System.Drawing.Size(140, 20);
            this.ftComboBox3.TabIndex = 57;
            // 
            // ftLabel13
            // 
            this.ftLabel13.AllowForeColorChange = false;
            this.ftLabel13.AutoSize = true;
            this.ftLabel13.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel13.ForeColor = System.Drawing.Color.Black;
            this.ftLabel13.Location = new System.Drawing.Point(223, 0);
            this.ftLabel13.Name = "ftLabel13";
            this.ftLabel13.OverrideDefault = false;
            this.ftLabel13.Size = new System.Drawing.Size(72, 12);
            this.ftLabel13.TabIndex = 47;
            this.ftLabel13.Text = "Same as above";
            // 
            // ftCheckBox1
            // 
            this.ftCheckBox1.AutoSize = true;
            this.ftCheckBox1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftCheckBox1.ForeColor = System.Drawing.Color.Black;
            this.ftCheckBox1.Location = new System.Drawing.Point(206, 0);
            this.ftCheckBox1.Name = "ftCheckBox1";
            this.ftCheckBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ftCheckBox1.Size = new System.Drawing.Size(15, 14);
            this.ftCheckBox1.TabIndex = 41;
            this.ftCheckBox1.UseVisualStyleBackColor = true;
            // 
            // ftCreated
            // 
            this.ftCreated.AllowForeColorChange = false;
            this.ftCreated.AutoSize = true;
            this.ftCreated.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftCreated.ForeColor = System.Drawing.Color.Black;
            this.ftCreated.IsMandatory = true;
            this.ftCreated.Location = new System.Drawing.Point(596, 19);
            this.ftCreated.Name = "ftCreated";
            this.ftCreated.OverrideDefault = false;
            this.ftCreated.Size = new System.Drawing.Size(46, 12);
            this.ftCreated.TabIndex = 69;
            this.ftCreated.Text = "Created*";
            // 
            // ftlblMarried
            // 
            this.ftlblMarried.AllowForeColorChange = false;
            this.ftlblMarried.AutoSize = true;
            this.ftlblMarried.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftlblMarried.ForeColor = System.Drawing.Color.Black;
            this.ftlblMarried.Location = new System.Drawing.Point(416, 19);
            this.ftlblMarried.Name = "ftlblMarried";
            this.ftlblMarried.OverrideDefault = false;
            this.ftlblMarried.Size = new System.Drawing.Size(39, 12);
            this.ftlblMarried.TabIndex = 68;
            this.ftlblMarried.Text = "Married";
            // 
            // ftlblGender
            // 
            this.ftlblGender.AllowForeColorChange = false;
            this.ftlblGender.AutoSize = true;
            this.ftlblGender.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftlblGender.ForeColor = System.Drawing.Color.Black;
            this.ftlblGender.IsMandatory = true;
            this.ftlblGender.Location = new System.Drawing.Point(263, 21);
            this.ftlblGender.Name = "ftlblGender";
            this.ftlblGender.OverrideDefault = false;
            this.ftlblGender.Size = new System.Drawing.Size(44, 12);
            this.ftlblGender.TabIndex = 67;
            this.ftlblGender.Text = "Gender*";
            // 
            // ftlblDOB
            // 
            this.ftlblDOB.AllowForeColorChange = false;
            this.ftlblDOB.AutoSize = true;
            this.ftlblDOB.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftlblDOB.ForeColor = System.Drawing.Color.Black;
            this.ftlblDOB.IsMandatory = true;
            this.ftlblDOB.Location = new System.Drawing.Point(16, 19);
            this.ftlblDOB.Name = "ftlblDOB";
            this.ftlblDOB.OverrideDefault = false;
            this.ftlblDOB.Size = new System.Drawing.Size(32, 12);
            this.ftlblDOB.TabIndex = 66;
            this.ftlblDOB.Text = "DOB*";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ftTxtAddress4);
            this.groupBox2.Controls.Add(this.ftTxtAddress2);
            this.groupBox2.Controls.Add(this.ftTxtAddress3);
            this.groupBox2.Controls.Add(this.ftTxtAddress1);
            this.groupBox2.Controls.Add(this.ftLabel32);
            this.groupBox2.Controls.Add(this.ftTxtMail);
            this.groupBox2.Controls.Add(this.lblAddressLine1);
            this.groupBox2.Controls.Add(this.ftLabel24);
            this.groupBox2.Controls.Add(this.ftLabel25);
            this.groupBox2.Controls.Add(this.ftLabel26);
            this.groupBox2.Controls.Add(this.ftTextBox12);
            this.groupBox2.Controls.Add(this.ftTextBox13);
            this.groupBox2.Controls.Add(this.ftTextBox14);
            this.groupBox2.Controls.Add(this.ftTextBox15);
            this.groupBox2.Controls.Add(this.ftLabel27);
            this.groupBox2.Controls.Add(this.ftTextBox16);
            this.groupBox2.Controls.Add(this.ftLabel28);
            this.groupBox2.Controls.Add(this.ftComboBox4);
            this.groupBox2.Controls.Add(this.ftLabel29);
            this.groupBox2.Controls.Add(this.ftComboBox5);
            this.groupBox2.Controls.Add(this.ftLabel30);
            this.groupBox2.Controls.Add(this.ftLabel31);
            this.groupBox2.Controls.Add(this.ftComboBox6);
            this.groupBox2.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox2.Location = new System.Drawing.Point(14, 140);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(753, 181);
            this.groupBox2.TabIndex = 65;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Correspondence Address";
            // 
            // ftTxtAddress4
            // 
            this.ftTxtAddress4.AllowAlpha = true;
            this.ftTxtAddress4.AllowDot = false;
            this.ftTxtAddress4.AllowedCustomCharacters = null;
            this.ftTxtAddress4.AllowNonASCII = false;
            this.ftTxtAddress4.AllowNumeric = true;
            this.ftTxtAddress4.AllowSpace = false;
            this.ftTxtAddress4.AllowSpecialChars = true;
            this.ftTxtAddress4.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtAddress4.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtAddress4.ForeColor = System.Drawing.Color.Black;
            this.ftTxtAddress4.IsEmailID = false;
            this.ftTxtAddress4.IsEmailIdValid = false;
            this.ftTxtAddress4.Location = new System.Drawing.Point(392, 56);
            this.ftTxtAddress4.MaxLength = 10;
            this.ftTxtAddress4.Name = "ftTxtAddress4";
            this.ftTxtAddress4.Size = new System.Drawing.Size(353, 20);
            this.ftTxtAddress4.TabIndex = 60;
            this.ftTxtAddress4.Tag = "Code";
            // 
            // ftTxtAddress2
            // 
            this.ftTxtAddress2.AllowAlpha = true;
            this.ftTxtAddress2.AllowDot = false;
            this.ftTxtAddress2.AllowedCustomCharacters = null;
            this.ftTxtAddress2.AllowNonASCII = false;
            this.ftTxtAddress2.AllowNumeric = true;
            this.ftTxtAddress2.AllowSpace = false;
            this.ftTxtAddress2.AllowSpecialChars = true;
            this.ftTxtAddress2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtAddress2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtAddress2.ForeColor = System.Drawing.Color.Black;
            this.ftTxtAddress2.IsEmailID = false;
            this.ftTxtAddress2.IsEmailIdValid = false;
            this.ftTxtAddress2.Location = new System.Drawing.Point(392, 25);
            this.ftTxtAddress2.MaxLength = 10;
            this.ftTxtAddress2.Name = "ftTxtAddress2";
            this.ftTxtAddress2.Size = new System.Drawing.Size(353, 20);
            this.ftTxtAddress2.TabIndex = 59;
            this.ftTxtAddress2.Tag = "Code";
            // 
            // ftTxtAddress3
            // 
            this.ftTxtAddress3.AllowAlpha = true;
            this.ftTxtAddress3.AllowDot = false;
            this.ftTxtAddress3.AllowedCustomCharacters = null;
            this.ftTxtAddress3.AllowNonASCII = false;
            this.ftTxtAddress3.AllowNumeric = true;
            this.ftTxtAddress3.AllowSpace = false;
            this.ftTxtAddress3.AllowSpecialChars = true;
            this.ftTxtAddress3.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtAddress3.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtAddress3.ForeColor = System.Drawing.Color.Black;
            this.ftTxtAddress3.IsEmailID = false;
            this.ftTxtAddress3.IsEmailIdValid = false;
            this.ftTxtAddress3.Location = new System.Drawing.Point(49, 56);
            this.ftTxtAddress3.MaxLength = 10;
            this.ftTxtAddress3.Name = "ftTxtAddress3";
            this.ftTxtAddress3.Size = new System.Drawing.Size(337, 20);
            this.ftTxtAddress3.TabIndex = 58;
            this.ftTxtAddress3.Tag = "Code";
            // 
            // ftTxtAddress1
            // 
            this.ftTxtAddress1.AllowAlpha = true;
            this.ftTxtAddress1.AllowDot = false;
            this.ftTxtAddress1.AllowedCustomCharacters = null;
            this.ftTxtAddress1.AllowNonASCII = false;
            this.ftTxtAddress1.AllowNumeric = true;
            this.ftTxtAddress1.AllowSpace = false;
            this.ftTxtAddress1.AllowSpecialChars = true;
            this.ftTxtAddress1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtAddress1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtAddress1.ForeColor = System.Drawing.Color.Black;
            this.ftTxtAddress1.IsEmailID = false;
            this.ftTxtAddress1.IsEmailIdValid = false;
            this.ftTxtAddress1.Location = new System.Drawing.Point(49, 25);
            this.ftTxtAddress1.MaxLength = 10;
            this.ftTxtAddress1.Name = "ftTxtAddress1";
            this.ftTxtAddress1.Size = new System.Drawing.Size(337, 20);
            this.ftTxtAddress1.TabIndex = 57;
            this.ftTxtAddress1.Tag = "Code";
            // 
            // ftLabel32
            // 
            this.ftLabel32.AllowForeColorChange = false;
            this.ftLabel32.AutoSize = true;
            this.ftLabel32.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel32.ForeColor = System.Drawing.Color.Black;
            this.ftLabel32.Location = new System.Drawing.Point(2, 90);
            this.ftLabel32.Name = "ftLabel32";
            this.ftLabel32.OverrideDefault = false;
            this.ftLabel32.Size = new System.Drawing.Size(32, 12);
            this.ftLabel32.TabIndex = 56;
            this.ftLabel32.Text = "E-Mail";
            // 
            // ftTxtMail
            // 
            this.ftTxtMail.AllowAlpha = true;
            this.ftTxtMail.AllowDot = false;
            this.ftTxtMail.AllowedCustomCharacters = null;
            this.ftTxtMail.AllowNonASCII = false;
            this.ftTxtMail.AllowNumeric = true;
            this.ftTxtMail.AllowSpace = false;
            this.ftTxtMail.AllowSpecialChars = true;
            this.ftTxtMail.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTxtMail.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTxtMail.ForeColor = System.Drawing.Color.Black;
            this.ftTxtMail.IsEmailID = false;
            this.ftTxtMail.IsEmailIdValid = false;
            this.ftTxtMail.Location = new System.Drawing.Point(49, 87);
            this.ftTxtMail.MaxLength = 10;
            this.ftTxtMail.Name = "ftTxtMail";
            this.ftTxtMail.Size = new System.Drawing.Size(337, 20);
            this.ftTxtMail.TabIndex = 55;
            this.ftTxtMail.Tag = "Code";
            // 
            // lblAddressLine1
            // 
            this.lblAddressLine1.AllowForeColorChange = false;
            this.lblAddressLine1.AutoSize = true;
            this.lblAddressLine1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblAddressLine1.ForeColor = System.Drawing.Color.Black;
            this.lblAddressLine1.Location = new System.Drawing.Point(3, 29);
            this.lblAddressLine1.Name = "lblAddressLine1";
            this.lblAddressLine1.OverrideDefault = false;
            this.lblAddressLine1.Size = new System.Drawing.Size(41, 12);
            this.lblAddressLine1.TabIndex = 50;
            this.lblAddressLine1.Text = "Address";
            // 
            // ftLabel24
            // 
            this.ftLabel24.AllowForeColorChange = false;
            this.ftLabel24.AutoSize = true;
            this.ftLabel24.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel24.ForeColor = System.Drawing.Color.Black;
            this.ftLabel24.Location = new System.Drawing.Point(600, 152);
            this.ftLabel24.Name = "ftLabel24";
            this.ftLabel24.OverrideDefault = false;
            this.ftLabel24.Size = new System.Drawing.Size(21, 12);
            this.ftLabel24.TabIndex = 49;
            this.ftLabel24.Text = "Fax";
            // 
            // ftLabel25
            // 
            this.ftLabel25.AllowForeColorChange = false;
            this.ftLabel25.AutoSize = true;
            this.ftLabel25.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel25.ForeColor = System.Drawing.Color.Black;
            this.ftLabel25.Location = new System.Drawing.Point(404, 154);
            this.ftLabel25.Name = "ftLabel25";
            this.ftLabel25.OverrideDefault = false;
            this.ftLabel25.Size = new System.Drawing.Size(26, 12);
            this.ftLabel25.TabIndex = 48;
            this.ftLabel25.Text = "Tel.2";
            // 
            // ftLabel26
            // 
            this.ftLabel26.AllowForeColorChange = false;
            this.ftLabel26.AutoSize = true;
            this.ftLabel26.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel26.ForeColor = System.Drawing.Color.Black;
            this.ftLabel26.Location = new System.Drawing.Point(212, 153);
            this.ftLabel26.Name = "ftLabel26";
            this.ftLabel26.OverrideDefault = false;
            this.ftLabel26.Size = new System.Drawing.Size(26, 12);
            this.ftLabel26.TabIndex = 47;
            this.ftLabel26.Text = "Tel.1";
            // 
            // ftTextBox12
            // 
            this.ftTextBox12.AllowAlpha = true;
            this.ftTextBox12.AllowDot = false;
            this.ftTextBox12.AllowedCustomCharacters = null;
            this.ftTextBox12.AllowNonASCII = false;
            this.ftTextBox12.AllowNumeric = true;
            this.ftTextBox12.AllowSpace = false;
            this.ftTextBox12.AllowSpecialChars = true;
            this.ftTextBox12.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox12.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox12.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox12.IsEmailID = false;
            this.ftTextBox12.IsEmailIdValid = false;
            this.ftTextBox12.Location = new System.Drawing.Point(624, 149);
            this.ftTextBox12.MaxLength = 10;
            this.ftTextBox12.Name = "ftTextBox12";
            this.ftTextBox12.Size = new System.Drawing.Size(122, 20);
            this.ftTextBox12.TabIndex = 41;
            this.ftTextBox12.Tag = "Code";
            // 
            // ftTextBox13
            // 
            this.ftTextBox13.AllowAlpha = true;
            this.ftTextBox13.AllowDot = false;
            this.ftTextBox13.AllowedCustomCharacters = null;
            this.ftTextBox13.AllowNonASCII = false;
            this.ftTextBox13.AllowNumeric = true;
            this.ftTextBox13.AllowSpace = false;
            this.ftTextBox13.AllowSpecialChars = true;
            this.ftTextBox13.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox13.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox13.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox13.IsEmailID = false;
            this.ftTextBox13.IsEmailIdValid = false;
            this.ftTextBox13.Location = new System.Drawing.Point(439, 149);
            this.ftTextBox13.MaxLength = 10;
            this.ftTextBox13.Name = "ftTextBox13";
            this.ftTextBox13.Size = new System.Drawing.Size(140, 20);
            this.ftTextBox13.TabIndex = 39;
            this.ftTextBox13.Tag = "Code";
            // 
            // ftTextBox14
            // 
            this.ftTextBox14.AllowAlpha = true;
            this.ftTextBox14.AllowDot = false;
            this.ftTextBox14.AllowedCustomCharacters = null;
            this.ftTextBox14.AllowNonASCII = false;
            this.ftTextBox14.AllowNumeric = true;
            this.ftTextBox14.AllowSpace = false;
            this.ftTextBox14.AllowSpecialChars = true;
            this.ftTextBox14.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox14.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox14.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox14.IsEmailID = false;
            this.ftTextBox14.IsEmailIdValid = false;
            this.ftTextBox14.Location = new System.Drawing.Point(245, 149);
            this.ftTextBox14.MaxLength = 10;
            this.ftTextBox14.Name = "ftTextBox14";
            this.ftTextBox14.Size = new System.Drawing.Size(140, 20);
            this.ftTextBox14.TabIndex = 37;
            this.ftTextBox14.Tag = "Code";
            // 
            // ftTextBox15
            // 
            this.ftTextBox15.AllowAlpha = true;
            this.ftTextBox15.AllowDot = false;
            this.ftTextBox15.AllowedCustomCharacters = null;
            this.ftTextBox15.AllowNonASCII = false;
            this.ftTextBox15.AllowNumeric = true;
            this.ftTextBox15.AllowSpace = false;
            this.ftTextBox15.AllowSpecialChars = true;
            this.ftTextBox15.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox15.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox15.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox15.IsEmailID = false;
            this.ftTextBox15.IsEmailIdValid = false;
            this.ftTextBox15.Location = new System.Drawing.Point(49, 149);
            this.ftTextBox15.MaxLength = 10;
            this.ftTextBox15.Name = "ftTextBox15";
            this.ftTextBox15.Size = new System.Drawing.Size(140, 20);
            this.ftTextBox15.TabIndex = 32;
            this.ftTextBox15.Tag = "Code";
            // 
            // ftLabel27
            // 
            this.ftLabel27.AllowForeColorChange = false;
            this.ftLabel27.AutoSize = true;
            this.ftLabel27.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel27.ForeColor = System.Drawing.Color.Black;
            this.ftLabel27.Location = new System.Drawing.Point(2, 153);
            this.ftLabel27.Name = "ftLabel27";
            this.ftLabel27.OverrideDefault = false;
            this.ftLabel27.Size = new System.Drawing.Size(34, 12);
            this.ftLabel27.TabIndex = 36;
            this.ftLabel27.Text = "Mobile";
            // 
            // ftTextBox16
            // 
            this.ftTextBox16.AllowAlpha = true;
            this.ftTextBox16.AllowDot = false;
            this.ftTextBox16.AllowedCustomCharacters = null;
            this.ftTextBox16.AllowNonASCII = false;
            this.ftTextBox16.AllowNumeric = true;
            this.ftTextBox16.AllowSpace = false;
            this.ftTextBox16.AllowSpecialChars = true;
            this.ftTextBox16.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox16.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox16.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox16.IsEmailID = false;
            this.ftTextBox16.IsEmailIdValid = false;
            this.ftTextBox16.Location = new System.Drawing.Point(624, 117);
            this.ftTextBox16.MaxLength = 10;
            this.ftTextBox16.Name = "ftTextBox16";
            this.ftTextBox16.Size = new System.Drawing.Size(122, 20);
            this.ftTextBox16.TabIndex = 31;
            this.ftTextBox16.Tag = "Code";
            // 
            // ftLabel28
            // 
            this.ftLabel28.AllowForeColorChange = false;
            this.ftLabel28.AutoSize = true;
            this.ftLabel28.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel28.ForeColor = System.Drawing.Color.Black;
            this.ftLabel28.Location = new System.Drawing.Point(596, 121);
            this.ftLabel28.Name = "ftLabel28";
            this.ftLabel28.OverrideDefault = false;
            this.ftLabel28.Size = new System.Drawing.Size(22, 12);
            this.ftLabel28.TabIndex = 35;
            this.ftLabel28.Text = "PIN";
            // 
            // ftComboBox4
            // 
            this.ftComboBox4.BackColor = System.Drawing.Color.White;
            this.ftComboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftComboBox4.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftComboBox4.ForeColor = System.Drawing.Color.Black;
            this.ftComboBox4.FormattingEnabled = true;
            this.ftComboBox4.Location = new System.Drawing.Point(439, 118);
            this.ftComboBox4.Name = "ftComboBox4";
            this.ftComboBox4.ReadOnly = false;
            this.ftComboBox4.Size = new System.Drawing.Size(140, 20);
            this.ftComboBox4.TabIndex = 33;
            // 
            // ftLabel29
            // 
            this.ftLabel29.AllowForeColorChange = false;
            this.ftLabel29.AutoSize = true;
            this.ftLabel29.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel29.ForeColor = System.Drawing.Color.Black;
            this.ftLabel29.Location = new System.Drawing.Point(404, 121);
            this.ftLabel29.Name = "ftLabel29";
            this.ftLabel29.OverrideDefault = false;
            this.ftLabel29.Size = new System.Drawing.Size(23, 12);
            this.ftLabel29.TabIndex = 34;
            this.ftLabel29.Text = "City";
            // 
            // ftComboBox5
            // 
            this.ftComboBox5.BackColor = System.Drawing.Color.White;
            this.ftComboBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftComboBox5.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftComboBox5.ForeColor = System.Drawing.Color.Black;
            this.ftComboBox5.FormattingEnabled = true;
            this.ftComboBox5.Location = new System.Drawing.Point(245, 118);
            this.ftComboBox5.Name = "ftComboBox5";
            this.ftComboBox5.ReadOnly = false;
            this.ftComboBox5.Size = new System.Drawing.Size(140, 20);
            this.ftComboBox5.TabIndex = 31;
            // 
            // ftLabel30
            // 
            this.ftLabel30.AllowForeColorChange = false;
            this.ftLabel30.AutoSize = true;
            this.ftLabel30.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel30.ForeColor = System.Drawing.Color.Black;
            this.ftLabel30.Location = new System.Drawing.Point(212, 121);
            this.ftLabel30.Name = "ftLabel30";
            this.ftLabel30.OverrideDefault = false;
            this.ftLabel30.Size = new System.Drawing.Size(27, 12);
            this.ftLabel30.TabIndex = 32;
            this.ftLabel30.Text = "State";
            // 
            // ftLabel31
            // 
            this.ftLabel31.AllowForeColorChange = false;
            this.ftLabel31.AutoSize = true;
            this.ftLabel31.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel31.ForeColor = System.Drawing.Color.Black;
            this.ftLabel31.Location = new System.Drawing.Point(3, 121);
            this.ftLabel31.Name = "ftLabel31";
            this.ftLabel31.OverrideDefault = false;
            this.ftLabel31.Size = new System.Drawing.Size(43, 12);
            this.ftLabel31.TabIndex = 31;
            this.ftLabel31.Text = "Country";
            // 
            // ftComboBox6
            // 
            this.ftComboBox6.BackColor = System.Drawing.Color.White;
            this.ftComboBox6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftComboBox6.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftComboBox6.ForeColor = System.Drawing.Color.Black;
            this.ftComboBox6.FormattingEnabled = true;
            this.ftComboBox6.Location = new System.Drawing.Point(49, 118);
            this.ftComboBox6.Name = "ftComboBox6";
            this.ftComboBox6.ReadOnly = false;
            this.ftComboBox6.Size = new System.Drawing.Size(140, 20);
            this.ftComboBox6.TabIndex = 29;
            // 
            // ftCmbMarried
            // 
            this.ftCmbMarried.BackColor = System.Drawing.Color.White;
            this.ftCmbMarried.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftCmbMarried.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftCmbMarried.ForeColor = System.Drawing.Color.Black;
            this.ftCmbMarried.FormattingEnabled = true;
            this.ftCmbMarried.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.ftCmbMarried.Location = new System.Drawing.Point(463, 15);
            this.ftCmbMarried.Name = "ftCmbMarried";
            this.ftCmbMarried.ReadOnly = false;
            this.ftCmbMarried.Size = new System.Drawing.Size(66, 20);
            this.ftCmbMarried.TabIndex = 64;
            // 
            // ftCmbGender
            // 
            this.ftCmbGender.BackColor = System.Drawing.Color.White;
            this.ftCmbGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftCmbGender.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftCmbGender.ForeColor = System.Drawing.Color.Black;
            this.ftCmbGender.FormattingEnabled = true;
            this.ftCmbGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.ftCmbGender.Location = new System.Drawing.Point(325, 15);
            this.ftCmbGender.Name = "ftCmbGender";
            this.ftCmbGender.ReadOnly = false;
            this.ftCmbGender.Size = new System.Drawing.Size(66, 20);
            this.ftCmbGender.TabIndex = 63;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(647, 13);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(120, 22);
            this.dateTimePicker1.TabIndex = 62;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ftLabel34);
            this.groupBox1.Controls.Add(this.ftTextBox19);
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox1.Location = new System.Drawing.Point(14, 77);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(753, 51);
            this.groupBox1.TabIndex = 61;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Father/Mother/Spouse";
            // 
            // ftLabel34
            // 
            this.ftLabel34.AllowForeColorChange = false;
            this.ftLabel34.AutoSize = true;
            this.ftLabel34.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel34.ForeColor = System.Drawing.Color.Black;
            this.ftLabel34.IsMandatory = true;
            this.ftLabel34.Location = new System.Drawing.Point(7, 24);
            this.ftLabel34.Name = "ftLabel34";
            this.ftLabel34.OverrideDefault = false;
            this.ftLabel34.Size = new System.Drawing.Size(36, 12);
            this.ftLabel34.TabIndex = 24;
            this.ftLabel34.Text = "Name*";
            // 
            // ftTextBox19
            // 
            this.ftTextBox19.AllowAlpha = true;
            this.ftTextBox19.AllowDot = false;
            this.ftTextBox19.AllowedCustomCharacters = null;
            this.ftTextBox19.AllowNonASCII = false;
            this.ftTextBox19.AllowNumeric = true;
            this.ftTextBox19.AllowSpace = false;
            this.ftTextBox19.AllowSpecialChars = true;
            this.ftTextBox19.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ftTextBox19.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftTextBox19.ForeColor = System.Drawing.Color.Black;
            this.ftTextBox19.IsEmailID = false;
            this.ftTextBox19.IsEmailIdValid = false;
            this.ftTextBox19.Location = new System.Drawing.Point(56, 20);
            this.ftTextBox19.MaxLength = 10;
            this.ftTextBox19.Name = "ftTextBox19";
            this.ftTextBox19.Size = new System.Drawing.Size(690, 20);
            this.ftTextBox19.TabIndex = 23;
            this.ftTextBox19.Tag = "Code";
            // 
            // tbEntity
            // 
            this.tbEntity.Controls.Add(this.tbAccount);
            this.tbEntity.Controls.Add(this.tbOthers);
            this.tbEntity.Controls.Add(this.DocUpload);
            this.tbEntity.Controls.Add(this.tabPage1);
            this.tbEntity.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.tbEntity.Location = new System.Drawing.Point(4, 104);
            this.tbEntity.Name = "tbEntity";
            this.tbEntity.SelectedIndex = 0;
            this.tbEntity.Size = new System.Drawing.Size(789, 555);
            this.tbEntity.TabIndex = 73;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Transparent;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.Location = new System.Drawing.Point(428, 248);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 25);
            this.btnDelete.TabIndex = 64;
            this.btnDelete.Text = "&Delete";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.UseVisualStyleBackColor = false;
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Transparent;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAdd.Location = new System.Drawing.Point(256, 249);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 25);
            this.btnAdd.TabIndex = 63;
            this.btnAdd.Text = "&New";
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAdd.UseVisualStyleBackColor = false;
            // 
            // ftBtnSaveIdentity
            // 
            this.ftBtnSaveIdentity.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ftBtnSaveIdentity.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ftBtnSaveIdentity.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.ftBtnSaveIdentity.Image = ((System.Drawing.Image)(resources.GetObject("ftBtnSaveIdentity.Image")));
            this.ftBtnSaveIdentity.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ftBtnSaveIdentity.Location = new System.Drawing.Point(337, 249);
            this.ftBtnSaveIdentity.Name = "ftBtnSaveIdentity";
            this.ftBtnSaveIdentity.Size = new System.Drawing.Size(84, 25);
            this.ftBtnSaveIdentity.TabIndex = 72;
            this.ftBtnSaveIdentity.Text = "&Save";
            this.ftBtnSaveIdentity.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ftBtnSaveIdentity.UseVisualStyleBackColor = true;
            // 
            // btnImport
            // 
            this.btnImport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnImport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnImport.Image = ((System.Drawing.Image)(resources.GetObject("btnImport.Image")));
            this.btnImport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnImport.Location = new System.Drawing.Point(288, 20);
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(85, 23);
            this.btnImport.TabIndex = 54;
            this.btnImport.Text = "Upload";
            this.btnImport.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnImport.UseVisualStyleBackColor = true;
            // 
            // ftBtnRemoveDoc
            // 
            this.ftBtnRemoveDoc.BackColor = System.Drawing.Color.Transparent;
            this.ftBtnRemoveDoc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ftBtnRemoveDoc.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.ftBtnRemoveDoc.Image = ((System.Drawing.Image)(resources.GetObject("ftBtnRemoveDoc.Image")));
            this.ftBtnRemoveDoc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ftBtnRemoveDoc.Location = new System.Drawing.Point(698, 93);
            this.ftBtnRemoveDoc.Name = "ftBtnRemoveDoc";
            this.ftBtnRemoveDoc.Size = new System.Drawing.Size(75, 25);
            this.ftBtnRemoveDoc.TabIndex = 65;
            this.ftBtnRemoveDoc.Text = "&Delete";
            this.ftBtnRemoveDoc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ftBtnRemoveDoc.UseVisualStyleBackColor = false;
            // 
            // EntityInd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.ftLabel78);
            this.Controls.Add(this.tbEntity);
            this.Controls.Add(this.btnApply);
            this.Controls.Add(this.lblMobileNo);
            this.Controls.Add(this.ftlblEntityCode);
            this.Controls.Add(this.lblHeading);
            this.Controls.Add(this.txtNameHead);
            this.Controls.Add(this.txtEntityCode);
            this.Name = "EntityInd";
            this.Size = new System.Drawing.Size(797, 703);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.DocUpload.ResumeLayout(false);
            this.DocUpload.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.tbOthers.ResumeLayout(false);
            this.tbOthers.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tbAccount.ResumeLayout(false);
            this.tbAccount.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tbEntity.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private MatchCommon.CustomControls.FTLabel ftLabel78;
        private MatchCommon.CustomControls.FTButton btnApply;
        private MatchCommon.CustomControls.FTLabel lblMobileNo;
        private MatchCommon.CustomControls.FTLabel ftlblEntityCode;
        private System.Windows.Forms.Label lblHeading;
        private System.Windows.Forms.TextBox txtNameHead;
        private System.Windows.Forms.TextBox txtEntityCode;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.CheckBox chkProtector;
        private System.Windows.Forms.CheckBox chkMatch;
        private System.Windows.Forms.CheckBox chkDP;
        private System.Windows.Forms.CheckBox chkODIN;
        private System.Windows.Forms.TabPage DocUpload;
        private MatchCommon.CustomControls.FTLabel ftLabel77;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date;
        private System.Windows.Forms.GroupBox groupBox11;
        private MatchCommon.CustomControls.FTLabel ftLabel81;
        private MatchCommon.CustomControls.FTComboBox ftCmbTypeofDocument;
        private System.Windows.Forms.TabPage tbOthers;
        private MatchCommon.CustomControls.FTLabel ftLabel54;
        private MatchCommon.CustomControls.FTTextBox ftTxtUserId;
        private MatchCommon.CustomControls.FTTextBox ftTxtPEP;
        private MatchCommon.CustomControls.FTTextBox ftTxtOccupation;
        private MatchCommon.CustomControls.FTLabel ftLabel53;
        private MatchCommon.CustomControls.FTComboBox ftCmbFacilityType;
        private MatchCommon.CustomControls.FTLabel ftLabel39;
        private MatchCommon.CustomControls.FTComboBox ftCmbPEP;
        private MatchCommon.CustomControls.FTLabel ftLabel40;
        private MatchCommon.CustomControls.FTComboBox ftCmbOccupation;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.DateTimePicker dateTimePicker6;
        private MatchCommon.CustomControls.FTComboBox ftCmbGrossAnnual;
        private System.Windows.Forms.DateTimePicker dateTimePicker5;
        private MatchCommon.CustomControls.FTTextBox ftTextBox25;
        private MatchCommon.CustomControls.FTLabel ftLabel41;
        private MatchCommon.CustomControls.FTLabel ftLabel42;
        private System.Windows.Forms.GroupBox groupBox6;
        private MatchCommon.CustomControls.FTLabel ftLabel43;
        private System.Windows.Forms.DateTimePicker dateTimePicker4;
        private MatchCommon.CustomControls.FTLabel ftLabel44;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private MatchCommon.CustomControls.FTLabel ftLabel45;
        private MatchCommon.CustomControls.FTLabel ftLabel46;
        private MatchCommon.CustomControls.FTLabel ftLabel47;
        private MatchCommon.CustomControls.FTTextBox ftTextBox26;
        private MatchCommon.CustomControls.FTTextBox ftTextBox27;
        private MatchCommon.CustomControls.FTComboBox ftComboBox8;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.TabPage tbAccount;
        private System.Windows.Forms.TabControl tbEntity;
        private MatchCommon.CustomControls.FTTextBox ftTextBox4;
        private MatchCommon.CustomControls.FTTextBox ftTextBox3;
        private MatchCommon.CustomControls.FTLabel ftLblOccupation;
        private MatchCommon.CustomControls.FTLabel ftLblNationality;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.GroupBox groupBox3;
        private MatchCommon.CustomControls.FTTextBox ftTxtAddress24;
        private MatchCommon.CustomControls.FTTextBox ftTxtAddress22;
        private MatchCommon.CustomControls.FTTextBox ftTxtAddress23;
        private MatchCommon.CustomControls.FTTextBox ftTxtAddress21;
        private MatchCommon.CustomControls.FTLabel ftLabel1;
        private MatchCommon.CustomControls.FTTextBox ftTxtMail2;
        private MatchCommon.CustomControls.FTLabel ftLabel2;
        private MatchCommon.CustomControls.FTLabel ftLabel3;
        private MatchCommon.CustomControls.FTLabel ftLabel4;
        private MatchCommon.CustomControls.FTLabel ftLabel5;
        private MatchCommon.CustomControls.FTTextBox ftTextBox8;
        private MatchCommon.CustomControls.FTTextBox ftTextBox9;
        private MatchCommon.CustomControls.FTTextBox ftTextBox10;
        private MatchCommon.CustomControls.FTTextBox ftTextBox11;
        private MatchCommon.CustomControls.FTLabel ftLabel6;
        private MatchCommon.CustomControls.FTTextBox ftTextBox18;
        private MatchCommon.CustomControls.FTLabel ftLabel7;
        private MatchCommon.CustomControls.FTComboBox ftComboBox1;
        private MatchCommon.CustomControls.FTLabel ftLabel8;
        private MatchCommon.CustomControls.FTComboBox ftComboBox2;
        private MatchCommon.CustomControls.FTLabel ftLabel9;
        private MatchCommon.CustomControls.FTLabel ftLabel10;
        private MatchCommon.CustomControls.FTComboBox ftComboBox3;
        private MatchCommon.CustomControls.FTLabel ftLabel13;
        private MatchCommon.CustomControls.FTCheckBox ftCheckBox1;
        private MatchCommon.CustomControls.FTLabel ftCreated;
        private MatchCommon.CustomControls.FTLabel ftlblMarried;
        private MatchCommon.CustomControls.FTLabel ftlblGender;
        private MatchCommon.CustomControls.FTLabel ftlblDOB;
        private System.Windows.Forms.GroupBox groupBox2;
        private MatchCommon.CustomControls.FTTextBox ftTxtAddress4;
        private MatchCommon.CustomControls.FTTextBox ftTxtAddress2;
        private MatchCommon.CustomControls.FTTextBox ftTxtAddress3;
        private MatchCommon.CustomControls.FTTextBox ftTxtAddress1;
        private MatchCommon.CustomControls.FTLabel ftLabel32;
        private MatchCommon.CustomControls.FTTextBox ftTxtMail;
        private MatchCommon.CustomControls.FTLabel lblAddressLine1;
        private MatchCommon.CustomControls.FTLabel ftLabel24;
        private MatchCommon.CustomControls.FTLabel ftLabel25;
        private MatchCommon.CustomControls.FTLabel ftLabel26;
        private MatchCommon.CustomControls.FTTextBox ftTextBox12;
        private MatchCommon.CustomControls.FTTextBox ftTextBox13;
        private MatchCommon.CustomControls.FTTextBox ftTextBox14;
        private MatchCommon.CustomControls.FTTextBox ftTextBox15;
        private MatchCommon.CustomControls.FTLabel ftLabel27;
        private MatchCommon.CustomControls.FTTextBox ftTextBox16;
        private MatchCommon.CustomControls.FTLabel ftLabel28;
        private MatchCommon.CustomControls.FTComboBox ftComboBox4;
        private MatchCommon.CustomControls.FTLabel ftLabel29;
        private MatchCommon.CustomControls.FTComboBox ftComboBox5;
        private MatchCommon.CustomControls.FTLabel ftLabel30;
        private MatchCommon.CustomControls.FTLabel ftLabel31;
        private MatchCommon.CustomControls.FTComboBox ftComboBox6;
        private MatchCommon.CustomControls.FTComboBox ftCmbMarried;
        private MatchCommon.CustomControls.FTComboBox ftCmbGender;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.GroupBox groupBox1;
        private MatchCommon.CustomControls.FTLabel ftLabel34;
        private MatchCommon.CustomControls.FTTextBox ftTextBox19;
        private MatchCommon.CustomControls.FTButton ftBtnRemoveDoc;
        private System.Windows.Forms.Button btnImport;
        private MatchCommon.CustomControls.FTButton ftBtnSaveIdentity;
        private MatchCommon.CustomControls.FTButton btnDelete;
        private MatchCommon.CustomControls.FTButton btnAdd;
    }
}
