﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FTIL.Match.CDD.BAL;
using FTIL.Match.CDD.UI.Forms;
using C1.Win.C1FlexGrid;
using FTIL.Match.Common.Log;
using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.Common;
using UCC.Class;

namespace FTIL.Match.CDD.UI.UserControls
{
    /// <summary>
    /// Related Party User Control
    /// </summary>
    public partial class ucEntityAuthSign : ucBaseEntity
    {

        private List<EntityDetails> m_IndividualEntityDetailList;


        private int m_ClientNoIndividual;
        private int m_RelatedPartyNo;

        private DataTable m_AddressDataTable;
        AuthSignDetails authDetails;
        private bool m_AddNew;
        private bool m_AddNewRelatedParty;

        private int m_RowNo;
        private int m_CurrentRowNo;

        private FormModeEnum m_FormMode;
        //public string EntityType { get; set; }


        /// <summary>
        /// Constructor
        /// </summary>
        public ucEntityAuthSign()
        {
            m_HasAllDropDownListBind = false;
            InitializeComponent();
            authDetails = new AuthSignDetails();
            authDetails.s_Nomination = "Y";// To add address details 

            m_IndividualEntityDetailList = new List<EntityDetails>();
           
            dgvAuthSign.Cols.Fixed = UIConstants.FlexGridLeftFixColumn;

            ucAddress1.Enabled = false;
            dgvAuthSign.Click += dgvAuthSign_Click;
            GridBind(authDetails.dtResult);

            m_FormMode = FormModeEnum.SELECT;


            txtSearchKey.BackColor = UIConstants.CtrlBackColorMandatory;
            cboRelationShip.BackColor = UIConstants.CtrlBackColorMandatory;
            cboIdentityType.BackColor = UIConstants.CtrlBackColorMandatory;
            txtDIN.BackColor = UIConstants.CtrlBackColorMandatory;

        }


        private void ucEntityAuthSign_Load(object sender, EventArgs e)
        {
            try
            {
                PopulateLookup();
                m_AddNew = false;
                
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
            }
        }

        /// <summary>
        /// KeyUp Event to Show Entity Search Form if F3 pressed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtSearchKey_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.F3)
                {
                    Help(false);
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
            }
        }


        /// <summary>
        /// Show Entity Search Form
        /// </summary>
        /// <param name="AdvanceSearch">Required Advance Search</param>
        private void Help(bool AdvanceSearch)
        {
            try
            {
                btnAdd.Text = "Add";

                txtSearchKey.Text = txtSearchKey.Text.Trim();
                if (txtSearchKey.Text.Length < 3 && AdvanceSearch == false)
                {
                    txtSearchKey.Text = null;
                        return;
                }
                int ClientNo = ShowEntityHelp(txtSearchKey.Text.Trim(), AdvanceSearch);

                if (ClientNo > 0)
                {
                    EntityDetails detail = GetEntityDetails(ClientNo);
                    detail.ClientNo = ClientNo;
                    m_ClientNoIndividual = ClientNo;
                    txtSearchKey.Text = detail.Applicant_Name;
                    ucAddress1.PopupateControls(detail.CorrespondenceAddress);
                   
                         if (detail.DOB_OR_DOI.ToString() != "")
                        dtDOB.Value = Convert.ToDateTime(detail.DOB_OR_DOI.ToString()).Date;
                    else
                        dtDOB.Value = System.DateTime.Now.Date;
                    m_IndividualEntityDetailList.Add(detail);

                    btnAdd.Text = "Add";

                    ResetControls(false);

                    m_AddNew = true;

                }

                m_FormMode =  FormModeEnum.INSERT;
                m_RelatedPartyNo = 0;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
            }
        }


        /// <summary>
        /// To Show Entity Help
        /// </summary>
        /// <param name="key">Search Key</param>
        /// <param name="AdvanceSearch">Flag for advance Search</param>
        /// <returns></returns>
        private int ShowEntityHelp(string key, bool AdvanceSearch)
        {
            int ClientNo = 0;
            try
            {
                frmEntitySearch frmSearch = new frmEntitySearch();
                frmSearch.NotVisibleColumns.Add(CEntityMaster.CLIENTNO);
                frmSearch.SearchKey = key;
                frmSearch.AllowAdvanceSearch = AdvanceSearch;
                frmSearch.Columns = new string[] { "Name", "KYCCode", "CustID", "KYCFormNo", "Mobile", "Email", "PAN" };
                frmSearch.DefaultSearchColumnIndex = 0;
                frmSearch.EntityNo = m_EntityDetailsInstance.ClientNo;
                frmSearch.HelpType = 1;
                frmSearch.IsAddNewEnable = true;



                DialogResult resultDia = frmSearch.ShowDialog();

                if (resultDia == DialogResult.OK)
                {
                    if (frmSearch.AddNewRecord)
                    {
                        ucAddress1.Enabled = true;
                        ucAddress1.ClearControls();
                        m_AddNewRelatedParty = true;
                        
                        txtSearchKey.Focus();
                    }
                    else
                    {
                        m_AddNewRelatedParty = false;
                        Row selectedRow = frmSearch.SelectedRow;
                        ClientNo = Convert.ToInt32(selectedRow[CEntityMaster.CLIENTNO]);
                    }
                }
                else
                {
                    // ucAddress1.Enabled = true;
                    ResetControls(true);
                    ucAddress1.ClearControls();
                   
                   // m_AddNewRelatedParty = true;

                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
            }
            return ClientNo;
        }


        /// <summary>
        /// Get Entity Details by ClientNo
        /// </summary>
        /// <param name="ClientNo"></param>
        /// <returns></returns>
        private EntityDetails GetEntityDetails(int ClientNo)
        {
            EntityDetails entityDetails = null;
            try
            {
                DataTable EntityResultDt = null;
                DataTable EntityAddrResultDt = null;


                MethodExecResult l_objMethodExceResult = CEntityMaster.GetEntitybyClientNo(ClientNo, ref EntityResultDt, ref EntityAddrResultDt);

                if (l_objMethodExceResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
                {
                    Logger.Instance.WriteLog(this, l_objMethodExceResult);
                    MessageBox.Show(l_objMethodExceResult.ErrorMessage, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                entityDetails = CEntityMaster.GetEntityDetailsByDataRow(EntityResultDt.Rows[0], EntityAddrResultDt.Rows[0]);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
            }
            return entityDetails;
        }


        /// <summary>
        /// Bind All DropDown List
        /// </summary>
        protected override void PopulateLookup()
        {
            DataTable l_dtCurrentRefData = null;
            DataRow[] dr = null;

            try
            {
                if (m_HasAllDropDownListBind)
                    return;

                cboRelationShip.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                cboRelationShip.AutoCompleteSource = AutoCompleteSource.ListItems;

                if (EntityType == CCMConstants.NON_INDIVIDUAL)
                    dr = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.RELATION].Select("s_ReferenceSubType = 'NONIND' OR s_ReferenceSubType = 'BOTH'");
                else
                    dr = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.RELATION].Select("s_ReferenceSubType = 'IND' OR s_ReferenceSubType = 'BOTH'");

                l_dtCurrentRefData = new DataTable();
                l_dtCurrentRefData.Columns.Add("n_ReferenceNo");
                l_dtCurrentRefData.Columns.Add("s_ReferenceType");
                l_dtCurrentRefData.Columns.Add("s_ReferenceCode");
                l_dtCurrentRefData.Columns.Add("s_ReferenceName");
                l_dtCurrentRefData.Columns.Add("s_ReferenceSubType");

                for (int iCnt = 0; iCnt <= dr.Length - 1; iCnt++)
                    l_dtCurrentRefData.ImportRow(dr[iCnt]);

                l_dtCurrentRefData.WithFirstBlank();
                cboRelationShip.ValueMember = "s_ReferenceCode";
                cboRelationShip.DisplayMember = "s_ReferenceName";
                cboRelationShip.DataSource = l_dtCurrentRefData;// CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.RELATION];


                cboIdentityType.ValueMember = "s_ReferenceCode";
                cboIdentityType.DisplayMember = "s_ReferenceName";
                cboIdentityType.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.PROOFTYPE];

                m_HasAllDropDownListBind = true;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
            }
        }


        /// <summary>
        /// Bind all Controls(Grid etc.)
        /// </summary>
        public override void PopulateControls()
        {
            try
            {

                if (EntityType == CCMConstants.NON_INDIVIDUAL)
                {
                    ftlblDOB.Text = "DOI";
                }
                else
                {
                    ftlblDOB.Text = "DOB";
                }



                DataTable dtResult = null;
                CEntityMaster.GetAuthSignDetails(m_EntityDetailsInstance.ClientNo, ref dtResult, ref m_AddressDataTable);
                authDetails.dtResult = dtResult;

                PopulateLookup();
                ResetControls();
                ucAddress1.ClearControls();


                DataRow[] dr = dtResult.Select("d_LastModifiedDateTime=Max(d_LastModifiedDateTime)");

                GridBind(dtResult);
                //txtDIN.BackColor = ctrlBackColor;
                //cboIdentityType.BackColor = ctrlBackColor;
                //txtSearchKey.BackColor = ctrlBackColor;
                //cboRelationShip.BackColor = ctrlBackColor;

                if (dtResult.Rows.Count > 0)
                    authDetails.dLastUpdatedDate = Convert.ToDateTime(dr[0]["d_LastModifiedDateTime"]);
                else
                    authDetails.dLastUpdatedDate = null;

                cboIdentityType.SelectedIndex = -1;
                cboRelationShip.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
            }
      }

        /// <summary>
        /// AuthSign/Related Party Details object
        /// </summary>
        public AuthSignDetails EntityAuthSignDetails
        {
            get { return authDetails; }
        }

        //public override EventHandler OnAddIndividual
        //{
        //    set { this.btnShowIndPopUp.Click += value; }
        //}


        /// <summary>
        /// Bind Grid 
        /// </summary>
        /// <param name="dt">Source DataTable</param>
        private void GridBind(DataTable dt)
        {
            try
            {
                dgvAuthSign.DataSource = dt;


                foreach (Column col1 in dgvAuthSign.Cols)
                    col1.Visible = false;
                

                dgvAuthSign.Cols["s_CustId"].Caption = "Customer ID";
                dgvAuthSign.Cols["s_ClientName"].Caption = "Name";
                dgvAuthSign.Cols["s_Details"].Caption = "ID";
                dgvAuthSign.Cols["n_RelationshipNo"].Caption = "Relationship";
                dgvAuthSign.Cols["n_Type"].Caption = "ID Type";

                dgvAuthSign.Cols["s_CustId"].Visible = true;
                dgvAuthSign.Cols["s_ClientName"].Visible = true;
                dgvAuthSign.Cols["s_Details"].Visible = true;
                dgvAuthSign.Cols["n_RelationshipNo"].Visible = true;
                dgvAuthSign.Cols["n_Type"].Visible = true;

                int width = 150;

                dgvAuthSign.Cols["s_CustId"].Width = width;
                dgvAuthSign.Cols["s_ClientName"].Width = width;
                dgvAuthSign.Cols["s_Details"].Width = width;
                dgvAuthSign.Cols["n_RelationshipNo"].Width = width;

                dgvAuthSign.Cols["n_RelationshipNo"].DataMap = CReferenceDataProvider.Instance.GetHashTable(CReferenceDataProvider.ReferenceType.RELATION,
                   CReferenceDataProvider.ReferenceFields.ReferenceName, CReferenceDataProvider.ReferenceFields.ReferenceCode);

                dgvAuthSign.Cols["n_Type"].DataMap = CReferenceDataProvider.Instance.GetHashTable(CReferenceDataProvider.ReferenceType.PROOFTYPE,
                        CReferenceDataProvider.ReferenceFields.ReferenceName, CReferenceDataProvider.ReferenceFields.ReferenceCode);

                if (dt.Rows.Count == 0)
                {
                    ResetControls();
                    ucAddress1.ClearControls();
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
            }

        }


        /// <summary>
        /// On Click of Auth Sign Row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvAuthSign_Click(object sender, EventArgs e)
        {
            PopulateControlOnRowClick(true);
        }


        /// <summary>
        /// Bind Controls on Click Event
        /// </summary>
        /// <param name="RefreshAddress"></param>
        private void PopulateControlOnRowClick(bool RefreshAddress = false)
        {
            try
            {
                ucAddress1.ClearControls();
                if (dgvAuthSign.Rows.Selected.Count == 0) return;

                Row l_objRow = dgvAuthSign.Rows.Selected[0];

                if (l_objRow == null) return;

                m_ClientNoIndividual = Convert.ToInt32(l_objRow["n_RelatedEntityNo"].ToString());
                m_RelatedPartyNo = Convert.ToInt32(l_objRow["n_RelatedPartyNo"].ToString());
                m_CurrentRowNo = Convert.ToInt32(l_objRow["n_RowNo"].ToString());

                ucAddress1.Enabled = m_ClientNoIndividual == 0;

                txtDIN.Text = l_objRow["s_Details"].ToString();
                txtSearchKey.Text = l_objRow["s_ClientName"].ToString();
                if(l_objRow["DOB"].ToString()!="")
                    dtDOB.Value = Convert.ToDateTime(l_objRow["DOB"].ToString()).Date;
                else
                    dtDOB.Value = System.DateTime.Now.Date;

                if (l_objRow["POADate"].ToString() != "")
                    dtPOA.Value = Convert.ToDateTime(l_objRow["POADate"].ToString()).Date;
                else
                    dtPOA.Value = System.DateTime.Now.Date;

                txtOtherRelation.Text = l_objRow["s_OtherRelation"].ToString();

                cboRelationShip.SetSelectedValue(l_objRow["n_RelationshipNo"].ToString());
                cboIdentityType.SetSelectedValue(l_objRow["n_Type"].ToString());
                chkAuthsign.Checked = l_objRow["sAuthSign"].ToString() == "Y";
                EntityDetails details = m_IndividualEntityDetailList.Find(item => item.ClientNo == m_ClientNoIndividual);

                DataRow[] addressRow = null;

                if (details != null)
                {
                    ucAddress1.PopupateControls(details.CorrespondenceAddress);
                }
                else if (m_ClientNoIndividual > 0 && m_AddressDataTable != null)
                {
                    addressRow = m_AddressDataTable.Select("n_ClientNo = " + m_ClientNoIndividual);
                }
                else if (authDetails.dtAddress != null && RefreshAddress)
                {
                    if (m_RelatedPartyNo > 0)
                        addressRow = authDetails.dtAddress.Select("n_ClientNo = " + m_RelatedPartyNo);
                    else
                        addressRow = authDetails.dtAddress.Select("n_RowNo = " + m_CurrentRowNo);

                    if (addressRow.Length == 0)
                        addressRow = m_AddressDataTable.Select("n_ClientNo = " + m_RelatedPartyNo);

                }
                else if (m_RelatedPartyNo > 0 && m_AddressDataTable != null)
                {
                    addressRow = m_AddressDataTable.Select("n_ClientNo = " + m_RelatedPartyNo);
                }

                if (addressRow != null && addressRow.Length > 0)
                {
                    Address address = new Address();
                    address.SetFromDataRow(addressRow[0]);
                    ucAddress1.PopupateControls(address);
                }
                else if (m_ClientNoIndividual == 0)
                {
                    ucAddress1.ClearControls();
                }


                btnAdd.Text = "Modify";
                m_AddNew = false;
                m_FormMode = FormModeEnum.UPDATE;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
            }
        }

        /// <summary>
        /// Add button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAdd_Click(object sender, EventArgs e)
         {
            try
            {
                if (IsAddValid())
                {
                    if (m_AddNewRelatedParty)
                    {
                        m_ClientNoIndividual = 0;
                    }

                    EntityDetails ed =
                       m_IndividualEntityDetailList.
                                        Find(item => item.ClientNo == m_ClientNoIndividual);

                    SyncDataTable(ed);
                    ucAddress1.ClearControls();
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
            }
        }

        
    /// <summary>
    /// Apply changes to AuthSign/Related Party DataTable
    /// </summary>
    private void SyncDataTable(EntityDetails detail)
        {
            try
            {
                int RowNo = m_CurrentRowNo;

                if (m_AddNewRelatedParty)
                {
                    ++m_RowNo;
                    RowNo = m_RowNo;
                }

                //if (detail == null)
                //{
                //    MessageBox.Show("Please map an individul entity."
                //                         , sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                //    return;
                //}

                authDetails.IndividualEntityNo = m_ClientNoIndividual;
                authDetails.NonIndividualEntityNo = EntityAccountInstance.ClientNo;
                authDetails.RelatedPartyNo = m_RelatedPartyNo;
                authDetails.DIN = txtDIN.Text.Trim();
                authDetails.RelationshipNo = Convert.ToInt32(cboRelationShip.GetSelectedValue());
                authDetails.IDType = cboIdentityType.GetSelectedValue();
                authDetails.IndividualName = txtSearchKey.Text.Trim();
                DataRow[] dr = authDetails.dtResult.Select("n_RelationshipNo = 98 OR n_RelationshipNo = 99");

                if (btnAdd.Text == "Add" && (authDetails.RelationshipNo == 98 || authDetails.RelationshipNo == 99))
                {  
                    if (dr.Length > 0)
                    {
                        MessageBox.Show("Can not add multiple " + cboRelationShip.SelectedText.ToString(), sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                else if (dr.Length > 1 && (authDetails.RelationshipNo == 98 || authDetails.RelationshipNo == 99))
                {
                    if (Convert.ToInt32(dr[0]["n_RelatedEntityNo"].ToString()) != authDetails.IndividualEntityNo)
                    {
                        MessageBox.Show("Can not add multiple " + cboRelationShip.SelectedText.ToString(), sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                if (m_AddNew == true && m_AddNewRelatedParty == false)
                {
                    if (detail == null)
                    {
                        MessageBox.Show("Please map an individul entity."
                                             , sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    authDetails.IndividualName = detail.Applicant_Name;
                    authDetails.CustID = detail.CustomerID;
                }

                if (m_AddNew == false && m_AddNewRelatedParty == false)
                {
                    Row l_objRow = dgvAuthSign.Rows.Selected[0];
                    authDetails.IndividualName = l_objRow["s_ClientName"].ToString();
                    authDetails.CustID = l_objRow["s_CustId"].ToString();

                }
                authDetails.dDOB = dtDOB.Value.ToString();
                if(cboRelationShip.SelectedValue.ToString() == "96")
                        authDetails.POADate = dtPOA.Value;

                if (cboRelationShip.SelectedValue.ToString() == "100")
                    authDetails.sOtherRelation = txtOtherRelation.Text;

                authDetails.AuthSign = chkAuthsign.Checked == true ? "Y" : "N";

                authDetails.SetDataResult(RowNo);

                //Add new Related party
                if (m_ClientNoIndividual == 0)
                {
                    Address addr = ucAddress1.GetAddress();
                    if (!string.IsNullOrEmpty(addr.Address_Line1))
                        authDetails.SetEntityAddress(addr, m_RelatedPartyNo, RowNo);
                }

                GridBind(authDetails.dtResult);

                btnAdd.Text = "Add";

                m_AddNewRelatedParty = false;
                m_AddNew = false;
                m_ClientNoIndividual = 0;

                ResetControls();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
                MessageBox.Show(ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Delete record from the grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (m_FormMode == FormModeEnum.INSERT)
            {
                ResetControls();
                ucAddress1.ClearControls();
                return;
            }

            try
            {
                if (cboRelationShip.SelectedIndex >= 0)
                {
                    if (MessageBox.Show("Do you want to delete party<" + txtSearchKey.Text + ">?", sClientHeaderName, MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        DataRow[] dr = authDetails.dtResult.Select("n_RelatedPartyNo = " + m_RelatedPartyNo);

                        if (dr.Length > 0)
                        {
                            authDetails.dtResult.Rows.Remove(dr[0]);
                            GridBind(authDetails.dtResult);
                            btnAdd.Text = "Add";
                            txtDIN.Text = string.Empty;
                            authDetails.DIN = txtDIN.Text.Trim();
                            cboRelationShip.SelectedIndex = -1;
                            cboIdentityType.SelectedIndex = -1;

                            txtSearchKey.Text = string.Empty;
                            txtOtherRelation.Text = "";
                            authDetails.Deleted = true;

                        }
                    }
                }
                else
                {
                    btnAdd.Text = "Add";
                    txtDIN.Text = string.Empty;
                    authDetails.DIN = txtDIN.Text.Trim();
                    cboRelationShip.SelectedIndex = -1;
                    cboIdentityType.SelectedIndex = -1;
                    txtSearchKey.Text = string.Empty;
                    txtOtherRelation.Text = "";
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
            }
        }


        /// <summary>
        /// Reset Form Controls
        /// </summary>
        /// <param name="ResetNameTextBox"></param>
        private void ResetControls(bool ResetNameTextBox = true)
        {
            txtDIN.Text = string.Empty;
            authDetails.DIN = txtDIN.Text.Trim();
            cboRelationShip.SelectedIndex = -1;
            cboIdentityType.SelectedIndex = -1;
            txtOtherRelation.Text = "";
            chkAuthsign.Checked = false;
            if(ResetNameTextBox)
                txtSearchKey.Text = string.Empty;
        }


        /// <summary>
        /// Validate the fields 
        /// </summary>
        /// <returns></returns>
        private bool IsAddValid()
        {

            if (string.IsNullOrEmpty(txtSearchKey.Text.Trim()))
            {
                MessageBox.Show("Please enter related party name.", sClientHeaderName, MessageBoxButtons.OK);
                txtSearchKey.Focus();
                return false;
            }
            if (cboRelationShip.SelectedItem == null ||cboRelationShip.SelectedIndex==0 )
            { 
                MessageBox.Show("Please select Relationship.", sClientHeaderName, MessageBoxButtons.OK);
                cboRelationShip.Focus();
                return false;
            }
            if (cboIdentityType.SelectedItem == null)
            {
                MessageBox.Show("Please select ID Type.", sClientHeaderName, MessageBoxButtons.OK);
                cboIdentityType.Focus();
                return false;
            }

            if (string.IsNullOrEmpty(txtDIN.Text.Trim()))
            {
                MessageBox.Show("Please enter ID Details.", sClientHeaderName, MessageBoxButtons.OK);
                txtDIN.Focus();
                return false;
            }
            if (Convert.ToInt32(cboIdentityType.GetSelectedValue()) == 8)
            {
                if (txtDIN.Text.Length != 0)
                {

                    if (!System.Text.RegularExpressions.Regex.IsMatch(txtDIN.Text.Trim(), @"^[a-zA-Z]{5}\d{4}[a-zA-Z]{1}$"))
                    {
                        MessageBox.Show("PAN No. should be 10 digit alphanumeric with combination of 5 alpha, next 4 numeric and last one an alpha.", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtDIN.Focus();
                        return false;
                    }
                   
                }
            }
                
     
            return true;  
        }

        /// <summary>
        /// On Name Text box leave (Will trigger if TAB Pressed)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtSearchKey_Leave(object sender, EventArgs e)
        {
            //if (btnDelete.Focused || btnAdd.Focused)
            //{
            //    if (txtSearchKey.Text.Length <= 2)
            //        txtSearchKey.Text = null;
            //    return;
            //}
            if (m_AddNewRelatedParty == false)
                Help(false);
        }

       
        /// <summary>
        /// Advance Search Link
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lnkAdvanceSearch_Click(object sender, EventArgs e)
        {
            Help(true);
        }


        public override bool CheckChanges()
        {
            if (this.IsGridUpdated == true) return true;
            try
            {
                if (authDetails.dtResult.Rows.Count == 0) return false;

                DataRow[] dr = authDetails.dtResult.Select("s_HasChanged = 'Y'");
                if (dr.Length > 0)
                {
                    return true;
                }
                else
                    return false;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityOthers), ex.Message);
                return false;
            }
        }

        public override void ResetDt()
        {
            DataTable dtResult = new DataTable();
            //CEntityMaster.GetEntityBankDetails(m_EntityDetailsInstance.ClientNo, ref dtResult);
            //authDetails.dtResult = dtResult;

            dtResult = authDetails.dtResult;
            for (int iCnt = 0; iCnt <= dtResult.Rows.Count - 1; iCnt++)
            {
                dtResult.Rows[iCnt]["s_HasChanged"] = "N";

            }
        }

        private void cboRelationShip_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sSelVal = "";
            if (cboRelationShip.SelectedValue!=null)
                sSelVal = cboRelationShip.SelectedValue.ToString();

            if (sSelVal == "96")
            {
                txtOtherRelation.Visible = false;
                lblPOAId.Visible = true;
                dtPOA.Visible = true;
                cboIdentityType.SetSelectedValue("12");
                lblPOAId.Text = "POA Date";
            }
            else if (sSelVal == "100")
            {
                
                lblPOAId.Text = "Others";
                lblPOAId.Visible = true;
                dtPOA.Visible = false;
                txtOtherRelation.Visible = true;
            }
            else
            {
                txtOtherRelation.Visible = false;
                lblPOAId.Visible = false;
                dtPOA.Visible = false;
                cboIdentityType.SelectedIndex = -1;
            }

            ////if (sSelVal == "96")
            ////{
            ////    lblAuthSign.Text = "POA Type";
            ////    lblPOAId.Text = "POA ID";
            ////    lblAuthSign.Visible = false;
            ////    lblPOAId.Visible = true;
            ////    txtPOAId.Visible = true;
            ////    cboAuthType.Visible = false;
            ////    //cboAuthType.Items.Clear();
            ////    //cboAuthType.Items.Add("Corporate");
            ////    //cboAuthType.Items.Add("Individual");
            ////    chkAuthsign.Visible = false;
            ////}
            ////else if (sSelVal == "95")
            ////{
            ////    lblAuthSign.Text = "Is Authorized signatory";
            ////    lblPOAId.Text = "Holder Type";
            ////    lblPOAId.Visible = true;
            ////    lblAuthSign.Visible = true;
            ////    cboAuthType.Visible = true;
            ////    chkAuthsign.Visible = true;
            ////    txtPOAId.Visible = false;
            ////    cboAuthType.Items.Clear();
            ////    cboAuthType.Items.Add("Second");
            ////    cboAuthType.Items.Add("Third");
            ////}
            ////else
            ////{
            ////    lblAuthSign.Text = "Is Authorized signatory";
            ////    lblPOAId.Text = "Holder Type";
            ////    cboAuthType.Items.Clear();
            ////    cboAuthType.Items.Add("Second");
            ////    cboAuthType.Items.Add("Third");

            ////    cboAuthType.Visible = true;
            ////    lblAuthSign.Visible = true;
            ////    lblPOAId.Visible = true;
            ////    txtPOAId.Visible = false;
            ////    chkAuthsign.Visible = true;
            ////}
        }

        /// <summary>
        /// Advance Search Button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAdvanceSearch_Click(object sender, EventArgs e)
        {
            Help(true);
            txtSearchKey.Focus();
        }
    }
}
