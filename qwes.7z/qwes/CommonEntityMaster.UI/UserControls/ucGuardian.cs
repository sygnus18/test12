﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.CDD.BAL;
using UCC.Class;
using UCC;
using FTIL.Match.CDD.UI.Forms;
using FTIL.Match.Common.Log;

namespace FTIL.Match.CDD.UI.UserControls
{
    /// <summary>
    /// to show details of guardian tab 
    /// </summary>
   
    public partial class ucGuardian : FTIL.Match.CDD.UI.UserControls.ucBaseEntity
    {
        private CEntityMaster m_CEntityMaster;
        ucAddress objGCorrespondenceAddress;
        ucAddress objGPermanetnAddress;
        public int ClientId { get; set; }
        public ucGuardian()
        {
            InitializeComponent();
            objGCorrespondenceAddress = new ucAddress();
            objGPermanetnAddress = new ucAddress();
            m_EntityDetailsInstance = new EntityDetails();
            ModifyMode = false;
        }

        /// <summary>
        /// cotrol page load for guardian tab
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ucGuardian_Load(object sender, EventArgs e)
        {
            try
            {
                objGCorrespondenceAddress.Dock = DockStyle.Fill;
                pnlCorrespondenceAdd.Controls.Add(objGCorrespondenceAddress);
                pnlCorrespondenceAdd.Tag = objGCorrespondenceAddress;

                objGPermanetnAddress.Dock = DockStyle.Fill;
                pnlParmanentAdd.Controls.Add(objGPermanetnAddress);
                pnlParmanentAdd.Tag = objGPermanetnAddress;

                PopulateLookup();
                PopulateControls();

                cboNationality_SelectedIndexChanged(this, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucGuardian), ex.Message);
            }
        }

        /// <summary>
        /// fill guardian data in edit mode
        /// </summary>
        public override void PopulateControls()
        {
            if (ModifyMode == false) return;
            try
            {
                if (m_EntityDetailsInstance == null) return;

                if (FormUtil.IsValidDate(m_EntityDetailsInstance.DOB_OR_DOI))
                    dtDOB.Value = m_EntityDetailsInstance.DOB_OR_DOI.Value;

                cboGender.SetSelectedValue(m_EntityDetailsInstance.Gender);
                //cboMaritalStatus.SetSelectedValue(m_EntityDetailsInstance.Marital_status);
                cboNationality.SetSelectedValue(m_EntityDetailsInstance.Nationality);

                m_EntityDetailsInstance.ClientNo = ClientId;
                //if (FormUtil.IsValidDate(m_EntityDetailsInstance.DateOfCreation))
                    //dtCreated.Value = m_EntityDetailsInstance.DateOfCreation.Value;
                txtGuardianName.Text = m_EntityDetailsInstance.Applicant_Name;
                txtFather_SpouseName.Text = m_EntityDetailsInstance.Father_sHusbands_Name;

                chkSameAsCorrs.Checked = m_EntityDetailsInstance.SameCorrPermAdd == "Y";

                if (!string.IsNullOrEmpty(m_EntityDetailsInstance.NationalityOther))
                {
                    txtNationalityName.Enabled = true;
                    txtNationalityName.Text = m_EntityDetailsInstance.NationalityOther;
                }

                objGCorrespondenceAddress.PopupateControls(m_EntityDetailsInstance.CorrespondenceAddress);

                if (!chkSameAsCorrs.Checked)
                    objGPermanetnAddress.PopupateControls(m_EntityDetailsInstance.PermanentAddress);
                else
                    objGPermanetnAddress.PopupateControls(m_EntityDetailsInstance.CorrespondenceAddress);

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucGuardian), ex.Message);
            }
        }

        /// <summary>
        /// get valid date for save guardian details
        /// </summary>
        /// <returns></returns>
        public override EntityDetails GetEntityDetails()
        {
            if (m_EntityDetailsInstance == null) return m_EntityDetailsInstance;

            try
            {
                if (isValid())
                {
                    HasUpdated = false;

                    if (HasUpdated == false)
                        HasUpdated = m_EntityDetailsInstance.DOB_OR_DOI != dtDOB.Value;
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.Gender, cboGender.GetSelectedValue());
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.Guardian_Name, txtGuardianName.Text);
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.Nationality, cboNationality.GetSelectedValue());
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.Father_sHusbands_Name, txtFather_SpouseName.Text);
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.NationalityOther, txtNationalityName.Text);

                    m_EntityDetailsInstance.ClientNo = ClientId;
                    m_EntityDetailsInstance.DOB_OR_DOI = dtDOB.Value;
                    m_EntityDetailsInstance.Gender = cboGender.GetSelectedValue();
                    m_EntityDetailsInstance.Marital_status = "";
                    m_EntityDetailsInstance.Nationality = cboNationality.GetSelectedValue();
                    m_EntityDetailsInstance.Guardian_Name = txtGuardianName.Text;
                    m_EntityDetailsInstance.Date_of_Declaration = System.DateTime.Now.Date;
                    m_EntityDetailsInstance.Father_sHusbands_Name = txtFather_SpouseName.Text;
                    m_EntityDetailsInstance.SameCorrPermAdd = chkSameAsCorrs.Checked == true ? "Y" : "N";

                    m_EntityDetailsInstance.CorrespondenceAddress = objGCorrespondenceAddress.GetAddress();


                    if (!chkSameAsCorrs.Checked)
                        m_EntityDetailsInstance.PermanentAddress = objGPermanetnAddress.GetAddress();
                    m_EntityDetailsInstance.NationalityOther = txtNationalityName.Text;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucGuardian), ex.Message);
            }
            return m_EntityDetailsInstance;

        }

        /// <summary>
        /// bind data controls
        /// </summary>
        protected override void PopulateLookup()
        {
            try
            {
                cboGender.ValueMember = "s_ReferenceCode";
                cboGender.DisplayMember = "s_ReferenceName";
                cboGender.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.GENDER]; //l_dsPopulateClientDetails.Tables[2];

                cboNationality.ValueMember = "s_ReferenceCode";
                cboNationality.DisplayMember = "s_ReferenceName";
                cboNationality.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.NATIONALTY]; //l_dsPopulateClientDetails.Tables[1];

                cboNationality_SelectedIndexChanged(this, EventArgs.Empty);
                cboGender.SelectedValue = string.Empty;
                //cboMaritalStatus.SelectedValue = string.Empty;
                cboNationality.SelectedValue = string.Empty;

                dtDOB.MaxDate = System.DateTime.Today.Date;
                txtFather_SpouseName.BackColor = ctrlBackColor;
                txtGuardianName.BackColor = ctrlBackColor;
                cboGender.BackColor = ctrlBackColor;
                cboNationality.BackColor = ctrlBackColor;
                dtDOB.BackColor = ctrlBackColor;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucGuardian), ex.Message);
            }
        }

        /// <summary>
        /// method fired nationality combo chenge
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cboNationality_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
            if (
                (cboNationality.SelectedValue != null)
                &&
                (cboNationality.SelectedValue.ToString() == CUCCConstants.Instance.OTHER_NATIONALITY_CODE) && (m_EntityDetailsInstance!=null) //Other
               )
            {
                if (!string.IsNullOrEmpty(m_EntityDetailsInstance.NationalityOther))
                    txtNationalityName.Text = m_EntityDetailsInstance.NationalityOther;
                else txtNationalityName.Text = string.Empty;

                txtNationalityName.Enabled = true;
                txtNationalityName.Focus();
            }
            else
            {
                txtNationalityName.Enabled = false;
                txtNationalityName.Text = string.Empty;
            }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucGuardian), ex.Message);
            }
        }

        /// <summary>
        /// check for madatory field validation 
        /// </summary>
        /// <returns></returns>
        protected override bool isValid()
        {
            string Msg = "";
            string FieldMsg = "";
            m_EntityDetailsInstance.IsValid = true;
            FieldMsg += m_EntityDetailsInstance.ValidateField(sName, "", " Name,", ref Msg);
            FieldMsg += m_EntityDetailsInstance.ValidateField(txtGuardianName.Text, "", " Guardian Name,", ref Msg);
            FieldMsg += m_EntityDetailsInstance.ValidateField(dtDOB.Text, System.DateTime.Today.Date.ToString("dd/MM/yyyy"), " DOB,", ref Msg);
            FieldMsg += m_EntityDetailsInstance.ValidateField(cboGender.SelectedIndex.ToString(), "-1", " Gender,", ref Msg);
            //FieldMsg += m_EntityDetailsInstance.ValidateField(cboMaritalStatus.SelectedIndex.ToString(), "-1", " Marital Status,", ref Msg);
            FieldMsg += m_EntityDetailsInstance.ValidateField(cboNationality.SelectedIndex.ToString(), "-1", " Nationality,", ref Msg);
            FieldMsg += m_EntityDetailsInstance.ValidateField(txtFather_SpouseName.Text, "", " Father/Spouse Name ", ref Msg);
            if (FieldMsg != "")
            {
                FieldMsg = FieldMsg.Remove(FieldMsg.Length - 1);
                m_EntityDetailsInstance.IsValid = false;
                MessageBox.Show(FieldMsg + Msg, "", MessageBoxButtons.OK);
            }
            return FieldMsg == "";


        }

        private void chkSameAsCorrs_CheckedChanged(object sender, EventArgs e)
        {
            objGPermanetnAddress.Enabled = !chkSameAsCorrs.Checked;
        }

        /// <summary>
        /// Corrospondance Address updated 
        /// </summary>
        public override bool CorrAddressUpdated { get { return objGCorrespondenceAddress.HasUpdated; } }


        /// <summary>
        /// Permanent address updated
        /// </summary>
        public override bool PerAddressUpdated { get { return objGPermanetnAddress.HasUpdated; } }

        /// <summary>
        /// delete active guardian infomation  
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            int iResult;
            if (MessageBox.Show("Do you want to delete Guardian <" + txtGuardianName.Text + ">?", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    m_CEntityMaster = new CEntityMaster();
                    iResult = m_CEntityMaster.RemoveGuardianDetails(ClientId);
                    if (iResult == 1)
                    {
                        MessageBox.Show(txtGuardianName.Text + " deleted successfully.", "", MessageBoxButtons.OK);
                    
                        dtDOB.Value = System.DateTime.Now.Date;
                    
                        cboGender.SelectedIndex=-1;
                        cboNationality.SelectedIndex=-1;
               
                        txtGuardianName.Text ="";
                        txtFather_SpouseName.Text = "";

                        chkSameAsCorrs.Checked = false;
                        txtNationalityName.Text ="";
                        txtNationalityName.Enabled = true;
                        objGCorrespondenceAddress.ClearControls();
                        objGPermanetnAddress.ClearControls();
                    }
                }
                catch (Exception ex)
                {
                    Logger.Instance.WriteLog(typeof(ucGuardian), ex.Message);
                }
            }
        } 
    }
}
