﻿namespace FTIL.Match.CDD.UI.UserControls
{
    partial class ucEntityAuthSign
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucEntityAuthSign));
            this.ttForTxtSearch = new System.Windows.Forms.ToolTip(this.components);
            this.txtOtherRelation = new MatchCommon.CustomControls.FTTextBox();
            this.txtSearchKey = new MatchCommon.CustomControls.FTTextBox();
            this.dtPOA = new System.Windows.Forms.DateTimePicker();
            this.chkAuthsign = new MatchCommon.CustomControls.FTCheckBox();
            this.lblPOAId = new MatchCommon.CustomControls.FTLabel();
            this.lblAuthSign = new MatchCommon.CustomControls.FTLabel();
            this.dtDOB = new System.Windows.Forms.DateTimePicker();
            this.ftlblDOB = new MatchCommon.CustomControls.FTLabel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.pnlCorrespondenceAdd = new System.Windows.Forms.Panel();
            this.ucAddress1 = new FTIL.Match.CDD.UI.UserControls.ucAddress();
            this.lnkAdvanceSearch = new System.Windows.Forms.LinkLabel();
            this.ftLabel47 = new MatchCommon.CustomControls.FTLabel();
            this.cboIdentityType = new MatchCommon.CustomControls.FTComboBox();
            this.btnDelete = new MatchCommon.CustomControls.FTButton();
            this.btnAdd = new MatchCommon.CustomControls.FTButton();
            this.ftLabel63 = new MatchCommon.CustomControls.FTLabel();
            this.cboRelationShip = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel1 = new MatchCommon.CustomControls.FTLabel();
            this.txtDIN = new MatchCommon.CustomControls.FTTextBox();
            this.dgvAuthSign = new MatchCommon.CustomControls.FTDataGrid();
            this.ftLabel74 = new MatchCommon.CustomControls.FTLabel();
            this.btnAdvanceSearch = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.pnlCorrespondenceAdd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAuthSign)).BeginInit();
            this.SuspendLayout();
            // 
            // txtOtherRelation
            // 
            this.txtOtherRelation.AllowAlpha = true;
            this.txtOtherRelation.AllowDot = true;
            this.txtOtherRelation.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtOtherRelation.AllowedCustomCharacters")));
            this.txtOtherRelation.AllowNonASCII = false;
            this.txtOtherRelation.AllowNumeric = true;
            this.txtOtherRelation.AllowSpace = true;
            this.txtOtherRelation.AllowSpecialChars = true;
            this.txtOtherRelation.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtOtherRelation.FocusColor = System.Drawing.Color.LightYellow;
            this.txtOtherRelation.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtOtherRelation.ForeColor = System.Drawing.Color.Black;
            this.txtOtherRelation.IsEmailID = false;
            this.txtOtherRelation.IsEmailIdValid = false;
            this.txtOtherRelation.Location = new System.Drawing.Point(377, 271);
            this.txtOtherRelation.MaxLength = 50;
            this.txtOtherRelation.Name = "txtOtherRelation";
            this.txtOtherRelation.Size = new System.Drawing.Size(134, 20);
            this.txtOtherRelation.TabIndex = 8;
            this.ttForTxtSearch.SetToolTip(this.txtOtherRelation, "Provide minimum 3 characters, and press F3.");
            this.txtOtherRelation.Visible = false;
            // 
            // txtSearchKey
            // 
            this.txtSearchKey.AllowAlpha = true;
            this.txtSearchKey.AllowDot = true;
            this.txtSearchKey.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtSearchKey.AllowedCustomCharacters")));
            this.txtSearchKey.AllowNonASCII = false;
            this.txtSearchKey.AllowNumeric = true;
            this.txtSearchKey.AllowSpace = true;
            this.txtSearchKey.AllowSpecialChars = true;
            this.txtSearchKey.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtSearchKey.FocusColor = System.Drawing.Color.LightYellow;
            this.txtSearchKey.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtSearchKey.ForeColor = System.Drawing.Color.Black;
            this.txtSearchKey.IsEmailID = false;
            this.txtSearchKey.IsEmailIdValid = false;
            this.txtSearchKey.Location = new System.Drawing.Point(76, 218);
            this.txtSearchKey.MaxLength = 255;
            this.txtSearchKey.Name = "txtSearchKey";
            this.txtSearchKey.Size = new System.Drawing.Size(233, 20);
            this.txtSearchKey.TabIndex = 1;
            this.ttForTxtSearch.SetToolTip(this.txtSearchKey, "Provide minimum 3 characters, and press F3.");
            this.txtSearchKey.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtSearchKey_KeyUp);
            this.txtSearchKey.Leave += new System.EventHandler(this.txtSearchKey_Leave);
            // 
            // dtPOA
            // 
            this.dtPOA.CustomFormat = "dd/MM/yyyy";
            this.dtPOA.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtPOA.Location = new System.Drawing.Point(377, 271);
            this.dtPOA.Name = "dtPOA";
            this.dtPOA.Size = new System.Drawing.Size(92, 20);
            this.dtPOA.TabIndex = 110;
            this.dtPOA.Value = new System.DateTime(2015, 2, 25, 12, 2, 20, 0);
            // 
            // chkAuthsign
            // 
            this.chkAuthsign.AutoSize = true;
            this.chkAuthsign.Font = new System.Drawing.Font("Tahoma", 8F);
            this.chkAuthsign.ForeColor = System.Drawing.Color.Black;
            this.chkAuthsign.Location = new System.Drawing.Point(126, 273);
            this.chkAuthsign.Name = "chkAuthsign";
            this.chkAuthsign.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.chkAuthsign.Size = new System.Drawing.Size(15, 14);
            this.chkAuthsign.TabIndex = 7;
            this.chkAuthsign.UseVisualStyleBackColor = true;
            // 
            // lblPOAId
            // 
            this.lblPOAId.AllowForeColorChange = false;
            this.lblPOAId.AutoSize = true;
            this.lblPOAId.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblPOAId.ForeColor = System.Drawing.Color.Black;
            this.lblPOAId.Location = new System.Drawing.Point(320, 274);
            this.lblPOAId.Name = "lblPOAId";
            this.lblPOAId.OverrideDefault = false;
            this.lblPOAId.Size = new System.Drawing.Size(54, 13);
            this.lblPOAId.TabIndex = 108;
            this.lblPOAId.Text = "POA Date";
            this.lblPOAId.Visible = false;
            // 
            // lblAuthSign
            // 
            this.lblAuthSign.AllowForeColorChange = false;
            this.lblAuthSign.AutoSize = true;
            this.lblAuthSign.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblAuthSign.ForeColor = System.Drawing.Color.Black;
            this.lblAuthSign.Location = new System.Drawing.Point(8, 272);
            this.lblAuthSign.Name = "lblAuthSign";
            this.lblAuthSign.OverrideDefault = false;
            this.lblAuthSign.Size = new System.Drawing.Size(119, 13);
            this.lblAuthSign.TabIndex = 106;
            this.lblAuthSign.Text = "Is Authorized signatory";
            // 
            // dtDOB
            // 
            this.dtDOB.CustomFormat = "dd/MM/yyyy";
            this.dtDOB.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtDOB.Location = new System.Drawing.Point(552, 218);
            this.dtDOB.Name = "dtDOB";
            this.dtDOB.Size = new System.Drawing.Size(92, 20);
            this.dtDOB.TabIndex = 3;
            this.dtDOB.Value = new System.DateTime(2015, 2, 25, 12, 2, 20, 0);
            // 
            // ftlblDOB
            // 
            this.ftlblDOB.AllowForeColorChange = false;
            this.ftlblDOB.AutoSize = true;
            this.ftlblDOB.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftlblDOB.ForeColor = System.Drawing.Color.Black;
            this.ftlblDOB.Location = new System.Drawing.Point(524, 221);
            this.ftlblDOB.Name = "ftlblDOB";
            this.ftlblDOB.OverrideDefault = false;
            this.ftlblDOB.Size = new System.Drawing.Size(28, 13);
            this.ftlblDOB.TabIndex = 104;
            this.ftlblDOB.Text = "DOB";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.pnlCorrespondenceAdd);
            this.groupBox2.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox2.Location = new System.Drawing.Point(4, 295);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(760, 171);
            this.groupBox2.TabIndex = 102;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Temporary/Correspondence Address";
            // 
            // pnlCorrespondenceAdd
            // 
            this.pnlCorrespondenceAdd.Controls.Add(this.ucAddress1);
            this.pnlCorrespondenceAdd.Location = new System.Drawing.Point(3, 19);
            this.pnlCorrespondenceAdd.Name = "pnlCorrespondenceAdd";
            this.pnlCorrespondenceAdd.Size = new System.Drawing.Size(753, 146);
            this.pnlCorrespondenceAdd.TabIndex = 0;
            // 
            // ucAddress1
            // 
            this.ucAddress1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.ucAddress1.HasUpdated = false;
            this.ucAddress1.isMandatory = false;
            this.ucAddress1.Location = new System.Drawing.Point(0, -1);
            this.ucAddress1.Name = "ucAddress1";
            this.ucAddress1.Size = new System.Drawing.Size(753, 145);
            this.ucAddress1.TabIndex = 9;
            // 
            // lnkAdvanceSearch
            // 
            this.lnkAdvanceSearch.AutoSize = true;
            this.lnkAdvanceSearch.Location = new System.Drawing.Point(382, 222);
            this.lnkAdvanceSearch.Name = "lnkAdvanceSearch";
            this.lnkAdvanceSearch.Size = new System.Drawing.Size(87, 13);
            this.lnkAdvanceSearch.TabIndex = 2;
            this.lnkAdvanceSearch.TabStop = true;
            this.lnkAdvanceSearch.Text = "Advance Search";
            this.lnkAdvanceSearch.Visible = false;
            this.lnkAdvanceSearch.Click += new System.EventHandler(this.lnkAdvanceSearch_Click);
            // 
            // ftLabel47
            // 
            this.ftLabel47.AllowForeColorChange = false;
            this.ftLabel47.AutoSize = true;
            this.ftLabel47.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel47.ForeColor = System.Drawing.Color.Black;
            this.ftLabel47.Location = new System.Drawing.Point(320, 247);
            this.ftLabel47.Name = "ftLabel47";
            this.ftLabel47.OverrideDefault = false;
            this.ftLabel47.Size = new System.Drawing.Size(31, 13);
            this.ftLabel47.TabIndex = 100;
            this.ftLabel47.Text = "Type";
            // 
            // cboIdentityType
            // 
            this.cboIdentityType.BackColor = System.Drawing.Color.White;
            this.cboIdentityType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboIdentityType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboIdentityType.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboIdentityType.ForeColor = System.Drawing.Color.Black;
            this.cboIdentityType.FormattingEnabled = true;
            this.cboIdentityType.Location = new System.Drawing.Point(377, 243);
            this.cboIdentityType.Name = "cboIdentityType";
            this.cboIdentityType.ReadOnly = false;
            this.cboIdentityType.Size = new System.Drawing.Size(134, 21);
            this.cboIdentityType.TabIndex = 5;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Transparent;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.Location = new System.Drawing.Point(685, 468);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 25);
            this.btnDelete.TabIndex = 8;
            this.btnDelete.Text = "&Remove";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Transparent;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAdd.Location = new System.Drawing.Point(603, 468);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 25);
            this.btnAdd.TabIndex = 7;
            this.btnAdd.Text = "&Add";
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // ftLabel63
            // 
            this.ftLabel63.AllowForeColorChange = false;
            this.ftLabel63.AutoSize = true;
            this.ftLabel63.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel63.ForeColor = System.Drawing.Color.Black;
            this.ftLabel63.Location = new System.Drawing.Point(8, 248);
            this.ftLabel63.Name = "ftLabel63";
            this.ftLabel63.OverrideDefault = false;
            this.ftLabel63.Size = new System.Drawing.Size(65, 13);
            this.ftLabel63.TabIndex = 95;
            this.ftLabel63.Text = "Relationship";
            // 
            // cboRelationShip
            // 
            this.cboRelationShip.BackColor = System.Drawing.Color.White;
            this.cboRelationShip.DropDownWidth = 200;
            this.cboRelationShip.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboRelationShip.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboRelationShip.ForeColor = System.Drawing.Color.Black;
            this.cboRelationShip.FormattingEnabled = true;
            this.cboRelationShip.Location = new System.Drawing.Point(76, 244);
            this.cboRelationShip.Name = "cboRelationShip";
            this.cboRelationShip.ReadOnly = false;
            this.cboRelationShip.Size = new System.Drawing.Size(233, 21);
            this.cboRelationShip.TabIndex = 4;
            this.cboRelationShip.SelectedIndexChanged += new System.EventHandler(this.cboRelationShip_SelectedIndexChanged);
            // 
            // ftLabel1
            // 
            this.ftLabel1.AllowForeColorChange = false;
            this.ftLabel1.AutoSize = true;
            this.ftLabel1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel1.ForeColor = System.Drawing.Color.Black;
            this.ftLabel1.Location = new System.Drawing.Point(524, 247);
            this.ftLabel1.Name = "ftLabel1";
            this.ftLabel1.OverrideDefault = false;
            this.ftLabel1.Size = new System.Drawing.Size(18, 13);
            this.ftLabel1.TabIndex = 93;
            this.ftLabel1.Text = "ID";
            // 
            // txtDIN
            // 
            this.txtDIN.AllowAlpha = true;
            this.txtDIN.AllowDot = false;
            this.txtDIN.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtDIN.AllowedCustomCharacters")));
            this.txtDIN.AllowNonASCII = false;
            this.txtDIN.AllowNumeric = true;
            this.txtDIN.AllowSpace = false;
            this.txtDIN.AllowSpecialChars = false;
            this.txtDIN.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDIN.FocusColor = System.Drawing.Color.LightYellow;
            this.txtDIN.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtDIN.ForeColor = System.Drawing.Color.Black;
            this.txtDIN.IsEmailID = false;
            this.txtDIN.IsEmailIdValid = false;
            this.txtDIN.Location = new System.Drawing.Point(552, 244);
            this.txtDIN.MaxLength = 20;
            this.txtDIN.Name = "txtDIN";
            this.txtDIN.Size = new System.Drawing.Size(206, 20);
            this.txtDIN.TabIndex = 6;
            // 
            // dgvAuthSign
            // 
            this.dgvAuthSign.AllowEditing = false;
            this.dgvAuthSign.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
            this.dgvAuthSign.BackColor = System.Drawing.Color.White;
            this.dgvAuthSign.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.dgvAuthSign.ColumnInfo = "5,1,0,0,0,95,Columns:0{Width:30;}\t";
            this.dgvAuthSign.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
            this.dgvAuthSign.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dgvAuthSign.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.dgvAuthSign.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
            this.dgvAuthSign.Location = new System.Drawing.Point(0, 2);
            this.dgvAuthSign.Name = "dgIdentityDtls";
            this.dgvAuthSign.Styles.EmptyArea.BackColor = System.Drawing.Color.White;
            this.dgvAuthSign.OverrideDefault = false;
            this.dgvAuthSign.Rows.Count = 10;
            this.dgvAuthSign.Rows.DefaultSize = 19;
            this.dgvAuthSign.Rows.MinSize = 25;
            this.dgvAuthSign.RowsFilter.AddFilterRow = false;
            this.dgvAuthSign.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.ListBox;
            this.dgvAuthSign.Size = new System.Drawing.Size(770, 210);
            this.dgvAuthSign.StyleInfo = "";
            this.dgvAuthSign.TabIndex = 101;
            // 
            // ftLabel74
            // 
            this.ftLabel74.AllowForeColorChange = false;
            this.ftLabel74.AutoSize = true;
            this.ftLabel74.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel74.ForeColor = System.Drawing.Color.Black;
            this.ftLabel74.Location = new System.Drawing.Point(8, 222);
            this.ftLabel74.Name = "ftLabel74";
            this.ftLabel74.OverrideDefault = false;
            this.ftLabel74.Size = new System.Drawing.Size(34, 13);
            this.ftLabel74.TabIndex = 90;
            this.ftLabel74.Text = "Name";
            // 
            // btnAdvanceSearch
            // 
            this.btnAdvanceSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdvanceSearch.Image = ((System.Drawing.Image)(resources.GetObject("btnAdvanceSearch.Image")));
            this.btnAdvanceSearch.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnAdvanceSearch.Location = new System.Drawing.Point(312, 218);
            this.btnAdvanceSearch.Name = "btnAdvanceSearch";
            this.btnAdvanceSearch.Size = new System.Drawing.Size(67, 21);
            this.btnAdvanceSearch.TabIndex = 111;
            this.btnAdvanceSearch.Text = "Search";
            this.btnAdvanceSearch.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.btnAdvanceSearch.UseVisualStyleBackColor = true;
            this.btnAdvanceSearch.Click += new System.EventHandler(this.btnAdvanceSearch_Click);
            // 
            // ucEntityAuthSign
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.btnAdvanceSearch);
            this.Controls.Add(this.txtOtherRelation);
            this.Controls.Add(this.dtPOA);
            this.Controls.Add(this.chkAuthsign);
            this.Controls.Add(this.lblPOAId);
            this.Controls.Add(this.lblAuthSign);
            this.Controls.Add(this.dtDOB);
            this.Controls.Add(this.ftlblDOB);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.lnkAdvanceSearch);
            this.Controls.Add(this.ftLabel47);
            this.Controls.Add(this.cboIdentityType);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.ftLabel63);
            this.Controls.Add(this.cboRelationShip);
            this.Controls.Add(this.ftLabel1);
            this.Controls.Add(this.txtDIN);
            this.Controls.Add(this.dgvAuthSign);
            this.Controls.Add(this.ftLabel74);
            this.Controls.Add(this.txtSearchKey);
            this.Name = "ucEntityAuthSign";
            this.Size = new System.Drawing.Size(768, 510);
            this.Load += new System.EventHandler(this.ucEntityAuthSign_Load);
            this.groupBox2.ResumeLayout(false);
            this.pnlCorrespondenceAdd.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAuthSign)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MatchCommon.CustomControls.FTDataGrid dgvAuthSign;
        private ucAddress ucAddress1;
        private MatchCommon.CustomControls.FTLabel ftLabel74;
        private MatchCommon.CustomControls.FTLabel ftLabel1;
        private MatchCommon.CustomControls.FTTextBox txtDIN;
        private MatchCommon.CustomControls.FTLabel ftLabel63;
        private MatchCommon.CustomControls.FTComboBox cboRelationShip;
        private MatchCommon.CustomControls.FTButton btnDelete;
        private MatchCommon.CustomControls.FTButton btnAdd;
        private System.Windows.Forms.ToolTip ttForTxtSearch;
        private MatchCommon.CustomControls.FTLabel ftLabel47;
        private MatchCommon.CustomControls.FTComboBox cboIdentityType;
        private System.Windows.Forms.LinkLabel lnkAdvanceSearch;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Panel pnlCorrespondenceAdd;
        private MatchCommon.CustomControls.FTTextBox txtSearchKey;
        private System.Windows.Forms.DateTimePicker dtDOB;
        private MatchCommon.CustomControls.FTLabel ftlblDOB;
        private MatchCommon.CustomControls.FTLabel lblAuthSign;
        private MatchCommon.CustomControls.FTLabel lblPOAId;
        private MatchCommon.CustomControls.FTCheckBox chkAuthsign;
        private System.Windows.Forms.DateTimePicker dtPOA;
        private MatchCommon.CustomControls.FTTextBox txtOtherRelation;
        private System.Windows.Forms.Button btnAdvanceSearch;
    }
}
