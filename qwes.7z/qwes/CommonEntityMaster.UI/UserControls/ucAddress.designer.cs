﻿namespace FTIL.Match.CDD.UI.UserControls
{
    partial class ucAddress
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblFax = new MatchCommon.CustomControls.FTLabel();
            this.lblTel2 = new MatchCommon.CustomControls.FTLabel();
            this.lblTel1 = new MatchCommon.CustomControls.FTLabel();
            this.txtFax = new MatchCommon.CustomControls.FTTextBox();
            this.txtTel2 = new MatchCommon.CustomControls.FTTextBox();
            this.txtTel1 = new MatchCommon.CustomControls.FTTextBox();
            this.txtMobile = new MatchCommon.CustomControls.FTTextBox();
            this.lblMobile = new MatchCommon.CustomControls.FTLabel();
            this.txtPIN = new MatchCommon.CustomControls.FTTextBox();
            this.lblPin = new MatchCommon.CustomControls.FTLabel();
            this.cboCity = new MatchCommon.CustomControls.FTComboBox();
            this.lblCity = new MatchCommon.CustomControls.FTLabel();
            this.cboState = new MatchCommon.CustomControls.FTComboBox();
            this.lblState = new MatchCommon.CustomControls.FTLabel();
            this.lblCountry = new MatchCommon.CustomControls.FTLabel();
            this.lblMail = new MatchCommon.CustomControls.FTLabel();
            this.txtMail = new MatchCommon.CustomControls.FTTextBox();
            this.lblAddress = new MatchCommon.CustomControls.FTLabel();
            this.txtAddress = new MatchCommon.CustomControls.FTTextBox();
            this.cboCountry = new MatchCommon.CustomControls.FTComboBox();
            this.cMnuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cMnuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblFax
            // 
            this.lblFax.AllowForeColorChange = false;
            this.lblFax.AutoSize = true;
            this.lblFax.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblFax.ForeColor = System.Drawing.Color.Black;
            this.lblFax.Location = new System.Drawing.Point(591, 124);
            this.lblFax.Name = "lblFax";
            this.lblFax.OverrideDefault = false;
            this.lblFax.Size = new System.Drawing.Size(25, 13);
            this.lblFax.TabIndex = 66;
            this.lblFax.Text = "Fax";
            // 
            // lblTel2
            // 
            this.lblTel2.AllowForeColorChange = false;
            this.lblTel2.AutoSize = true;
            this.lblTel2.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblTel2.ForeColor = System.Drawing.Color.Black;
            this.lblTel2.Location = new System.Drawing.Point(402, 125);
            this.lblTel2.Name = "lblTel2";
            this.lblTel2.OverrideDefault = false;
            this.lblTel2.Size = new System.Drawing.Size(31, 13);
            this.lblTel2.TabIndex = 65;
            this.lblTel2.Text = "Tel.2";
            // 
            // lblTel1
            // 
            this.lblTel1.AllowForeColorChange = false;
            this.lblTel1.AutoSize = true;
            this.lblTel1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblTel1.ForeColor = System.Drawing.Color.Black;
            this.lblTel1.Location = new System.Drawing.Point(210, 125);
            this.lblTel1.Name = "lblTel1";
            this.lblTel1.OverrideDefault = false;
            this.lblTel1.Size = new System.Drawing.Size(31, 13);
            this.lblTel1.TabIndex = 64;
            this.lblTel1.Text = "Tel.1";
            // 
            // txtFax
            // 
            this.txtFax.AllowAlpha = true;
            this.txtFax.AllowDot = false;
            this.txtFax.AllowedCustomCharacters = null;
            this.txtFax.AllowNonASCII = false;
            this.txtFax.AllowNumeric = true;
            this.txtFax.AllowSpace = false;
            this.txtFax.AllowSpecialChars = false;
            this.txtFax.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtFax.FocusColor = System.Drawing.Color.LightYellow;
            this.txtFax.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtFax.ForeColor = System.Drawing.Color.Black;
            this.txtFax.IsEmailID = false;
            this.txtFax.IsEmailIdValid = false;
            this.txtFax.Location = new System.Drawing.Point(619, 121);
            this.txtFax.MaxLength = 15;
            this.txtFax.Name = "txtFax";
            this.txtFax.Size = new System.Drawing.Size(131, 20);
            this.txtFax.TabIndex = 59;
            this.txtFax.Tag = "Code";
            // 
            // txtTel2
            // 
            this.txtTel2.AllowAlpha = false;
            this.txtTel2.AllowDot = false;
            this.txtTel2.AllowedCustomCharacters = null;
            this.txtTel2.AllowNonASCII = false;
            this.txtTel2.AllowNumeric = true;
            this.txtTel2.AllowSpace = false;
            this.txtTel2.AllowSpecialChars = false;
            this.txtTel2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTel2.FocusColor = System.Drawing.Color.LightYellow;
            this.txtTel2.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtTel2.ForeColor = System.Drawing.Color.Black;
            this.txtTel2.IsEmailID = false;
            this.txtTel2.IsEmailIdValid = false;
            this.txtTel2.Location = new System.Drawing.Point(434, 121);
            this.txtTel2.MaxLength = 15;
            this.txtTel2.Name = "txtTel2";
            this.txtTel2.Size = new System.Drawing.Size(140, 20);
            this.txtTel2.TabIndex = 58;
            this.txtTel2.Tag = "Code";
            this.txtTel2.TextChanged += new System.EventHandler(this.txtTel2_TextChanged);
            // 
            // txtTel1
            // 
            this.txtTel1.AllowAlpha = false;
            this.txtTel1.AllowDot = false;
            this.txtTel1.AllowedCustomCharacters = null;
            this.txtTel1.AllowNonASCII = false;
            this.txtTel1.AllowNumeric = true;
            this.txtTel1.AllowSpace = false;
            this.txtTel1.AllowSpecialChars = false;
            this.txtTel1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTel1.FocusColor = System.Drawing.Color.LightYellow;
            this.txtTel1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtTel1.ForeColor = System.Drawing.Color.Black;
            this.txtTel1.IsEmailID = false;
            this.txtTel1.IsEmailIdValid = false;
            this.txtTel1.Location = new System.Drawing.Point(246, 121);
            this.txtTel1.MaxLength = 15;
            this.txtTel1.Name = "txtTel1";
            this.txtTel1.Size = new System.Drawing.Size(140, 20);
            this.txtTel1.TabIndex = 57;
            this.txtTel1.Tag = "Code";
            // 
            // txtMobile
            // 
            this.txtMobile.AllowAlpha = false;
            this.txtMobile.AllowDot = false;
            this.txtMobile.AllowedCustomCharacters = null;
            this.txtMobile.AllowNonASCII = false;
            this.txtMobile.AllowNumeric = true;
            this.txtMobile.AllowSpace = false;
            this.txtMobile.AllowSpecialChars = false;
            this.txtMobile.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMobile.FocusColor = System.Drawing.Color.LightYellow;
            this.txtMobile.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtMobile.ForeColor = System.Drawing.Color.Black;
            this.txtMobile.IsEmailID = false;
            this.txtMobile.IsEmailIdValid = false;
            this.txtMobile.Location = new System.Drawing.Point(53, 121);
            this.txtMobile.MaxLength = 15;
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.Size = new System.Drawing.Size(140, 20);
            this.txtMobile.TabIndex = 56;
            this.txtMobile.Tag = "Code";
            // 
            // lblMobile
            // 
            this.lblMobile.AllowForeColorChange = false;
            this.lblMobile.AutoSize = true;
            this.lblMobile.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblMobile.ForeColor = System.Drawing.Color.Black;
            this.lblMobile.Location = new System.Drawing.Point(6, 125);
            this.lblMobile.Name = "lblMobile";
            this.lblMobile.OverrideDefault = false;
            this.lblMobile.Size = new System.Drawing.Size(37, 13);
            this.lblMobile.TabIndex = 60;
            this.lblMobile.Text = "Mobile";
            // 
            // txtPIN
            // 
            this.txtPIN.AllowAlpha = false;
            this.txtPIN.AllowDot = false;
            this.txtPIN.AllowedCustomCharacters = null;
            this.txtPIN.AllowNonASCII = false;
            this.txtPIN.AllowNumeric = true;
            this.txtPIN.AllowSpace = false;
            this.txtPIN.AllowSpecialChars = false;
            this.txtPIN.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPIN.FocusColor = System.Drawing.Color.LightYellow;
            this.txtPIN.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtPIN.ForeColor = System.Drawing.Color.Black;
            this.txtPIN.IsEmailID = false;
            this.txtPIN.IsEmailIdValid = false;
            this.txtPIN.Location = new System.Drawing.Point(619, 70);
            this.txtPIN.MaxLength = 6;
            this.txtPIN.Name = "txtPIN";
            this.txtPIN.Size = new System.Drawing.Size(131, 20);
            this.txtPIN.TabIndex = 54;
            this.txtPIN.Tag = "Code";
            // 
            // lblPin
            // 
            this.lblPin.AllowForeColorChange = false;
            this.lblPin.AutoSize = true;
            this.lblPin.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblPin.ForeColor = System.Drawing.Color.Black;
            this.lblPin.Location = new System.Drawing.Point(591, 74);
            this.lblPin.Name = "lblPin";
            this.lblPin.OverrideDefault = false;
            this.lblPin.Size = new System.Drawing.Size(24, 13);
            this.lblPin.TabIndex = 59;
            this.lblPin.Text = "PIN";
            // 
            // cboCity
            // 
            this.cboCity.BackColor = System.Drawing.Color.White;
            this.cboCity.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboCity.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboCity.ForeColor = System.Drawing.Color.Black;
            this.cboCity.FormattingEnabled = true;
            this.cboCity.Location = new System.Drawing.Point(54, 70);
            this.cboCity.Name = "cboCity";
            this.cboCity.ReadOnly = false;
            this.cboCity.Size = new System.Drawing.Size(140, 21);
            this.cboCity.TabIndex = 51;
            this.cboCity.SelectedIndexChanged += new System.EventHandler(this.cboCity_SelectedIndexChanged_1);
            // 
            // lblCity
            // 
            this.lblCity.AllowForeColorChange = false;
            this.lblCity.AutoSize = true;
            this.lblCity.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblCity.ForeColor = System.Drawing.Color.Black;
            this.lblCity.Location = new System.Drawing.Point(6, 74);
            this.lblCity.Name = "lblCity";
            this.lblCity.OverrideDefault = false;
            this.lblCity.Size = new System.Drawing.Size(26, 13);
            this.lblCity.TabIndex = 58;
            this.lblCity.Text = "City";
            // 
            // cboState
            // 
            this.cboState.BackColor = System.Drawing.Color.White;
            this.cboState.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboState.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboState.ForeColor = System.Drawing.Color.Black;
            this.cboState.FormattingEnabled = true;
            this.cboState.Location = new System.Drawing.Point(244, 70);
            this.cboState.Name = "cboState";
            this.cboState.ReadOnly = false;
            this.cboState.Size = new System.Drawing.Size(140, 21);
            this.cboState.TabIndex = 52;
            // 
            // lblState
            // 
            this.lblState.AllowForeColorChange = false;
            this.lblState.AutoSize = true;
            this.lblState.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblState.ForeColor = System.Drawing.Color.Black;
            this.lblState.Location = new System.Drawing.Point(208, 74);
            this.lblState.Name = "lblState";
            this.lblState.OverrideDefault = false;
            this.lblState.Size = new System.Drawing.Size(33, 13);
            this.lblState.TabIndex = 55;
            this.lblState.Text = "State";
            // 
            // lblCountry
            // 
            this.lblCountry.AllowForeColorChange = false;
            this.lblCountry.AutoSize = true;
            this.lblCountry.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblCountry.ForeColor = System.Drawing.Color.Black;
            this.lblCountry.Location = new System.Drawing.Point(390, 74);
            this.lblCountry.Name = "lblCountry";
            this.lblCountry.OverrideDefault = false;
            this.lblCountry.Size = new System.Drawing.Size(46, 13);
            this.lblCountry.TabIndex = 54;
            this.lblCountry.Text = "Country";
            // 
            // lblMail
            // 
            this.lblMail.AllowForeColorChange = false;
            this.lblMail.AutoSize = true;
            this.lblMail.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblMail.ForeColor = System.Drawing.Color.Black;
            this.lblMail.Location = new System.Drawing.Point(6, 99);
            this.lblMail.Name = "lblMail";
            this.lblMail.OverrideDefault = false;
            this.lblMail.Size = new System.Drawing.Size(35, 13);
            this.lblMail.TabIndex = 50;
            this.lblMail.Text = "E-Mail";
            // 
            // txtMail
            // 
            this.txtMail.AllowAlpha = true;
            this.txtMail.AllowDot = true;
            this.txtMail.AllowedCustomCharacters = null;
            this.txtMail.AllowNonASCII = false;
            this.txtMail.AllowNumeric = true;
            this.txtMail.AllowSpace = false;
            this.txtMail.AllowSpecialChars = true;
            this.txtMail.FocusColor = System.Drawing.Color.LightYellow;
            this.txtMail.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtMail.ForeColor = System.Drawing.Color.Black;
            this.txtMail.IsEmailID = true;
            this.txtMail.IsEmailIdValid = false;
            this.txtMail.Location = new System.Drawing.Point(53, 96);
            this.txtMail.MaxLength = 50;
            this.txtMail.Name = "txtMail";
            this.txtMail.Size = new System.Drawing.Size(697, 20);
            this.txtMail.TabIndex = 55;
            this.txtMail.Tag = "Code";
            this.txtMail.TextChanged += new System.EventHandler(this.txtMail_TextChanged);
            // 
            // lblAddress
            // 
            this.lblAddress.AllowForeColorChange = false;
            this.lblAddress.AutoSize = true;
            this.lblAddress.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblAddress.ForeColor = System.Drawing.Color.Black;
            this.lblAddress.Location = new System.Drawing.Point(3, 24);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.OverrideDefault = false;
            this.lblAddress.Size = new System.Drawing.Size(46, 13);
            this.lblAddress.TabIndex = 47;
            this.lblAddress.Text = "Address";
            // 
            // txtAddress
            // 
            this.txtAddress.AllowAlpha = true;
            this.txtAddress.AllowDot = true;
            this.txtAddress.AllowedCustomCharacters = null;
            this.txtAddress.AllowNonASCII = false;
            this.txtAddress.AllowNumeric = true;
            this.txtAddress.AllowSpace = true;
            this.txtAddress.AllowSpecialChars = true;
            this.txtAddress.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtAddress.FocusColor = System.Drawing.Color.LightYellow;
            this.txtAddress.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtAddress.ForeColor = System.Drawing.Color.Black;
            this.txtAddress.IsEmailID = false;
            this.txtAddress.IsEmailIdValid = false;
            this.txtAddress.Location = new System.Drawing.Point(53, 2);
            this.txtAddress.MaxLength = 255;
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtAddress.Size = new System.Drawing.Size(697, 63);
            this.txtAddress.TabIndex = 50;
            this.txtAddress.Tag = "Code";
            this.txtAddress.TextChanged += new System.EventHandler(this.txtAddress_TextChanged);
            // 
            // cboCountry
            // 
            this.cboCountry.BackColor = System.Drawing.Color.White;
            this.cboCountry.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboCountry.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboCountry.ForeColor = System.Drawing.Color.Black;
            this.cboCountry.FormattingEnabled = true;
            this.cboCountry.Location = new System.Drawing.Point(436, 70);
            this.cboCountry.Name = "cboCountry";
            this.cboCountry.ReadOnly = false;
            this.cboCountry.Size = new System.Drawing.Size(140, 21);
            this.cboCountry.TabIndex = 53;
            // 
            // cMnuStrip
            // 
            this.cMnuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyToolStripMenuItem,
            this.pasteToolStripMenuItem});
            this.cMnuStrip.Name = "cMnuStrip";
            this.cMnuStrip.Size = new System.Drawing.Size(103, 48);
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(102, 22);
            this.copyToolStripMenuItem.Text = "Copy";
            this.copyToolStripMenuItem.Click += new System.EventHandler(this.copyToolStripMenuItem_Click);
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(102, 22);
            this.pasteToolStripMenuItem.Text = "Paste";
            this.pasteToolStripMenuItem.Click += new System.EventHandler(this.pasteToolStripMenuItem_Click);
            // 
            // ucAddress
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.ContextMenuStrip = this.cMnuStrip;
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.lblFax);
            this.Controls.Add(this.lblTel2);
            this.Controls.Add(this.lblTel1);
            this.Controls.Add(this.txtFax);
            this.Controls.Add(this.txtTel2);
            this.Controls.Add(this.txtTel1);
            this.Controls.Add(this.txtMobile);
            this.Controls.Add(this.lblMobile);
            this.Controls.Add(this.txtPIN);
            this.Controls.Add(this.lblPin);
            this.Controls.Add(this.cboCity);
            this.Controls.Add(this.lblCity);
            this.Controls.Add(this.cboState);
            this.Controls.Add(this.lblState);
            this.Controls.Add(this.lblCountry);
            this.Controls.Add(this.cboCountry);
            this.Controls.Add(this.lblMail);
            this.Controls.Add(this.txtMail);
            this.Controls.Add(this.lblAddress);
            this.Name = "ucAddress";
            this.Size = new System.Drawing.Size(752, 142);
            this.Load += new System.EventHandler(this.ucAddress_Load);
            this.cMnuStrip.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MatchCommon.CustomControls.FTLabel lblFax;
        private MatchCommon.CustomControls.FTLabel lblTel2;
        private MatchCommon.CustomControls.FTLabel lblTel1;
        private MatchCommon.CustomControls.FTTextBox txtFax;
        private MatchCommon.CustomControls.FTTextBox txtTel2;
        private MatchCommon.CustomControls.FTTextBox txtTel1;
        private MatchCommon.CustomControls.FTTextBox txtMobile;
        private MatchCommon.CustomControls.FTLabel lblMobile;
        private MatchCommon.CustomControls.FTTextBox txtPIN;
        private MatchCommon.CustomControls.FTLabel lblPin;
        private MatchCommon.CustomControls.FTComboBox cboCity;
        private MatchCommon.CustomControls.FTLabel lblCity;
        private MatchCommon.CustomControls.FTComboBox cboState;
        private MatchCommon.CustomControls.FTLabel lblState;
        private MatchCommon.CustomControls.FTLabel lblCountry;
        private MatchCommon.CustomControls.FTLabel lblMail;
        private MatchCommon.CustomControls.FTTextBox txtMail;
        private MatchCommon.CustomControls.FTLabel lblAddress;
        private MatchCommon.CustomControls.FTTextBox txtAddress;
        private MatchCommon.CustomControls.FTComboBox cboCountry;
        private System.Windows.Forms.ContextMenuStrip cMnuStrip;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
    }
}
