﻿namespace FTIL.Match.CDD.UI.UserControls
{
    partial class ucEntityOthers
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucEntityOthers));
            this.ftLabel54 = new MatchCommon.CustomControls.FTLabel();
            this.txtUserId = new MatchCommon.CustomControls.FTTextBox();
            this.txtPEP = new MatchCommon.CustomControls.FTTextBox();
            this.txtOccupation = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel39 = new MatchCommon.CustomControls.FTLabel();
            this.cboPEP = new MatchCommon.CustomControls.FTComboBox();
            this.lblOccupation = new MatchCommon.CustomControls.FTLabel();
            this.cboOccupation = new MatchCommon.CustomControls.FTComboBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.dtNetworth = new System.Windows.Forms.DateTimePicker();
            this.cboGrossAnnual = new MatchCommon.CustomControls.FTComboBox();
            this.dtGrossAnnual = new System.Windows.Forms.DateTimePicker();
            this.txtNetworth = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel41 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel42 = new MatchCommon.CustomControls.FTLabel();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btnDelete = new MatchCommon.CustomControls.FTButton();
            this.btnAdd = new MatchCommon.CustomControls.FTButton();
            this.ftLabel43 = new MatchCommon.CustomControls.FTLabel();
            this.dtExpiryDate = new System.Windows.Forms.DateTimePicker();
            this.ftLabel44 = new MatchCommon.CustomControls.FTLabel();
            this.dtDateOfIssue = new System.Windows.Forms.DateTimePicker();
            this.ftLabel45 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel46 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel47 = new MatchCommon.CustomControls.FTLabel();
            this.txtPlaceOfIssue = new MatchCommon.CustomControls.FTTextBox();
            this.txtIdentityDetails = new MatchCommon.CustomControls.FTTextBox();
            this.cboIdentityType = new MatchCommon.CustomControls.FTComboBox();
            this.chPanExempt = new MatchCommon.CustomControls.FTCheckBox();
            this.dgIdentityDtls = new MatchCommon.CustomControls.FTDataGrid();
            this.ftLabel1 = new MatchCommon.CustomControls.FTLabel();
            this.cboFacityType = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel2 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel3 = new MatchCommon.CustomControls.FTLabel();
            this.chkSelfAuth = new MatchCommon.CustomControls.FTCheckBox();
            this.ftLabel4 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel6 = new MatchCommon.CustomControls.FTLabel();
            this.txtTaxDeductionStatus = new MatchCommon.CustomControls.FTTextBox();
            this.chkStandingInstruction = new MatchCommon.CustomControls.FTCheckBox();
            this.ftLabel5 = new MatchCommon.CustomControls.FTLabel();
            this.cboSubType = new MatchCommon.CustomControls.FTComboBox();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgIdentityDtls)).BeginInit();
            this.SuspendLayout();
            // 
            // ftLabel54
            // 
            this.ftLabel54.AllowForeColorChange = false;
            this.ftLabel54.AutoSize = true;
            this.ftLabel54.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel54.ForeColor = System.Drawing.Color.Black;
            this.ftLabel54.Location = new System.Drawing.Point(4, 443);
            this.ftLabel54.Name = "ftLabel54";
            this.ftLabel54.OverrideDefault = false;
            this.ftLabel54.Size = new System.Drawing.Size(42, 13);
            this.ftLabel54.TabIndex = 78;
            this.ftLabel54.Text = "User Id";
            // 
            // txtUserId
            // 
            this.txtUserId.AllowAlpha = true;
            this.txtUserId.AllowDot = false;
            this.txtUserId.AllowedCustomCharacters = null;
            this.txtUserId.AllowNonASCII = false;
            this.txtUserId.AllowNumeric = true;
            this.txtUserId.AllowSpace = false;
            this.txtUserId.AllowSpecialChars = true;
            this.txtUserId.BackColor = System.Drawing.SystemColors.Window;
            this.txtUserId.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtUserId.FocusColor = System.Drawing.Color.LightYellow;
            this.txtUserId.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtUserId.ForeColor = System.Drawing.Color.Black;
            this.txtUserId.IsEmailID = false;
            this.txtUserId.IsEmailIdValid = false;
            this.txtUserId.Location = new System.Drawing.Point(76, 440);
            this.txtUserId.MaxLength = 10;
            this.txtUserId.Name = "txtUserId";
            this.txtUserId.Size = new System.Drawing.Size(171, 20);
            this.txtUserId.TabIndex = 107;
            this.txtUserId.Tag = "Code";
            // 
            // txtPEP
            // 
            this.txtPEP.AllowAlpha = true;
            this.txtPEP.AllowDot = false;
            this.txtPEP.AllowedCustomCharacters = null;
            this.txtPEP.AllowNonASCII = false;
            this.txtPEP.AllowNumeric = true;
            this.txtPEP.AllowSpace = false;
            this.txtPEP.AllowSpecialChars = true;
            this.txtPEP.BackColor = System.Drawing.SystemColors.Window;
            this.txtPEP.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPEP.FocusColor = System.Drawing.Color.LightYellow;
            this.txtPEP.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtPEP.ForeColor = System.Drawing.Color.Black;
            this.txtPEP.IsEmailID = false;
            this.txtPEP.IsEmailIdValid = false;
            this.txtPEP.Location = new System.Drawing.Point(254, 413);
            this.txtPEP.MaxLength = 200;
            this.txtPEP.Name = "txtPEP";
            this.txtPEP.Size = new System.Drawing.Size(508, 20);
            this.txtPEP.TabIndex = 106;
            this.txtPEP.Tag = "Code";
            // 
            // txtOccupation
            // 
            this.txtOccupation.AllowAlpha = true;
            this.txtOccupation.AllowDot = false;
            this.txtOccupation.AllowedCustomCharacters = null;
            this.txtOccupation.AllowNonASCII = false;
            this.txtOccupation.AllowNumeric = true;
            this.txtOccupation.AllowSpace = false;
            this.txtOccupation.AllowSpecialChars = true;
            this.txtOccupation.BackColor = System.Drawing.SystemColors.Window;
            this.txtOccupation.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtOccupation.FocusColor = System.Drawing.Color.LightYellow;
            this.txtOccupation.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtOccupation.ForeColor = System.Drawing.Color.Black;
            this.txtOccupation.IsEmailID = false;
            this.txtOccupation.IsEmailIdValid = false;
            this.txtOccupation.Location = new System.Drawing.Point(254, 385);
            this.txtOccupation.MaxLength = 200;
            this.txtOccupation.Name = "txtOccupation";
            this.txtOccupation.Size = new System.Drawing.Size(508, 20);
            this.txtOccupation.TabIndex = 104;
            this.txtOccupation.Tag = "Code";
            // 
            // ftLabel39
            // 
            this.ftLabel39.AllowForeColorChange = false;
            this.ftLabel39.AutoSize = true;
            this.ftLabel39.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel39.ForeColor = System.Drawing.Color.Black;
            this.ftLabel39.Location = new System.Drawing.Point(4, 416);
            this.ftLabel39.Name = "ftLabel39";
            this.ftLabel39.OverrideDefault = false;
            this.ftLabel39.Size = new System.Drawing.Size(25, 13);
            this.ftLabel39.TabIndex = 76;
            this.ftLabel39.Text = "PEP";
            // 
            // cboPEP
            // 
            this.cboPEP.BackColor = System.Drawing.Color.White;
            this.cboPEP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPEP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboPEP.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboPEP.ForeColor = System.Drawing.Color.Black;
            this.cboPEP.FormattingEnabled = true;
            this.cboPEP.Location = new System.Drawing.Point(76, 413);
            this.cboPEP.Name = "cboPEP";
            this.cboPEP.ReadOnly = false;
            this.cboPEP.Size = new System.Drawing.Size(171, 21);
            this.cboPEP.TabIndex = 105;
            // 
            // lblOccupation
            // 
            this.lblOccupation.AllowForeColorChange = false;
            this.lblOccupation.AutoSize = true;
            this.lblOccupation.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblOccupation.ForeColor = System.Drawing.Color.Black;
            this.lblOccupation.Location = new System.Drawing.Point(4, 388);
            this.lblOccupation.Name = "lblOccupation";
            this.lblOccupation.OverrideDefault = false;
            this.lblOccupation.Size = new System.Drawing.Size(61, 13);
            this.lblOccupation.TabIndex = 73;
            this.lblOccupation.Text = "Occupation";
            // 
            // cboOccupation
            // 
            this.cboOccupation.BackColor = System.Drawing.Color.White;
            this.cboOccupation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboOccupation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboOccupation.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboOccupation.ForeColor = System.Drawing.Color.Black;
            this.cboOccupation.FormattingEnabled = true;
            this.cboOccupation.Location = new System.Drawing.Point(76, 385);
            this.cboOccupation.Name = "cboOccupation";
            this.cboOccupation.ReadOnly = false;
            this.cboOccupation.Size = new System.Drawing.Size(171, 21);
            this.cboOccupation.TabIndex = 103;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.dtNetworth);
            this.groupBox7.Controls.Add(this.cboGrossAnnual);
            this.groupBox7.Controls.Add(this.dtGrossAnnual);
            this.groupBox7.Controls.Add(this.txtNetworth);
            this.groupBox7.Controls.Add(this.ftLabel41);
            this.groupBox7.Controls.Add(this.ftLabel42);
            this.groupBox7.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox7.Location = new System.Drawing.Point(2, 290);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(766, 54);
            this.groupBox7.TabIndex = 70;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Income/Networth";
            // 
            // dtNetworth
            // 
            this.dtNetworth.CustomFormat = "MM/dd/yyyy";
            this.dtNetworth.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtNetworth.Location = new System.Drawing.Point(667, 22);
            this.dtNetworth.Name = "dtNetworth";
            this.dtNetworth.Size = new System.Drawing.Size(92, 21);
            this.dtNetworth.TabIndex = 99;
            // 
            // cboGrossAnnual
            // 
            this.cboGrossAnnual.BackColor = System.Drawing.Color.White;
            this.cboGrossAnnual.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboGrossAnnual.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboGrossAnnual.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboGrossAnnual.ForeColor = System.Drawing.Color.Black;
            this.cboGrossAnnual.FormattingEnabled = true;
            this.cboGrossAnnual.Location = new System.Drawing.Point(76, 22);
            this.cboGrossAnnual.Name = "cboGrossAnnual";
            this.cboGrossAnnual.ReadOnly = false;
            this.cboGrossAnnual.Size = new System.Drawing.Size(171, 21);
            this.cboGrossAnnual.TabIndex = 96;
            // 
            // dtGrossAnnual
            // 
            this.dtGrossAnnual.CustomFormat = "dd/MM/yyyy";
            this.dtGrossAnnual.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtGrossAnnual.Location = new System.Drawing.Point(252, 21);
            this.dtGrossAnnual.Name = "dtGrossAnnual";
            this.dtGrossAnnual.Size = new System.Drawing.Size(92, 21);
            this.dtGrossAnnual.TabIndex = 97;
            // 
            // txtNetworth
            // 
            this.txtNetworth.AllowAlpha = false;
            this.txtNetworth.AllowDot = false;
            this.txtNetworth.AllowedCustomCharacters = null;
            this.txtNetworth.AllowNonASCII = true;
            this.txtNetworth.AllowNumeric = true;
            this.txtNetworth.AllowSpace = false;
            this.txtNetworth.AllowSpecialChars = false;
            this.txtNetworth.BackColor = System.Drawing.SystemColors.Window;
            this.txtNetworth.FocusColor = System.Drawing.Color.LightYellow;
            this.txtNetworth.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtNetworth.ForeColor = System.Drawing.Color.Black;
            this.txtNetworth.IsEmailID = false;
            this.txtNetworth.IsEmailIdValid = false;
            this.txtNetworth.Location = new System.Drawing.Point(480, 22);
            this.txtNetworth.MaxLength = 30;
            this.txtNetworth.Name = "txtNetworth";
            this.txtNetworth.Size = new System.Drawing.Size(181, 20);
            this.txtNetworth.TabIndex = 98;
            this.txtNetworth.Tag = "";
            // 
            // ftLabel41
            // 
            this.ftLabel41.AllowForeColorChange = false;
            this.ftLabel41.AutoSize = true;
            this.ftLabel41.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel41.ForeColor = System.Drawing.Color.Black;
            this.ftLabel41.Location = new System.Drawing.Point(5, 25);
            this.ftLabel41.Name = "ftLabel41";
            this.ftLabel41.OverrideDefault = false;
            this.ftLabel41.Size = new System.Drawing.Size(70, 13);
            this.ftLabel41.TabIndex = 59;
            this.ftLabel41.Text = "Gross Annual";
            // 
            // ftLabel42
            // 
            this.ftLabel42.AllowForeColorChange = false;
            this.ftLabel42.AutoSize = true;
            this.ftLabel42.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel42.ForeColor = System.Drawing.Color.Black;
            this.ftLabel42.Location = new System.Drawing.Point(427, 26);
            this.ftLabel42.Name = "ftLabel42";
            this.ftLabel42.OverrideDefault = false;
            this.ftLabel42.Size = new System.Drawing.Size(52, 13);
            this.ftLabel42.TabIndex = 26;
            this.ftLabel42.Text = "Networth";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btnDelete);
            this.groupBox6.Controls.Add(this.btnAdd);
            this.groupBox6.Controls.Add(this.ftLabel43);
            this.groupBox6.Controls.Add(this.dtExpiryDate);
            this.groupBox6.Controls.Add(this.ftLabel44);
            this.groupBox6.Controls.Add(this.dtDateOfIssue);
            this.groupBox6.Controls.Add(this.ftLabel45);
            this.groupBox6.Controls.Add(this.ftLabel46);
            this.groupBox6.Controls.Add(this.ftLabel47);
            this.groupBox6.Controls.Add(this.txtPlaceOfIssue);
            this.groupBox6.Controls.Add(this.txtIdentityDetails);
            this.groupBox6.Controls.Add(this.cboIdentityType);
            this.groupBox6.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox6.Location = new System.Drawing.Point(2, 166);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(766, 112);
            this.groupBox6.TabIndex = 69;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Identification";
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Transparent;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.Location = new System.Drawing.Point(684, 76);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 25);
            this.btnDelete.TabIndex = 95;
            this.btnDelete.Text = "&Remove";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Transparent;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAdd.Location = new System.Drawing.Point(602, 76);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 25);
            this.btnAdd.TabIndex = 94;
            this.btnAdd.Text = "&Add";
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // ftLabel43
            // 
            this.ftLabel43.AllowForeColorChange = false;
            this.ftLabel43.AutoSize = true;
            this.ftLabel43.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel43.ForeColor = System.Drawing.Color.Black;
            this.ftLabel43.Location = new System.Drawing.Point(279, 50);
            this.ftLabel43.Name = "ftLabel43";
            this.ftLabel43.OverrideDefault = false;
            this.ftLabel43.Size = new System.Drawing.Size(76, 13);
            this.ftLabel43.TabIndex = 59;
            this.ftLabel43.Text = "Place Of Issue";
            // 
            // dtExpiryDate
            // 
            this.dtExpiryDate.CustomFormat = "dd/MM/yyyy";
            this.dtExpiryDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtExpiryDate.Location = new System.Drawing.Point(155, 76);
            this.dtExpiryDate.Name = "dtExpiryDate";
            this.dtExpiryDate.Size = new System.Drawing.Size(92, 21);
            this.dtExpiryDate.TabIndex = 92;
            // 
            // ftLabel44
            // 
            this.ftLabel44.AllowForeColorChange = false;
            this.ftLabel44.AutoSize = true;
            this.ftLabel44.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel44.ForeColor = System.Drawing.Color.Black;
            this.ftLabel44.Location = new System.Drawing.Point(5, 81);
            this.ftLabel44.Name = "ftLabel44";
            this.ftLabel44.OverrideDefault = false;
            this.ftLabel44.Size = new System.Drawing.Size(152, 13);
            this.ftLabel44.TabIndex = 57;
            this.ftLabel44.Text = "Commencement / Expiry Date ";
            // 
            // dtDateOfIssue
            // 
            this.dtDateOfIssue.CustomFormat = "dd/MM/yyyy";
            this.dtDateOfIssue.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtDateOfIssue.Location = new System.Drawing.Point(155, 47);
            this.dtDateOfIssue.Name = "dtDateOfIssue";
            this.dtDateOfIssue.Size = new System.Drawing.Size(92, 21);
            this.dtDateOfIssue.TabIndex = 91;
            // 
            // ftLabel45
            // 
            this.ftLabel45.AllowForeColorChange = false;
            this.ftLabel45.AutoSize = true;
            this.ftLabel45.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel45.ForeColor = System.Drawing.Color.Black;
            this.ftLabel45.Location = new System.Drawing.Point(5, 53);
            this.ftLabel45.Name = "ftLabel45";
            this.ftLabel45.OverrideDefault = false;
            this.ftLabel45.Size = new System.Drawing.Size(134, 13);
            this.ftLabel45.TabIndex = 55;
            this.ftLabel45.Text = "Incorporation / Issue Date";
            // 
            // ftLabel46
            // 
            this.ftLabel46.AllowForeColorChange = false;
            this.ftLabel46.AutoSize = true;
            this.ftLabel46.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel46.ForeColor = System.Drawing.Color.Black;
            this.ftLabel46.Location = new System.Drawing.Point(279, 23);
            this.ftLabel46.Name = "ftLabel46";
            this.ftLabel46.OverrideDefault = false;
            this.ftLabel46.Size = new System.Drawing.Size(39, 13);
            this.ftLabel46.TabIndex = 54;
            this.ftLabel46.Text = "Details";
            // 
            // ftLabel47
            // 
            this.ftLabel47.AllowForeColorChange = false;
            this.ftLabel47.AutoSize = true;
            this.ftLabel47.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel47.ForeColor = System.Drawing.Color.Black;
            this.ftLabel47.Location = new System.Drawing.Point(5, 23);
            this.ftLabel47.Name = "ftLabel47";
            this.ftLabel47.OverrideDefault = false;
            this.ftLabel47.Size = new System.Drawing.Size(55, 13);
            this.ftLabel47.TabIndex = 53;
            this.ftLabel47.Text = "Document";
            // 
            // txtPlaceOfIssue
            // 
            this.txtPlaceOfIssue.AllowAlpha = true;
            this.txtPlaceOfIssue.AllowDot = false;
            this.txtPlaceOfIssue.AllowedCustomCharacters = null;
            this.txtPlaceOfIssue.AllowNonASCII = false;
            this.txtPlaceOfIssue.AllowNumeric = true;
            this.txtPlaceOfIssue.AllowSpace = true;
            this.txtPlaceOfIssue.AllowSpecialChars = true;
            this.txtPlaceOfIssue.BackColor = System.Drawing.SystemColors.Window;
            this.txtPlaceOfIssue.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPlaceOfIssue.FocusColor = System.Drawing.Color.LightYellow;
            this.txtPlaceOfIssue.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtPlaceOfIssue.ForeColor = System.Drawing.Color.Black;
            this.txtPlaceOfIssue.IsEmailID = false;
            this.txtPlaceOfIssue.IsEmailIdValid = false;
            this.txtPlaceOfIssue.Location = new System.Drawing.Point(358, 47);
            this.txtPlaceOfIssue.MaxLength = 100;
            this.txtPlaceOfIssue.Name = "txtPlaceOfIssue";
            this.txtPlaceOfIssue.Size = new System.Drawing.Size(402, 20);
            this.txtPlaceOfIssue.TabIndex = 93;
            this.txtPlaceOfIssue.Tag = "Code";
            // 
            // txtIdentityDetails
            // 
            this.txtIdentityDetails.AllowAlpha = true;
            this.txtIdentityDetails.AllowDot = false;
            this.txtIdentityDetails.AllowedCustomCharacters = null;
            this.txtIdentityDetails.AllowNonASCII = false;
            this.txtIdentityDetails.AllowNumeric = true;
            this.txtIdentityDetails.AllowSpace = false;
            this.txtIdentityDetails.AllowSpecialChars = false;
            this.txtIdentityDetails.BackColor = System.Drawing.SystemColors.Window;
            this.txtIdentityDetails.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtIdentityDetails.FocusColor = System.Drawing.Color.LightYellow;
            this.txtIdentityDetails.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtIdentityDetails.ForeColor = System.Drawing.Color.Black;
            this.txtIdentityDetails.IsEmailID = false;
            this.txtIdentityDetails.IsEmailIdValid = false;
            this.txtIdentityDetails.Location = new System.Drawing.Point(358, 20);
            this.txtIdentityDetails.MaxLength = 100;
            this.txtIdentityDetails.Name = "txtIdentityDetails";
            this.txtIdentityDetails.Size = new System.Drawing.Size(402, 20);
            this.txtIdentityDetails.TabIndex = 90;
            this.txtIdentityDetails.Tag = "Code";
            // 
            // cboIdentityType
            // 
            this.cboIdentityType.BackColor = System.Drawing.Color.White;
            this.cboIdentityType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboIdentityType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboIdentityType.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboIdentityType.ForeColor = System.Drawing.Color.Black;
            this.cboIdentityType.FormattingEnabled = true;
            this.cboIdentityType.Location = new System.Drawing.Point(76, 20);
            this.cboIdentityType.Name = "cboIdentityType";
            this.cboIdentityType.ReadOnly = false;
            this.cboIdentityType.Size = new System.Drawing.Size(171, 21);
            this.cboIdentityType.TabIndex = 89;
            this.cboIdentityType.SelectedIndexChanged += new System.EventHandler(this.cboIdentityType_SelectedIndexChanged);
            // 
            // chPanExempt
            // 
            this.chPanExempt.AutoSize = true;
            this.chPanExempt.Font = new System.Drawing.Font("Tahoma", 8F);
            this.chPanExempt.ForeColor = System.Drawing.Color.Black;
            this.chPanExempt.Location = new System.Drawing.Point(358, 360);
            this.chPanExempt.Name = "chPanExempt";
            this.chPanExempt.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.chPanExempt.Size = new System.Drawing.Size(15, 14);
            this.chPanExempt.TabIndex = 101;
            this.chPanExempt.UseVisualStyleBackColor = true;
            this.chPanExempt.CheckedChanged += new System.EventHandler(this.chPanExempt_CheckedChanged);
            // 
            // dgIdentityDtls
            // 
            this.dgIdentityDtls.AllowEditing = false;
            this.dgIdentityDtls.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
            this.dgIdentityDtls.BackColor = System.Drawing.Color.White;
            this.dgIdentityDtls.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.dgIdentityDtls.ColumnInfo = "5,1,0,0,0,95,Columns:0{Width:30;}\t";
            this.dgIdentityDtls.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
            this.dgIdentityDtls.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dgIdentityDtls.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.dgIdentityDtls.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
            this.dgIdentityDtls.Location = new System.Drawing.Point(0, 2);
            this.dgIdentityDtls.Name = "dgIdentityDtls";
            this.dgIdentityDtls.Styles.EmptyArea.BackColor = System.Drawing.Color.White;
            this.dgIdentityDtls.OverrideDefault = false;
            this.dgIdentityDtls.Rows.Count = 10;
            this.dgIdentityDtls.Rows.DefaultSize = 19;
            this.dgIdentityDtls.Rows.MinSize = 25;
            this.dgIdentityDtls.RowsFilter.AddFilterRow = false;
            this.dgIdentityDtls.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.ListBox;
            this.dgIdentityDtls.Size = new System.Drawing.Size(770, 150);
            this.dgIdentityDtls.StyleInfo = "";
            this.dgIdentityDtls.TabIndex = 4;
            // 
            // ftLabel1
            // 
            this.ftLabel1.AllowForeColorChange = false;
            this.ftLabel1.AutoSize = true;
            this.ftLabel1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel1.ForeColor = System.Drawing.Color.Black;
            this.ftLabel1.Location = new System.Drawing.Point(4, 470);
            this.ftLabel1.Name = "ftLabel1";
            this.ftLabel1.OverrideDefault = false;
            this.ftLabel1.Size = new System.Drawing.Size(67, 13);
            this.ftLabel1.TabIndex = 105;
            this.ftLabel1.Text = "Facility Type";
            // 
            // cboFacityType
            // 
            this.cboFacityType.BackColor = System.Drawing.Color.White;
            this.cboFacityType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboFacityType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboFacityType.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboFacityType.ForeColor = System.Drawing.Color.Black;
            this.cboFacityType.FormattingEnabled = true;
            this.cboFacityType.Location = new System.Drawing.Point(76, 466);
            this.cboFacityType.Name = "cboFacityType";
            this.cboFacityType.ReadOnly = false;
            this.cboFacityType.Size = new System.Drawing.Size(171, 21);
            this.cboFacityType.TabIndex = 110;
            // 
            // ftLabel2
            // 
            this.ftLabel2.AllowForeColorChange = false;
            this.ftLabel2.AutoSize = true;
            this.ftLabel2.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel2.ForeColor = System.Drawing.Color.Black;
            this.ftLabel2.Location = new System.Drawing.Point(279, 360);
            this.ftLabel2.Name = "ftLabel2";
            this.ftLabel2.OverrideDefault = false;
            this.ftLabel2.Size = new System.Drawing.Size(66, 13);
            this.ftLabel2.TabIndex = 107;
            this.ftLabel2.Text = "PAN Exempt";
            // 
            // ftLabel3
            // 
            this.ftLabel3.AllowForeColorChange = false;
            this.ftLabel3.AutoSize = true;
            this.ftLabel3.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel3.ForeColor = System.Drawing.Color.Black;
            this.ftLabel3.Location = new System.Drawing.Point(545, 359);
            this.ftLabel3.Name = "ftLabel3";
            this.ftLabel3.OverrideDefault = false;
            this.ftLabel3.Size = new System.Drawing.Size(63, 13);
            this.ftLabel3.TabIndex = 109;
            this.ftLabel3.Text = "Is Self Auth";
            // 
            // chkSelfAuth
            // 
            this.chkSelfAuth.AutoSize = true;
            this.chkSelfAuth.Font = new System.Drawing.Font("Tahoma", 8F);
            this.chkSelfAuth.ForeColor = System.Drawing.Color.Black;
            this.chkSelfAuth.Location = new System.Drawing.Point(647, 361);
            this.chkSelfAuth.Name = "chkSelfAuth";
            this.chkSelfAuth.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.chkSelfAuth.Size = new System.Drawing.Size(15, 14);
            this.chkSelfAuth.TabIndex = 102;
            this.chkSelfAuth.UseVisualStyleBackColor = true;
            // 
            // ftLabel4
            // 
            this.ftLabel4.AllowForeColorChange = false;
            this.ftLabel4.AutoSize = true;
            this.ftLabel4.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel4.ForeColor = System.Drawing.Color.Black;
            this.ftLabel4.Location = new System.Drawing.Point(545, 442);
            this.ftLabel4.Name = "ftLabel4";
            this.ftLabel4.OverrideDefault = false;
            this.ftLabel4.Size = new System.Drawing.Size(104, 13);
            this.ftLabel4.TabIndex = 110;
            this.ftLabel4.Text = "Standing Instruction";
            // 
            // ftLabel6
            // 
            this.ftLabel6.AllowForeColorChange = false;
            this.ftLabel6.AutoSize = true;
            this.ftLabel6.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel6.ForeColor = System.Drawing.Color.Black;
            this.ftLabel6.Location = new System.Drawing.Point(279, 443);
            this.ftLabel6.Name = "ftLabel6";
            this.ftLabel6.OverrideDefault = false;
            this.ftLabel6.Size = new System.Drawing.Size(76, 13);
            this.ftLabel6.TabIndex = 114;
            this.ftLabel6.Text = "Tax Deduction";
            // 
            // txtTaxDeductionStatus
            // 
            this.txtTaxDeductionStatus.AllowAlpha = true;
            this.txtTaxDeductionStatus.AllowDot = false;
            this.txtTaxDeductionStatus.AllowedCustomCharacters = null;
            this.txtTaxDeductionStatus.AllowNonASCII = false;
            this.txtTaxDeductionStatus.AllowNumeric = true;
            this.txtTaxDeductionStatus.AllowSpace = false;
            this.txtTaxDeductionStatus.AllowSpecialChars = true;
            this.txtTaxDeductionStatus.BackColor = System.Drawing.SystemColors.Window;
            this.txtTaxDeductionStatus.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTaxDeductionStatus.FocusColor = System.Drawing.Color.LightYellow;
            this.txtTaxDeductionStatus.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtTaxDeductionStatus.ForeColor = System.Drawing.Color.Black;
            this.txtTaxDeductionStatus.IsEmailID = false;
            this.txtTaxDeductionStatus.IsEmailIdValid = false;
            this.txtTaxDeductionStatus.Location = new System.Drawing.Point(358, 440);
            this.txtTaxDeductionStatus.MaxLength = 50;
            this.txtTaxDeductionStatus.Name = "txtTaxDeductionStatus";
            this.txtTaxDeductionStatus.Size = new System.Drawing.Size(138, 20);
            this.txtTaxDeductionStatus.TabIndex = 108;
            this.txtTaxDeductionStatus.Tag = "Code";
            // 
            // chkStandingInstruction
            // 
            this.chkStandingInstruction.AutoSize = true;
            this.chkStandingInstruction.Font = new System.Drawing.Font("Tahoma", 8F);
            this.chkStandingInstruction.ForeColor = System.Drawing.Color.Black;
            this.chkStandingInstruction.Location = new System.Drawing.Point(647, 442);
            this.chkStandingInstruction.Name = "chkStandingInstruction";
            this.chkStandingInstruction.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.chkStandingInstruction.Size = new System.Drawing.Size(15, 14);
            this.chkStandingInstruction.TabIndex = 109;
            this.chkStandingInstruction.UseVisualStyleBackColor = true;
            // 
            // ftLabel5
            // 
            this.ftLabel5.AllowForeColorChange = false;
            this.ftLabel5.AutoSize = true;
            this.ftLabel5.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel5.ForeColor = System.Drawing.Color.Black;
            this.ftLabel5.Location = new System.Drawing.Point(4, 360);
            this.ftLabel5.Name = "ftLabel5";
            this.ftLabel5.OverrideDefault = false;
            this.ftLabel5.Size = new System.Drawing.Size(52, 13);
            this.ftLabel5.TabIndex = 116;
            this.ftLabel5.Text = "Sub Type";
            // 
            // cboSubType
            // 
            this.cboSubType.BackColor = System.Drawing.Color.White;
            this.cboSubType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSubType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboSubType.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboSubType.ForeColor = System.Drawing.Color.Black;
            this.cboSubType.FormattingEnabled = true;
            this.cboSubType.Location = new System.Drawing.Point(76, 357);
            this.cboSubType.Name = "cboSubType";
            this.cboSubType.ReadOnly = false;
            this.cboSubType.Size = new System.Drawing.Size(171, 21);
            this.cboSubType.TabIndex = 100;
            // 
            // ucEntityOthers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.cboSubType);
            this.Controls.Add(this.ftLabel5);
            this.Controls.Add(this.chkStandingInstruction);
            this.Controls.Add(this.ftLabel6);
            this.Controls.Add(this.txtTaxDeductionStatus);
            this.Controls.Add(this.ftLabel4);
            this.Controls.Add(this.ftLabel3);
            this.Controls.Add(this.chkSelfAuth);
            this.Controls.Add(this.ftLabel2);
            this.Controls.Add(this.chPanExempt);
            this.Controls.Add(this.ftLabel1);
            this.Controls.Add(this.cboFacityType);
            this.Controls.Add(this.ftLabel54);
            this.Controls.Add(this.txtUserId);
            this.Controls.Add(this.txtPEP);
            this.Controls.Add(this.txtOccupation);
            this.Controls.Add(this.ftLabel39);
            this.Controls.Add(this.cboPEP);
            this.Controls.Add(this.lblOccupation);
            this.Controls.Add(this.cboOccupation);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.dgIdentityDtls);
            this.Name = "ucEntityOthers";
            this.Size = new System.Drawing.Size(770, 508);
            this.Load += new System.EventHandler(this.ucEntityOthers_Load);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgIdentityDtls)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MatchCommon.CustomControls.FTLabel ftLabel54;
        private MatchCommon.CustomControls.FTTextBox txtUserId;
        private MatchCommon.CustomControls.FTTextBox txtPEP;
        private MatchCommon.CustomControls.FTTextBox txtOccupation;
        private MatchCommon.CustomControls.FTLabel ftLabel39;
        private MatchCommon.CustomControls.FTComboBox cboPEP;
        private MatchCommon.CustomControls.FTLabel lblOccupation;
        private MatchCommon.CustomControls.FTComboBox cboOccupation;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.DateTimePicker dtNetworth;
        private MatchCommon.CustomControls.FTComboBox cboGrossAnnual;
        private System.Windows.Forms.DateTimePicker dtGrossAnnual;
        private MatchCommon.CustomControls.FTTextBox txtNetworth;
        private MatchCommon.CustomControls.FTLabel ftLabel41;
        private MatchCommon.CustomControls.FTLabel ftLabel42;
        private System.Windows.Forms.GroupBox groupBox6;
        private MatchCommon.CustomControls.FTButton btnDelete;
        private MatchCommon.CustomControls.FTButton btnAdd;
        private MatchCommon.CustomControls.FTLabel ftLabel43;
        private System.Windows.Forms.DateTimePicker dtExpiryDate;
        private MatchCommon.CustomControls.FTLabel ftLabel44;
        private System.Windows.Forms.DateTimePicker dtDateOfIssue;
        private MatchCommon.CustomControls.FTLabel ftLabel45;
        private MatchCommon.CustomControls.FTLabel ftLabel46;
        private MatchCommon.CustomControls.FTLabel ftLabel47;
        private MatchCommon.CustomControls.FTTextBox txtPlaceOfIssue;
        private MatchCommon.CustomControls.FTTextBox txtIdentityDetails;
        private MatchCommon.CustomControls.FTComboBox cboIdentityType;
        private MatchCommon.CustomControls.FTDataGrid dgIdentityDtls;
        private MatchCommon.CustomControls.FTLabel ftLabel1;
        private MatchCommon.CustomControls.FTComboBox cboFacityType;
        private MatchCommon.CustomControls.FTCheckBox chPanExempt;
        private MatchCommon.CustomControls.FTLabel ftLabel2;
        private MatchCommon.CustomControls.FTLabel ftLabel3;
        private MatchCommon.CustomControls.FTCheckBox chkSelfAuth;
        private MatchCommon.CustomControls.FTLabel ftLabel4;
        private MatchCommon.CustomControls.FTLabel ftLabel6;
        private MatchCommon.CustomControls.FTTextBox txtTaxDeductionStatus;
        private MatchCommon.CustomControls.FTCheckBox chkStandingInstruction;
        private MatchCommon.CustomControls.FTLabel ftLabel5;
        private MatchCommon.CustomControls.FTComboBox cboSubType;
    }
}
