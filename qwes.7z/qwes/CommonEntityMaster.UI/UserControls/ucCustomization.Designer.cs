﻿namespace FTIL.Match.CDD.UI.UserControls
{
    partial class ucCustomization
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucCustomization));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ftlblGender = new MatchCommon.CustomControls.FTLabel();
            this.cboCustomProduct = new MatchCommon.CustomControls.FTComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnModify = new MatchCommon.CustomControls.FTButton();
            this.btnSave = new MatchCommon.CustomControls.FTButton();
            this.btnRemove = new MatchCommon.CustomControls.FTButton();
            this.btnAdd = new MatchCommon.CustomControls.FTButton();
            this.dgCustomize = new MatchCommon.CustomControls.FTDataGrid();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgCustomize)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ftlblGender);
            this.groupBox1.Controls.Add(this.cboCustomProduct);
            this.groupBox1.Location = new System.Drawing.Point(8, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(761, 46);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // ftlblGender
            // 
            this.ftlblGender.AllowForeColorChange = false;
            this.ftlblGender.AutoSize = true;
            this.ftlblGender.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftlblGender.ForeColor = System.Drawing.Color.Black;
            this.ftlblGender.Location = new System.Drawing.Point(6, 19);
            this.ftlblGender.Name = "ftlblGender";
            this.ftlblGender.OverrideDefault = false;
            this.ftlblGender.Size = new System.Drawing.Size(44, 13);
            this.ftlblGender.TabIndex = 98;
            this.ftlblGender.Text = "Product";
            // 
            // cboCustomProduct
            // 
            this.cboCustomProduct.BackColor = System.Drawing.Color.White;
            this.cboCustomProduct.DisplayMember = "1,2";
            this.cboCustomProduct.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCustomProduct.DropDownWidth = 90;
            this.cboCustomProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboCustomProduct.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboCustomProduct.ForeColor = System.Drawing.Color.Black;
            this.cboCustomProduct.FormattingEnabled = true;
            this.cboCustomProduct.Location = new System.Drawing.Point(59, 16);
            this.cboCustomProduct.Name = "cboCustomProduct";
            this.cboCustomProduct.ReadOnly = false;
            this.cboCustomProduct.Size = new System.Drawing.Size(171, 21);
            this.cboCustomProduct.TabIndex = 94;
            this.cboCustomProduct.ValueMember = "M,F";
            this.cboCustomProduct.SelectedIndexChanged += new System.EventHandler(this.cboCustomProduct_SelectedIndexChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnModify);
            this.groupBox2.Controls.Add(this.btnSave);
            this.groupBox2.Controls.Add(this.btnRemove);
            this.groupBox2.Controls.Add(this.btnAdd);
            this.groupBox2.Location = new System.Drawing.Point(7, 458);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(762, 46);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // btnModify
            // 
            this.btnModify.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnModify.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModify.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnModify.Image = ((System.Drawing.Image)(resources.GetObject("btnModify.Image")));
            this.btnModify.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnModify.Location = new System.Drawing.Point(490, 14);
            this.btnModify.Name = "btnModify";
            this.btnModify.Size = new System.Drawing.Size(84, 25);
            this.btnModify.TabIndex = 142;
            this.btnModify.Text = "&Properties";
            this.btnModify.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnModify.UseVisualStyleBackColor = true;
            this.btnModify.Click += new System.EventHandler(this.btnModify_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Location = new System.Drawing.Point(674, 14);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(84, 25);
            this.btnSave.TabIndex = 141;
            this.btnSave.Text = "&Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.BackColor = System.Drawing.Color.Transparent;
            this.btnRemove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRemove.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnRemove.Image = ((System.Drawing.Image)(resources.GetObject("btnRemove.Image")));
            this.btnRemove.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRemove.Location = new System.Drawing.Point(581, 14);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(84, 25);
            this.btnRemove.TabIndex = 103;
            this.btnRemove.Text = "&Remove";
            this.btnRemove.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRemove.UseVisualStyleBackColor = false;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Transparent;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAdd.Location = new System.Drawing.Point(396, 14);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(84, 25);
            this.btnAdd.TabIndex = 102;
            this.btnAdd.Text = "&Add";
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // dgCustomize
            // 
            this.dgCustomize.AllowEditing = false;
            this.dgCustomize.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
            this.dgCustomize.BackColor = System.Drawing.Color.White;
            this.dgCustomize.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.dgCustomize.ColumnInfo = "5,1,0,0,0,95,Columns:0{Width:30;}\t";
            this.dgCustomize.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
            this.dgCustomize.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dgCustomize.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.dgCustomize.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
            this.dgCustomize.Location = new System.Drawing.Point(8, 54);
            this.dgCustomize.Name = "dgCustomize";
            this.dgCustomize.Styles.EmptyArea.BackColor = System.Drawing.Color.White;
            this.dgCustomize.OverrideDefault = false;
            this.dgCustomize.Rows.Count = 10;
            this.dgCustomize.Rows.DefaultSize = 19;
            this.dgCustomize.Rows.MinSize = 25;
            this.dgCustomize.RowsFilter.AddFilterRow = false;
            this.dgCustomize.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.ListBox;
            this.dgCustomize.Size = new System.Drawing.Size(763, 400);
            this.dgCustomize.StyleInfo = "";
            this.dgCustomize.TabIndex = 4;
            this.dgCustomize.Click += new System.EventHandler(this.dgCustomize_Click);
            this.dgCustomize.DoubleClick += new System.EventHandler(this.dgCustomize_DoubleClick);
            // 
            // ucCustomization
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dgCustomize);
            this.Margin = new System.Windows.Forms.Padding(0);
            this.Name = "ucCustomization";
            this.Size = new System.Drawing.Size(775, 513);
            this.Load += new System.EventHandler(this.usCustomization_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgCustomize)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private MatchCommon.CustomControls.FTComboBox cboCustomProduct;
        private MatchCommon.CustomControls.FTLabel ftlblGender;
        private System.Windows.Forms.GroupBox groupBox2;
        private MatchCommon.CustomControls.FTButton btnRemove;
        private MatchCommon.CustomControls.FTButton btnAdd;
        private MatchCommon.CustomControls.FTButton btnSave;
        protected MatchCommon.CustomControls.FTButton btnModify;
        private MatchCommon.CustomControls.FTDataGrid dgCustomize;
    }
}
