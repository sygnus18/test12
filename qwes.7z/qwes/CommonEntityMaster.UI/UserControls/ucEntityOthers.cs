﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using UCC.Class;
using FTIL.Match.CDD.BAL;
using FTIL.Match.CDD.UI.Forms;
using FTIL.Match.CDD.BAL.DataClasses;
using C1.Win.C1FlexGrid;
using FTIL.Match.Common.Log;

namespace FTIL.Match.CDD.UI.UserControls
{
    public partial class ucEntityOthers :  ucBaseEntity
    {
        //private DataTable dtResult;
        private EntityOthersDtl objOthers;

        private int ColIndex { get; set; }
        private int RowIndex { get; set; }
        DataSet dsResult = null;

        private BindingSource m_GridBindingSource;
        private string m_ProofProvidedSelectedRow;

        public ucEntityOthers()
        {

            InitializeComponent();
            objOthers = new EntityOthersDtl();



            dgIdentityDtls.OverrideDefault = true;
            this.dgIdentityDtls.Cols.Fixed = UIConstants.FlexGridLeftFixColumn;
            dgIdentityDtls.Styles.Normal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dgIdentityDtls.Styles.Alternate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);

            dgIdentityDtls.RowColChange += new System.EventHandler(this.dgIdentityDtls_SelectionChanged);


            m_GridBindingSource = new BindingSource();

            dgIdentityDtls.DataSource = m_GridBindingSource;


        }

        private void ucEntityOthers_Load(object sender, EventArgs e)
        {
            PopulateLookup();
            //if (EntityType == CCMConstants.NON_INDIVIDUAL)
            //{
            //    lblParentDetails.Visible = true;
            //    txtSearchKey.Visible = true;
            //    btnAdvanceSearch.Visible = true;
            //}
            //else
            //{
            //    lblParentDetails.Visible = false;
            //    txtSearchKey.Visible = false;
            //    btnAdvanceSearch.Visible = false;
            //}
            
        }


        public override void PopulateControls()
        {
            if (ModifyMode == false) return;
            try
            {
               
                DataTable dtResult = null;
                CEntityMaster.GetEntityDocDetails(m_EntityDetailsInstance.ClientNo, null, ref dsResult, m_EntityDetailsInstance.StatusNonIndVal);
                objOthers.dtResult = dsResult.Tables[0];
                dtResult = dsResult.Tables[0];
                DataRow[] dr = dtResult.Select("n_Type = " + CCMConstants.CONST_PAN_DOCTYPE);
                chPanExempt.Enabled = !(dr.Length > 0);

                PopulateLookup();
                GridBind();
                dr = dtResult.Select("FileModifiedDateTime=Max(FileModifiedDateTime)");

                if (dtResult.Rows.Count > 0)
                    if(dr.Length>0)
                        objOthers.dLastUpdatedDate = Convert.ToDateTime(dr[0]["FileModifiedDateTime"]);
                else
                {
                    objOthers.dLastUpdatedDate = null;
                    btnAdd.Text = "Add";
                    cboIdentityType.SelectedIndex = -1;
                    txtPlaceOfIssue.Text = "";
                    txtIdentityDetails.Text = "";
                    dtDateOfIssue.Value = System.DateTime.Now.Date;
                    dtExpiryDate.Value = System.DateTime.Now.Date;
                }

                cboOccupation.SetSelectedValue(m_EntityDetailsInstance.Occupation);
                txtIdentityDetails.Text = m_EntityDetailsInstance.OccupationOther;
                cboPEP.SetSelectedValue(m_EntityDetailsInstance.PEP);
                txtPEP.Text = m_EntityDetailsInstance.PEPDesc;

                cboGrossAnnual.SetSelectedValue(m_EntityDetailsInstance.AnnualIncome);

                cboFacityType.SetSelectedValue(m_EntityDetailsInstance.FacilityType);
                if (m_EntityDetailsInstance.FacilityType == "") //change according to CDD phase 2
                { cboFacityType.SelectedIndex = 2; }
                cboSubType.SetSelectedValue(m_EntityDetailsInstance.sSubType);

                if (FormUtil.IsValidDate(m_EntityDetailsInstance.AnnualIncomeDate))
                    dtGrossAnnual.Value = m_EntityDetailsInstance.AnnualIncomeDate.Value;

                if (FormUtil.IsValidDate(m_EntityDetailsInstance.NetworthDate))
                    dtNetworth.Value = m_EntityDetailsInstance.NetworthDate.Value;

                if (m_EntityDetailsInstance.Networth != "" && m_EntityDetailsInstance.Networth != null)
                    txtNetworth.Text = m_EntityDetailsInstance.Networth.Substring(0, m_EntityDetailsInstance.Networth.IndexOf("."));
                else
                    txtNetworth.Text = "";
                txtUserId.Text = m_EntityDetailsInstance.UserId;

                
                chkSelfAuth.Checked = m_EntityDetailsInstance.SelfAuth == "Y";
                txtTaxDeductionStatus.Text = m_EntityDetailsInstance.TaxDeductionStatus;
                //txtSEBIReg.Text = m_EntityDetailsInstance.SEBIRegistration;
                chkStandingInstruction.Checked = m_EntityDetailsInstance.StandingInstruction =="Y";


                if (EntityType == CCMConstants.NON_INDIVIDUAL)
                {
                    lblOccupation.Text = "Industry";
                }

                chPanExempt.Checked = m_EntityDetailsInstance.PANExempt == "Y";
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityOthers), ex.Message);
                MessageBox.Show("Unable to populate other tab details.", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        protected override void PopulateLookup()
        {
            DataTable l_dtCurrentRefData = null;
            DataRow[] dr = null;
            string strType;
            try
            {
                cboFacityType.BackColor = ctrlBackColor;
                cboGrossAnnual.BackColor = ctrlBackColor;
                cboIdentityType.BackColor = ctrlBackColor;
                cboOccupation.BackColor = ctrlBackColor;
                cboPEP.BackColor = ctrlBackColor;

                txtIdentityDetails.BackColor = ctrlBackColor;
                txtNetworth.BackColor = ctrlBackColor;
                //txtOccupation.BackColor = ctrlBackColor;
                //txtPEP.BackColor = ctrlBackColor;
                txtPlaceOfIssue.BackColor = ctrlBackColor;
                txtUserId.BackColor = ctrlBackColor;

                if (m_HasAllDropDownListBind) return;


                cboIdentityType.ValueMember = "s_ReferenceCode";
                cboIdentityType.DisplayMember = "s_ReferenceName";
                cboIdentityType.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.PROOFTYPE];

                cboOccupation.ValueMember = "s_ReferenceCode";
                cboOccupation.DisplayMember = "s_ReferenceName";
                cboOccupation.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.OCCUPATION].WithFirstBlank();

                cboPEP.ValueMember = "s_ReferenceCode";
                cboPEP.DisplayMember = "s_ReferenceName";
                cboPEP.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.PEP];
                if (EntityType == CCMConstants.NON_INDIVIDUAL)
                    dr = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.ANNINC].Select("s_ReferenceSubType = 'NONIND' OR s_ReferenceSubType = 'BOTH'");
                else
                    dr = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.ANNINC].Select("s_ReferenceSubType = 'IND' OR s_ReferenceSubType = 'BOTH'");
                

                l_dtCurrentRefData = new DataTable();
                l_dtCurrentRefData.Columns.Add("n_ReferenceNo");
                l_dtCurrentRefData.Columns.Add("s_ReferenceType");
                l_dtCurrentRefData.Columns.Add("s_ReferenceCode");
                l_dtCurrentRefData.Columns.Add("s_ReferenceName");
                l_dtCurrentRefData.Columns.Add("s_ReferenceSubType");

                
                for (int iCnt = 0; iCnt <= dr.Length - 1; iCnt++)
                    l_dtCurrentRefData.ImportRow(dr[iCnt]);

                l_dtCurrentRefData.WithFirstBlank();

                cboGrossAnnual.ValueMember = "s_ReferenceCode";
                cboGrossAnnual.DisplayMember = "s_ReferenceName";
                cboGrossAnnual.DataSource = l_dtCurrentRefData; // CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.ANNINC].WithFirstBlank();
                           
                cboFacityType.ValueMember = "s_ReferenceCode";
                cboFacityType.DisplayMember = "s_ReferenceName";
                //cboFacityType.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.FACILITY].WithFirstBlank();
                 cboFacityType.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.FACILITY];

                strType = m_EntityDetailsInstance.StatusNonIndVal;
                

                if (dsResult == null)
                    CEntityMaster.GetEntityDocDetails(m_EntityDetailsInstance.ClientNo, null, ref dsResult, m_EntityDetailsInstance.StatusNonIndVal);

                if(dsResult.Tables[1].Rows.Count > 0)
                   dsResult.Tables[1].WithFirstBlank();
                
                cboSubType.ValueMember = "s_SubTypeCode";
                cboSubType.DisplayMember = "s_SubTypeDescription";
                cboSubType.DataSource = dsResult.Tables[1];

                dtDateOfIssue.Value = System.DateTime.Today.Date;
                dtExpiryDate.Value = System.DateTime.Today.Date;

                dtGrossAnnual.MaxDate = System.DateTime.Today.Date;
                dtNetworth.MaxDate = System.DateTime.Today.Date;

                dtDateOfIssue.MaxDate = System.DateTime.Today.Date;

                this.dgIdentityDtls.Cols.Fixed = 0;
                cboIdentityType.SelectedIndex = -1;
                cboOccupation.SelectedIndex = -1;
                cboPEP.SelectedIndex = -1;
                cboGrossAnnual.SelectedIndex = -1;
                cboSubType.SelectedIndex = -1;
                cboFacityType.SelectedIndex = cboFacityType.Items.Count-1;

                m_HasAllDropDownListBind = true;

                if (ModifyMode == false)
                {
                    DataTable dtResult = null;
                    CEntityMaster.GetEntityDocDetails(0, null, ref dsResult);
                    dtResult = dsResult.Tables[0];
                    objOthers.dtResult = dtResult;
                    GridBind();
                    return;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityOthers), ex.Message);
                MessageBox.Show("Unable to populate other tab details", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
           
        }


      
        public EntityOthersDtl EntityDocDetails
        {
            get { return objOthers; }
        }


        public override EntityDetails GetEntityDetails()
        {
            try
            {
                if (m_EntityDetailsInstance == null) return m_EntityDetailsInstance;
                if (isValid())
                {
                    HasUpdated = false;
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.Occupation, cboOccupation.GetSelectedValue());
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.OccupationOther, txtIdentityDetails.Text);
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.PEP, cboOccupation.GetSelectedValue());
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.PEPDesc, txtPEP.Text);
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.AnnualIncome, cboOccupation.GetSelectedValue());
                    if (HasUpdated == false)
                        HasUpdated = m_EntityDetailsInstance.AnnualIncomeDate != dtGrossAnnual.Value;
                    if (HasUpdated == false)
                        HasUpdated = m_EntityDetailsInstance.NetworthDate != dtNetworth.Value;
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.Networth, txtNetworth.Text);
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.UserId, txtUserId.Text);

                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.SelfAuth, chkSelfAuth.Checked ? "Y" : "N");
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.TaxDeductionStatus, txtTaxDeductionStatus.Text);
                    //if (HasUpdated == false)
                        //HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.SEBIRegistration, txtSEBIReg.Text);
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.StandingInstruction, chkStandingInstruction.Checked ? "Y" : "N");

                    m_EntityDetailsInstance.Occupation = cboOccupation.GetSelectedValue();
                    m_EntityDetailsInstance.OccupationOther = txtIdentityDetails.Text;
                    m_EntityDetailsInstance.PEP = cboPEP.GetSelectedValue();
                    m_EntityDetailsInstance.FacilityType = cboFacityType.GetSelectedValue();

                    m_EntityDetailsInstance.PEPDesc = txtPEP.Text;
                    m_EntityDetailsInstance.AnnualIncome = cboGrossAnnual.GetSelectedValue();
                    m_EntityDetailsInstance.AnnualIncomeDate = dtGrossAnnual.Value;
                    m_EntityDetailsInstance.NetworthDate = dtNetworth.Value;
                    m_EntityDetailsInstance.Networth = txtNetworth.Text;
                    m_EntityDetailsInstance.UserId = txtUserId.Text;

                    m_EntityDetailsInstance.PANExempt = chPanExempt.Checked ? "Y" : "N";

                    m_EntityDetailsInstance.SelfAuth = chkSelfAuth.Checked ? "Y" : "N";
                    m_EntityDetailsInstance.TaxDeductionStatus = txtTaxDeductionStatus.Text;
                    m_EntityDetailsInstance.SEBIRegistration = "";//txtSEBIReg.Text;
                    m_EntityDetailsInstance.StandingInstruction = chkStandingInstruction.Checked ? "Y" : "N";
                    m_EntityDetailsInstance.sSubType = cboSubType.GetSelectedValue();
                    //TODO : For Document details Datatable

                    HasUpdated = true;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityOthers), ex.Message);
                MessageBox.Show("Unable to fetch data from other tab data to save", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return m_EntityDetailsInstance;
        }



        public  EntityDetails GetEntityDetails(bool bSupressValidation )
        {
            try
            {
                if (m_EntityDetailsInstance == null) return m_EntityDetailsInstance;

                HasUpdated = false;
                if (HasUpdated == false)
                    HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.Occupation, cboOccupation.GetSelectedValue());
                if (HasUpdated == false)
                    HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.OccupationOther, txtIdentityDetails.Text);
                if (HasUpdated == false)
                    HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.PEP, cboOccupation.GetSelectedValue());
                if (HasUpdated == false)
                    HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.PEPDesc, txtPEP.Text);
                if (HasUpdated == false)
                    HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.AnnualIncome, cboOccupation.GetSelectedValue());
                if (HasUpdated == false)
                    HasUpdated = m_EntityDetailsInstance.AnnualIncomeDate != dtGrossAnnual.Value;
                if (HasUpdated == false)
                    HasUpdated = m_EntityDetailsInstance.NetworthDate != dtNetworth.Value;
                if (HasUpdated == false)
                    HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.Networth, txtNetworth.Text);
                if (HasUpdated == false)
                    HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.UserId, txtUserId.Text);

                m_EntityDetailsInstance.Occupation = cboOccupation.GetSelectedValue();
                m_EntityDetailsInstance.OccupationOther = txtIdentityDetails.Text;
                m_EntityDetailsInstance.PEP = cboPEP.GetSelectedValue();
                m_EntityDetailsInstance.FacilityType = cboFacityType.GetSelectedValue();

                m_EntityDetailsInstance.PEPDesc = txtPEP.Text;
                m_EntityDetailsInstance.AnnualIncome = cboGrossAnnual.GetSelectedValue();
                m_EntityDetailsInstance.AnnualIncomeDate = dtGrossAnnual.Value;
                m_EntityDetailsInstance.NetworthDate = dtNetworth.Value;
                m_EntityDetailsInstance.Networth = txtNetworth.Text;
                m_EntityDetailsInstance.UserId = txtUserId.Text;


                m_EntityDetailsInstance.SelfAuth = chkSelfAuth.Checked ? "Y" : "N";
                m_EntityDetailsInstance.TaxDeductionStatus = txtTaxDeductionStatus.Text;
                //m_EntityDetailsInstance.SEBIRegistration = txtSEBIReg.Text;
                m_EntityDetailsInstance.StandingInstruction = chkStandingInstruction.Checked ? "Y" : "N";
                m_EntityDetailsInstance.sSubType = cboSubType.GetSelectedValue();
                //TODO : For Document details Datatable
                HasUpdated = true;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityOthers), ex.Message);
                MessageBox.Show("Unable to fetch data from other tab data to save", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return m_EntityDetailsInstance;
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (dtDateOfIssue.Value.Date > dtExpiryDate.Value.Date)
            {
                MessageBox.Show("Date Of Issue cannot be greater than Expiry Date.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                dtDateOfIssue.Focus();
                return;
            }
            else
            {
                SyncDataTable();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (cboIdentityType.SelectedIndex >= 0)
                {
                    DataRow[] dr = objOthers.dtResult.Select("n_Type = " + cboIdentityType.SelectedValue);

                    if (dr[0]["s_ProofProvided"].ToString() == "Y")
                    {

                        MessageBox.Show("Can not remove document details since document uploaded."
                              , string.Empty, MessageBoxButtons.OK, MessageBoxIcon.Error);

                        return;
                    }

                    if (MessageBox.Show("Do you want to delete <" + cboIdentityType.Text + ">?", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {

                        if (dr.Length > 0)
                        {
                            objOthers.dtResult.Rows.Remove(dr[0]);
                            GridBind();
                            cboIdentityType.SelectedIndex = 0;
                            txtPlaceOfIssue.Text = "";
                            txtIdentityDetails.Text = "";

                            DataRow[] drPan = objOthers.dtResult.Select("n_Type = " + CCMConstants.CONST_PAN_DOCTYPE);

                            chPanExempt.Enabled = !(drPan.Length > 0);

                            IsOtherGridUpdated = true;
                            this.IsGridUpdated = true;
                            btnAdd.Text = "Add";

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityOthers), ex.Message);
                  MessageBox.Show("Unable to delete data.", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
      
        private void SyncDataTable()
        {
            RowIndex = 0;
            try
            {
                if (isAddValid())
                {

                    objOthers.IdentityType = cboIdentityType.SelectedValue.ToString();

                    if (chPanExempt.Checked && objOthers.IdentityType == CCMConstants.CONST_PAN_DOCTYPE.ToString())
                    {
                        MessageBox.Show("Can not add PAN details since PAN Exempt checked."
                                           , string.Empty, MessageBoxButtons.OK, MessageBoxIcon.Error);

                        return;
                    }
                    if (Convert.ToInt32(cboIdentityType.GetSelectedValue()) == 8)
                    {                       
                        if (txtIdentityDetails.Text.Length != 0)
                        {

                            if (!System.Text.RegularExpressions.Regex.IsMatch(txtIdentityDetails.Text.Trim(), @"^[a-zA-Z]{5}\d{4}[a-zA-Z]{1}$"))
                            {
                                MessageBox.Show("PAN No. should be 10 digit alphanumeric with combination of 5 alpha, next 4 numeric and last one an alpha.", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                txtIdentityDetails.Focus();
                                return ;
                            }

                        }
                    }

                    objOthers.IdentityTypeDetails = txtIdentityDetails.Text;
                    objOthers.PlaceOfIssue = txtPlaceOfIssue.Text;
                    objOthers.ExpiryDate = dtExpiryDate.Value;
                    objOthers.DateOfIssue = dtDateOfIssue.Value;
                    objOthers.ProofProvided = m_ProofProvidedSelectedRow;

                    objOthers.SetDataResult();
                    GridBind();

                    btnAdd.Text = "Add";
                    txtIdentityDetails.Text = string.Empty;
                    txtPlaceOfIssue.Text = string.Empty;
                    cboIdentityType.SelectedIndex = -1;
                    dtDateOfIssue.Value = System.DateTime.Today.Date;
                    dtExpiryDate.Value = System.DateTime.Today.Date;
                }

                DataRow[] dr = objOthers.dtResult.Select("n_Type = " + CCMConstants.CONST_PAN_DOCTYPE);

                chPanExempt.Enabled = !(dr.Length > 0);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityOthers), ex.Message);
                 MessageBox.Show("Unable to sync data.", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        protected override bool isValid()
        {
            string Msg = "";
            string FieldMsg = "";
            try
            {
                m_EntityDetailsInstance.iCount = 0;
                m_EntityDetailsInstance.IsValid = true;
                //FieldMsg += m_EntityDetailsInstance.ValidateField(cboGrossAnnual.SelectedIndex.ToString(), "-1", " Gross Annual,", ref Msg);
                //FieldMsg += m_EntityDetailsInstance.ValidateField(txtNetworth.Text, "", " Networth,", ref Msg);
                //FieldMsg += m_EntityDetailsInstance.ValidateField(dtDateOfIssue.Text, System.DateTime.Today.Date.ToString(), " Date Of Issue,", ref Msg);
                //FieldMsg += m_EntityDetailsInstance.ValidateField(dtExpiryDate.Text, System.DateTime.Today.Date.ToString(), " Expiry Date,", ref Msg);
                //FieldMsg += m_EntityDetailsInstance.ValidateField(dtGrossAnnual.Text, System.DateTime.Today.Date.ToString(), " Gross Annual Date,", ref Msg);
                //FieldMsg += m_EntityDetailsInstance.ValidateField(dtNetworth.Text, System.DateTime.Today.Date.ToString(), " Networth Date,", ref Msg);


                //FieldMsg += m_EntityDetailsInstance.ValidateField(cboPEP.SelectedIndex.ToString(), "-1", " PEP,", ref Msg);
                //FieldMsg += m_EntityDetailsInstance.ValidateField(cboOccupation.SelectedIndex.ToString(), "-1", " Occupation,", ref Msg);
                //FieldMsg += m_EntityDetailsInstance.ValidateField(cboFacityType.SelectedIndex.ToString(), "-1", " Facity Type,", ref Msg);

                //FieldMsg += m_EntityDetailsInstance.ValidateField(txtUserId.Text, "", " UserId,", ref Msg);

                if (FieldMsg != "")
                {
                    FieldMsg = FieldMsg.Remove(FieldMsg.Length - 1);
                    m_EntityDetailsInstance.IsValid = false;
                    MessageBox.Show(FieldMsg + Msg, "", MessageBoxButtons.OK);
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityOthers), ex.Message);
                  MessageBox.Show(ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return FieldMsg == "";
        }

        private void GridBind()
        {
            try
            {
                m_GridBindingSource.DataSource = objOthers.dtResult;
                if (objOthers.dtResult != null)
                {
                    dgIdentityDtls.Cols["n_ClientDocNo"].Visible = false;
                    dgIdentityDtls.Cols["s_DocType"].Visible = false;
                    dgIdentityDtls.Cols["s_HasChanged"].Visible = false;
                    dgIdentityDtls.Cols["FileModifiedDateTime"].Visible = false;


                    dgIdentityDtls.Cols["s_Details"].Caption = "Details";
                    dgIdentityDtls.Cols["d_DateOfIssue"].Caption = "Incorporation / Issue Date";
                    dgIdentityDtls.Cols["d_DateOfExpiry"].Caption = "Commencement / Expiry  Date";
                    dgIdentityDtls.Cols["n_Type"].Caption = "Document";
                    dgIdentityDtls.Cols["s_IssuedPlace"].Caption = "Place Of Issue";
                    dgIdentityDtls.Cols["s_ProofProvided"].Caption = "Proof Provided";
                    dgIdentityDtls.Cols["FileModifiedDateTime"].Caption = "File Modified Date";
                    

                    dgIdentityDtls.Cols["d_DateOfExpiry"].Width = 200;

                    dgIdentityDtls.Cols["n_Type"].DataMap = CReferenceDataProvider.Instance.GetHashTable(CReferenceDataProvider.ReferenceType.PROOFTYPE,
                       CReferenceDataProvider.ReferenceFields.ReferenceName, CReferenceDataProvider.ReferenceFields.ReferenceCode);
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityOthers), ex.Message);
                  MessageBox.Show("Unable to fetch data to bind other details grid", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

 

        private bool isAddValid()
        {
            string Msg = "";
            string FieldMsg = "";

            try
            {
                objOthers.IsVaild = true;
                FieldMsg += ValidateField(cboIdentityType.SelectedIndex.ToString(), "-1", " Idntity Type,", ref Msg);
                FieldMsg += ValidateField(txtIdentityDetails.Text, "", " Idntity Details,", ref Msg);
                FieldMsg += ValidateField(dtDateOfIssue.Text, System.DateTime.Today.Date.ToString(), " Date Of Issue,", ref Msg);
                FieldMsg += ValidateField(txtPlaceOfIssue.Text, "", " Place Of Issue,", ref Msg);
                
                if (FieldMsg != "")
                {
                    FieldMsg = FieldMsg.Remove(FieldMsg.Length - 1);
                    objOthers.IsVaild = false;
                    MessageBox.Show(FieldMsg + Msg, sClientHeaderName, MessageBoxButtons.OK);

                }
                
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityOthers), ex.Message);
                MessageBox.Show(ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return FieldMsg == "";
        }

        private string ValidateField(string FieldVal, string InvalidCiteria, string FieldName, ref string sMsg)
        {
            bool IsVaild;
            string RetVal;
            RetVal = "";
            IsVaild = FieldVal != InvalidCiteria;
            if (!IsVaild)
            {
                RetVal = FieldName;
                sMsg = " is mandatory.";
            }

            return RetVal;
        }
      

        private void dgIdentityDtls_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (dgIdentityDtls.Rows.Selected.Count > 0)
                {
                    Row l_objRow = dgIdentityDtls.Rows.Selected[0];

                    cboIdentityType.SetSelectedValue(l_objRow["n_Type"].ToString());
                    txtIdentityDetails.Text = l_objRow["s_Details"].ToString();
                    txtPlaceOfIssue.Text = l_objRow["s_IssuedPlace"].ToString();
                    dtExpiryDate.Value = l_objRow["d_DateOfExpiry"] != System.DBNull.Value ? Convert.ToDateTime(l_objRow["d_DateOfExpiry"].ToString()) : dtExpiryDate.MaxDate;
                    dtDateOfIssue.Value = l_objRow["d_DateOfIssue"] != System.DBNull.Value ? Convert.ToDateTime(l_objRow["d_DateOfIssue"].ToString()) : dtDateOfIssue.MaxDate;
                    m_ProofProvidedSelectedRow = l_objRow["s_ProofProvided"].ToString();
                    btnAdd.Text = "Modify";

                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityOthers), ex.Message);
                MessageBox.Show(ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public override bool CheckChanges()
        {
            if (this.IsGridUpdated == true) return true;
            try
            {
                if (objOthers.dtResult.Rows.Count == 0) return false;

                DataRow[] dr = objOthers.dtResult.Select("s_HasChanged = 'Y'");
                if (dr.Length > 0)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityOthers), ex.Message);
                MessageBox.Show(ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        public override void ResetDt()
        {
            try
            {
                DataTable dtResult = new DataTable();
                //CEntityMaster.GetEntityBankDetails(m_EntityDetailsInstance.ClientNo, ref dtResult);
                //objOthers.dtResult = dtResult;

                dtResult = objOthers.dtResult;
                for (int iCnt = 0; iCnt <= dtResult.Rows.Count - 1; iCnt++)
                {
                    dtResult.Rows[iCnt]["s_HasChanged"] = "N";

                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityOthers), ex.Message);
            }
        }

        private void cboIdentityType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                txtIdentityDetails.Text = string.Empty;
                txtPlaceOfIssue.Text = string.Empty;
                dtDateOfIssue.Value = System.DateTime.Today.Date;
                dtExpiryDate.Value = System.DateTime.Today.Date;
                btnAdd.Text = "Add";
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityOthers), ex.Message);
                  MessageBox.Show(ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //SetControlBehaviourForPAN();
       
        }

        private void chPanExempt_CheckedChanged(object sender, EventArgs e)
        {   
            //SetControlBehaviourForPAN();
        }

        /// <summary>
        /// Control Behaviour for PAN 
        /// </summary>
        private void SetControlBehaviourForPAN()
        {
            //string sDocType = cboIdentityType.GetSelectedValue();

            //bool flag = true;
       
            //if (sDocType == CCMConstants.CONST_PAN_DOCTYPE.ToString())
            //{
            //    chPanExempt.Enabled = true;
            //    flag = !chPanExempt.Checked;
            //}
            //else
            //    chPanExempt.Enabled = true;

            //txtIdentityDetails.Enabled = flag;
            //txtPlaceOfIssue.Enabled = flag;
            //dtDateOfIssue.Enabled = flag;
            //dtExpiryDate.Enabled = flag;

            //btnAdd.Enabled = flag;
            //btnDelete.Enabled = flag;
        }


        
    }
}

