﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FTIL.Match.CDD.BAL.DataClasses;
using UCC.Class;
using FTIL.Match.CDD.UI.Forms;
using FTIL.Match.Common.Log;
using C1.Win.C1FlexGrid;
using FTIL.Match.CDD.BAL;
using FTIL.Match.Common;

namespace FTIL.Match.CDD.UI.UserControls
{
    public partial class ucEntityAcountNonInd : FTIL.Match.CDD.UI.UserControls.ucBaseEntity
    {
      
        ucAddress objCorrespondenceAddress;
        ucAddress objPermanentAddress;
        private int m_ParentClientNo;

        //public string sName { get; set; }


        public ucEntityAcountNonInd()
        {
            ModifyMode = false;

            InitializeComponent();
            m_EntityDetailsInstance = new EntityDetails();
            objCorrespondenceAddress = new ucAddress();
            objPermanentAddress = new ucAddress();
        }

        public override EntityDetails GetEntityDetails()
        {
            try
            {
                m_EntityDetailsInstance.CorrespondenceAddress = objCorrespondenceAddress.GetAddress();
                if (!chkSameAsCorrs.Checked)
                    m_EntityDetailsInstance.PermanentAddress = objPermanentAddress.GetAddress();

                if (isValid())
                {

                  //  m_EntityDetailsInstance.DOB_OR_DOI = dtDOI.Value;
                   // m_EntityDetailsInstance.Date_of_Declaration = dtCreated.Value;
                  //  m_EntityDetailsInstance.PAN = txtPAN.Text;
                    m_EntityDetailsInstance.PlaceOfIncorpration = txtPOI.Text;
                    m_EntityDetailsInstance.IS_Parent_Accont= chkIsParentAc.Checked == true ? "Y" : "N";
                    m_EntityDetailsInstance.Parent_Account_No = m_ParentClientNo;
                    // m_EntityDetailsInstance.CIN = txtCIN.Text;
                    m_EntityDetailsInstance.StatusText = txtStatus.Text;
                    m_EntityDetailsInstance.StatusNonIndVal = cboClientStatus.GetSelectedValue();


                   // m_EntityDetailsInstance.DateOfBusinessComm = dtCommenctment.Value;

                    m_EntityDetailsInstance.SameCorrPermAdd = chkSameAsCorrs.Checked == true ? "Y" : "N";
                }

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAcountNonInd), ex.Message);
            }
            return m_EntityDetailsInstance;
        }

        private void ucEntityAcountNonInd_Load(object sender, EventArgs e)
        {
            try
            {
                objCorrespondenceAddress.isMandatory = true;
                objPermanentAddress.isMandatory = true;
                objCorrespondenceAddress.Dock = DockStyle.Fill;
                pnlCorrespondenceAdd.Controls.Add(objCorrespondenceAddress);
                pnlCorrespondenceAdd.Tag = objCorrespondenceAddress;

                objPermanentAddress.Dock = DockStyle.Fill;
                pnlParmanentAdd.Controls.Add(objPermanentAddress);
                pnlParmanentAdd.Tag = objPermanentAddress;
                PopulateLookup();

                PopulateControls();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAcountNonInd), ex.Message);
            }
        }

        protected override  void  PopulateLookup()
        {
            try
            {
                cboClientStatus.ValueMember = "s_ReferenceCode";
                cboClientStatus.DisplayMember = "s_ReferenceName";
                cboClientStatus.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.CDDTYPE_NI].WithFirstBlank();


                cboClientStatus.SelectedValue = string.Empty;
                //dtDOI.MaxDate = System.DateTime.Today;
                //dtDOI.CalendarTitleBackColor = System.Drawing.Color.Yellow;

                //txtCIN.BackColor = ctrlBackColor;
                //txtPAN.BackColor = ctrlBackColor;
                txtPOI.BackColor = ctrlBackColor;
                txtStatus.BackColor = ctrlBackColor;
                cboClientStatus.BackColor = ctrlBackColor;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAcountNonInd), ex.Message);
            }
        }

        /// <summary>
        /// Get Entity Details by ClientNo
        /// </summary>
        /// <param name="ClientNo"></param>
        /// <returns></returns>
        //private EntityDetails GetEntityDetails(int ClientNo)
        //{
        //    EntityDetails entityDetails = null;
        //    try
        //    {
        //        DataTable EntityResultDt = null;
        //        DataTable EntityAddrResultDt = null;


        //        //MethodExecResult l_objMethodExceResult = CEntityMaster.GetParentEntitybyClientNo(ClientNo, ref EntityResultDt );
        //        MethodExecResult l_objMethodExceResult = CEntityMaster.GetEntitybyClientNo(ClientNo, ref EntityResultDt, ref EntityAddrResultDt);
        //        if (l_objMethodExceResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
        //        {
        //            Logger.Instance.WriteLog(this, l_objMethodExceResult);
        //            MessageBox.Show(l_objMethodExceResult.ErrorMessage, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
        //        }

        //        entityDetails = CEntityMaster.GetEntityDetailsByDataRow(EntityResultDt.Rows[0], EntityAddrResultDt.Rows[0]);
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.Instance.WriteLog(typeof(ucEntityAcountNonInd), ex.Message);
        //    }
        //    return entityDetails;
        //}


        /// <summary>
        /// Get Entity Details by ClientNo
        /// </summary>
        /// <param name="ClientNo"></param>
        /// <returns></returns>
        private DataTable GetEntityDetails(int ClientNo)
        {
            DataTable EntityResultDt = null;
            try
            {
                MethodExecResult l_objMethodExceResult = CEntityMaster.GetParentEntitybyClientNo(ClientNo, ref EntityResultDt);
                if (l_objMethodExceResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
                {
                    Logger.Instance.WriteLog(this, l_objMethodExceResult);
                    MessageBox.Show(l_objMethodExceResult.ErrorMessage, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAcountNonInd), ex.Message);
            }
            return EntityResultDt;
        }


        public override void PopulateControls()
        {
            try
            {
                if (ModifyMode == false) return;

                //if (FormUtil.IsValidDate(m_EntityDetailsInstance.DOB_OR_DOI))
                //    dtDOI.Value = m_EntityDetailsInstance.DOB_OR_DOI.Value;

                txtPOI.Text = m_EntityDetailsInstance.PlaceOfIncorpration;
                if (m_EntityDetailsInstance.Parent_Account_No > 0)
                {
                    //EntityDetails detail = GetEntityDetails(m_EntityDetailsInstance.Parent_Account_No);
                    //if (detail != null)
                    //{
                    //    detail.ClientNo = m_EntityDetailsInstance.Parent_Account_No;

                    //    txtSearchKey.Text = detail.Applicant_Name;
                    //}
                    DataTable Dt= GetEntityDetails(m_EntityDetailsInstance.Parent_Account_No);              
                    if (Dt.Rows.Count > 0)
                    {
                        txtSearchKey.Text = Convert.ToString(Dt.Rows[0]["s_ClientName"]);
                    }

                }
                   // txtSearchKey.Text = m_EntityDetailsInstance.Parent_Account_No.ToString();
                chkIsParentAc.Checked= m_EntityDetailsInstance.IS_Parent_Accont == "Y";
                //if (FormUtil.IsValidDate(m_EntityDetailsInstance.DateOfCreation))
                //    dtCreated.Value = m_EntityDetailsInstance.DateOfCreation.Value;

                //if (FormUtil.IsValidDate(m_EntityDetailsInstance.DateOfBusinessComm))
                //    dtCommenctment.Value = m_EntityDetailsInstance.DateOfBusinessComm.Value;

                cboClientStatus.SetSelectedValue(m_EntityDetailsInstance.StatusNonIndVal);

                txtStatus.Text = m_EntityDetailsInstance.StatusText;

                //txtCIN.Text = m_EntityDetailsInstance.CIN;
                //txtPAN.Text = m_EntityDetailsInstance.PAN;


                chkSameAsCorrs.Checked = m_EntityDetailsInstance.SameCorrPermAdd == "Y";


                objCorrespondenceAddress.PopupateControls(m_EntityDetailsInstance.CorrespondenceAddress);

                if (!chkSameAsCorrs.Checked)
                    objPermanentAddress.PopupateControls(m_EntityDetailsInstance.PermanentAddress);
                else
                    objPermanentAddress.PopupateControls(m_EntityDetailsInstance.CorrespondenceAddress);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAcountNonInd), ex.Message);
            }
        }


        protected override bool isValid()
        {
            string Msg = "";
            string FieldMsg = "";
            try
            {
                m_EntityDetailsInstance.iCount = 0;
                m_EntityDetailsInstance.IsValid = true;
                FieldMsg += m_EntityDetailsInstance.ValidateField(sName, "", " Name,", ref Msg);
                //FieldMsg += m_EntityDetailsInstance.ValidateField(dtDOI.Text, System.DateTime.Today.Date.ToString(), " DOI,", ref Msg);
                //FieldMsg += m_EntityDetailsInstance.ValidateField(cboClientStatus.SelectedIndex.ToString(), "-1", " Client Status,", ref Msg);
                //FieldMsg += m_EntityDetailsInstance.ValidateField(txtCIN.Text, "", " CIN,", ref Msg);
                //FieldMsg += m_EntityDetailsInstance.ValidateField(txtPAN.Text, "", " PAN,", ref Msg);

                //FieldMsg += m_EntityDetailsInstance.ValidateField(txtPOI.Text, "", " Place of incorporation,", ref Msg);
                //FieldMsg += m_EntityDetailsInstance.ValidateField(dtCommenctment.Text, System.DateTime.Today.Date.ToString(), " Commencement Date,", ref Msg);


                //FieldMsg += m_EntityDetailsInstance.ValidateField(m_EntityDetailsInstance.CorrespondenceAddress.Address_Line1, "", " Correspondence Address,", ref Msg);
                //FieldMsg += m_EntityDetailsInstance.ValidateField(m_EntityDetailsInstance.CorrespondenceAddress.Email_ID, "", " Correspondence Address <Mail>,", ref Msg);
                //FieldMsg += m_EntityDetailsInstance.ValidateField(m_EntityDetailsInstance.CorrespondenceAddress.PIN_Code, "", " Correspondence Address <PIN Code>,", ref Msg);
                //FieldMsg += m_EntityDetailsInstance.ValidateField(m_EntityDetailsInstance.CorrespondenceAddress.Mobile_No, "", "Correspondence Address <Mobile>,", ref Msg);
                //FieldMsg += m_EntityDetailsInstance.ValidateField(m_EntityDetailsInstance.CorrespondenceAddress.City, null, " Correspondence Address <City>,", ref Msg);
                //FieldMsg += m_EntityDetailsInstance.ValidateField(m_EntityDetailsInstance.CorrespondenceAddress.StateCode, null, " Correspondence Address <State>,", ref Msg);
                //FieldMsg += m_EntityDetailsInstance.ValidateField(m_EntityDetailsInstance.CorrespondenceAddress.Country, null, " Correspondence Address <Country>,", ref Msg);

                //if (!chkSameAsCorrs.Checked)
                //{
                //    FieldMsg += m_EntityDetailsInstance.ValidateField(m_EntityDetailsInstance.PermanentAddress.Address_Line1, "", " Permanent Address,", ref Msg);
                //    FieldMsg += m_EntityDetailsInstance.ValidateField(m_EntityDetailsInstance.PermanentAddress.Email_ID, "", " Permanent Address <Mail>,", ref Msg);
                //    FieldMsg += m_EntityDetailsInstance.ValidateField(m_EntityDetailsInstance.PermanentAddress.PIN_Code, "", " Permanent Address <PIN Code>,", ref Msg);
                //    FieldMsg += m_EntityDetailsInstance.ValidateField(m_EntityDetailsInstance.PermanentAddress.Mobile_No, "", " Permanent Address <Mobile>,", ref Msg);
                //    FieldMsg += m_EntityDetailsInstance.ValidateField(m_EntityDetailsInstance.PermanentAddress.City, null, " Permanent Address <City>,", ref Msg);
                //    FieldMsg += m_EntityDetailsInstance.ValidateField(m_EntityDetailsInstance.PermanentAddress.StateCode, null, " Permanent Address <State>,", ref Msg);
                //    FieldMsg += m_EntityDetailsInstance.ValidateField(m_EntityDetailsInstance.PermanentAddress.Country, null, " Permanent Address <Country>,", ref Msg);
                //}

                if (FieldMsg != "")
                {
                    FieldMsg = FieldMsg.Remove(FieldMsg.Length - 1);
                    m_EntityDetailsInstance.IsValid = false;
                    MessageBox.Show(FieldMsg + Msg, sClientHeaderName, MessageBoxButtons.OK);
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAcountNonInd), ex.Message);
            }
            return FieldMsg == "";

        }
        private void chkSameAsCorrs_CheckedChanged(object sender, EventArgs e)
        {
            objPermanentAddress.Enabled = !chkSameAsCorrs.Checked;

            if (chkSameAsCorrs.Checked)
                objPermanentAddress.PopupateControls(objCorrespondenceAddress.GetAddress());
     
        }
        /// Corrospondance Address updated 
        /// </summary>
        public override bool CorrAddressUpdated { get { return objCorrespondenceAddress.HasUpdated; } }


        /// <summary>
        /// Permanent address updated
        /// </summary>
        public override bool PerAddressUpdated { get { return objPermanentAddress .HasUpdated; } }

        private void txtStatus_TextChanged(object sender, EventArgs e)
        {

        }

        private void chkIsParentAc_CheckedChanged(object sender, EventArgs e)
        {
            if (chkIsParentAc.Checked)
            {
                txtSearchKey.Enabled = false;
                btnAdvanceSearch.Enabled = false;
                txtSearchKey.Clear();
            }
            else
            {
                txtSearchKey.Enabled = true;
                btnAdvanceSearch.Enabled = true;
            }
        }

        private void txtSearchKey_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.F3)
                {
                    Row dr = ShowHelp(txtSearchKey.Text.Trim(), false, 8, new string[] { "Name", "KYCCode", "CustID" });
                    if (dr != null)
                        txtSearchKey.Text=Convert.ToString(dr["Name"]);
                

                    else
                        txtSearchKey.Text = "";


                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAcountNonInd), ex.Message);
            }

        }
        



        /// <summary>
        /// To Show Help
        /// </summary>
        /// <param name="key">Search Key</param>
        /// <param name="AdvanceSearch">Flag for advance Search</param>
        /// <returns></returns>
        private Row ShowHelp(string key, bool AdvanceSearch, int HelpType, string[] SearchColumnList)
        {
            string GroupCode = string.Empty;
            Row selectedRow = null;
            int ClientNo = 0;
            try
            {
                frmEntitySearch frmSearch = new frmEntitySearch();
                frmSearch.NotVisibleColumns.Add(CEntityMaster.CLIENTNO);
                frmSearch.SearchKey = key;
                frmSearch.HelpType = HelpType;
                frmSearch.AllowAdvanceSearch = AdvanceSearch;
                frmSearch.Columns = SearchColumnList;
                frmSearch.DefaultSearchColumnIndex = 0;
                frmSearch.IsAddNewEnable = false;

                DialogResult resultDia = frmSearch.ShowDialog();

                if (resultDia == DialogResult.OK)
                {
                    selectedRow = frmSearch.SelectedRow;                  
                    m_ParentClientNo = Convert.ToInt32(selectedRow[CEntityMaster.CLIENTNO]);
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAcountNonInd), ex.Message);
            }
            return selectedRow;
        }

        

        private void txtSearchKey_Leave(object sender, EventArgs e)
        {
            Row dr = ShowHelp(txtSearchKey.Text.Trim(), false,8, new string[] { "Name", "KYCCode", "CustID" });
            if (dr != null)
                txtSearchKey.Text = Convert.ToString(dr["Name"]);
            else
                txtSearchKey.Text = "";
        }

        private void btnAdvanceSearch_Click(object sender, EventArgs e)
        {
            try
            {                
                Row dr = ShowHelp(txtSearchKey.Text.Trim(), false, 8, new string[] { "Name", "KYCCode", "CustID" });
                if (dr != null)
                    txtSearchKey.Text = Convert.ToString(dr["Name"]);
                else
                    txtSearchKey.Text = "";
              
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAcountNonInd), ex.Message);
            }
        }
    }
}
