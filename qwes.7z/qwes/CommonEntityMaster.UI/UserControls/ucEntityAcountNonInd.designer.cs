﻿namespace FTIL.Match.CDD.UI.UserControls
{
    partial class ucEntityAcountNonInd
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucEntityAcountNonInd));
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.pnlParmanentAdd = new System.Windows.Forms.Panel();
            this.ftLabel37 = new MatchCommon.CustomControls.FTLabel();
            this.chkSameAsCorrs = new MatchCommon.CustomControls.FTCheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.pnlCorrespondenceAdd = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnAdvanceSearch = new System.Windows.Forms.Button();
            this.lblParentDetails = new MatchCommon.CustomControls.FTLabel();
            this.txtSearchKey = new MatchCommon.CustomControls.FTTextBox();
            this.chkIsParentAc = new System.Windows.Forms.CheckBox();
            this.txtStatus = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel63 = new MatchCommon.CustomControls.FTLabel();
            this.cboClientStatus = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel59 = new MatchCommon.CustomControls.FTLabel();
            this.txtPOI = new MatchCommon.CustomControls.FTTextBox();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.pnlParmanentAdd);
            this.groupBox3.Controls.Add(this.ftLabel37);
            this.groupBox3.Controls.Add(this.chkSameAsCorrs);
            this.groupBox3.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox3.Location = new System.Drawing.Point(5, 326);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(760, 172);
            this.groupBox3.TabIndex = 75;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Registered Address";
            // 
            // pnlParmanentAdd
            // 
            this.pnlParmanentAdd.Location = new System.Drawing.Point(4, 20);
            this.pnlParmanentAdd.Name = "pnlParmanentAdd";
            this.pnlParmanentAdd.Size = new System.Drawing.Size(753, 150);
            this.pnlParmanentAdd.TabIndex = 49;
            // 
            // ftLabel37
            // 
            this.ftLabel37.AllowForeColorChange = false;
            this.ftLabel37.AutoSize = true;
            this.ftLabel37.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel37.ForeColor = System.Drawing.Color.Black;
            this.ftLabel37.Location = new System.Drawing.Point(223, 0);
            this.ftLabel37.Name = "ftLabel37";
            this.ftLabel37.OverrideDefault = false;
            this.ftLabel37.Size = new System.Drawing.Size(80, 13);
            this.ftLabel37.TabIndex = 47;
            this.ftLabel37.Text = "Same as above";
            // 
            // chkSameAsCorrs
            // 
            this.chkSameAsCorrs.AutoSize = true;
            this.chkSameAsCorrs.Font = new System.Drawing.Font("Tahoma", 8F);
            this.chkSameAsCorrs.ForeColor = System.Drawing.Color.Black;
            this.chkSameAsCorrs.Location = new System.Drawing.Point(206, 0);
            this.chkSameAsCorrs.Name = "chkSameAsCorrs";
            this.chkSameAsCorrs.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.chkSameAsCorrs.Size = new System.Drawing.Size(15, 14);
            this.chkSameAsCorrs.TabIndex = 41;
            this.chkSameAsCorrs.UseVisualStyleBackColor = true;
            this.chkSameAsCorrs.CheckedChanged += new System.EventHandler(this.chkSameAsCorrs_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.pnlCorrespondenceAdd);
            this.groupBox2.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox2.Location = new System.Drawing.Point(5, 133);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(760, 172);
            this.groupBox2.TabIndex = 74;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Correspondence Address";
            // 
            // pnlCorrespondenceAdd
            // 
            this.pnlCorrespondenceAdd.Location = new System.Drawing.Point(4, 19);
            this.pnlCorrespondenceAdd.Name = "pnlCorrespondenceAdd";
            this.pnlCorrespondenceAdd.Size = new System.Drawing.Size(753, 150);
            this.pnlCorrespondenceAdd.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnAdvanceSearch);
            this.groupBox1.Controls.Add(this.lblParentDetails);
            this.groupBox1.Controls.Add(this.txtSearchKey);
            this.groupBox1.Controls.Add(this.chkIsParentAc);
            this.groupBox1.Controls.Add(this.txtStatus);
            this.groupBox1.Controls.Add(this.ftLabel63);
            this.groupBox1.Controls.Add(this.cboClientStatus);
            this.groupBox1.Controls.Add(this.ftLabel59);
            this.groupBox1.Controls.Add(this.txtPOI);
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox1.Location = new System.Drawing.Point(5, -6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(760, 118);
            this.groupBox1.TabIndex = 73;
            this.groupBox1.TabStop = false;
            // 
            // btnAdvanceSearch
            // 
            this.btnAdvanceSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdvanceSearch.Image = ((System.Drawing.Image)(resources.GetObject("btnAdvanceSearch.Image")));
            this.btnAdvanceSearch.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnAdvanceSearch.Location = new System.Drawing.Point(690, 29);
            this.btnAdvanceSearch.Name = "btnAdvanceSearch";
            this.btnAdvanceSearch.Size = new System.Drawing.Size(66, 24);
            this.btnAdvanceSearch.TabIndex = 122;
            this.btnAdvanceSearch.Text = "Search";
            this.btnAdvanceSearch.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.btnAdvanceSearch.UseVisualStyleBackColor = true;
            this.btnAdvanceSearch.Click += new System.EventHandler(this.btnAdvanceSearch_Click);
            // 
            // lblParentDetails
            // 
            this.lblParentDetails.AllowForeColorChange = false;
            this.lblParentDetails.AutoSize = true;
            this.lblParentDetails.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblParentDetails.ForeColor = System.Drawing.Color.Black;
            this.lblParentDetails.Location = new System.Drawing.Point(361, 33);
            this.lblParentDetails.Name = "lblParentDetails";
            this.lblParentDetails.OverrideDefault = false;
            this.lblParentDetails.Size = new System.Drawing.Size(74, 13);
            this.lblParentDetails.TabIndex = 121;
            this.lblParentDetails.Text = "Parent Details";
            // 
            // txtSearchKey
            // 
            this.txtSearchKey.AllowAlpha = true;
            this.txtSearchKey.AllowDot = true;
            this.txtSearchKey.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtSearchKey.AllowedCustomCharacters")));
            this.txtSearchKey.AllowNonASCII = true;
            this.txtSearchKey.AllowNumeric = true;
            this.txtSearchKey.AllowSpace = true;
            this.txtSearchKey.AllowSpecialChars = true;
            this.txtSearchKey.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtSearchKey.FocusColor = System.Drawing.Color.LightYellow;
            this.txtSearchKey.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtSearchKey.ForeColor = System.Drawing.Color.Black;
            this.txtSearchKey.IsEmailID = false;
            this.txtSearchKey.IsEmailIdValid = false;
            this.txtSearchKey.Location = new System.Drawing.Point(440, 29);
            this.txtSearchKey.MaxLength = 255;
            this.txtSearchKey.Name = "txtSearchKey";
            this.txtSearchKey.Size = new System.Drawing.Size(245, 20);
            this.txtSearchKey.TabIndex = 120;
            this.txtSearchKey.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtSearchKey_KeyUp);
            this.txtSearchKey.Leave += new System.EventHandler(this.txtSearchKey_Leave);
            // 
            // chkIsParentAc
            // 
            this.chkIsParentAc.AutoSize = true;
            this.chkIsParentAc.Location = new System.Drawing.Point(256, 33);
            this.chkIsParentAc.Name = "chkIsParentAc";
            this.chkIsParentAc.Size = new System.Drawing.Size(91, 17);
            this.chkIsParentAc.TabIndex = 86;
            this.chkIsParentAc.Text = "Is Parent A/C";
            this.chkIsParentAc.UseVisualStyleBackColor = true;
            this.chkIsParentAc.CheckedChanged += new System.EventHandler(this.chkIsParentAc_CheckedChanged);
            // 
            // txtStatus
            // 
            this.txtStatus.AllowAlpha = true;
            this.txtStatus.AllowDot = false;
            this.txtStatus.AllowedCustomCharacters = null;
            this.txtStatus.AllowNonASCII = false;
            this.txtStatus.AllowNumeric = true;
            this.txtStatus.AllowSpace = false;
            this.txtStatus.AllowSpecialChars = true;
            this.txtStatus.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtStatus.FocusColor = System.Drawing.Color.LightYellow;
            this.txtStatus.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtStatus.ForeColor = System.Drawing.Color.Black;
            this.txtStatus.IsEmailID = false;
            this.txtStatus.IsEmailIdValid = false;
            this.txtStatus.Location = new System.Drawing.Point(256, 77);
            this.txtStatus.MaxLength = 200;
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(501, 20);
            this.txtStatus.TabIndex = 79;
            this.txtStatus.Tag = "Code";
            this.txtStatus.TextChanged += new System.EventHandler(this.txtStatus_TextChanged);
            // 
            // ftLabel63
            // 
            this.ftLabel63.AllowForeColorChange = false;
            this.ftLabel63.AutoSize = true;
            this.ftLabel63.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel63.ForeColor = System.Drawing.Color.Black;
            this.ftLabel63.Location = new System.Drawing.Point(6, 80);
            this.ftLabel63.Name = "ftLabel63";
            this.ftLabel63.OverrideDefault = false;
            this.ftLabel63.Size = new System.Drawing.Size(31, 13);
            this.ftLabel63.TabIndex = 85;
            this.ftLabel63.Text = "Type";
            // 
            // cboClientStatus
            // 
            this.cboClientStatus.BackColor = System.Drawing.Color.White;
            this.cboClientStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboClientStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboClientStatus.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboClientStatus.ForeColor = System.Drawing.Color.Black;
            this.cboClientStatus.FormattingEnabled = true;
            this.cboClientStatus.Location = new System.Drawing.Point(83, 77);
            this.cboClientStatus.Name = "cboClientStatus";
            this.cboClientStatus.ReadOnly = false;
            this.cboClientStatus.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.cboClientStatus.Size = new System.Drawing.Size(163, 21);
            this.cboClientStatus.TabIndex = 78;
            // 
            // ftLabel59
            // 
            this.ftLabel59.AllowForeColorChange = false;
            this.ftLabel59.AutoSize = true;
            this.ftLabel59.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel59.ForeColor = System.Drawing.Color.Black;
            this.ftLabel59.Location = new System.Drawing.Point(6, 33);
            this.ftLabel59.Name = "ftLabel59";
            this.ftLabel59.OverrideDefault = false;
            this.ftLabel59.Size = new System.Drawing.Size(72, 26);
            this.ftLabel59.TabIndex = 77;
            this.ftLabel59.Text = "Place of\r\nIncorporation";
            // 
            // txtPOI
            // 
            this.txtPOI.AllowAlpha = true;
            this.txtPOI.AllowDot = false;
            this.txtPOI.AllowedCustomCharacters = null;
            this.txtPOI.AllowNonASCII = false;
            this.txtPOI.AllowNumeric = true;
            this.txtPOI.AllowSpace = false;
            this.txtPOI.AllowSpecialChars = true;
            this.txtPOI.BackColor = System.Drawing.SystemColors.Window;
            this.txtPOI.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPOI.FocusColor = System.Drawing.Color.LightYellow;
            this.txtPOI.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtPOI.ForeColor = System.Drawing.Color.Black;
            this.txtPOI.IsEmailID = false;
            this.txtPOI.IsEmailIdValid = false;
            this.txtPOI.Location = new System.Drawing.Point(83, 29);
            this.txtPOI.MaxLength = 100;
            this.txtPOI.Name = "txtPOI";
            this.txtPOI.Size = new System.Drawing.Size(163, 20);
            this.txtPOI.TabIndex = 76;
            this.txtPOI.Tag = "Code";
            // 
            // ucEntityAcountNonInd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "ucEntityAcountNonInd";
            this.Size = new System.Drawing.Size(768, 513);
            this.Load += new System.EventHandler(this.ucEntityAcountNonInd_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private MatchCommon.CustomControls.FTLabel ftLabel37;
        private MatchCommon.CustomControls.FTCheckBox chkSameAsCorrs;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private MatchCommon.CustomControls.FTTextBox txtStatus;
        private MatchCommon.CustomControls.FTLabel ftLabel63;
        private MatchCommon.CustomControls.FTComboBox cboClientStatus;
        private MatchCommon.CustomControls.FTLabel ftLabel59;
        private MatchCommon.CustomControls.FTTextBox txtPOI;
        private System.Windows.Forms.Panel pnlCorrespondenceAdd;
        private System.Windows.Forms.Panel pnlParmanentAdd;
        private System.Windows.Forms.CheckBox chkIsParentAc;
        private System.Windows.Forms.Button btnAdvanceSearch;
        private MatchCommon.CustomControls.FTLabel lblParentDetails;
        private MatchCommon.CustomControls.FTTextBox txtSearchKey;
    }
}
