﻿namespace FTIL.Match.CDD.UI.UserControls
{
    partial class ucODINPreferences
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucODINPreferences));
            this.lblParentAC = new System.Windows.Forms.Label();
            this.cboParentAC = new System.Windows.Forms.ComboBox();
            this.lblNnDVPBrok = new System.Windows.Forms.Label();
            this.lblDVPBrok = new System.Windows.Forms.Label();
            this.txtBroerageNonDVP = new MatchCommon.CustomControls.FTTextBox();
            this.txtBrokerageDVP = new MatchCommon.CustomControls.FTTextBox();
            this.lblGroupAdmin = new System.Windows.Forms.Label();
            this.cboGroupAdmin = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cboCategory = new System.Windows.Forms.ComboBox();
            this.lblCategory = new System.Windows.Forms.Label();
            this.cboConnectionMode = new System.Windows.Forms.ComboBox();
            this.lblConnectionMode = new System.Windows.Forms.Label();
            this.cboPartType = new System.Windows.Forms.ComboBox();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.cboProductType = new System.Windows.Forms.ComboBox();
            this.lblPartType = new System.Windows.Forms.Label();
            this.lblProductType = new System.Windows.Forms.Label();
            this.txtTopMargin = new MatchCommon.CustomControls.FTTextBox();
            this.lblTopMargin = new System.Windows.Forms.Label();
            this.gbTradingDetails = new System.Windows.Forms.GroupBox();
            this.txtMaxBcastScripsAllowed = new MatchCommon.CustomControls.FTTextBox();
            this.txtNoOfOrdersPerSec = new MatchCommon.CustomControls.FTTextBox();
            this.txtBrokeragePer = new MatchCommon.CustomControls.FTTextBox();
            this.txtClientIPAddr = new MatchCommon.CustomControls.FTTextBox();
            this.lblBrokeragePer = new System.Windows.Forms.Label();
            this.lblClientIPAddress = new System.Windows.Forms.Label();
            this.chkMaxBcastStripsAllowed = new System.Windows.Forms.CheckBox();
            this.chkNoOfOrderPerSec = new System.Windows.Forms.CheckBox();
            this.gbSecurities = new System.Windows.Forms.GroupBox();
            this.chkSecuritiesGroup = new System.Windows.Forms.CheckBox();
            this.chkSecuritiesAll = new System.Windows.Forms.CheckBox();
            this.cboSecOptionType = new System.Windows.Forms.ComboBox();
            this.lblOptType = new System.Windows.Forms.Label();
            this.cboStrikePrice = new System.Windows.Forms.ComboBox();
            this.dtSecExpiryDate = new System.Windows.Forms.DateTimePicker();
            this.lblStrikePr = new System.Windows.Forms.Label();
            this.lblExpDate = new System.Windows.Forms.Label();
            this.lblInstrName = new System.Windows.Forms.Label();
            this.txtSecInstrName = new MatchCommon.CustomControls.FTTextBox();
            this.textBox27 = new MatchCommon.CustomControls.FTTextBox();
            this.lblSeries = new System.Windows.Forms.Label();
            this.txtSecSeries = new MatchCommon.CustomControls.FTTextBox();
            this.lblSymbol = new System.Windows.Forms.Label();
            this.txtSecSymbolId = new MatchCommon.CustomControls.FTTextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtSecurityCode = new MatchCommon.CustomControls.FTTextBox();
            this.gbOrdrLmt = new System.Windows.Forms.GroupBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.lblMinVal = new System.Windows.Forms.Label();
            this.txtOrderLimitMinVal = new MatchCommon.CustomControls.FTTextBox();
            this.lblMinQty = new System.Windows.Forms.Label();
            this.txtOrderLimitsMinQty = new MatchCommon.CustomControls.FTTextBox();
            this.lblPendingOrdLmt = new System.Windows.Forms.Label();
            this.txtPendingOrderLimit = new MatchCommon.CustomControls.FTTextBox();
            this.lblMaxValue = new System.Windows.Forms.Label();
            this.txtOrderLimitMaxVal = new MatchCommon.CustomControls.FTTextBox();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.txtOrderLimitQty = new MatchCommon.CustomControls.FTTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.chkListPreferences = new System.Windows.Forms.CheckedListBox();
            this.gbUserDetails = new System.Windows.Forms.GroupBox();
            this.cboMainAC = new System.Windows.Forms.ComboBox();
            this.lblMainAc = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.gbTradingDetails.SuspendLayout();
            this.gbSecurities.SuspendLayout();
            this.gbOrdrLmt.SuspendLayout();
            this.gbUserDetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblParentAC
            // 
            this.lblParentAC.AutoSize = true;
            this.lblParentAC.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParentAC.Location = new System.Drawing.Point(245, 357);
            this.lblParentAC.Name = "lblParentAC";
            this.lblParentAC.Size = new System.Drawing.Size(58, 13);
            this.lblParentAC.TabIndex = 8;
            this.lblParentAC.Text = "Parent A/c";
            this.lblParentAC.Visible = false;
            // 
            // cboParentAC
            // 
            this.cboParentAC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboParentAC.FormattingEnabled = true;
            this.cboParentAC.Location = new System.Drawing.Point(327, 354);
            this.cboParentAC.Name = "cboParentAC";
            this.cboParentAC.Size = new System.Drawing.Size(135, 21);
            this.cboParentAC.TabIndex = 9;
            this.cboParentAC.Visible = false;
            // 
            // lblNnDVPBrok
            // 
            this.lblNnDVPBrok.AutoSize = true;
            this.lblNnDVPBrok.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNnDVPBrok.Location = new System.Drawing.Point(6, 377);
            this.lblNnDVPBrok.Name = "lblNnDVPBrok";
            this.lblNnDVPBrok.Size = new System.Drawing.Size(70, 26);
            this.lblNnDVPBrok.TabIndex = 25;
            this.lblNnDVPBrok.Text = "Brokerage %\r\n(Non-DVP)";
            this.lblNnDVPBrok.Visible = false;
            // 
            // lblDVPBrok
            // 
            this.lblDVPBrok.AutoSize = true;
            this.lblDVPBrok.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDVPBrok.Location = new System.Drawing.Point(245, 380);
            this.lblDVPBrok.Name = "lblDVPBrok";
            this.lblDVPBrok.Size = new System.Drawing.Size(70, 26);
            this.lblDVPBrok.TabIndex = 23;
            this.lblDVPBrok.Text = "Brokerage %\r\n(DVP)";
            this.lblDVPBrok.Visible = false;
            // 
            // txtBroerageNonDVP
            // 
            this.txtBroerageNonDVP.AllowAlpha = true;
            this.txtBroerageNonDVP.AllowDot = true;
            this.txtBroerageNonDVP.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtBroerageNonDVP.AllowedCustomCharacters")));
            this.txtBroerageNonDVP.AllowNonASCII = false;
            this.txtBroerageNonDVP.AllowNumeric = true;
            this.txtBroerageNonDVP.AllowSpace = true;
            this.txtBroerageNonDVP.AllowSpecialChars = true;
            this.txtBroerageNonDVP.FocusColor = System.Drawing.Color.LightYellow;
            this.txtBroerageNonDVP.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtBroerageNonDVP.ForeColor = System.Drawing.Color.Black;
            this.txtBroerageNonDVP.IsEmailID = false;
            this.txtBroerageNonDVP.IsEmailIdValid = false;
            this.txtBroerageNonDVP.Location = new System.Drawing.Point(88, 377);
            this.txtBroerageNonDVP.Name = "txtBroerageNonDVP";
            this.txtBroerageNonDVP.Size = new System.Drawing.Size(135, 20);
            this.txtBroerageNonDVP.TabIndex = 26;
            this.txtBroerageNonDVP.Visible = false;
            // 
            // txtBrokerageDVP
            // 
            this.txtBrokerageDVP.AllowAlpha = true;
            this.txtBrokerageDVP.AllowDot = true;
            this.txtBrokerageDVP.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtBrokerageDVP.AllowedCustomCharacters")));
            this.txtBrokerageDVP.AllowNonASCII = false;
            this.txtBrokerageDVP.AllowNumeric = true;
            this.txtBrokerageDVP.AllowSpace = true;
            this.txtBrokerageDVP.AllowSpecialChars = true;
            this.txtBrokerageDVP.FocusColor = System.Drawing.Color.LightYellow;
            this.txtBrokerageDVP.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtBrokerageDVP.ForeColor = System.Drawing.Color.Black;
            this.txtBrokerageDVP.IsEmailID = false;
            this.txtBrokerageDVP.IsEmailIdValid = false;
            this.txtBrokerageDVP.Location = new System.Drawing.Point(328, 380);
            this.txtBrokerageDVP.Name = "txtBrokerageDVP";
            this.txtBrokerageDVP.Size = new System.Drawing.Size(135, 20);
            this.txtBrokerageDVP.TabIndex = 24;
            this.txtBrokerageDVP.Visible = false;
            // 
            // lblGroupAdmin
            // 
            this.lblGroupAdmin.AutoSize = true;
            this.lblGroupAdmin.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGroupAdmin.Location = new System.Drawing.Point(10, 357);
            this.lblGroupAdmin.Name = "lblGroupAdmin";
            this.lblGroupAdmin.Size = new System.Drawing.Size(68, 13);
            this.lblGroupAdmin.TabIndex = 16;
            this.lblGroupAdmin.Text = "Group Admin";
            this.lblGroupAdmin.Visible = false;
            // 
            // cboGroupAdmin
            // 
            this.cboGroupAdmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboGroupAdmin.FormattingEnabled = true;
            this.cboGroupAdmin.Items.AddRange(new object[] {
            "HO"});
            this.cboGroupAdmin.Location = new System.Drawing.Point(86, 354);
            this.cboGroupAdmin.Name = "cboGroupAdmin";
            this.cboGroupAdmin.Size = new System.Drawing.Size(135, 21);
            this.cboGroupAdmin.TabIndex = 17;
            this.cboGroupAdmin.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cboCategory);
            this.groupBox1.Controls.Add(this.lblCategory);
            this.groupBox1.Controls.Add(this.cboConnectionMode);
            this.groupBox1.Controls.Add(this.lblConnectionMode);
            this.groupBox1.Controls.Add(this.cboPartType);
            this.groupBox1.Controls.Add(this.comboBox10);
            this.groupBox1.Controls.Add(this.cboProductType);
            this.groupBox1.Controls.Add(this.lblPartType);
            this.groupBox1.Controls.Add(this.lblProductType);
            this.groupBox1.Controls.Add(this.txtTopMargin);
            this.groupBox1.Controls.Add(this.lblTopMargin);
            this.groupBox1.Location = new System.Drawing.Point(9, 14);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(471, 105);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            // 
            // cboCategory
            // 
            this.cboCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboCategory.FormattingEnabled = true;
            this.cboCategory.Location = new System.Drawing.Point(322, 15);
            this.cboCategory.Name = "cboCategory";
            this.cboCategory.Size = new System.Drawing.Size(135, 21);
            this.cboCategory.TabIndex = 43;
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.lblCategory.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategory.Location = new System.Drawing.Point(240, 18);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(52, 13);
            this.lblCategory.TabIndex = 42;
            this.lblCategory.Text = "Category";
            // 
            // cboConnectionMode
            // 
            this.cboConnectionMode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboConnectionMode.FormattingEnabled = true;
            this.cboConnectionMode.Location = new System.Drawing.Point(81, 15);
            this.cboConnectionMode.Name = "cboConnectionMode";
            this.cboConnectionMode.Size = new System.Drawing.Size(135, 21);
            this.cboConnectionMode.TabIndex = 39;
            // 
            // lblConnectionMode
            // 
            this.lblConnectionMode.AutoSize = true;
            this.lblConnectionMode.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConnectionMode.Location = new System.Drawing.Point(4, 18);
            this.lblConnectionMode.Name = "lblConnectionMode";
            this.lblConnectionMode.Size = new System.Drawing.Size(61, 26);
            this.lblConnectionMode.TabIndex = 38;
            this.lblConnectionMode.Text = "Connection\r\nMode";
            // 
            // cboPartType
            // 
            this.cboPartType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboPartType.FormattingEnabled = true;
            this.cboPartType.Location = new System.Drawing.Point(81, 77);
            this.cboPartType.Name = "cboPartType";
            this.cboPartType.Size = new System.Drawing.Size(135, 21);
            this.cboPartType.TabIndex = 37;
            // 
            // comboBox10
            // 
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Location = new System.Drawing.Point(265, -123);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(104, 21);
            this.comboBox10.TabIndex = 36;
            // 
            // cboProductType
            // 
            this.cboProductType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboProductType.FormattingEnabled = true;
            this.cboProductType.Location = new System.Drawing.Point(81, 46);
            this.cboProductType.Name = "cboProductType";
            this.cboProductType.Size = new System.Drawing.Size(135, 21);
            this.cboProductType.TabIndex = 34;
            // 
            // lblPartType
            // 
            this.lblPartType.AutoSize = true;
            this.lblPartType.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPartType.Location = new System.Drawing.Point(4, 80);
            this.lblPartType.Name = "lblPartType";
            this.lblPartType.Size = new System.Drawing.Size(54, 13);
            this.lblPartType.TabIndex = 35;
            this.lblPartType.Text = "Part Type";
            // 
            // lblProductType
            // 
            this.lblProductType.AutoSize = true;
            this.lblProductType.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductType.Location = new System.Drawing.Point(4, 49);
            this.lblProductType.Name = "lblProductType";
            this.lblProductType.Size = new System.Drawing.Size(71, 13);
            this.lblProductType.TabIndex = 33;
            this.lblProductType.Text = "Product Type";
            // 
            // txtTopMargin
            // 
            this.txtTopMargin.AllowAlpha = true;
            this.txtTopMargin.AllowDot = true;
            this.txtTopMargin.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtTopMargin.AllowedCustomCharacters")));
            this.txtTopMargin.AllowNonASCII = false;
            this.txtTopMargin.AllowNumeric = true;
            this.txtTopMargin.AllowSpace = true;
            this.txtTopMargin.AllowSpecialChars = true;
            this.txtTopMargin.FocusColor = System.Drawing.Color.LightYellow;
            this.txtTopMargin.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtTopMargin.ForeColor = System.Drawing.Color.Black;
            this.txtTopMargin.IsEmailID = false;
            this.txtTopMargin.IsEmailIdValid = false;
            this.txtTopMargin.Location = new System.Drawing.Point(322, 45);
            this.txtTopMargin.Name = "txtTopMargin";
            this.txtTopMargin.Size = new System.Drawing.Size(135, 20);
            this.txtTopMargin.TabIndex = 28;
            // 
            // lblTopMargin
            // 
            this.lblTopMargin.AutoSize = true;
            this.lblTopMargin.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTopMargin.Location = new System.Drawing.Point(240, 49);
            this.lblTopMargin.Name = "lblTopMargin";
            this.lblTopMargin.Size = new System.Drawing.Size(60, 13);
            this.lblTopMargin.TabIndex = 27;
            this.lblTopMargin.Text = "Top Margin";
            // 
            // gbTradingDetails
            // 
            this.gbTradingDetails.Controls.Add(this.txtMaxBcastScripsAllowed);
            this.gbTradingDetails.Controls.Add(this.txtNoOfOrdersPerSec);
            this.gbTradingDetails.Controls.Add(this.txtBrokeragePer);
            this.gbTradingDetails.Controls.Add(this.txtClientIPAddr);
            this.gbTradingDetails.Controls.Add(this.lblBrokeragePer);
            this.gbTradingDetails.Controls.Add(this.lblClientIPAddress);
            this.gbTradingDetails.Controls.Add(this.chkMaxBcastStripsAllowed);
            this.gbTradingDetails.Controls.Add(this.chkNoOfOrderPerSec);
            this.gbTradingDetails.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.gbTradingDetails.Location = new System.Drawing.Point(8, 125);
            this.gbTradingDetails.Name = "gbTradingDetails";
            this.gbTradingDetails.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gbTradingDetails.Size = new System.Drawing.Size(729, 75);
            this.gbTradingDetails.TabIndex = 34;
            this.gbTradingDetails.TabStop = false;
            this.gbTradingDetails.Text = "Trading Details";
            // 
            // txtMaxBcastScripsAllowed
            // 
            this.txtMaxBcastScripsAllowed.AllowAlpha = true;
            this.txtMaxBcastScripsAllowed.AllowDot = true;
            this.txtMaxBcastScripsAllowed.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtMaxBcastScripsAllowed.AllowedCustomCharacters")));
            this.txtMaxBcastScripsAllowed.AllowNonASCII = false;
            this.txtMaxBcastScripsAllowed.AllowNumeric = true;
            this.txtMaxBcastScripsAllowed.AllowSpace = true;
            this.txtMaxBcastScripsAllowed.AllowSpecialChars = true;
            this.txtMaxBcastScripsAllowed.FocusColor = System.Drawing.Color.LightYellow;
            this.txtMaxBcastScripsAllowed.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtMaxBcastScripsAllowed.ForeColor = System.Drawing.Color.Black;
            this.txtMaxBcastScripsAllowed.IsEmailID = false;
            this.txtMaxBcastScripsAllowed.IsEmailIdValid = false;
            this.txtMaxBcastScripsAllowed.Location = new System.Drawing.Point(162, 45);
            this.txtMaxBcastScripsAllowed.Name = "txtMaxBcastScripsAllowed";
            this.txtMaxBcastScripsAllowed.Size = new System.Drawing.Size(135, 20);
            this.txtMaxBcastScripsAllowed.TabIndex = 42;
            // 
            // txtNoOfOrdersPerSec
            // 
            this.txtNoOfOrdersPerSec.AllowAlpha = true;
            this.txtNoOfOrdersPerSec.AllowDot = true;
            this.txtNoOfOrdersPerSec.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtNoOfOrdersPerSec.AllowedCustomCharacters")));
            this.txtNoOfOrdersPerSec.AllowNonASCII = false;
            this.txtNoOfOrdersPerSec.AllowNumeric = true;
            this.txtNoOfOrdersPerSec.AllowSpace = true;
            this.txtNoOfOrdersPerSec.AllowSpecialChars = true;
            this.txtNoOfOrdersPerSec.FocusColor = System.Drawing.Color.LightYellow;
            this.txtNoOfOrdersPerSec.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtNoOfOrdersPerSec.ForeColor = System.Drawing.Color.Black;
            this.txtNoOfOrdersPerSec.IsEmailID = false;
            this.txtNoOfOrdersPerSec.IsEmailIdValid = false;
            this.txtNoOfOrdersPerSec.Location = new System.Drawing.Point(162, 16);
            this.txtNoOfOrdersPerSec.Name = "txtNoOfOrdersPerSec";
            this.txtNoOfOrdersPerSec.Size = new System.Drawing.Size(135, 20);
            this.txtNoOfOrdersPerSec.TabIndex = 41;
            // 
            // txtBrokeragePer
            // 
            this.txtBrokeragePer.AllowAlpha = true;
            this.txtBrokeragePer.AllowDot = true;
            this.txtBrokeragePer.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtBrokeragePer.AllowedCustomCharacters")));
            this.txtBrokeragePer.AllowNonASCII = false;
            this.txtBrokeragePer.AllowNumeric = true;
            this.txtBrokeragePer.AllowSpace = true;
            this.txtBrokeragePer.AllowSpecialChars = true;
            this.txtBrokeragePer.FocusColor = System.Drawing.Color.LightYellow;
            this.txtBrokeragePer.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtBrokeragePer.ForeColor = System.Drawing.Color.Black;
            this.txtBrokeragePer.IsEmailID = false;
            this.txtBrokeragePer.IsEmailIdValid = false;
            this.txtBrokeragePer.Location = new System.Drawing.Point(443, 45);
            this.txtBrokeragePer.Name = "txtBrokeragePer";
            this.txtBrokeragePer.Size = new System.Drawing.Size(48, 20);
            this.txtBrokeragePer.TabIndex = 40;
            this.txtBrokeragePer.Visible = false;
            // 
            // txtClientIPAddr
            // 
            this.txtClientIPAddr.AllowAlpha = true;
            this.txtClientIPAddr.AllowDot = true;
            this.txtClientIPAddr.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtClientIPAddr.AllowedCustomCharacters")));
            this.txtClientIPAddr.AllowNonASCII = false;
            this.txtClientIPAddr.AllowNumeric = true;
            this.txtClientIPAddr.AllowSpace = true;
            this.txtClientIPAddr.AllowSpecialChars = true;
            this.txtClientIPAddr.FocusColor = System.Drawing.Color.LightYellow;
            this.txtClientIPAddr.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtClientIPAddr.ForeColor = System.Drawing.Color.Black;
            this.txtClientIPAddr.IsEmailID = false;
            this.txtClientIPAddr.IsEmailIdValid = false;
            this.txtClientIPAddr.Location = new System.Drawing.Point(443, 16);
            this.txtClientIPAddr.Name = "txtClientIPAddr";
            this.txtClientIPAddr.Size = new System.Drawing.Size(274, 20);
            this.txtClientIPAddr.TabIndex = 40;
            // 
            // lblBrokeragePer
            // 
            this.lblBrokeragePer.AutoSize = true;
            this.lblBrokeragePer.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBrokeragePer.Location = new System.Drawing.Point(337, 51);
            this.lblBrokeragePer.Name = "lblBrokeragePer";
            this.lblBrokeragePer.Size = new System.Drawing.Size(70, 13);
            this.lblBrokeragePer.TabIndex = 37;
            this.lblBrokeragePer.Text = "Brokerage %";
            this.lblBrokeragePer.Visible = false;
            // 
            // lblClientIPAddress
            // 
            this.lblClientIPAddress.AutoSize = true;
            this.lblClientIPAddress.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClientIPAddress.Location = new System.Drawing.Point(337, 21);
            this.lblClientIPAddress.Name = "lblClientIPAddress";
            this.lblClientIPAddress.Size = new System.Drawing.Size(89, 13);
            this.lblClientIPAddress.TabIndex = 36;
            this.lblClientIPAddress.Text = "Client IP Address";
            // 
            // chkMaxBcastStripsAllowed
            // 
            this.chkMaxBcastStripsAllowed.AutoSize = true;
            this.chkMaxBcastStripsAllowed.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkMaxBcastStripsAllowed.Location = new System.Drawing.Point(6, 47);
            this.chkMaxBcastStripsAllowed.Name = "chkMaxBcastStripsAllowed";
            this.chkMaxBcastStripsAllowed.Size = new System.Drawing.Size(146, 17);
            this.chkMaxBcastStripsAllowed.TabIndex = 6;
            this.chkMaxBcastStripsAllowed.Text = "Max Bcast Scrips Allowed";
            this.chkMaxBcastStripsAllowed.UseVisualStyleBackColor = true;
            // 
            // chkNoOfOrderPerSec
            // 
            this.chkNoOfOrderPerSec.AutoSize = true;
            this.chkNoOfOrderPerSec.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkNoOfOrderPerSec.Location = new System.Drawing.Point(6, 19);
            this.chkNoOfOrderPerSec.Name = "chkNoOfOrderPerSec";
            this.chkNoOfOrderPerSec.Size = new System.Drawing.Size(115, 17);
            this.chkNoOfOrderPerSec.TabIndex = 5;
            this.chkNoOfOrderPerSec.Text = "No of Orders / Sec";
            this.chkNoOfOrderPerSec.UseVisualStyleBackColor = true;
            // 
            // gbSecurities
            // 
            this.gbSecurities.Controls.Add(this.chkSecuritiesGroup);
            this.gbSecurities.Controls.Add(this.chkSecuritiesAll);
            this.gbSecurities.Controls.Add(this.cboSecOptionType);
            this.gbSecurities.Controls.Add(this.lblOptType);
            this.gbSecurities.Controls.Add(this.cboStrikePrice);
            this.gbSecurities.Controls.Add(this.dtSecExpiryDate);
            this.gbSecurities.Controls.Add(this.lblStrikePr);
            this.gbSecurities.Controls.Add(this.lblExpDate);
            this.gbSecurities.Controls.Add(this.lblInstrName);
            this.gbSecurities.Controls.Add(this.txtSecInstrName);
            this.gbSecurities.Controls.Add(this.textBox27);
            this.gbSecurities.Controls.Add(this.lblSeries);
            this.gbSecurities.Controls.Add(this.txtSecSeries);
            this.gbSecurities.Controls.Add(this.lblSymbol);
            this.gbSecurities.Controls.Add(this.txtSecSymbolId);
            this.gbSecurities.Controls.Add(this.label18);
            this.gbSecurities.Controls.Add(this.txtSecurityCode);
            this.gbSecurities.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.gbSecurities.Location = new System.Drawing.Point(8, 199);
            this.gbSecurities.Name = "gbSecurities";
            this.gbSecurities.Size = new System.Drawing.Size(349, 134);
            this.gbSecurities.TabIndex = 43;
            this.gbSecurities.TabStop = false;
            this.gbSecurities.Text = "Securities / Contract";
            // 
            // chkSecuritiesGroup
            // 
            this.chkSecuritiesGroup.AutoSize = true;
            this.chkSecuritiesGroup.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkSecuritiesGroup.Location = new System.Drawing.Point(73, 106);
            this.chkSecuritiesGroup.Name = "chkSecuritiesGroup";
            this.chkSecuritiesGroup.Size = new System.Drawing.Size(55, 17);
            this.chkSecuritiesGroup.TabIndex = 65;
            this.chkSecuritiesGroup.Text = "Group";
            this.chkSecuritiesGroup.UseVisualStyleBackColor = true;
            // 
            // chkSecuritiesAll
            // 
            this.chkSecuritiesAll.AutoSize = true;
            this.chkSecuritiesAll.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkSecuritiesAll.Location = new System.Drawing.Point(6, 106);
            this.chkSecuritiesAll.Name = "chkSecuritiesAll";
            this.chkSecuritiesAll.Size = new System.Drawing.Size(37, 17);
            this.chkSecuritiesAll.TabIndex = 64;
            this.chkSecuritiesAll.Text = "All";
            this.chkSecuritiesAll.UseVisualStyleBackColor = true;
            // 
            // cboSecOptionType
            // 
            this.cboSecOptionType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboSecOptionType.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboSecOptionType.FormattingEnabled = true;
            this.cboSecOptionType.Location = new System.Drawing.Point(247, 78);
            this.cboSecOptionType.Name = "cboSecOptionType";
            this.cboSecOptionType.Size = new System.Drawing.Size(76, 21);
            this.cboSecOptionType.TabIndex = 63;
            // 
            // lblOptType
            // 
            this.lblOptType.AutoSize = true;
            this.lblOptType.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOptType.Location = new System.Drawing.Point(247, 60);
            this.lblOptType.Name = "lblOptType";
            this.lblOptType.Size = new System.Drawing.Size(66, 13);
            this.lblOptType.TabIndex = 62;
            this.lblOptType.Text = "Option Type";
            // 
            // cboStrikePrice
            // 
            this.cboStrikePrice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboStrikePrice.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboStrikePrice.FormattingEnabled = true;
            this.cboStrikePrice.Location = new System.Drawing.Point(165, 78);
            this.cboStrikePrice.Name = "cboStrikePrice";
            this.cboStrikePrice.Size = new System.Drawing.Size(76, 21);
            this.cboStrikePrice.TabIndex = 61;
            // 
            // dtSecExpiryDate
            // 
            this.dtSecExpiryDate.CustomFormat = "dd/MM/yyyy";
            this.dtSecExpiryDate.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtSecExpiryDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtSecExpiryDate.Location = new System.Drawing.Point(73, 78);
            this.dtSecExpiryDate.Name = "dtSecExpiryDate";
            this.dtSecExpiryDate.Size = new System.Drawing.Size(86, 21);
            this.dtSecExpiryDate.TabIndex = 0;
            // 
            // lblStrikePr
            // 
            this.lblStrikePr.AutoSize = true;
            this.lblStrikePr.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStrikePr.Location = new System.Drawing.Point(165, 62);
            this.lblStrikePr.Name = "lblStrikePr";
            this.lblStrikePr.Size = new System.Drawing.Size(60, 13);
            this.lblStrikePr.TabIndex = 60;
            this.lblStrikePr.Text = "Strike Price";
            // 
            // lblExpDate
            // 
            this.lblExpDate.AutoSize = true;
            this.lblExpDate.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExpDate.Location = new System.Drawing.Point(73, 60);
            this.lblExpDate.Name = "lblExpDate";
            this.lblExpDate.Size = new System.Drawing.Size(63, 13);
            this.lblExpDate.TabIndex = 59;
            this.lblExpDate.Text = "Expiry Date";
            // 
            // lblInstrName
            // 
            this.lblInstrName.AutoSize = true;
            this.lblInstrName.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstrName.Location = new System.Drawing.Point(6, 60);
            this.lblInstrName.Name = "lblInstrName";
            this.lblInstrName.Size = new System.Drawing.Size(60, 13);
            this.lblInstrName.TabIndex = 58;
            this.lblInstrName.Text = "Instr Name";
            // 
            // txtSecInstrName
            // 
            this.txtSecInstrName.AllowAlpha = true;
            this.txtSecInstrName.AllowDot = true;
            this.txtSecInstrName.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtSecInstrName.AllowedCustomCharacters")));
            this.txtSecInstrName.AllowNonASCII = false;
            this.txtSecInstrName.AllowNumeric = true;
            this.txtSecInstrName.AllowSpace = true;
            this.txtSecInstrName.AllowSpecialChars = true;
            this.txtSecInstrName.FocusColor = System.Drawing.Color.LightYellow;
            this.txtSecInstrName.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtSecInstrName.ForeColor = System.Drawing.Color.Black;
            this.txtSecInstrName.IsEmailID = false;
            this.txtSecInstrName.IsEmailIdValid = false;
            this.txtSecInstrName.Location = new System.Drawing.Point(6, 78);
            this.txtSecInstrName.Name = "txtSecInstrName";
            this.txtSecInstrName.Size = new System.Drawing.Size(62, 20);
            this.txtSecInstrName.TabIndex = 57;
            // 
            // textBox27
            // 
            this.textBox27.AllowAlpha = true;
            this.textBox27.AllowDot = true;
            this.textBox27.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("textBox27.AllowedCustomCharacters")));
            this.textBox27.AllowNonASCII = false;
            this.textBox27.AllowNumeric = true;
            this.textBox27.AllowSpace = true;
            this.textBox27.AllowSpecialChars = true;
            this.textBox27.FocusColor = System.Drawing.Color.LightYellow;
            this.textBox27.Font = new System.Drawing.Font("Tahoma", 8F);
            this.textBox27.ForeColor = System.Drawing.Color.Black;
            this.textBox27.IsEmailID = false;
            this.textBox27.IsEmailIdValid = false;
            this.textBox27.Location = new System.Drawing.Point(247, 32);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(76, 20);
            this.textBox27.TabIndex = 56;
            // 
            // lblSeries
            // 
            this.lblSeries.AutoSize = true;
            this.lblSeries.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSeries.Location = new System.Drawing.Point(165, 15);
            this.lblSeries.Name = "lblSeries";
            this.lblSeries.Size = new System.Drawing.Size(36, 13);
            this.lblSeries.TabIndex = 55;
            this.lblSeries.Text = "Series";
            // 
            // txtSecSeries
            // 
            this.txtSecSeries.AllowAlpha = true;
            this.txtSecSeries.AllowDot = true;
            this.txtSecSeries.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtSecSeries.AllowedCustomCharacters")));
            this.txtSecSeries.AllowNonASCII = false;
            this.txtSecSeries.AllowNumeric = true;
            this.txtSecSeries.AllowSpace = true;
            this.txtSecSeries.AllowSpecialChars = true;
            this.txtSecSeries.FocusColor = System.Drawing.Color.LightYellow;
            this.txtSecSeries.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtSecSeries.ForeColor = System.Drawing.Color.Black;
            this.txtSecSeries.IsEmailID = false;
            this.txtSecSeries.IsEmailIdValid = false;
            this.txtSecSeries.Location = new System.Drawing.Point(165, 32);
            this.txtSecSeries.Name = "txtSecSeries";
            this.txtSecSeries.Size = new System.Drawing.Size(76, 20);
            this.txtSecSeries.TabIndex = 54;
            // 
            // lblSymbol
            // 
            this.lblSymbol.AutoSize = true;
            this.lblSymbol.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSymbol.Location = new System.Drawing.Point(73, 15);
            this.lblSymbol.Name = "lblSymbol";
            this.lblSymbol.Size = new System.Drawing.Size(87, 13);
            this.lblSymbol.TabIndex = 53;
            this.lblSymbol.Text = "Symbol / Scrip Id\r\n";
            // 
            // txtSecSymbolId
            // 
            this.txtSecSymbolId.AllowAlpha = true;
            this.txtSecSymbolId.AllowDot = true;
            this.txtSecSymbolId.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtSecSymbolId.AllowedCustomCharacters")));
            this.txtSecSymbolId.AllowNonASCII = false;
            this.txtSecSymbolId.AllowNumeric = true;
            this.txtSecSymbolId.AllowSpace = true;
            this.txtSecSymbolId.AllowSpecialChars = true;
            this.txtSecSymbolId.FocusColor = System.Drawing.Color.LightYellow;
            this.txtSecSymbolId.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtSecSymbolId.ForeColor = System.Drawing.Color.Black;
            this.txtSecSymbolId.IsEmailID = false;
            this.txtSecSymbolId.IsEmailIdValid = false;
            this.txtSecSymbolId.Location = new System.Drawing.Point(73, 32);
            this.txtSecSymbolId.Name = "txtSecSymbolId";
            this.txtSecSymbolId.Size = new System.Drawing.Size(86, 20);
            this.txtSecSymbolId.TabIndex = 52;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(6, 16);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(32, 13);
            this.label18.TabIndex = 51;
            this.label18.Text = "Code";
            // 
            // txtSecurityCode
            // 
            this.txtSecurityCode.AllowAlpha = true;
            this.txtSecurityCode.AllowDot = true;
            this.txtSecurityCode.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtSecurityCode.AllowedCustomCharacters")));
            this.txtSecurityCode.AllowNonASCII = false;
            this.txtSecurityCode.AllowNumeric = true;
            this.txtSecurityCode.AllowSpace = true;
            this.txtSecurityCode.AllowSpecialChars = true;
            this.txtSecurityCode.FocusColor = System.Drawing.Color.LightYellow;
            this.txtSecurityCode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtSecurityCode.ForeColor = System.Drawing.Color.Black;
            this.txtSecurityCode.IsEmailID = false;
            this.txtSecurityCode.IsEmailIdValid = false;
            this.txtSecurityCode.Location = new System.Drawing.Point(6, 32);
            this.txtSecurityCode.Name = "txtSecurityCode";
            this.txtSecurityCode.Size = new System.Drawing.Size(62, 20);
            this.txtSecurityCode.TabIndex = 41;
            // 
            // gbOrdrLmt
            // 
            this.gbOrdrLmt.Controls.Add(this.checkBox10);
            this.gbOrdrLmt.Controls.Add(this.lblMinVal);
            this.gbOrdrLmt.Controls.Add(this.txtOrderLimitMinVal);
            this.gbOrdrLmt.Controls.Add(this.lblMinQty);
            this.gbOrdrLmt.Controls.Add(this.txtOrderLimitsMinQty);
            this.gbOrdrLmt.Controls.Add(this.lblPendingOrdLmt);
            this.gbOrdrLmt.Controls.Add(this.txtPendingOrderLimit);
            this.gbOrdrLmt.Controls.Add(this.lblMaxValue);
            this.gbOrdrLmt.Controls.Add(this.txtOrderLimitMaxVal);
            this.gbOrdrLmt.Controls.Add(this.lblQuantity);
            this.gbOrdrLmt.Controls.Add(this.txtOrderLimitQty);
            this.gbOrdrLmt.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.gbOrdrLmt.Location = new System.Drawing.Point(388, 199);
            this.gbOrdrLmt.Name = "gbOrdrLmt";
            this.gbOrdrLmt.Size = new System.Drawing.Size(349, 134);
            this.gbOrdrLmt.TabIndex = 44;
            this.gbOrdrLmt.TabStop = false;
            this.gbOrdrLmt.Text = "Order Limits";
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(326, 39);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(15, 14);
            this.checkBox10.TabIndex = 76;
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // lblMinVal
            // 
            this.lblMinVal.AutoSize = true;
            this.lblMinVal.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMinVal.Location = new System.Drawing.Point(87, 66);
            this.lblMinVal.Name = "lblMinVal";
            this.lblMinVal.Size = new System.Drawing.Size(56, 13);
            this.lblMinVal.TabIndex = 75;
            this.lblMinVal.Text = "Min. Value";
            // 
            // txtOrderLimitMinVal
            // 
            this.txtOrderLimitMinVal.AllowAlpha = true;
            this.txtOrderLimitMinVal.AllowDot = true;
            this.txtOrderLimitMinVal.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtOrderLimitMinVal.AllowedCustomCharacters")));
            this.txtOrderLimitMinVal.AllowNonASCII = false;
            this.txtOrderLimitMinVal.AllowNumeric = true;
            this.txtOrderLimitMinVal.AllowSpace = true;
            this.txtOrderLimitMinVal.AllowSpecialChars = true;
            this.txtOrderLimitMinVal.FocusColor = System.Drawing.Color.LightYellow;
            this.txtOrderLimitMinVal.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtOrderLimitMinVal.ForeColor = System.Drawing.Color.Black;
            this.txtOrderLimitMinVal.IsEmailID = false;
            this.txtOrderLimitMinVal.IsEmailIdValid = false;
            this.txtOrderLimitMinVal.Location = new System.Drawing.Point(87, 85);
            this.txtOrderLimitMinVal.Name = "txtOrderLimitMinVal";
            this.txtOrderLimitMinVal.Size = new System.Drawing.Size(109, 20);
            this.txtOrderLimitMinVal.TabIndex = 74;
            // 
            // lblMinQty
            // 
            this.lblMinQty.AutoSize = true;
            this.lblMinQty.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMinQty.Location = new System.Drawing.Point(5, 66);
            this.lblMinQty.Name = "lblMinQty";
            this.lblMinQty.Size = new System.Drawing.Size(68, 13);
            this.lblMinQty.TabIndex = 73;
            this.lblMinQty.Text = "Min Quantity";
            // 
            // txtOrderLimitsMinQty
            // 
            this.txtOrderLimitsMinQty.AllowAlpha = true;
            this.txtOrderLimitsMinQty.AllowDot = true;
            this.txtOrderLimitsMinQty.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtOrderLimitsMinQty.AllowedCustomCharacters")));
            this.txtOrderLimitsMinQty.AllowNonASCII = false;
            this.txtOrderLimitsMinQty.AllowNumeric = true;
            this.txtOrderLimitsMinQty.AllowSpace = true;
            this.txtOrderLimitsMinQty.AllowSpecialChars = true;
            this.txtOrderLimitsMinQty.FocusColor = System.Drawing.Color.LightYellow;
            this.txtOrderLimitsMinQty.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtOrderLimitsMinQty.ForeColor = System.Drawing.Color.Black;
            this.txtOrderLimitsMinQty.IsEmailID = false;
            this.txtOrderLimitsMinQty.IsEmailIdValid = false;
            this.txtOrderLimitsMinQty.Location = new System.Drawing.Point(5, 85);
            this.txtOrderLimitsMinQty.Name = "txtOrderLimitsMinQty";
            this.txtOrderLimitsMinQty.Size = new System.Drawing.Size(71, 20);
            this.txtOrderLimitsMinQty.TabIndex = 72;
            // 
            // lblPendingOrdLmt
            // 
            this.lblPendingOrdLmt.AutoSize = true;
            this.lblPendingOrdLmt.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPendingOrdLmt.Location = new System.Drawing.Point(207, 20);
            this.lblPendingOrdLmt.Name = "lblPendingOrdLmt";
            this.lblPendingOrdLmt.Size = new System.Drawing.Size(100, 13);
            this.lblPendingOrdLmt.TabIndex = 71;
            this.lblPendingOrdLmt.Text = "Pending Order Limit";
            // 
            // txtPendingOrderLimit
            // 
            this.txtPendingOrderLimit.AllowAlpha = true;
            this.txtPendingOrderLimit.AllowDot = true;
            this.txtPendingOrderLimit.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtPendingOrderLimit.AllowedCustomCharacters")));
            this.txtPendingOrderLimit.AllowNonASCII = false;
            this.txtPendingOrderLimit.AllowNumeric = true;
            this.txtPendingOrderLimit.AllowSpace = true;
            this.txtPendingOrderLimit.AllowSpecialChars = true;
            this.txtPendingOrderLimit.FocusColor = System.Drawing.Color.LightYellow;
            this.txtPendingOrderLimit.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtPendingOrderLimit.ForeColor = System.Drawing.Color.Black;
            this.txtPendingOrderLimit.IsEmailID = false;
            this.txtPendingOrderLimit.IsEmailIdValid = false;
            this.txtPendingOrderLimit.Location = new System.Drawing.Point(207, 36);
            this.txtPendingOrderLimit.Name = "txtPendingOrderLimit";
            this.txtPendingOrderLimit.Size = new System.Drawing.Size(109, 20);
            this.txtPendingOrderLimit.TabIndex = 70;
            // 
            // lblMaxValue
            // 
            this.lblMaxValue.AutoSize = true;
            this.lblMaxValue.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaxValue.Location = new System.Drawing.Point(87, 20);
            this.lblMaxValue.Name = "lblMaxValue";
            this.lblMaxValue.Size = new System.Drawing.Size(60, 13);
            this.lblMaxValue.TabIndex = 69;
            this.lblMaxValue.Text = "Max. Value";
            // 
            // txtOrderLimitMaxVal
            // 
            this.txtOrderLimitMaxVal.AllowAlpha = true;
            this.txtOrderLimitMaxVal.AllowDot = true;
            this.txtOrderLimitMaxVal.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtOrderLimitMaxVal.AllowedCustomCharacters")));
            this.txtOrderLimitMaxVal.AllowNonASCII = false;
            this.txtOrderLimitMaxVal.AllowNumeric = true;
            this.txtOrderLimitMaxVal.AllowSpace = true;
            this.txtOrderLimitMaxVal.AllowSpecialChars = true;
            this.txtOrderLimitMaxVal.FocusColor = System.Drawing.Color.LightYellow;
            this.txtOrderLimitMaxVal.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtOrderLimitMaxVal.ForeColor = System.Drawing.Color.Black;
            this.txtOrderLimitMaxVal.IsEmailID = false;
            this.txtOrderLimitMaxVal.IsEmailIdValid = false;
            this.txtOrderLimitMaxVal.Location = new System.Drawing.Point(87, 36);
            this.txtOrderLimitMaxVal.Name = "txtOrderLimitMaxVal";
            this.txtOrderLimitMaxVal.Size = new System.Drawing.Size(109, 20);
            this.txtOrderLimitMaxVal.TabIndex = 68;
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantity.Location = new System.Drawing.Point(5, 20);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(49, 13);
            this.lblQuantity.TabIndex = 67;
            this.lblQuantity.Text = "Quantity";
            // 
            // txtOrderLimitQty
            // 
            this.txtOrderLimitQty.AllowAlpha = true;
            this.txtOrderLimitQty.AllowDot = true;
            this.txtOrderLimitQty.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtOrderLimitQty.AllowedCustomCharacters")));
            this.txtOrderLimitQty.AllowNonASCII = false;
            this.txtOrderLimitQty.AllowNumeric = true;
            this.txtOrderLimitQty.AllowSpace = true;
            this.txtOrderLimitQty.AllowSpecialChars = true;
            this.txtOrderLimitQty.FocusColor = System.Drawing.Color.LightYellow;
            this.txtOrderLimitQty.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtOrderLimitQty.ForeColor = System.Drawing.Color.Black;
            this.txtOrderLimitQty.IsEmailID = false;
            this.txtOrderLimitQty.IsEmailIdValid = false;
            this.txtOrderLimitQty.Location = new System.Drawing.Point(5, 36);
            this.txtOrderLimitQty.Name = "txtOrderLimitQty";
            this.txtOrderLimitQty.Size = new System.Drawing.Size(71, 20);
            this.txtOrderLimitQty.TabIndex = 66;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(504, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 13);
            this.label3.TabIndex = 48;
            this.label3.Text = "Preferences";
            // 
            // chkListPreferences
            // 
            this.chkListPreferences.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.chkListPreferences.FormattingEnabled = true;
            this.chkListPreferences.Items.AddRange(new object[] {
            "Surveillance On",
            "Surv. Auto",
            "Margin/Prime",
            "Allow DMA",
            "Disallow DMA"});
            this.chkListPreferences.Location = new System.Drawing.Point(589, 24);
            this.chkListPreferences.Name = "chkListPreferences";
            this.chkListPreferences.Size = new System.Drawing.Size(148, 84);
            this.chkListPreferences.TabIndex = 50;
            // 
            // gbUserDetails
            // 
            this.gbUserDetails.Controls.Add(this.cboMainAC);
            this.gbUserDetails.Controls.Add(this.lblMainAc);
            this.gbUserDetails.Controls.Add(this.chkListPreferences);
            this.gbUserDetails.Controls.Add(this.label3);
            this.gbUserDetails.Controls.Add(this.gbOrdrLmt);
            this.gbUserDetails.Controls.Add(this.gbSecurities);
            this.gbUserDetails.Controls.Add(this.gbTradingDetails);
            this.gbUserDetails.Controls.Add(this.groupBox1);
            this.gbUserDetails.Controls.Add(this.cboGroupAdmin);
            this.gbUserDetails.Controls.Add(this.lblGroupAdmin);
            this.gbUserDetails.Controls.Add(this.txtBrokerageDVP);
            this.gbUserDetails.Controls.Add(this.txtBroerageNonDVP);
            this.gbUserDetails.Controls.Add(this.lblDVPBrok);
            this.gbUserDetails.Controls.Add(this.lblNnDVPBrok);
            this.gbUserDetails.Controls.Add(this.cboParentAC);
            this.gbUserDetails.Controls.Add(this.lblParentAC);
            this.gbUserDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbUserDetails.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.gbUserDetails.Location = new System.Drawing.Point(0, 0);
            this.gbUserDetails.Name = "gbUserDetails";
            this.gbUserDetails.Size = new System.Drawing.Size(780, 650);
            this.gbUserDetails.TabIndex = 5;
            this.gbUserDetails.TabStop = false;
            this.gbUserDetails.Text = "User Details";
            // 
            // cboMainAC
            // 
            this.cboMainAC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboMainAC.FormattingEnabled = true;
            this.cboMainAC.Location = new System.Drawing.Point(579, 354);
            this.cboMainAC.Name = "cboMainAC";
            this.cboMainAC.Size = new System.Drawing.Size(135, 21);
            this.cboMainAC.TabIndex = 52;
            this.cboMainAC.Visible = false;
            // 
            // lblMainAc
            // 
            this.lblMainAc.AutoSize = true;
            this.lblMainAc.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMainAc.Location = new System.Drawing.Point(504, 357);
            this.lblMainAc.Name = "lblMainAc";
            this.lblMainAc.Size = new System.Drawing.Size(48, 13);
            this.lblMainAc.TabIndex = 51;
            this.lblMainAc.Text = "Main A/c";
            this.lblMainAc.Visible = false;
            // 
            // ucODINPreferences
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.gbUserDetails);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "ucODINPreferences";
            this.Size = new System.Drawing.Size(780, 650);
            this.Load += new System.EventHandler(this.ucQDINPreferences_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gbTradingDetails.ResumeLayout(false);
            this.gbTradingDetails.PerformLayout();
            this.gbSecurities.ResumeLayout(false);
            this.gbSecurities.PerformLayout();
            this.gbOrdrLmt.ResumeLayout(false);
            this.gbOrdrLmt.PerformLayout();
            this.gbUserDetails.ResumeLayout(false);
            this.gbUserDetails.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblParentAC;
        private System.Windows.Forms.ComboBox cboParentAC;
        private System.Windows.Forms.Label lblNnDVPBrok;
        private System.Windows.Forms.Label lblDVPBrok;
        private MatchCommon.CustomControls.FTTextBox txtBroerageNonDVP;
        private MatchCommon.CustomControls.FTTextBox txtBrokerageDVP;
        private System.Windows.Forms.Label lblGroupAdmin;
        private System.Windows.Forms.ComboBox cboGroupAdmin;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cboConnectionMode;
        private System.Windows.Forms.Label lblConnectionMode;
        private System.Windows.Forms.ComboBox cboPartType;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.ComboBox cboProductType;
        private System.Windows.Forms.Label lblPartType;
        private System.Windows.Forms.Label lblProductType;
        private MatchCommon.CustomControls.FTTextBox txtTopMargin;
        private System.Windows.Forms.Label lblTopMargin;
        private System.Windows.Forms.GroupBox gbTradingDetails;
        private MatchCommon.CustomControls.FTTextBox txtMaxBcastScripsAllowed;
        private MatchCommon.CustomControls.FTTextBox txtNoOfOrdersPerSec;
        private MatchCommon.CustomControls.FTTextBox txtBrokeragePer;
        private MatchCommon.CustomControls.FTTextBox txtClientIPAddr;
        private System.Windows.Forms.Label lblBrokeragePer;
        private System.Windows.Forms.Label lblClientIPAddress;
        private System.Windows.Forms.CheckBox chkMaxBcastStripsAllowed;
        private System.Windows.Forms.CheckBox chkNoOfOrderPerSec;
        private System.Windows.Forms.GroupBox gbSecurities;
        private System.Windows.Forms.CheckBox chkSecuritiesGroup;
        private System.Windows.Forms.CheckBox chkSecuritiesAll;
        private System.Windows.Forms.ComboBox cboSecOptionType;
        private System.Windows.Forms.Label lblOptType;
        private System.Windows.Forms.ComboBox cboStrikePrice;
        private System.Windows.Forms.DateTimePicker dtSecExpiryDate;
        private System.Windows.Forms.Label lblStrikePr;
        private System.Windows.Forms.Label lblExpDate;
        private System.Windows.Forms.Label lblInstrName;
        private MatchCommon.CustomControls.FTTextBox txtSecInstrName;
        private MatchCommon.CustomControls.FTTextBox textBox27;
        private System.Windows.Forms.Label lblSeries;
        private MatchCommon.CustomControls.FTTextBox txtSecSeries;
        private System.Windows.Forms.Label lblSymbol;
        private MatchCommon.CustomControls.FTTextBox txtSecSymbolId;
        private System.Windows.Forms.Label label18;
        private MatchCommon.CustomControls.FTTextBox txtSecurityCode;
        private System.Windows.Forms.GroupBox gbOrdrLmt;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.Label lblMinVal;
        private MatchCommon.CustomControls.FTTextBox txtOrderLimitMinVal;
        private System.Windows.Forms.Label lblMinQty;
        private MatchCommon.CustomControls.FTTextBox txtOrderLimitsMinQty;
        private System.Windows.Forms.Label lblPendingOrdLmt;
        private MatchCommon.CustomControls.FTTextBox txtPendingOrderLimit;
        private System.Windows.Forms.Label lblMaxValue;
        private MatchCommon.CustomControls.FTTextBox txtOrderLimitMaxVal;
        private System.Windows.Forms.Label lblQuantity;
        private MatchCommon.CustomControls.FTTextBox txtOrderLimitQty;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckedListBox chkListPreferences;
        private System.Windows.Forms.GroupBox gbUserDetails;
        private System.Windows.Forms.ComboBox cboCategory;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.ComboBox cboMainAC;
        private System.Windows.Forms.Label lblMainAc;
    }
}
