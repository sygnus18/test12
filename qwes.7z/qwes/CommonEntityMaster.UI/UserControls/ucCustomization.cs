﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FTIL.Match.CDD.BAL;
using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.Common.Log;

namespace FTIL.Match.CDD.UI.UserControls
{
    public partial class ucCustomization : ucBaseEntity
    {
        private MatchCommon.CustomControls.FTTextBox txtColumnValue;
        private MatchCommon.CustomControls.FTComboBox cmboYN;
        private MaskedTextBox txtDateValue;
        private MatchCommon.CustomControls.FTComboBox cmboType;

        private MatchCommon.CustomControls.FTDateTimePicker dtColumnVal;

        public int CustomLoad { get; set; } 
        public int ClientId { get; set; }
        public int ProductNo { get; set; }
        public string sCustId { get; set; }
        private string sPreTexVal { get; set; }
        private string sComboTypeText { get; set; }

        private string sFormatNo { get; set; }
        private DataTable dt;
        cCustomization objCustomization;
        public ucCustomization()
        {
            InitializeComponent();
            this.dgCustomize.AllowEditing = true;
            objCustomization = new cCustomization();
            this.dgCustomize.Cols.Fixed = 0;
            cmboYN = new MatchCommon.CustomControls.FTComboBox();
            cmboType = new MatchCommon.CustomControls.FTComboBox();
            txtDateValue = new MaskedTextBox();
            txtDateValue.ValidatingType = typeof(System.DateTime);
            dtColumnVal = new MatchCommon.CustomControls.FTDateTimePicker();

            dtColumnVal.Leave += DtValues;
            dtColumnVal.Enter += DtEnter;

            cmboType.DrawMode = DrawMode.Normal;
            cmboType.SelectedIndexChanged += cboType_SelectedIndexChanged;
            cmboYN.SelectedIndexChanged += cboType_SelectedIndexChanged;

            txtColumnValue = new MatchCommon.CustomControls.FTTextBox();
            txtColumnValue.MaxLength = 30;
            txtColumnValue.AllowAlpha = true;
            txtColumnValue.AllowDot = false;
            txtColumnValue.AllowNonASCII = false;
            txtColumnValue.CharacterCasing = CharacterCasing.Upper;
            //txtColumnValue.AllowSpace = false;
            txtColumnValue.AllowSpecialChars = false;
            txtColumnValue.AllowNumeric = true;
           // txtColumnValue.Click += txtKeyFocus;
            txtColumnValue.Leave += txtKeyLeave;

        }

        private void usCustomization_Load(object sender, EventArgs e)
        {
            if (CustomLoad == 0)
                PopulateControls();
        }


        public override void PopulateControls()
        {
            if (ModifyMode == false) return;
            try
            {
                CustomLoad = 1;
                DataSet dsResult = null;
                objCustomization.GetCustomizationDetails(ProductNo, ref dsResult, sCustId);
                objCustomization.dtCustomization = dsResult.Tables[0];
                if (objCustomization.dtCustomization == null && objCustomization.dtCustomization.Rows.Count <= 0)
                {
                    btnModify.Enabled = false;
                    btnRemove.Enabled = false;
                    btnSave.Enabled = false;
                }
                GridBind();
                dt = dsResult.Tables[1];
                PopulateLookup();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucCustomization), ex.Message);
                MessageBox.Show(ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        /// <summary>
        /// call from details fill combo of bank tab data on load and reload. 
        /// </summary>
        protected override void PopulateLookup()
        {
            if (m_HasAllDropDownListBind) return;
            try
            {
                cboCustomProduct.ValueMember = "n_ProductNo";
                cboCustomProduct.DisplayMember = "s_ProductName";
                cboCustomProduct.DataSource = dt;

                cboCustomProduct.SelectedIndex = 0;

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucBank), ex.Message);
                MessageBox.Show("Unable to populate bank details", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            m_HasAllDropDownListBind = true;
        }


        private void GridBind()
        {
            try
            {
                dgCustomize.DataSource = objCustomization.dtCustomization;
                dgCustomize.Cols["n_CustomFieldNo"].Visible = false;
                dgCustomize.Cols["n_ProductNo"].Visible = false;
                dgCustomize.Cols["n_FieldTypeNo"].Visible = false;
                dgCustomize.Cols["n_FieldFormatNo"].Visible = false;
                dgCustomize.Cols["n_FieldMaxLength"].Visible = false;
                dgCustomize.Cols["n_FieldMinLength"].Visible = false;
                dgCustomize.Cols["n_FieldMandatory"].Visible = false;
                dgCustomize.Cols["s_HasChanged"].Visible = false;
                dgCustomize.Cols["sComboVal"].Visible = false;

                dgCustomize.Cols["s_FieldName"].Caption = "Column Name";
                dgCustomize.Cols["s_FieldValue"].Caption = "Value";

                dgCustomize.Cols["s_FieldName"].Width = 300;
                dgCustomize.Cols["s_FieldValue"].Width = 460;

                this.dgCustomize.Cols["s_FieldName"].AllowEditing = false;
                dgCustomize.Cols["s_FieldValue"].Editor = txtColumnValue;


                if (objCustomization.dtCustomization.Rows.Count == 0) objCustomization.isValid = false;
                else
                {
                    objCustomization.isValid = true;
                    txtColumnValue.Text = dgCustomize.Rows[1]["s_FieldValue"].ToString();
                }

                //DataRow[] dr = objBankDtl.dtBankResult.Select("s_Default = 'Y'");
                //if (dr.Length >= 1)
                //    chkDefault.Enabled = false;
                //else
                //    chkDefault.Enabled = true;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucCustomization), ex.Message);
                MessageBox.Show("Unable to fetch data for bind Customization", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
            Forms.frmAddColumn objAddCol = new Forms.frmAddColumn();
            objAddCol.ProductNo = this.ProductNo;
            objAddCol.sCustId = this.sCustId;
            objAddCol.FieldNo = 0;
            objAddCol.dtCustomization = objCustomization.dtCustomization;
            objAddCol.ShowDialog();
                if (objAddCol.dtCustomization.Rows.Count > 0)
                {
                    btnModify.Enabled = true;
                    btnRemove.Enabled = true;
                    btnSave.Enabled = true;
                }
                else
                {

                    btnModify.Enabled = false;
                    btnRemove.Enabled = false;
                    btnSave.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucCustomization), ex.Message);
                MessageBox.Show("Unable create object for new column", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void dgCustomize_DoubleClick(object sender, EventArgs e)
        {
            
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            try
            {
                int rowIdx = dgCustomize.RowSel;
                int colIdx = dgCustomize.ColSel;
                Forms.frmAddColumn objAddCol = new Forms.frmAddColumn();
                objAddCol.ProductNo = this.ProductNo;
                objAddCol.sCustId = this.sCustId;
                objAddCol.FieldNo = Convert.ToInt32(dgCustomize.Rows[rowIdx]["n_CustomFieldNo"].ToString());
                objAddCol.FieldType = Convert.ToInt32(dgCustomize.Rows[rowIdx]["n_FieldTypeNo"].ToString());
                objAddCol.Format = Convert.ToInt32(dgCustomize.Rows[rowIdx]["n_FieldFormatNo"].ToString());
                objAddCol.MaxLen = Convert.ToInt32(dgCustomize.Rows[rowIdx]["n_FieldMaxLength"].ToString());
                objAddCol.MinLen = Convert.ToInt32(dgCustomize.Rows[rowIdx]["n_FieldMinLength"].ToString());
                objAddCol.FieldName = dgCustomize.Rows[rowIdx]["s_FieldName"].ToString();
                objAddCol.isMandatory = dgCustomize.Rows[rowIdx]["n_FieldMandatory"].ToString() == "Y" ? true : false;
                objAddCol.dtCustomization = objCustomization.dtCustomization;
                objAddCol.sComboVal = dgCustomize.Rows[rowIdx]["sComboVal"].ToString();

                objCustomization.FieldNo = Convert.ToInt32(dgCustomize.Rows[rowIdx]["n_CustomFieldNo"].ToString());
                objAddCol.ShowDialog();
                dgCustomize.Focus();
                dgCustomize.RowSel = rowIdx;
                dgCustomize.ColSel = 0;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucCustomization), ex.Message);
                MessageBox.Show(ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string sManField = "";
            int iManCnt = 0;
            try
            {
                int rowIdx = dgCustomize.RowSel;
                int colIdx = dgCustomize.ColSel;
                if (txtColumnValue.Text != dgCustomize.Rows[rowIdx]["s_FieldValue"].ToString())
                    dgCustomize.Rows[rowIdx]["s_HasChanged"] = "Y";

                for (int iCnt = 0; iCnt <= dgCustomize.Rows.Count-1; iCnt++)
                {
                    if (dgCustomize.Rows[iCnt]["s_FieldValue"].ToString() == "" && dgCustomize.Rows[iCnt]["n_FieldMandatory"].ToString() == "Y")
                    {
                        iManCnt += 1;
                        sManField += dgCustomize.Rows[iCnt]["s_FieldName"].ToString() + ",";

                    }
                }
                if (sManField != "")
                {
                    sManField = sManField.Remove(sManField.Length - 1);
                    if(iManCnt==1)
                        MessageBox.Show(sManField + " is mandatory field. Its can not left blank.", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    else
                        MessageBox.Show(sManField + " are mandatory fields. Its can not left blank.", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);

                    return;
                }


                objCustomization.sCustId = this.sCustId;
                objCustomization.UpdateFieldValuesDetails(this.ProductNo, objCustomization.dtCustomization, DateTime.Now.Date);

                if (objCustomization.nErrorNo == 0)
                {
                    MessageBox.Show("Record Updated Successfully.", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ResetDt();
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucCustomization), ex.Message);
                MessageBox.Show(ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtKeyLeave(object sender, EventArgs e) 
        {
            try
            {
                int rowIdx = dgCustomize.RowSel;
                int colIdx = dgCustomize.ColSel;

                if (txtColumnValue.Text != dgCustomize.Rows[rowIdx]["s_FieldValue"].ToString() && (dgCustomize.Rows[rowIdx]["n_FieldTypeNo"].ToString() != "9"))
                {
                    if (txtColumnValue.Text.Length > Convert.ToInt32(dgCustomize.Rows[rowIdx]["n_FieldMaxLength"].ToString()))
                    {

                        MessageBox.Show(dgCustomize.Rows[rowIdx]["s_FieldName"].ToString() + " max length is " + dgCustomize.Rows[rowIdx]["n_FieldMaxLength"].ToString(),
                                        sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtColumnValue.Focus();
                        return;
                    }

                    if (txtColumnValue.Text.Length < Convert.ToInt32(dgCustomize.Rows[rowIdx]["n_FieldMinLength"].ToString()) && txtColumnValue.Text != "")
                    {

                        MessageBox.Show(dgCustomize.Rows[rowIdx]["s_FieldName"].ToString() + " min length is " + dgCustomize.Rows[rowIdx]["n_FieldMinLength"].ToString(),
                                        sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtColumnValue.Focus();
                        return;
                    }

                    dgCustomize.Rows[rowIdx]["s_HasChanged"] = "Y";
                }


                //if (dgCustomize.Rows[rowIdx]["n_FieldTypeNo"].ToString() == "9")
                //{
                //    sComboTypeText = txtColumnValue.Text;
                //    cmboType = new MatchCommon.CustomControls.FTComboBox();
                //    string[] sComboArr = sComboTypeText.Split(',');
                //    for (int iCnt = 0; iCnt <= sComboArr.Length - 1; iCnt++)
                //    {
                //        cmboType.Items.Add(sComboArr[iCnt]);

                //    }
                //    dgCustomize.Rows[rowIdx]["sComboVal"] = sComboTypeText;
                //}

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucCustomization), ex.Message);
                MessageBox.Show(ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        

        /// <summary>
        /// check changes made in active grid tab
        /// </summary>
        /// <returns></returns>
        public override bool CheckChanges()
        {
            int rowIdx = dgCustomize.RowSel;
            int colIdx = dgCustomize.ColSel;
          

            if (this.IsGridUpdated == true) return true;
            try
            {
                if (txtColumnValue.Text != dgCustomize.Rows[rowIdx]["s_FieldValue"].ToString())
                    dgCustomize.Rows[rowIdx]["s_HasChanged"] = "Y";

                if (objCustomization.dtCustomization.Rows.Count == 0) return false;

                DataRow[] dr = objCustomization.dtCustomization.Select("s_HasChanged = 'Y'");
                if (dr.Length > 0)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucCustomization), ex.Message);
                return false;
            }
        }

        /// <summary>
        /// reset data on submit changes.
        /// </summary>
        public override void ResetDt()
        {
            try
            {
                DataTable dtResult = new DataTable();
                dtResult = objCustomization.dtCustomization;
                for (int iCnt = 0; iCnt <= dtResult.Rows.Count - 1; iCnt++)
                {
                    dtResult.Rows[iCnt]["s_HasChanged"] = "N";

                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucBank), ex.Message);
            }
        }

        private void dgCustomize_Click(object sender, EventArgs e)
        {
            int rowIdx = dgCustomize.RowSel;
            int colIdx = dgCustomize.ColSel;
            if (rowIdx < 0) return;

            try
            {
                txtColumnValue.Text = dgCustomize.Rows[rowIdx]["s_FieldValue"].ToString();
                dgCustomize.Cols["s_FieldValue"].Editor = txtColumnValue;
                if (dgCustomize.Rows[rowIdx]["n_FieldTypeNo"].ToString() == "8")
                {
                    txtColumnValue.AllowSpace = false;
                    txtColumnValue.AllowSpecialChars = false;
                    txtColumnValue.AllowAlpha = false;
                    txtColumnValue.AllowNumeric = true;
                    txtColumnValue.AllowDot = false;
                    txtColumnValue.MaxLength = Convert.ToInt32(dgCustomize.Rows[rowIdx]["n_FieldMaxLength"].ToString());
                }
                else if (dgCustomize.Rows[rowIdx]["n_FieldTypeNo"].ToString() == "2" && dgCustomize.Rows[rowIdx]["n_FieldFormatNo"].ToString() != "4"
                        && dgCustomize.Rows[rowIdx]["n_FieldFormatNo"].ToString() != "5" && dgCustomize.Rows[rowIdx]["n_FieldFormatNo"].ToString() != "10")
                {
                    txtColumnValue.AllowSpace = false;
                    txtColumnValue.AllowSpecialChars = false;
                    txtColumnValue.AllowAlpha = false;
                    txtColumnValue.AllowNumeric = true;
                    txtColumnValue.AllowDot = false;
                    txtColumnValue.MaxLength = Convert.ToInt32(dgCustomize.Rows[rowIdx]["n_FieldMaxLength"].ToString());
                }
                else if (dgCustomize.Rows[rowIdx]["n_FieldTypeNo"].ToString() == "3" && dgCustomize.Rows[rowIdx]["n_FieldFormatNo"].ToString() != "14"
                                                            && dgCustomize.Rows[rowIdx]["n_FieldFormatNo"].ToString() != "13")
                {
                    txtColumnValue.AllowSpace = false;
                    txtColumnValue.AllowSpecialChars = false;
                    txtColumnValue.AllowAlpha = false;
                    txtColumnValue.AllowNumeric = true;
                    txtColumnValue.AllowDot = false;
                    txtColumnValue.MaxLength = Convert.ToInt32(dgCustomize.Rows[rowIdx]["n_FieldMaxLength"].ToString());
                }
                else if (dgCustomize.Rows[rowIdx]["n_FieldTypeNo"].ToString() == "4")
                {
                    txtColumnValue.AllowSpace = false;
                    txtColumnValue.AllowSpecialChars = false;
                    txtColumnValue.AllowAlpha = false;

                    txtColumnValue.AllowNumeric = true;
                    txtColumnValue.AllowDot = true;
                    txtColumnValue.MaxLength = Convert.ToInt32(dgCustomize.Rows[rowIdx]["n_FieldMaxLength"].ToString());
                }
                else if (dgCustomize.Rows[rowIdx]["n_FieldTypeNo"].ToString() == "5")
                {   
                    cmboYN = new MatchCommon.CustomControls.FTComboBox();
                    cmboYN.SelectedIndexChanged += cboType_SelectedIndexChanged;
                    cmboYN.Width = 20;
                    if (dgCustomize.Rows[rowIdx]["n_FieldFormatNo"].ToString() == "19")
                    {
                        cmboYN.Items.Add("Yes");
                        cmboYN.Items.Add("No");
                    }
                    else if (dgCustomize.Rows[rowIdx]["n_FieldFormatNo"].ToString() == "20")
                    {
                        cmboYN.Items.Add("True");
                        cmboYN.Items.Add("False");
                    }
                    else if (dgCustomize.Rows[rowIdx]["n_FieldFormatNo"].ToString() == "21")
                    {
                        cmboYN.Items.Add("On");
                        cmboYN.Items.Add("Off");
                    }
                    cmboYN.ReadOnly = true;
                    dgCustomize.Cols["s_FieldValue"].Editor = cmboYN;

                }
                else if (dgCustomize.Rows[rowIdx]["n_FieldTypeNo"].ToString() == "6")
                {
                    if (dgCustomize.Rows[rowIdx]["n_FieldFormatNo"].ToString() == "24")
                    {
                        dtColumnVal.Format = DateTimePickerFormat.Short;

                    }
                    else
                    {
                        dtColumnVal.Format = DateTimePickerFormat.Long;
                    }

                    dgCustomize.Cols["s_FieldValue"].Editor = dtColumnVal;

                }
                else if (dgCustomize.Rows[rowIdx]["n_FieldTypeNo"].ToString() == "7")
                {
                    txtColumnValue.AllowSpace = false;
                    txtColumnValue.AllowSpecialChars = false;
                    txtColumnValue.AllowAlpha = false;
                    txtColumnValue.AllowNumeric = true;
                    txtColumnValue.AllowDot = false;
                    txtColumnValue.MaxLength = Convert.ToInt32(dgCustomize.Rows[rowIdx]["n_FieldMaxLength"].ToString());

                   
                }
                else if (dgCustomize.Rows[rowIdx]["n_FieldTypeNo"].ToString() == "9")
                {
                    if (dgCustomize.Rows[rowIdx]["sComboVal"].ToString().Trim() != "")
                    {
                        sComboTypeText = dgCustomize.Rows[rowIdx]["sComboVal"].ToString().Trim();
                        cmboType = new MatchCommon.CustomControls.FTComboBox();
                        cmboType.SelectedIndexChanged += cboType_SelectedIndexChanged; 

                        string[] sComboArr = sComboTypeText.Split(',');
                        for (int iCnt = 0; iCnt <= sComboArr.Length - 1; iCnt++)
                        {
                            cmboType.Items.Add(sComboArr[iCnt]);

                        }
                        dgCustomize.Rows[rowIdx]["sComboVal"] = sComboTypeText;
                        cmboType.ReadOnly = true;
                        dgCustomize.Cols["s_FieldValue"].Editor = cmboType;
                    }

                    if (dgCustomize.Rows[rowIdx]["s_FieldValue"].ToString().Trim() != "")
                    {
                        cmboType.ReadOnly = true;
                        dgCustomize.Cols["s_FieldValue"].Editor = cmboType;
                    }
                    else if(cmboType.Items.Count==0)
                    {
                        txtColumnValue.AllowSpace = true;
                        txtColumnValue.AllowSpecialChars = true;
                        txtColumnValue.AllowAlpha = true;
                        txtColumnValue.AllowNumeric = true;
                        txtColumnValue.AllowDot = true;
                        txtColumnValue.MaxLength = Convert.ToInt32(dgCustomize.Rows[rowIdx]["n_FieldMaxLength"].ToString());
                    }

                }
                else
                {

                    txtColumnValue.AllowSpace = true;
                    txtColumnValue.AllowSpecialChars = true;
                    txtColumnValue.AllowAlpha = true;
                    txtColumnValue.AllowNumeric = true;
                    txtColumnValue.AllowDot = true;
                    txtColumnValue.MaxLength = Convert.ToInt32(dgCustomize.Rows[rowIdx]["n_FieldMaxLength"].ToString());

                }

                if (dgCustomize.Rows[rowIdx]["n_FieldFormatNo"].ToString() == "14" || dgCustomize.Rows[rowIdx]["n_FieldFormatNo"].ToString() == "13" ||
                    dgCustomize.Rows[rowIdx]["n_FieldFormatNo"].ToString() == "4" || dgCustomize.Rows[rowIdx]["n_FieldFormatNo"].ToString() == "5" ||
                    dgCustomize.Rows[rowIdx]["n_FieldFormatNo"].ToString() == "2" || dgCustomize.Rows[rowIdx]["n_FieldFormatNo"].ToString() == "10"
                    )
                {
                    txtColumnValue = new MatchCommon.CustomControls.FTTextBox();
                    dgCustomize.Cols["s_FieldValue"].Editor = txtColumnValue;
                    txtColumnValue.AllowSpace = false;
                    txtColumnValue.AllowSpecialChars = false;
                    txtColumnValue.AllowAlpha = false;
                    txtColumnValue.AllowNumeric = true;
                    txtColumnValue.AllowDot = true;
                    txtColumnValue.MaxLength = Convert.ToInt32(dgCustomize.Rows[rowIdx]["n_FieldMaxLength"].ToString());
                    txtColumnValue.KeyPress += checkValues;
                    txtColumnValue.Leave += txtKeyLeave;
                }

                sFormatNo = dgCustomize.Rows[rowIdx]["n_FieldFormatNo"].ToString();

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucCustomization), ex.Message);
                MessageBox.Show(ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cboCustomProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                DataSet dsResult = null;
                ProductNo = Convert.ToInt32(cboCustomProduct.SelectedValue);
                objCustomization.GetCustomizationDetails(ProductNo, ref dsResult, sCustId);
                objCustomization.dtCustomization = dsResult.Tables[0];
                if (objCustomization.dtCustomization.Rows.Count <= 0)
                {
                    btnModify.Enabled = false;
                    btnRemove.Enabled = false;
                    btnSave.Enabled = false;
                }
                else
                {
                    btnModify.Enabled = true;
                    btnRemove.Enabled = true;
                    btnSave.Enabled = true;
                }
                GridBind();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucCustomization), ex.Message);
                MessageBox.Show(ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cboType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                int rowIdx = dgCustomize.RowSel;
                int colIdx = dgCustomize.ColSel;
                dgCustomize.Rows[rowIdx]["s_HasChanged"] = "Y";
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucCustomization), ex.Message);
                MessageBox.Show(ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

     
        private void rowValidate( DataRow[] dr, ref string sMsg )
        {
           
            if (dr.Length > 0)
            {
                string changedFlag = "N";

                if (dr[0]["n_FieldMandatory"].ToString() == "Y" && dr[0]["s_FieldValue"] == "")
                {
                    
                }

                if (dr[0]["n_FieldMaxLength"].ToString() != "0" && dr[0]["s_FieldValue"].ToString().Length >
                        Convert.ToInt32(dr[0]["n_FieldMaxLength"].ToString()))
                {

                }

                if (dr[0]["n_FieldMinLength"].ToString() != "0" && dr[0]["s_FieldValue"].ToString().Length <
                       Convert.ToInt32(dr[0]["n_FieldMinLength"].ToString()))
                {

                }


               
            }

        }

        private void checkValues(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == 110 || e.KeyChar == '.')
                {
                    if (txtColumnValue.Text.IndexOf(".") >= 0) // for decimal check
                    {
                        e.KeyChar = 'a';
                        return;
                    }
                }
                else if (e.KeyChar != '\b')
                {
                    if (sFormatNo == "4" || sFormatNo == "13") // for 1 decimal place
                    {
                        if (txtColumnValue.Text.IndexOf(".") >= 0 && txtColumnValue.Text.IndexOf(".") + 2 == txtColumnValue.Text.Length)
                        {
                            e.KeyChar = 'a';
                            return;
                        }
                    }
                    else if (sFormatNo == "5" || sFormatNo == "14" || sFormatNo == "10") // for 2 decimal place 
                    {
                        if (txtColumnValue.Text.IndexOf(".") >= 0 && txtColumnValue.Text.IndexOf(".") + 3 == txtColumnValue.Text.Length)
                        {
                            e.KeyChar = 'a';
                            return;
                        }
                    }
                    else if (sFormatNo == "2" ) // for 3 decimal place 
                    {
                        if (txtColumnValue.Text.IndexOf(".") >= 0 && txtColumnValue.Text.IndexOf(".") + 4 == txtColumnValue.Text.Length)
                        {
                            e.KeyChar = 'a';
                            return;
                        }
                    }
                }

                //if (txtColumnValue.Text.IndexOf(".") > 0)
                //{
                //    if ((txtColumnValue.Text.IndexOf(".") + 1) != txtColumnValue.Text.Length)
                //    {
                //        txtColumnValue.Text.Remove(txtColumnValue.Text.Length - 1);

                //    }

                //}
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucCustomization), ex.Message);
                MessageBox.Show(ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }


        private void DtValues(object sender, EventArgs e)
        {
            int rowIdx = dgCustomize.RowSel;
            int colIdx = dgCustomize.ColSel;
            dgCustomize.Rows[rowIdx]["s_HasChanged"] = "Y";
                                
        }

        private void DtEnter(object sender, EventArgs e)
        {
            try
            {
                int rowIdx = dgCustomize.RowSel;
                int colIdx = dgCustomize.ColSel;
                if (dgCustomize.Rows[rowIdx]["n_FieldFormatNo"].ToString() == "24")
                {
                    dtColumnVal.Format = DateTimePickerFormat.Short;

                }
                else
                {
                    dtColumnVal.Format = DateTimePickerFormat.Long;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucCustomization), ex.Message);
                MessageBox.Show(ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            try
            {
                int rowIdx = dgCustomize.RowSel;
                int colIdx = dgCustomize.ColSel;
                if (dgCustomize.Rows[rowIdx]["s_FieldValue"].ToString() == "")
                {
                    MessageBox.Show( dgCustomize.Rows[rowIdx]["s_FieldName"].ToString() + " value is already blank.", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                if (MessageBox.Show("Do you want to remove value for " + dgCustomize.Rows[rowIdx]["s_FieldName"].ToString(), "",
                                              MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    dgCustomize.Rows[rowIdx]["s_FieldValue"] = "";
                    dgCustomize.Rows[rowIdx]["s_HasChanged"] = "Y";

                    dgCustomize.Rows[rowIdx]["n_FieldMandatory"] = "D";
                }

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucCustomization), ex.Message);
                MessageBox.Show(ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

      

    }
}
