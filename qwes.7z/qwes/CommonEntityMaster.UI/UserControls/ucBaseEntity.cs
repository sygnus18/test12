﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FTIL.Match.CDD.BAL;
using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.CDD.UI.Forms;

namespace FTIL.Match.CDD.UI.UserControls
{
    public partial  class ucBaseEntity : UserControl
    {
       // public int ClientNo { get; set; }
        public Color ctrlBackColor = UIConstants.CtrlBackColor;
        public bool ModifyMode { get; set; }
        public string sName { get; set; }
        public string sShortCode { get; set; }
        
        public string sBranch { get; set; }
        public int n_Solutation { get; set; }
        public string EntityType { get; set; }
        public bool IsBankGridUpdated { get; set; }
        public bool IsOtherGridUpdated { get; set; }
        public string sClientHeaderName { get; set; }
        public virtual bool IsGridUpdated { get; set; }

        protected EntityDetails m_EntityDetailsInstance;
        protected bool m_HasAllDropDownListBind;


        protected bool m_HasUpdated;

        protected bool m_RequiredSync;


        public bool HasUpdated
        {
            get {
                    if (!ModifyMode) return true;
                    return m_HasUpdated; 
                }
            set { m_HasUpdated = value; }
        }

        public bool RequiredSync
        {
            get
            {
                return m_RequiredSync;
            }
            set { m_RequiredSync = value; }
        }


 
      
        public ucBaseEntity()
        {
            InitializeComponent();
            ModifyMode = false;
            m_HasAllDropDownListBind = false;
        }

        public EntityDetails EntityAccountInstance
        {
            get { return m_EntityDetailsInstance; }
            set { m_EntityDetailsInstance = value; }
        }

        protected virtual void PopulateLookup() { }

        protected virtual bool isValid() { return true; }


        public virtual void PopulateControls() { }

        public virtual EntityDetails GetEntityDetails() { return null; }


        /// Corrospondance Address updated 
        /// </summary>
        public virtual bool CorrAddressUpdated { get { return true; } }


        /// <summary>
        /// Permanent address updated
        /// </summary>
        public virtual bool PerAddressUpdated { get { return true; } }

        public virtual bool CheckChanges() { return false; }
        public virtual void ResetDt(){ }

        public virtual EventHandler OnAddIndividual
        {
            get;
            set;
        }


     


    }
}
