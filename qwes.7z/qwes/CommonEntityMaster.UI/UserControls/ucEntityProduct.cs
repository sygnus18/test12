﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FTIL.Match.CDD.BAL;
using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.CDD.UI.Forms;
using FTIL.Match.Common.Log;
using FTIL.Match.Common;

namespace FTIL.Match.CDD.UI.UserControls
{
    //public partial class ucEntityProduct : UserControl
    public partial class ucEntityProduct : FTIL.Match.CDD.UI.UserControls.ucBaseEntity
    {
        #region Variables

       // private FTIL.Match.CDD.ProductSync.Forms.frmFrame objFrame;
        //private CDD.ProductSync.Forms.frmFrame objFrame;

        private CProductSync m_ObjProductSync;
        private EntityDetails m_EntityDetails;
        private frmProcess objProcess;
        private MatchCommon.CustomControls.FTTextBox txtCDDCustCodeForGrid;
        private MatchCommon.CustomControls.FTTextBox txtDPCodeForGrid;
        //-------------------------------------------------------------------------------------------------

        private CExchangeMap m_ObjExchange;
        private frmProcess objProcess1;
        private MatchCommon.CustomControls.FTTextBox txtCDDCustCodeForGrid1;
        private MatchCommon.CustomControls.FTTextBox txtDPCodeForGrid1;
        CheckBox HeaderCheckBox = null;


        public string sClientHeaderName { get; set; }
        public int ClientNo { get; set; }
        public string CDDCode { get; set; }
        public string ClientName { get; set; }
        public string CustId { get; set; }
        public string EntityType { get; set; }

        public int BranchNo { get; set; }
        public int GroupNo { get; set; }
        public int UserId { get; set; }
        public DateTime? dFromDate { get; set; }
        DataTable dtProduct = null;
        //-------------------------------------------------------------------------------------------------------------
        

        public int ExNo { get; set; }
        public int ExMapingNo { get; set; }
        public int TradingCode { get; set; }
        public int CtclId { get; set; }
        public int TradingBranchId { get; set; }
        public int ExchangeNo { get; set; }
        public int AddModifyFlag { get; set; }

        public DataTable dtExchange = null;
        static int length = 0;
#endregion


        public EntityDetails EntityDetails
        {
            get { return m_EntityDetails; }
            set { m_EntityDetails = value; }
        }

        public CExchangeMap EntityProductDetails
        {
            get { return m_ObjExchange; }
        }

      

        public ucEntityProduct()
        {

            InitializeComponent();
            m_ObjExchange = new CExchangeMap();
            m_ObjProductSync = new CProductSync();
            dgvProduct.Cols.Fixed = UIConstants.FlexGridLeftFixColumn;
            dgvProduct.AllowEditing = true;
            dgvProduct.AllowSorting =  C1.Win.C1FlexGrid.AllowSortingEnum.None;

            txtCDDCustCodeForGrid = new MatchCommon.CustomControls.FTTextBox();
            txtCDDCustCodeForGrid.MaxLength = 30;
            txtCDDCustCodeForGrid.AllowAlpha = true;
            txtCDDCustCodeForGrid.AllowDot = false;
            txtCDDCustCodeForGrid.AllowNonASCII = false;
            txtCDDCustCodeForGrid.AllowSpace = false;
            txtCDDCustCodeForGrid.AllowSpecialChars = false;
            txtCDDCustCodeForGrid.AllowNumeric = true;

            txtDPCodeForGrid = new MatchCommon.CustomControls.FTTextBox();
            txtDPCodeForGrid.MaxLength = 30;
            txtDPCodeForGrid.AllowAlpha = true;
            txtDPCodeForGrid.AllowDot = false;
            txtDPCodeForGrid.AllowNonASCII = false;
            txtDPCodeForGrid.AllowSpace = false;
            txtDPCodeForGrid.AllowSpecialChars = false;
            txtDPCodeForGrid.AllowNumeric = true;


            //---------------------------------------------------------------------------------
            
            
            dgvClientExchange.Cols.Fixed = UIConstants.FlexGridLeftFixColumn;
            dgvClientExchange.AllowEditing = true;
            dgvClientExchange.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;

            txtCDDCustCodeForGrid1 = new MatchCommon.CustomControls.FTTextBox();
            txtCDDCustCodeForGrid1.MaxLength = 30;
            txtCDDCustCodeForGrid1.AllowAlpha = true;
            txtCDDCustCodeForGrid1.AllowDot = false;
            txtCDDCustCodeForGrid1.AllowNonASCII = false;
            txtCDDCustCodeForGrid1.AllowSpace = false;
            txtCDDCustCodeForGrid1.AllowSpecialChars = false;
            txtCDDCustCodeForGrid1.AllowNumeric = true;

            txtDPCodeForGrid1 = new MatchCommon.CustomControls.FTTextBox();
            txtDPCodeForGrid1.MaxLength = 30;
            txtDPCodeForGrid1.AllowAlpha = true;
            txtDPCodeForGrid1.AllowDot = false;
            txtDPCodeForGrid1.AllowNonASCII = false;
            txtDPCodeForGrid1.AllowSpace = false;
            txtDPCodeForGrid1.AllowSpecialChars = false;
            txtDPCodeForGrid1.AllowNumeric = true;
        }



        private void ucEntityProduct_Load(object sender, EventArgs e)
        {
            BindGrid();
        }

        public void PopulateControls()
        {
            BindGrid();
            if (this.CustId == "")
            {
                btnSync.Enabled = false;
            }
        }

        private void BindGrid()
        {
            m_ObjProductSync.GetEntityProducts(ClientNo, ref dtProduct);
            
            dgvProduct.DataSource = dtProduct;
            dgvProduct.Cols["n_ProductNo"].Visible = false;
            this.dgvProduct.Cols["n_LinkRequired"].Visible = false;
            this.dgvProduct.Cols["DPCode"].Visible = false;


            dgvProduct.Cols["b_Flag"].Caption = "";
            dgvProduct.Cols["s_ProductName"].Caption = "Product";
            dgvProduct.Cols["s_EntityProductID"].Caption = "Code";

            dgvProduct.Cols["b_Flag"].Width = 40;
            dgvProduct.Cols["s_ProductName"].Width = 150;
            dgvProduct.Cols["s_EntityProductID"].Width = 170;
            dgvProduct.Cols["Status"].Width = 70;
            dgvProduct.Cols["Last Sync Date"].Width = 130;
            dgvProduct.Cols["Description"].Width = 210;// 180;
            dgvProduct.Cols["s_EntityProductID"].Editor = txtCDDCustCodeForGrid;
            dgvProduct.Cols["DPCode"].Editor = txtDPCodeForGrid;

            dgvProduct.Cols["s_ProductName"].AllowEditing = false;
            this.dgvProduct.Cols["DPCode"].AllowEditing = false;
            this.dgvProduct.Cols["Description"].AllowEditing = false;
            this.dgvProduct.Cols["Status"].AllowEditing = false;
            this.dgvProduct.Cols["Last Sync Date"].AllowEditing = false;
            this.dgvProduct.Cols["Last Sync Date"].Format = "dd/MM/yy hh:mm tt";

            C1.Win.C1FlexGrid.CellStyle cs;
            cs = dgvProduct.Styles.Add("Blue");
            cs.Font = new Font(Font, FontStyle.Underline);
            cs.ForeColor = System.Drawing.Color.Blue;
            for (int iCnt = 1; iCnt <= dgvProduct.Rows.Count - 1; iCnt++)
            {
                if (this.dgvProduct.Rows[iCnt]["Description"].ToString() == "Successfull")// && this.dgvProduct.Rows[iCnt]["n_LinkRequired"].ToString() == "1")
                {
                    // dgvProduct.SetCellStyle(iCnt, 1, cs);
                    dgvProduct.Rows[iCnt]["Description"] = "Successful";
                }
            }
           
       //--------------------------------------------ANIL ADD FOR Exchange---------------------------------------------------------------------


            m_ObjExchange.GetExchangeDetailsForProduct(ClientNo, ref dtExchange, "S");

            dgvClientExchange.DataSource = dtExchange;

            this.dgvClientExchange.Cols["n_ClientExMapNo"].Visible = false;
            this.dgvClientExchange.Cols["n_ClientNo"].Visible = false;
            this.dgvClientExchange.Cols["n_ExNo"].Visible = false;

            this.dgvClientExchange.Cols["ExchangeNo"].Visible = false;

            this.dgvClientExchange.Cols["n_SegmentNo"].Visible = false;
            this.dgvClientExchange.Cols["s_CPCode"].Visible = false;
            this.dgvClientExchange.Cols["n_ClientType"].Visible = false;

            this.dgvClientExchange.Cols["n_AccountType"].Visible = false;
            this.dgvClientExchange.Cols["d_ClientAgreementDate"].Visible = false;
            this.dgvClientExchange.Cols["s_InpersonVerification"].Visible = false;

            this.dgvClientExchange.Cols["s_ClientStatus"].Visible = false;
            this.dgvClientExchange.Cols["s_Remarks"].Visible = false;
            this.dgvClientExchange.Cols["s_UCCDownloaded"].Visible = false;

            this.dgvClientExchange.Cols["n_BatchNo"].Visible = false;
            this.dgvClientExchange.Cols["n_BranchNo"].Visible = false;
            this.dgvClientExchange.Cols["n_GroupNo"].Visible = false;

            this.dgvClientExchange.Cols["n_UCCRejRefNo"].Visible = false;
            this.dgvClientExchange.Cols["d_LastModifiedDateTime"].Visible = false;
            this.dgvClientExchange.Cols["s_Relationship"].Visible = false;

            this.dgvClientExchange.Cols["n_UserNo"].Visible = false;
            this.dgvClientExchange.Cols["n_MakerUser"].Visible = false;
            this.dgvClientExchange.Cols["d_MakerDatetime"].Visible = false;

            this.dgvClientExchange.Cols["n_AuthorizeUser"].Visible = false;
            this.dgvClientExchange.Cols["d_AuthorizeDatetime"].Visible = false;
            this.dgvClientExchange.Cols["s_AuthorizationRemarks"].Visible = false;

            this.dgvClientExchange.Cols["s_IsPendingAuth"].Visible = false;
            this.dgvClientExchange.Cols["s_AuthorizedStatus"].Visible = false;

            dgvClientExchange.Cols["ExchangeCode"].Caption = "Exchange";
            dgvClientExchange.Cols["ExchangeName"].Caption = "Exchange Name";
            dgvClientExchange.Cols["s_Code"].Caption = "Trading Code";
            dgvClientExchange.Cols["s_CTCLTWSId"].Caption = "Ctcl/Tws Id";
            dgvClientExchange.Cols["s_TradingBranchCode"].Caption = "Trading Branch Id";



            //dgvClientExchange.Cols["b_Flag"].Width = 75;
            dgvClientExchange.Cols["ExchangeCode"].Width = 80;
            dgvClientExchange.Cols["ExchangeName"].Width = 240;
            dgvClientExchange.Cols["s_Code"].Width = 150;
            dgvClientExchange.Cols["s_CTCLTWSId"].Width = 150;
            dgvClientExchange.Cols["s_TradingBranchCode"].Width = 150;

            //dgvClientExchange.Cols["b_Flag"].AllowEditing = false;
            this.dgvClientExchange.Cols["ExchangeCode"].AllowEditing = false;
            this.dgvClientExchange.Cols["ExchangeName"].AllowEditing = false;
            this.dgvClientExchange.Cols["s_Code"].AllowEditing = true;
            this.dgvClientExchange.Cols["s_CTCLTWSId"].AllowEditing = true;
            this.dgvClientExchange.Cols["s_TradingBranchCode"].AllowEditing = true;
          

       //--------------------------------------------------------------------------------------------------------------------------------------
        }


        /// <summary>
        /// sync with realeted API
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSync_Click(object sender, EventArgs e)
        {
        
            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (dgvProduct.Rows.Count > 0)
                {
                                      

                    MethodExecResult l_objMethodExceResult = new MethodExecResult(0);
                    //m_ObjProductSync.CDDCode = this.CDDCode;
                    m_ObjProductSync.ClientNo = this.ClientNo;
                    m_ObjProductSync.ClientName = this.ClientName;
                    m_ObjProductSync.CustId = this.CustId;
                    m_ObjProductSync.EntityType = this.EntityType;

                    DataRow[] dr = dtProduct.Select("b_Flag = true");
                    if (dr.Length == 0)
                    {
                        MessageBox.Show("Kindly select at least one product.", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Cursor = Cursors.Default;
                        return;
                    }
                    objProcess = new frmProcess();
                        

                    objProcess.ClientNo = this.ClientNo;

                    //objProcess.CDDCode = this.CDDCode;
                    objProcess.ClientNo = this.ClientNo;
                    objProcess.ClientName = this.ClientName;
                    objProcess.CustId = this.CustId;
                    objProcess.EntityType = this.EntityType;
                    objProcess.dFromDate = this.dFromDate;


                    objProcess.dtProduct = dtProduct;
                    objProcess.BindGrid();
                    objProcess.ShowDialog();

                    C1.Win.C1FlexGrid.CellStyle cs;
                    cs = dgvProduct.Styles.Add("Blue");
                    cs.Font = new Font(Font, FontStyle.Underline);
                    cs.ForeColor = System.Drawing.Color.Blue;

                    for (int iCnt = 1; iCnt <= dgvProduct.Rows.Count - 1; iCnt++)
                    {

                        if (this.dgvProduct.Rows[iCnt]["Description"].ToString() == "Successfull" && this.dgvProduct.Rows[iCnt]["n_LinkRequired"].ToString() == "1")
                        {
                           // dgvProduct.SetCellStyle(iCnt, 1, cs);
                        }
                    }

                    this.Cursor = Cursors.Default;
                  



                    //objProcess.setVal(iCnt.ToString());

                    //for (int iCnt = 1; iCnt <= dgvProduct.Rows.Count - 1; iCnt++)
                    //{
                        
                    //    if (Convert.ToInt32(this.dgvProduct.Rows[iCnt][0]) == 1)
                    //    {
                    //        nCheckCount += 1;
                    //        dtProduct.Rows[iCnt-1]["Status"] = "Processing";

                    //        s_Products += this.dgvProduct.Rows[iCnt]["n_ProductNo"].ToString() + ",";
                    //        m_ObjProductSync.ProductId = Convert.ToInt32(this.dgvProduct.Rows[iCnt]["n_ProductNo"].ToString());
                    //        m_ObjProductSync.EntityProductID = this.dgvProduct.Rows[iCnt]["s_EntityProductID"].ToString();
                    //        iLen = m_ObjProductSync.EntityProductID.Length;
                    //        if (m_ObjProductSync.EntityProductID == "")
                    //        {
                    //            MessageBox.Show("Code can not left blank.", string.Empty, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //            return;
                    //        }
                    //        if (iLen > 12)
                    //            m_ObjProductSync.EntityProductID = m_ObjProductSync.EntityProductID.Substring(iLen-12, 12);
                           
                    //        //l_objMethodExceResult=m_ObjProductSync.SyncProducts(m_ObjProductSync.ProductId);
                    //        if(m_ObjProductSync.ProductId==1)
                    //            m_ObjProductSync.SyncProductsMatch(m_ObjProductSync.ProductId);
                    //        else if (m_ObjProductSync.ProductId == 17 || m_ObjProductSync.ProductId == 18)
                    //        {
                    //            m_ObjProductSync.DPCode = this.dgvProduct.Rows[iCnt]["DPCode"].ToString();
                    //            m_ObjProductSync.DPType = this.dgvProduct.Rows[iCnt]["s_ProductName"].ToString();
                    //            m_ObjProductSync.DPType = m_ObjProductSync.DPType.Substring(m_ObjProductSync.DPType.Length - 4, 4);
                    //            m_ObjProductSync.dFromDate = dFromDate;

                    //            if (m_ObjProductSync.DPCode == "")
                    //            {
                    //                MessageBox.Show("Code can not left blank for product <" + this.dgvProduct.Rows[iCnt]["s_ProductName"].ToString() + ">" , string.Empty, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //                return;
                    //            }

                    //            m_ObjProductSync.SyncProductsMatchDP(m_ObjProductSync.ProductId);


                    //        }


                    //       if (m_ObjProductSync.nErrorNo == 102)
                    //       {
                    //           MessageBox.Show( "Code " + m_ObjProductSync.EntityProductID + " is already exist.", string.Empty, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //       }
                    //       //else if (m_ObjProductSync.nErrorNo != 0)
                    //       //{
                    //       //    MessageBox.Show(m_ObjProductSync.sErrorMsg , string.Empty, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //       //}
                           
                    //       if (m_ObjProductSync.nErrorNo == 0)
                    //       {
                    //           this.dgvProduct.Cols["s_ProductName"].Style.ForeColor = System.Drawing.Color.Blue;
                              
                    //           dtProduct.Rows[iCnt-1]["Status"] = "Done";
                    //           dtProduct.Rows[iCnt - 1]["Description"] = "Successfull";
                    //       }
                    //       else
                    //       {
                    //           dtProduct.Rows[iCnt - 1]["Status"] = "Error";
                    //           dtProduct.Rows[iCnt - 1]["Description"] = m_ObjProductSync.sErrorMsg;

                    //       }
                    //    }

                    //}

                    //if (nCheckCount == 0)
                    //{
                    //    MessageBox.Show("Kindly select at least one product.", string.Empty, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //    return;
                    //}

                    //if ((l_objMethodExceResult.ReturnCode == 0 && nCheckCount != 0) || (m_ObjProductSync.nErrorNo == 0 && nCheckCount != 0))
                    //{
                    //    MessageBox.Show("Sync proccess successfully completed.", string.Empty, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //}

                }
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                Logger.Instance.WriteLog(typeof(frmEntityDetail), ex.Message);
                MessageBox.Show(MatchCommon.CCommon.CommonUpdateFailureMessage, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvProduct_DoubleClick(object sender, EventArgs e)
        {
        }

       
        private void dgvProduct_Click(object sender, EventArgs e)
        {
            int iRowIndx = this.dgvProduct.RowSel;
            int iColIndx = this.dgvProduct.ColSel;
            if (iColIndx == 0)
                this.dgvProduct.Rows[iRowIndx].AllowEditing = true;

            if (this.dgvProduct.Rows[iRowIndx]["Description"].ToString() == "Successfull" && iColIndx >0)
            {
                this.dgvProduct.Rows[iRowIndx].AllowEditing = false;
            }

            if (this.dgvProduct.Rows[iRowIndx]["b_Flag"].ToString() == "True" &&
                (this.dgvProduct.Rows[iRowIndx]["n_ProductNo"].ToString() == "17" || this.dgvProduct.Rows[iRowIndx]["n_ProductNo"].ToString() == "18")
                && this.dgvProduct.Rows[iRowIndx]["Description"].ToString() != "Successfull")
            {
                this.dgvProduct.Cols["DPCode"].AllowEditing = true;
                //this.dgvProduct.Cols["DPCode"].Visible = true;                  
            }
            else 
            {
                this.dgvProduct.Cols["DPCode"].AllowEditing = false;
            }

            //if (this.dgvProduct.Rows[iRowIndx]["Description"].ToString() == "Successfull" && iColIndx == 1 && this.dgvProduct.Rows[iRowIndx]["n_LinkRequired"].ToString() == "1")
            //{
            //    if (this.dgvProduct.Rows[iRowIndx]["n_ProductNo"].ToString() == "X")
            //    {
            //        //string sBinDirName;
            //        //sBinDirName = Environment.CurrentDirectory;
            //        //sBinDirName = sBinDirName + @"\Apps\CDD.ProductSync.exe";
            //        //System.Diagnostics.Process.Start(sBinDirName);
            //        //dgvProduct.ColSel = 0;
            //        return;
            //    }
            //    else
            //    {

            //        objFrame = new FTIL.Match.CDD.ProductSync.Forms.frmFrame();
            //        objFrame.ProductId = Convert.ToInt32(this.dgvProduct.Rows[iRowIndx]["n_ProductNo"].ToString());
            //        objFrame.strProductName = this.dgvProduct.Rows[iRowIndx]["s_ProductName"].ToString();
            //        objFrame.ShowDialog();
            //        dgvProduct.ColSel = 0;
            //    }
            //}
          
        }

        public void Save()
        {
            try
            {
                EntityProductDetails.dtExchangeResult = (DataTable)dgvClientExchange.DataSource;
            }
            catch (Exception Ex)
            {

                throw Ex;
            }
        }



    }
}
