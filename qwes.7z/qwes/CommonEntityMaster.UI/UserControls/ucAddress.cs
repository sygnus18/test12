﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.Common.Log;
using UCC.Class;
using UCC;
using FTIL.Match.CDD.UI.Forms;

namespace FTIL.Match.CDD.UI.UserControls
{
    /// <summary>
    /// User Control for Address
    /// </summary>
    public partial class ucAddress : UserControl
    {
        private bool m_HasControlsBound;
        private Color ctrlBackColor;
        private  Address m_AddressInstance;
        private static Address m_AddressForCopyPaste;
        public bool isMandatory { get; set; }
        private int m_nAddressNo;
        /// <summary>
        /// Current record/selected city-state code
        /// </summary>
        private int m_iCityStateCode;


        /// <summary>
        /// Message box title
        /// </summary>
        private string m_sMsgBoxTitle;
        public bool HasUpdated {get; set;}
        public ucAddress()
        {
            m_sMsgBoxTitle = string.Empty;
            m_AddressInstance = new Address();
            InitializeComponent();
        
            ctrlBackColor = UIConstants.CtrlBackColor;
            cboCity.SelectedIndexChanged += cboCity_SelectedIndexChanged;
      
            m_HasControlsBound = false;

           //txtAddress.Select(0, 0);
        }

        private void ucAddress_Load(object sender, EventArgs e)
        {
            try
            {
                PopulateLookup();
                pasteToolStripMenuItem.Enabled = !(m_AddressForCopyPaste == null);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucAddress), ex.Message);
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //txtAddress.SelectionStart = 0;
            //txtAddress.SelectionLength = txtAddress.Text.Length;
            //txtAddress.Focus();
            //txtAddress.Select();


        }


        /// <summary>
        /// Get Address object, filled by the Controls
        /// </summary>
        /// <returns></returns>
        public Address GetAddress()
        {
            try
            {
                string[] sAddress = null;
                string sTempData = txtAddress.Text.ToString().Trim();
                sAddress = sTempData.Split(new[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);

                 //if (sAddress.Length == 0) return null;
                if (sAddress.Length != 0)
                {
                    m_AddressInstance.Address_Line1 = sAddress[0].Trim();

                    if (sAddress.Length > 1)
                        m_AddressInstance.Address_Line2 = sAddress[1].Trim();
                    m_AddressInstance.Address_Line3 = "";
                    if (sAddress.Length > 2)
                        for (int i = 2; i < sAddress.Length; i++)
                            if (sAddress[i].Trim() != "")
                                m_AddressInstance.Address_Line3 += sAddress[i].Trim() + " ";
                }
                else
                    m_AddressInstance.Address_Line1 = null;

                if (!HasUpdated)
                {
                    HasUpdated = false;
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_AddressInstance.City, cboCity.GetSelectedValue());
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_AddressInstance.Country, cboCountry.GetSelectedValue());
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_AddressInstance.Email_ID, txtMail.Text);
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_AddressInstance.Mobile_No, txtMobile.Text);
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_AddressInstance.PIN_Code, txtPIN.Text);
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_AddressInstance.StateCode, cboState.GetSelectedValue());
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_AddressInstance.Tel_Res, txtTel1.Text);
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_AddressInstance.Tel_Work, txtTel2.Text);
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_AddressInstance.Fax_No, txtFax.Text);
                }

                m_AddressInstance.City = cboCity.GetSelectedValue();
                m_AddressInstance.Country = cboCountry.GetSelectedValue();
                m_AddressInstance.Email_ID = txtMail.Text;
                m_AddressInstance.Mobile_No = txtMobile.Text;
                m_AddressInstance.PIN_Code = txtPIN.Text;
                m_AddressInstance.StateCode = cboState.GetSelectedValue();
                m_AddressInstance.Tel_Res = txtTel1.Text;
                m_AddressInstance.Tel_Work = txtTel2.Text;
                m_AddressInstance.Fax_No = txtFax.Text;
                m_AddressInstance.AddressNo = m_nAddressNo;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucAddress), ex.Message);
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return m_AddressInstance;
        }



        /// <summary>
        /// Get Address object, filled by the Controls
        /// </summary>
        /// <returns></returns>


        /// <summary>
        /// Bind Controls from Address object
        /// </summary>
        /// <param name="address"></param>
        public void PopupateControls(Address address)
        {
            if (address == null)   return;
            
            try
            {
                m_nAddressNo = address.AddressNo;
      
                if (address.Address_Line1 != "")
                {
                    txtAddress.Text = address.Address_Line1 + Environment.NewLine +
                        address.Address_Line2 + Environment.NewLine +
                        address.Address_Line3;
                }

                    txtMail.Text = address.Email_ID;
                    txtMobile.Text = address.Mobile_No;
                    txtPIN.Text = address.PIN_Code;
                    txtTel1.Text = address.Tel_Res;
                    txtTel2.Text = address.Tel_Work;
                    txtFax.Text = address.Fax_No;

                    cboCity.SetSelectedValue(address.City);
                    cboCountry.SetSelectedValue(address.Country);
                    cboState.SetSelectedValue(address.StateCode);

                //txtAddress.SelectionStart = 0;
                //txtAddress.Focus();
                //txtAddress.Select();
                while (txtAddress.Text.EndsWith(Environment.NewLine))
                {
                    txtAddress.Text=txtAddress.Text.Substring(0, txtAddress.Text.Length-Environment.NewLine.Length);
                }
                txtAddress.SelectionStart = 0;
                txtAddress.SelectionLength = txtAddress.Text.Length;
                txtAddress.Focus();
                txtAddress.Select();

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucAddress), ex.Message);
                //MessageBox.Show("Unable to fill address details", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }


     


        /// <summary>
        /// Bind City, State and Country DropDown list
        /// </summary>
        public void PopulateLookup()
        {
            if (m_HasControlsBound) return;
            try
            {

                cboCity.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                cboCity.AutoCompleteSource = AutoCompleteSource.ListItems;

                cboCity.ValueMember = "n_CityStateCode";
                cboCity.DisplayMember = "s_City";

                cboCity.DataSource = new BindingSource(CMastersDataProvider.Instance[Masters.CityStateMapping], null);


                cboState.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                cboState.AutoCompleteSource = AutoCompleteSource.ListItems;

                DataTable l_dt = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.STATE];
                l_dt.DefaultView.Sort = "s_ReferenceName asc";
                cboState.ValueMember = "s_ReferenceCode";
                cboState.DisplayMember = "s_ReferenceName";
                cboState.DataSource = new BindingSource(l_dt, null);

                cboCountry.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                cboCountry.AutoCompleteSource = AutoCompleteSource.ListItems;

                DataTable dtCountry = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.COUNTRY];
                cboCountry.ValueMember= "s_ReferenceCode";
                cboCountry.DisplayMember = "s_ReferenceName";
                cboCountry.DataSource = new BindingSource(dtCountry, null);

                
                cboCity.SelectedValue = 0;
                cboState.SelectedValue = 0;
                cboCountry.SelectedValue = 0;

                if (isMandatory)
                {

                    txtAddress.BackColor = ctrlBackColor;
                    txtMail.BackColor = ctrlBackColor;
                    txtMobile.BackColor = ctrlBackColor;
                    txtPIN.BackColor = ctrlBackColor;
                    cboCity.BackColor = ctrlBackColor;
                    cboCountry.BackColor = ctrlBackColor;
                    cboState.BackColor = ctrlBackColor;

                }

                m_HasControlsBound = true;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucAddress), ex.Message);
                MessageBox.Show("Unable to fill address details", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        /// <summary>
        /// City combo item changed event handler.
        /// Populates City & state mapped with current city.
        /// Sets current CityState code number.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        //#region cboCity_SelectedIndexChanged
        private void cboCity_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable l_dtCity = CMastersDataProvider.Instance[Masters.CityStateMapping];
            if (l_dtCity == null)
                return;
            if (cboCity.SelectedValue == null)
                return;

            try
            {
                DataRow[] l_objRows = l_dtCity.Select("n_CityStateCode = " + cboCity.SelectedValue.ToString());
                if ((l_objRows != null) && (l_objRows.Length > 0))
                {
                    m_iCityStateCode = Convert.ToInt32(cboCity.SelectedValue.ToString());
                    cboState.SelectedValue = l_objRows[0]["n_StateNumber"].ToString();
                    cboCountry.SelectedValue = l_objRows[0]["n_CountryCode"].ToString();
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                MessageBox.Show("Unable to set state/country", m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }
        //#endregion

        /// <summary>
        /// City text changed event handler.
        /// Sets State combo to Others. Clears current CityState code number.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region cboCity_TextUpdate
        private void cboCity_TextUpdate(object sender, EventArgs e)
        {
            try
            {
                m_iCityStateCode = 0;
                cboState.SelectedValue = CUCCConstants.Instance.OTHER_STATE_CODE;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
            }
        }
        #endregion


        /// <summary>
        /// Clear all control values
        /// </summary>
        public void ClearControls()
        {
            txtAddress.Text = "";
            txtMail.Text = "";
            txtMobile.Text ="";
            txtPIN.Text = "";
            txtTel1.Text = "";
            txtTel2.Text = "";
            txtFax.Text = "";

            cboCity.SelectedIndex=-1;
            cboCountry.SelectedIndex = -1;
            cboState.SelectedIndex = -1;
        }

        /// <summary>
        /// Copy Address details from Controls
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            m_AddressForCopyPaste = GetAddress();
            pasteToolStripMenuItem.Enabled = !(m_AddressForCopyPaste == null);
        }

        /// <summary>
        /// Populate Address details from copied object
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PopupateControls(m_AddressForCopyPaste);
        }

        private void txtMail_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMobile_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTel2_TextChanged(object sender, EventArgs e)
        {

        }

        private void cboCity_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void txtAddress_TextChanged(object sender, EventArgs e)
        {
            //int strt = txtAddress.SelectionStart;
            // var pos = txtAddress.SelectionLength;

            // txtAddress.SelectionStart = strt;
          
        }

        

    }
}
