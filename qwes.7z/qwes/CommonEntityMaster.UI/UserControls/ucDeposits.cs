﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FTIL.Match.CDD.UI.UserControls
{
    public partial class ucDeposits : UserControl
    {
        public ucDeposits()
        {
            InitializeComponent();
        }

        private void chkSettleLtGrossExposure_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSettleLtGrossExposure.Checked)
            {
                txtMultiplierGrossExposure.Enabled = true;
                // txtSettleLtGrossExposure.Enabled = true;
            }
            else
            {
                txtMultiplierGrossExposure.Enabled = false;
                //txtSettleLtGrossExposure.Enabled = false;
            }
        }

        private void chkSettlLtNetPurchase_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSettlLtNetPurchase.Checked)
            {
                txtMultiplierNetPurchase.Enabled = true;
                //txtsettlLtNetPurchase.Enabled = true;
            }
            else
            {
                txtMultiplierNetPurchase.Enabled = false;
                //txtsettlLtNetPurchase.Enabled = false;
            }

        }

        private void chkSettlLtNetSale_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSettlLtNetSale.Checked)
            {
                txtMultiplierNetSale.Enabled = true;
                //txtSettlLtNetSale.Enabled = true;
            }
            else
            {
                txtMultiplierNetSale.Enabled = false;
                //txtSettlLtNetSale.Enabled = false;
            }

        }

        private void chkSettlLtNetQty_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSettlLtNetQty.Checked)
            {
                txtmultiplierNetQty.Enabled = true;
                //txtSettlLtNetQty.Enabled = true;
            }
            else
            {
                txtmultiplierNetQty.Enabled = false;
                //txtSettlLtNetQty.Enabled = false;
            }

        }

        private void chkSettlLtNetPos_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSettlLtNetQty.Checked)
            {
                txtMultiplierNetPos.Enabled = true;
                // txtSettlLtNetPos.Enabled = true;
            }
            else
            {
                txtMultiplierNetPos.Enabled = false;
                //  txtSettlLtNetPos.Enabled = false;
            }

        }

        private void chkSettlLtNetTurnOver_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSettlLtNetQty.Checked)
            {
                txtMultiplierNetTurnOver.Enabled = true;
                // txtSettlLtNetTurnOver.Enabled = true;
            }
            else
            {
                txtMultiplierNetTurnOver.Enabled = false;
                //txtSettlLtNetTurnOver.Enabled = false;
            }
        }

        private void chkSettlLtMTMLt_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSettlLtMTMLt.Checked)
            {
                txtMultiplierMTMLt.Enabled = true;
                // txtSettlLtMTMLt.Enabled = true;
            }
            else
            {
                txtMultiplierMTMLt.Enabled = false;
                // txtSettlLtMTMLt.Enabled = false;
            }
        }

        private void chkSettlLtMargin_CheckedChanged(object sender, EventArgs e)
        {

            if (chkSettlLtMargin.Checked)
            {
                txtMultiplierMargin.Enabled = true;
                //txtSettlLtMargin.Enabled = true;
            }
            else
            {
                txtMultiplierMargin.Enabled = false;
                //txtSettlLtMargin.Enabled = false;
            }
        }

    }
}
