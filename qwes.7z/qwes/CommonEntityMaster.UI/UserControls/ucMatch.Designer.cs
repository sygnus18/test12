﻿namespace FTIL.Match.CDD.UI.UserControls
{
    partial class ucMatch
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPrefernces = new System.Windows.Forms.Button();
            this.btnCustodian = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnPrefernces
            // 
            this.btnPrefernces.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrefernces.Location = new System.Drawing.Point(19, 45);
            this.btnPrefernces.Name = "btnPrefernces";
            this.btnPrefernces.Size = new System.Drawing.Size(83, 32);
            this.btnPrefernces.TabIndex = 2;
            this.btnPrefernces.Text = "Preferences";
            this.btnPrefernces.UseVisualStyleBackColor = true;
            this.btnPrefernces.Visible = true;
            this.btnPrefernces.Click += new System.EventHandler(this.btnPrefernces_Click);
            // 
            // btnCustodian
            // 
            this.btnCustodian.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCustodian.Location = new System.Drawing.Point(156, 45);
            this.btnCustodian.Name = "btnCustodian";
            this.btnCustodian.Size = new System.Drawing.Size(83, 32);
            this.btnCustodian.TabIndex = 3;
            this.btnCustodian.Text = "Custodian";
            this.btnCustodian.UseVisualStyleBackColor = true;
            this.btnCustodian.Visible = true;
            this.btnCustodian.Click += new System.EventHandler(this.btnCustodian_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnPrefernces);
            this.groupBox1.Controls.Add(this.btnCustodian);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(276, 160);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            // 
            // ucMatch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.groupBox1);
            this.Name = "ucMatch";
            this.Size = new System.Drawing.Size(787, 499);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnPrefernces;
        private System.Windows.Forms.Button btnCustodian;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}
