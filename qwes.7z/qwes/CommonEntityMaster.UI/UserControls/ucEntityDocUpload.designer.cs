﻿namespace FTIL.Match.CDD.UI.UserControls
{
    partial class ucEntityDocUpload
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucEntityDocUpload));
            this.ftBtnRemoveDoc = new MatchCommon.CustomControls.FTButton();
            this.ftLabel77 = new MatchCommon.CustomControls.FTLabel();
            this.dgvDocUpload = new MatchCommon.CustomControls.FTDataGrid();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.lblUploadLog = new MatchCommon.CustomControls.FTLabel();
            this.btnImport = new System.Windows.Forms.Button();
            this.txtComment = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel81 = new MatchCommon.CustomControls.FTLabel();
            this.ftCmbTypeofDocument = new MatchCommon.CustomControls.FTComboBox();
            this.ftGroupBox3 = new MatchCommon.CustomControls.FTGroupBox();
            this.picDocument = new MatchCommon.CustomControls.FTPictureBox();
            this.btnExport = new MatchCommon.CustomControls.FTButton();
            this.pnlButtons = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDocUpload)).BeginInit();
            this.groupBox11.SuspendLayout();
            this.ftGroupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picDocument)).BeginInit();
            this.pnlButtons.SuspendLayout();
            this.SuspendLayout();
            // 
            // ftBtnRemoveDoc
            // 
            this.ftBtnRemoveDoc.BackColor = System.Drawing.Color.Transparent;
            this.ftBtnRemoveDoc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ftBtnRemoveDoc.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.ftBtnRemoveDoc.Image = ((System.Drawing.Image)(resources.GetObject("ftBtnRemoveDoc.Image")));
            this.ftBtnRemoveDoc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ftBtnRemoveDoc.Location = new System.Drawing.Point(88, 4);
            this.ftBtnRemoveDoc.Name = "ftBtnRemoveDoc";
            this.ftBtnRemoveDoc.Size = new System.Drawing.Size(75, 25);
            this.ftBtnRemoveDoc.TabIndex = 5;
            this.ftBtnRemoveDoc.Text = "&Remove";
            this.ftBtnRemoveDoc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ftBtnRemoveDoc.UseVisualStyleBackColor = false;
            this.ftBtnRemoveDoc.Click += new System.EventHandler(this.ftBtnRemoveDoc_Click);
            // 
            // ftLabel77
            // 
            this.ftLabel77.AllowForeColorChange = false;
            this.ftLabel77.AutoSize = true;
            this.ftLabel77.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel77.ForeColor = System.Drawing.Color.Black;
            this.ftLabel77.Location = new System.Drawing.Point(270, 27);
            this.ftLabel77.Name = "ftLabel77";
            this.ftLabel77.OverrideDefault = false;
            this.ftLabel77.Size = new System.Drawing.Size(52, 13);
            this.ftLabel77.TabIndex = 69;
            this.ftLabel77.Text = "Comment";
            // 
            // dgvDocUpload
            // 
            this.dgvDocUpload.AllowEditing = false;
            this.dgvDocUpload.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
            this.dgvDocUpload.BackColor = System.Drawing.Color.White;
            this.dgvDocUpload.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.dgvDocUpload.ColumnInfo = "5,1,0,0,0,95,Columns:0{Width:30;}\t";
            this.dgvDocUpload.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
            this.dgvDocUpload.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dgvDocUpload.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.dgvDocUpload.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
            this.dgvDocUpload.Location = new System.Drawing.Point(0, 2);
            this.dgvDocUpload.Name = "dgvDocUpload";
            this.dgvDocUpload.Styles.EmptyArea.BackColor = System.Drawing.Color.White;
            this.dgvDocUpload.OverrideDefault = false;
            this.dgvDocUpload.Rows.Count = 10;
            this.dgvDocUpload.Rows.DefaultSize = 19;
            this.dgvDocUpload.Rows.MinSize = 25;
            this.dgvDocUpload.RowsFilter.AddFilterRow = false;
            this.dgvDocUpload.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.ListBox;
            this.dgvDocUpload.Size = new System.Drawing.Size(250, 313);
            this.dgvDocUpload.StyleInfo = "";
            this.dgvDocUpload.TabIndex = 4;
            this.dgvDocUpload.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.dgvDocUpload_PreviewKeyDown);

            this.dgvDocUpload.Styles.EmptyArea.BackColor = System.Drawing.Color.White;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Type";
            this.dataGridViewTextBoxColumn4.MaxInputLength = 100;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // Date
            // 
            this.Date.HeaderText = "Date";
            this.Date.Name = "Date";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.lblUploadLog);
            this.groupBox11.Controls.Add(this.btnImport);
            this.groupBox11.Controls.Add(this.ftLabel77);
            this.groupBox11.Controls.Add(this.txtComment);
            this.groupBox11.Controls.Add(this.ftLabel81);
            this.groupBox11.Controls.Add(this.ftCmbTypeofDocument);
            this.groupBox11.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.groupBox11.Location = new System.Drawing.Point(0, 324);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(768, 102);
            this.groupBox11.TabIndex = 2;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Identification";
            // 
            // lblUploadLog
            // 
            this.lblUploadLog.AllowForeColorChange = false;
            this.lblUploadLog.AutoSize = true;
            this.lblUploadLog.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblUploadLog.ForeColor = System.Drawing.Color.Black;
            this.lblUploadLog.Location = new System.Drawing.Point(388, 28);
            this.lblUploadLog.Name = "lblUploadLog";
            this.lblUploadLog.OverrideDefault = false;
            this.lblUploadLog.Size = new System.Drawing.Size(0, 13);
            this.lblUploadLog.TabIndex = 1;
            // 
            // btnImport
            // 
            this.btnImport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnImport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnImport.Image = ((System.Drawing.Image)(resources.GetObject("btnImport.Image")));
            this.btnImport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnImport.Location = new System.Drawing.Point(688, 22);
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(75, 25);
            this.btnImport.TabIndex = 0;
            this.btnImport.Text = "Upload";
            this.btnImport.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnImport.UseVisualStyleBackColor = true;
            this.btnImport.Click += new System.EventHandler(this.btnImport_Click);
            // 
            // txtComment
            // 
            this.txtComment.AllowAlpha = true;
            this.txtComment.AllowDot = true;
            this.txtComment.AllowedCustomCharacters = null;
            this.txtComment.AllowNonASCII = false;
            this.txtComment.AllowNumeric = true;
            this.txtComment.AllowSpace = true;
            this.txtComment.AllowSpecialChars = true;
            this.txtComment.FocusColor = System.Drawing.Color.LightYellow;
            this.txtComment.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtComment.ForeColor = System.Drawing.Color.Black;
            this.txtComment.IsEmailID = false;
            this.txtComment.IsEmailIdValid = false;
            this.txtComment.Location = new System.Drawing.Point(328, 24);
            this.txtComment.MaxLength = 255;
            this.txtComment.Multiline = true;
            this.txtComment.Name = "txtComment";
            this.txtComment.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtComment.Size = new System.Drawing.Size(353, 72);
            this.txtComment.TabIndex = 5;
            this.txtComment.Tag = "Code";
            // 
            // ftLabel81
            // 
            this.ftLabel81.AllowForeColorChange = false;
            this.ftLabel81.AutoSize = true;
            this.ftLabel81.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel81.ForeColor = System.Drawing.Color.Black;
            this.ftLabel81.Location = new System.Drawing.Point(6, 28);
            this.ftLabel81.Name = "ftLabel81";
            this.ftLabel81.OverrideDefault = false;
            this.ftLabel81.Size = new System.Drawing.Size(95, 13);
            this.ftLabel81.TabIndex = 53;
            this.ftLabel81.Text = "Type of Document";
            // 
            // ftCmbTypeofDocument
            // 
            this.ftCmbTypeofDocument.BackColor = System.Drawing.Color.White;
            this.ftCmbTypeofDocument.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ftCmbTypeofDocument.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ftCmbTypeofDocument.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftCmbTypeofDocument.ForeColor = System.Drawing.Color.Black;
            this.ftCmbTypeofDocument.FormattingEnabled = true;
            this.ftCmbTypeofDocument.Location = new System.Drawing.Point(102, 24);
            this.ftCmbTypeofDocument.Name = "ftCmbTypeofDocument";
            this.ftCmbTypeofDocument.ReadOnly = false;
            this.ftCmbTypeofDocument.Size = new System.Drawing.Size(156, 21);
            this.ftCmbTypeofDocument.TabIndex = 0;
            // 
            // ftGroupBox3
            // 
            this.ftGroupBox3.Controls.Add(this.picDocument);
            this.ftGroupBox3.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftGroupBox3.ForeColor = System.Drawing.Color.DimGray;
            this.ftGroupBox3.Location = new System.Drawing.Point(259, 3);
            this.ftGroupBox3.Name = "ftGroupBox3";
            this.ftGroupBox3.Size = new System.Drawing.Size(508, 315);
            this.ftGroupBox3.TabIndex = 2;
            this.ftGroupBox3.TabStop = false;
            this.ftGroupBox3.Text = "Document";
            // 
            // picDocument
            // 
            this.picDocument.Location = new System.Drawing.Point(6, 16);
            this.picDocument.Name = "picDocument";
            this.picDocument.Size = new System.Drawing.Size(497, 293);
            this.picDocument.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDocument.TabIndex = 0;
            this.picDocument.TabStop = false;
            this.picDocument.DoubleClick += new System.EventHandler(this.picDocument_DoubleClick);
            // 
            // btnExport
            // 
            this.btnExport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExport.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnExport.Image = ((System.Drawing.Image)(resources.GetObject("btnExport.Image")));
            this.btnExport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExport.Location = new System.Drawing.Point(6, 4);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(75, 25);
            this.btnExport.TabIndex = 4;
            this.btnExport.Text = "&Export";
            this.btnExport.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // pnlButtons
            // 
            this.pnlButtons.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlButtons.Controls.Add(this.btnExport);
            this.pnlButtons.Controls.Add(this.ftBtnRemoveDoc);
            this.pnlButtons.Location = new System.Drawing.Point(600, 473);
            this.pnlButtons.Name = "pnlButtons";
            this.pnlButtons.Size = new System.Drawing.Size(167, 32);
            this.pnlButtons.TabIndex = 3;
            // 
            // ucEntityDocUpload
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.pnlButtons);
            this.Controls.Add(this.ftGroupBox3);
            this.Controls.Add(this.dgvDocUpload);
            this.Controls.Add(this.groupBox11);
            this.Name = "ucEntityDocUpload";
            this.Size = new System.Drawing.Size(770, 508);
            this.Load += new System.EventHandler(this.ucEntityDocUpload_Load);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ucEntityDocUpload_MouseClick);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDocUpload)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.ftGroupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picDocument)).EndInit();
            this.pnlButtons.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MatchCommon.CustomControls.FTButton ftBtnRemoveDoc;
        private MatchCommon.CustomControls.FTLabel ftLabel77;
        private MatchCommon.CustomControls.FTDataGrid dgvDocUpload;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Button btnImport;
        private MatchCommon.CustomControls.FTLabel ftLabel81;
        private MatchCommon.CustomControls.FTComboBox ftCmbTypeofDocument;
        private MatchCommon.CustomControls.FTTextBox txtComment;
        private MatchCommon.CustomControls.FTGroupBox ftGroupBox3;
        private MatchCommon.CustomControls.FTPictureBox picDocument;
        protected MatchCommon.CustomControls.FTButton btnExport;
        private System.Windows.Forms.Panel pnlButtons;
        private MatchCommon.CustomControls.FTLabel lblUploadLog;
    }
}
