﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Collections;
using System.Windows.Forms;
using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.CDD.UI.Forms;
using FTIL.Match.Common.Log;
using FTIL.Match.Common;
using FTIL.Match.CDD.BAL;
using C1.Win.C1FlexGrid;
using MatchCommon;
using MatchCommon.UI.Forms;
using UCC.Class;

namespace FTIL.Match.CDD.UI.UserControls
{
    public partial class ucClientPreferences : ucBaseEntity  //: UserControl
    {
        private CClientPreferences m_ObjClientPrefernces;
        private COperationPreference m_ObjCOperationPreference;
        DataSet l_dsLookUp ;
        string l_sErrorMsg;
        private DataTable m_dtServProvider, m_dtFormat, m_dtDownloadFor, m_dtFlatISO, m_dtTradeClub,
            m_dtPaymentMode, m_dtGlobalPref, m_dtContractFormType, m_dtContractNoGen,
            m_dtBillGen, m_dtBillNoGen, m_dtSettOn, m_dtStockTransfer, m_dtChargeDelvCharges,
            m_dtSettDateOnContract, m_dtRegionMapping, m_dtPayoutRiskMatrix, m_dtOverriderRMSFor,
            m_dtAccEntryintheNameOf, m_dtNameOnContract;
        private DataTable m_dtClientPrefData, m_dtMakerData;
        private BindingSource m_bsClientPref;
        private readonly string MsgBoxTitle = "Client Preferences";
        private bool m_bValidPreferenceCodeSet, m_bValidChargeCodeSet;
        private COperationPreference objOperationPreference;

        private int ColIndex { get; set; }
        private int RowIndex { get; set; }
        public int ClientId { get; set; }
        private int iCount { get; set; }
        int nPreferenceNo;
        public string EntityType { get; set; }
        public DataSet dsPreferences;


        public COperationPreference OperationPreference
        {
            get { return objOperationPreference; }
        } 


        public ucClientPreferences()
        {
            InitializeComponent();
            objOperationPreference = new COperationPreference();
            m_ObjClientPrefernces = new CClientPreferences(); 
            m_ObjCOperationPreference = new COperationPreference();
        }

        private void lblIntRate_Click(object sender, EventArgs e)
        {}
        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {}
        private void label2_Click(object sender, EventArgs e)
        { }
        private void groupBox1_Enter(object sender, EventArgs e)
        {}



        private void ucClientPreferences_Load(object sender, EventArgs e)
        {

                PopulateLookup();
                PopulateControls();
                //RefreshData(false);
                // EnableDisablMenuItem(false);
                //dgvUnderlying_RowColChange(this, EventArgs.Empty);
            
        }
        #region Clear
        public void Clear()
        {
           // m_bUpdationInProgress = true;

            try
            {
                txtPreferenceCode.Text = "";
                txtCharge.Text = "";
                txtIntRate.Text = "";
                //txtBeforeFunds.Text = "";
                //txtBeforeSecurities.Text = "";
                //txtAfterFunds.Text = "";
                //txtAfterSecurities.Text = "";

                cbBills.Checked = false;
                cbContracts.Checked = false;
                cbPOA.Checked = false;
                cbRunningClient.Checked = false;
                cbIncludeAuctionPenalInBrkg.Checked = false;
                cbIncludeCCinBrok.Checked = false;
                //cbSTOnNetGrossBrkg.Checked = false;
                cbIncludeCFinBrok.Checked = false;
                //cbIncludeDepoinBrok.Checked = false;
                cbIncludeSDinBrok.Checked = false;
                cbIncludeSEBIInBrok.Checked = false;
                cbIncludeSTinBrok.Checked = false;
                //cbIncludeSTinCC.Checked = false;
                cbIncludeSTTinBrok.Checked = false;
                cbIncludeTOInBrok.Checked = false;
                //chkTradeConfMemo.Checked = false;

                cboServProvider.SelectedIndex = -1;
                cboFlatISO.SelectedIndex = -1;
                cboFormat.SelectedIndex = -1;
                cboDownloadFor.SelectedIndex = -1;
                cboTradeClub.SelectedIndex = -1;
                cboPaymentMode.SelectedIndex = -1;
                if (cboGlobalPreference.Visible)
                    cboGlobalPreference.SelectedIndex = -1;
                cboContractFormType.SelectedIndex = -1;
                cboContractNoGen.SelectedIndex = -1;
                cboBillGeneration.SelectedIndex = -1;
                cboBillNoGen.SelectedIndex = -1;
                cboSettlementOn.SelectedIndex = -1;
                cboStockTransfer.SelectedIndex = -1;
                if (cboChargeDeliveryCharges.Visible)
                    cboChargeDeliveryCharges.SelectedIndex = -1;
                cboSettDateOnContract.SelectedIndex = -1;
                if (cboRegionMapping.Visible)
                    cboRegionMapping.SelectedIndex = -1;
                //if (cboPayoutRiskMatrix.Visible)
                //    cboPayoutRiskMatrix.SelectedIndex = -1;
                //if (cboOverrideRMSFor.Visible)
                //    cboOverrideRMSFor.SelectedIndex = -1;
                //if (cboAcEntryInTheNameOf.Visible)
                //    cboAcEntryInTheNameOf.SelectedIndex = -1;
                //if (cboNameOnContract.Visible)
                //    cboNameOnContract.SelectedIndex = -1;
            }
            finally
            {
                //m_bUpdationInProgress = false;
            }
        }
        #endregion

        public override void PopulateControls()
        {
            if (ModifyMode == false) return;

            try
            {
                    m_ObjCOperationPreference.GetEntityPreferenceDetails(ClientId, ref dsPreferences);
                    if (dsPreferences == null || dsPreferences.Tables.Count < 1 || dsPreferences.Tables[0].Rows.Count < 1)
                        return;
                 
                    nPreferenceNo = m_ObjCOperationPreference.PreferenceNo;
                    txtG3.Text = m_ObjCOperationPreference.G3;
                    txtFmlyGroupCode.Text = m_ObjCOperationPreference.FmlyGroupCode;
                    txtFmlyGroupName.Text = m_ObjCOperationPreference.FamilyName;
                    txtPreferenceCode.Text = m_ObjCOperationPreference.PreferenceCode;
                    txtCharge.Text = m_ObjCOperationPreference.Charge;
                    cboBrokMethod.SelectedValue = m_ObjCOperationPreference.BrokMethod;
                    txtBrokSlab.Text = m_ObjCOperationPreference.BrokSlab;
                    chkAllowtoBrok.Checked = m_ObjCOperationPreference.AllowtoBrok == "Y" ? true : false;
                    txtIntRate.Text = m_ObjCOperationPreference.IntRate;
                    cbPOA.Checked = m_ObjCOperationPreference.POA == "Y" ? true : false;
                    cbRunningClient.Checked = m_ObjCOperationPreference.RunningClient == "Y" ? true : false;
                    cboTradeClub.SelectedValue = m_ObjCOperationPreference.TradeClub;

                    cboTradeClub.SetSelectedValue(m_ObjCOperationPreference.TradeClub == null ? "" : m_ObjCOperationPreference.TradeClub ); 
                    cboPaymentMode.SetSelectedValue ( m_ObjCOperationPreference.PaymentMode == null ? "" : m_ObjCOperationPreference.PaymentMode); 
                    cboGlobalPreference.SetSelectedValue( m_ObjCOperationPreference.GlobalPreference == null ? "" : m_ObjCOperationPreference.GlobalPreference);

                    cboServProvider.SetSelectedValue ( m_ObjCOperationPreference.ServProvider == null ? "" : m_ObjCOperationPreference.ServProvider);
                    cboFlatISO.SetSelectedValue (m_ObjCOperationPreference.FlatISO == null ? "" : m_ObjCOperationPreference.FlatISO);
                    cboFormat.SetSelectedValue ( m_ObjCOperationPreference.Format == null ? "" : m_ObjCOperationPreference.Format);
                    cboDownloadFor.SetSelectedValue ( m_ObjCOperationPreference.DownloadFor == null ? "" : m_ObjCOperationPreference.DownloadFor);
                    cboContractNoGen.SetSelectedValue ( m_ObjCOperationPreference.ContractNoGen == null ? "" : m_ObjCOperationPreference.ContractNoGen);
                    cboContractFormType.SetSelectedValue ( m_ObjCOperationPreference.ContractFormType == null ? "" : m_ObjCOperationPreference.ContractFormType);
                    cboStockTransfer.SetSelectedValue ( m_ObjCOperationPreference.StockTransfer == null ? "" : m_ObjCOperationPreference.StockTransfer);
                    cboChargeDeliveryCharges.SetSelectedValue(m_ObjCOperationPreference.ChargeDeliveryCharges == null ? "" : m_ObjCOperationPreference.ChargeDeliveryCharges);
                    cboRegionMapping.SetSelectedValue ( m_ObjCOperationPreference.RegionMapping == null ? "" : m_ObjCOperationPreference.RegionMapping);
                    
                    cbIncludeTOInBrok.Checked = m_ObjCOperationPreference.IncludeTOInBrok == "Y" ? true : false;
                    cbIncludeSTinBrok.Checked = m_ObjCOperationPreference.IncludeSTinBrok == "Y" ? true : false;
                    cbIncludeSTTinBrok.Checked = m_ObjCOperationPreference.IncludeSTTinBrok == "Y" ? true : false;
                    cbIncludeSDinBrok.Checked = m_ObjCOperationPreference.IncludeSDinBrok == "Y" ? true : false;
                    cbIncludeSEBIInBrok.Checked = m_ObjCOperationPreference.IncludeSEBIInBrok == "Y" ? true : false;
                    cbIncludeCFinBrok.Checked = m_ObjCOperationPreference.IncludeCFinBrok == "Y" ? true : false;
                    cbIncludeCCinBrok.Checked = m_ObjCOperationPreference.IncludeCCinBrok == "Y" ? true : false;
                    cbIncludeAuctionPenalInBrkg.Checked = m_ObjCOperationPreference.IncludeAuctionPenalInBrkg == "Y" ? true : false; 

                    txtBeforePayinFunds.Text = m_ObjCOperationPreference.BeforePayinFunds;
                    txtBeforePayinSecurities.Text = m_ObjCOperationPreference.BeforePayinSecurities;
                    txtAfterPayoutFunds.Text = m_ObjCOperationPreference.AfterPayoutFunds;
                    txtAfterPayoutSecurities.Text = m_ObjCOperationPreference.AfterPayoutSecurities;
                  

                     cbBills.Checked   = m_ObjCOperationPreference.Bills == "Y" ? true : false;
                     cbContracts.Checked  = m_ObjCOperationPreference.Contracts == "Y" ? true : false;
                    /* ((CListItem)(cboSettlementOn.SelectedItem)).DataValue = m_ObjCOperationPreference.SettlementOn;
                     ((CListItem)(cboBillGeneration.SelectedItem)).DataValue = m_ObjCOperationPreference.BillGeneration;
                     ((CListItem)(cboBillNoGen.SelectedItem)).DataValue = m_ObjCOperationPreference.BillNoGen;
                     ((CListItem)(cboSettDateOnContract.SelectedItem)).DataValue = m_ObjCOperationPreference.SettDateOnContract; 
                     */

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAccount), ex.Message);
                MessageBox.Show("Unable to fill account details", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public COperationPreference GetEntityPreferenceDetails()
        {
            try
            {
                if (objOperationPreference == null) return objOperationPreference; 
                HasUpdated = false;
                objOperationPreference.PreferenceNo = nPreferenceNo;
                objOperationPreference.ClientNo = ClientId;  
                objOperationPreference.G3 = txtG3.Text;
                objOperationPreference.FmlyGroupCode = txtFmlyGroupCode.Text;
                objOperationPreference.PreferenceCode = txtPreferenceCode.Text;
                objOperationPreference.Charge = txtCharge.Text;
                objOperationPreference.BrokMethod = cboBrokMethod.SelectedValue.ToString();
                objOperationPreference.BrokSlab = txtBrokSlab.Text;
                objOperationPreference.AllowtoBrok = chkAllowtoBrok.Checked ? "Y" : "N";
                objOperationPreference.IntRate = txtIntRate.Text;
                objOperationPreference.POA = cbPOA.Checked ? "Y" : "N";
                objOperationPreference.RunningClient = cbRunningClient.Checked ? "Y" : "N";
                objOperationPreference.TradeClub = cboTradeClub.SelectedValue.ToString(); //((FTIL.Match.CDD.UI.CListItem)(cboSettlementOn.SelectedItem)).DataValue
                objOperationPreference.PaymentMode = cboPaymentMode.SelectedValue.ToString();
                objOperationPreference.IncludeSTinBrok = cbIncludeSTinBrok.Checked ? "Y" : "N"; 
                objOperationPreference.GlobalPreference = cboGlobalPreference.SelectedValue.ToString();  
                objOperationPreference.IncludeTOInBrok = cbIncludeTOInBrok.Checked ? "Y" : "N";
                objOperationPreference.IncludeSTTinBrok = cbIncludeSTTinBrok.Checked ? "Y" : "N";
                objOperationPreference.IncludeSDinBrok = cbIncludeSDinBrok.Checked ? "Y" : "N";
                objOperationPreference.IncludeSEBIInBrok = cbIncludeSEBIInBrok.Checked ? "Y" : "N";
                objOperationPreference.IncludeCFinBrok = cbIncludeCFinBrok.Checked ? "Y" : "N";
                objOperationPreference.IncludeCCinBrok = cbIncludeCCinBrok.Checked ? "Y" : "N";
                objOperationPreference.IncludeAuctionPenalInBrkg = cbIncludeAuctionPenalInBrkg.Checked ? "Y" : "N";
                objOperationPreference.ServProvider = cboServProvider.SelectedValue.ToString();
                objOperationPreference.FlatISO = cboFlatISO.SelectedValue.ToString(); 
                objOperationPreference.Format = cboFormat.SelectedValue.ToString();  
                objOperationPreference.DownloadFor = cboDownloadFor.SelectedValue.ToString();  
                objOperationPreference.ContractNoGen = cboContractNoGen.SelectedValue.ToString();  
                objOperationPreference.ContractFormType = cboContractFormType.SelectedValue.ToString();  
                objOperationPreference.StockTransfer = cboStockTransfer.SelectedValue.ToString();  
                objOperationPreference.ChargeDeliveryCharges = cboChargeDeliveryCharges.SelectedValue.ToString();  
                objOperationPreference.RegionMapping = cboRegionMapping.SelectedValue.ToString();  
                objOperationPreference.BeforePayinFunds = txtBeforePayinFunds.Text;
                objOperationPreference.BeforePayinSecurities = txtBeforePayinSecurities.Text; 
                objOperationPreference.AfterPayoutFunds = txtAfterPayoutFunds.Text;
                objOperationPreference.AfterPayoutSecurities = txtAfterPayoutSecurities.Text;
                objOperationPreference.SettlementOn = cboSettlementOn.SelectedValue.ToString();
                /* objOperationPreference.BillGeneration = cboBillGeneration.SelectedValue;  
                 objOperationPreference.BillNoGen = cboBillNoGen.SelectedValue;  
                 objOperationPreference.SettlementOn = cboSettDateOnContractValue; 
                 objOperationPreference.Bills = cbBills.Checked ? "Y" : "N";
                 objOperationPreference.Contracts = cbContracts.Checked ? "Y" : "N";
                 m_EntityDetailsInstance.IsValid = false; */
                HasUpdated = true;

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityOthers), ex.Message);
                MessageBox.Show("Unable to fetch data from other tab data to save", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return objOperationPreference;

        }
        #region dgvUnderlying_RowColChange
        private void dgvUnderlying_RowColChange(object sender, EventArgs e)
        {
            //SetCheckerView(true);

            //if (m_objOperation != MasterOperation.Add)
            //    Clear();

            if (dgvPreference.Rows.Selected.Count != 1)
            {
                return;
            }
            //PopulateFields();
            
        }
        #endregion

          
        private void txtPreferenceCode_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.F3)
                {

                    Row dr = ShowHelp(txtPreferenceCode.Text.Trim(), true, 7, new string[] { "ODINPreferencesID" });
                    txtPreferenceCode.Text = dr == null ? "" : Convert.ToString(dr[COperationPreference.PREFERENCECODE]);
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
            }
        }
        private void txtPreferenceCode_Leave(object sender, EventArgs e)
        {
            try
            {
                if (txtPreferenceCode.Text.Trim().Length < 3) return;

                Row dr = ShowHelp(txtPreferenceCode.Text.Trim(), true, 7, new string[] { "ODINPreferencesID" });
                txtPreferenceCode.Text = dr== null ? "" : Convert.ToString(dr[COperationPreference.PREFERENCECODE]);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
            }

        } 
        #region l_frmSearchPreference_AfterUserAction
        private void l_frmSearchPreference_AfterUserAction(object sender, MatchCommon.UI.Forms.MatchSearchEventArgs e)
        {
            if ((e.ReturnCode == 0) && (e.Data != null))
            {
                txtPreferenceCode.Text = e.Data.Rows[0]["RoundingPrefCode"].ToString().Trim();

                m_bValidPreferenceCodeSet = true;
            }
            else
            {
                txtPreferenceCode.Text = "";
            }
        }
        #endregion

        private void txtCharge_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (txtCharge.Text.Trim().Length < 3) return;

                Row dr = ShowHelp(txtCharge.Text.Trim(), true, 5, new string[] {  "ChargeCode"  });
                txtCharge.Text = dr == null ? "" : Convert.ToString(dr[COperationPreference.CHARGECODE]);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
            }
        }

        private void txtCharge_Leave(object sender, EventArgs e)
        {
            try
            {
                if (txtCharge.Text.Trim().Length < 3) return;

                Row dr = ShowHelp(txtCharge.Text.Trim(),true,5, new string[] {   "ChargeCode"  });
                txtCharge.Text = dr == null ? "" : Convert.ToString(dr[COperationPreference.CHARGECODE]);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
            }
        }
        #region l_frmSearchCharge_AfterUserAction
        private void l_frmSearchCharge_AfterUserAction(object sender, MatchCommon.UI.Forms.MatchSearchEventArgs e)
        {
            if ((e.ReturnCode == 0) && (e.Data != null))
            {
                txtCharge.Text = e.Data.Rows[0]["ChargeCode"].ToString().Trim();

                m_bValidChargeCodeSet = true;
            }
            else
            {
                txtCharge.Text = "";
            }
        }
        #endregion
        #region txtBrokSlab_KeyUp
        private void txtBrokSlab_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.F3)
                {

                    Row dr = ShowHelp(txtBrokSlab.Text.Trim(), true, 4, new string[] { "BrokGrpCode" }, cboBrokMethod.SelectedValue.ToString());
                    txtBrokSlab.Text = dr == null ? "" : Convert.ToString(dr[COperationPreference.BROKGRPCODE]);
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
            }

        }
        #endregion


        #region txtBrokSlab_Leave
        private void txtBrokSlab_Leave(object sender, EventArgs e)
        {
            try
            {
                if (txtBrokSlab.Text.Trim().Length < 3) return;

                Row dr = ShowHelp(txtBrokSlab.Text.Trim(), true, 4, new string[] { "BrokGrpCode" }, cboBrokMethod.SelectedValue.ToString());
                txtBrokSlab.Text = dr == null ? "" : Convert.ToString(dr[COperationPreference.BROKGRPCODE]);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
            }
        }
        #endregion

        #region ShowSchemeHelp
        /// <summary>
        /// Opens Client help window with data filtered as per input Control ID
        /// </summary>
        private void ShowBrokerageHelp(string p_vsInputValue)
        {
            // m_objCommission.GetBrokerageDetails(ref dtCommision);         
            MatchCommon.UI.Forms.frmMatchSearch l_frmSearch = new MatchCommon.UI.Forms.frmMatchSearch();
            l_frmSearch.AfterUserAction += new MatchCommon.UI.Forms.frmMatchSearch.dlgAfterUserAction(l_frmSearch_AfterUserActionScheme);
            l_frmSearch.AfterDataRetrieval += new MatchCommon.UI.Forms.frmMatchSearch.dlgAfterDataRetrieval(l_frmSearch_AfterDataRetrieval);
            l_frmSearch.SearchSelectionMode = SearchSelectionModes.SINGLE_SELECTION;
            l_frmSearch.SearchType = SearchTypes.BROKSLAB;
            l_frmSearch.InputType = InputTypes.FIXED;
            l_frmSearch.GetData = true;
            l_frmSearch.SearchBy = "BrokGrpCode";
            l_frmSearch.Condition = Conditions.BEGINWITH;
            l_frmSearch.KeywordFrom = string.IsNullOrEmpty(p_vsInputValue.Trim()) ? "%" : p_vsInputValue;
            l_frmSearch.ReturnIfSingleRow = true;
            l_frmSearch.ShowDialog(this);
        }
        #endregion


        protected override void PopulateLookup()
        { 
            try
            {
                m_ObjClientPrefernces.GetLookupData(ref l_dsLookUp, ref l_sErrorMsg);


                //Service Provider
             /*   if (l_dsLookUp.Tables.Count > 1)
                {
                    m_dtServProvider = l_dsLookUp.Tables[1];
                    cboServProvider.ValueMember = "DataValue";
                    cboServProvider.DisplayMember = "DisplayValue";
                    for (int l_intRowCounter = 0; l_intRowCounter < m_dtServProvider.Rows.Count; l_intRowCounter++)
                    {
                        CListItem l_objItem = new CListItem(m_dtServProvider.Rows[l_intRowCounter][CClientPreferences.ServProviderDisplay].ToString(),
                            m_dtServProvider.Rows[l_intRowCounter][CClientPreferences.ServProvider].ToString());
                        cboServProvider.Items.Add(l_objItem);
                    }

                }

                //ISOFlat
                if (l_dsLookUp.Tables.Count > 2)
                {
                    m_dtFlatISO = l_dsLookUp.Tables[2];
                    cboFlatISO.ValueMember = "DataValue";
                    cboFlatISO.DisplayMember = "DisplayValue";
                    for (int l_intRowCounter = 0; l_intRowCounter < m_dtFlatISO.Rows.Count; l_intRowCounter++)
                    {
                        CListItem l_objItem = new CListItem(m_dtFlatISO.Rows[l_intRowCounter][CClientPreferences.ISOFlatDisplay].ToString(),
                            m_dtFlatISO.Rows[l_intRowCounter][CClientPreferences.ISOFlat].ToString());
                        cboFlatISO.Items.Add(l_objItem);
                    }
                }

                //Format
                if (l_dsLookUp.Tables.Count > 3)
                {
                    m_dtFormat = l_dsLookUp.Tables[3];
                    cboFormat.ValueMember = "DataValue";
                    cboFormat.DisplayMember = "DisplayValue";
                    for (int l_intRowCounter = 0; l_intRowCounter < m_dtFormat.Rows.Count; l_intRowCounter++)
                    {
                        CListItem l_objItem = new CListItem(m_dtFormat.Rows[l_intRowCounter][CClientPreferences.FormatDisplay].ToString(),
                            m_dtFormat.Rows[l_intRowCounter][CClientPreferences.Format].ToString());
                        cboFormat.Items.Add(l_objItem);
                    }
                }

                //Download For
                if (l_dsLookUp.Tables.Count > 4)
                {
                    m_dtDownloadFor = l_dsLookUp.Tables[4];
                    cboDownloadFor.ValueMember = "DataValue";
                    cboDownloadFor.DisplayMember = "DisplayValue";
                    for (int l_intRowCounter = 0; l_intRowCounter < m_dtDownloadFor.Rows.Count; l_intRowCounter++)
                    {
                        CListItem l_objItem = new CListItem(m_dtDownloadFor.Rows[l_intRowCounter][CClientPreferences.DownloadForDisplay].ToString(),
                            m_dtDownloadFor.Rows[l_intRowCounter][CClientPreferences.DownloadFor].ToString());
                        cboDownloadFor.Items.Add(l_objItem);
                    }
                }

                //Trade Club
                if (l_dsLookUp.Tables.Count > 5)
                {
                    m_dtTradeClub = l_dsLookUp.Tables[5];
                    cboTradeClub.ValueMember = "DataValue";
                    cboTradeClub.DisplayMember = "DisplayValue";
                    for (int l_intRowCounter = 0; l_intRowCounter < m_dtTradeClub.Rows.Count; l_intRowCounter++)
                    {
                        CListItem l_objItem = new CListItem(m_dtTradeClub.Rows[l_intRowCounter][CClientPreferences.TradeClubDisplay].ToString(),
                            m_dtTradeClub.Rows[l_intRowCounter][CClientPreferences.TradeClub].ToString());
                        cboTradeClub.Items.Add(l_objItem);
                    }
                }

                //Payment Mode
                if (l_dsLookUp.Tables.Count > 6)
                {
                    m_dtPaymentMode = l_dsLookUp.Tables[6];
                    cboPaymentMode.ValueMember = "DataValue";
                    cboPaymentMode.DisplayMember = "DisplayValue";
                    for (int l_intRowCounter = 0; l_intRowCounter < m_dtPaymentMode.Rows.Count; l_intRowCounter++)
                    {
                        CListItem l_objItem = new CListItem(m_dtPaymentMode.Rows[l_intRowCounter][CClientPreferences.PaymentModeDisplay].ToString(),
                            m_dtPaymentMode.Rows[l_intRowCounter][CClientPreferences.PaymentMode].ToString());
                        cboPaymentMode.Items.Add(l_objItem);
                    }
                }

                //Global Preferences
                if (l_dsLookUp.Tables.Count > 7)
                {
                    m_dtGlobalPref = l_dsLookUp.Tables[7];
                    if (cboGlobalPreference.Visible)
                    {
                        cboGlobalPreference.ValueMember = "DataValue";
                        cboGlobalPreference.DisplayMember = "DisplayValue";
                        for (int l_intRowCounter = 0; l_intRowCounter < m_dtGlobalPref.Rows.Count; l_intRowCounter++)
                        {
                            CListItem l_objItem = new CListItem(m_dtGlobalPref.Rows[l_intRowCounter][CClientPreferences.GlobalPreferencesDisplay].ToString(),
                                m_dtGlobalPref.Rows[l_intRowCounter][CClientPreferences.GlobalPreferences].ToString());
                            cboGlobalPreference.Items.Add(l_objItem);
                        }
                    }
                }

                //Contract Form Type
                if (l_dsLookUp.Tables.Count > 8)
                {
                    m_dtContractFormType = l_dsLookUp.Tables[8];
                    cboContractFormType.ValueMember = "DataValue";
                    cboContractFormType.DisplayMember = "DisplayValue";
                    for (int l_intRowCounter = 0; l_intRowCounter < m_dtContractFormType.Rows.Count; l_intRowCounter++)
                    {
                        CListItem l_objItem = new CListItem(m_dtContractFormType.Rows[l_intRowCounter][CClientPreferences.ContractFormTypeDisplay].ToString(),
                            m_dtContractFormType.Rows[l_intRowCounter][CClientPreferences.ContractFormType].ToString());
                        cboContractFormType.Items.Add(l_objItem);
                    }
                }

                //Contract No. Gen
                if (l_dsLookUp.Tables.Count > 9)
                {
                    m_dtContractNoGen = l_dsLookUp.Tables[9];
                    cboContractNoGen.ValueMember = "DataValue";
                    cboContractNoGen.DisplayMember = "DisplayValue";
                    for (int l_intRowCounter = 0; l_intRowCounter < m_dtContractNoGen.Rows.Count; l_intRowCounter++)
                    {
                        CListItem l_objItem = new CListItem(m_dtContractNoGen.Rows[l_intRowCounter][CClientPreferences.ContractNoGenDisplay].ToString(),
                            m_dtContractNoGen.Rows[l_intRowCounter][CClientPreferences.ContractNoGen].ToString());
                        cboContractNoGen.Items.Add(l_objItem);
                    }
                }

                //Bill Generation
                if (l_dsLookUp.Tables.Count > 10)
                {
                    m_dtBillGen = l_dsLookUp.Tables[10];
                    cboBillGeneration.ValueMember = "DataValue";
                    cboBillGeneration.DisplayMember = "DisplayValue";
                    for (int l_intRowCounter = 0; l_intRowCounter < m_dtBillGen.Rows.Count; l_intRowCounter++)
                    {
                        CListItem l_objItem = new CListItem(m_dtBillGen.Rows[l_intRowCounter][CClientPreferences.BillGenDisplay].ToString(),
                            m_dtBillGen.Rows[l_intRowCounter][CClientPreferences.BillGen].ToString());
                        cboBillGeneration.Items.Add(l_objItem);
                    }
                }

                //Bill No Generation
                if (l_dsLookUp.Tables.Count > 11)
                {
                    m_dtBillNoGen = l_dsLookUp.Tables[11];
                    cboBillNoGen.ValueMember = "DataValue";
                    cboBillNoGen.DisplayMember = "DisplayValue";
                    for (int l_intRowCounter = 0; l_intRowCounter < m_dtBillNoGen.Rows.Count; l_intRowCounter++)
                    {
                        CListItem l_objItem = new CListItem(m_dtBillNoGen.Rows[l_intRowCounter][CClientPreferences.BillNoGenDisplay].ToString(),
                            m_dtBillNoGen.Rows[l_intRowCounter][CClientPreferences.BillNoGen].ToString());
                        cboBillNoGen.Items.Add(l_objItem);
                    }
                }

                //Settlement On
                if (l_dsLookUp.Tables.Count > 12)
                {
                    m_dtSettOn = l_dsLookUp.Tables[12];
                    cboSettlementOn.ValueMember = "DataValue";
                    cboSettlementOn.DisplayMember = "DisplayValue";
                    for (int l_intRowCounter = 0; l_intRowCounter < m_dtSettOn.Rows.Count; l_intRowCounter++)
                    {
                        CListItem l_objItem = new CListItem(m_dtSettOn.Rows[l_intRowCounter][CClientPreferences.SettlementOnDisplay].ToString(),
                            m_dtSettOn.Rows[l_intRowCounter][CClientPreferences.SettlementOn].ToString());
                        cboSettlementOn.Items.Add(l_objItem);
                    }
                }

                //Stock Transfer
                if (l_dsLookUp.Tables.Count > 13)
                {
                    m_dtStockTransfer = l_dsLookUp.Tables[13];
                    cboStockTransfer.ValueMember = "DataValue";
                    cboStockTransfer.DisplayMember = "DisplayValue";
                    for (int l_intRowCounter = 0; l_intRowCounter < m_dtStockTransfer.Rows.Count; l_intRowCounter++)
                    {
                        CListItem l_objItem = new CListItem(m_dtStockTransfer.Rows[l_intRowCounter][CClientPreferences.StockTransferDisplay].ToString(),
                            m_dtStockTransfer.Rows[l_intRowCounter][CClientPreferences.StockTransfer].ToString());
                        cboStockTransfer.Items.Add(l_objItem);
                    }
                }

                //Charge Delv Charges
                if (l_dsLookUp.Tables.Count > 14)
                {
                    m_dtChargeDelvCharges = l_dsLookUp.Tables[14];
                    if (cboChargeDeliveryCharges.Visible)
                    {
                        cboChargeDeliveryCharges.ValueMember = "DataValue";
                        cboChargeDeliveryCharges.DisplayMember = "DisplayValue";
                        for (int l_intRowCounter = 0; l_intRowCounter < m_dtChargeDelvCharges.Rows.Count; l_intRowCounter++)
                        {
                            CListItem l_objItem = new CListItem(m_dtChargeDelvCharges.Rows[l_intRowCounter][CClientPreferences.ChargeDelvChargesDisplay].ToString(),
                                m_dtChargeDelvCharges.Rows[l_intRowCounter][CClientPreferences.ChargeDelvCharges].ToString());
                            cboChargeDeliveryCharges.Items.Add(l_objItem);
                        }
                    }
                }

                //Settlement Date On Contract
                if (l_dsLookUp.Tables.Count > 15)
                {
                    m_dtSettDateOnContract = l_dsLookUp.Tables[15];
                    cboSettDateOnContract.ValueMember = "DataValue";
                    cboSettDateOnContract.DisplayMember = "DisplayValue";
                    for (int l_intRowCounter = 0; l_intRowCounter < m_dtSettDateOnContract.Rows.Count; l_intRowCounter++)
                    {
                        CListItem l_objItem = new CListItem(m_dtSettDateOnContract.Rows[l_intRowCounter][CClientPreferences.SettDateOnContractDisplay].ToString(),
                            m_dtSettDateOnContract.Rows[l_intRowCounter][CClientPreferences.SettDateOnContract].ToString());
                        cboSettDateOnContract.Items.Add(l_objItem);
                    }
                }

                //Region Mapping
                if (l_dsLookUp.Tables.Count > 16)
                {
              * 
                    m_dtRegionMapping = l_dsLookUp.Tables[16];
                    if (cboRegionMapping.Visible)
                    {
                        cboRegionMapping.ValueMember = "DataValue";
                        cboRegionMapping.DisplayMember = "DisplayValue";
                        for (int l_intRowCounter = 0; l_intRowCounter < m_dtRegionMapping.Rows.Count; l_intRowCounter++)
                        {
                            CListItem l_objItem = new CListItem(m_dtRegionMapping.Rows[l_intRowCounter][CClientPreferences.RegionMappingDisplay].ToString(),
                                m_dtRegionMapping.Rows[l_intRowCounter][CClientPreferences.RegionMapping].ToString());
                            cboRegionMapping.Items.Add(l_objItem);
                        }
                    }
                }*/

                if (l_dsLookUp.Tables.Count > 1)
                {
                    m_dtServProvider = l_dsLookUp.Tables[1];
                    cboServProvider.ValueMember = CClientPreferences.ServProvider;
                    cboServProvider.DisplayMember = CClientPreferences.ServProviderDisplay;
                    cboServProvider.DataSource = m_dtServProvider;  
                }

                //ISOFlat
                if (l_dsLookUp.Tables.Count > 2)
                {
                    m_dtFlatISO = l_dsLookUp.Tables[2];
                    cboFlatISO.ValueMember = CClientPreferences.ISOFlat;
                    cboFlatISO.DisplayMember = CClientPreferences.ISOFlatDisplay;
                    cboFlatISO.DataSource = m_dtFlatISO;   
                }

                //Format
                if (l_dsLookUp.Tables.Count > 3)
                {
                    m_dtFormat = l_dsLookUp.Tables[3];
                    cboFormat.ValueMember = CClientPreferences.Format;
                    cboFormat.DisplayMember = CClientPreferences.FormatDisplay;
                    cboFormat.DataSource = m_dtFormat; 
                }

                //Download For
                if (l_dsLookUp.Tables.Count > 4)
                {
                    m_dtDownloadFor = l_dsLookUp.Tables[4];
                    cboDownloadFor.ValueMember = CClientPreferences.DownloadFor;
                    cboDownloadFor.DisplayMember = CClientPreferences.DownloadForDisplay;
                    cboDownloadFor.DataSource = m_dtDownloadFor; 
                }

                //Trade Club
                if (l_dsLookUp.Tables.Count > 5)
                {
                    m_dtTradeClub = l_dsLookUp.Tables[5];
                    cboTradeClub.ValueMember = CClientPreferences.TradeClub;
                    cboTradeClub.DisplayMember = CClientPreferences.TradeClubDisplay;
                    cboTradeClub.DataSource = m_dtTradeClub;
                }

                //Payment Mode
                if (l_dsLookUp.Tables.Count > 6)
                {
                    m_dtPaymentMode = l_dsLookUp.Tables[6];
                    cboPaymentMode.ValueMember = CClientPreferences.PaymentMode;
                    cboPaymentMode.DisplayMember = CClientPreferences.PaymentModeDisplay;
                    cboPaymentMode.DataSource = m_dtPaymentMode;  
                }

                //Global Preferences
                if (l_dsLookUp.Tables.Count > 7)
                {
                    m_dtGlobalPref = l_dsLookUp.Tables[7];
                    if (cboGlobalPreference.Visible)
                    {
                        cboGlobalPreference.ValueMember = CClientPreferences.GlobalPreferences;
                        cboGlobalPreference.DisplayMember = CClientPreferences.GlobalPreferencesDisplay;
                        cboGlobalPreference.DataSource = m_dtGlobalPref; 
                    }
                }

                //Contract Form Type
                if (l_dsLookUp.Tables.Count > 8)
                {
                    m_dtContractFormType = l_dsLookUp.Tables[8];
                    cboContractFormType.ValueMember = CClientPreferences.ContractFormType;
                    cboContractFormType.DisplayMember = CClientPreferences.ContractFormTypeDisplay;
                    cboContractFormType.DataSource = m_dtContractFormType; 
                }

                //Contract No. Gen
                if (l_dsLookUp.Tables.Count > 9)
                {
                    m_dtContractNoGen = l_dsLookUp.Tables[9];
                    cboContractNoGen.ValueMember =CClientPreferences.ContractNoGen;
                    cboContractNoGen.DisplayMember = CClientPreferences.ContractNoGenDisplay;
                    cboContractNoGen.DataSource = m_dtContractNoGen; 
                }

                //Bill Generation
                if (l_dsLookUp.Tables.Count > 10)
                {
                    m_dtBillGen = l_dsLookUp.Tables[10];
                    cboBillGeneration.ValueMember = CClientPreferences.BillGen;
                    cboBillGeneration.DisplayMember = CClientPreferences.BillGenDisplay;
                    cboBillGeneration.DataSource = m_dtBillGen; 
                }

                //Bill No Generation
                if (l_dsLookUp.Tables.Count > 11)
                {
                    m_dtBillNoGen = l_dsLookUp.Tables[11];
                    cboBillNoGen.ValueMember = CClientPreferences.BillNoGen;
                    cboBillNoGen.DisplayMember = CClientPreferences.BillGenDisplay;
                    cboBillNoGen.DataSource = m_dtBillNoGen;
                      
                }

                //Settlement On
                if (l_dsLookUp.Tables.Count > 12)
                {
                    m_dtSettOn = l_dsLookUp.Tables[12];
                    cboSettlementOn.ValueMember = CClientPreferences.SettlementOn;
                    cboSettlementOn.DisplayMember = CClientPreferences.SettlementOnDisplay;
                    cboSettlementOn.DataSource = m_dtSettOn; 
                }

                //Stock Transfer
                if (l_dsLookUp.Tables.Count > 13)
                {
                    m_dtStockTransfer = l_dsLookUp.Tables[13];
                    cboStockTransfer.ValueMember = CClientPreferences.StockTransfer;
                    cboStockTransfer.DisplayMember = CClientPreferences.StockTransferDisplay;
                    cboStockTransfer.DataSource = m_dtStockTransfer;

                }

                //Charge Delv Charges
                if (l_dsLookUp.Tables.Count > 14)
                {
                    m_dtChargeDelvCharges = l_dsLookUp.Tables[14];
                    if (cboChargeDeliveryCharges.Visible)
                    {
                        cboChargeDeliveryCharges.ValueMember = CClientPreferences.ChargeDelvCharges;
                        cboChargeDeliveryCharges.DisplayMember = CClientPreferences.ChargeDelvChargesDisplay;
                        cboChargeDeliveryCharges.DataSource = m_dtChargeDelvCharges;
                         
                    }
                }

                //Settlement Date On Contract
                if (l_dsLookUp.Tables.Count > 15)
                {
                    m_dtSettDateOnContract = l_dsLookUp.Tables[15];
                    cboSettDateOnContract.ValueMember = CClientPreferences.SettDateOnContract;
                    cboSettDateOnContract.DisplayMember = CClientPreferences.SettDateOnContractDisplay;
                    cboSettDateOnContract.DataSource = m_dtSettDateOnContract; 
                }

                //Region Mapping
                if (l_dsLookUp.Tables.Count > 16)
                {
                    m_dtRegionMapping = l_dsLookUp.Tables[16];
                    if (cboRegionMapping.Visible)
                    {
                        cboRegionMapping.ValueMember = CClientPreferences.RegionMapping;
                        cboRegionMapping.DisplayMember = CClientPreferences.RegionMappingDisplay;
                        cboRegionMapping.DataSource = m_dtRegionMapping; 
                    }
                }

                cboBrokMethod.ValueMember = "s_ReferenceCode";
                cboBrokMethod.DisplayMember = "s_ReferenceName";
                cboBrokMethod.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.BrokMethodCode];
                cboBrokMethod.SelectedValue = 0;

                 
                SetData(l_dsLookUp);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucBank), ex.Message);
                MessageBox.Show("Unable to populate details", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            m_HasAllDropDownListBind = true;
        }
        #region l_frmSearch_AfterUserActionScheme
        private void l_frmSearch_AfterUserActionScheme(object sender, MatchCommon.UI.Forms.MatchSearchEventArgs e)
        {

            if ((e.ReturnCode == 0) && (e.Data != null))
            {
                txtBrokSlab.Text = e.Data.Rows[0]["BrokGrpCode"].ToString().Trim();
                //m_sScheme = e.Data.Rows[0]["BrokGrpCode"].ToString();
                //m_bValidSchemeDescNameSet = true;
            }
            else
            {
                txtBrokSlab.Text = "";
            }
        }
        #endregion

        #region l_frmSearch_AfterDataRetrieval
        private void l_frmSearch_AfterDataRetrieval(object sender, MatchCommon.UI.Forms.MatchSearchDataEventArgs e)
        {
            if (e.IsWindowLoad)
            {
                if (
                    (e.Data != null)
                    && (e.Data.Rows.Count > 1)
                    )
                {
                    string l_sBrokMethod = "";
                    if (cboBrokMethod.SelectedItem != null)
                    {
                        l_sBrokMethod = ((MatchCommon.CListItem)cboBrokMethod.SelectedItem).DisplayValue;
                        // "Brokerage Slab Type"
                    }

                    // CR 866 - Brokerage scheme help corrected
                    //string l_sFilterExpr = "[Brokerage Slab Type]='" + l_sBrokMethod + "' AND BrokGrpCode LIKE '"
                    //    + txtBrokSlab.Text.Trim() + "%'";

                    string l_sFilterExpr = "[Brokerage Slab Type]='" + l_sBrokMethod + "' AND BrokGrpCode LIKE '"
                        + txtBrokSlab.Text.Trim() + "%'";
                    DataView dvData = e.Data.DefaultView;
                    dvData.RowFilter = "";
                    dvData.RowFilter = l_sFilterExpr;
                    if (dvData.Count == 1)
                    {
                        e.SearchDataUserAction = MatchCommon.UI.Forms.UserAction.CloseWindow;
                    }
                }
            }
        }
        #endregion
        private void gbPrintingAllowedFor_Enter(object sender, EventArgs e) { }
       private void gbSTPDetails_Enter(object sender, EventArgs e) { }        
        private void gbCharges_Enter(object sender, EventArgs e) { }
        private void SetData(DataSet l_dsLookUp)
        {
            cboServProvider.SelectedItem = cboServProvider.Items[1];
            cboFlatISO.SelectedItem = cboFlatISO.Items[0];
            cboFormat.SelectedItem = cboFormat.Items[1];
            cboDownloadFor.SelectedItem = cboDownloadFor.Items[0];
            cboPaymentMode.SelectedItem = cboPaymentMode.Items[1];
            cboGlobalPreference.SelectedItem = cboGlobalPreference.Items[3];
            cboContractFormType.SelectedItem = cboContractFormType.Items[0];
            //cboBillGeneration.SelectedItem = cboBillGeneration.Items[0];
            //cboBillNoGen.SelectedItem = cboBillNoGen.Items[0];              
            cboSettlementOn.SelectedItem = cboSettlementOn.Items[0];
            cboChargeDeliveryCharges.SelectedItem = cboChargeDeliveryCharges.Items[1];
            cboSettDateOnContract.SelectedItem = cboSettDateOnContract.Items[1];
            cboRegionMapping.SelectedItem = cboRegionMapping.Items[1];
            cboBrokMethod.SelectedItem = cboBrokMethod.Items[1];

            if (EntityType == CCMConstants.INDIVIDUAL)
            {
                cboTradeClub.SelectedItem = cboTradeClub.Items[5];
                cboContractNoGen.SelectedItem = cboContractNoGen.Items[2];
                cboStockTransfer.SelectedItem = cboStockTransfer.Items[0];
            }
            else if (EntityType == CCMConstants.NON_INDIVIDUAL)
            {
                cboTradeClub.SelectedItem = cboTradeClub.Items[0];
                cboContractNoGen.SelectedItem = cboContractNoGen.Items[0];
                cboStockTransfer.SelectedItem = cboStockTransfer.Items[1];
            }
        }

        private void txtG3_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.F3)
                {

                    Row dr = ShowHelp(txtG3.Text.Trim(), true, 2, new string[] { "GroupCode", "GroupDesc" });
                    txtG3.Text = dr == null ? "" : Convert.ToString(dr[COperationPreference.GROUPCODE]);
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
            }
        }

        private void txtG3_Leave(object sender, EventArgs e)
        {
            try
            {
                if (txtG3.Text.Trim().Length < 3 ) return;

                Row dr = ShowHelp(txtG3.Text.Trim(), true, 2, new string[] { "GroupCode","GroupDesc"});
                txtG3.Text = dr == null ? "" : Convert.ToString(dr[COperationPreference.GROUPCODE]);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
            }
        }
         
        private void txtFmlyGroupCode_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.F3)
                {
                    Row dr = ShowHelp(txtFmlyGroupCode.Text.Trim(), true, 3, new string[] { "FamilyCode", "FamilyName" });
                    txtFmlyGroupCode.Text = dr == null ? "" : Convert.ToString(dr[COperationPreference.FAMILYCODE]);
                    txtFmlyGroupName.Text = dr == null ? "" : Convert.ToString(dr[COperationPreference.FAMILYNAME]);

                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
            }
        }
         

        private void txtFmlyGroupCode_Leave(object sender, EventArgs e)
        {
            try
            {
                if (txtFmlyGroupCode.Text.Trim().Length < 3) return;

                Row dr = ShowHelp(txtFmlyGroupCode.Text.Trim(), true, 3, new string[] { "FamilyCode", "FamilyName"});
                txtFmlyGroupCode.Text =dr== null ? "" : dr == null ? "" : Convert.ToString(dr[COperationPreference.FAMILYCODE]);
                txtFmlyGroupName.Text = dr == null ? "" : Convert.ToString(dr[COperationPreference.FAMILYNAME]);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
            }
        } 
      
        /// <summary>
        /// To Show Entity Help
        /// </summary>
        /// <param name="key">Search Key</param>
        /// <param name="AdvanceSearch">Flag for advance Search</param>
        /// <returns></returns>
        private Row ShowHelp(string key, bool AdvanceSearch, int HelpType, string[] SearchColumnList, string ConditionColValue= null)
        {
            string GroupCode = string.Empty;
            Row selectedRow = null;
            try
            {
                frmEntitySearch frmSearch = new frmEntitySearch();
                frmSearch.SearchKey = key;
                frmSearch.HelpType = HelpType;
                frmSearch.AllowAdvanceSearch = AdvanceSearch;
                frmSearch.Columns = SearchColumnList;
                frmSearch.DefaultSearchColumnIndex = 0;
                frmSearch.IsAddNewEnable = false;
                frmSearch.ConditionColValue = ConditionColValue;

                DialogResult resultDia = frmSearch.ShowDialog();

                if (resultDia == DialogResult.OK)
                {
                    selectedRow = frmSearch.SelectedRow;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAuthSign), ex.Message);
            }
            return selectedRow;
        }

     
    }
}
