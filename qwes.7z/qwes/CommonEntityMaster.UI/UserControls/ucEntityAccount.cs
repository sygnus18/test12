﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FTIL.Match.CDD.BAL.DataClasses;
using UCC.Class;
using UCC;
using FTIL.Match.CDD.UI.Forms;
using FTIL.Match.Common.Log;
using FTIL.Match.CDD.BAL;
using FTIL.MATCH.CDD.UI.Class;

/// <summary>
/// user control for individual account details
/// </summary>

namespace FTIL.Match.CDD.UI.UserControls
{
    public partial class ucEntityAccount : FTIL.Match.CDD.UI.UserControls.ucBaseEntity
    {
    
        ucAddress objCorrespondenceAddress;
        ucAddress objPermanetnAddress;
        frmEntityDetail objEntityDetail;
        private CucAddress m_ucAddress;
        //public string sName { get; set; }
        public string EntityType { get; set; }


        public ucEntityAccount()
        {
            ModifyMode = false;

            InitializeComponent();
            objCorrespondenceAddress = new ucAddress();
            objCorrespondenceAddress.Name = "objCorrespondenceAddress";
            
            objPermanetnAddress = new ucAddress();
            objPermanetnAddress.Name = "objPermanetnAddress";
            
            m_EntityDetailsInstance = new EntityDetails();
            m_ucAddress = new CucAddress();
        }

        private void ucEntityAccount_Load(object sender, EventArgs e)
        {
            try
            {
                objCorrespondenceAddress.isMandatory = true;
                objPermanetnAddress.isMandatory = true;

                objCorrespondenceAddress.Dock = DockStyle.Fill;
                pnlCorrespondenceAdd.Controls.Add(objCorrespondenceAddress);
                pnlCorrespondenceAdd.Tag = objCorrespondenceAddress;

                objPermanetnAddress.Dock = DockStyle.Fill;
                pnlParmanentAdd.Controls.Add(objPermanetnAddress);
                pnlParmanentAdd.Tag = objPermanetnAddress;

                PopulateLookup();
                PopulateControls();

                cboNationality_SelectedIndexChanged(this, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAccount), ex.Message);
                MessageBox.Show("unable to load account details", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public override void PopulateControls()
        {
            if (ModifyMode == false) return;

            try
            {
                if (FormUtil.IsValidDate(m_EntityDetailsInstance.DOB_OR_DOI))
                    dtDOB.Value = m_EntityDetailsInstance.DOB_OR_DOI.Value;

                cboGender.SetSelectedValue(m_EntityDetailsInstance.Gender);
                cboMaritalStatus.SetSelectedValue(m_EntityDetailsInstance.Marital_status);
                cboNationality.SetSelectedValue(m_EntityDetailsInstance.Nationality);
                dtDOB.MaxDate = System.DateTime.Today.Date;
                if (m_EntityDetailsInstance.StatusNonIndVal.Length == 1)
                    //m_EntityDetailsInstance.StatusNonIndVal = "0" + m_EntityDetailsInstance.StatusNonIndVal;
                cboClientStatus.SetSelectedValue(m_EntityDetailsInstance.StatusNonIndVal);
                //    m_EntityAccountInstance.Occupation = "";// txtOccupation.Text;

                //if (FormUtil.IsValidDate(m_EntityDetailsInstance.DateOfCreation))
                    //dtCreated.Value = m_EntityDetailsInstance.DateOfCreation.Value;

                txtFather_SpouseName.Text = m_EntityDetailsInstance.Father_sHusbands_Name;

                chkSameAsCorrs.Checked = m_EntityDetailsInstance.SameCorrPermAdd == "Y";

                if (!string.IsNullOrEmpty(m_EntityDetailsInstance.NationalityOther))
                {
                    txtNationalityName.Enabled = true;
                    txtNationalityName.Text = m_EntityDetailsInstance.NationalityOther;
                }

                objCorrespondenceAddress.PopupateControls(m_EntityDetailsInstance.CorrespondenceAddress);

                if (!chkSameAsCorrs.Checked)
                    objPermanetnAddress.PopupateControls(m_EntityDetailsInstance.PermanentAddress);
                else
                    objPermanetnAddress.PopupateControls(m_EntityDetailsInstance.CorrespondenceAddress);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAccount), ex.Message);
                MessageBox.Show("Unable to fill account details", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public override EntityDetails GetEntityDetails()
        {
            try
            {
                m_EntityDetailsInstance.CorrespondenceAddress = objCorrespondenceAddress.GetAddress();
                if (!chkSameAsCorrs.Checked)
                    m_EntityDetailsInstance.PermanentAddress = objPermanetnAddress.GetAddress();

                if (isValid())
                {
                    HasUpdated = false;

                    if (HasUpdated == false)
                        HasUpdated = m_EntityDetailsInstance.DOB_OR_DOI != dtDOB.Value;
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.Gender, cboGender.GetSelectedValue());
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.Marital_status, cboMaritalStatus.GetSelectedValue());
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.Nationality, cboNationality.GetSelectedValue());
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.Father_sHusbands_Name, txtFather_SpouseName.Text);
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.NationalityOther, txtNationalityName.Text);
                    if (HasUpdated == false)
                        HasUpdated = !FormUtil.IsEqual(m_EntityDetailsInstance.StatusNonIndVal, cboClientStatus.GetSelectedValue());


                    m_EntityDetailsInstance.DOB_OR_DOI = dtDOB.Value;
                    m_EntityDetailsInstance.Gender = cboGender.GetSelectedValue();
                    m_EntityDetailsInstance.Marital_status = cboMaritalStatus.GetSelectedValue();
                    m_EntityDetailsInstance.Nationality = cboNationality.GetSelectedValue();
                    m_EntityDetailsInstance.Occupation = "";// txtOccupation.Text;
                    //m_EntityDetailsInstance.Date_of_Declaration = frmEntityDetail.dtCreated.Value;
                    m_EntityDetailsInstance.Father_sHusbands_Name = txtFather_SpouseName.Text;
                    m_EntityDetailsInstance.StatusNonIndVal = cboClientStatus.GetSelectedValue();

                    if (HasUpdated == false)
                    {
                        bool bFlag = m_EntityDetailsInstance.SameCorrPermAdd == "Y";
                        HasUpdated = bFlag != chkSameAsCorrs.Checked;
                    }

                    m_EntityDetailsInstance.SameCorrPermAdd = chkSameAsCorrs.Checked == true ? "Y" : "N";


                    m_EntityDetailsInstance.NationalityOther = txtNationalityName.Text;
                }
                else
                    m_EntityDetailsInstance.IsValid = false;

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAccount), ex.Message);
                MessageBox.Show("Unable to get account details to save", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return m_EntityDetailsInstance;

        }

        protected override void PopulateLookup()
        {
            try
            {
                cboGender.ValueMember = "s_ReferenceCode";
                cboGender.DisplayMember = "s_ReferenceName";
                cboGender.DataSource = m_ucAddress.GetGender();

                cboMaritalStatus.ValueMember = "s_ReferenceCode";
                cboMaritalStatus.DisplayMember = "s_ReferenceName";
                cboMaritalStatus.DataSource = m_ucAddress.GetMaritalStatus(); //l_dsPopulateClientDetails.Tables[3];

                cboNationality.ValueMember = "s_ReferenceCode";
                cboNationality.DisplayMember = "s_ReferenceName";
                cboNationality.DataSource = m_ucAddress.GetNationality(); //l_dsPopulateClientDetails.Tables[1];

                cboClientStatus.ValueMember = "s_ReferenceCode";
                cboClientStatus.DisplayMember = "s_ReferenceName";
                cboClientStatus.DataSource = m_ucAddress.GetClientStatus();


                cboClientStatus.SelectedValue = string.Empty;

                cboNationality_SelectedIndexChanged(this, EventArgs.Empty);
                cboGender.SelectedValue = string.Empty;
                cboMaritalStatus.SelectedValue = string.Empty;
                cboNationality.SelectedValue = string.Empty;

                dtDOB.MaxDate = System.DateTime.Today.Date;
                cboMaritalStatus.BackColor = UIConstants.CtrlBackColor;
                cboNationality.BackColor = UIConstants.CtrlBackColor;
                txtFather_SpouseName.BackColor = UIConstants.CtrlBackColor;

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAccount), ex.Message);
                MessageBox.Show("Unalble to populate account details", sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cboNationality_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (
                    (cboNationality.SelectedValue != null)
                    &&
                    (cboNationality.SelectedValue.ToString() == CUCCConstants.Instance.OTHER_NATIONALITY_CODE) //Other
                   )
                {
                    if (!string.IsNullOrEmpty(m_EntityDetailsInstance.NationalityOther))
                        txtNationalityName.Text = m_EntityDetailsInstance.NationalityOther;
                    else txtNationalityName.Text = string.Empty;

                    txtNationalityName.Enabled = true;
                    txtNationalityName.Focus();
                }
                else
                {
                    txtNationalityName.Enabled = false;
                    txtNationalityName.Text = string.Empty;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAccount), ex.Message);
                MessageBox.Show(ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        protected override bool isValid()
        {
            string Msg="";
            string FieldMsg = "";
            try
            {
                m_EntityDetailsInstance.iCount = 0;
                m_EntityDetailsInstance.IsValid = true;
                FieldMsg += m_EntityDetailsInstance.ValidateField(sName, "", " Name,", ref Msg);
                if (FieldMsg != "")
                {
                    FieldMsg = FieldMsg.Remove(FieldMsg.Length - 1);
                    m_EntityDetailsInstance.IsValid = false;
                    MessageBox.Show(FieldMsg + Msg, sClientHeaderName, MessageBoxButtons.OK);
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(ucEntityAccount), ex.Message);
                MessageBox.Show(ex.Message, sClientHeaderName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
          return FieldMsg=="";

        }

        private void chkSameAsCorrs_CheckedChanged(object sender, EventArgs e)
        {
            objPermanetnAddress.Enabled = !chkSameAsCorrs.Checked;
            if (chkSameAsCorrs.Checked)
            {
                objPermanetnAddress.PopupateControls(objCorrespondenceAddress.GetAddress());
            }
        }

        /// Corrospondance Address updated 
        /// </summary>
        public override bool CorrAddressUpdated { get {
                return objCorrespondenceAddress.HasUpdated;
            } }


        /// <summary>
        /// Permanent address updated
        /// </summary>
        public override bool PerAddressUpdated { get {
                return  objPermanetnAddress.HasUpdated;
            } }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void cboGender_SelectedIndexChanged(object sender, EventArgs e)
        {

            //if (cboGender.SelectedIndex > 0)
            //{
            //    objEntityDetail = new frmEntityDetail();
            //    int ind = Convert.ToInt32(cboGender.SelectedIndex.ToString());
            //    objEntityDetail.SetDefaultImg(ind);
            //}

        }

        public EventHandler GenderSelectionChange
        {
            set
            {
                cboGender.SelectedIndexChanged += value;
            }
        }
    }
}

