﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace FTIL.Match.CDD.ProductSync
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FTIL.Match.CDD.ProductSync.Forms.frmFrame());
        }
    }
}
