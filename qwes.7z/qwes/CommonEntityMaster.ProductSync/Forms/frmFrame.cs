﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using EquityMaster.Forms;
using FTIL.Match.Common.Log;
namespace FTIL.Match.CDD.ProductSync.Forms
{
    public partial class frmFrame : Form
    {
        public int ProductId { get; set; }
        public string strProductName { get; set; }
        //private EquityMaster.Forms.frmClientPreferencesMaster obj;
        public frmFrame()
        {
            InitializeComponent();
            this.KeyPreview = true;
        }

        private void frmFrame_Load(object sender, EventArgs e)
        {
            //strProductName = "Match";
            //ProductId = 1;
            switch (ProductId)
            {
                case 1: MatchEquity();
                    break;

                case 17:
                    break;
                case 18:
                    break;

                default: break;


            }
            this.ShowIcon = false;

            tabPage1.Text = strProductName;
            this.Text = strProductName;
        }
        private void MatchEquity()
        {
            string sBinDirName;

            sBinDirName = Environment.CurrentDirectory;

            try
            {


                EquityMaster.Forms.frmClientPreferencesMaster obj = new EquityMaster.Forms.frmClientPreferencesMaster();
                obj.TopLevel = false;
                obj.Parent = tabPage1;
                obj.WindowState = FormWindowState.Maximized;
                obj.MaximizeBox = false;
                obj.MinimizeBox = false;
                obj.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
                obj.FormClosing += fncFormClosing;
                obj.ShowIcon = false;
                obj.ShowInTaskbar = false;
                obj.StartPosition = FormStartPosition.CenterScreen;
                obj.Visible = true;

                obj.Dock = DockStyle.Fill;
                tabPage1.Controls.Add(obj);
                tabPage1.Tag = obj;
            }

            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex.Message);
                MessageBox.Show(ex.Message + " and unable to page bind.", string.Empty, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void fncFormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
        }
        private void frmFrame_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }
    }
}
