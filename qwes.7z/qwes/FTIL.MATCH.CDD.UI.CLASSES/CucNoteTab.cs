﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FTIL.Match.Common;
using FTIL.Match.CDD.BAL;
using FTIL.Match.Common.Log;

namespace FTIL.MATCH.CDD.UI.Class
{
    public class CucNoteTab
    {
         CNote m_CNote =new CNote();

         public void FillData(int EntityNo)
         {
             try
             {
                 m_CNote.GetNote(EntityNo);
             }
             catch (Exception Ex)
             {
                 Logger.Instance.WriteLog(typeof(CucNoteTab), Ex.Message);
             }
         }

         public MethodExecResult updateData(int EntityNo,string Description,string NoteText)
         {
             try
             {
                 m_CNote.EntityNo = EntityNo;
                 m_CNote.Description = Description;
                 m_CNote.NoteText = NoteText;

                 MethodExecResult m_MethodExecResult = m_CNote.UpdateNote();
                 return m_MethodExecResult;
             }
             catch (Exception Ex)
             {
                 Logger.Instance.WriteLog(typeof(CucNoteTab), Ex.Message);
                 return new MethodExecResult(-1, null, Ex.Message, null);
             }
         }
    }
}
