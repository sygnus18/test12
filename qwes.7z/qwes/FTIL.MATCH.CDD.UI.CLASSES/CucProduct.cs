﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using FTIL.Match.CDD.BAL;
using FTIL.Match.Common.Log;

namespace FTIL.MATCH.CDD.UI.Class
{
   public class CucProduct
    {
        public void FillExchangeGrid(int ClientNo, ref DataTable dtExchange)
        {

            try
            {
                CExchangeMap m_ObjExchange = new CExchangeMap();
                m_ObjExchange.GetExchangeDetailsForProduct(ClientNo, ref dtExchange, "S");
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucProduct), Ex.Message);
            }
        }

        public void FillProductGrid(int ClientNo, ref DataTable dtProduct)
        {
            try
            {
                CProductSync m_ObjProductSync = new CProductSync();
                m_ObjProductSync.GetEntityProducts(ClientNo, ref dtProduct);
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucProduct), Ex.Message);
            }
        }
    }
}
