﻿using FTIL.Match.CDD.BAL;
using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.Common.Log;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using UCC.Class;

namespace FTIL.MATCH.CDD.UI.Class
{
    public class CucOperation
    {
        COperationPreference m_ObjClientPrefernces = new COperationPreference();

        public void GetEntityPreferenceDetails(int ClientId, ref DataSet ds)
        {
            try
            {
                m_ObjClientPrefernces.GetEntityPreferenceDetails(ClientId, ref ds);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CucOperation), ex.Message);
            }
        }

        public static void GetCompanyName(ref DataSet dsLicenseDetails)
        {
            try
            {
                CClientAuthorization.GetCompanyName(ref dsLicenseDetails);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CucOperation), ex.Message);
            }
        }


        public void GetLookupData(ref DataSet l_dsLookUp, ref string l_sErrorMsg)
        {
            try
            {
                m_ObjClientPrefernces.GetLookupData(ref l_dsLookUp, ref l_sErrorMsg);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CucOperation), ex.Message);
            }
        }

        public DataTable GetBrokMethod()
        {
            DataTable DtBrokMethod = null;
            try
            {
                DtBrokMethod = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.BrokMethodCode];
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CucOperation), ex.Message);
            }
            return DtBrokMethod;
        }


        public void GetCustodianDetails(int ClientNo, ref DataTable dtCustodianDetails, int UserNo, ref DataTable dtCustodianMaster)
        {
            try
            {
                CEntityMaster.GetCustodianDetails(ClientNo, ref dtCustodianDetails, UserNo, ref dtCustodianMaster);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CucOperation), ex.Message);
            }
        }





    }
}
