﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using UCC.Class;
using FTIL.Match.CDD.BAL;
using FTIL.Match.Common.Log;
using FTIL.Match.CDD.BAL.DataClasses;

namespace FTIL.MATCH.CDD.UI.Class
{

    public class CucOther
    {
        public DataTable GetDocument()
        {
            try
            {
                return CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.PROOFTYPE];
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucOther), Ex.Message);
                return null;
            }
        }

        public DataTable GetOccupation()
        {
            try
            {
                return CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.OCCUPATION];
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucOther), Ex.Message);
                return null;
            }
        }

        public DataTable GetPEP()
        {
            try
            {
                return CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.PEP];
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucOther), Ex.Message);
                return null;
            }
        }

        public DataTable GetFacilityType()
        {
            try
            {
                return CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.FACILITY];
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucOther), Ex.Message);
                return null;
            }
        }

        public DataTable GetGrossAnnual(string EntityType)
        {
            try
            {
                DataTable l_dtCurrentRefData = null;
                DataRow[] dr = null;

                if (EntityType == CCMConstants.NON_INDIVIDUAL)
                    dr = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.ANNINC].Select("s_ReferenceSubType = 'NONIND' OR s_ReferenceSubType = 'BOTH'");
                else
                    dr = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.ANNINC].Select("s_ReferenceSubType = 'IND' OR s_ReferenceSubType = 'BOTH'");


                l_dtCurrentRefData = new DataTable();
                l_dtCurrentRefData.Columns.Add("n_ReferenceNo");
                l_dtCurrentRefData.Columns.Add("s_ReferenceType");
                l_dtCurrentRefData.Columns.Add("s_ReferenceCode");
                l_dtCurrentRefData.Columns.Add("s_ReferenceName");
                l_dtCurrentRefData.Columns.Add("s_ReferenceSubType");


                for (int iCnt = 0; iCnt <= dr.Length - 1; iCnt++)
                    l_dtCurrentRefData.ImportRow(dr[iCnt]);

                return l_dtCurrentRefData;
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucOther), Ex.Message);
                return null;
            }
        }

        public DataSet FillGrid(int ClientNo, string StatusNonIndVal = "")
        {
            DataSet dsResult = null;
           
            try
            {
                CEntityMaster.GetEntityDocDetails(ClientNo, null, ref dsResult, StatusNonIndVal);
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucOther), Ex.Message);
            }
            return dsResult;
        }


        public DataSet FillSubType(int ClientNo, string StatusNonIndVal = "")
        {
            DataSet dsResult = null;
            try
            { 
                CEntityMaster.GetEntityDocDetails(ClientNo, null, ref dsResult, StatusNonIndVal); 
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucOther), Ex.Message); 
            }
            return  dsResult ;
        }



        public DataTable GetEducationData()
        {
            try
            {
                return CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.EDUCATION];
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucOther), Ex.Message);
                return null;
            }
        }

    }
}
