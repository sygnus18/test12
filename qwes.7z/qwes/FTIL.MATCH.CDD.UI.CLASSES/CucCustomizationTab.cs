﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.Common.Log;

namespace FTIL.MATCH.CDD.UI.Class
{
   public class CucCustomizationTab
    {
        cCustomization objCustomization = new cCustomization();
        public void FillCustomizationDetails(int ProductNo, ref DataSet dsResult, string s_CustId)
        {
            try
            {
                objCustomization.GetCustomizationDetails(ProductNo, ref dsResult, s_CustId);
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucCustomizationTab), Ex.Message);
            }
        }

        public void SaveCustomizationDetails(int ProductNo, DataTable dsResult)
        {
            try
            {
                objCustomization.UpdateFieldValuesDetails(ProductNo, dsResult, DateTime.Now.Date);
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucCustomizationTab), Ex.Message);
            }
        }
    }
}
