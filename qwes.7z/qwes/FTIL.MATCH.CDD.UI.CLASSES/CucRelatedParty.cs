﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using UCC.Class;
using FTIL.Match.Common.Log;
using FTIL.Match.CDD.BAL;
using FTIL.Match.Common;
using FTIL.Match.CDD.BAL.DataClasses;

namespace FTIL.MATCH.CDD.UI.Class
{
    public class CucRelatedParty
    {
        public DataTable GetRelationship()
        {
            try
            {
                string EntityType = "I";
                DataTable l_dtCurrentRefData = null;
                DataRow[] dr = null;

                if (EntityType == CCMConstants.NON_INDIVIDUAL)
                    dr = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.RELATION].Select("s_ReferenceSubType = 'NONIND' OR s_ReferenceSubType = 'BOTH'");
                else
                    dr = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.RELATION].Select("s_ReferenceSubType = 'IND' OR s_ReferenceSubType = 'BOTH'");

                l_dtCurrentRefData = new DataTable();

                l_dtCurrentRefData.Columns.Add("n_ReferenceNo");
                l_dtCurrentRefData.Columns.Add("s_ReferenceType");
                l_dtCurrentRefData.Columns.Add("s_ReferenceCode");
                l_dtCurrentRefData.Columns.Add("s_ReferenceName");
                l_dtCurrentRefData.Columns.Add("s_ReferenceSubType");

                for (int iCnt = 0; iCnt <= dr.Length - 1; iCnt++)
                        l_dtCurrentRefData.ImportRow(dr[iCnt]);
                  
                return l_dtCurrentRefData;
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucRelatedParty), Ex.Message);
                return null;
            }
        }

        public DataSet GetAuthSignDetails(int nClientNo)
        {
            DataSet ds = new DataSet();
            try
            {
                DataTable dtAuthDetails, dtAddress;
                dtAuthDetails = dtAddress = null;
                CEntityMaster.GetAuthSignDetails(nClientNo, ref dtAuthDetails, ref dtAddress);
                dtAuthDetails.TableName = "AuthDetails";
                dtAddress.TableName = "Address";

                ds.Tables.Add(dtAuthDetails.Copy());
                ds.Tables.Add(dtAddress.Copy());
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ds;
        }


   
    }
}
