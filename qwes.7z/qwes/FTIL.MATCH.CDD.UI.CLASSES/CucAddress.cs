﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using UCC.Class;
using FTIL.Match.Common.Log;
using FTIL.Match.CDD.BAL;

namespace FTIL.MATCH.CDD.UI.Class
{
    public class CucAddress
    { 
        public DataTable GetCity()
        { 
          return (CMastersDataProvider.Instance[Masters.CityStateMapping]);  
        }

        public DataTable GetCity(string n_EntityNo, string s_CityName)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            try
            {
                CEntityMaster objCity = new CEntityMaster();
                objCity.GetCity(n_EntityNo, ref ds, s_CityName);
                if (ds != null && ds.Tables.Count > 1)
                   dt= ds.Tables[1]; 
            }
            catch(Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CucAddress), ex.Message); 
            }

            return dt;
        }

        public DataTable GetBranch(string n_EntityNo, string s_BranchCode)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            try
            {
                CEntityMaster objbranchy = new CEntityMaster();
                objbranchy.GetBranch(n_EntityNo, ref ds, s_BranchCode);
                if (ds != null)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CucAddress), ex.Message);
            }

            return dt;
        } 

        public DataTable GetState()
        {
            DataTable dtState = null;
            try
            { 
                dtState = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.STATE];
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CucAddress), ex.Message); 
            }
            return dtState;
        }

        public DataTable GetCountry()
        {
            DataTable dtCountry = null;
            try
            {
             dtCountry =CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.COUNTRY];
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CucAddress), ex.Message);
            }
            return dtCountry;
        }

        public DataTable GetTaxStatus()
        {
            DataTable dtTaxStatus = null;
            try
            {
                dtTaxStatus = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.TaxStatus];
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CucAddress), ex.Message);
            }
            return dtTaxStatus;
        }

        public DataTable GetBranch()
        {
            DataTable dtBranch = null;
            try
            {
                dtBranch = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.Branch];
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CucAddress), ex.Message);
            }
            return dtBranch;
        }

        public DataTable GetGender()
        {
            DataTable dtGender = null;
            try
            {
                dtGender = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.GENDER];//.WithFirstBlank();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CucAddress), ex.Message);
            }
            return dtGender;
        }

        public DataTable GetMaritalStatus()
        {
            DataTable dtMaritalStatus = null;
            try
            {
            dtMaritalStatus= CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.MARITALST];//.WithFirstBlank();
                }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CucAddress), ex.Message);
            }
            return dtMaritalStatus;
        }

        public DataTable GetNationality()
        {
            DataTable dtNationality = null;
            try
            {
                dtNationality = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.NATIONALTY];//.WithFirstBlank();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CucAddress), ex.Message);
            }
            return dtNationality;
        }

        public DataTable GetClientStatus()
        {
            DataTable dtClientStatus = null;
            try
            {
            dtClientStatus = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.CDDTYPE_I];//.WithFirstBlank();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CucAddress), ex.Message);
            }
            return dtClientStatus;
        }

        public DataTable GetTitle()
        {
            DataTable dtClientStatus = null;
            try
            {
                dtClientStatus = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.TITLE];//.WithFirstBlank();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CucAddress), ex.Message);
            }
            return dtClientStatus;
        }

        public DataTable GetType()
        {
            DataTable dtClientStatus = null;
            try
            {
                dtClientStatus = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.CDDTYPE_I];//.WithFirstBlank();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CucAddress), ex.Message);
            }
            return dtClientStatus;
        }

        public DataSet GetAccountDetails(int nClientNo)
        {
            DataSet ds = new DataSet();
            try
            {
                DataTable dtEntity, dtAddress;
                dtEntity = dtAddress = null;
                CEntityMaster.GetEntitybyClientNo(nClientNo, ref dtEntity, ref dtAddress);
                dtEntity.TableName="Entity";
                dtAddress.TableName = "Address";

                ds.Tables.Add(dtEntity.Copy());
                ds.Tables.Add(dtAddress.Copy());
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ds;
        }

        public DataTable GetTitle2()
        {
            DataTable dtClientStatus = null;
            try
            {
                dtClientStatus = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.TITLE2];//.WithFirstBlank();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CucAddress), ex.Message);
            }
            return dtClientStatus;
        }


        public DataTable GetTabType()
        {
            DataTable dtClientStatus = null;
            try
            {
                dtClientStatus = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.TABTYPE];//.WithFirstBlank();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CucAddress), ex.Message);
            }
            return dtClientStatus;
        }

        public DataTable GetIntroducerType()
        {
            DataTable dtClientStatus = null;
            try
            {
                dtClientStatus = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.INTTYPE];//.WithFirstBlank();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(typeof(CucAddress), ex.Message);
            }
            return dtClientStatus;
        }


    }
}
