﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;

namespace FTIL.MATCH.CDD.UI.Class
{ 
    public static class Extension
    {
        /*Converts DataTable To List*/
        public static List<TSource> ToList<TSource>(this DataTable dataTable) where TSource : new()
        {

            var dataList = new List<TSource>();

            const BindingFlags flags = BindingFlags.Public | BindingFlags.Instance | BindingFlags.NonPublic;

            PropertyInfo[] properties = typeof(TSource).GetProperties(flags);

            foreach (DataRow dataRow in dataTable.Rows)
            {
                var aTSource = new TSource();
                foreach (var propertyInfo in properties)
                {
                    if (dataTable.Columns.Contains(propertyInfo.Name))
                    {
                        if ((dataRow[propertyInfo.Name] != null) && (dataRow[propertyInfo.Name] != DBNull.Value))
                            propertyInfo.SetValue(aTSource, dataRow[propertyInfo.Name], null);

                    }
                }
                dataList.Add(aTSource);
            }
            return dataList;
        }

        /// <summary>
        /// Extension method on DataTable to return DataTable with first record as blank
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static DataTable WithFirstBlank(this DataTable dt)
        {
            if (dt == null)
                return null;

            if (string.IsNullOrEmpty(dt.Rows[0][0].ToString()))
                return dt;

            DataRow dr = dt.NewRow();

            dt.Rows.InsertAt(dr, 0);

            return dt;
        }


    } 
}
