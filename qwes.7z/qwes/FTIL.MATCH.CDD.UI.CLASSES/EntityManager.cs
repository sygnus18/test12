﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FTIL.Match.CDD.BAL;
using FTIL.Match.CDD.BAL.DataClasses;
using FTIL.Match.Common;
using FTIL.Match.Common.Log; 
using System.Data;

namespace FTIL.MATCH.CDD.UI.Class
{
    /// <summary>
    /// Class for manupulationg Entity
    /// </summary>
  public  class EntityManager
    {

        public EntityManager()
        {
            m_CEntityMaster = new CEntityMaster();
            EntityOtherDetails = new EntityOthersDtl();
            m_EntityBankDetails = new BankDtls();
            m_EntityCustodianDetails = new cCustodian();
            m_EntityProductDetails = new CExchangeMap();

        }

        private CEntityMaster m_CEntityMaster;

        private EntityDetails m_EntityDetails;
        private EntityOthersDtl m_EntityOtherDetails;
        private BankDtls m_EntityBankDetails;
        private CExchangeMap m_EntityProductDetails;
        private EntityDetails m_EntityGuardianDetails;
        private cCustodian m_EntityCustodianDetails;
        private COperationPreference m_OperationPreference;

        public byte[] EntityUploadedPhotoBin { get; set; }
        public long UploadedPhotoSizeByte { get; set; }
        public DateTime UploadedPhotoModifedDT { get; set; }
        public string UploadedPhotoFileName { get; set; }



        /// <summary>
        /// Total no of record in Master Entity Grid
        /// </summary>
        public int EntityMasterRecordCount { get { return m_CEntityMaster.EntityDataTable.Rows.Count; } }



        public int ClientNo { get { return m_CEntityMaster.ClientNo; } }


        /// <summary>
        /// Flag for account details updated or not
        /// </summary>
        public bool AccDetailUpdatedFlag { get; set; }

        /// <summary>
        /// Flag for account document details updated or not
        /// </summary>
        public bool AccDocDetailUpdatedFlag { get; set; }

        /// <summary>
        /// Flag for Bank details updated or not
        /// </summary>
        public bool AccBankDetailUpdatedFlag { get; set; }

        /// <summary>
        /// Corrospondance Address updated 
        /// </summary>
        public bool CorrAddressUpdated { get; set; }


        /// <summary>
        /// Permanent address updated
        /// </summary>
        public bool PerAddressUpdated { get; set; }


        public bool HasPhotoUpdated { get; set; }

        /// <summary>
        /// Guardian Corrospondance Address updated  
        /// </summary>
        public bool CorrGuardianAddressUpdated { get; set; }

        /// <summary>
        /// Guardian Permanent Address updated  
        /// </summary>
        public bool PerGuardianAddressUpdated { get; set; }

        /// <summary>
        /// Flag for Custodian details updated or not
        /// </summary>
        public bool CustodianDetailUpdatedFlag { get; set; }


        public CEntityMaster EntityMasterInstance
        {
            get { return m_CEntityMaster; }
            set { m_CEntityMaster = value; }
        }

        /// <summary>
        /// Flag for Guardian details updated or not 
        /// </summary>
        public bool AccGuardiantDetailUpdatedFlag { get; set; }


        /// <summary>
        /// Other Details 
        /// </summary>
        public EntityOthersDtl EntityOtherDetails
        {
            get { return m_EntityOtherDetails; }
            set { m_EntityOtherDetails = value; }
        }

        public EntityDetails EntityGuardianDetails
        {
            get { return m_EntityGuardianDetails; }
            set { m_EntityGuardianDetails = value; }
        }

        public BankDtls EntityBankDetails
        {
            get { return m_EntityBankDetails; }
            set { m_EntityBankDetails = value; }
        }


        public CExchangeMap EntityProductDetails
        {
            get { return m_EntityProductDetails; }
            set { m_EntityProductDetails = value; }
        }

        public EntityDetails EntityDetails
        {
            get { return m_EntityDetails; }
            set { m_EntityDetails = value; }
        }

        public AuthSignDetails EntityAuthSignDetail { get; set; }
        public cCustodian EntityCustodianDetails
        {
            get { return m_EntityCustodianDetails; }
            set { m_EntityCustodianDetails = value; }
        }

        public COperationPreference OperationPreference
        {
            get { return m_OperationPreference; }
            set { m_OperationPreference = value; }
        }

        public string sError { get; set; }
        /// <summary>
        /// Fill Entity details 
        /// </summary>
        /// <param name="identifier">EntityNo/RowNo</param>
        /// <param name="byRowNo">If RowNo passed</param>
        public void SetEntityDetails(int identifier, bool byRowNo)
        {

            if (byRowNo)
                m_EntityDetails = m_CEntityMaster.GetEntityDetailsByNo(identifier, byRowNo);
            else
                m_EntityDetails = m_CEntityMaster.GetEntityDetailsByNo(ClientNo, byRowNo);

            if (ClientNo == 0)
                m_EntityDetails = new EntityDetails();

        }

        /// <summary>
        /// Fill Guardian Details
        /// </summary>
        /// <param name="identifier">EntityNo/RowNo</param>
        /// <param name="byRowNo">If RowNo passed</param>
        public void SetGuardianDetails(int identifier, bool byRowNo)
        {

            m_EntityGuardianDetails = m_CEntityMaster.GetEntityGaurdianDetails(ClientNo);

            if (ClientNo == 0 || m_EntityGuardianDetails == null)
                m_EntityGuardianDetails = new EntityDetails();
        }

        /// <summary>
        /// Apply Entity changes to database
        /// </summary>
        /// <returns></returns>
        public void ApplyChanges(string Operation, string sTabName)
        {

            MethodExecResult l_objMethodExceResult = new MethodExecResult(0);
            m_CEntityMaster.ErrorMsg = "";
            sError = "";
            // Save Account details/and Other details
            if (sTabName == "TBACCOUNT" || sTabName == "TBOTHERS")
            {
                //Return if No data has been updated 
                if (AccDetailUpdatedFlag == false && AccDocDetailUpdatedFlag == false &&
                     CorrAddressUpdated == false && PerAddressUpdated == false)
                {
                    return;
                }
                AccDocDetailUpdatedFlag = false;

                if (EntityDetails != null)
                    if (EntityDetails.IsValid == false) return;

                //Invaild Data
                if (EntityDetails == null)
                {
                    return;
                }


                l_objMethodExceResult = m_CEntityMaster.Update(m_EntityDetails, Operation, AccDetailUpdatedFlag, CorrAddressUpdated, PerAddressUpdated);
                m_EntityDetails.ClientNo = m_CEntityMaster.ClientNo;

                //check for modified lastupdated date 
                if (m_CEntityMaster.ErrorNo == 101)
                {

                    m_CEntityMaster.ErrorMsg = "Y";
                    l_objMethodExceResult = m_CEntityMaster.Update(m_EntityDetails, Operation, AccDetailUpdatedFlag, CorrAddressUpdated, PerAddressUpdated);
                    m_EntityDetails.ClientNo = m_CEntityMaster.ClientNo;

                }


                // Save Entity Document details
                if (sTabName == "TBOTHERS")
                {
                    if (EntityOtherDetails.dtResult != null)
                        l_objMethodExceResult = m_CEntityMaster.UpdateEntityDocDetails(m_EntityDetails.ClientNo, EntityOtherDetails.dtResult, EntityOtherDetails.dLastUpdatedDate);
                    //check for modified lastupdated date 
                    if (m_CEntityMaster.ErrorNo == 101)
                    {
                        m_CEntityMaster.ErrorMsg = "Y";
                        l_objMethodExceResult = m_CEntityMaster.UpdateEntityDocDetails(m_EntityDetails.ClientNo, EntityOtherDetails.dtResult, EntityOtherDetails.dLastUpdatedDate);


                    }
                    AccDocDetailUpdatedFlag = true;
                }
            }

            if (sTabName == "TBBANK")
            {
                if (EntityBankDetails.dtBankResult != null)
                    l_objMethodExceResult = m_CEntityMaster.UpdateEntityBankDetails(m_EntityDetails.ClientNo, EntityBankDetails.dtBankResult, EntityBankDetails.dLastUpdatedDate);
                if (m_CEntityMaster.ErrorNo == 101)
                {
                    m_CEntityMaster.ErrorMsg = "Y";
                    l_objMethodExceResult = m_CEntityMaster.UpdateEntityBankDetails(m_EntityDetails.ClientNo, EntityBankDetails.dtBankResult, EntityBankDetails.dLastUpdatedDate);

                }
            }

            //-------------Anil Added For Product----------------------------
            if (sTabName == "TBPRODUCT")
            {
                if (EntityProductDetails.dtExchangeResult != null)
                    l_objMethodExceResult = m_CEntityMaster.UpdateEntityProductDetails(m_EntityDetails.ClientNo, EntityProductDetails.dtExchangeResult, EntityProductDetails.dLastUpdatedDate);
                if (m_CEntityMaster.ErrorNo == 101)
                {
                    m_CEntityMaster.ErrorMsg = "Y";
                    l_objMethodExceResult = m_CEntityMaster.UpdateEntityProductDetails(m_EntityDetails.ClientNo, EntityBankDetails.dtBankResult, EntityBankDetails.dLastUpdatedDate);

                }
            }
            //----------------------------------------------------

            if (sTabName == "TBGUARDIAN")
            {
                if (m_EntityGuardianDetails != null)
                    l_objMethodExceResult = m_CEntityMaster.UpdateGuardian(m_EntityGuardianDetails, Operation,
                        AccGuardiantDetailUpdatedFlag, CorrGuardianAddressUpdated, PerGuardianAddressUpdated);
            }
            if (sTabName == "TBCUSTODIAN")
            {
                if (EntityCustodianDetails != null)
                {
                    l_objMethodExceResult = m_CEntityMaster.UpdateEntityCustodianDetails(m_EntityDetails.ClientNo, EntityCustodianDetails.dtCustodianResult, EntityCustodianDetails.dLastUpdatedDate);

                }
                if (m_CEntityMaster.ErrorNo == 101)
                {
                    m_CEntityMaster.ErrorMsg = "Y";
                    l_objMethodExceResult = m_CEntityMaster.UpdateEntityCustodianDetails(m_EntityDetails.ClientNo, EntityCustodianDetails.dtCustodianResult, EntityCustodianDetails.dLastUpdatedDate);

                }
            }
            if (sTabName == "TBAUTHORISEDSIGNATORIES")
            {
                if (EntityAuthSignDetail != null)
                {

                    //Invaild Data
                    if (EntityAuthSignDetail.HasRecordUpdated() == false)
                    {
                        return;
                    }

                    if (EntityAuthSignDetail.dtResult != null)
                        l_objMethodExceResult = m_CEntityMaster.UpdateEntityAuthSignDetails(m_EntityDetails.ClientNo,
                            EntityAuthSignDetail.dtResult, EntityAuthSignDetail.dtAddress, EntityAuthSignDetail.dLastUpdatedDate);
                    if (m_CEntityMaster.ErrorNo == 101)
                    {
                        m_CEntityMaster.ErrorMsg = "Y";
                        l_objMethodExceResult = m_CEntityMaster.UpdateEntityAuthSignDetails(m_EntityDetails.ClientNo,
                           EntityAuthSignDetail.dtResult, EntityAuthSignDetail.dtAddress, EntityAuthSignDetail.dLastUpdatedDate);

                    }

                }
            }
            if (sTabName == "TBPREFERENCES")
            {
                if (m_OperationPreference != null)
                    l_objMethodExceResult = m_CEntityMaster.UpdateClientPreferences(Operation, m_CEntityMaster.ClientNo, m_OperationPreference);
            }

            if (l_objMethodExceResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, l_objMethodExceResult);

                if (m_CEntityMaster.ErrorNo == 101)
                { /* MessageBox.Show(m_CEntityMaster.ErrorMsg, string.Empty, MessageBoxButtons.OK, MessageBoxIcon.Error);*/ }
                else
                    sError = "E";
            }
            else
            {
                try
                {
                    // AutoAuthorized(ClientNo);
                }
                catch (Exception ex)
                {
                    sError = "E";
                    Logger.Instance.WriteLog(this, ex.Message);
                    return;
                }
            }
        }


        public long UploadPhoto()
        {

            if (EntityUploadedPhotoBin != null && HasPhotoUpdated)
            {
                MethodExecResult l_objMethodExceResult;


                l_objMethodExceResult = CEntityMaster.UploadDocument(
                                 "U", m_CEntityMaster.ClientNo, UploadedPhotoFileName,
                                        EntityUploadedPhotoBin, null,
                                        UploadedPhotoSizeByte,
                                        UploadedPhotoModifedDT,
                                        ClientNo, 'C',
                                        "",
                                         "",
                                        DateTime.Now
                                  );//


                EntityUploadedPhotoBin = null;
                //HasPhotoUpdated = false;

                return l_objMethodExceResult.ReturnCode;
            }

            return -1;
        }
    }
}
