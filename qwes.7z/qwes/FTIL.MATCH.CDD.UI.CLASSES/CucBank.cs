﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using FTIL.Match.CDD.BAL;
using UCC.Class;
using FTIL.Match.Common.Log;

namespace FTIL.MATCH.CDD.UI.Class
{
    public class CucBank
    {
        public void FillBankDetails(int ClientId, ref DataTable dtResult, int UserNo, ref DataTable dtBankMaster)
        {
            try
            {
                CEntityMaster.GetEntityBankDetails(ClientId, ref dtResult, UserNo, ref dtBankMaster);
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucBank), Ex.Message);
            }
        }

        public DataTable Getaccount()
        {
            try
            {
                return CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.BANKACCTYP];
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucBank), Ex.Message);
                return null;
            }
        }
    }
}
