﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FTIL.Match.CDD.BAL;
using System.Data;
using FTIL.Match.Common;
using System.IO;
using FTIL.Match.Common.Log;

namespace FTIL.MATCH.CDD.UI.Class
{
    public class CucDocUpload
    {
        public void FillTypeofDocument(int n_ClientNo, ref DataSet ds_Doc)
        {
            try
            {
                CEntityMaster.GetEntityDocDetails(n_ClientNo, "DOC_UPLOAD", ref ds_Doc);
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucDocUpload), Ex.Message);
            }
        }

        public void FillUploadedDocumentDetails(int n_ClientNo, ref DataTable dt_UploadDocumentDetails)
        {
            try
            {
                CEntityMaster.GetUploadedDocumentDetail(n_ClientNo, ref  dt_UploadDocumentDetails);
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucDocUpload), Ex.Message);
            }
        }

        public void GetTypeOfDocument(int n_ClientNo, ref DataSet ds_UploadDocumentDetails)
        {
            try
            {
                CEntityMaster.GetUploadedDocumentDetail(n_ClientNo, ref  ds_UploadDocumentDetails);
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucDocUpload), Ex.Message);
            }
        }

        public void GetUploadType(int nClientNo, ref DataSet resultDataSet)
        {
            try
            {
                CEntityMaster.GetUploadType(nClientNo, ref resultDataSet);
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucDocUpload), Ex.Message);
            }
        }

        public MethodExecResult UploadDocument(string OperationType, int n_ClientDocNo, string s_filename, string s_comment, long n_size, DateTime? d_LastWriteTime, int n_ClientNo, byte[] b_data, char s_EntityType,string n_RepresentativeNo,string s_DocProofNo, DateTime d_DocExpiryDate)
        {

            try
            {
                MethodExecResult resultMethod = CEntityMaster.UploadDocument(
                                                     OperationType, n_ClientDocNo, s_filename,
                                                     b_data, s_comment,
                                                     n_size,
                                                     d_LastWriteTime,
                                                     n_ClientNo,
                                                     s_EntityType,
                                                     n_RepresentativeNo,
                                                     s_DocProofNo,
                                                     d_DocExpiryDate
                                                      );

                return resultMethod;
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucDocUpload), Ex.Message);
                return null;
            }
        }

        public MethodExecResult DeleteDocument(int n_CurrentClientDocNo, string s_comment,  int n_ClientNo)
        {
            try
            {
                MethodExecResult resultMethod = CEntityMaster.UploadDocument(
                                                            "D", n_CurrentClientDocNo, null, null, s_comment, -1, null, n_ClientNo, 'D', "", "", DateTime.Now);//

                return resultMethod;
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucDocUpload), Ex.Message);
                return null;
            }
        }

        public MethodExecResult GetUploadedDocumentImage(int n_CurrentClientDocNo, char s_EntityType, ref DataTable dt_Image)
        {

            MethodExecResult resultMethod = new MethodExecResult(-1);
            try
            {
                resultMethod = CEntityMaster.GetUploadedDocumentImage(n_CurrentClientDocNo, s_EntityType, ref  dt_Image); 
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucDocUpload), Ex.Message); 
            }
            return   resultMethod;
        }

        public MethodExecResult GetDocNo(int n_ClientNo, int nType, ref DataTable dt_DocNo) 
        {
            MethodExecResult resultMethod = new MethodExecResult(-1);
            try
            {
                resultMethod = CEntityMaster.GetDocNo(n_ClientNo, nType, ref dt_DocNo);
                
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucDocUpload), Ex.Message);
            }
            return resultMethod;
        }

        public MethodExecResult DeleteDocDetails(int n_ClientNo)
        {
             MethodExecResult resultMethod = new MethodExecResult(-1);
            try
            {
                resultMethod = CEntityMaster.DeleteDocDetails(n_ClientNo);
                
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucDocUpload), Ex.Message);
            }
            return resultMethod;
        }

        public MethodExecResult InsertUploadOption(int n_ClientNo, string UploadType)
        {
            MethodExecResult resultMethod = new MethodExecResult(-1);
            try
            {
                resultMethod = CEntityMaster.InsertUploadOption(n_ClientNo, UploadType);

            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CucDocUpload), Ex.Message);
            }
            return resultMethod;
        }
   
    }
}
