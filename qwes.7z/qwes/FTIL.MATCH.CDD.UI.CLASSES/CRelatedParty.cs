﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using UCC.Class;
using FTIL.Match.CDD.BAL;
using FTIL.Match.Common.Log;

namespace GetDetails
{
    class CRelatedParty
    {

        public void FillRelatedParty(int ClientId, ref DataTable dtResult, ref DataTable m_AddressDataTable)
        {
            try
            {
                CEntityMaster.GetAuthSignDetails(ClientId, ref dtResult, ref m_AddressDataTable);
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CRelatedParty), Ex.Message);
            }
        }

        public DataTable Type()
        {
            try
            {
                return CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.PROOFTYPE];
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CRelatedParty), Ex.Message);
                return null;
            }
        }

        public DataTable Relation(string EntityType)
        {
            try
            {
                DataTable l_dtCurrentRefData = null;
                DataRow[] dr = null;

                if (EntityType == CCMConstants.NON_INDIVIDUAL)
                    dr = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.RELATION].Select("s_ReferenceSubType = 'NONIND' OR s_ReferenceSubType = 'BOTH'");
                else
                    dr = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.RELATION].Select("s_ReferenceSubType = 'IND' OR s_ReferenceSubType = 'BOTH'");

                l_dtCurrentRefData = new DataTable();

                l_dtCurrentRefData.Columns.Add("n_ReferenceNo");
                l_dtCurrentRefData.Columns.Add("s_ReferenceType");
                l_dtCurrentRefData.Columns.Add("s_ReferenceCode");
                l_dtCurrentRefData.Columns.Add("s_ReferenceName");
                l_dtCurrentRefData.Columns.Add("s_ReferenceSubType");

                for (int iCnt = 0; iCnt <= dr.Length - 1; iCnt++)
                    l_dtCurrentRefData.ImportRow(dr[iCnt]);


                return l_dtCurrentRefData;
            }
            catch (Exception Ex)
            {
                Logger.Instance.WriteLog(typeof(CRelatedParty), Ex.Message);
                return null;
            }
        }
        
    }
}
