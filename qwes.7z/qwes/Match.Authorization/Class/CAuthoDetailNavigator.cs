using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;

namespace FTIL.Match.Authorization.Class
{
    /// <summary>
    /// Class for Maker/Checker functionality 
    /// </summary>
    public class CAuthoDetailNavigator
    {
        private ArrayList uniqueId;
        private int index;
        private DataTable dtSource;

        /// <summary>
        /// Data Source to be navigate
        /// </summary>
        public DataView NavigatedDataSource
        {
            get
            {
                dtSource.DefaultView.RowFilter = string.Format("EntityNo={0}", uniqueId[index]);
                dtSource.DefaultView.Sort = "Values desc";
                return dtSource.DefaultView;
            }
        }

        /// <summary>
        /// Is Previous record allowed to navigate
        /// </summary>
        public bool PreviousAllowed
        { get { return index > 0 && index < uniqueId.Count; } }


        /// <summary>
        /// If next record allowed to navigate
        /// </summary>
        public bool NextAllowed
        { get { return index < (uniqueId.Count - 1); } }


        /// <summary>
        /// Constructor : Will assign navigation datasource
        /// </summary>
        /// <param name="dtSource"></param>
        public CAuthoDetailNavigator(DataTable dtSource)
        {
            if(dtSource==null)
                throw new Exception("Navigator Data Source is null");
            else if (!dtSource.Columns.Contains("EntityNo"))
                throw new Exception("Navigator source requires a EntityNo column");

            this.dtSource = dtSource;
            this.uniqueId = new ArrayList();
            for (int i = 0; i < dtSource.Rows.Count; i++)
            {
                if (uniqueId.IndexOf(dtSource.Rows[i]["EntityNo"]) < 0)
                    uniqueId.Add(dtSource.Rows[i]["EntityNo"]);
            }
            index = 0;
        }

        /// <summary>
        /// Move to next record 
        /// </summary>
        public void Next()
        {
            if(this.NextAllowed)
                index++;
        }

        /// <summary>
        /// Move to previous record
        /// </summary>
        public void Previous()
        {
            if (this.PreviousAllowed)
                index--;
        }
    }
}
