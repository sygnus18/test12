using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using FTIL.Match.Common.Db;
using FTIL.Match.Common;

namespace FTIL.Match.Authorization.Class
{
    /// <summary>
    /// Class for Maker/Checker
    /// </summary>
    public class CAuthorization
    {
        #region Properties
        private int exNo;
        public int ExNo
        {
            get { return exNo; }
            set { exNo = value; }
        }

        private int authoFor;
        public int AuthoFor
        {
            get { return authoFor; }
            set { authoFor = value; }
        }

        private int authoUserNo;
        public int AuthoUserNo
        {
            get { return authoUserNo; }
            set { authoUserNo = value; }
        }

        private int entityNo;
        public int EntityNo
        {
            get { return entityNo; }
            set { entityNo = value; }
        }

        private string action;
        public string Action
        {
            get { return action; }
            set { action = value; }
        }

        private string remarks;
        public string Remarks
        {
            get { return remarks; }
            set { remarks = value; }
        }

        private int entityType;
        public int EntityType
        {
            get { return entityType; }
            set { entityType = value; }
        }

        private string duplicateCode;
        public string DuplicateCode
        {
            get { return duplicateCode; }
            set { duplicateCode = value; }
        }


        public string AuthorizeAll { get; set; }

        #endregion

        #region FillCombos
        public static DataTable FillAuthorizationList()
        {
            return GetDropDownLookUp("AUTH");
        }

        public static DataTable FillEntityType()
        {
            return GetDropDownLookUp("ENTITYTYPE");
        }
        #endregion

        #region Functions
        /// <summary>
        /// Get Authorization Pending records
        /// </summary>
        /// <param name="ExNo">NA</param>
        /// <param name="Id">EntityNo</param>
        /// <returns>DataSet Auth.Pending records</returns>
        public DataSet FetchData(int ExNo, int Id)
        {

             DbWorkItem l_objDbWorkItem = new DbWorkItem("sp_AuthorizationPending");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@Pn_AuthorizationFor", SqlDbType.VarChar, this.authoFor);

            l_objDbWorkItem.AddParameter("@Pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            l_objDbWorkItem.AddParameter("@Pn_EntityNo", SqlDbType.Int, Id);

            


            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                    throw new Exception("Lookup data not found.");
                else
                {
                    return l_dsReturnData;
                }
            }
            else
            {
                throw new Exception(l_objDbWorkItem.ExecutionStatus.ErrorMessage);
            }

        }

        /// <summary>
        /// Authorize the records
        /// </summary>
        public void Save()
        {

            DbWorkItem objdbwork = new DbWorkItem("sp_Authorization");
            objdbwork.ResultType = QueryType.DataSet;

            objdbwork.AddParameter("@Pn_EntityNo", SqlDbType.Int, this.entityNo);
            objdbwork.AddParameter("@Pn_AuthorizationFor", SqlDbType.Int, this.authoFor);
            objdbwork.AddParameter("@Ps_AuthorizeAll", SqlDbType.VarChar, "N");
            objdbwork.AddParameter("@Ps_Action", SqlDbType.VarChar, this.action);
            objdbwork.AddParameter("@Ps_Remarks", SqlDbType.VarChar, this.remarks);
            objdbwork.AddParameter("@Pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);
          

            DbManager.Instance.ExecuteDbTask(objdbwork);


            if (objdbwork.ExecutionStatus.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                throw new Exception(objdbwork.ExecutionStatus.ErrorMessage);
            }

        }

        
        /// <summary>
        /// Get DropDown data
        /// </summary>
        /// <param name="sLookupFor">Lookup key</param>
        /// <returns>DataTable to be bind with dropdown</returns>
        public static DataTable GetDropDownLookUp(string sLookupFor)
        {

            DataTable dtLookup = new DataTable();
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_CCMLookup");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@ps_For", SqlDbType.VarChar, sLookupFor);

            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                    throw new Exception("Lookup data not found.");
                else
                {
                    dtLookup = l_dsReturnData.Tables[0];
                    return dtLookup;
                }
            }
            else
            {
                return null;
            }

        }

        /// <summary>
        /// Check Maker/Checker is on or not
        /// </summary>
        /// <returns></returns>
        public bool IsMakerCheckerOn()
        {
            DataTable dt = GetDropDownLookUp("AUTH");

            DataRow[] dr = dt.Select("AuthoNo >" + 0); 

            return dr.Length > 0;
        }

        #endregion
    }
}
