using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using C1.Win.C1FlexGrid;
using FTIL.Match.Authorization.Class;

namespace FTIL.Match.Authorization.Forms
{
    /// <summary>
    /// Authorization main screen
    /// </summary>
    public partial class frmAuthorization : MatchCommon.UI.Forms.frmMatchBase
    {
        public CAuthorization authorization = new CAuthorization();
        public long TotalRecords = 0, CheckedAll = 0, TotalRemarks = 0, ARecords = 0, RRecords = 0, FlagLoading = 0;
        public int ComboSelectedIndex;
        private bool bFlag = false;
         int[] cols = new int[7];
        string sAuthorization = "";
        public frmAuthorization()
        {
            InitializeComponent();
            FillCombo();
            KeyPreview = true;
            c1FlexGridAuthorized.AutoResize = true;
            this.StartPosition = FormStartPosition.Manual;
            c1FlexGridAuthorized.KeyUp += c1FlexGridAuthorized_KeyUp;
            c1FlexGridAuthorized.KeyActionEnter = KeyActionEnum.None;
        }
        public frmAuthorization(bool bFilter)
        {
            InitializeComponent();
            bFlag = bFilter;
            FillCombo();
        }
        private void FillCombo()
        {
            DataRow dr;

            DataTable dt = CAuthorization.FillAuthorizationList();

            this.cboAuthorize.DataSource = dt;
            this.cboAuthorize.DisplayMember = dt.Columns[1].Caption.ToString();
            this.cboAuthorize.ValueMember = dt.Columns[0].Caption.ToString();
            this.cboAuthorize.SelectedIndex = 0;

            DataTable dt1 = CAuthorization.FillEntityType();
            dr = dt1.NewRow();
            dr[dt1.Columns[0].Caption.ToString()] = 0;
            dr[dt1.Columns[1].Caption.ToString()] = "";
            dt1.Rows.InsertAt(dr, 0);

            this.cboEntityType.DataSource = dt1;
            this.cboEntityType.DisplayMember = dt1.Columns[1].Caption.ToString();
            this.cboEntityType.ValueMember = dt1.Columns[0].Caption.ToString();
            this.cboEntityType.SelectedIndex = 0;

        }

        private void FrmAuthorization_Load(object sender, EventArgs e)
        {
            //this.WindowState = FormWindowState.Maximized;
        }

        private void tsBtnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cboAuthorize_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.cboAuthorize.SelectedIndex > 0)
            {
                this.authorization.AuthoFor = Convert.ToInt32(this.cboAuthorize.SelectedValue);
                if (this.authorization.AuthoFor == 101 || this.authorization.AuthoFor == 9 )
                {
                    this.cboEntityType.Visible = true;
                    this.lblEntityType.Visible = true;
                }
                else
                {
                    this.cboEntityType.Visible = false;
                    this.lblEntityType.Visible = false;
                }

                if (this.authorization.AuthoFor == 101 || this.authorization.AuthoFor == 9)
                {
                }
                else
                {
                    this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
                    this.pnAll.Enabled = true;
                    FillData();
                    this.Cursor = System.Windows.Forms.Cursors.Arrow;
                }
               
            }
            else
            {
                this.FlagLoading = 0;
                this.c1FlexGridAuthorized.DataSource = null;
                this.pnAll.Enabled = false;
                tsBtnClear_Click(sender, e);
                this.lblTotalUnAutho.Text = "0";
                this.lblTotalAutho.Text = "0";
                this.lblTotalReject.Text = "0";
                this.pnlAuthorize.Visible = false;
            }
        }

        private void FillData()
        {
            ComboSelectedIndex = 0;
            if (this.cboEntityType.Visible == true)
                this.authorization.EntityType = Convert.ToInt32(cboEntityType.SelectedValue);
            else
                this.authorization.EntityType = 0;
            DataSet ds = authorization.FetchData(0, 0);
            if (ds!=null)
            {
                DataTable dt = ds.Tables[0];
                this.c1FlexGridAuthorized.DataSource = dt;// authorization.FetchData(0, 0);
            }
            sAuthorization = cboAuthorize.Text.ToString();
                      
            ComboSelectedIndex = 1;
            if (this.c1FlexGridAuthorized.DataSource != null)
            {
                this.FlagLoading = 1;
                for (int ctr = 0; ctr < this.c1FlexGridAuthorized.Cols.Count; ctr++)
                {
                    this.c1FlexGridAuthorized.Cols[ctr].AllowEditing = false;
                }
                this.c1FlexGridAuthorized.Cols[0].DataType = typeof(bool);
                this.c1FlexGridAuthorized.Cols[0].AllowEditing = true;
                this.c1FlexGridAuthorized.Cols[0].Width = 70;
                this.c1FlexGridAuthorized.Cols[1].DataType = typeof(bool);
                this.c1FlexGridAuthorized.Cols[1].AllowEditing = true;
                this.c1FlexGridAuthorized.Cols[1].Width = 70;
                this.c1FlexGridAuthorized.Cols["Remarks"].AllowEditing = true;
                ColHide();
                TotalRecords = this.c1FlexGridAuthorized.Rows.Count - 1;
                this.lblTotalUnAutho.Text = TotalRecords.ToString();
                this.pnlAuthorize.Visible = true;
            }
            else
                this.FlagLoading = 0;
        }
        
   
        private void ColHide()
        {
            this.c1FlexGridAuthorized.Cols["EntityNo"].Visible = false;
            this.c1FlexGridAuthorized.Cols["Change Nature"].Visible = false;

        }

        private void chkAll_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkAll = sender as CheckBox;
            if (this.c1FlexGridAuthorized.DataSource == null || CheckedAll == 1)
            {
                return;
            }
            if (chkAll.Checked)
            {
                if (chkAll == chkAuthoAll)
                {
                    this.chkRejectAll.Checked = false;
                    this.lblTotalAutho.Text = TotalRecords.ToString();
                    this.lblTotalReject.Text = "0";
                    for (int ctr = 1; ctr < this.c1FlexGridAuthorized.Rows.Count; ctr++)
                    {
                        
                        this.c1FlexGridAuthorized[ctr, 1] = 0;
                        this.c1FlexGridAuthorized[ctr, 0] = 1;
                    }
                    this.ARecords = Convert.ToInt32(this.lblTotalAutho.Text);
                    this.RRecords = 0;
                }
                else if (chkAll == chkRejectAll)
                {
                    this.chkAuthoAll.Checked = false;
                    this.lblTotalAutho.Text = "0";
                    this.lblTotalReject.Text = TotalRecords.ToString();
                    for (int ctr = 1; ctr < this.c1FlexGridAuthorized.Rows.Count; ctr++)
                    {
                        this.c1FlexGridAuthorized[ctr, 0] = 0;
                        this.c1FlexGridAuthorized[ctr, 1] = 1;
                    }
                    this.ARecords =0;
                    this.RRecords = Convert.ToInt32(lblTotalReject.Text);
                }
            }
            else
            {
                this.lblTotalAutho.Text = "0";
                this.lblTotalReject.Text = "0";
                for (int ctr = 1; ctr < this.c1FlexGridAuthorized.Rows.Count; ctr++)
                {
                    this.c1FlexGridAuthorized[ctr, 0] = 0;
                    this.c1FlexGridAuthorized[ctr, 1] = 0;
                }
                this.ARecords = 0;
                this.RRecords = 0;
            }
         }

      
       
        private void chkBox_Enter(object sender, EventArgs e)
        {
            CheckBox chkBox = sender as CheckBox;
            if (chkBox == chkAuthoAll)
                chkBox.BackColor = Color.Blue;
            else if (chkBox == chkRejectAll)
                chkBox.BackColor = Color.Blue;
        }

        private void chkBox_Leave(object sender, EventArgs e)
        {
            CheckBox chkBox = sender as CheckBox;
            if (chkBox == chkAuthoAll)
                chkBox.BackColor = Color.White;
            else if (chkBox == chkRejectAll)
                chkBox.BackColor = Color.White;
        }

        private void tsBtnSave_Click(object sender, EventArgs e)
         {
            if (this.c1FlexGridAuthorized.Rows.Count <= 1)
            {
                return;
            }
            if (ARecords + RRecords == 0)
            {
                FlashMessage("Select a record for authorization!", this, false);
                return;
            }
            string Remarks = "";
            TotalRemarks = 0;
            if (this.c1FlexGridAuthorized.Cols["Remarks"].Index == this.c1FlexGridAuthorized.Col)
                this.c1FlexGridAuthorized.Select(this.c1FlexGridAuthorized.RowSel, this.c1FlexGridAuthorized.Col - 1);

            for (int ctr = 1; ctr < this.c1FlexGridAuthorized.Rows.Count; ctr++)
            {
                if (this.c1FlexGridAuthorized[ctr, "Remarks"].ToString() != "")
                    TotalRemarks++;
            }
            for (int ctr = 1; ctr < this.c1FlexGridAuthorized.Rows.Count; ctr++)
            {
                if (this.c1FlexGridAuthorized[ctr, "Remarks"].ToString().Length > 255)
                {
                    FlashMessage("Please enter remarks less than 255 characters.", this, false);
                    return;
                }
            }
            if (TotalRemarks < (ARecords + RRecords))
            {
                if (txtCommonRemarks.Text != "")
                    Remarks = txtCommonRemarks.Text;
                else
                {
                    FlashMessage("Please enter proper remarks.", this, false);
                    txtCommonRemarks.Focus();
                    return;
                }
            }

            if (MessageBox.Show("Are you sure you want to save the selected data? click on YES/NO.", "Authorization", MessageBoxButtons.YesNo, MessageBoxIcon.Information).ToString() == "No")
            {
                return;
            }
            this.Cursor = Cursors.WaitCursor;
            bool success = true;
            for (int ctr = 1; ctr < this.c1FlexGridAuthorized.Rows.Count; ctr++)
            {
                try
                {
                    if (Convert.ToInt32(this.c1FlexGridAuthorized[ctr, 0]) == 1 || Convert.ToInt32(this.c1FlexGridAuthorized[ctr, 1]) == 1)
                    {
                       // authorization.ExNo = Convert.ToInt32(this.c1FlexGridAuthorized[ctr, "ExNo"]);
                        authorization.EntityNo = Convert.ToInt32(this.c1FlexGridAuthorized[ctr, "EntityNo"]);
                        authorization.AuthoFor = Convert.ToInt32(this.cboAuthorize.SelectedValue);
                        authorization.Action = (Convert.ToInt32(this.c1FlexGridAuthorized[ctr, 0]) == 1) ? "A" : "R";
                        authorization.Remarks = (this.c1FlexGridAuthorized[ctr, "Remarks"].ToString() == "") ? Remarks : this.c1FlexGridAuthorized[ctr, "Remarks"].ToString();
                         authorization.Save();
                        if(!string.IsNullOrEmpty(authorization.DuplicateCode))
                        {
                            FlashMessage("Duplicate Code '" + authorization.DuplicateCode+"'", this, true);
                        }
                    }
                }
                
                catch (Exception ex)
                {
                    success = false;
                    MessageBox.Show(this,"Some error has occured while saving Authorization records.\r\n" + ex.Message, this.Text,MessageBoxButtons.OK,MessageBoxIcon.Error);
                    break;
                }
            }
            if (success)
            FlashMessage("Authorization Details saved successfully.", this, false);
            FillGrid();
          
            this.Cursor = Cursors.Arrow;
        }

        private void FillGrid()
        {
            int SelectedExIndex = 0;
            int SelectedEntityIndex = 0;
            SelectedExIndex = Convert.ToInt32(this.cboAuthorize.SelectedIndex);
            SelectedEntityIndex = Convert.ToInt32(this.cboEntityType.SelectedIndex);
            this.cboAuthorize.SelectedIndex = 0;
            this.cboAuthorize.SelectedIndex = SelectedExIndex;
            this.cboEntityType.SelectedIndex = SelectedEntityIndex;
            this.pnAll.Enabled = true;
            FillData();
        }

        private void c1FlexGridAuthorized_DoubleClick(object sender, EventArgs e)
        {
            if (this.c1FlexGridAuthorized.Rows.Count > 0)
            {
                int SelRow = this.c1FlexGridAuthorized.RowSel;
                int SelCol = this.c1FlexGridAuthorized.ColSel;
                if (this.c1FlexGridAuthorized.Cols["Remarks"].Index != SelCol && SelCol > 1)
                {
                    frmUnAuthorizedDetails unAuthoDetails = new frmUnAuthorizedDetails(this.authorization.FetchData(0, Convert.ToInt32(this.c1FlexGridAuthorized[SelRow, "EntityNo"])));
                    unAuthoDetails.ShowIcon = true;
                    unAuthoDetails.Icon = this.Icon;
                    unAuthoDetails.ShowDialog();
                    
                }
            }
        }


         private void c1FlexGridAuthorized_KeyUp(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Space)
                || (e.KeyCode == Keys.F2) || e.KeyCode == Keys.Enter)
            {
                if (c1FlexGridAuthorized.Row >= c1FlexGridAuthorized.Rows.Fixed)
                {
                    c1FlexGridAuthorized_Click(sender, e);
                }
             
                if (e.KeyCode == Keys.Enter)
                {
                    c1FlexGridAuthorized_DoubleClick(sender, e);
                }

            }
        }
      

        private void c1FlexGridAuthorized_Click(object sender, EventArgs e)
        {
            int SelRow = this.c1FlexGridAuthorized.RowSel;
            int SelCol = this.c1FlexGridAuthorized.ColSel;
            if ((SelCol == 0 || SelCol == 1) && this.FlagLoading == 1)
            {
                long LARecords = 0, LRRecords = 0;

                if (SelCol == 0 && SelRow >= 0)
                {
                    if (Convert.ToInt32(this.c1FlexGridAuthorized[SelRow, SelCol]) == 1)
                        this.c1FlexGridAuthorized[SelRow, 1] = 0;
                }
                else if (SelCol == 1 && SelRow >= 0)
                {
                    if (Convert.ToInt32(this.c1FlexGridAuthorized[SelRow, SelCol]) == 1)
                        this.c1FlexGridAuthorized[SelRow, 0] = 0;
                }
                for (int ctr = 1; ctr < this.c1FlexGridAuthorized.Rows.Count; ctr++)
                {
                    if (Convert.ToInt32(this.c1FlexGridAuthorized[ctr, 0]) == 1)
                    {
                        LARecords++;
                    }
                    if (Convert.ToInt32(this.c1FlexGridAuthorized[ctr, 1]) == 1)
                    {
                        LRRecords++;
                    }
                    if (Convert.ToInt32(this.c1FlexGridAuthorized[ctr, 0]) == 0 && Convert.ToInt32(this.c1FlexGridAuthorized[ctr, 1]) == 0)
                        if (ComboSelectedIndex != 0)
                            this.c1FlexGridAuthorized[ctr, "Remarks"] = "";

                }

                this.ARecords = LARecords;
                this.RRecords = LRRecords;
                CheckedAll = 1;
                this.chkAuthoAll.Checked = (ARecords == TotalRecords && ARecords != 0) ? true : false;
                this.lblTotalAutho.Text = ARecords.ToString();
                this.chkRejectAll.Checked = (RRecords == TotalRecords && RRecords != 0) ? true : false;
                this.lblTotalReject.Text = RRecords.ToString();

                CheckedAll = 0;
            }
            else
            {
                this.ARecords = Convert.ToInt32(this.lblTotalAutho.Text);
                this.RRecords = Convert.ToInt32(lblTotalReject.Text);

            }
        }

        private void tsBtnClear_Click(object sender, EventArgs e)
        {
            this.chkAuthoAll.Checked = false;
            this.chkRejectAll.Checked = false;
            this.txtCommonRemarks.Text = "";

            this.ARecords = 0;
            this.RRecords = 0;
            this.lblTotalAutho.Text = ARecords.ToString();
            this.lblTotalReject.Text = RRecords.ToString();

            for (int ctr = 1; ctr < this.c1FlexGridAuthorized.Rows.Count; ctr++)
            {
                if (this.c1FlexGridAuthorized.Cols.Contains("Remarks"))
                this.c1FlexGridAuthorized[ctr, "Remarks"] = null;
                this.c1FlexGridAuthorized[ctr, 0] = 0;
                this.c1FlexGridAuthorized[ctr, 1] = 0;
            }
        }

        private void tsBtnReset_Click(object sender, EventArgs e)
        {
            FillGrid();
        }

        private void cboEntityType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.cboEntityType.SelectedIndex > 0)
            {
                this.pnAll.Enabled = true;
                FillData();

            }
            else
            {
                this.FlagLoading = 0;
                this.c1FlexGridAuthorized.DataSource = null;
                this.pnAll.Enabled = false;
                tsBtnClear_Click(sender, e);
                this.lblTotalUnAutho.Text = "0";
                this.lblTotalAutho.Text = "0";
                this.lblTotalReject.Text = "0";
                this.pnlAuthorize.Visible = false;
            }
        }

        private  void FlashMessage(string Ps_PassingText, Form Pf_Form, Boolean Pb_Error)
        {
            Pf_Form.UseWaitCursor = false;
            if (Pb_Error == true)
            {
                MessageBox.Show(Ps_PassingText, Pf_Form.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show(Ps_PassingText, Pf_Form.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void frmAuthorization_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) this.Close();
        }

      

    }
}