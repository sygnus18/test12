namespace FTIL.Match.Authorization.Forms
{
    partial class frmAuthorization
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAuthorization));
            this.pnlAuthorize = new MatchCommon.CustomControls.FTPanel();
            this.c1FlexGridAuthorized = new MatchCommon.CustomControls.FTDataGrid();
            this.lblAutho = new MatchCommon.CustomControls.FTLabel();
            this.pnAll = new MatchCommon.CustomControls.FTPanel();
            this.lblTotalReject = new MatchCommon.CustomControls.FTLabel();
            this.lblTotalAutho = new MatchCommon.CustomControls.FTLabel();
            this.lblTotalUnAutho = new MatchCommon.CustomControls.FTLabel();
            this.label3 = new MatchCommon.CustomControls.FTLabel();
            this.label2 = new MatchCommon.CustomControls.FTLabel();
            this.label1 = new MatchCommon.CustomControls.FTLabel();
            this.chkRejectAll = new MatchCommon.CustomControls.FTCheckBox();
            this.lblRejectAll = new MatchCommon.CustomControls.FTLabel();
            this.txtCommonRemarks = new MatchCommon.CustomControls.FTTextBox();
            this.lblCommonRemarks = new MatchCommon.CustomControls.FTLabel();
            this.chkAuthoAll = new MatchCommon.CustomControls.FTCheckBox();
            this.lblAuthoAll = new MatchCommon.CustomControls.FTLabel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsBtnReset = new System.Windows.Forms.ToolStripButton();
            this.tsBtnClear = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsBtnSave = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsBtnClose = new System.Windows.Forms.ToolStripButton();
            this.panel1 = new MatchCommon.CustomControls.FTPanel();
            this.lblEntityType = new MatchCommon.CustomControls.FTLabel();
            this.cboEntityType = new MatchCommon.CustomControls.FTComboBox();
            this.lblAuthorize = new MatchCommon.CustomControls.FTLabel();
            this.cboAuthorize = new MatchCommon.CustomControls.FTComboBox();
            this.panelTop = new MatchCommon.CustomControls.FTPanel();
            this.lblDescription = new MatchCommon.CustomControls.FTLabel();
            this.lblTitle = new MatchCommon.CustomControls.FTLabel();
            this.pnlAuthorize.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c1FlexGridAuthorized)).BeginInit();
            this.pnAll.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlAuthorize
            // 
            this.pnlAuthorize.Controls.Add(this.c1FlexGridAuthorized);
            this.pnlAuthorize.Controls.Add(this.lblAutho);
            this.pnlAuthorize.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAuthorize.Location = new System.Drawing.Point(4, 228);
            this.pnlAuthorize.Name = "pnlAuthorize";
            this.pnlAuthorize.Size = new System.Drawing.Size(687, 256);
            this.pnlAuthorize.TabIndex = 3;
            this.pnlAuthorize.Visible = false;
            // 
            // c1FlexGridAuthorized
            // 
            this.c1FlexGridAuthorized.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
            this.c1FlexGridAuthorized.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
            this.c1FlexGridAuthorized.BackColor = System.Drawing.Color.White;
            this.c1FlexGridAuthorized.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.c1FlexGridAuthorized.ColumnInfo = resources.GetString("c1FlexGridAuthorized.ColumnInfo");
            this.c1FlexGridAuthorized.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1FlexGridAuthorized.EditOptions = C1.Win.C1FlexGrid.EditFlags.None;
            this.c1FlexGridAuthorized.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
            this.c1FlexGridAuthorized.Font = new System.Drawing.Font("Tahoma", 8F);
            this.c1FlexGridAuthorized.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.c1FlexGridAuthorized.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
            this.c1FlexGridAuthorized.Location = new System.Drawing.Point(0, 18);
            this.c1FlexGridAuthorized.Name = "c1FlexGridAuthorized";
            this.c1FlexGridAuthorized.OverrideDefault = false;
            this.c1FlexGridAuthorized.Rows.DefaultSize = 17;
            this.c1FlexGridAuthorized.RowsFilter.AddFilterRow = false;
            this.c1FlexGridAuthorized.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Cell;
            this.c1FlexGridAuthorized.Size = new System.Drawing.Size(687, 238);
            this.c1FlexGridAuthorized.StyleInfo = "";
            this.c1FlexGridAuthorized.TabIndex = 4;
            this.c1FlexGridAuthorized.Click += new System.EventHandler(this.c1FlexGridAuthorized_Click);
            this.c1FlexGridAuthorized.DoubleClick += new System.EventHandler(this.c1FlexGridAuthorized_DoubleClick);
            this.c1FlexGridAuthorized.AllowEditing = true;
            // 
            // lblAutho
            // 
            this.lblAutho.AllowForeColorChange = false;
            this.lblAutho.BackColor = System.Drawing.Color.LightGray;
            this.lblAutho.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblAutho.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblAutho.ForeColor = System.Drawing.Color.Black;
            this.lblAutho.Location = new System.Drawing.Point(0, 0);
            this.lblAutho.Name = "lblAutho";
            this.lblAutho.OverrideDefault = false;
            this.lblAutho.Size = new System.Drawing.Size(687, 18);
            this.lblAutho.TabIndex = 0;
            this.lblAutho.Text = "UnAuthorized Records";
            this.lblAutho.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnAll
            // 
            this.pnAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.pnAll.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnAll.Controls.Add(this.lblTotalReject);
            this.pnAll.Controls.Add(this.lblTotalAutho);
            this.pnAll.Controls.Add(this.lblTotalUnAutho);
            this.pnAll.Controls.Add(this.label3);
            this.pnAll.Controls.Add(this.label2);
            this.pnAll.Controls.Add(this.label1);
            this.pnAll.Controls.Add(this.chkRejectAll);
            this.pnAll.Controls.Add(this.lblRejectAll);
            this.pnAll.Controls.Add(this.txtCommonRemarks);
            this.pnAll.Controls.Add(this.lblCommonRemarks);
            this.pnAll.Controls.Add(this.chkAuthoAll);
            this.pnAll.Controls.Add(this.lblAuthoAll);
            this.pnAll.Controls.Add(this.toolStrip1);
            this.pnAll.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnAll.Location = new System.Drawing.Point(4, 80);
            this.pnAll.Name = "pnAll";
            this.pnAll.Size = new System.Drawing.Size(687, 148);
            this.pnAll.TabIndex = 2;
            // 
            // lblTotalReject
            // 
            this.lblTotalReject.AllowForeColorChange = false;
            this.lblTotalReject.AutoSize = true;
            this.lblTotalReject.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblTotalReject.ForeColor = System.Drawing.Color.Black;
            this.lblTotalReject.Location = new System.Drawing.Point(202, 105);
            this.lblTotalReject.Name = "lblTotalReject";
            this.lblTotalReject.OverrideDefault = false;
            this.lblTotalReject.Size = new System.Drawing.Size(13, 13);
            this.lblTotalReject.TabIndex = 12;
            this.lblTotalReject.Text = "0";
            // 
            // lblTotalAutho
            // 
            this.lblTotalAutho.AllowForeColorChange = false;
            this.lblTotalAutho.AutoSize = true;
            this.lblTotalAutho.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblTotalAutho.ForeColor = System.Drawing.Color.Black;
            this.lblTotalAutho.Location = new System.Drawing.Point(202, 89);
            this.lblTotalAutho.Name = "lblTotalAutho";
            this.lblTotalAutho.OverrideDefault = false;
            this.lblTotalAutho.Size = new System.Drawing.Size(13, 13);
            this.lblTotalAutho.TabIndex = 11;
            this.lblTotalAutho.Text = "0";
            // 
            // lblTotalUnAutho
            // 
            this.lblTotalUnAutho.AllowForeColorChange = false;
            this.lblTotalUnAutho.AutoSize = true;
            this.lblTotalUnAutho.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblTotalUnAutho.ForeColor = System.Drawing.Color.Black;
            this.lblTotalUnAutho.Location = new System.Drawing.Point(202, 73);
            this.lblTotalUnAutho.Name = "lblTotalUnAutho";
            this.lblTotalUnAutho.OverrideDefault = false;
            this.lblTotalUnAutho.Size = new System.Drawing.Size(13, 13);
            this.lblTotalUnAutho.TabIndex = 10;
            this.lblTotalUnAutho.Text = "0";
            // 
            // label3
            // 
            this.label3.AllowForeColorChange = false;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 8F);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(17, 105);
            this.label3.Name = "label3";
            this.label3.OverrideDefault = false;
            this.label3.Size = new System.Drawing.Size(138, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Total Records for Rejection";
            // 
            // label2
            // 
            this.label2.AllowForeColorChange = false;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 8F);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(17, 89);
            this.label2.Name = "label2";
            this.label2.OverrideDefault = false;
            this.label2.Size = new System.Drawing.Size(157, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Total Records for Authorization";
            // 
            // label1
            // 
            this.label1.AllowForeColorChange = false;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(17, 73);
            this.label1.Name = "label1";
            this.label1.OverrideDefault = false;
            this.label1.Size = new System.Drawing.Size(141, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Total UnAuthorized Records";
            // 
            // chkRejectAll
            // 
            this.chkRejectAll.AutoSize = true;
            this.chkRejectAll.ForeColor = System.Drawing.Color.Black;
            this.chkRejectAll.Location = new System.Drawing.Point(303, 12);
            this.chkRejectAll.Name = "chkRejectAll";
            this.chkRejectAll.Size = new System.Drawing.Size(15, 14);
            this.chkRejectAll.TabIndex = 1;
            this.chkRejectAll.UseVisualStyleBackColor = true;
            this.chkRejectAll.CheckedChanged += new System.EventHandler(this.chkAll_CheckedChanged);
            this.chkRejectAll.Enter += new System.EventHandler(this.chkBox_Enter);
            this.chkRejectAll.Leave += new System.EventHandler(this.chkBox_Leave);
            // 
            // lblRejectAll
            // 
            this.lblRejectAll.AllowForeColorChange = false;
            this.lblRejectAll.AutoSize = true;
            this.lblRejectAll.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblRejectAll.ForeColor = System.Drawing.Color.Black;
            this.lblRejectAll.Location = new System.Drawing.Point(202, 13);
            this.lblRejectAll.Name = "lblRejectAll";
            this.lblRejectAll.OverrideDefault = false;
            this.lblRejectAll.Size = new System.Drawing.Size(52, 13);
            this.lblRejectAll.TabIndex = 2;
            this.lblRejectAll.Text = "Reject All";
            // 
            // txtCommonRemarks
            // 
            this.txtCommonRemarks.AllowAlpha = true;
            this.txtCommonRemarks.AllowDot = true;
            this.txtCommonRemarks.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtCommonRemarks.AllowedCustomCharacters")));
            this.txtCommonRemarks.AllowNonASCII = false;
            this.txtCommonRemarks.AllowNumeric = true;
            this.txtCommonRemarks.AllowSpace = true;
            this.txtCommonRemarks.AllowSpecialChars = true;
            this.txtCommonRemarks.FocusColor = System.Drawing.Color.LightYellow;
            this.txtCommonRemarks.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtCommonRemarks.ForeColor = System.Drawing.Color.Black;
            this.txtCommonRemarks.IsEmailID = false;
            this.txtCommonRemarks.IsEmailIdValid = false;
            this.txtCommonRemarks.Location = new System.Drawing.Point(129, 33);
            this.txtCommonRemarks.MaxLength = 255;
            this.txtCommonRemarks.Name = "txtCommonRemarks";
            this.txtCommonRemarks.Size = new System.Drawing.Size(525, 20);
            this.txtCommonRemarks.TabIndex = 2;
            // 
            // lblCommonRemarks
            // 
            this.lblCommonRemarks.AllowForeColorChange = false;
            this.lblCommonRemarks.AutoSize = true;
            this.lblCommonRemarks.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblCommonRemarks.ForeColor = System.Drawing.Color.Black;
            this.lblCommonRemarks.Location = new System.Drawing.Point(17, 37);
            this.lblCommonRemarks.Name = "lblCommonRemarks";
            this.lblCommonRemarks.OverrideDefault = false;
            this.lblCommonRemarks.Size = new System.Drawing.Size(92, 13);
            this.lblCommonRemarks.TabIndex = 4;
            this.lblCommonRemarks.Text = "Common Remarks";
            // 
            // chkAuthoAll
            // 
            this.chkAuthoAll.AutoSize = true;
            this.chkAuthoAll.ForeColor = System.Drawing.Color.Black;
            this.chkAuthoAll.Location = new System.Drawing.Point(129, 12);
            this.chkAuthoAll.Name = "chkAuthoAll";
            this.chkAuthoAll.Size = new System.Drawing.Size(15, 14);
            this.chkAuthoAll.TabIndex = 0;
            this.chkAuthoAll.UseVisualStyleBackColor = true;
            this.chkAuthoAll.CheckedChanged += new System.EventHandler(this.chkAll_CheckedChanged);
            this.chkAuthoAll.Enter += new System.EventHandler(this.chkBox_Enter);
            this.chkAuthoAll.Leave += new System.EventHandler(this.chkBox_Leave);
            // 
            // lblAuthoAll
            // 
            this.lblAuthoAll.AllowForeColorChange = false;
            this.lblAuthoAll.AutoSize = true;
            this.lblAuthoAll.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblAuthoAll.ForeColor = System.Drawing.Color.Black;
            this.lblAuthoAll.Location = new System.Drawing.Point(17, 13);
            this.lblAuthoAll.Name = "lblAuthoAll";
            this.lblAuthoAll.OverrideDefault = false;
            this.lblAuthoAll.Size = new System.Drawing.Size(67, 13);
            this.lblAuthoAll.TabIndex = 0;
            this.lblAuthoAll.Text = "Authorize All";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsBtnReset,
            this.tsBtnClear,
            this.toolStripSeparator1,
            this.tsBtnSave,
            this.toolStripSeparator2,
            this.tsBtnClose});
            this.toolStrip1.Location = new System.Drawing.Point(0, 121);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(685, 25);
            this.toolStrip1.TabIndex = 3;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsBtnReset
            // 
            this.tsBtnReset.ImageTransparentColor = System.Drawing.Color.Black;
            this.tsBtnReset.Name = "tsBtnReset";
            this.tsBtnReset.Size = new System.Drawing.Size(50, 22);
            this.tsBtnReset.Text = "&Refresh";
            this.tsBtnReset.Click += new System.EventHandler(this.tsBtnReset_Click);
            // 
            // tsBtnClear
            // 
            this.tsBtnClear.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsBtnClear.Name = "tsBtnClear";
            this.tsBtnClear.Size = new System.Drawing.Size(67, 22);
            this.tsBtnClear.Text = "&Clear Filter";
            this.tsBtnClear.Click += new System.EventHandler(this.tsBtnClear_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // tsBtnSave
            // 
            this.tsBtnSave.ImageTransparentColor = System.Drawing.Color.Black;
            this.tsBtnSave.Name = "tsBtnSave";
            this.tsBtnSave.Size = new System.Drawing.Size(35, 22);
            this.tsBtnSave.Text = "&Save";
            this.tsBtnSave.Click += new System.EventHandler(this.tsBtnSave_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tsBtnClose
            // 
            this.tsBtnClose.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsBtnClose.Name = "tsBtnClose";
            this.tsBtnClose.Size = new System.Drawing.Size(40, 22);
            this.tsBtnClose.Text = "C&lose";
            this.tsBtnClose.Click += new System.EventHandler(this.tsBtnClose_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lblEntityType);
            this.panel1.Controls.Add(this.cboEntityType);
            this.panel1.Controls.Add(this.lblAuthorize);
            this.panel1.Controls.Add(this.cboAuthorize);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(4, 47);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(687, 33);
            this.panel1.TabIndex = 1;
            // 
            // lblEntityType
            // 
            this.lblEntityType.AllowForeColorChange = false;
            this.lblEntityType.AutoSize = true;
            this.lblEntityType.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblEntityType.ForeColor = System.Drawing.Color.Black;
            this.lblEntityType.Location = new System.Drawing.Point(383, 9);
            this.lblEntityType.Name = "lblEntityType";
            this.lblEntityType.OverrideDefault = false;
            this.lblEntityType.Size = new System.Drawing.Size(62, 13);
            this.lblEntityType.TabIndex = 2;
            this.lblEntityType.Text = "Entity Type";
            this.lblEntityType.Visible = false;
            // 
            // cboEntityType
            // 
            this.cboEntityType.BackColor = System.Drawing.Color.White;
            this.cboEntityType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboEntityType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboEntityType.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboEntityType.ForeColor = System.Drawing.Color.Black;
            this.cboEntityType.FormattingEnabled = true;
            this.cboEntityType.Location = new System.Drawing.Point(465, 6);
            this.cboEntityType.Name = "cboEntityType";
            this.cboEntityType.ReadOnly = false;
            this.cboEntityType.Size = new System.Drawing.Size(189, 21);
            this.cboEntityType.TabIndex = 2;
            this.cboEntityType.Visible = false;
            this.cboEntityType.SelectedIndexChanged += new System.EventHandler(this.cboEntityType_SelectedIndexChanged);
            // 
            // lblAuthorize
            // 
            this.lblAuthorize.AllowForeColorChange = false;
            this.lblAuthorize.AutoSize = true;
            this.lblAuthorize.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblAuthorize.ForeColor = System.Drawing.Color.Black;
            this.lblAuthorize.Location = new System.Drawing.Point(17, 9);
            this.lblAuthorize.Name = "lblAuthorize";
            this.lblAuthorize.OverrideDefault = false;
            this.lblAuthorize.Size = new System.Drawing.Size(90, 13);
            this.lblAuthorize.TabIndex = 0;
            this.lblAuthorize.Text = "Authorization For";
            // 
            // cboAuthorize
            // 
            this.cboAuthorize.BackColor = System.Drawing.Color.White;
            this.cboAuthorize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboAuthorize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboAuthorize.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboAuthorize.ForeColor = System.Drawing.Color.Black;
            this.cboAuthorize.FormattingEnabled = true;
            this.cboAuthorize.Location = new System.Drawing.Point(142, 6);
            this.cboAuthorize.Name = "cboAuthorize";
            this.cboAuthorize.ReadOnly = false;
            this.cboAuthorize.Size = new System.Drawing.Size(189, 21);
            this.cboAuthorize.TabIndex = 1;
            this.cboAuthorize.SelectedIndexChanged += new System.EventHandler(this.cboAuthorize_SelectedIndexChanged);
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.panelTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelTop.Controls.Add(this.lblDescription);
            this.panelTop.Controls.Add(this.lblTitle);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(4, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(687, 47);
            this.panelTop.TabIndex = 0;
            // 
            // lblDescription
            // 
            this.lblDescription.AllowForeColorChange = false;
            this.lblDescription.AutoSize = true;
            this.lblDescription.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblDescription.ForeColor = System.Drawing.Color.Black;
            this.lblDescription.Location = new System.Drawing.Point(17, 22);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.OverrideDefault = false;
            this.lblDescription.Size = new System.Drawing.Size(228, 13);
            this.lblDescription.TabIndex = 0;
            this.lblDescription.Text = "Use this screen to authorize or reject records.";
            // 
            // lblTitle
            // 
            this.lblTitle.AllowForeColorChange = false;
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblTitle.ForeColor = System.Drawing.Color.Black;
            this.lblTitle.Location = new System.Drawing.Point(17, 6);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.OverrideDefault = false;
            this.lblTitle.Size = new System.Drawing.Size(71, 13);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Authorization";
            // 
            // frmAuthorization
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(691, 484);
            this.Controls.Add(this.pnlAuthorize);
            this.Controls.Add(this.pnAll);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelTop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmAuthorization";
            this.Padding = new System.Windows.Forms.Padding(4, 0, 0, 0);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Authorization";
            this.Load += new System.EventHandler(this.FrmAuthorization_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmAuthorization_KeyUp);
            this.pnlAuthorize.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.c1FlexGridAuthorized)).EndInit();
            this.pnAll.ResumeLayout(false);
            this.pnAll.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MatchCommon.CustomControls.FTPanel panel1;
        private MatchCommon.CustomControls.FTPanel panelTop;
        protected MatchCommon.CustomControls.FTLabel lblDescription;
        protected MatchCommon.CustomControls.FTLabel lblTitle;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsBtnReset;
        private System.Windows.Forms.ToolStripButton tsBtnClear;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton tsBtnSave;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton tsBtnClose;
        private MatchCommon.CustomControls.FTLabel lblAuthorize;
        private MatchCommon.CustomControls.FTComboBox cboAuthorize;
        private MatchCommon.CustomControls.FTPanel pnlAuthorize;
        private MatchCommon.CustomControls.FTLabel lblAutho;
        private MatchCommon.CustomControls.FTDataGrid c1FlexGridAuthorized;
        private MatchCommon.CustomControls.FTPanel pnAll;
        private MatchCommon.CustomControls.FTTextBox txtCommonRemarks;
        private MatchCommon.CustomControls.FTLabel lblCommonRemarks;
        private MatchCommon.CustomControls.FTCheckBox chkAuthoAll;
        private MatchCommon.CustomControls.FTLabel lblAuthoAll;
        private MatchCommon.CustomControls.FTCheckBox chkRejectAll;
        private MatchCommon.CustomControls.FTLabel lblRejectAll;
        private MatchCommon.CustomControls.FTLabel lblTotalReject;
        private MatchCommon.CustomControls.FTLabel lblTotalAutho;
        private MatchCommon.CustomControls.FTLabel lblTotalUnAutho;
        private MatchCommon.CustomControls.FTLabel label3;
        private MatchCommon.CustomControls.FTLabel label2;
        private MatchCommon.CustomControls.FTLabel label1;
        private MatchCommon.CustomControls.FTLabel lblEntityType;
        private MatchCommon.CustomControls.FTComboBox cboEntityType;

    }
}