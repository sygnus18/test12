namespace FTIL.Match.Authorization.Forms
{
    partial class frmUnAuthorizedDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbUnAuthoDetails = new MatchCommon.CustomControls.FTGroupBox();
            this.tabChildEntities = new MatchCommon.CustomControls.FTTabControl();
            this.btnUserRights = new MatchCommon.CustomControls.FTButton();
            this.chShowAll = new MatchCommon.CustomControls.FTCheckBox();
            this.grbUnAuthoDetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbUnAuthoDetails
            // 
            this.grbUnAuthoDetails.Controls.Add(this.tabChildEntities);
            this.grbUnAuthoDetails.Font = new System.Drawing.Font("Tahoma", 8F);
            this.grbUnAuthoDetails.ForeColor = System.Drawing.Color.Black;
            this.grbUnAuthoDetails.Location = new System.Drawing.Point(0, 3);
            this.grbUnAuthoDetails.Name = "grbUnAuthoDetails";
            this.grbUnAuthoDetails.Size = new System.Drawing.Size(756, 536);
            this.grbUnAuthoDetails.TabIndex = 0;
            this.grbUnAuthoDetails.TabStop = false;
            this.grbUnAuthoDetails.Text = "UnAuthorized Details";
            // 
            // tabChildEntities
            // 
            this.tabChildEntities.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabChildEntities.Font = new System.Drawing.Font("Tahoma", 8F);
            this.tabChildEntities.Location = new System.Drawing.Point(3, 16);
            this.tabChildEntities.Name = "tabChildEntities";
            this.tabChildEntities.SelectedIndex = 0;
            this.tabChildEntities.Size = new System.Drawing.Size(750, 517);
            this.tabChildEntities.TabIndex = 1;
            // 
            // btnUserRights
            // 
            this.btnUserRights.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUserRights.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnUserRights.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnUserRights.Location = new System.Drawing.Point(596, 545);
            this.btnUserRights.Name = "btnUserRights";
            this.btnUserRights.Size = new System.Drawing.Size(94, 21);
            this.btnUserRights.TabIndex = 18;
            this.btnUserRights.Text = "&User Rights";
            this.btnUserRights.UseVisualStyleBackColor = true;
            this.btnUserRights.Click += new System.EventHandler(this.btnUserRights_Click);
            // 
            // chShowAll
            // 
            this.chShowAll.AutoSize = true;
            this.chShowAll.Font = new System.Drawing.Font("Tahoma", 8F);
            this.chShowAll.ForeColor = System.Drawing.Color.Black;
            this.chShowAll.Location = new System.Drawing.Point(5, 549);
            this.chShowAll.Name = "chShowAll";
            this.chShowAll.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.chShowAll.Size = new System.Drawing.Size(66, 17);
            this.chShowAll.TabIndex = 98;
            this.chShowAll.Text = "Show All";
            this.chShowAll.UseVisualStyleBackColor = true;
            this.chShowAll.CheckedChanged += new System.EventHandler(this.chPanExempt_CheckedChanged);
            // 
            // frmUnAuthorizedDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(756, 569);
            this.Controls.Add(this.chShowAll);
            this.Controls.Add(this.btnUserRights);
            this.Controls.Add(this.grbUnAuthoDetails);
            this.MaximizeBox = false;
            this.Name = "frmUnAuthorizedDetails";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Authorization";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.FrmUnAuthorizedDetails_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmUnAuthorizedDetails_KeyUp);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.grbUnAuthoDetails.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

           
            this.ResumeLayout(false);



        }

        #endregion

        private MatchCommon.CustomControls.FTGroupBox grbUnAuthoDetails;
        private MatchCommon.CustomControls.FTButton btnUserRights;
        private MatchCommon.CustomControls.FTTabControl tabChildEntities;
        private MatchCommon.CustomControls.FTCheckBox chShowAll;
    }
}