﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;
using UCC.Class;
using UCC.Class.KRA;
using UCC.Class.Master;
using C1.Win.C1FlexGrid;


namespace UCC.Forms.KRA
{
    public partial class frmKRADownload : Form
    {

        #region Variable declaration

        /// <summary>
        /// Indicates if valid client code is set in ClientCode text box
        /// If not, opens Help window on ClientCode text box leave event if text box text is not empty.
        /// </summary>
        private bool m_bValidClientValueSet;

        /// <summary>
        /// Client filter BL class instance
        /// </summary>
        private CClientFilter m_objClientFilter;

        #endregion Variable declaration

        #region Constructor
        public frmKRADownload()
        {
            InitializeComponent();
            m_objClientFilter = new CClientFilter();
        }
        #endregion Constructor

        #region Events

        #region frmKRADownload_Load
        private void frmKRADownload_Load(object sender, EventArgs e)
        {
            PopulateLookUp();

            cboExportType.Enabled = false;
            txtBatchNo.Enabled = false;
        }
        #endregion frmKRADownload_Load

        #region btnExport_Click
        private void btnExport_Click(object sender, EventArgs e)
        {
            if (dtpFromDate.Value.Date > dtpToDate.Value.Date)
            {
                MessageBox.Show("From date cannot be greater than To date.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                dtpFromDate.Focus();
                return;
            }

            if (Convert.ToInt16(cboKRAAgency.SelectedValue) == 0)
            {
                MessageBox.Show("Please select KRA Agency.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                cboKRAAgency.Focus();
                return;
            }

            KRAFilters filter = new KRAFilters();
            
            filter.KRAAgency = (KRAAgencyEnum)Convert.ToInt32(cboKRAAgency.SelectedValue);

            if (!string.IsNullOrEmpty(txtBatchNo.Text.Trim()))
                filter.BatchNo = Convert.ToInt32(txtBatchNo.Text.Trim());


            if (!string.IsNullOrEmpty(txtClientCode.Text.Trim()))
                filter.ClientCode = txtClientCode.Text.Trim();

            filter.FromDate = dtpFromDate.Value.Date;
            filter.ToDate = dtpToDate.Value.Date;

         
            string l_sFilePath = txtFilePath.Text.Trim();

            if (System.IO.Directory.Exists(l_sFilePath) == false || string.IsNullOrEmpty(l_sFilePath))
            {
                MessageBox.Show("Please select download path.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                ftBrowse.Focus();
            }
            else
            {
                bool b_HasErrorsOccured = false;

                if (!l_sFilePath.EndsWith(@"\"))
                    l_sFilePath = l_sFilePath + @"\";

                List<CClient> l_ClientsForKRA = GetClientsForKRA(filter);

                if (l_ClientsForKRA != null)
                {
                    KRAExportManager objKRAExport = new KRAExportManager(l_ClientsForKRA);

                    DataTable l_dtKRAValidationResult = objKRAExport.ProcessKRAClient(filter.KRAAgency);

                    if (l_dtKRAValidationResult != null)
                    {
                        if (l_dtKRAValidationResult.Rows.Count > 0)
                            b_HasErrorsOccured = true;
                    }

                    MethodExecResult result = objKRAExport.ExportKRA(l_sFilePath);

                    DialogResult dialogResult = System.Windows.Forms.DialogResult.None;

                    dialogResult = MessageBox.Show(result.DetailedErrorMessage, this.Text, MessageBoxButtons.OK,
                            result.ReturnCode == MethodExecResult.SuccessfulReturnCode ? MessageBoxIcon.Information
                            : MessageBoxIcon.Error
                            );

                    if (dialogResult == System.Windows.Forms.DialogResult.OK && (b_HasErrorsOccured || result.ReturnCode != MethodExecResult.SuccessfulReturnCode))
                        ShowErrorWindow(l_dtKRAValidationResult, filter.KRAAgency);

                }
            }
        }
        #endregion btnExport_Click

        #region btnClose_Click
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion

        #region ftBrowse_Click
        private void ftBrowse_Click(object sender, EventArgs e)
        {
            DialogResult result = this.fbdKRADestinationPath.ShowDialog();
         
            if (result == System.Windows.Forms.DialogResult.OK)
                this.txtFilePath.Text = this.fbdKRADestinationPath.SelectedPath;
        }
        #endregion

        #region txtClientCode_TextChanged
        /// <summary>
        /// Client code text box text change event handler.
        /// Sets m_bValidClientValueSet to false.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        private void txtClientCode_TextChanged(object sender, EventArgs e)
        {
            m_bValidClientValueSet = false;
        }
        #endregion

        #region txtClientCode_KeyUp
        /// <summary>
        /// Client Code text box Key Up Event handler.
        /// Opens help window if F3 key is pressed.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        private void txtClientCode_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtClientCode.ReadOnly)
                return;

            if (e.KeyCode == Keys.F3)
                ShowClientHelp(txtClientCode.Text);
        }
        #endregion

        #region txtClientCode_Leave
        /// <summary>
        /// Client code text box leave event handler.
        /// If valid client set flag is False, opens client help window populating records as per client code textbox text.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        private void txtClientCode_Leave(object sender, EventArgs e)
        {
            if (txtClientCode.ReadOnly || (txtClientCode.Enabled == false))
                return;

            if (txtClientCode.Text.Trim().Length == 0)
                return;

            if (m_bValidClientValueSet == false)
                ShowClientHelp(txtClientCode.Text.Trim());
        }
        #endregion

        #endregion Events

        #region Methods

        #region PopulateLookUp
        /// <summary>
        /// Populates help (combo) controls with master values
        /// </summary>
        private void PopulateLookUp()
        {
            DataSet l_ViewData = new DataSet();

            //To be removed and taken from CMastersDataProvider
            MethodExecResult l_objMethodExceResult = m_objClientFilter.GetUCCClientFilterLookUpData(ref l_ViewData);
            if (l_objMethodExceResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, l_objMethodExceResult);
                MessageBox.Show(l_objMethodExceResult.ErrorMessage, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DataTable dt = Utility.GetDataTableFromEnum<KRAAgencyEnum>(true, "-- SELECT --", 0);
            cboKRAAgency.DisplayMember = "ENumName";
            cboKRAAgency.ValueMember = "EnumValue";
            cboKRAAgency.DataSource = dt;

        }
        #endregion

        #region GetClientsForKRA
        /// <summary>
        /// Retrieves client details from database applying filters.
        /// </summary>
        /// <param name="filters">Filter values</param>
        /// <returns>Collection of all applicable clients</returns>
        private List<CClient> GetClientsForKRA(KRAFilters filter)
        {
            List<CClient> l_Clients = null;

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCRetrieveKRAClientData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@ps_ClientCode", SqlDbType.VarChar, filter.ClientCode);
            l_objDbWorkItem.AddParameter("@pdt_FromDate", SqlDbType.DateTime, filter.FromDate);
            l_objDbWorkItem.AddParameter("@pdt_ToDate", SqlDbType.DateTime, filter.ToDate);
            l_objDbWorkItem.AddParameter("@pn_Exchange", SqlDbType.Int, filter.Exchange);
            l_objDbWorkItem.AddParameter("@pn_BatchNo", SqlDbType.SmallInt, filter.BatchNo);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);


            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0) || (l_dsReturnData.Tables[0].Rows.Count == 0))
                {
                    Logger.Instance.WriteLog(this, "Initalizing KRA Clients. No data found. Client: ");
                    MessageBox.Show("No client details found", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    l_Clients = new List<CClient>();

                    //First DataTable contains client Data
                    DataTable dtClients = l_dsReturnData.Tables[0];

                    //Second DataTable contains client Data
                    DataTable dtClientsAddress = l_dsReturnData.Tables[1];


                    //KYC addtional details
                    DataTable dtClientAddtionalDetails = l_dsReturnData.Tables[2];


                    for (int i = 0; i < dtClients.Rows.Count; i++)
                    {
                        CClient client = new CClient(Convert.ToInt32(dtClients.Rows[i]["n_ClientNo"].ToString()), false);
                        client.InitializeFromDataRow(dtClients.Rows[i]);
                        //Populate Address collection for the Client
                        client.SetClientAddressesFromDataTable(dtClientsAddress);

                        //Set KYC addtional detail (IPV etc.) 
                        client.SetAdditionalDetailsFromDataTable(dtClientAddtionalDetails);

                        l_Clients.Add(client);
                    }
                }
            }
            else
            {
                Logger.Instance.WriteLog(this, l_objDbWorkItem.ExecutionStatus);
                throw new ApplicationException(l_objDbWorkItem.ExecutionStatus.ErrorMessage, l_objDbWorkItem.ExecutionStatus.ExceptionObject);
            }

            return l_Clients;

        }
        #endregion

        #region ShowErrorWindow
        private void ShowErrorWindow(DataTable dt, KRAAgencyEnum kraAgency)
        {
            dt = Utility.GetDistinctRecords(dt);

            UCC.Forms.frmDisplayRecordset validationScreen = new Forms.frmDisplayRecordset();
            validationScreen.DataTitle = "KRA Download Error details";
            validationScreen.InputData = dt;
            validationScreen.WindowTitle = "KRA Download for " + Enum.GetName(typeof(KRAAgencyEnum), kraAgency);
            validationScreen.Icon = this.Icon;

            validationScreen.DisplayColumns.Add("ClientCode", "Client Code");
            validationScreen.DisplayColumns.Add("FieldName", "Column Name");
            validationScreen.DisplayColumns.Add("Error", "Error Detail");

            validationScreen.OnGridDoubleClick += new EventHandler(this.dgvClient_DoubleClick);

            validationScreen.ShowDialog();

        }
        #endregion
        
        #region ShowClientHelp
        /// <summary>
        /// Opens client help window populating records as per given client code
        /// </summary>
        /// <param name="p_vsClientCode">Filter client code</param>
        /// <returns>Success/return code. 0 = Successful</returns>
        private long ShowClientHelp(string p_vsClientCode)
        {
            frmSearch l_objSearch = new frmSearch();
            l_objSearch.SearchTypeCurrent = frmSearch.SearchType.Client;
            l_objSearch.SearchValueCurrent = frmSearch.SearchValue.ClientCode;
            l_objSearch.SearchText = txtClientCode.Text;
            l_objSearch.Icon = this.Icon;

            if (l_objSearch.ShowDialog() == DialogResult.OK)
            {
                m_bValidClientValueSet = true;
                txtClientCode.Text = l_objSearch.SelectedCode;
            }
            else
            {
                txtClientCode.Text = string.Empty;
            }

            return 0;
        }
        #endregion


        #region dgvClient_DoubleClick
        
        /// <summary>
        /// Event to open client registration window on click on error row 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvClient_DoubleClick(object sender, EventArgs e)
        {
            DataGridView dgv = (DataGridView)sender;
            DataGridViewRow l_objRow = null;

            if (dgv.SelectedRows.Count != 1)
            {
                MessageBox.Show("Select Single Record for Modification", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            l_objRow = dgv.SelectedRows[0];
            if (l_objRow == null)
            {
                return;
            }
            CClient l_objClient = null;
            try
            {
                string sClientCode = l_objRow.Cells[0].Value.ToString(); 
                l_objClient = new CClient(sClientCode);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return ;
            }
            frmUCCClientInfo l_objfrmUCCClientInfo = new frmUCCClientInfo(l_objClient);
            l_objfrmUCCClientInfo.StartPosition = FormStartPosition.CenterScreen;
            l_objfrmUCCClientInfo.Icon = this.Icon;
            l_objfrmUCCClientInfo.ShowDialog();
        }

        #endregion

        #endregion Methods

    }
}
