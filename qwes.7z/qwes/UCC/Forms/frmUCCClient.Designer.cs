﻿   namespace UCC.Forms
{
    partial class frmUCCClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmUCCClient));
            this.pnlInfo = new MatchCommon.CustomControls.FTPanel();
            this.lblArrow = new MatchCommon.CustomControls.FTLabel();
            this.lblDetails = new MatchCommon.CustomControls.FTLabel();
            this.lblInfo = new MatchCommon.CustomControls.FTLabel();
            this.pnlClient = new MatchCommon.CustomControls.FTPanel();
            this.dgvClient = new MatchCommon.CustomControls.FTDataGrid();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.lblNoOfRecords = new MatchCommon.CustomControls.FTLabel();
            this.btnUploadResponse = new System.Windows.Forms.Button();
            this.picProcessRunning = new System.Windows.Forms.PictureBox();
            this.btnExport = new System.Windows.Forms.Button();
            this.btnImport = new System.Windows.Forms.Button();
            this.menuUCCClient = new MatchCommon.CustomControls.FTMasterMenuStrip();
            this.pnlInfo.SuspendLayout();
            this.pnlClient.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClient)).BeginInit();
            this.pnlTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picProcessRunning)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlInfo
            // 
            this.pnlInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(234)))), ((int)(((byte)(234)))));
            this.pnlInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlInfo.Controls.Add(this.lblArrow);
            this.pnlInfo.Controls.Add(this.lblDetails);
            this.pnlInfo.Controls.Add(this.lblInfo);
            this.pnlInfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlInfo.Location = new System.Drawing.Point(31, 0);
            this.pnlInfo.Name = "pnlInfo";
            this.pnlInfo.Size = new System.Drawing.Size(791, 18);
            this.pnlInfo.TabIndex = 11;
            this.pnlInfo.TabStop = true;
            // 
            // lblArrow
            // 
            this.lblArrow.AllowForeColorChange = false;
            this.lblArrow.AutoSize = true;
            this.lblArrow.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblArrow.ForeColor = System.Drawing.Color.Black;
            this.lblArrow.Location = new System.Drawing.Point(65, 2);
            this.lblArrow.Name = "lblArrow";
            this.lblArrow.OverrideDefault = false;
            this.lblArrow.Size = new System.Drawing.Size(23, 13);
            this.lblArrow.TabIndex = 2;
            this.lblArrow.Text = ">>";
            // 
            // lblDetails
            // 
            this.lblDetails.AllowForeColorChange = false;
            this.lblDetails.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDetails.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblDetails.ForeColor = System.Drawing.Color.Black;
            this.lblDetails.Location = new System.Drawing.Point(91, 2);
            this.lblDetails.Name = "lblDetails";
            this.lblDetails.OverrideDefault = false;
            this.lblDetails.Size = new System.Drawing.Size(525, 12);
            this.lblDetails.TabIndex = 1;
            this.lblDetails.Text = "This screen facilitates entering UCC Client Info.";
            // 
            // lblInfo
            // 
            this.lblInfo.AllowForeColorChange = false;
            this.lblInfo.AutoSize = true;
            this.lblInfo.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblInfo.ForeColor = System.Drawing.Color.Black;
            this.lblInfo.Location = new System.Drawing.Point(4, 2);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.OverrideDefault = false;
            this.lblInfo.Size = new System.Drawing.Size(58, 13);
            this.lblInfo.TabIndex = 0;
            this.lblInfo.Text = "UCC Client";
            // 
            // pnlClient
            // 
            this.pnlClient.BackColor = System.Drawing.Color.Transparent;
            this.pnlClient.Controls.Add(this.dgvClient);
            this.pnlClient.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlClient.Location = new System.Drawing.Point(31, 18);
            this.pnlClient.Name = "pnlClient";
            this.pnlClient.Size = new System.Drawing.Size(791, 484);
            this.pnlClient.TabIndex = 12;
            // 
            // dgvClient
            // 
            this.dgvClient.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
            this.dgvClient.AllowEditing = false;
            this.dgvClient.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
            this.dgvClient.BackColor = System.Drawing.Color.Transparent;
            this.dgvClient.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.dgvClient.ColumnInfo = "10,1,0,0,0,85,Columns:0{Width:30;}\t";
            this.dgvClient.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvClient.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
            this.dgvClient.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dgvClient.ForeColor = System.Drawing.Color.Black;
            this.dgvClient.KeyActionEnter = C1.Win.C1FlexGrid.KeyActionEnum.None;
            this.dgvClient.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
            this.dgvClient.Location = new System.Drawing.Point(0, 0);
            this.dgvClient.Name = "dgvClient";
            this.dgvClient.OverrideDefault = false;
            this.dgvClient.Rows.Count = 1;
            this.dgvClient.Rows.DefaultSize = 17;
            this.dgvClient.Rows.MinSize = 25;
            this.dgvClient.RowsFilter.AddFilterRow = false;
            this.dgvClient.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.ListBox;
            this.dgvClient.Size = new System.Drawing.Size(791, 484);
            this.dgvClient.StyleInfo = "";
            this.dgvClient.TabIndex = 0;
            this.dgvClient.DoubleClick += new System.EventHandler(this.dgvClient_DoubleClick);
            this.dgvClient.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvClient_KeyUp);
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.Transparent;
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.lblNoOfRecords);
            this.pnlTop.Controls.Add(this.btnUploadResponse);
            this.pnlTop.Controls.Add(this.picProcessRunning);
            this.pnlTop.Controls.Add(this.btnExport);
            this.pnlTop.Controls.Add(this.btnImport);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlTop.Location = new System.Drawing.Point(31, 502);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(791, 30);
            this.pnlTop.TabIndex = 6;
            // 
            // lblNoOfRecords
            // 
            this.lblNoOfRecords.AllowForeColorChange = false;
            this.lblNoOfRecords.AutoSize = true;
            this.lblNoOfRecords.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblNoOfRecords.ForeColor = System.Drawing.Color.Black;
            this.lblNoOfRecords.Location = new System.Drawing.Point(4, 8);
            this.lblNoOfRecords.Name = "lblNoOfRecords";
            this.lblNoOfRecords.OverrideDefault = false;
            this.lblNoOfRecords.Size = new System.Drawing.Size(77, 13);
            this.lblNoOfRecords.TabIndex = 4;
            this.lblNoOfRecords.Text = "No Of Records";
            // 
            // btnUploadResponse
            // 
            this.btnUploadResponse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUploadResponse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUploadResponse.Location = new System.Drawing.Point(662, 3);
            this.btnUploadResponse.Name = "btnUploadResponse";
            this.btnUploadResponse.Size = new System.Drawing.Size(111, 23);
            this.btnUploadResponse.TabIndex = 3;
            this.btnUploadResponse.Text = "&Upload Response";
            this.btnUploadResponse.UseVisualStyleBackColor = true;
            this.btnUploadResponse.Click += new System.EventHandler(this.btnUploadResponse_Click);
            // 
            // picProcessRunning
            // 
            this.picProcessRunning.Image = global::UCC.Properties.Resources.Progress;
            this.picProcessRunning.Location = new System.Drawing.Point(309, -1);
            this.picProcessRunning.Name = "picProcessRunning";
            this.picProcessRunning.Size = new System.Drawing.Size(31, 31);
            this.picProcessRunning.TabIndex = 2;
            this.picProcessRunning.TabStop = false;
            // 
            // btnExport
            // 
            this.btnExport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExport.Image = ((System.Drawing.Image)(resources.GetObject("btnExport.Image")));
            this.btnExport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExport.Location = new System.Drawing.Point(574, 3);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(80, 23);
            this.btnExport.TabIndex = 1;
            this.btnExport.Text = "&Export";
            this.btnExport.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // btnImport
            // 
            this.btnImport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnImport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnImport.Image = ((System.Drawing.Image)(resources.GetObject("btnImport.Image")));
            this.btnImport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnImport.Location = new System.Drawing.Point(481, 3);
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(85, 23);
            this.btnImport.TabIndex = 0;
            this.btnImport.Text = "BO &Import";
            this.btnImport.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnImport.UseVisualStyleBackColor = true;
            this.btnImport.Click += new System.EventHandler(this.btnImport_Click);
            // 
            // menuUCCClient
            // 
            this.menuUCCClient.AutoSize = false;
            this.menuUCCClient.BackColor = System.Drawing.SystemColors.Window;
            this.menuUCCClient.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("menuUCCClient.BackgroundImage")));
            this.menuUCCClient.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.menuUCCClient.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuUCCClient.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.menuUCCClient.Location = new System.Drawing.Point(0, 0);
            this.menuUCCClient.Name = "menuUCCClient";
            this.menuUCCClient.ShowItemToolTips = true;
            this.menuUCCClient.Size = new System.Drawing.Size(31, 532);
            this.menuUCCClient.TabIndex = 0;
            this.menuUCCClient.Text = "menuStrip1";
            // 
            // frmUCCClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(822, 532);
            this.Controls.Add(this.pnlClient);
            this.Controls.Add(this.pnlTop);
            this.Controls.Add(this.pnlInfo);
            this.Controls.Add(this.menuUCCClient);
            this.Name = "frmUCCClient";
            this.ShowInTaskbar = false;
            this.Text = "UCC Client";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.UCCClient_Load);
            this.Shown += new System.EventHandler(this.UCCClient_Shown);
            this.pnlInfo.ResumeLayout(false);
            this.pnlInfo.PerformLayout();
            this.pnlClient.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvClient)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picProcessRunning)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MatchCommon.CustomControls.FTMasterMenuStrip menuUCCClient;
        private MatchCommon.CustomControls.FTTopicBar tbUCCClient;
        private MatchCommon.CustomControls.FTPanel pnlInfo;
        private MatchCommon.CustomControls.FTLabel lblArrow;
        private MatchCommon.CustomControls.FTLabel lblDetails;
        private MatchCommon.CustomControls.FTLabel lblInfo;
        private MatchCommon.CustomControls.FTPanel pnlClient;
        private MatchCommon.CustomControls.FTDataGrid dgvClient;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Button btnImport;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.PictureBox picProcessRunning;
        private System.Windows.Forms.Button btnUploadResponse;
        private MatchCommon.CustomControls.FTLabel lblNoOfRecords;
    }
}