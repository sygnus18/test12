﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using UCC.Class;
using C1.Win.C1FlexGrid;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;
using MatchCommon;

namespace UCC.Forms
{
    public partial class frmSearch : Form
    {
        #region Types

        /// <summary>
        /// Search Type
        /// </summary>
        #region SearchType (enum)
        public enum SearchType
        {
            Client,
            Branch,
            G3,
            DP,
            Bank
        }
        #endregion

        /// <summary>
        /// Search Field
        /// </summary>
        #region SearchValue (enum)
        public enum SearchValue
        {
            ClientCode,
            ClientName,
            BranchCode,
            BranchName,
            G3Code,
            G3Name,
            DPCode,
            BankCode
        }
        #endregion

        #endregion

        #region Variables

        /// <summary>
        /// Search data
        /// </summary>
        private DataTable m_dtSearchData;
        
        /// <summary>
        /// Search data visible column caption
        /// </summary>
        private DataTable m_dtSearchDataVisibleCols;
        
        /// <summary>
        /// Search type variable
        /// </summary>
        private SearchType m_objSearchType;

        /// <summary>
        /// Seach BL class instance
        /// </summary>
        private CSearch l_objSearch;

        /// <summary>
        /// Selected record code
        /// </summary>
        private string m_sSelectedCode = string.Empty;

        /// <summary>
        /// Selected record name
        /// </summary>
        private string m_sSelectedName = string.Empty;

        /// <summary>
        /// Selected record unique column value
        /// </summary>
        private string m_sSelectedUniqueValue = string.Empty;

        /// <summary>
        /// Search filter value
        /// </summary>
        private string m_sSearchText = string.Empty;

        /// <summary>
        /// Seach Value
        /// </summary>
        private SearchValue m_objSearchValue;

        /// <summary>
        /// Code column name in help data DataTable
        /// </summary>
        private string m_sCodeColumn;

        /// <summary>
        /// Name column name in help data DataTable
        /// </summary>
        private string m_sNameColumn;

        /// <summary>
        /// Unique ID column
        /// </summary>
        private string m_sUniqueColName;

        /// <summary>
        /// Name of Bank Branch in help data DataTable
        /// </summary>
        private string m_sBranchColumn;

        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        #region Constructor
        public frmSearch()
        {
            InitializeComponent();

            dgvSearchGrid.OverrideDefault = true;
            dgvSearchGrid.Styles.Normal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dgvSearchGrid.Styles.Alternate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);

            m_dtSearchData = new DataTable();
            l_objSearch = new CSearch();
        } 
        #endregion

        #region Events

        /// <summary>
        /// Window load event handler. Initializes controls.
        /// Retrieves data applying search text filter.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region frmSearch_Load
        private void frmSearch_Load(object sender, EventArgs e)
        {
            //this.DialogResult = DialogResult.Cancel;
            txtSearch.Text = SearchText;
            PopulateGrid();
        } 
        #endregion

        /// <summary>
        /// Window shown event handler.
        /// Sets focus on grid.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region frmSearch_Shown
        private void frmSearch_Shown(object sender, System.EventArgs e)
        {
            dgvSearchGrid.Focus();
        }
        #endregion

        /// <summary>
        /// Retrieves records for specified search type applying search text filter.
        /// If only one record found, sets same as selected and closes window.
        /// </summary>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region PopulateGrid
        private long PopulateGrid()
        {
            Clear();

            ArrayList l_SearchFilter = new ArrayList();
            l_SearchFilter.Add(SearchTypeCurrent.ToString());
            l_SearchFilter.Add(txtSearch.Text.Trim());
            l_SearchFilter.Add(SearchValueCurrent.ToString());

            DataSet l_dsHelpData = new DataSet();
            string l_sErrorMsg = string.Empty;
            MethodExecResult l_objMethodExceResult = l_objSearch.GetUCCSearchData(l_SearchFilter, ref l_dsHelpData);

            if (l_objMethodExceResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                MessageBox.Show(l_objMethodExceResult.ErrorMessage, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                Logger.Instance.WriteLog(this, l_objMethodExceResult);
                return -1;

            }

            if (l_dsHelpData.Tables.Count > 0)
                m_dtSearchData = l_dsHelpData.Tables[0];
            if (l_dsHelpData.Tables.Count > 1)
                m_dtSearchDataVisibleCols = l_dsHelpData.Tables[1];
            if (l_dsHelpData.Tables.Count > 2)
            {
                try
                {
                    m_sCodeColumn = l_dsHelpData.Tables[2].Rows[0]["s_CodeColName"].ToString();
                    m_sNameColumn = l_dsHelpData.Tables[2].Rows[0]["s_NameColName"].ToString();
                    m_sUniqueColName = l_dsHelpData.Tables[2].Rows[0]["s_UniqueNoColName"].ToString();
                    m_sBranchColumn = "s_BankBranch";
                }
                catch (Exception ex)
                {
                    Logger.Instance.WriteLog(this, ex);
                }
            }

            if (m_dtSearchData == null)
                return 1;

            if (m_dtSearchData.Rows.Count == 1)
            {
                try
                {
                    if (m_dtSearchData.Rows[0][m_sCodeColumn] != DBNull.Value)
                        SelectedCode = m_dtSearchData.Rows[0][m_sCodeColumn].ToString().Trim();
                    if (m_dtSearchData.Rows[0][m_sNameColumn] != DBNull.Value)
                        SelectedName = m_dtSearchData.Rows[0][m_sNameColumn].ToString().Trim();
                    if (m_dtSearchData.Rows[0][m_sUniqueColName] != DBNull.Value)
                        SelectedUniqueValue = m_dtSearchData.Rows[0][m_sUniqueColName].ToString().Trim();
                }
                catch (Exception ex)
                {
                    Logger.Instance.WriteLog(this, ex);
                }

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                dgvSearchGrid.DataSource = m_dtSearchData;
                FormatGrid();
            }

            return 0;
        } 
        #endregion

        /// <summary>
        /// Clears window controls/class instance objects
        /// </summary>
        #region Clear
        private void Clear()
        {
            m_sCodeColumn = string.Empty;
            m_sNameColumn = string.Empty;
            m_sUniqueColName = string.Empty;

            m_sSelectedCode = string.Empty;
            m_sSelectedName = string.Empty;
            m_sSelectedUniqueValue = string.Empty;

            if (m_dtSearchData != null)
                m_dtSearchData.Dispose();
            m_dtSearchData = null;

            if (m_dtSearchDataVisibleCols != null)
                m_dtSearchDataVisibleCols.Dispose();
            m_dtSearchDataVisibleCols = null;

            dgvSearchGrid.DataSource = null;
            dgvSearchGrid.Rows.Count = dgvSearchGrid.Rows.Fixed;
        }
        #endregion

        /// <summary>
        /// Retrieves records applying search text box filter.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnApply_Click
        private void btnApply_Click(object sender, EventArgs e)
        {
            PopulateGrid();
        } 
        #endregion

        /// <summary>
        /// Grid mouse double click event handler.
        /// Marks double clicked record as selected and closes window.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region dgvSearchGrid_DoubleClick
        private void dgvSearchGrid_DoubleClick(object sender, EventArgs e)
        {
            HitTestInfo l_htiInfo = dgvSearchGrid.HitTest(dgvSearchGrid.PointToClient(Cursor.Position));

            if (
                (l_htiInfo.Column < dgvSearchGrid.Cols.Fixed)
                || (l_htiInfo.Column > dgvSearchGrid.Cols.Count)
                || (l_htiInfo.Row < dgvSearchGrid.Rows.Fixed)
                || (l_htiInfo.Row > dgvSearchGrid.Rows.Count)
               )
            {
                return;
            }

            if (dgvSearchGrid.Rows.Selected.Count != 1)
            {
                MessageBox.Show("Select single record!!!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            Row l_objRow = null;
            l_objRow = dgvSearchGrid.Rows.Selected[0];

            if (l_objRow == null)
            {
                return;
            }

            try
            {
                if (l_objRow[m_sCodeColumn] != DBNull.Value)
                    SelectedCode = l_objRow[m_sCodeColumn].ToString().Trim();
                if (l_objRow[m_sNameColumn] != DBNull.Value)
                    SelectedName = l_objRow[m_sNameColumn].ToString().Trim();
                if (l_objRow[m_sUniqueColName] != DBNull.Value)
                    SelectedUniqueValue = l_objRow[m_sUniqueColName].ToString().Trim();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
            }

            SearchText = String.Empty;

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
        
        #endregion
        
        /// <summary>
        /// Close button click event handler
        /// Closes current window marking dialog result as Cancel
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnClose_Click
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
        #endregion

        /// <summary>
        /// Grid key up event handler.
        /// Redirects to dgvSearchGrid_DoubleClick if pressed key is ENTER
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region dgvSearchGrid_KeyUp
        private void dgvSearchGrid_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                dgvSearchGrid_DoubleClick(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Search text box key up event handler.
        /// Performs Apply button clicked if pressed key is ENTER.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtSearch_KeyUp
        private void txtSearch_KeyUp(object sender, KeyEventArgs e)
        {
            if ((e.KeyValue == 13) || (e.KeyValue == 9))
                btnApply_Click(this, EventArgs.Empty);
        }
        #endregion

        #endregion

        #region Methods

        /// <summary>
        /// Formats data layout of grid. Sets visible columns, their titles.
        /// </summary>
        #region FormatGrid
        private void FormatGrid()
        {
            foreach (Column col in dgvSearchGrid.Cols)
            {
                col.Visible = false;
            }

            if( (m_dtSearchDataVisibleCols != null) && (m_dtSearchDataVisibleCols.Rows.Count > 0) )
            {
                for (int l_iColCounter = 0; l_iColCounter < m_dtSearchDataVisibleCols.Columns.Count; l_iColCounter++)
                {
                    string l_sCurrentColName = m_dtSearchDataVisibleCols.Columns[l_iColCounter].ColumnName;
                    if (dgvSearchGrid.Cols.Contains(l_sCurrentColName))
                    {
                        dgvSearchGrid.Cols[l_sCurrentColName].Caption = m_dtSearchDataVisibleCols.Rows[0][l_sCurrentColName].ToString();
                        dgvSearchGrid.Cols[l_sCurrentColName].Visible = true;

                        if (l_sCurrentColName == m_sNameColumn)
                        {
                            dgvSearchGrid.Cols[l_sCurrentColName].Width = 350;
                        }

                        if (l_sCurrentColName == m_sBranchColumn)
                        {
                            dgvSearchGrid.Cols[l_sCurrentColName].Width = 175;
                        }

                    }
                }
            }

        } 
        #endregion
        
        #endregion

        #region Properties

        /// <summary>
        /// Search Type
        /// </summary>
        #region SearchTypeCurrent
        public SearchType SearchTypeCurrent
        {
            get { return m_objSearchType; }
            set { m_objSearchType = value; }
        }
        #endregion

        /// <summary>
        /// Search value
        /// </summary>
        #region SearchValueCurrent
        public SearchValue SearchValueCurrent
        {
            get { return m_objSearchValue; }
            set { m_objSearchValue = value; }
        }
        #endregion

        /// <summary>
        /// Search initial filter text
        /// </summary>
        #region SearchText
        public string SearchText
        {
            get { return m_sSearchText; }
            set { m_sSearchText = value; }
        }
        #endregion

        /// <summary>
        /// Search data
        /// </summary>
        #region SearchData
        public DataTable SearchData
        {
            get { return m_dtSearchData; }
        }
        #endregion

        /// <summary>
        /// Selected record code
        /// </summary>
        #region SelectedCode
        public string SelectedCode
        {
            get { return m_sSelectedCode; }
            private set { m_sSelectedCode = value; }
        }
        #endregion

        /// <summary>
        /// Selected record name
        /// </summary>
        #region SelectedName
        public string SelectedName
        {
            get { return m_sSelectedName; }
            private set { m_sSelectedName = value; }
        }
        #endregion

        /// <summary>
        /// Selected Unique Value
        /// </summary>
        #region SelectedUniqueValue
        public string SelectedUniqueValue
        {
            get { return m_sSelectedUniqueValue; }
            private set { m_sSelectedUniqueValue = value; }
        }
        #endregion

        #endregion

    }
}
