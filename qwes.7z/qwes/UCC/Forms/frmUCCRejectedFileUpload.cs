﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.IO;
using System.Windows.Forms;
using UCC.Class;
using MatchCommon;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;

/// <summary>
///==================================================================================================================
/// File/Class/Custom Name    : frmUCCRejectedFileUpload.cs
/// Modified for CR No.       : CR993
/// Modified By               : Shantanu S
/// Date of Modified          : 20/11/2013
/// Modification Reason       : UCC response file upload for BSE exchange added.  
/// Modified By               : Shantanu S
/// Date of Modified          : 19/03/2014
/// Modification Reason       : Changes done for CR964. Record Type ComboBox added for NSE New/Modified file upload. 
///==================================================================================================================
/// </summary>

namespace UCC.Forms
{
    /// <summary>
    /// Exchange UCC response file upload window
    /// </summary>
    public partial class frmUCCRejectedFileUpload : Form
    {
        #region Variables

        /// <summary>
        /// Message bot title
        /// </summary>
        private readonly string MsgBoxTitle = "UCC Rejected File Upload";

        /// <summary>
        /// Read only variable options to be displayed in Record Type combo box
        /// </summary>
        private readonly string ViewNewRec = "New";
        private readonly string ViewModifiedRec = "Modified";
        
        /// <summary>
        /// Response upload BL class instance
        /// </summary>
        private CUCCRejectedFileUpload m_objUCCRejectedFile;

        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        #region Constructor
        public frmUCCRejectedFileUpload()
        {
            InitializeComponent();

            dgRejectionDetail.OverrideDefault = true;
            dgRejectionDetail.Styles.Normal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dgRejectionDetail.Styles.Alternate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);

            m_objUCCRejectedFile = new CUCCRejectedFileUpload();
        }
        #endregion

        #region Events

        /// <summary>
        /// Window load event handler. 
        /// Initializes menu/controls, populates help controls.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region frmUCCRejectedFileUpload_Load
        private void frmUCCRejectedFileUpload_Load(object sender, EventArgs e)
        {
            menuUCCRejectedFileUpload.View.Visible = false;
            menuUCCRejectedFileUpload.New.Visible = false;
            menuUCCRejectedFileUpload.Modify.Visible = false;
            menuUCCRejectedFileUpload.Cancel.Visible = false;
            menuUCCRejectedFileUpload.Delete.Visible = false;
            menuUCCRejectedFileUpload.Filter.Visible = false;
            menuUCCRejectedFileUpload.Legends.Visible = false;
            menuUCCRejectedFileUpload.Save.Visible = false;

            menuUCCRejectedFileUpload.Help.Click += new EventHandler(Help_Click);
            menuUCCRejectedFileUpload.Exit.Click += new EventHandler(Exit_Click);

            DataSet l_dsLookupData = null;

            MethodExecResult l_meResult = m_objUCCRejectedFile.GetLookupData(ref l_dsLookupData);

            if (l_meResult.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                cboExchange.ValueMember = "DataValue";
                cboExchange.DisplayMember = "DisplayValue";
                DataTable l_dtExchanges = l_dsLookupData.Tables[0];

                for (int l_intRowCounter = 0; l_intRowCounter < l_dtExchanges.Rows.Count; l_intRowCounter++)
                {
                    CListItem l_objNewCode = new CListItem();
                    l_objNewCode.DataValue = l_dtExchanges.Rows[l_intRowCounter]["n_ExNo"].ToString();
                    l_objNewCode.DisplayValue = l_dtExchanges.Rows[l_intRowCounter]["s_ExCode"].ToString();
                    l_objNewCode.CustomValue1 = l_dtExchanges.Rows[l_intRowCounter]["s_MemberId"].ToString();
                    cboExchange.Items.Add(l_objNewCode);
                }

                cboExchange.SelectedIndex = 0;

                //CR964 Starts
                cboRecordType.Items.Clear();    
                cboRecordType.Items.Add(ViewNewRec);
                cboRecordType.Items.Add(ViewModifiedRec);
                cboRecordType.SelectedItem = ViewNewRec;

                ExchangeType l_objExchangeCode = CUCCCommon.Instance.GetExchangeType(((CListItem)cboExchange.SelectedItem).DisplayValue);
                if (l_objExchangeCode == ExchangeType.NSE)
                    cboRecordType.Enabled = true;
                else
                    cboRecordType.Enabled = false;

                //CR964 Ends

                btnUpload.Enabled = true;
                btnClear.Enabled = false;
            }
            else
            {
                MessageBox.Show(l_meResult.ErrorMessage, MsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
        }
        #endregion

        /// <summary>
        /// Upload the rejection file.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnUpload_Click
        private void btnUpload_Click(object sender, EventArgs e)
        {
            UploadData();
        }
        #endregion

        /// <summary>
        /// Clear and reset the UI.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnClear_Click
        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearData();
        }
        #endregion

        /// <summary>
        /// Show the help.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region Help_Click
        private void Help_Click(object sender, EventArgs e)
        {
            MessageBox.Show(MatchCommon.CCommon.HelpNotAvailableMessage, MsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        #endregion

        /// <summary>
        /// Close the form.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region Exit_Click
        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion

        /// <summary>
        /// Closes window
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnClose_Click
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion

        #endregion

        #region Methods

        /// <summary>
        /// Upload the rejection file to database where it gets validated and valid records are updated.
        /// Displays result of failed validations.
        /// </summary>
        #region UploadData
        public void UploadData()
        {
            if (cboExchange.SelectedIndex < 0)
            {
                MessageBox.Show("Select the Exchange.", MsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string l_sFilter = string.Empty;
            Char[] l_sFileSpliter;
            ExchangeType l_objExchangeCode = CUCCCommon.Instance.GetExchangeType(((CListItem)cboExchange.SelectedItem).DisplayValue);

            if (l_objExchangeCode == ExchangeType.NSE)
            {
                l_sFilter = "UCC Rejected Files(*.log*)|*.log*";
                l_sFileSpliter = new char[] { '|' };
            }
            else if (l_objExchangeCode == ExchangeType.MCXSX)
            {
                l_sFilter = "UCC Rejected Files(*.E*)|*.E*";
                l_sFileSpliter = new char[] { ',' };
            }
            else if (l_objExchangeCode == ExchangeType.BSE) //CR993
            {
                l_sFilter = "UCC Rejected Files(*.txt*)|*.txt*";
                l_sFileSpliter = new char[] { '|' };
            }
            else
            {
                MessageBox.Show("Exchange not supported.", MsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            OpenFileDialog l_opdUpload = new OpenFileDialog();
            l_opdUpload.Filter = l_sFilter;
            l_opdUpload.Multiselect = false;
            l_opdUpload.Title = "UCC Rejected File";
            l_opdUpload.CheckFileExists = true;
            l_opdUpload.CheckPathExists = true;
            string l_sFolderPath = MatchCommon.CCommon.MyCommon(MatchCommonModules.Cash).GetTemplateFileFolder("UCC_Rejected_Upload");

            if (System.IO.Directory.Exists(l_sFolderPath))
                l_opdUpload.InitialDirectory = l_sFolderPath;

            if (l_opdUpload.ShowDialog() != DialogResult.OK)
                return;

            string l_sFileName = l_opdUpload.FileName;
            StreamReader l_objTxtReader = null;

            try
            {
                DataTable l_dtFileData = new DataTable("#UCCRejectedFileUpload");

                l_dtFileData.Columns.Add("s_ClientCode");
                l_dtFileData.Columns.Add("s_RejectionCode");
                l_dtFileData.Columns.Add("s_Status");//CR993
                l_dtFileData.Columns.Add("s_RejectDesc");//CR993

                l_dtFileData.Columns["s_ClientCode"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, "");
                l_dtFileData.Columns["s_ClientCode"].ExtendedProperties.Add(DbManager.ColLengthAttr, "25");
                l_dtFileData.Columns["s_RejectionCode"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, "");
                l_dtFileData.Columns["s_RejectionCode"].ExtendedProperties.Add(DbManager.ColLengthAttr, "255");

                l_dtFileData.Columns["s_Status"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, ""); //CR993
                l_dtFileData.Columns["s_Status"].ExtendedProperties.Add(DbManager.ColLengthAttr, "25");  //CR993
                l_dtFileData.Columns["s_RejectDesc"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, "");  //CR993
                l_dtFileData.Columns["s_RejectDesc"].ExtendedProperties.Add(DbManager.ColLengthAttr, "255");  //CR993

                l_objTxtReader = new StreamReader(l_opdUpload.FileName);
                string l_sLine = string.Empty;

                bool l_bHeaderRow = true;
                string l_sFileMemberId = string.Empty;
                string l_sDateFormat = "ddMMyyyy";
                DateTime l_dtDate = DateTime.MinValue;
                int l_iBatchNo = 0;
                int l_iTotalNoOfRecords = 0;
                string l_sMemberId = ((CListItem)cboExchange.SelectedItem).CustomValue1;
                int l_iExchangeNo = Convert.ToInt32(((CListItem)cboExchange.SelectedItem).DataValue);
                string l_sNSERejectionCode = string.Empty;

                string l_sRecType = string.Empty;   //CR964
                l_sRecType = cboRecordType.SelectedItem.ToString() == ViewNewRec ? "N" : "M";  //CR964

                if (l_objExchangeCode == ExchangeType.MCXSX)
                {
                    while ((l_sLine = l_objTxtReader.ReadLine()) != null)
                    {

                        DataRow l_drRecord = l_dtFileData.NewRow();
                        string[] l_sArr = null;

                        l_sArr = l_sLine.Split(l_sFileSpliter);

                        if (l_bHeaderRow)
                        {
                            l_sFileMemberId = l_sArr[2];
                            l_dtDate = DateTime.ParseExact(l_sArr[3], l_sDateFormat, null); // "16042013"
                            l_iBatchNo = Convert.ToInt32(l_sArr[4]);
                            l_iTotalNoOfRecords = Convert.ToInt32(l_sArr[5]);
                            l_bHeaderRow = false;
                        }
                        else
                        {
                            l_drRecord["s_ClientCode"] = l_sArr[0];
                            l_drRecord["s_RejectionCode"] = l_sArr[1];
                            l_dtFileData.Rows.Add(l_drRecord);
                        }

                    }
                }
                else if (l_objExchangeCode == ExchangeType.NSE)
                {
                    string l_sOnlyFileName;
                    string[] l_sOnlyFileNameArr;
                    l_sOnlyFileName = System.IO.Path.GetFileName(l_sFileName);

                    l_sOnlyFileNameArr = l_sOnlyFileName.Split(new Char[] { '_' });
                    l_sFileMemberId = l_sOnlyFileNameArr[0];
                    Int16 l_fileLineCount = 0;
                    while ((l_sLine = l_objTxtReader.ReadLine()) != null)
                    {
                        l_fileLineCount++;
                        if (l_fileLineCount < 7)
                            continue;
                        if (l_sLine.Contains("--------"))
                            break;

                        string[] l_sArr = null;
                        

                        if (l_bHeaderRow)
                        {
                            l_sArr = l_sLine.Split(new char[] { ':' });
                            
                            //////string l_strHeaderDate = string.Empty;
                            //////l_strHeaderDate = l_sRecType == "N" ? l_sArr[1].Trim().Substring(4, 8) : l_sArr[1].Trim().Substring(8, 8);    //CR964
                            //l_dtDate = DateTime.ParseExact(l_strHeaderDate, "yyyyMMdd", null); // "16042013"

                            l_dtDate = DateTime.ParseExact(l_sRecType == "N" ? l_sArr[1].Trim().Substring(4, 8) : l_sArr[1].Trim().Substring(8, 8), "yyyyMMdd", null); // "16042013"
                            
                            l_iBatchNo = Convert.ToInt32(
                                ( (l_sRecType == "N") ? l_sArr[1].Trim().Substring(14, 2) : l_sArr[1].Trim().Substring(18, 2))
                                );
                            l_bHeaderRow = false;
                        }
                        else
                        {
                            l_sArr = l_sLine.Split(l_sFileSpliter);

                            if (
                                ((l_sRecType == "N") && (l_sArr.Length != 250))  //CR1219 (2 POA details fields added so count increamented)
                                || ((l_sRecType != "N") && (l_sArr.Length != 64))
                               )
                            {
                                MessageBox.Show("Invalid file format. No of fields are not matching.", MsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                return;
                            }

                            DataRow l_drRecord = l_dtFileData.NewRow();
                            l_sNSERejectionCode = l_sRecType == "N" ? l_sArr[249] : l_sArr[63];    //CR964, //CR1219 (2 POA details fields added so count increamented)  

                            l_drRecord["s_ClientCode"] = l_sArr[1];
                            l_drRecord["s_RejectionCode"] = l_sNSERejectionCode;

                            l_dtFileData.Rows.Add(l_drRecord);
                        }

                    }

                }
                else if (l_objExchangeCode == ExchangeType.BSE)    //CR993
                {
                    l_dtDate = System.DateTime.Now;
                    while ((l_sLine = l_objTxtReader.ReadLine()) != null)
                    {
                        string[] l_sArr = null;
                        l_sArr = l_sLine.Split(l_sFileSpliter);

                        DataRow l_drRecord = l_dtFileData.NewRow();

                        //l_drRecord["s_RecordNo"] = l_sArr[0];
                        l_drRecord["s_ClientCode"] = l_sArr[1];
                        l_drRecord["s_Status"] = l_sArr[2];
                        l_drRecord["s_RejectDesc"] = l_sArr[3];

                        l_dtFileData.Rows.Add(l_drRecord);
                    }

                }

                l_dtFileData.AcceptChanges();

                int l_returnRecords = 0;
                MethodExecResult l_meResult = m_objUCCRejectedFile.CheckForFileAlreadyUploaded(l_iExchangeNo, l_iBatchNo, ref l_returnRecords, l_objExchangeCode, l_sRecType, l_dtDate);    //CR964
                if (l_meResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
                {
                    CCommon.MyCommon(MatchCommon.MatchCommonModules.Cash).WriteLog(this.GetType().ToString(), string.Empty,
                        string.Empty, string.Empty, "Error checking already uploaded file." + Environment.NewLine + l_meResult.DetailedErrorMessage, l_meResult.ExceptionObject);

                    MessageBox.Show("Error validating upload file.", MsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnClear.Enabled = false;
                    return;
                }
                if (l_returnRecords > 0 && l_objExchangeCode != ExchangeType.BSE)  //CR993
                {
                    MessageBox.Show("Response file already uploaded for Exchange: " + l_objExchangeCode.ToString() + " and BatchNo: " + l_iBatchNo.ToString() , MsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                if (l_dtFileData.Rows.Count <= 0)
                {
                    MessageBox.Show("Invalid File Format", MsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                if (l_objExchangeCode == ExchangeType.MCXSX && l_iTotalNoOfRecords != l_dtFileData.Rows.Count)
                {
                    MessageBox.Show("Mismatch in Total No of records", MsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                if (!l_sMemberId.Equals(l_sFileMemberId) && l_objExchangeCode != ExchangeType.BSE) //CR993
                {
                    MessageBox.Show("Invalid Member Code", MsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                l_iTotalNoOfRecords = l_dtFileData.Rows.Count;
                DataSet l_dsFileData = new DataSet();
                l_dsFileData.Tables.Add(l_dtFileData);
                DataSet l_dsInvalidData = new DataSet();

                l_meResult = m_objUCCRejectedFile.UploadData(l_dsFileData, l_iExchangeNo, l_dtDate, l_iBatchNo, ref l_dsInvalidData, l_objExchangeCode, l_sRecType);   //CR964

                if (l_meResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
                {
                    CCommon.MyCommon(MatchCommon.MatchCommonModules.Cash).WriteLog(this.GetType().ToString(), string.Empty,
                        string.Empty, string.Empty, "Error uploading data. " + Environment.NewLine + l_meResult.DetailedErrorMessage, l_meResult.ExceptionObject);

                    MessageBox.Show("Error in data upload.", MsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnClear.Enabled = false;
                    return;
                }

                btnClear.Enabled = true;
                btnUpload.Enabled = false;
                cboExchange.Enabled = false;
                cboRecordType.Enabled = false;    //CR964

                if (l_dsInvalidData != null)
                {
                    int l_iUploadedRecordCount = 0;

                    if (l_dsInvalidData.Tables.Count > 1 && l_dsInvalidData.Tables[1].Rows.Count > 0)
                    {
                        l_iUploadedRecordCount = Convert.ToInt32(l_dsInvalidData.Tables[1].Rows[0][0].ToString());
                    }

                    if (l_iUploadedRecordCount > 0)
                    {
                        MessageBox.Show("Upload successfully completed.", MsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("No valid data to upload.", MsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    if (l_dsInvalidData.Tables.Count > 0 && l_dsInvalidData.Tables[0].Rows.Count > 0)
                    {
                        dgRejectionDetail.DataSource = l_dsInvalidData.Tables[0];
                        FormatGrid();
                    }

                    string l_sStatusText = "Status : Total records = " + l_iTotalNoOfRecords.ToString() + ". Success : " + l_iUploadedRecordCount.ToString();

                    if (l_iTotalNoOfRecords != l_iUploadedRecordCount)
                    {
                        l_sStatusText += " and Failure : " + (l_iTotalNoOfRecords - l_iUploadedRecordCount).ToString();
                    }

                    l_sStatusText += ".";
                    lblStatus.Text = l_sStatusText;
                }
            }
            catch (IOException IOExc)
            {
                CCommon.MyCommon(MatchCommon.MatchCommonModules.Cash).WriteLog(this.GetType().ToString(), MsgBoxTitle,
                    "", "", "IO Error processing input file" + Environment.NewLine + IOExc.ToString(), IOExc);

                MessageBox.Show("IO Error in processing input file", MsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                menuUCCRejectedFileUpload.Save.Enabled = false;
                return;
            }
            catch (Exception ex)
            {
                CCommon.MyCommon(MatchCommon.MatchCommonModules.Cash).WriteLog(this.GetType().ToString(), MsgBoxTitle,
                    "", "", "Error processing input file" + Environment.NewLine + ex.ToString(), ex);

                MessageBox.Show("Invalid File Format", MsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                menuUCCRejectedFileUpload.Save.Enabled = false;
                return;
            }
            finally
            {
                if (l_objTxtReader != null)
                    l_objTxtReader.Close();
            }

        }
        #endregion

        /// <summary>
        /// Formats grid layout.
        /// </summary>
        #region FormatGrid
        private void FormatGrid()
        {
            if (dgRejectionDetail.DataSource == null)
                return;

            if (dgRejectionDetail.Cols.Contains("s_ClientCode"))
            {
                dgRejectionDetail.Cols["s_ClientCode"].Caption = "Client Code";
            }

            if (dgRejectionDetail.Cols.Contains("s_RejectionCode"))
            {
                dgRejectionDetail.Cols["s_RejectionCode"].Caption = "Rejection Code";
            }

            if (dgRejectionDetail.Cols.Contains("s_RejDescription"))
            {
                dgRejectionDetail.Cols["s_RejDescription"].Caption = "Rejection Description";
                dgRejectionDetail.Cols["s_RejDescription"].Width = 300;
            }

            if (dgRejectionDetail.Cols.Contains("s_Remarks"))
            {
                dgRejectionDetail.Cols["s_Remarks"].Caption = "Remarks";
                dgRejectionDetail.Cols["s_Remarks"].Width = 200;
            }
        }
        #endregion

        /// <summary>
        /// Clear and resets UI input controls
        /// </summary>
        #region ClearData
        private void ClearData()
        {
            dgRejectionDetail.DataSource = null;
            lblStatus.Text = "Status : ";
            btnClear.Enabled = false;
            btnUpload.Enabled = true;
            cboExchange.Enabled = true;
            cboExchange_SelectedIndexChanged(this, EventArgs.Empty);   //CR964

            return;
        }
        #endregion

        #region
        private void cboExchange_SelectedIndexChanged(object sender, EventArgs e)
        {
            ExchangeType l_objExchangeCode = CUCCCommon.Instance.GetExchangeType(((CListItem)cboExchange.SelectedItem).DisplayValue);
            if (l_objExchangeCode == ExchangeType.NSE)
                cboRecordType.Enabled = true;
            else
                cboRecordType.Enabled = false;
        }
        #endregion

        #endregion
    }
}
