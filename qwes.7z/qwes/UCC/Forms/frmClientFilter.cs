﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using UCC.Class;
using UCC.Forms;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;
using MatchCommon;

namespace UCC.Forms
{
    /// <summary>
    /// FilterParameters (struct)
    /// </summary>
    #region FilterParameters
    public struct FilterParameters
    {
        public string ClientCode;
        public string ClientName;
        public int ExchangeNo;
        public string Branch;
        public string G3;
        public DateTime? FromCreationDate, ToCreationDate;
    }
    #endregion

    /// <summary>
    /// Client filter window
    /// </summary>
    public partial class frmClientFilter : Form
    {
        #region Variables

        /// <summary>
        /// Client filter BL class instance
        /// </summary>
        private CClientFilter m_objClientFilter;

        /// <summary>
        /// Client filter parameter instance
        /// </summary>
        private FilterParameters m_objFilterParams;

        /// <summary>
        /// Indicates if client text box text is valid client code
        /// </summary>
        private bool m_bValidClientValueSet;
        
        /// <summary>
        /// Indicates if branch text box text is valid branch code
        /// </summary>
        private bool m_bValidBranchValueSet;

        /// <summary>
        /// Indicates if G3 text box text is valid G3 code
        /// </summary>
        private bool m_bValidG3ValueSet;

        #endregion

        /// <summary>
        /// Client filter constructor
        /// </summary>
        #region Constructor
        public frmClientFilter()
        {
            InitializeComponent();

            this.DialogResult = DialogResult.Cancel;
            m_objClientFilter = new CClientFilter();
        } 
        #endregion

        #region Evetns

        /// <summary>
        /// Window load event handler. Initializes controls.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region frmClientFilter_Load
        private void frmClientFilter_Load(object sender, EventArgs e)
        {
            PopulateLookUp();
            PopulateDefaulValues();
        } 
        #endregion

        /// <summary>
        /// Apply button click event handler.
        /// Sets filter class instance and closes window
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnApply_Click
        private void btnApply_Click(object sender, EventArgs e)
        {
            if (dtpFromCreationDate.Checked)
            {
                if (dtpFromCreationDate.Value.Date > dtpToCreationDate.Value.Date)
                {
                    MessageBox.Show("From date cannot be less than To date", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    dtpFromCreationDate.Focus();
                    return;
                }
            }

            m_objFilterParams = new FilterParameters();
            m_objFilterParams.ClientCode = txtClientCode.Text.Trim();
            m_objFilterParams.ClientName = txtClientName.Text.Trim();
            m_objFilterParams.ExchangeNo = Convert.ToInt32(this.cboExchangeCode.SelectedValue);

            m_objFilterParams.Branch = txtBranch.Text.Trim();
            m_objFilterParams.G3 = txtG3.Text.Trim();

            m_objFilterParams.FromCreationDate = null;
            m_objFilterParams.ToCreationDate = null;
            if (dtpFromCreationDate.Checked)
            {
                m_objFilterParams.FromCreationDate = dtpFromCreationDate.Value;
                m_objFilterParams.ToCreationDate = dtpToCreationDate.Value;
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        } 
        #endregion

        /// <summary>
        /// Closes current window
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnCancel_Click
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #endregion

        /// <summary>
        /// Client code text box text change event handler.
        /// Sets m_bValidClientValueSet to false.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtClientCode_TextChanged
        private void txtClientCode_TextChanged(object sender, EventArgs e)
        {
            m_bValidClientValueSet = false;
        } 
        #endregion

        /// <summary>
        /// Client Code text box Key Up Event handler.
        /// Opens help window if F3 key is pressed.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtClientCode_KeyUp
        /// <summary>
        /// Client Code Key Up Event.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        private void txtClientCode_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtClientCode.ReadOnly)
                return;

            if (e.KeyCode == Keys.F3)
                ShowClientHelp(txtClientCode.Text, string.Empty);
        } 
        #endregion

        /// <summary>
        /// Client code text box leave event handler.
        /// If valid client set flag is False, opens client help window populating records as per client code textbox text.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtClientCode_Leave
        private void txtClientCode_Leave(object sender, EventArgs e)
        {
            if (txtClientCode.ReadOnly)
                return;

            if (txtClientCode.Text.Trim().Length == 0)
            {
                txtClientName.Text = string.Empty;
                return;
            }

            if (m_bValidClientValueSet == false)
                ShowClientHelp(txtClientCode.Text.Trim(), string.Empty);
        }
        #endregion

        /// <summary>
        /// Branch Code text box Key Up Event handler.
        /// Opens help window if F3 key is pressed.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtBranch_KeyUp
        private void txtBranch_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtBranch.ReadOnly)
                return;

            if (e.KeyCode == Keys.F3)
                ShowBranchHelp(txtBranch.Text.Trim());
        }
        #endregion

        /// <summary>
        /// Branch code text box leave event handler.
        /// If valid branch set flag is False, opens branch help window populating records as per branch code textbox text.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtBranch_Leave
        private void txtBranch_Leave(object sender, EventArgs e)
        {
            if (txtBranch.ReadOnly)
                return;

            if (txtBranch.Text.Trim().Length == 0)
                return;

            if (m_bValidBranchValueSet == false)
                ShowBranchHelp(txtBranch.Text.Trim());
        }
        #endregion

        /// <summary>
        /// Branch code text box text change event handler.
        /// Sets m_bValidBranchValueSet to false.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtBranch_TextChanged
        private void txtBranch_TextChanged(object sender, EventArgs e)
        {
            m_bValidBranchValueSet = false;
        }
        #endregion

        /// <summary>
        /// G3 Code text box Key Up Event handler.
        /// Opens help window if F3 key is pressed.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtG3_KeyUp
        private void txtG3_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtG3.ReadOnly)
                return;

            if (e.KeyCode == Keys.F3)
                ShowG3Help(txtG3.Text.Trim());
        }
        #endregion

        /// <summary>
        /// G3 code text box leave event handler.
        /// If valid G3 set flag is False, opens G3 help window populating records as per G3 code textbox text.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtG3_Leave
        private void txtG3_Leave(object sender, EventArgs e)
        {
            if (txtG3.ReadOnly)
                return;

            if (txtG3.Text.Trim().Length == 0)
                return;

            if (m_bValidG3ValueSet == false)
                ShowG3Help(txtG3.Text.Trim());
        }
        #endregion

        /// <summary>
        /// G3 code text box text change event handler.
        /// Sets m_bValidG3ValueSet to false.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtG3_TextChanged
        private void txtG3_TextChanged(object sender, EventArgs e)
        {
            m_bValidG3ValueSet = false;
        }
        #endregion
        
        /// <summary>
        /// Client Name text box leave event handler.
        /// Clears client code text box if client name is cleared.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        #region txtClientName_Leave
        private void txtClientName_Leave(object sender, EventArgs e)
        {
            if (txtClientName.ReadOnly)
                return;
        }
        #endregion

        #endregion

        #region Methods

        /// <summary>
        /// Populates help (combo) controls with master values
        /// </summary>
        #region PopulateLookUp
        private void PopulateLookUp()
        {
            DataSet l_ViewData = new DataSet();

            //To be removed and taken from CMastersDataProvider
            MethodExecResult l_objMethodExceResult = m_objClientFilter.GetUCCClientFilterLookUpData(ref l_ViewData);
            if (l_objMethodExceResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, l_objMethodExceResult);
                MessageBox.Show(l_objMethodExceResult.ErrorMessage, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            cboExchangeCode.DisplayMember = "s_ReferenceName";
            cboExchangeCode.ValueMember = "s_ReferenceCode";
            cboExchangeCode.DataSource = l_ViewData.Tables[1];
        }
        #endregion

        /// <summary>
        /// Populates controls with previously set values
        /// </summary>
        #region PopulateDefaulValues
        private void PopulateDefaulValues()
        {
            txtClientCode.Text = m_objFilterParams.ClientCode;
            txtClientName.Text = m_objFilterParams.ClientName;
            m_bValidClientValueSet = true;

            cboExchangeCode.SelectedValue = m_objFilterParams.ExchangeNo;
            txtBranch.Text = m_objFilterParams.Branch;
            txtG3.Text = m_objFilterParams.G3;

            m_bValidBranchValueSet = true;
            m_bValidG3ValueSet = true;

            dtpFromCreationDate.Checked = true;
            if (m_objFilterParams.FromCreationDate.HasValue)
                dtpFromCreationDate.Value = m_objFilterParams.FromCreationDate.Value;
            else
                dtpFromCreationDate.Checked = false;

            dtpToCreationDate.Checked = true;
            if (m_objFilterParams.ToCreationDate.HasValue)
                dtpToCreationDate.Value = m_objFilterParams.ToCreationDate.Value;
            else
                dtpToCreationDate.Checked = false;
        }
        #endregion

        /// <summary>
        /// Opens client help window populating records as per given client code
        /// </summary>
        /// <param name="p_vsClientCode">Filter client code</param>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region ShowClientHelp
        private long ShowClientHelp(string p_vsClientCode, string p_vsClientName)
        {
            frmSearch l_objSearch = new frmSearch();
            l_objSearch.SearchTypeCurrent = frmSearch.SearchType.Client;
            if (p_vsClientCode == string.Empty)
            {
                l_objSearch.SearchText = p_vsClientName;
                l_objSearch.SearchValueCurrent = frmSearch.SearchValue.ClientName;
            }
            else
            {
                l_objSearch.SearchText = p_vsClientCode;
                l_objSearch.SearchValueCurrent = frmSearch.SearchValue.ClientCode;
            }

            if (l_objSearch.ShowDialog() == DialogResult.OK)
            {
                txtClientCode.Text = l_objSearch.SelectedCode;
                txtClientName.Text = l_objSearch.SelectedName;
                m_bValidClientValueSet = true;
            }
            else
            {
                txtClientCode.Text = string.Empty;
                txtClientName.Text = string.Empty;
            }

            return 0;
        }
        #endregion

        /// <summary>
        /// Opens branch help window populating records as per given branch code
        /// </summary>
        /// <param name="p_vsClientCode">Filter branch code</param>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region ShowBranchHelp
        private long ShowBranchHelp(string p_vsBranchCode)
        {
            frmSearch l_objSearch = new frmSearch();
            l_objSearch.SearchTypeCurrent = frmSearch.SearchType.Branch;
            l_objSearch.SearchText = p_vsBranchCode;
            l_objSearch.SearchValueCurrent = frmSearch.SearchValue.BranchCode;

            if (l_objSearch.ShowDialog() == DialogResult.OK)
            {
                txtBranch.Text = l_objSearch.SelectedCode;
                m_bValidBranchValueSet = true;
            }

            return 0;
        }
        #endregion

        /// <summary>
        /// Opens G3 help window populating records as per given G3 code
        /// </summary>
        /// <param name="p_vsClientCode">Filter G3 code</param>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region ShowG3Help
        private long ShowG3Help(string p_vsG3Code)
        {
            frmSearch l_objSearch = new frmSearch();
            l_objSearch.SearchTypeCurrent = frmSearch.SearchType.G3;
            l_objSearch.SearchText = p_vsG3Code;
            l_objSearch.SearchValueCurrent = frmSearch.SearchValue.G3Code;

            if (l_objSearch.ShowDialog() == DialogResult.OK)
            {
                txtG3.Text = l_objSearch.SelectedCode;
                m_bValidG3ValueSet = true;
            }

            return 0;
        }
        #endregion

        #endregion

        #region Properties

        /// <summary>
        /// Filter Parameters
        /// </summary>
        #region FilterParams
        public FilterParameters FilterParams
        {
            get { return m_objFilterParams; }
            set { m_objFilterParams = value; }
        }
        #endregion
        
        #endregion
    }
}
