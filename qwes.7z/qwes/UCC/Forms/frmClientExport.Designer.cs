﻿namespace UCC.Forms
{
    partial class frmClientExport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmClientExport));
            this.ftLabel30 = new MatchCommon.CustomControls.FTLabel();
            this.txtClientCode = new MatchCommon.CustomControls.FTTextBox();
            this.btnExport = new System.Windows.Forms.Button();
            this.cboExportType = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel17 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel59 = new MatchCommon.CustomControls.FTLabel();
            this.cboExchangeCode = new MatchCommon.CustomControls.FTComboBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.ftLabel1 = new MatchCommon.CustomControls.FTLabel();
            this.dtpFromDate = new System.Windows.Forms.DateTimePicker();
            this.dtpToDate = new System.Windows.Forms.DateTimePicker();
            this.ftLabel2 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel4 = new MatchCommon.CustomControls.FTLabel();
            this.txtBatchNo = new MatchCommon.CustomControls.FTTextBox();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.lblRecordType = new MatchCommon.CustomControls.FTLabel();
            this.cboRecordType = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel5 = new MatchCommon.CustomControls.FTLabel();
            this.chkSelectAll = new MatchCommon.CustomControls.FTCheckBox();
            this.ftLabel3 = new MatchCommon.CustomControls.FTLabel();
            this.cboView = new MatchCommon.CustomControls.FTComboBox();
            this.btnRetrieve = new System.Windows.Forms.Button();
            this.pnlFill = new System.Windows.Forms.Panel();
            this.dgvExport = new MatchCommon.CustomControls.FTDataGrid();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.lblNoOfRecords = new MatchCommon.CustomControls.FTLabel();
            this.pnlTop.SuspendLayout();
            this.pnlFill.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvExport)).BeginInit();
            this.pnlBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // ftLabel30
            // 
            this.ftLabel30.AllowForeColorChange = false;
            this.ftLabel30.AutoSize = true;
            this.ftLabel30.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel30.ForeColor = System.Drawing.Color.Black;
            this.ftLabel30.Location = new System.Drawing.Point(35, 41);
            this.ftLabel30.Name = "ftLabel30";
            this.ftLabel30.OverrideDefault = false;
            this.ftLabel30.Size = new System.Drawing.Size(57, 12);
            this.ftLabel30.TabIndex = 6;
            this.ftLabel30.Text = "Client Code";
            // 
            // txtClientCode
            // 
            this.txtClientCode.AllowAlpha = true;
            this.txtClientCode.AllowDot = true;
            this.txtClientCode.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtClientCode.AllowedCustomCharacters")));
            this.txtClientCode.AllowNonASCII = false;
            this.txtClientCode.AllowNumeric = true;
            this.txtClientCode.AllowSpace = true;
            this.txtClientCode.AllowSpecialChars = true;
            this.txtClientCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtClientCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtClientCode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtClientCode.ForeColor = System.Drawing.Color.Black;
            this.txtClientCode.IsEmailID = true;
            this.txtClientCode.IsEmailIdValid = false;
            this.txtClientCode.Location = new System.Drawing.Point(99, 38);
            this.txtClientCode.Name = "txtClientCode";
            this.txtClientCode.Size = new System.Drawing.Size(140, 20);
            this.txtClientCode.TabIndex = 7;
            this.txtClientCode.TextChanged += new System.EventHandler(this.txtClientCode_TextChanged);
            this.txtClientCode.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtClientCode_KeyUp);
            this.txtClientCode.Leave += new System.EventHandler(this.txtClientCode_Leave);
            // 
            // btnExport
            // 
            this.btnExport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExport.BackColor = System.Drawing.Color.Transparent;
            this.btnExport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExport.Image = ((System.Drawing.Image)(resources.GetObject("btnExport.Image")));
            this.btnExport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExport.Location = new System.Drawing.Point(644, 8);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(75, 23);
            this.btnExport.TabIndex = 14;
            this.btnExport.Text = "&Export";
            this.btnExport.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExport.UseVisualStyleBackColor = false;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // cboExportType
            // 
            this.cboExportType.BackColor = System.Drawing.Color.White;
            this.cboExportType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboExportType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboExportType.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboExportType.ForeColor = System.Drawing.Color.Black;
            this.cboExportType.FormattingEnabled = true;
            this.cboExportType.Location = new System.Drawing.Point(460, 39);
            this.cboExportType.MaxLength = 25;
            this.cboExportType.Name = "cboExportType";
            this.cboExportType.ReadOnly = false;
            this.cboExportType.Size = new System.Drawing.Size(93, 20);
            this.cboExportType.TabIndex = 11;
            // 
            // ftLabel17
            // 
            this.ftLabel17.AllowForeColorChange = false;
            this.ftLabel17.AutoSize = true;
            this.ftLabel17.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel17.ForeColor = System.Drawing.Color.Black;
            this.ftLabel17.Location = new System.Drawing.Point(389, 42);
            this.ftLabel17.Name = "ftLabel17";
            this.ftLabel17.OverrideDefault = false;
            this.ftLabel17.Size = new System.Drawing.Size(61, 12);
            this.ftLabel17.TabIndex = 10;
            this.ftLabel17.Text = "Export Type";
            // 
            // ftLabel59
            // 
            this.ftLabel59.AllowForeColorChange = false;
            this.ftLabel59.AutoSize = true;
            this.ftLabel59.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel59.ForeColor = System.Drawing.Color.Black;
            this.ftLabel59.Location = new System.Drawing.Point(453, 10);
            this.ftLabel59.Name = "ftLabel59";
            this.ftLabel59.OverrideDefault = false;
            this.ftLabel59.Size = new System.Drawing.Size(49, 12);
            this.ftLabel59.TabIndex = 4;
            this.ftLabel59.Text = "Exchange";
            // 
            // cboExchangeCode
            // 
            this.cboExchangeCode.BackColor = System.Drawing.Color.White;
            this.cboExchangeCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboExchangeCode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboExchangeCode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboExchangeCode.ForeColor = System.Drawing.Color.Black;
            this.cboExchangeCode.FormattingEnabled = true;
            this.cboExchangeCode.Location = new System.Drawing.Point(539, 7);
            this.cboExchangeCode.MaxLength = 25;
            this.cboExchangeCode.Name = "cboExchangeCode";
            this.cboExchangeCode.ReadOnly = false;
            this.cboExchangeCode.Size = new System.Drawing.Size(162, 20);
            this.cboExchangeCode.TabIndex = 5;
            this.cboExchangeCode.SelectedIndexChanged += new System.EventHandler(this.cboExchangeCode_SelectedIndexChanged);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.BackColor = System.Drawing.Color.Transparent;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.Image")));
            this.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancel.Location = new System.Drawing.Point(742, 8);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 15;
            this.btnCancel.Text = "&Close";
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // ftLabel1
            // 
            this.ftLabel1.AllowForeColorChange = false;
            this.ftLabel1.AutoSize = true;
            this.ftLabel1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel1.ForeColor = System.Drawing.Color.Black;
            this.ftLabel1.Location = new System.Drawing.Point(35, 12);
            this.ftLabel1.Name = "ftLabel1";
            this.ftLabel1.OverrideDefault = false;
            this.ftLabel1.Size = new System.Drawing.Size(25, 12);
            this.ftLabel1.TabIndex = 0;
            this.ftLabel1.Text = "Date";
            // 
            // dtpFromDate
            // 
            this.dtpFromDate.CalendarForeColor = System.Drawing.Color.Black;
            this.dtpFromDate.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFromDate.Location = new System.Drawing.Point(99, 8);
            this.dtpFromDate.Name = "dtpFromDate";
            this.dtpFromDate.Size = new System.Drawing.Size(131, 21);
            this.dtpFromDate.TabIndex = 1;
            // 
            // dtpToDate
            // 
            this.dtpToDate.CalendarForeColor = System.Drawing.Color.Black;
            this.dtpToDate.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpToDate.Location = new System.Drawing.Point(320, 8);
            this.dtpToDate.Name = "dtpToDate";
            this.dtpToDate.Size = new System.Drawing.Size(116, 21);
            this.dtpToDate.TabIndex = 3;
            // 
            // ftLabel2
            // 
            this.ftLabel2.AllowForeColorChange = false;
            this.ftLabel2.AutoSize = true;
            this.ftLabel2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel2.ForeColor = System.Drawing.Color.Black;
            this.ftLabel2.Location = new System.Drawing.Point(260, 12);
            this.ftLabel2.Name = "ftLabel2";
            this.ftLabel2.OverrideDefault = false;
            this.ftLabel2.Size = new System.Drawing.Size(40, 12);
            this.ftLabel2.TabIndex = 2;
            this.ftLabel2.Text = "To Date";
            // 
            // ftLabel4
            // 
            this.ftLabel4.AllowForeColorChange = false;
            this.ftLabel4.AutoSize = true;
            this.ftLabel4.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel4.ForeColor = System.Drawing.Color.Black;
            this.ftLabel4.Location = new System.Drawing.Point(260, 42);
            this.ftLabel4.Name = "ftLabel4";
            this.ftLabel4.OverrideDefault = false;
            this.ftLabel4.Size = new System.Drawing.Size(46, 12);
            this.ftLabel4.TabIndex = 8;
            this.ftLabel4.Text = "Batch No";
            // 
            // txtBatchNo
            // 
            this.txtBatchNo.AllowAlpha = false;
            this.txtBatchNo.AllowDot = false;
            this.txtBatchNo.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtBatchNo.AllowedCustomCharacters")));
            this.txtBatchNo.AllowNonASCII = false;
            this.txtBatchNo.AllowNumeric = true;
            this.txtBatchNo.AllowSpace = false;
            this.txtBatchNo.AllowSpecialChars = false;
            this.txtBatchNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBatchNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtBatchNo.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtBatchNo.ForeColor = System.Drawing.Color.Black;
            this.txtBatchNo.IsEmailID = true;
            this.txtBatchNo.IsEmailIdValid = false;
            this.txtBatchNo.Location = new System.Drawing.Point(320, 39);
            this.txtBatchNo.MaxLength = 3;
            this.txtBatchNo.Name = "txtBatchNo";
            this.txtBatchNo.Size = new System.Drawing.Size(48, 20);
            this.txtBatchNo.TabIndex = 9;
            // 
            // pnlTop
            // 
            this.pnlTop.Controls.Add(this.lblRecordType);
            this.pnlTop.Controls.Add(this.cboRecordType);
            this.pnlTop.Controls.Add(this.ftLabel5);
            this.pnlTop.Controls.Add(this.chkSelectAll);
            this.pnlTop.Controls.Add(this.ftLabel3);
            this.pnlTop.Controls.Add(this.cboView);
            this.pnlTop.Controls.Add(this.btnRetrieve);
            this.pnlTop.Controls.Add(this.cboExchangeCode);
            this.pnlTop.Controls.Add(this.txtClientCode);
            this.pnlTop.Controls.Add(this.ftLabel30);
            this.pnlTop.Controls.Add(this.ftLabel4);
            this.pnlTop.Controls.Add(this.ftLabel17);
            this.pnlTop.Controls.Add(this.txtBatchNo);
            this.pnlTop.Controls.Add(this.cboExportType);
            this.pnlTop.Controls.Add(this.ftLabel59);
            this.pnlTop.Controls.Add(this.ftLabel1);
            this.pnlTop.Controls.Add(this.dtpToDate);
            this.pnlTop.Controls.Add(this.dtpFromDate);
            this.pnlTop.Controls.Add(this.ftLabel2);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(840, 96);
            this.pnlTop.TabIndex = 0;
            // 
            // lblRecordType
            // 
            this.lblRecordType.AllowForeColorChange = false;
            this.lblRecordType.AutoSize = true;
            this.lblRecordType.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblRecordType.ForeColor = System.Drawing.Color.Black;
            this.lblRecordType.Location = new System.Drawing.Point(30, 70);
            this.lblRecordType.Name = "lblRecordType";
            this.lblRecordType.OverrideDefault = false;
            this.lblRecordType.Size = new System.Drawing.Size(63, 12);
            this.lblRecordType.TabIndex = 17;
            this.lblRecordType.Text = "Record Type";
            // 
            // cboRecordType
            // 
            this.cboRecordType.BackColor = System.Drawing.Color.White;
            this.cboRecordType.DisplayMember = "New";
            this.cboRecordType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboRecordType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboRecordType.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboRecordType.ForeColor = System.Drawing.Color.Black;
            this.cboRecordType.FormattingEnabled = true;
            this.cboRecordType.Location = new System.Drawing.Point(101, 67);
            this.cboRecordType.MaxLength = 25;
            this.cboRecordType.Name = "cboRecordType";
            this.cboRecordType.ReadOnly = false;
            this.cboRecordType.Size = new System.Drawing.Size(93, 20);
            this.cboRecordType.TabIndex = 18;
            this.cboRecordType.ValueMember = "1";
            // 
            // ftLabel5
            // 
            this.ftLabel5.AllowForeColorChange = false;
            this.ftLabel5.AutoSize = true;
            this.ftLabel5.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel5.ForeColor = System.Drawing.Color.Black;
            this.ftLabel5.Location = new System.Drawing.Point(724, 42);
            this.ftLabel5.Name = "ftLabel5";
            this.ftLabel5.OverrideDefault = false;
            this.ftLabel5.Size = new System.Drawing.Size(45, 12);
            this.ftLabel5.TabIndex = 14;
            this.ftLabel5.Text = "Select All";
            // 
            // chkSelectAll
            // 
            this.chkSelectAll.AutoSize = true;
            this.chkSelectAll.ForeColor = System.Drawing.Color.Black;
            this.chkSelectAll.Location = new System.Drawing.Point(808, 41);
            this.chkSelectAll.Name = "chkSelectAll";
            this.chkSelectAll.Size = new System.Drawing.Size(15, 14);
            this.chkSelectAll.TabIndex = 15;
            this.chkSelectAll.UseVisualStyleBackColor = true;
            this.chkSelectAll.CheckedChanged += new System.EventHandler(this.chkSelectAll_CheckedChanged);
            // 
            // ftLabel3
            // 
            this.ftLabel3.AllowForeColorChange = false;
            this.ftLabel3.AutoSize = true;
            this.ftLabel3.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel3.ForeColor = System.Drawing.Color.Black;
            this.ftLabel3.Location = new System.Drawing.Point(571, 42);
            this.ftLabel3.Name = "ftLabel3";
            this.ftLabel3.OverrideDefault = false;
            this.ftLabel3.Size = new System.Drawing.Size(26, 12);
            this.ftLabel3.TabIndex = 12;
            this.ftLabel3.Text = "View";
            // 
            // cboView
            // 
            this.cboView.BackColor = System.Drawing.Color.White;
            this.cboView.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboView.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboView.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboView.ForeColor = System.Drawing.Color.Black;
            this.cboView.FormattingEnabled = true;
            this.cboView.Location = new System.Drawing.Point(608, 39);
            this.cboView.MaxLength = 25;
            this.cboView.Name = "cboView";
            this.cboView.ReadOnly = false;
            this.cboView.Size = new System.Drawing.Size(93, 20);
            this.cboView.TabIndex = 13;
            this.cboView.SelectedIndexChanged += new System.EventHandler(this.cboView_SelectedIndexChanged);
            // 
            // btnRetrieve
            // 
            this.btnRetrieve.BackColor = System.Drawing.Color.Transparent;
            this.btnRetrieve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRetrieve.Image = ((System.Drawing.Image)(resources.GetObject("btnRetrieve.Image")));
            this.btnRetrieve.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRetrieve.Location = new System.Drawing.Point(726, 6);
            this.btnRetrieve.Name = "btnRetrieve";
            this.btnRetrieve.Size = new System.Drawing.Size(97, 23);
            this.btnRetrieve.TabIndex = 16;
            this.btnRetrieve.Text = "&Retrieve";
            this.btnRetrieve.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRetrieve.UseVisualStyleBackColor = false;
            this.btnRetrieve.Click += new System.EventHandler(this.btnRetrieve_Click);
            // 
            // pnlFill
            // 
            this.pnlFill.Controls.Add(this.dgvExport);
            this.pnlFill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlFill.Location = new System.Drawing.Point(0, 96);
            this.pnlFill.Name = "pnlFill";
            this.pnlFill.Size = new System.Drawing.Size(840, 358);
            this.pnlFill.TabIndex = 17;
            // 
            // dgvExport
            // 
            this.dgvExport.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
            this.dgvExport.AllowEditing = false;
            this.dgvExport.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
            this.dgvExport.BackColor = System.Drawing.Color.Transparent;
            this.dgvExport.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.dgvExport.ColumnInfo = "10,1,0,0,0,85,Columns:0{Width:30;}\t";
            this.dgvExport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvExport.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
            this.dgvExport.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvExport.ForeColor = System.Drawing.Color.Black;
            this.dgvExport.KeyActionEnter = C1.Win.C1FlexGrid.KeyActionEnum.None;
            this.dgvExport.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
            this.dgvExport.Location = new System.Drawing.Point(0, 0);
            this.dgvExport.Name = "dgvExport";
            this.dgvExport.OverrideDefault = false;
            this.dgvExport.Rows.Count = 1;
            this.dgvExport.Rows.DefaultSize = 17;
            this.dgvExport.Rows.MinSize = 25;
            this.dgvExport.RowsFilter.AddFilterRow = false;
            this.dgvExport.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.ListBox;
            this.dgvExport.Size = new System.Drawing.Size(840, 358);
            this.dgvExport.StyleInfo = resources.GetString("dgvExport.StyleInfo");
            this.dgvExport.TabIndex = 1;
            this.dgvExport.BeforeEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.dgvExport_BeforeEdit);
            this.dgvExport.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.dgvExport_AfterEdit);
            // 
            // pnlBottom
            // 
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom.Controls.Add(this.lblNoOfRecords);
            this.pnlBottom.Controls.Add(this.btnCancel);
            this.pnlBottom.Controls.Add(this.btnExport);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 454);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(840, 38);
            this.pnlBottom.TabIndex = 17;
            // 
            // lblNoOfRecords
            // 
            this.lblNoOfRecords.AllowForeColorChange = false;
            this.lblNoOfRecords.AutoSize = true;
            this.lblNoOfRecords.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblNoOfRecords.ForeColor = System.Drawing.Color.Black;
            this.lblNoOfRecords.Location = new System.Drawing.Point(34, 12);
            this.lblNoOfRecords.Name = "lblNoOfRecords";
            this.lblNoOfRecords.OverrideDefault = false;
            this.lblNoOfRecords.Size = new System.Drawing.Size(67, 12);
            this.lblNoOfRecords.TabIndex = 17;
            this.lblNoOfRecords.Text = "No of records";
            // 
            // frmClientExport
            // 
            this.AcceptButton = this.btnRetrieve;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(840, 492);
            this.Controls.Add(this.pnlFill);
            this.Controls.Add(this.pnlBottom);
            this.Controls.Add(this.pnlTop);
            this.Name = "frmClientExport";
            this.ShowInTaskbar = false;
            this.Text = "Client Export";
            this.Load += new System.EventHandler(this.frmClientExport_Load);
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlFill.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvExport)).EndInit();
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MatchCommon.CustomControls.FTLabel ftLabel30;
        private MatchCommon.CustomControls.FTTextBox txtClientCode;
        private System.Windows.Forms.Button btnExport;
        private MatchCommon.CustomControls.FTComboBox cboExportType;
        private MatchCommon.CustomControls.FTLabel ftLabel17;
        private MatchCommon.CustomControls.FTLabel ftLabel59;
        private MatchCommon.CustomControls.FTComboBox cboExchangeCode;
        private System.Windows.Forms.Button btnCancel;
        private MatchCommon.CustomControls.FTLabel ftLabel1;
        private System.Windows.Forms.DateTimePicker dtpFromDate;
        private System.Windows.Forms.DateTimePicker dtpToDate;
        private MatchCommon.CustomControls.FTLabel ftLabel2;
        private MatchCommon.CustomControls.FTLabel ftLabel4;
        private MatchCommon.CustomControls.FTTextBox txtBatchNo;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Panel pnlFill;
        private System.Windows.Forms.Panel pnlBottom;
        private MatchCommon.CustomControls.FTDataGrid dgvExport;
        private System.Windows.Forms.Button btnRetrieve;
        private MatchCommon.CustomControls.FTLabel ftLabel3;
        private MatchCommon.CustomControls.FTComboBox cboView;
        private MatchCommon.CustomControls.FTCheckBox chkSelectAll;
        private MatchCommon.CustomControls.FTLabel ftLabel5;
        private MatchCommon.CustomControls.FTLabel lblNoOfRecords;
        private MatchCommon.CustomControls.FTLabel lblRecordType;
        private MatchCommon.CustomControls.FTComboBox cboRecordType;
    }
}