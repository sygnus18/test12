﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using UCC.Class;
using UCC.Forms;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;
using MatchCommon;
using UCC.Class.Master;
using C1.Win.C1FlexGrid;

namespace UCC.Forms
{
    /// <summary>
    /// UCC File Authorization screen
    /// </summary>
    public partial class frmCheckerAuthorization : Form
    {
        #region Variables

        /// <summary>
        /// Checker Authorization BL class instance
        /// </summary>
        private CCheckerAuthorization m_objClientAuth;


        /// <summary>
        /// UCC data DataTable
        /// </summary>
        private DataTable m_dtUCCData;

        /// <summary>
        /// Grid record selection column name
        /// </summary>
        private readonly string SelectColName = "n_Select";

        /// <summary>
        /// Binding source to bind data with grid
        /// </summary>
        private BindingSource m_bsExport;


        #endregion

        /// <summary>
        /// Export class constructor
        /// </summary>
        #region Constructor
        public frmCheckerAuthorization()
        {
            InitializeComponent();

            m_objClientAuth = new CCheckerAuthorization();
            dgvAuth.OverrideDefault = true;
            dgvAuth.Styles.Normal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dgvAuth.Styles.Alternate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);

            this.DialogResult = DialogResult.Cancel;
            m_bsExport = new BindingSource();
        } 
        #endregion

        #region Events

        /// <summary>
        /// Window load event handler. Initializes controls.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region frmCheckerAuthorization_Load
        private void frmCheckerAuthorization_Load(object sender, EventArgs e)
        {
            lblNoOfRecords.Text = string.Empty;
            dgvAuth.AllowEditing = true;
            PopulateDropdown();
        } 
        #endregion

        /// <summary>
        /// Populates window help controls with master data
        /// </summary>
        #region PopulateDropdown
        private void PopulateDropdown()
        {
            ArrayList l_paramValueArr = new ArrayList();
            l_paramValueArr.Add(AppEnvironment.AppUser.UserNo);
            DataTable l_dtMaker = new DataTable();
            MethodExecResult l_objMethodExecResult = m_objClientAuth.GetMakerUserDetails(l_paramValueArr, ref l_dtMaker);
            if (l_objMethodExecResult.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                cboMaker.DisplayMember = "s_UserName";
                cboMaker.ValueMember = "n_UserNo";
                cboMaker.DataSource = l_dtMaker;
            }


            cboEntityType.DisplayMember = "s_ReferenceName";
            cboEntityType.ValueMember = "s_ReferenceCode";
            cboEntityType.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.AUTHENTTYP];

            cboAuthStatus.DisplayMember = "s_ReferenceName";
            cboAuthStatus.ValueMember = "s_ReferenceCode";
            cboAuthStatus.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.AUTHSTATUS];

        }
        #endregion

        /// <summary>
        /// Authorization button click event handler.
        /// Authorize the selected grid records.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnAuthorization_Click
        private void btnAuthorization_Click(object sender, EventArgs e)
        {
            m_bsExport.EndEdit();
            this.Cursor = Cursors.WaitCursor;
            DataRow[] l_drArr = m_dtUCCData.Select(this.SelectColName + "=" + 1);
            if (l_drArr.Length == 0)
            {
                MessageBox.Show("No record(s) selected to authorize.", this.Text, MessageBoxButtons.OK,MessageBoxIcon.Information);
                this.Cursor = Cursors.Default;
                return;
            }
            foreach (DataRow l_rwCurrent in l_drArr)
            {
                AuthorizeRejectRecords(l_rwCurrent, "A");
            }

            MessageBox.Show("Selected record(s) authorized successfully." , this.Text, MessageBoxButtons.OK,MessageBoxIcon.Information);
            this.RefreshData();
            this.Cursor = Cursors.Default;

        }
        #endregion

        /// <summary>
        /// Rejection button click event handler.
        /// Reject the selected grid records.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnReject_Click
        private void btnReject_Click(object sender, EventArgs e)
        {
            m_bsExport.EndEdit();
            this.Cursor = Cursors.WaitCursor;
            DataRow[] l_drArr = m_dtUCCData.Select(this.SelectColName + "=" + 1);
            if (l_drArr.Length == 0)
            {
                MessageBox.Show("No record(s) selected to reject.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Cursor = Cursors.Default;
                return;
            }

            DataRow[] l_drArr2 = m_dtUCCData.Select(this.SelectColName + "=" + 1 + " AND s_Remarks = '' ");
            if (l_drArr2.Length> 0)
            {
                MessageBox.Show("Rejected remarks not provided for some record(s).", this.Text, MessageBoxButtons.OK,MessageBoxIcon.Information);
                this.Cursor = Cursors.Default;
                return;
            }

            DataRow[] l_drArr3 = m_dtUCCData.Select(this.SelectColName + "=" + 1 + " AND len(s_Remarks) > 100 ");
            if (l_drArr3.Length > 0)
            {
                MessageBox.Show("Length of rejection remarks should not be greater than 100 characters for Entity : " + l_drArr3[0]["s_Code"].ToString(), this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Cursor = Cursors.Default;
                return;
                
            }


            foreach (DataRow l_rwCurrent in l_drArr)
            {

                AuthorizeRejectRecords(l_rwCurrent, "R");
            }
            MessageBox.Show("Selected record(s) rejected successfully", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.RefreshData();
            this.Cursor = Cursors.Default;
        }
        #endregion


        /// <summary>
        /// Closes current window
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnCancel_Click
        private void btnCancel_Click(object sender, EventArgs e)
        {
            m_bsExport.EndEdit();
            if (m_dtUCCData == null)
            {
                this.Close();
                return;
            }
            DataRow[] l_drArr = m_dtUCCData.Select(this.SelectColName + "=" + 1);
            if (l_drArr.Length >0)
            {
                if (MessageBox.Show("Record(s) are selected to authorize/reject. Do you want to continue?", this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question,MessageBoxDefaultButton.Button2) == DialogResult.No)
                    return;
            }

            this.Close();
        }
        
        #endregion

        /// <summary>
        /// Retrieve button click event handler.
        /// Retrieves data from database applying current selected filter.
        /// If Batch No is provided, Reexports data for selected Date, Exchange and Batch no.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnRetrieve_Click
        private void btnRetrieve_Click(object sender, EventArgs e)
        {
            this.RefreshData();
            
        }
        #endregion

        /// <summary>
        /// Select All check box check state changed event handler.
        /// Selects/deselects all valid records as per check box checked status.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region chkSelectAll_CheckedChanged
        private void chkSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            if (m_dtUCCData == null)
            {
                MessageBox.Show("No data exists!!!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            int l_iRowCounter = 0;
            int l_iSelectedRecordsCount = 0;
            bool l_bSelectDeselect = chkSelectAll.Checked;
            try
            {
                for (l_iRowCounter = 0; l_iRowCounter < m_dtUCCData.Rows.Count; l_iRowCounter++)
                {
                    m_dtUCCData.Rows[l_iRowCounter][SelectColName] = l_bSelectDeselect;
                    l_iSelectedRecordsCount++;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "Error performing Select All operation at Line " + (l_iRowCounter + 1).ToString() + Environment.NewLine, ex);
                MessageBox.Show("Error performing operation." + Environment.NewLine + ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
        }
        #endregion
        
        /// <summary>
        /// Show records combo item changed event handler.
        /// Filters currently displayed grid records as per selection (All/UnAuthorized/Rejected).
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region cboAuthStatus_SelectedIndexChanged
        private void cboAuthStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            if ((m_dtUCCData == null) || (m_dtUCCData.Rows.Count == 0))
                return;

            string l_sFilterExpr = string.Empty;

            if (cboAuthStatus.SelectedItem != null)
            {
                    l_sFilterExpr = "s_AuthorizedStatus =" + cboAuthStatus.SelectedValue.ToString();
            }

            m_dtUCCData.DefaultView.RowFilter = l_sFilterExpr;
            lblNoOfRecords.Text = "#Records: " + m_dtUCCData.DefaultView.Count.ToString();
        }
        #endregion

        #endregion

        #region Methods

        /// <summary>
        /// Authorize or Reject the single record based on passed data and response type
        /// </summary>
        /// <param name="p_dr">Selected record to authorize or reject </param>
        /// <param name="p_sResponseType">A:Authorise R:Reject </param>
        #region AuthorizeRejectRecords
        private void AuthorizeRejectRecords(DataRow p_dr,String p_sResponseType)
        {
            string l_sAuthReject;
            ArrayList l_paramValueArr = new ArrayList();
            l_paramValueArr.Add(Convert.ToInt32(p_dr["n_ClientNo"]));
            l_paramValueArr.Add(1);
            l_paramValueArr.Add(p_sResponseType);
            l_paramValueArr.Add(p_dr["s_Remarks"].ToString());
            l_paramValueArr.Add(AppEnvironment.AppUser.UserNo);

            l_sAuthReject = p_sResponseType == "A" ? "Authorize" : "Reject";

            MethodExecResult l_objMethodExecResult = m_objClientAuth.UpdateCheckerAuthRejectData(l_paramValueArr);
            if (l_objMethodExecResult.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, "Client: " + p_dr["s_Code"] + "  checker " + l_sAuthReject + "successfully." + Environment.NewLine, null);
            }
            else
            {
                Logger.Instance.WriteLog(this, "Error performing " + l_sAuthReject + " operation on Client: " + p_dr["s_Code"] + "." + Environment.NewLine, l_objMethodExecResult.ExceptionObject);
            }
        }
        #endregion

        /// <summary>
        /// Formats data layout of grid. Sets visible columns, their titles.
        /// </summary>
        #region FormatGrid
        private void FormatGrid()
        {
            if (dgvAuth.DataSource == null)
                return;

            for (int l_iColCounter = 0; l_iColCounter < dgvAuth.Cols.Count; l_iColCounter++)
            {
                dgvAuth.Cols[l_iColCounter].Visible = false;
                dgvAuth.Cols[l_iColCounter].AllowEditing = false;
            }

            if(dgvAuth.Cols.Contains(SelectColName))
            {
                dgvAuth.Cols[SelectColName].Visible = true;
                dgvAuth.Cols[SelectColName].AllowEditing = true;
                dgvAuth.Cols[SelectColName].Caption = "Select";
                dgvAuth.Cols[SelectColName].Move(dgvAuth.Cols.Fixed);
                dgvAuth.Cols[SelectColName].Width = 40;
            }

            if (dgvAuth.Cols.Contains("s_Code"))
            {
                dgvAuth.Cols["s_Code"].Visible = true;
                dgvAuth.Cols["s_Code"].Caption = "Entity Code";
                dgvAuth.Cols["s_Code"].Width = 110;
            }
            if (dgvAuth.Cols.Contains("s_Name"))
            {
                dgvAuth.Cols["s_Name"].Visible = true;
                dgvAuth.Cols["s_Name"].Caption = "Entity Name";
                dgvAuth.Cols["s_Name"].Width = 300;
            }
            if (dgvAuth.Cols.Contains("s_UserName"))
            {
                dgvAuth.Cols["s_UserName"].Visible = true;
                dgvAuth.Cols["s_UserName"].Caption = "Maker";
                dgvAuth.Cols["s_UserName"].Width = 300;
            }

            if (dgvAuth.Cols.Contains("s_Remarks"))
            {
                dgvAuth.Cols["s_Remarks"].Visible = true;
                dgvAuth.Cols["s_Remarks"].AllowEditing = true;
                dgvAuth.Cols["s_Remarks"].Caption = "Checker Remarks";
                dgvAuth.Cols["s_Remarks"].Width = 500;
            }
        }
        #endregion

        /// <summary>
        /// Retrive the data for Authorize or reject base on selected filter values
        /// </summary>
        #region RefreshData
        private void RefreshData()
        {
            ArrayList l_paramValueArr = new ArrayList();
            l_paramValueArr.Add(1);//EntityType Client
            l_paramValueArr.Add(Convert.ToInt32(cboMaker.SelectedValue));//MakerUser
            l_paramValueArr.Add(dtpMakerDate.Value.Date);//MakerDate
            l_paramValueArr.Add(cboAuthStatus.SelectedValue);//AuthStatus

            this.Cursor = Cursors.WaitCursor;
            MethodExecResult l_objMethodExecResult = m_objClientAuth.RetrieveUCCData(l_paramValueArr, ref m_dtUCCData);
            if (l_objMethodExecResult.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {


                DataColumn l_dcSelect = new DataColumn(SelectColName, typeof(bool));
                l_dcSelect.DefaultValue = false;
                l_dcSelect.AllowDBNull = false;
                m_dtUCCData.Columns.Add(l_dcSelect);
                
                foreach(DataRow _dr in m_dtUCCData.Rows)
                {
                    if (_dr["s_AuthorizedStatus"].ToString() == "U")
                    {
                        _dr["s_Remarks"] = txtRemarks.Text;
                    }
                }
                m_dtUCCData.AcceptChanges();

                m_bsExport.DataSource = m_dtUCCData;
                dgvAuth.DataSource = m_bsExport;
                FormatGrid();
                btnAuthorization.Enabled = true;
                btnReject.Enabled = true;
                btnCheckerView.Enabled = true;
                this.Cursor = Cursors.Default;


            }
            else
            {
                if (m_dtUCCData!=null)
                    m_dtUCCData.Clear();
                btnAuthorization.Enabled = false;
                btnReject.Enabled = false;
                btnCheckerView.Enabled = false;
                Logger.Instance.WriteLog(this, l_objMethodExecResult);
                MessageBox.Show(l_objMethodExecResult.ErrorMessage, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Cursor = Cursors.Default;
            }
        }
        #endregion

        /// <summary>
        /// Opens client details window for modification
        /// </summary>
        #region OpenClientDetailsWindow
        private long OpenClientDetailsWindow()
        {
            Row l_objRow = null;
            if (dgvAuth.Rows.Selected.Count != 1)
            {
                MessageBox.Show("Select Single Record for Modification", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return -1;
            }
            l_objRow = dgvAuth.Rows.Selected[0];

            if (l_objRow == null)
            {
                return -1;
            }

            CClient l_objClient = null;
            try
            {
                l_objClient = new CClient(l_objRow["s_Code"].ToString().Trim(), Convert.ToInt32(l_objRow["n_MakerUser"]));
                l_objClient.IsCheckerView = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }

            l_objClient.ClientName = l_objRow["s_Name"].ToString().Trim();

            frmUCCClientInfo l_objfrmUCCClientInfo = new frmUCCClientInfo(l_objClient);
            l_objfrmUCCClientInfo.StartPosition = FormStartPosition.CenterScreen;
            l_objfrmUCCClientInfo.Icon = this.Icon;
            l_objfrmUCCClientInfo.ShowDialog();

            return 0;
        }
        #endregion

        /// <summary>
        /// Handle the double click event to open the client window in view mode
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        #region dgvAuth_DoubleClick
        private void dgvAuth_DoubleClick(object sender, EventArgs e)
        {
            HitTestInfo l_htiInfo = dgvAuth.HitTest(dgvAuth.PointToClient(Cursor.Position));

            if (
                (l_htiInfo.Column < dgvAuth.Cols.Fixed)
                || (l_htiInfo.Column > dgvAuth.Cols.Count)
                || (l_htiInfo.Row < dgvAuth.Rows.Fixed)
                || (l_htiInfo.Row > dgvAuth.Rows.Count)
               )
            {
                return;
            }
            this.OpenCheckerViewWindow();
        }
        #endregion
        
        /// <summary>
        /// Handle the click event of btnCheckerView to open the client window in view mode
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        #region btnCheckerView_Click
        private void btnCheckerView_Click(object sender, EventArgs e)
        {
            if (dgvAuth.Rows.Selected.Count != 1)
            {
                MessageBox.Show("Select a record to view", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                dgvAuth.Focus();
                return;
            }
            this.OpenCheckerViewWindow();
        }
        #endregion 

        /// <summary>
        /// Open the respective entity window based on selected entity.
        /// </summary>
        #region OpenCheckerViewWindow
        private void OpenCheckerViewWindow()
        {
            if (Convert.ToInt32(cboEntityType.SelectedValue) == 1) //Client window opening
            {
                this.OpenClientDetailsWindow();
            }
        }
        #endregion 
        #endregion
    }
}
