﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using UCC.Class;
using System.Collections;
using C1.Win.C1FlexGrid;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;
using MatchCommon;
using System.Configuration;

using UCC.Forms.UCCClient;
using UCC.Class.Master;

namespace UCC.Forms
{
    /// <summary>
    /// Client Info screen to modify various client details like basic, exchange mapping, address...
    /// This screen loads various user controls for functionalities mentioned above.
    /// </summary>
    public partial class frmUCCClientInfo : Form
    {
        public enum UITab
        {
            MainInfo,
            ExchangeMapping,
            Address,
            DP,
            Bank
        }

        #region Variables

        /// <summary>
        /// Context client instance
        /// </summary>
        private CClient m_objCurrentClient;

        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="p_vobjCurrentClient"></param>
        #region Constructor
        public frmUCCClientInfo(CClient p_vobjCurrentClient)
        {
            InitializeComponent();

            menuClientInfo.Visible = false;
            m_objCurrentClient = p_vobjCurrentClient;
        } 
        #endregion

        #region Events

        /// <summary>
        /// Window load event handler. 
        /// Initializes tab control tab pages loading Client basic details, exchange mapping and address user controls.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region UCCClientInfo_Load
        private void UCCClientInfo_Load(object sender, EventArgs e)
        {
            lblClientInfo.Text = m_objCurrentClient.ClientCode + " - " + m_objCurrentClient.ClientName;
            if (m_objCurrentClient.IsPendingAuth)
            {
                if(m_objCurrentClient.AllowModificationsToCurrentUser)
                    lblClientInfo.Text += " - " + CUCCConstants.Instance.AUTH_RECORD_AVAILABLE_FOR_CHANGES_MSG;
                else
                    lblClientInfo.Text += " - " + CUCCConstants.Instance.AUTH_RECORD_UNAVAILABLE_FOR_CHANGES_MSG;
            }

            UCCClientInfoMain l_objClientInfo = new UCCClientInfoMain(m_objCurrentClient);
            l_objClientInfo.Dock = DockStyle.Fill;            
            PageClientDetails.Controls.Add(l_objClientInfo);
            PageClientDetails.Tag = l_objClientInfo;
            
            UCCClientExchangeInfo l_objExchInfo = new UCCClientExchangeInfo(m_objCurrentClient);
            l_objExchInfo.Dock = DockStyle.Fill;
            PageClientExchangeMapping.Controls.Add(l_objExchInfo);
            PageClientExchangeMapping.Tag = l_objExchInfo;

            UCCClientAddressInfo l_objAddrInfo = new UCCClientAddressInfo(m_objCurrentClient);
            l_objAddrInfo.Dock = DockStyle.Fill;
            pageAddress.Controls.Add(l_objAddrInfo);
            pageAddress.Tag = l_objAddrInfo;

            UCCClientDP l_objClientDP = new UCCClientDP(m_objCurrentClient);
            l_objClientDP.Dock = DockStyle.Fill;
            pageDP.Controls.Add(l_objClientDP);
            pageDP.Tag = l_objClientDP;

            UCCClientBank l_objClientBank = new UCCClientBank(m_objCurrentClient);
            l_objClientBank.Dock = DockStyle.Fill;
            pageBank.Controls.Add(l_objClientBank);
            pageBank.Tag = l_objClientBank;

            string l_FEValidateON ="N";
            Object  l_ObjAppConfig = ConfigurationSettings.AppSettings["FEValidateON"];
            if (l_ObjAppConfig != null)
                l_FEValidateON = Convert.ToString(l_ObjAppConfig);

            if (l_FEValidateON == "Y")
            {
                ValidateClient l_objValidateClient = new ValidateClient(m_objCurrentClient, this);
                l_objValidateClient.Dock = DockStyle.Fill;
                pageValidate.Controls.Add(l_objValidateClient);
                pageValidate.Tag = l_objValidateClient;
            }
            else
            {
                tbUCCClientInfo.TabPages.Remove(pageValidate);
            }

            
        }
        #endregion

        /// <summary>
        /// Closes current window
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnClose_Click
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion

        /// <summary>
        /// Window key up event handler.
        /// Calls various operations based on key pressed & current user control.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region frmUCCClientInfo_KeyUp
        private void frmUCCClientInfo_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control)
            {
                IEventInfo l_objCurrentUserControl = tbUCCClientInfo.SelectedTab.Tag as IEventInfo;
                if (l_objCurrentUserControl != null)
                {
                    switch (e.KeyCode)
                    {
                        case Keys.F:
                            l_objCurrentUserControl.Filter();
                            break;
                        case Keys.R:
                            l_objCurrentUserControl.RefreshData();
                            break;
                        case Keys.A:
                            l_objCurrentUserControl.AddRecord();
                            break;
                        case Keys.M:
                            l_objCurrentUserControl.ModifyRecord();
                            break;
                        case Keys.D:
                            l_objCurrentUserControl.DeleteRecord();
                            break;
                        case Keys.S:
                            l_objCurrentUserControl.SaveData();
                            break;
                        case Keys.X:
                            l_objCurrentUserControl.Exit();
                            break;
                    }
                }
            }
            else if (e.Modifiers == Keys.None)
            {
                if (e.KeyCode == Keys.Escape)
                    btnClose_Click(this, EventArgs.Empty);
            }
        }
        #endregion

        #region Methods

        #region SelectUITab
        internal void SelectUITab(UITab Tab)
        {
            switch (Tab)
            {
                case UITab.MainInfo:
                    tbUCCClientInfo.SelectedTab = PageClientDetails;
                    break;
                case UITab.ExchangeMapping:
                    tbUCCClientInfo.SelectedTab = PageClientExchangeMapping;
                    break;
                case UITab.Address:
                    tbUCCClientInfo.SelectedTab = pageAddress;
                    break;
                case UITab.DP:
                    tbUCCClientInfo.SelectedTab = pageDP;
                    break;
                case UITab.Bank:
                    tbUCCClientInfo.SelectedTab = pageBank;
                    break;
            }
        }
        #endregion

        private void tbUCCClientInfo_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            if (tbUCCClientInfo.SelectedIndex == 0)
            {
             UCCClientInfoMain l_objClientInfo = (UCCClientInfoMain)PageClientDetails.Controls[0];
             if (m_objCurrentClient.IsPendingAuth)
                 l_objClientInfo.btnMakerCancel.Visible = true;
             else
                 l_objClientInfo.btnMakerCancel.Visible = false;
            }
        }

        #endregion

        #endregion
    }
}
