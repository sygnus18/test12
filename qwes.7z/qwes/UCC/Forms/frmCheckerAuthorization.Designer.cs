﻿namespace UCC.Forms
{
    partial class frmCheckerAuthorization
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCheckerAuthorization));
            this.btnAuthorization = new System.Windows.Forms.Button();
            this.cboAuthStatus = new MatchCommon.CustomControls.FTComboBox();
            this.ftLabel17 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel59 = new MatchCommon.CustomControls.FTLabel();
            this.cboEntityType = new MatchCommon.CustomControls.FTComboBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.ftLabel1 = new MatchCommon.CustomControls.FTLabel();
            this.dtpMakerDate = new System.Windows.Forms.DateTimePicker();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.txtRemarks = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel2 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel5 = new MatchCommon.CustomControls.FTLabel();
            this.chkSelectAll = new MatchCommon.CustomControls.FTCheckBox();
            this.ftLabel3 = new MatchCommon.CustomControls.FTLabel();
            this.cboMaker = new MatchCommon.CustomControls.FTComboBox();
            this.btnRetrieve = new System.Windows.Forms.Button();
            this.pnlFill = new System.Windows.Forms.Panel();
            this.dgvAuth = new MatchCommon.CustomControls.FTDataGrid();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.btnReject = new System.Windows.Forms.Button();
            this.lblNoOfRecords = new MatchCommon.CustomControls.FTLabel();
            this.btnCheckerView = new System.Windows.Forms.Button();
            this.pnlTop.SuspendLayout();
            this.pnlFill.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAuth)).BeginInit();
            this.pnlBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnAuthorization
            // 
            this.btnAuthorization.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAuthorization.BackColor = System.Drawing.Color.Transparent;
            this.btnAuthorization.Enabled = false;
            this.btnAuthorization.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAuthorization.Image = ((System.Drawing.Image)(resources.GetObject("btnAuthorization.Image")));
            this.btnAuthorization.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAuthorization.Location = new System.Drawing.Point(603, 8);
            this.btnAuthorization.Name = "btnAuthorization";
            this.btnAuthorization.Size = new System.Drawing.Size(73, 23);
            this.btnAuthorization.TabIndex = 0;
            this.btnAuthorization.Text = "&Authorize";
            this.btnAuthorization.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAuthorization.UseVisualStyleBackColor = false;
            this.btnAuthorization.Click += new System.EventHandler(this.btnAuthorization_Click);
            // 
            // cboAuthStatus
            // 
            this.cboAuthStatus.BackColor = System.Drawing.Color.White;
            this.cboAuthStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboAuthStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboAuthStatus.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboAuthStatus.ForeColor = System.Drawing.Color.Black;
            this.cboAuthStatus.FormattingEnabled = true;
            this.cboAuthStatus.Location = new System.Drawing.Point(76, 33);
            this.cboAuthStatus.MaxLength = 25;
            this.cboAuthStatus.Name = "cboAuthStatus";
            this.cboAuthStatus.ReadOnly = false;
            this.cboAuthStatus.Size = new System.Drawing.Size(131, 20);
            this.cboAuthStatus.TabIndex = 3;
            // 
            // ftLabel17
            // 
            this.ftLabel17.AllowForeColorChange = false;
            this.ftLabel17.AutoSize = true;
            this.ftLabel17.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel17.ForeColor = System.Drawing.Color.Black;
            this.ftLabel17.Location = new System.Drawing.Point(39, 36);
            this.ftLabel17.Name = "ftLabel17";
            this.ftLabel17.OverrideDefault = false;
            this.ftLabel17.Size = new System.Drawing.Size(32, 12);
            this.ftLabel17.TabIndex = 10;
            this.ftLabel17.Text = "Status";
            // 
            // ftLabel59
            // 
            this.ftLabel59.AllowForeColorChange = false;
            this.ftLabel59.AutoSize = true;
            this.ftLabel59.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel59.ForeColor = System.Drawing.Color.Black;
            this.ftLabel59.Location = new System.Drawing.Point(14, 9);
            this.ftLabel59.Name = "ftLabel59";
            this.ftLabel59.OverrideDefault = false;
            this.ftLabel59.Size = new System.Drawing.Size(57, 12);
            this.ftLabel59.TabIndex = 4;
            this.ftLabel59.Text = "Entity Type";
            // 
            // cboEntityType
            // 
            this.cboEntityType.BackColor = System.Drawing.Color.White;
            this.cboEntityType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboEntityType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboEntityType.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboEntityType.ForeColor = System.Drawing.Color.Black;
            this.cboEntityType.FormattingEnabled = true;
            this.cboEntityType.Location = new System.Drawing.Point(76, 6);
            this.cboEntityType.MaxLength = 25;
            this.cboEntityType.Name = "cboEntityType";
            this.cboEntityType.ReadOnly = false;
            this.cboEntityType.Size = new System.Drawing.Size(131, 20);
            this.cboEntityType.TabIndex = 0;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.BackColor = System.Drawing.Color.Transparent;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.Image")));
            this.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancel.Location = new System.Drawing.Point(755, 8);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(67, 23);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "&Close";
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // ftLabel1
            // 
            this.ftLabel1.AllowForeColorChange = false;
            this.ftLabel1.AutoSize = true;
            this.ftLabel1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel1.ForeColor = System.Drawing.Color.Black;
            this.ftLabel1.Location = new System.Drawing.Point(534, 9);
            this.ftLabel1.Name = "ftLabel1";
            this.ftLabel1.OverrideDefault = false;
            this.ftLabel1.Size = new System.Drawing.Size(56, 12);
            this.ftLabel1.TabIndex = 0;
            this.ftLabel1.Text = "Maker Date";
            // 
            // dtpMakerDate
            // 
            this.dtpMakerDate.CalendarForeColor = System.Drawing.Color.Black;
            this.dtpMakerDate.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpMakerDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpMakerDate.Location = new System.Drawing.Point(599, 6);
            this.dtpMakerDate.Name = "dtpMakerDate";
            this.dtpMakerDate.Size = new System.Drawing.Size(103, 21);
            this.dtpMakerDate.TabIndex = 2;
            // 
            // pnlTop
            // 
            this.pnlTop.Controls.Add(this.txtRemarks);
            this.pnlTop.Controls.Add(this.ftLabel2);
            this.pnlTop.Controls.Add(this.ftLabel5);
            this.pnlTop.Controls.Add(this.chkSelectAll);
            this.pnlTop.Controls.Add(this.ftLabel3);
            this.pnlTop.Controls.Add(this.cboMaker);
            this.pnlTop.Controls.Add(this.btnRetrieve);
            this.pnlTop.Controls.Add(this.cboEntityType);
            this.pnlTop.Controls.Add(this.ftLabel17);
            this.pnlTop.Controls.Add(this.cboAuthStatus);
            this.pnlTop.Controls.Add(this.ftLabel59);
            this.pnlTop.Controls.Add(this.ftLabel1);
            this.pnlTop.Controls.Add(this.dtpMakerDate);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(840, 80);
            this.pnlTop.TabIndex = 0;
            // 
            // txtRemarks
            // 
            this.txtRemarks.AllowAlpha = true;
            this.txtRemarks.AllowDot = true;
            this.txtRemarks.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtRemarks.AllowedCustomCharacters")));
            this.txtRemarks.AllowNonASCII = true;
            this.txtRemarks.AllowNumeric = true;
            this.txtRemarks.AllowSpace = true;
            this.txtRemarks.AllowSpecialChars = true;
            this.txtRemarks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtRemarks.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtRemarks.ForeColor = System.Drawing.Color.Black;
            this.txtRemarks.IsEmailID = false;
            this.txtRemarks.IsEmailIdValid = false;
            this.txtRemarks.Location = new System.Drawing.Point(314, 34);
            this.txtRemarks.MaxLength = 100;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Size = new System.Drawing.Size(389, 20);
            this.txtRemarks.TabIndex = 4;
            // 
            // ftLabel2
            // 
            this.ftLabel2.AllowForeColorChange = false;
            this.ftLabel2.AutoSize = true;
            this.ftLabel2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel2.ForeColor = System.Drawing.Color.Black;
            this.ftLabel2.Location = new System.Drawing.Point(231, 36);
            this.ftLabel2.Name = "ftLabel2";
            this.ftLabel2.OverrideDefault = false;
            this.ftLabel2.Size = new System.Drawing.Size(77, 12);
            this.ftLabel2.TabIndex = 17;
            this.ftLabel2.Text = "Default Remarks";
            // 
            // ftLabel5
            // 
            this.ftLabel5.AllowForeColorChange = false;
            this.ftLabel5.AutoSize = true;
            this.ftLabel5.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel5.ForeColor = System.Drawing.Color.Black;
            this.ftLabel5.Location = new System.Drawing.Point(26, 61);
            this.ftLabel5.Name = "ftLabel5";
            this.ftLabel5.OverrideDefault = false;
            this.ftLabel5.Size = new System.Drawing.Size(45, 12);
            this.ftLabel5.TabIndex = 14;
            this.ftLabel5.Text = "Select All";
            // 
            // chkSelectAll
            // 
            this.chkSelectAll.AutoSize = true;
            this.chkSelectAll.ForeColor = System.Drawing.Color.Black;
            this.chkSelectAll.Location = new System.Drawing.Point(77, 61);
            this.chkSelectAll.Name = "chkSelectAll";
            this.chkSelectAll.Size = new System.Drawing.Size(15, 14);
            this.chkSelectAll.TabIndex = 6;
            this.chkSelectAll.UseVisualStyleBackColor = true;
            this.chkSelectAll.CheckedChanged += new System.EventHandler(this.chkSelectAll_CheckedChanged);
            // 
            // ftLabel3
            // 
            this.ftLabel3.AllowForeColorChange = false;
            this.ftLabel3.AutoSize = true;
            this.ftLabel3.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel3.ForeColor = System.Drawing.Color.Black;
            this.ftLabel3.Location = new System.Drawing.Point(274, 9);
            this.ftLabel3.Name = "ftLabel3";
            this.ftLabel3.OverrideDefault = false;
            this.ftLabel3.Size = new System.Drawing.Size(33, 12);
            this.ftLabel3.TabIndex = 12;
            this.ftLabel3.Text = "Maker";
            // 
            // cboMaker
            // 
            this.cboMaker.BackColor = System.Drawing.Color.White;
            this.cboMaker.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMaker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboMaker.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboMaker.ForeColor = System.Drawing.Color.Black;
            this.cboMaker.FormattingEnabled = true;
            this.cboMaker.Location = new System.Drawing.Point(316, 6);
            this.cboMaker.MaxLength = 25;
            this.cboMaker.Name = "cboMaker";
            this.cboMaker.ReadOnly = false;
            this.cboMaker.Size = new System.Drawing.Size(186, 20);
            this.cboMaker.TabIndex = 1;
            // 
            // btnRetrieve
            // 
            this.btnRetrieve.BackColor = System.Drawing.Color.Transparent;
            this.btnRetrieve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRetrieve.Image = ((System.Drawing.Image)(resources.GetObject("btnRetrieve.Image")));
            this.btnRetrieve.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRetrieve.Location = new System.Drawing.Point(726, 33);
            this.btnRetrieve.Name = "btnRetrieve";
            this.btnRetrieve.Size = new System.Drawing.Size(97, 23);
            this.btnRetrieve.TabIndex = 5;
            this.btnRetrieve.Text = "&Retrieve";
            this.btnRetrieve.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRetrieve.UseVisualStyleBackColor = false;
            this.btnRetrieve.Click += new System.EventHandler(this.btnRetrieve_Click);
            // 
            // pnlFill
            // 
            this.pnlFill.Controls.Add(this.dgvAuth);
            this.pnlFill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlFill.Location = new System.Drawing.Point(0, 80);
            this.pnlFill.Name = "pnlFill";
            this.pnlFill.Size = new System.Drawing.Size(840, 374);
            this.pnlFill.TabIndex = 17;
            // 
            // dgvAuth
            // 
            this.dgvAuth.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
            this.dgvAuth.AllowEditing = false;
            this.dgvAuth.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
            this.dgvAuth.BackColor = System.Drawing.Color.Transparent;
            this.dgvAuth.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.dgvAuth.ColumnInfo = "10,1,0,0,0,85,Columns:0{Width:30;}\t";
            this.dgvAuth.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAuth.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
            this.dgvAuth.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvAuth.ForeColor = System.Drawing.Color.Black;
            this.dgvAuth.KeyActionEnter = C1.Win.C1FlexGrid.KeyActionEnum.None;
            this.dgvAuth.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
            this.dgvAuth.Location = new System.Drawing.Point(0, 0);
            this.dgvAuth.Name = "dgvAuth";
            this.dgvAuth.OverrideDefault = false;
            this.dgvAuth.Rows.Count = 1;
            this.dgvAuth.Rows.DefaultSize = 17;
            this.dgvAuth.Rows.MinSize = 25;
            this.dgvAuth.RowsFilter.AddFilterRow = false;
            this.dgvAuth.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.ListBox;
            this.dgvAuth.Size = new System.Drawing.Size(840, 374);
            this.dgvAuth.StyleInfo = resources.GetString("dgvAuth.StyleInfo");
            this.dgvAuth.TabIndex = 0;
            this.dgvAuth.DoubleClick += new System.EventHandler(this.dgvAuth_DoubleClick);
            // 
            // pnlBottom
            // 
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom.Controls.Add(this.btnCheckerView);
            this.pnlBottom.Controls.Add(this.btnReject);
            this.pnlBottom.Controls.Add(this.lblNoOfRecords);
            this.pnlBottom.Controls.Add(this.btnCancel);
            this.pnlBottom.Controls.Add(this.btnAuthorization);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 454);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(840, 38);
            this.pnlBottom.TabIndex = 17;
            // 
            // btnReject
            // 
            this.btnReject.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReject.BackColor = System.Drawing.Color.Transparent;
            this.btnReject.Enabled = false;
            this.btnReject.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReject.Image = ((System.Drawing.Image)(resources.GetObject("btnReject.Image")));
            this.btnReject.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReject.Location = new System.Drawing.Point(684, 8);
            this.btnReject.Name = "btnReject";
            this.btnReject.Size = new System.Drawing.Size(63, 23);
            this.btnReject.TabIndex = 1;
            this.btnReject.Text = "Re&ject";
            this.btnReject.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnReject.UseVisualStyleBackColor = false;
            this.btnReject.Click += new System.EventHandler(this.btnReject_Click);
            // 
            // lblNoOfRecords
            // 
            this.lblNoOfRecords.AllowForeColorChange = false;
            this.lblNoOfRecords.AutoSize = true;
            this.lblNoOfRecords.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblNoOfRecords.ForeColor = System.Drawing.Color.Black;
            this.lblNoOfRecords.Location = new System.Drawing.Point(34, 12);
            this.lblNoOfRecords.Name = "lblNoOfRecords";
            this.lblNoOfRecords.OverrideDefault = false;
            this.lblNoOfRecords.Size = new System.Drawing.Size(67, 12);
            this.lblNoOfRecords.TabIndex = 17;
            this.lblNoOfRecords.Text = "No of records";
            // 
            // btnCheckerView
            // 
            this.btnCheckerView.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCheckerView.BackColor = System.Drawing.Color.Transparent;
            this.btnCheckerView.Enabled = false;
            this.btnCheckerView.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCheckerView.Image = ((System.Drawing.Image)(resources.GetObject("btnCheckerView.Image")));
            this.btnCheckerView.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCheckerView.Location = new System.Drawing.Point(525, 8);
            this.btnCheckerView.Name = "btnCheckerView";
            this.btnCheckerView.Size = new System.Drawing.Size(70, 23);
            this.btnCheckerView.TabIndex = 18;
            this.btnCheckerView.Text = "&View";
            this.btnCheckerView.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCheckerView.UseVisualStyleBackColor = false;
            this.btnCheckerView.Click += new System.EventHandler(this.btnCheckerView_Click);
            // 
            // frmCheckerAuthorization
            // 
            this.AcceptButton = this.btnRetrieve;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(840, 492);
            this.Controls.Add(this.pnlFill);
            this.Controls.Add(this.pnlBottom);
            this.Controls.Add(this.pnlTop);
            this.Name = "frmCheckerAuthorization";
            this.ShowInTaskbar = false;
            this.Text = "Authorization";
            this.Load += new System.EventHandler(this.frmCheckerAuthorization_Load);
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlFill.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAuth)).EndInit();
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAuthorization;
        private MatchCommon.CustomControls.FTComboBox cboAuthStatus;
        private MatchCommon.CustomControls.FTLabel ftLabel17;
        private MatchCommon.CustomControls.FTLabel ftLabel59;
        private MatchCommon.CustomControls.FTComboBox cboEntityType;
        private System.Windows.Forms.Button btnCancel;
        private MatchCommon.CustomControls.FTLabel ftLabel1;
        private System.Windows.Forms.DateTimePicker dtpMakerDate;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Panel pnlFill;
        private System.Windows.Forms.Panel pnlBottom;
        private MatchCommon.CustomControls.FTDataGrid dgvAuth;
        private System.Windows.Forms.Button btnRetrieve;
        private MatchCommon.CustomControls.FTLabel ftLabel3;
        private MatchCommon.CustomControls.FTComboBox cboMaker;
        private MatchCommon.CustomControls.FTCheckBox chkSelectAll;
        private MatchCommon.CustomControls.FTLabel ftLabel5;
        private MatchCommon.CustomControls.FTLabel lblNoOfRecords;
        private MatchCommon.CustomControls.FTLabel ftLabel2;
        private MatchCommon.CustomControls.FTTextBox txtRemarks;
        private System.Windows.Forms.Button btnReject;
        private System.Windows.Forms.Button btnCheckerView;
    }
}