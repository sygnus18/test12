﻿namespace UCC.Forms
{
    partial class frmSearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSearch));
            this.ftTop = new MatchCommon.CustomControls.FTPanel();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnApply = new System.Windows.Forms.Button();
            this.ftLabel30 = new MatchCommon.CustomControls.FTLabel();
            this.txtSearch = new MatchCommon.CustomControls.FTTextBox();
            this.pnlSearchGrid = new MatchCommon.CustomControls.FTPanel();
            this.dgvSearchGrid = new MatchCommon.CustomControls.FTDataGrid();
            this.ftTop.SuspendLayout();
            this.pnlSearchGrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSearchGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // ftTop
            // 
            this.ftTop.Controls.Add(this.btnClose);
            this.ftTop.Controls.Add(this.btnApply);
            this.ftTop.Controls.Add(this.ftLabel30);
            this.ftTop.Controls.Add(this.txtSearch);
            this.ftTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.ftTop.Location = new System.Drawing.Point(0, 0);
            this.ftTop.Name = "ftTop";
            this.ftTop.Size = new System.Drawing.Size(491, 49);
            this.ftTop.TabIndex = 0;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Transparent;
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.Location = new System.Drawing.Point(384, 13);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "&Close";
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnApply
            // 
            this.btnApply.BackColor = System.Drawing.Color.Transparent;
            this.btnApply.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnApply.Image = ((System.Drawing.Image)(resources.GetObject("btnApply.Image")));
            this.btnApply.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnApply.Location = new System.Drawing.Point(285, 13);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new System.Drawing.Size(75, 23);
            this.btnApply.TabIndex = 2;
            this.btnApply.Text = "&Apply";
            this.btnApply.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnApply.UseVisualStyleBackColor = false;
            this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
            // 
            // ftLabel30
            // 
            this.ftLabel30.AllowForeColorChange = false;
            this.ftLabel30.AutoSize = true;
            this.ftLabel30.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel30.ForeColor = System.Drawing.Color.Black;
            this.ftLabel30.Location = new System.Drawing.Point(21, 19);
            this.ftLabel30.Name = "ftLabel30";
            this.ftLabel30.OverrideDefault = false;
            this.ftLabel30.Size = new System.Drawing.Size(29, 12);
            this.ftLabel30.TabIndex = 0;
            this.ftLabel30.Text = "Code";
            // 
            // txtSearch
            // 
            this.txtSearch.AllowAlpha = true;
            this.txtSearch.AllowDot = true;
            this.txtSearch.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtSearch.AllowedCustomCharacters")));
            this.txtSearch.AllowNonASCII = false;
            this.txtSearch.AllowNumeric = true;
            this.txtSearch.AllowSpace = true;
            this.txtSearch.AllowSpecialChars = true;
            this.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSearch.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtSearch.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtSearch.ForeColor = System.Drawing.Color.Black;
            this.txtSearch.IsEmailID = true;
            this.txtSearch.IsEmailIdValid = false;
            this.txtSearch.Location = new System.Drawing.Point(68, 14);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(155, 20);
            this.txtSearch.TabIndex = 1;
            this.txtSearch.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtSearch_KeyUp);
            // 
            // pnlSearchGrid
            // 
            this.pnlSearchGrid.BackColor = System.Drawing.Color.Transparent;
            this.pnlSearchGrid.Controls.Add(this.dgvSearchGrid);
            this.pnlSearchGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlSearchGrid.Location = new System.Drawing.Point(0, 49);
            this.pnlSearchGrid.Name = "pnlSearchGrid";
            this.pnlSearchGrid.Size = new System.Drawing.Size(491, 486);
            this.pnlSearchGrid.TabIndex = 5;
            // 
            // dgvSearchGrid
            // 
            this.dgvSearchGrid.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
            this.dgvSearchGrid.AllowEditing = false;
            this.dgvSearchGrid.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
            this.dgvSearchGrid.BackColor = System.Drawing.Color.Transparent;
            this.dgvSearchGrid.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.dgvSearchGrid.ColumnInfo = "10,1,0,0,0,85,Columns:0{Width:30;}\t";
            this.dgvSearchGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSearchGrid.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
            this.dgvSearchGrid.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvSearchGrid.ForeColor = System.Drawing.Color.Black;
            this.dgvSearchGrid.KeyActionEnter = C1.Win.C1FlexGrid.KeyActionEnum.None;
            this.dgvSearchGrid.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
            this.dgvSearchGrid.Location = new System.Drawing.Point(0, 0);
            this.dgvSearchGrid.Name = "dgvSearchGrid";
            this.dgvSearchGrid.OverrideDefault = false;
            this.dgvSearchGrid.Rows.Count = 1;
            this.dgvSearchGrid.Rows.DefaultSize = 17;
            this.dgvSearchGrid.Rows.MinSize = 25;
            this.dgvSearchGrid.RowsFilter.AddFilterRow = false;
            this.dgvSearchGrid.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.ListBox;
            this.dgvSearchGrid.Size = new System.Drawing.Size(491, 486);
            this.dgvSearchGrid.StyleInfo = resources.GetString("dgvSearchGrid.StyleInfo");
            this.dgvSearchGrid.TabIndex = 0;
            this.dgvSearchGrid.DoubleClick += new System.EventHandler(this.dgvSearchGrid_DoubleClick);
            this.dgvSearchGrid.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvSearchGrid_KeyUp);
            // 
            // frmSearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(491, 535);
            this.Controls.Add(this.pnlSearchGrid);
            this.Controls.Add(this.ftTop);
            this.MaximizeBox = false;
            this.Name = "frmSearch";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Search Window";
            this.Load += new System.EventHandler(this.frmSearch_Load);
            this.Shown += new System.EventHandler(frmSearch_Shown);
            this.ftTop.ResumeLayout(false);
            this.ftTop.PerformLayout();
            this.pnlSearchGrid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSearchGrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MatchCommon.CustomControls.FTPanel pnlSearchGrid;
        private MatchCommon.CustomControls.FTPanel ftTop;
        private System.Windows.Forms.Button btnApply;
        private MatchCommon.CustomControls.FTLabel ftLabel30;
        private MatchCommon.CustomControls.FTTextBox txtSearch;
        private MatchCommon.CustomControls.FTDataGrid dgvSearchGrid;
        private System.Windows.Forms.Button btnClose;

    }
}