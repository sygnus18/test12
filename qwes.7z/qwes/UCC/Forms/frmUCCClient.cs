﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using System.Drawing;
using System.Text;
using UCC.Class;
using C1.Win.C1FlexGrid;
using System.Collections;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;
using MatchCommon;
using UCC.Class.Master;

namespace UCC.Forms
{
    /// <summary>
    /// UCC Client main window to display records in grid view
    /// </summary>
    public partial class frmUCCClient : Form
    {
        #region Variables

        /// <summary>
        /// UCC Client BL class instance
        /// </summary>
        private CUCCClient m_objUCCClient;

        /// <summary>
        /// Filter parameters
        /// </summary>
        private FilterParameters m_objFilterParams;

        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        #region Constructor
        public frmUCCClient()
        {
            InitializeComponent();

            dgvClient.OverrideDefault = true;
            dgvClient.Styles.Normal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dgvClient.Styles.Alternate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            
            m_objUCCClient = new CUCCClient();
        } 
        #endregion

        #region Events

        /// <summary>
        /// Window load event handler. Initializes controls.
        /// Retrieves data applying search text filter.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region UCCClient_Load
		private void UCCClient_Load(object sender, EventArgs e)
        {
            lblNoOfRecords.Text = string.Empty;

            menuUCCClient.Cancel.Visible = false;
            menuUCCClient.Legends.Visible = false;
            menuUCCClient.Help.Visible = false;
            menuUCCClient.New.Visible = false;
            menuUCCClient.Delete.Visible = false;
            menuUCCClient.Save.Visible = false;
            
            menuUCCClient.Modify.Click += Modify_Click;
            menuUCCClient.View.Click += View_Click;
            menuUCCClient.Filter.Click += Filter_Click;
            menuUCCClient.Exit.Click += Exit_Click;

            picProcessRunning.Visible = false;
            //RefreshData();
        }
     	#endregion
        
        /// <summary>
        /// Windows Form 'Shown' event handler to popup Client filter window after successful form rendering
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        #region UCCClient_Shown
        private void UCCClient_Shown(object sender, EventArgs e)
        {
            Filter_Click(sender, e);
        }
        #endregion

        /// <summary>
        /// New menu button click event handler.
        /// Prepares fields for new data clearing them and populating with default values.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region New_Click (not used)
        private void New_Click(object sender, EventArgs e)
        {
            //AddData();
        }
        #endregion

        /// <summary>
        /// Refresh button click event handler. Retrieves data from database again.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region View_Click
        private void View_Click(object sender, EventArgs e)
        {
            ViewData();
        }
        #endregion

        /// <summary>
        /// Modify button click event handler. 
        /// Opens current selected record in Client modification window
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region Modify_Click
        private void Modify_Click(object sender, EventArgs e)
        {
            OpenClientDetailsWindow();            
        }
        #endregion

        /// <summary>
        /// Filter menu button click event handler.
        /// Opens filter window.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region Filter_Click
        private void Filter_Click(object sender, EventArgs e)
        {
            if (FilterData() == 0)
            {
                RefreshData();
            }
        }
        #endregion

        /// <summary>
        /// Delete menu button click event handler.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region Delete_Click (not used)
        private void Delete_Click(object sender, EventArgs e)
        {
            //DeleteData();
        }
        #endregion

        /// <summary>
        /// Closes current window
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region Exit_Click
        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();

        }
        #endregion

        /// <summary>
        /// Grid double click event handler.
        /// Redirects to OpenClientDetailsWindow method to open client details window.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region dgvClient_DoubleClick
        private void dgvClient_DoubleClick(object sender, EventArgs e)
        {
            HitTestInfo l_htiInfo = dgvClient.HitTest(dgvClient.PointToClient(Cursor.Position));

            if (
                (l_htiInfo.Column < dgvClient.Cols.Fixed)
                || (l_htiInfo.Column > dgvClient.Cols.Count)
                || (l_htiInfo.Row < dgvClient.Rows.Fixed)
                || (l_htiInfo.Row > dgvClient.Rows.Count)
               )
            {
                return;
            }

            OpenClientDetailsWindow();
        } 
        #endregion

        /// <summary>
        /// Grid key up event handler.
        /// Redirects to dgvClient_DoubleClick to open client details window.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region dgvClient_KeyUp
        private void dgvClient_KeyUp(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
                dgvClient_DoubleClick(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Export button click event handler.
        /// Opens UCC file export window as MDI child window.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnExport_Click
        private void btnExport_Click(object sender, EventArgs e)
        {
            CUCCCommon.Instance.OpenFormAsChild<frmClientExport>();
        }
        #endregion

        /// <summary>
        /// Import button click event handler.
        /// Synchronizes client details data with base application data using BL class.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnImport_Click
        private void btnImport_Click(object sender, EventArgs e)
        {
            btnImport.Enabled = false;
            try
            {
                if (FilterData() != 0)
                {
                    return;
                }

                DataTable l_dtSynchronizeResult = null;
                picProcessRunning.Visible = true;
                Application.DoEvents();
                Application.DoEvents();

                MethodExecResult l_objMethodExecResult = m_objUCCClient.SynchronizeClientUCCData(m_objFilterParams, false, null, ref l_dtSynchronizeResult);
                
                picProcessRunning.Visible = false;
                if (l_objMethodExecResult.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    if( (l_dtSynchronizeResult == null) || (l_dtSynchronizeResult.Rows.Count == 0) )
                    {
                        MessageBox.Show("Completed Successfully", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        frmUCCImportResult l_frmUCCImportResult = new frmUCCImportResult();
                        l_frmUCCImportResult.UCCImportResultData = l_dtSynchronizeResult;
                        l_frmUCCImportResult.Icon = this.Icon;
                        l_frmUCCImportResult.ShowDialog();
                    }
                }
                else
                {
                    Logger.Instance.WriteLog(this, l_objMethodExecResult);
                    MessageBox.Show(l_objMethodExecResult.ErrorMessage, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            finally
            {
                btnImport.Enabled = true;
                picProcessRunning.Visible = false;
            }
        }
        #endregion

        /// <summary>
        /// Upload Response button click event handler.
        /// Opens exchange UCC response file upload window.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnUploadResponse_Click
        private void btnUploadResponse_Click(object sender, EventArgs e)
        {
            frmUCCRejectedFileUpload l_frmUCCRejectedFileUpload = new frmUCCRejectedFileUpload();
            l_frmUCCRejectedFileUpload.StartPosition = FormStartPosition.CenterScreen;
            l_frmUCCRejectedFileUpload.Icon = this.Icon;
            l_frmUCCRejectedFileUpload.ShowDialog();
        }
        #endregion

        #endregion

        #region Methods

        /// <summary>
        /// Opens filter window passing previously selected filter parameter object
        /// </summary>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region FilterData
        private long FilterData()
        {
            frmClientFilter m_objClientFilter = new frmClientFilter();
            m_objClientFilter.FilterParams = m_objFilterParams;
            m_objClientFilter.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            m_objClientFilter.Icon = this.Icon;

            if (m_objClientFilter.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_objFilterParams = m_objClientFilter.FilterParams;
                return 0;
            }

            return 1;
        }
        #endregion

        /// <summary>
        /// Retrieves/sets data from database again for current filter parameters using RefreshData method
        /// </summary>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region ViewData
        /// <summary>
        /// user to Retrieve data on click of view. 
        /// </summary>
        /// <returns></returns>
        private long ViewData()
        {
            if (!RefreshData())
                return -1;

            return 0;
        }
        #endregion

        /// <summary>
        /// Retrieves/sets data from database again for current filter parameters
        /// </summary>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region RefreshData
        private bool RefreshData()
        {
            DataTable l_ViewData = new DataTable();
            MethodExecResult l_objMethodExceResult = m_objUCCClient.GetUCCClientFilterData(m_objFilterParams, ref l_ViewData);

            lblNoOfRecords.Text = string.Empty;
            if (l_objMethodExceResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, l_objMethodExceResult);
                MessageBox.Show(l_objMethodExceResult.ErrorMessage, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;

            }

            //if (l_lRetCode != 0)
            //{
            //    MatchCommon.CCommon.MyCommon(MatchCommon.MatchCommonModules.Cash).WriteLog("RefreshData() : RefreshData()", m_ClassName, "", "", l_sErrorMsg, null);
            //    return false;
            //}

            lblNoOfRecords.Text = "#Records: " + l_ViewData.Rows.Count.ToString();
            dgvClient.DataSource = null;
            dgvClient.DataSource = l_ViewData;
            FormatGrid();

            return true;
        }
        #endregion

        /// <summary>
        /// Opens client details window for modification
        /// </summary>
        #region OpenClientDetailsWindow
        private long OpenClientDetailsWindow()
        {
            Row l_objRow = null;
            if (dgvClient.Rows.Selected.Count != 1)
            {
                MessageBox.Show("Select Single Record for Modification", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return -1;
            }
            l_objRow = dgvClient.Rows.Selected[0];

            if (l_objRow == null)
            {
                return -1;
            }

            CClient l_objClient = null;
            try
            {
                l_objClient = new CClient(l_objRow["ClientCode"].ToString().Trim());

                Int32 l_nUserNo;
                l_nUserNo = l_objClient.IsCheckerView ? l_objClient.MakerUser : AppEnvironment.AppUser.UserNo;

                // populate Exchange collection 
                CClientExchangeCollection l_objClientExchange = new CClientExchangeCollection(l_objClient.ClientNo, l_nUserNo);
                l_objClient.ClientExchanges = l_objClientExchange.ClientExchanges;

                // populate Address collection 
                CClientAddressCollection l_objClientAddressCollection = new CClientAddressCollection(l_objClient.ClientNo, l_nUserNo);
                l_objClient.ClientAddressesNew = l_objClientAddressCollection.ClientAddressesNew;

                // populate Bank collection 
                CClientBankCollection m_objClientBank = new CClientBankCollection(l_objClient.ClientNo, l_nUserNo);
                l_objClient.ClientBanks = m_objClientBank.ClientBanks;

                // populate DP collection 
                CClientDPCollection m_objClientDP = new CClientDPCollection(l_objClient.ClientNo, l_nUserNo);
                l_objClient.ClientDPs = m_objClientDP.ClientDPs;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }

            l_objClient.ClientName = l_objRow["ClientName"].ToString().Trim();

            frmUCCClientInfo l_objfrmUCCClientInfo = new frmUCCClientInfo(l_objClient);
            l_objfrmUCCClientInfo.StartPosition = FormStartPosition.CenterScreen;
            l_objfrmUCCClientInfo.Icon = this.Icon;
            l_objfrmUCCClientInfo.ShowDialog();

            return 0;
        }
        #endregion

        /// <summary>
        /// Formats data layout of grid. Sets visible columns, their titles.
        /// </summary>
        #region FormatGrid
        /// <summary>
        /// Client Grid Formatting
        /// </summary>
        private void FormatGrid()
        {
            if (dgvClient.DataSource == null)
                return;
            if (dgvClient.Cols.Contains("ProductNo"))
                dgvClient.Cols["ProductNo"].Visible = false;
            if (dgvClient.Cols.Contains("ClientNo"))
                dgvClient.Cols["ClientNo"].Visible = false;
            if (dgvClient.Cols.Contains("ClientCode"))
                dgvClient.Cols["ClientCode"].Caption = "Client Code";
            if (dgvClient.Cols.Contains("ClientName"))
            {
                dgvClient.Cols["ClientName"].Caption = "Client Name";
                dgvClient.Cols["ClientName"].Width = 200;
            }
            if (dgvClient.Cols.Contains("ClientType"))
                dgvClient.Cols["ClientType"].Caption = "Client Type";
            if (dgvClient.Cols.Contains("PANNo"))
                dgvClient.Cols["PANNo"].Caption = "PAN";
            if (dgvClient.Cols.Contains("Gender"))
            {
                dgvClient.Cols["Gender"].Caption = "Gender";
                dgvClient.Cols["Gender"].DataMap = CReferenceDataProvider.Instance.GetHashTable(CReferenceDataProvider.ReferenceType.GENDER, CReferenceDataProvider.ReferenceFields.ReferenceName, CReferenceDataProvider.ReferenceFields.ReferenceCode);
            }
            if (dgvClient.Cols.Contains("GuardianName"))
                dgvClient.Cols["GuardianName"].Caption = "Guardian Name";
            if (dgvClient.Cols.Contains("MaritalStatus"))
            {
                dgvClient.Cols["MaritalStatus"].Caption = "Marital Status";
                dgvClient.Cols["MaritalStatus"].DataMap = CReferenceDataProvider.Instance.GetHashTable(CReferenceDataProvider.ReferenceType.MARITALST, CReferenceDataProvider.ReferenceFields.ReferenceName, CReferenceDataProvider.ReferenceFields.ReferenceCode);
            }
            if (dgvClient.Cols.Contains("Nationality"))
            {
                dgvClient.Cols["Nationality"].Caption = "Nationality";
                dgvClient.Cols["Nationality"].DataMap = CReferenceDataProvider.Instance.GetHashTable(CReferenceDataProvider.ReferenceType.NATIONALTY, CReferenceDataProvider.ReferenceFields.ReferenceName, CReferenceDataProvider.ReferenceFields.ReferenceCode);
            }
            if (dgvClient.Cols.Contains("NationalityOther"))
                dgvClient.Cols["NationalityOther"].Caption = "Nationality Name";
            if (dgvClient.Cols.Contains("PanExempt"))
            {
                dgvClient.Cols["PanExempt"].Caption = "Pan Exempt";

                Hashtable l_hstYesNo = new Hashtable();
                l_hstYesNo.Add("Y", "Yes");
                l_hstYesNo.Add("N", "No");
                dgvClient.Cols["PanExempt"].DataMap = l_hstYesNo;
            }
            if (dgvClient.Cols.Contains("CorporateIdNo"))
                dgvClient.Cols["CorporateIdNo"].Caption = "CIN No";
            if (dgvClient.Cols.Contains("d_DOB"))
                dgvClient.Cols["d_DOB"].Caption = "DOB";
            if (dgvClient.Cols.Contains("d_CreationDate"))
                dgvClient.Cols["d_CreationDate"].Caption = "Creation Date";
            if (dgvClient.Cols.Contains("NetWorth"))
                dgvClient.Cols["NetWorth"].Caption = "NetWorth";
            if (dgvClient.Cols.Contains("d_NetWorthAsOnDate"))
                dgvClient.Cols["d_NetWorthAsOnDate"].Caption = "Net Worth As On Date";
            if (dgvClient.Cols.Contains("GrAnnIncRange"))
            {
                dgvClient.Cols["GrAnnIncRange"].Caption = "Gross Annual Income Range";
                dgvClient.Cols["GrAnnIncRange"].DataMap = CReferenceDataProvider.Instance.GetHashTable(CReferenceDataProvider.ReferenceType.ANNINC, CReferenceDataProvider.ReferenceFields.ReferenceName, CReferenceDataProvider.ReferenceFields.ReferenceNo);
            }
            if (dgvClient.Cols.Contains("d_GrAnnIncAsOnDate"))
                dgvClient.Cols["d_GrAnnIncAsOnDate"].Caption = "Gross Annual Income As On Date";
            if (dgvClient.Cols.Contains("PEP"))
            {
                dgvClient.Cols["PEP"].Caption = "PEP";
                dgvClient.Cols["PEP"].DataMap = CReferenceDataProvider.Instance.GetHashTable(CReferenceDataProvider.ReferenceType.PEP, CReferenceDataProvider.ReferenceFields.ReferenceName, CReferenceDataProvider.ReferenceFields.ReferenceCode);
            }
            if (dgvClient.Cols.Contains("PlaceofIncorporation"))
                dgvClient.Cols["PlaceofIncorporation"].Caption = "Place of Incorporation";
            if (dgvClient.Cols.Contains("Occupation"))
            {
                dgvClient.Cols["Occupation"].Caption = "Occupation";
                dgvClient.Cols["Occupation"].DataMap = CReferenceDataProvider.Instance.GetHashTable(CReferenceDataProvider.ReferenceType.OCCUPATION, CReferenceDataProvider.ReferenceFields.ReferenceName, CReferenceDataProvider.ReferenceFields.ReferenceNo);
            }
            if (dgvClient.Cols.Contains("OccupationOthers"))
                dgvClient.Cols["OccupationOthers"].Caption = "Occupation Name";
            if (dgvClient.Cols.Contains("d_CommOfBusiness"))
                dgvClient.Cols["d_CommOfBusiness"].Caption = "Business Commencement";
            if (dgvClient.Cols.Contains("UCCCode"))
                dgvClient.Cols["UCCCode"].Caption = "UCC Code";
            if (dgvClient.Cols.Contains("s_Relationship"))
            {
                dgvClient.Cols["s_Relationship"].Caption = "Relationship";
                dgvClient.Cols["s_Relationship"].DataMap = CReferenceDataProvider.Instance.GetHashTable(CReferenceDataProvider.ReferenceType.RELATION, CReferenceDataProvider.ReferenceFields.ReferenceName, CReferenceDataProvider.ReferenceFields.ReferenceCode);
            }
            if (dgvClient.Cols.Contains("s_TypeofFacility"))
            {
                dgvClient.Cols["s_TypeofFacility"].Caption = "Type of Facility";
                dgvClient.Cols["s_TypeofFacility"].DataMap = CReferenceDataProvider.Instance.GetHashTable(CReferenceDataProvider.ReferenceType.FACILITY, CReferenceDataProvider.ReferenceFields.ReferenceName, CReferenceDataProvider.ReferenceFields.ReferenceCode);
            }

            if (dgvClient.Cols.Contains("s_CINExempt"))
            {
                dgvClient.Cols["s_CINExempt"].Caption = "CIN Exempt";

                Hashtable l_hstYesNo = new Hashtable();
                l_hstYesNo.Add("Y", "Yes");
                l_hstYesNo.Add("N", "No");
                dgvClient.Cols["s_CINExempt"].DataMap = l_hstYesNo;
            }
            if (dgvClient.Cols.Contains("ClientTypeCorporate"))
            {
                dgvClient.Cols["ClientTypeCorporate"].Caption = "Client Type Corporate";

                Hashtable l_hstYesNo = new Hashtable();
                l_hstYesNo.Add("Y", "Yes");
                l_hstYesNo.Add("N", "No");
                dgvClient.Cols["ClientTypeCorporate"].DataMap = l_hstYesNo;
            }
            if (dgvClient.Cols.Contains("s_UpdationFlag"))
            {
                dgvClient.Cols["s_UpdationFlag"].Caption = "Updation Flag";

                Hashtable l_hstYesNo = new Hashtable();
                l_hstYesNo.Add("Y", "Yes");
                l_hstYesNo.Add("N", "No");
                dgvClient.Cols["s_UpdationFlag"].DataMap = l_hstYesNo;
            }
        }
        #endregion

        #endregion
    }
}
