﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Collections;

using C1.Win.C1FlexGrid;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;
using FTIL.Match.Common.Utils;
using FTIL.Match.Common.Constants;
using UCC.Class;
using System.Text.RegularExpressions;
using UCC.Class.Master;

namespace UCC.Forms.UCCClient
{
    /// <summary>
    /// Client address screen user control
    /// </summary>
    public partial class UCCClientBank : UserControl, IEventInfo
    {
        #region Variables

        /// <summary>
        /// Indicates DML operation
        /// </summary>
        private MasterOperation m_objOperation;
        
        /// <summary>
        /// Instance of client address BL class
        /// </summary>
        private CClientBank m_objCurrentClientBank;

        /// <summary>
        /// ClientBank data
        /// </summary>
        private DataTable m_dtClientBankDetails;

        /// <summary>
        /// Current client
        /// </summary>
        private CClient m_objCurrentClient;

        /// <summary>
        /// Message box title
        /// </summary>
        private string m_sMsgBoxTitle;

        /// <summary>
        /// Indicates if field value changes have been initiated from internal code
        /// </summary>
        private bool m_bInternalUpdation;

        /// <summary>
        /// Indicates if current Bank value, set in Bank text box, is valid?
        /// </summary>
        private bool m_bValidBankValueSet;

        /// <summary>
        /// Collection of bank details for a selected client
        /// </summary>
        private CClientBankCollection m_objClientBank;

        #endregion

        /// <summary>
        /// Client Bank class constructor
        /// </summary>
        /// <param name="p_vobjCurrentClient">Client context instance</param>
        #region Constructor
        public UCCClientBank(CClient p_vobjCurrentClient)
        {
            InitializeComponent();

            dgvClientBank.OverrideDefault = true;
            dgvClientBank.Styles.Normal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dgvClientBank.Styles.Alternate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            
            m_objCurrentClient = p_vobjCurrentClient;
        }
        #endregion

        #region Events

        /// <summary>
        /// Window load event handler. Initializes menu, controls & loads data
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region UCCClientBankInfo_Load
        private void UCCClientBankInfo_Load(object sender, EventArgs e)
        {
            pnlActionControls.Enabled = m_objCurrentClient.AllowModificationsToCurrentUser;
            m_sMsgBoxTitle = this.ParentForm.Text + " - Bank";

            PopulateLookUp();
            View_Click(this, EventArgs.Empty);
            EnableDisableClientBankField(false);
        }
        #endregion
        
        /// <summary>
        /// Grid Row/Column changed event handler. Populates current address details in controls
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region dgvBank_RowColChange
        private void dgvBank_RowColChange(object sender, EventArgs e)
        {
            EnableDisableClientBankField(true);

            if (dgvClientBank.Rows.Selected.Count != 1)
            {
                return;
            }

            switch (m_objOperation)
            {
                case MasterOperation.Modify:
                case MasterOperation.Delete:
                case MasterOperation.View:
                    PopulateFields();
                    break;
            }
        }
        #endregion

        /// <summary>
        /// Refresh button click event handler. Retrieves data from database again.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region View_Click
        private void View_Click(object sender, EventArgs e)
        {
            m_objOperation = MasterOperation.View;
            RefreshClientBankData();
        }
        #endregion
                
        /// <summary>
        /// New button click event handler. Clears fields and activates default control.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region New_Click
        private void New_Click(object sender, EventArgs e)
        {
            m_objOperation = MasterOperation.Add;
            ClearFields();

            EnableDisableClientBankField(true);
            cboExchange.Focus();
        }
        #endregion

        /// <summary>
        /// Delete button event handler. Proceeds to perform action in database after confirming same from user.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region Delete_Click
        private void Delete_Click(object sender, EventArgs e)
        {
            if (dgvClientBank.Rows.Count == dgvClientBank.Rows.Fixed)
            {
                MessageBox.Show("Select single record!!!", m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            //DataRow[] l_dr = m_dtClientBankDetails.Select("n_ExNo = " + m_objCurrentClientBank.ExNo);

            if (chkDefault.Checked)
            {
                    MessageBox.Show("Default Bank cannot be deleted!!!", m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
            }

            if (MessageBox.Show("Are you sure you want to delete current client-Bank?", m_sMsgBoxTitle,
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.No)
            {
                return;
            }

            DeleteClientBankData();
            View_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Save button event handler. Proceeds to perform changes (Add/Modify) in database. 
        /// Refreshes data after successful completion.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region Save_Click
        private void Save_Click(object sender, EventArgs e)
        {
            if (SaveClientBankData() == 0)
            {
                View_Click(this, EventArgs.Empty);
            }
        }
        #endregion

        /// <summary>
        /// Closes parent window where this user control is hosted
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region Exit_Click
        private void Exit_Click(object sender, EventArgs e)
        {
            this.ParentForm.Close();
        }
        #endregion

        /// <summary>
        /// Default checkbox check state changed event handler.
        /// Restrains user deselecting Default checked status.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region chkDefault_CheckedChanged
        private void chkDefault_CheckedChanged(object sender, EventArgs e)
        {
            if (m_bInternalUpdation)
                return;
            if (dgvClientBank.DataSource == null)
                return;

            if (m_objOperation == MasterOperation.Add)
                return;

            if (chkDefault.Checked == false)
            {
                MessageBox.Show("Default flag cannot be removed. Please mark default to other Bank in same exchange to remove default flag of current Bank.", 
                    m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                chkDefault.Checked = true;
                return;
            }
        }
        #endregion

        /// <summary>
        /// Add button click event handler. Redirects to New_Click event handler.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnAdd_Click
        private void btnAdd_Click(object sender, EventArgs e)
        {
            New_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Delete button click event handler. Redirects to Delete_Click event handler.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnDelete_Click
        private void btnDelete_Click(object sender, EventArgs e)
        {
            Delete_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Save button click event handler. Redirects to Save_Click event handler.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnSave_Click
        private void btnSave_Click(object sender, EventArgs e)
        {
            Save_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Bank text leave event handler.
        /// Checks if valid Bank is set. If not & text is not empty, opens Bank help window.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtBank_Leave
        private void txtBank_Leave(object sender, EventArgs e)
        {
            if (txtBank.ReadOnly)
                return;

            if (txtBank.Text.Trim().Length == 0)
                return;

            if (m_bValidBankValueSet == false)
                ShowBankHelp(txtBank.Text.Trim());
        }
        #endregion

        /// <summary>
        /// Bank text box Key Up Event handler.
        /// Opens help window if F3 key is pressed.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtBank_KeyUp
        private void txtBank_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtBank.ReadOnly)
                return;

            if (e.KeyCode == Keys.F3)
                ShowBankHelp(txtBank.Text);
        }
        #endregion

        /// <summary>
        /// Bank text box text change event handler.
        /// Sets m_bValidBankValueSet to false.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtBank_TextChanged
        private void txtBank_TextChanged(object sender, EventArgs e)
        {
            m_bValidBankValueSet = false;
        }
        #endregion
        
        /// <summary>
        /// Makercancel button click event handler.redirect to CancelMakerChanges function
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">Event argument</param>
        #region btnMakerCancel_Click
        private void btnMakerCancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure to cancel maker changes?", m_sMsgBoxTitle,
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.No)
            {
                return;
            }
            this.CancelMakerChanges();
        }
        #endregion

        #endregion

        #region Methods

        /// <summary>
        /// Opens Bank help window populating records as per given Bank code
        /// </summary>
        /// <param name="p_vsBankCode">Filter Bank code</param>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region ShowBankHelp
        private long ShowBankHelp(string p_vsBankCode)
        {
            frmSearch l_objSearch = new frmSearch();
            l_objSearch.SearchTypeCurrent = frmSearch.SearchType.Bank;
            l_objSearch.SearchText = p_vsBankCode;
            l_objSearch.SearchValueCurrent = frmSearch.SearchValue.BankCode;

            if (l_objSearch.ShowDialog() == DialogResult.OK)
            {
                txtBank.Text = l_objSearch.SelectedCode;
                txtBank.Tag = l_objSearch.SelectedUniqueValue;
                m_bValidBankValueSet = true;
            }
            else
            {
                txtBank.Text = string.Empty;
                txtBank.Tag = null;
            }

            return 0;
        }
        #endregion

        /// <summary>
        /// Formats data layout of grid. Sets visible columns, their titles.
        /// </summary>
        #region FormatGrid
        private void FormatGrid()
        {
            for (int l_iColCounter = dgvClientBank.Cols.Fixed; l_iColCounter < dgvClientBank.Cols.Count; l_iColCounter++)
                dgvClientBank.Cols[l_iColCounter].Visible = false;

            if (dgvClientBank.Cols.Contains("n_ExNo"))
            {
                dgvClientBank.Cols["n_ExNo"].Visible = true;
                dgvClientBank.Cols["n_ExNo"].Caption = "Exch Code";

                dgvClientBank.Cols["n_ExNo"].DataMap = CReferenceDataProvider.Instance.GetHashTable(CReferenceDataProvider.ReferenceType.EXCH, CReferenceDataProvider.ReferenceFields.ReferenceName, CReferenceDataProvider.ReferenceFields.ReferenceCode);
            }

            if (dgvClientBank.Cols.Contains("n_BankNo"))
            {
                dgvClientBank.Cols["n_BankNo"].Visible = true;
                dgvClientBank.Cols["n_BankNo"].Caption = "Bank";

                List<CBank> l_lstAllBanks = CBankCollection.Instance.AllBank;
                Hashtable l_hstBank = new Hashtable();
                for (int l_iBankCounter = 0; l_iBankCounter < l_lstAllBanks.Count; l_iBankCounter++)
                    l_hstBank.Add(l_lstAllBanks[l_iBankCounter].BankNo, l_lstAllBanks[l_iBankCounter].BankCode);
                dgvClientBank.Cols["n_BankNo"].DataMap = l_hstBank;
            }

            if (dgvClientBank.Cols.Contains("s_AccountNo"))
            {
                dgvClientBank.Cols["s_AccountNo"].Visible = true;
                dgvClientBank.Cols["s_AccountNo"].Caption = "Account No";
            }

            if (dgvClientBank.Cols.Contains("s_Default"))
            {
                dgvClientBank.Cols["s_Default"].Visible = true;
                dgvClientBank.Cols["s_Default"].Caption = "Default";

                Hashtable l_hstYesNo = new Hashtable();
                l_hstYesNo.Add("Y", "Yes");
                l_hstYesNo.Add("N", "No");
                dgvClientBank.Cols["s_Default"].DataMap = l_hstYesNo;
            }

            if (dgvClientBank.Cols.Contains("n_AccountType"))
            {
                dgvClientBank.Cols["n_AccountType"].Visible = true;
                dgvClientBank.Cols["n_AccountType"].Caption = "Account Type";

                dgvClientBank.Cols["n_AccountType"].DataMap = CReferenceDataProvider.Instance.GetHashTable(CReferenceDataProvider.ReferenceType.BANKACCTYP, CReferenceDataProvider.ReferenceFields.ReferenceName, CReferenceDataProvider.ReferenceFields.ReferenceNo);
            }
        }
        #endregion

        /// <summary>
        /// Populates help (combo) controls with master values
        /// </summary>
        /// <returns></returns>
        #region PopulateLookUp
        private long PopulateLookUp()
        {
            cboExchange.ValueMember = "n_ExNo";
            cboExchange.DisplayMember = "s_ExCode";
            cboExchange.DataSource = CMastersDataProvider.Instance[Masters.Exchange];

            cboAccountType.ValueMember = "n_ReferenceNo";
            cboAccountType.DisplayMember = "s_ReferenceName";
            cboAccountType.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.BANKACCTYP];

            return 0;
        }
        #endregion

        /// <summary>
        /// Updates current changes to database using BL class
        /// </summary>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region SaveClientBankData
        private long SaveClientBankData()
        {
            if (
                (m_objOperation != MasterOperation.Add)
                &&
                (
                (dgvClientBank.DataSource == null)
                || (dgvClientBank.Rows.Count == dgvClientBank.Rows.Fixed)
                ))
            {
                MessageBox.Show("No data exists!!!", m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return 1;
            }

            string l_sErrorMessage = string.Empty;
            Control l_ctrlErrorControl = null;
            if (ValidateBankDetails(ref l_sErrorMessage, ref l_ctrlErrorControl) == false)
            {
                MessageBox.Show(l_sErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                if ((l_ctrlErrorControl != null) && (l_ctrlErrorControl.Enabled))
                    l_ctrlErrorControl.Focus();
                return 1;
            }

            ArrayList l_ClientBankData = new ArrayList();

            if (m_objOperation == MasterOperation.Add)
            {
                if (m_objCurrentClientBank == null)
                    m_objCurrentClientBank = new CClientBank(0);
                m_objCurrentClientBank.ClientBankNo = 0;
            }

            m_objCurrentClientBank.AccountNo = txtAccountNo.Text.Trim();
            m_objCurrentClientBank.ClientNo = m_objCurrentClient.ClientNo;
            m_objCurrentClientBank.Default = (chkDefault.Checked ? "Y" : "N");
            m_objCurrentClientBank.BankNo = Convert.ToInt16(txtBank.Tag);
            m_objCurrentClientBank.ExNo = Convert.ToInt16(cboExchange.SelectedValue);
            m_objCurrentClientBank.AccountType = Convert.ToInt16(cboAccountType.SelectedValue);
            MethodExecResult l_objMethodExceResult = m_objCurrentClientBank.Update();

            if (l_objMethodExceResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, l_objMethodExceResult);

                if (m_objOperation == MasterOperation.Add)
                    MessageBox.Show("Unable to add Bank details" + Environment.NewLine + l_objMethodExceResult.ErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK);
                else
                    MessageBox.Show("Unable to update Bank details" + Environment.NewLine + l_objMethodExceResult.ErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK);

                return -1;
            }
            else
            {
                if (CSystemParam.Instance[CSystemParam.SysParam.MakerCheckerClient].SysParamValue == "Y")
                {
                    if (m_objOperation == MasterOperation.Add)
                        MessageBox.Show("Records Added Successfully for Authorisation", m_sMsgBoxTitle, MessageBoxButtons.OK);
                    else
                        MessageBox.Show("Records Updated Successfully for Authorisation", m_sMsgBoxTitle, MessageBoxButtons.OK);
                }
                else
                {
                    if (m_objOperation == MasterOperation.Add)
                        MessageBox.Show("Records Added Successfully", m_sMsgBoxTitle, MessageBoxButtons.OK);
                    else
                        MessageBox.Show("Records Updated Successfully", m_sMsgBoxTitle, MessageBoxButtons.OK);
                }
                m_objCurrentClient.IsPendingAuth = true;
                View_Click(this, EventArgs.Empty);

                return 0;
            }
        }
        #endregion

        /// <summary>
        /// Deletes current record from database using BL class
        /// </summary>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region DeleteClientBankData
        private long DeleteClientBankData()
        {
            MethodExecResult l_objMethodExceResult = m_objCurrentClientBank.Delete();

            if (l_objMethodExceResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, l_objMethodExceResult);
                MessageBox.Show("Client Bank cannot be deleted", m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            else
            {
                MessageBox.Show("Records Deleted Successfully", m_sMsgBoxTitle, MessageBoxButtons.OK);
                m_objCurrentClient.IsPendingAuth = true;
                ClearFields();
                RefreshClientBankData();

            }
            return 0;
        }
        #endregion

        /// <summary>
        /// Retrieves/sets data from database again for current client
        /// </summary>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region RefreshClientBankData
        private long RefreshClientBankData()
        {
            Int32 l_nUserNo;
            l_nUserNo = m_objCurrentClient.IsCheckerView ? m_objCurrentClient.MakerUser : AppEnvironment.AppUser.UserNo;
            m_objClientBank = new CClientBankCollection(m_objCurrentClient.ClientNo, l_nUserNo);
            if ((m_objClientBank.LastMethodExecResult != null) && (m_objClientBank.LastMethodExecResult.ReturnCode != MethodExecResult.SuccessfulReturnCode))
            {
                MessageBox.Show(m_objClientBank.LastMethodExecResult.ErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }

            //////// populate collection 
            //////m_objCurrentClient.ClientBanks = new List<CClientBank>();
            //////foreach (DataRow _dr in m_objClientBank.BankDetailData.Rows)
            //////{
            //////    CClientBank l_ClientBank;
            //////    l_ClientBank = new CClientBank(Convert.ToInt32(_dr["n_ClientBankNo"]));
            //////    l_ClientBank.Initialize(_dr, m_objClientBank);
            //////    m_objCurrentClient.ClientBanks.Add(l_ClientBank);
            //////}
            m_objCurrentClient.ClientBanks = m_objClientBank.ClientBanks;
            m_dtClientBankDetails = m_objClientBank.BankDetailData;
            dgvClientBank.DataSource = m_dtClientBankDetails;
            FormatGrid();

            if ((m_dtClientBankDetails == null) || (m_dtClientBankDetails.Rows.Count == 0))
                btnAdd_Click(this, EventArgs.Empty);
            return 0;
        }
        #endregion

        /// <summary>
        /// Populates controls with current selected address record
        /// </summary>
        
        #region PopulateFields
        private void PopulateFields()
        {
            ClearFields();

            Row l_objSelectedRow = dgvClientBank.Rows.Selected[0];

            if (l_objSelectedRow == null)
            {
                return;
            }

            try
            {
                txtBank.Text = l_objSelectedRow["n_BankNo"].ToString().Trim();
            }
            catch
            {
                return;
            }

            try
            {
                m_bInternalUpdation = true;
                CurrencyManager l_cmCurrentMgr = (CurrencyManager)dgvClientBank.BindingContext[dgvClientBank.DataSource, dgvClientBank.DataMember];
                DataRowView l_drvCurrent = (DataRowView)l_cmCurrentMgr.Current;
                DataRow l_rwCurrent = l_drvCurrent.Row;

                m_objCurrentClientBank = new CClientBank(Convert.ToInt32(l_rwCurrent["n_ClientBankNo"]));
                MethodExecResult l_objMethodExecResult = m_objCurrentClientBank.Initialize(l_rwCurrent, m_objClientBank);

                if (l_objMethodExecResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
                {
                    MessageBox.Show(l_objMethodExecResult.ErrorMessage);
                    return;
                }

                cboExchange.SelectedValue = m_objCurrentClientBank.ExNo;
                CBank l_objBank = CBankCollection.Instance[m_objCurrentClientBank.BankNo];
                if(l_objBank != null)
                    txtBank.Text = l_objBank.BankCode;
                txtBank.Tag = m_objCurrentClientBank.BankNo;
                txtAccountNo.Text = m_objCurrentClientBank.AccountNo;
                chkDefault.Checked = (m_objCurrentClientBank.Default == "Y");
                cboAccountType.SelectedValue = m_objCurrentClientBank.AccountType;
                m_bValidBankValueSet = true;

                if (m_objCurrentClientBank.AuthorizedStatus == "F")
                    btnMakerCancel.Visible = false;
                else
                    btnMakerCancel.Visible = true;

                if (m_objCurrentClient.IsPendingAuth)
                    ApplyMakerCheckerEffects(m_objCurrentClientBank, m_objCurrentClientBank.OriginalBank);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                MessageBox.Show(ex.Message, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            finally
            {
                m_bInternalUpdation = false;
            }
        }
        #endregion

        /// <summary>
        /// Clears all control values
        /// </summary>
        #region ClearFields
        private void ClearFields()
        {
            m_bInternalUpdation = true;
            try
            {
                cboExchange.SelectedIndex = -1;
                txtBank.Text = string.Empty;
                txtBank.Tag = null;
                txtAccountNo.Text = string.Empty;
                chkDefault.Checked = false;
                cboAccountType.SelectedIndex = -1;
            }
            finally
            {
                m_bInternalUpdation = false;
            }

        }
        #endregion

        /// <summary>
        /// Enables/disables all controls
        /// </summary>
        /// <param name="p_vsFlag">Enable/disable flag</param>
        #region EnableDisableClientBankField
        private void EnableDisableClientBankField(bool p_vsFlag)
        {
            switch(m_objOperation)
            {
                case MasterOperation.Add:
                    cboExchange.Enabled = true;
                    break;
                default:
                    cboExchange.Enabled = false;
                    break;
            }
        }
        #endregion
        
        /// <summary>
        /// Validates current Bank record
        /// </summary>
        /// <param name="ErrorMessage">Error message if validation fails</param>
        /// <param name="ErrorControl">Error control where validation failed</param>
        /// <returns>True if all validations passed, False otherwise</returns>
        #region ValidateBankDetails
        private bool ValidateBankDetails(ref string ErrorMessage, ref Control ErrorControl)
        {
            //Mandatory Fields
            if (cboExchange.SelectedValue == null)
            {
                ErrorControl = cboExchange;
                ErrorMessage = "Exchange cannot be blank";
                return false;
            }
            
            if (txtBank.Enabled && txtBank.Text.Trim().Length == 0)
            {
                ErrorControl = txtBank;
                ErrorMessage = "Bank cannot be blank";
                return false;
            }

            if (txtAccountNo.Enabled && txtAccountNo.Text.Trim().Length == 0)
            {
                ErrorControl = txtAccountNo;
                ErrorMessage = "Account No cannot be blank";
                return false;
            }

            if (cboAccountType.SelectedValue == null)
            {
                ErrorControl = cboAccountType;
                ErrorMessage = "Account Type cannot be blank";
                return false;
            }
            
            return true;
        }
        #endregion

        #region ApplyMakerCheckerEffects
        private void ApplyMakerCheckerEffects(CClientBank m_objCurrent, CClientBank m_objCompareTo)
        {


            CUCCCommon l_objCommon = CUCCCommon.Instance;
            if (m_objCompareTo == null)
                m_objCompareTo = m_objCurrent;

            if (m_objCurrent.ExNo == m_objCompareTo.ExNo)
                l_objCommon.ResetMakerChangedStyle(cboExchange, lblExchange, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(cboExchange, lblExchange, ttMain, CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.EXCH, m_objCompareTo.ExNo.ToString()));

            if (m_objCurrent.BankNo == m_objCompareTo.BankNo)
                l_objCommon.ResetMakerChangedStyle(txtBank, lblBank, ttMain);
            else
            {
                CBank l_objBank = CBankCollection.Instance[m_objCompareTo.BankNo];
                l_objCommon.SetMakerChangedStyle(txtBank, lblBank, ttMain, l_objBank.BankCode);
            }

            if (m_objCurrent.AccountType == m_objCompareTo.AccountType)
                l_objCommon.ResetMakerChangedStyle(cboAccountType, lblAccountNo, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(cboAccountType, lblAccountNo, ttMain, CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.BANKACCTYP, Convert.ToInt32(m_objCompareTo.AccountType)));


            if (m_objCurrent.AccountNo == m_objCompareTo.AccountNo)
                l_objCommon.ResetMakerChangedStyle(txtAccountNo, lblAccountNo, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtAccountNo, lblAccountNo, ttMain, m_objCompareTo.AccountNo);

            if (m_objCurrent.Default == m_objCompareTo.Default)
                l_objCommon.ResetMakerChangedStyle(chkDefault, lblDefault, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(chkDefault, lblDefault, ttMain, m_objCompareTo.Default);

        }
        #endregion

        #endregion

        #region IEventInfo Members

        #region Not applicable

        /// <summary>
        /// Not implemented
        /// </summary>
        void IEventInfo.Filter() {}
        /// <summary>
        /// Not implemented
        /// </summary>
        void IEventInfo.ModifyRecord() { }

        #endregion

        /// <summary>
        /// Redirects to View_Click
        /// </summary>
        #region RefreshData
        void IEventInfo.RefreshData()
        {
            View_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Redirects to New_Click
        /// </summary>
        #region AddRecord
        void IEventInfo.AddRecord()
        {
            New_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Redirects to Delete_Click
        /// </summary>
        #region DeleteRecord
        void IEventInfo.DeleteRecord()
        {
            Delete_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Redirects to Save_Click
        /// </summary>
        #region SaveData
        void IEventInfo.SaveData()
        {
            Save_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Redirects to Exit_Click
        /// </summary>
        #region Exit
        void IEventInfo.Exit()
        {
            Exit_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Cancel the maker changes for the selected record
        /// </summary>
        #region CancelMakerChanges
        private void CancelMakerChanges()
        {
            MakerCancel lbjMkrCancel = new MakerCancel();
            ArrayList l_lstParamValue = new ArrayList();
            MethodExecResult l_objMethodExceResult;

            l_lstParamValue.Add(m_objCurrentClientBank.ClientNo);
            l_lstParamValue.Add(5);

            l_objMethodExceResult = lbjMkrCancel.CancelMakerEffect(l_lstParamValue);

            if (l_objMethodExceResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, l_objMethodExceResult);
                MessageBox.Show("Unable to cancel the maker changes" + Environment.NewLine + l_objMethodExceResult.ErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                View_Click(this, EventArgs.Empty);
                MessageBox.Show("Maker changes cancel successfully", m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        #endregion 
        #endregion

    }
}
