﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using C1.Win.C1FlexGrid;

using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;
using UCC.Class;
using FTIL.Match.Common.Utils;
using UCC.Class.Master;

namespace UCC.Forms.UCCClient
{
    /// <summary>
    /// Client Exchange mapping screen user control
    /// </summary>
    public partial class UCCClientExchangeInfo : UserControl, IEventInfo
    {
        #region Variables

        /// <summary>
        /// Client Exchange mapping BL class instance
        /// </summary>
        private CUCCClientExchangeMapping m_objCUCCClientExchangeMapping;

        /// <summary>
        /// Client Exchange mapping data DataTable
        /// </summary>
        private DataTable m_dtClientExchangeDetails;

        /// <summary>
        /// Unique number for identifying client exchange mapping
        /// </summary>
        private int m_iClientExchangeMappingNo;

        /// <summary>
        /// Current Client Context instance
        /// </summary>
        private CClient m_objCurrentClient;

        /// <summary>
        /// Message box title string
        /// </summary>
        private string m_sMsgBoxTitle;

        /// <summary>
        /// Collection of Exchanges details for a selected client
        /// </summary>
        private CClientExchangeCollection m_objClientExchange;

        #endregion

        /// <summary>
        /// Client Exchange mapping class constructor
        /// </summary>
        /// <param name="p_vobjCurrentClient">Client context instance</param>
        #region Constructor
        public UCCClientExchangeInfo(CClient p_vobjCurrentClient)
        {
            InitializeComponent();

            dgvClientExchangeMapping.OverrideDefault = true;
            dgvClientExchangeMapping.Styles.Normal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dgvClientExchangeMapping.Styles.Alternate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            
            m_objCurrentClient = p_vobjCurrentClient;

            m_dtClientExchangeDetails = new DataTable();
           // m_objCUCCClientExchangeMapping = new CUCCClientExchangeMapping();
        } 
        #endregion

        #region Events

        /// <summary>
        /// Window load event handler. Initializes menu, controls & loads data
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region UCCClientExchangeInfo_Load
        private void UCCClientExchangeInfo_Load(object sender, EventArgs e)
        {
            pnlActionControls.Enabled = m_objCurrentClient.AllowModificationsToCurrentUser;
            m_sMsgBoxTitle = this.ParentForm.Text + " - Exchange Mapping";

            PopulateLookUp();
            View_Click(this, EventArgs.Empty);
            PopulateFields();
            FormatGrid();
        }

        #endregion

        /// <summary>
        /// Grid Row/Column changed event handler. Populates current exchange mapping details in controls
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region dgvClientExchangeMapping_RowColChange
        private void dgvClientExchangeMapping_RowColChange(object sender, EventArgs e)
        {
            if (dgvClientExchangeMapping.Rows.Selected.Count != 1)
            {
                return;
            }

            PopulateFields();
        } 
        #endregion

        /// <summary>
        /// Refresh button click event handler. Retrieves data from database again.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region View_Click
        private void View_Click(object sender, EventArgs e)
        {
            RefreshClientExchangeData();
        }
        #endregion

        /// <summary>
        /// Save button event handler. Proceeds to perform changes in database. 
        /// Refreshes data after successful completion.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region Save_Click
        private void Save_Click(object sender, EventArgs e)
        {
            SaveClientExchangeMappingData();
            EnableDisableClientExchanegField(false);
        }
        #endregion

        /// <summary>
        /// Closes parent window where this user control is hosted
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region Exit_Click
        private void Exit_Click(object sender, EventArgs e)
        {
            this.ParentForm.Close();
        }
        #endregion

        /// <summary>
        /// Save button click event handler. Redirects to Save_Click event handler.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnSave_Click
        private void btnSave_Click(object sender, EventArgs e)
        {
            Save_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// ClientType changed event handler. Sets Relationship combo data for current client type & exchange.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        #region cboClientType_SelectedIndexChanged
        private void cboClientType_SelectedIndexChanged(object sender, EventArgs e)
        {
            cboRelationship.DataSource = null;

            if (cboClientType.SelectedValue == null)
                return;
            if (dgvClientExchangeMapping.Rows.Selected.Count < 1)
                return;

            Row l_objSelectedRow = dgvClientExchangeMapping.Rows.Selected[0];
            if (l_objSelectedRow == null)
                return;

            try
            {
                ExchangeType l_objExchType = CUCCCommon.Instance.GetExchangeType(l_objSelectedRow["s_ExType"].ToString());
                Int16 l_iCategoryNo = Convert.ToInt16(cboClientType.SelectedValue);

                cboRelationship.ValueMember = "RelationshipCode";
                cboRelationship.DisplayMember = "RelationshipName";
                cboRelationship.DataSource = CExchCategoryRelMappingCollection.Instance[l_objExchType, l_iCategoryNo];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }
        #endregion

        /// <summary>
        /// Makercancel button click event handler.redirect to CancelMakerChanges function
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">Event argument</param>
        #region btnMakerCancel_Click
        private void btnMakerCancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure to cancel maker changes?", m_sMsgBoxTitle,
               MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.No)
            {
                return;
            }
            this.CancelMakerChanges();
        }
        #endregion

        #endregion

        #region Methods

        /// <summary>
        /// Formats data layout of grid. Sets visible columns, their titles.
        /// </summary>
        #region FormatGrid
        private void FormatGrid()
        {
            if (dgvClientExchangeMapping.DataSource == null)
                return;

            for (int l_iColCounter = 0; l_iColCounter < dgvClientExchangeMapping.Cols.Count; l_iColCounter++)
                dgvClientExchangeMapping.Cols[l_iColCounter].Visible = false;   

            if (dgvClientExchangeMapping.Cols.Contains("n_ClientNo"))
                dgvClientExchangeMapping.Cols["n_ClientNo"].Visible = false;
            if (dgvClientExchangeMapping.Cols.Contains("n_ClientExMapNo"))
                dgvClientExchangeMapping.Cols["n_ClientExMapNo"].Visible = false;

            if (dgvClientExchangeMapping.Cols.Contains("n_ExNo"))
            {
                dgvClientExchangeMapping.Cols["n_ExNo"].Visible = true;
                dgvClientExchangeMapping.Cols["n_ExNo"].Caption = "Exchange";
                dgvClientExchangeMapping.Cols["n_ExNo"].Width = 75;
                dgvClientExchangeMapping.Cols["n_ExNo"].DataMap = CReferenceDataProvider.Instance.GetHashTable(CReferenceDataProvider.ReferenceType.EXCH, CReferenceDataProvider.ReferenceFields.ReferenceName, CReferenceDataProvider.ReferenceFields.ReferenceCode);
            }

            if (dgvClientExchangeMapping.Cols.Contains("s_Code"))
            {
                dgvClientExchangeMapping.Cols["s_Code"].Visible = true;
                dgvClientExchangeMapping.Cols["s_Code"].Caption = "Trading Code";
            }

            if (dgvClientExchangeMapping.Cols.Contains("s_CPCode"))
            {
                dgvClientExchangeMapping.Cols["s_CPCode"].Visible = true;
                dgvClientExchangeMapping.Cols["s_CPCode"].Caption = "CP Code";
            }

            if (dgvClientExchangeMapping.Cols.Contains("d_ClientAgreementDate"))
            {
                dgvClientExchangeMapping.Cols["d_ClientAgreementDate"].Visible = true;
                dgvClientExchangeMapping.Cols["d_ClientAgreementDate"].Caption = "Client Agreement Date";
            }

            if (dgvClientExchangeMapping.Cols.Contains("s_InpersonVerification"))
            {
                dgvClientExchangeMapping.Cols["s_InpersonVerification"].Visible = true;
                dgvClientExchangeMapping.Cols["s_InpersonVerification"].Caption = "Inperson Verification";

                Hashtable l_hstYesNo = new Hashtable();
                l_hstYesNo.Add("Y", "Yes");
                l_hstYesNo.Add("N", "No");
                dgvClientExchangeMapping.Cols["s_InpersonVerification"].DataMap = l_hstYesNo;
            }
            if (dgvClientExchangeMapping.Cols.Contains("s_ClientStatus"))
            {
                dgvClientExchangeMapping.Cols["s_ClientStatus"].Visible = true;
                dgvClientExchangeMapping.Cols["s_ClientStatus"].Caption = "Client Status";
                dgvClientExchangeMapping.Cols["s_ClientStatus"].DataMap = CReferenceDataProvider.Instance.GetHashTable(CReferenceDataProvider.ReferenceType.STATUS, CReferenceDataProvider.ReferenceFields.ReferenceName, CReferenceDataProvider.ReferenceFields.ReferenceCode);
            }
            if (dgvClientExchangeMapping.Cols.Contains("s_Remarks"))
            {
                dgvClientExchangeMapping.Cols["s_Remarks"].Visible = true;
                dgvClientExchangeMapping.Cols["s_Remarks"].Caption = "Remarks";
            }
            if (dgvClientExchangeMapping.Cols.Contains("s_ClientTypeDesc"))
            {
                dgvClientExchangeMapping.Cols["s_ClientTypeDesc"].Visible = true;
                dgvClientExchangeMapping.Cols["s_ClientTypeDesc"].Caption = "Client Type";
                dgvClientExchangeMapping.Cols["s_ClientTypeDesc"].Width = 220;
            }
            if (dgvClientExchangeMapping.Cols.Contains("n_SegmentNo"))
            {
                dgvClientExchangeMapping.Cols["n_SegmentNo"].Visible = true;
                dgvClientExchangeMapping.Cols["n_SegmentNo"].Caption = "Segment";
                dgvClientExchangeMapping.Cols["n_SegmentNo"].Width = 55;
                dgvClientExchangeMapping.Cols["n_SegmentNo"].DataMap = CReferenceDataProvider.Instance.GetHashTable(CReferenceDataProvider.ReferenceType.SEGTYPE, CReferenceDataProvider.ReferenceFields.ReferenceName, CReferenceDataProvider.ReferenceFields.ReferenceCode);
            }
            if (dgvClientExchangeMapping.Cols.Contains("s_UCCDownloaded"))
            {
                dgvClientExchangeMapping.Cols["s_UCCDownloaded"].Visible = true;
                dgvClientExchangeMapping.Cols["s_UCCDownloaded"].Caption = "Downloaded";
                
                Hashtable l_hstYesNo = new Hashtable();
                l_hstYesNo.Add("Y", "Yes");
                l_hstYesNo.Add("N", "No");
                dgvClientExchangeMapping.Cols["s_UCCDownloaded"].DataMap = l_hstYesNo;
            }
            if (dgvClientExchangeMapping.Cols.Contains("n_BatchNo"))
            {
                dgvClientExchangeMapping.Cols["n_BatchNo"].Visible = true;
                dgvClientExchangeMapping.Cols["n_BatchNo"].Caption = "Batch No";
            }
            if (dgvClientExchangeMapping.Cols.Contains("s_RejectionDesc"))
            {
                dgvClientExchangeMapping.Cols["s_RejectionDesc"].Visible = true;
                dgvClientExchangeMapping.Cols["s_RejectionDesc"].Caption = "Rejection Reason";
            }
        } 
        #endregion

        /// <summary>
        /// Populates help (combo) controls with master values
        /// </summary>
        /// <returns></returns>
        #region PopulateLookUp
        private long PopulateLookUp()
        {
            txtTradingCode.Enabled = false;
            //cboStatus.Enabled = false;
            chkUCCDownloaded.Enabled = false;
            //cboClientType.Enabled = false;

            if (AppEnvironment.AppSettings.AppProduct == Product.Settlement)
            {
                cboSegment.Enabled = false;
                //txtRemarks.Enabled = false;
            }
            else if (AppEnvironment.AppSettings.AppProduct == Product.Derivative)
            {
                dtpClientAgreementDate.Enabled = false;
                chkInpersonVerification.Enabled = false;
            }

            //cboClientType.ValueMember = "s_ReferenceCode";
            //cboClientType.DisplayMember = "s_ReferenceName";
            //cboClientType.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.CLIENTTYPE]; //l_dsPopulateClientDetails.Tables[6];

            ////////////////Client Exchange Controls
            cboExchangeCode.ValueMember = "n_ExNo";
            cboExchangeCode.DisplayMember = "s_ExCode";
            cboExchangeCode.DataSource = CMastersDataProvider.Instance[Masters.Exchange]; //l_dsPopulateClientDetails.Tables[8];

            cboStatus.ValueMember = "s_ReferenceCode";
            cboStatus.DisplayMember = "s_ReferenceName";
            cboStatus.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.STATUS]; //l_dsPopulateClientDetails.Tables[10];

            cboSegment.ValueMember = "s_ReferenceCode";
            cboSegment.DisplayMember = "s_ReferenceName";
            cboSegment.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.SEGTYPE]; //l_dsPopulateClientDetails.Tables[16];

            return 0;

        } 
        #endregion

        /// <summary>
        /// Updates current changes to database using BL class
        /// </summary>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region SaveClientExchangeMappingData
        private long SaveClientExchangeMappingData()
        {
            if (
                (dgvClientExchangeMapping.DataSource == null)
                || (dgvClientExchangeMapping.Rows.Count == dgvClientExchangeMapping.Rows.Fixed)
                )
            {
                MessageBox.Show("No data exists!!!", m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return 1;
            }

            string l_sErrorMessage = string.Empty;
            Control l_ctrlErrorControl = null;
            if (ValidateClientExchangeDetails(ref l_sErrorMessage, ref l_ctrlErrorControl) == false)
            {
                MessageBox.Show(l_sErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                if ((l_ctrlErrorControl != null) && (l_ctrlErrorControl.Enabled))
                    l_ctrlErrorControl.Focus();
                return 1;
            }

            ArrayList l_ClientExchangeData = new ArrayList();
            l_ClientExchangeData.Add(m_objCurrentClient.ClientCode);
            l_ClientExchangeData.Add(cboExchangeCode.SelectedValue);
            l_ClientExchangeData.Add(m_iClientExchangeMappingNo);
            l_ClientExchangeData.Add(cboSegment.SelectedValue);
            l_ClientExchangeData.Add(txtTradingCode.Text.Trim());
            l_ClientExchangeData.Add(txtCPCode.Text.Trim());
            l_ClientExchangeData.Add(cboClientType.SelectedValue);
            if (chkInpersonVerification.Checked)
                l_ClientExchangeData.Add("Y");
            else
                l_ClientExchangeData.Add("N");
            if(dtpClientAgreementDate.Checked)
                l_ClientExchangeData.Add(dtpClientAgreementDate.Value.Date);
            else
                l_ClientExchangeData.Add(null);
            l_ClientExchangeData.Add(cboStatus.SelectedValue);
            l_ClientExchangeData.Add(txtRemarks.Text.Trim());
            l_ClientExchangeData.Add(cboRelationship.SelectedValue);

            MethodExecResult l_objMethodExceResult = m_objCUCCClientExchangeMapping.UpdateUCCClientExchangeData(l_ClientExchangeData);

            if (l_objMethodExceResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, l_objMethodExceResult);
                MessageBox.Show("Unable to modify exchange details" + Environment.NewLine + l_objMethodExceResult.ErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;

            }
            else
            {
                m_objCurrentClient.IsPendingAuth = true;
                View_Click(this, EventArgs.Empty);
                FormatGrid();
                if (CSystemParam.Instance[CSystemParam.SysParam.MakerCheckerClient].SysParamValue == "Y")
                    MessageBox.Show("Records Updated Successfully for Authorisation", m_sMsgBoxTitle, MessageBoxButtons.OK);
                else
                    MessageBox.Show("Records Updated Successfully", m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return 0;
        } 
        #endregion

        /// <summary>
        /// Retrieves/sets data from database again for current client
        /// </summary>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region RefreshClientExchangeData
        private long RefreshClientExchangeData()
        {
            Int32 l_nUserNo;
            l_nUserNo = m_objCurrentClient.IsCheckerView ? m_objCurrentClient.MakerUser : AppEnvironment.AppUser.UserNo;
            m_objClientExchange = new CClientExchangeCollection(m_objCurrentClient.ClientNo, l_nUserNo);
            if ((m_objClientExchange.LastMethodExecResult != null) && (m_objClientExchange.LastMethodExecResult.ReturnCode != MethodExecResult.SuccessfulReturnCode))
            {
                MessageBox.Show(m_objClientExchange.LastMethodExecResult.ErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }

            ////// populate collection 
            ////m_objCurrentClient.ClientExchanges = new List<CUCCClientExchangeMapping>();
            ////foreach (DataRow _dr in m_objClientExchange.ExchDetailData.Rows)
            ////{
            ////    CUCCClientExchangeMapping l_ClientExchnage;
            ////    l_ClientExchnage = new CUCCClientExchangeMapping(Convert.ToInt32(_dr["n_ClientExMapNo"]));
            ////    l_ClientExchnage.Initialize(_dr, m_objClientExchange);
            ////    m_objCurrentClient.ClientExchanges.Add(l_ClientExchnage);
            ////}
            m_objCurrentClient.ClientExchanges = m_objClientExchange.ClientExchanges;
            m_dtClientExchangeDetails = m_objClientExchange.ExchDetailData;
            dgvClientExchangeMapping.DataSource = m_dtClientExchangeDetails;
            FormatGrid();

            return 0;
        } 
        #endregion

        /// <summary>
        /// Populates controls with current selected record
        /// </summary>
        #region PopulateFields
        private void PopulateFields()
        {
            if (dgvClientExchangeMapping.Rows.Selected.Count == 0)
            {
                //ClearControls();
                return;
            }

            Row l_objSelectedRow = dgvClientExchangeMapping.Rows.Selected[0];

            if (l_objSelectedRow == null)
            {
                //ClearControls();
                return;
            }

            try
            {
                m_iClientExchangeMappingNo = Convert.ToInt32(l_objSelectedRow["n_ClientExMapNo"]);
            }
            catch
            {
                //ClearControls();
                return;
            }

            try
            {

                ///m_bInternalUpdation = true;
                CurrencyManager l_cmCurrentMgr = (CurrencyManager)dgvClientExchangeMapping.BindingContext[dgvClientExchangeMapping.DataSource, dgvClientExchangeMapping.DataMember];
                DataRowView l_drvCurrent = (DataRowView)l_cmCurrentMgr.Current;
                DataRow l_rwCurrent = l_drvCurrent.Row;


                m_objCUCCClientExchangeMapping = new CUCCClientExchangeMapping(Convert.ToInt32(l_rwCurrent["n_ClientExMapNo"]));
                MethodExecResult l_objMethodExecResult = m_objCUCCClientExchangeMapping.Initialize(l_rwCurrent, m_objClientExchange);

                if (l_objMethodExecResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
                {
                    MessageBox.Show(l_objMethodExecResult.ErrorMessage);
                    return;
                }



                cboExchangeCode.SelectedValue = m_objCUCCClientExchangeMapping.ExNo;
                cboSegment.SelectedValue = m_objCUCCClientExchangeMapping.Segment;

                txtTradingCode.Text = m_objCUCCClientExchangeMapping.TradingCode;
                txtCPCode.Text = m_objCUCCClientExchangeMapping.CPCode;

                if (m_objCUCCClientExchangeMapping.ClientAgreementDate.ToString() == "")
                {
                    dtpClientAgreementDate.Value = CMatchCommonUtils.Instance.ServerDate;
                    dtpClientAgreementDate.Checked = false;
                }
                else
                {
                    dtpClientAgreementDate.Value = Convert.ToDateTime(m_objCUCCClientExchangeMapping.ClientAgreementDate);
                    dtpClientAgreementDate.Checked = true;
                }

                chkInpersonVerification.Checked = (m_objCUCCClientExchangeMapping.InpersonVerification == "Y");

                cboStatus.SelectedValue = m_objCUCCClientExchangeMapping.ClientStatus;
                txtRemarks.Text = m_objCUCCClientExchangeMapping.Remarks;

                chkUCCDownloaded.Checked = (m_objCUCCClientExchangeMapping.UCCDownloaded == "Y");
                txtBatchNo.Text = m_objCUCCClientExchangeMapping.BatchNo.ToString();
                txtRejectionCode.Text = m_objCUCCClientExchangeMapping.RejectionDesc;

                cboClientType.ValueMember = "n_CategoryNo";
                cboClientType.DisplayMember = "s_Category";
                ExchangeType l_objExchType = CUCCCommon.Instance.GetExchangeType(m_objCUCCClientExchangeMapping.ExchangeType);
                cboClientType.DataSource = CClientCategoryDataProvider.Instance[l_objExchType];

                cboClientType.SelectedValue = m_objCUCCClientExchangeMapping.ClientType;

                cboRelationship.SelectedValue = m_objCUCCClientExchangeMapping.Relationship == null ? "0" : m_objCUCCClientExchangeMapping.Relationship.ToString();


                if (m_objCUCCClientExchangeMapping.AuthorizedStatus == "F")
                    btnMakerCancel.Visible = false;
                else
                    btnMakerCancel.Visible = true;

                if (m_objCurrentClient.IsPendingAuth)
                    ApplyMakerCheckerEffects(m_objCUCCClientExchangeMapping, m_objCUCCClientExchangeMapping.OriginalExchangeMap);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion

        /// <summary>
        /// Enables/disables all controls
        /// </summary>
        /// <param name="p_vsFlag">Enable/disable flag</param>
        #region EnableDisableClientExchanegField (not used)
        private void EnableDisableClientExchanegField(bool p_vsFlag)
        {
        } 
        #endregion

        /// <summary>
        /// Validates current record.
        /// </summary>
        /// <param name="ErrorMessage">Error message if validation fails</param>
        /// <param name="ErrorControl">Error control where validation failed</param>
        /// <returns>True if all validations passed, False otherwise</returns>
        #region ValidateClientExchangeDetails
        private bool ValidateClientExchangeDetails(ref string ErrorMessage, ref Control ErrorControl)
        {
            //Mandatory
            if (cboClientType.Enabled && cboClientType.SelectedItem == null)
            {
                ErrorControl = cboClientType;
                ErrorMessage = "Client Type must be provided";
                return false;
            }

            if(dtpClientAgreementDate.Enabled && (dtpClientAgreementDate.Value.Date > CMatchCommonUtils.Instance.ServerDate.Date) )
            {
                ErrorControl = dtpClientAgreementDate;
                ErrorMessage = "Client Agreement Date cannot be greater than current date";
                return false;
            }

            if (
                dtpClientAgreementDate.Enabled 
                &&
                (cboSegment.SelectedItem != null)
                &&
                (cboSegment.SelectedValue.ToString() == "2") //SLB Segment
                && 
                (dtpClientAgreementDate.Checked == false)
               )
            {
                ErrorControl = dtpClientAgreementDate;
                ErrorMessage = "Client Agreement Date must be provided for SLB Segment";
                return false;
            }

            //If either of Client status or Client Type changed, Remarks must be provided & Remarks must be different from original
            if (
                (dgvClientExchangeMapping.Rows.Selected.Count > 0)
                && (dgvClientExchangeMapping.Rows.Selected[0] != null)
                )
            {
                Row l_objSelectedRow = dgvClientExchangeMapping.Rows.Selected[0];

                try
                {
                    string l_sOrigCategoryNo = l_objSelectedRow["n_ClientType"].ToString();
                    string l_sNewCategoryNo = string.Empty;
                    if (cboClientType.SelectedValue != null)
                        l_sNewCategoryNo = cboClientType.SelectedValue.ToString();

                    string l_sOrigStatus = l_objSelectedRow["s_ClientStatus"].ToString();
                    string l_sNewStatus = string.Empty;
                    if (cboStatus.SelectedValue != null)
                        l_sNewStatus = cboStatus.SelectedValue.ToString();

                    string l_sOrigRemarks = l_objSelectedRow["s_Remarks"].ToString().Trim();
                    string l_sNewRemarks = txtRemarks.Text.Trim();

                    if (
                        (
                            (l_sOrigCategoryNo != l_sNewCategoryNo)
                            || (l_sOrigStatus != l_sNewStatus)
                        )
                        &&
                        (
                            (l_sOrigRemarks == l_sNewRemarks)
                            || (l_sNewRemarks.Length == 0)
                        )
                      )
                    {
                        ErrorControl = txtRemarks;
                        ErrorMessage = "Remarks must be provided for change in Client Type/Status";
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    ErrorControl = txtRemarks;
                    ErrorMessage = "Error checking Remarks" + Environment.NewLine + ex.Message;
                    return false;
                }
            }

            return true;

        }
        #endregion

        #region ApplyMakerCheckerEffects
        private void ApplyMakerCheckerEffects(CUCCClientExchangeMapping m_objCurrent, CUCCClientExchangeMapping m_objCompareTo)
        {


            CUCCCommon l_objCommon = CUCCCommon.Instance;
            if (m_objCompareTo == null)
                m_objCompareTo = m_objCurrent;

            if (m_objCurrent.ExNo == m_objCompareTo.ExNo)
                l_objCommon.ResetMakerChangedStyle(cboExchangeCode, lblExchange, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(cboExchangeCode, lblExchange, ttMain, CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.EXCH, m_objCompareTo.ExNo.ToString()));

            if (m_objCurrent.Segment == m_objCompareTo.Segment)
                l_objCommon.ResetMakerChangedStyle(cboSegment, lblSegment, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(cboSegment, lblSegment, ttMain, CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.SEGTYPE, m_objCompareTo.Segment.ToString()));

            if (m_objCurrent.TradingCode == m_objCompareTo.TradingCode)
                l_objCommon.ResetMakerChangedStyle(txtTradingCode, lblTradingCode, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtTradingCode, lblTradingCode, ttMain, m_objCompareTo.TradingCode);

            if (m_objCurrent.CPCode == m_objCompareTo.CPCode)
                l_objCommon.ResetMakerChangedStyle(txtCPCode, lblCPCode, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtCPCode, lblCPCode, ttMain, m_objCompareTo.CPCode);


            if (m_objCurrent.ClientType == m_objCompareTo.ClientType)
                l_objCommon.ResetMakerChangedStyle(cboClientType, lblClientType, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(cboClientType, lblClientType, ttMain, CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.CLIENTTYPE, m_objCompareTo.ClientType.ToString()));

            if (m_objCurrent.InpersonVerification == m_objCompareTo.InpersonVerification)
                l_objCommon.ResetMakerChangedStyle(chkInpersonVerification, lblInpersonVerification, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(chkInpersonVerification, lblInpersonVerification, ttMain, m_objCompareTo.InpersonVerification);

            if (m_objCurrent.Relationship == m_objCompareTo.Relationship)
                l_objCommon.ResetMakerChangedStyle(cboRelationship, lblRelationship, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(cboRelationship, lblRelationship, ttMain, CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.RELATION, m_objCompareTo.Relationship));


            if (m_objCurrent.ClientAgreementDate == m_objCompareTo.ClientAgreementDate)
                l_objCommon.ResetMakerChangedStyle(dtpClientAgreementDate, lblClientAgreementDate, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(dtpClientAgreementDate, lblClientAgreementDate, ttMain, m_objCompareTo.ClientAgreementDate);

            if (m_objCurrent.ClientStatus == m_objCompareTo.ClientStatus)
                l_objCommon.ResetMakerChangedStyle(cboStatus, lblStatus, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(cboStatus, lblStatus, ttMain, CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.STATUS, m_objCompareTo.ClientStatus.ToString()));

            if (m_objCurrent.Remarks == m_objCompareTo.Remarks)
                l_objCommon.ResetMakerChangedStyle(txtRemarks, lblRemarks, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtRemarks, lblRemarks, ttMain, m_objCompareTo.Remarks);

            if (m_objCurrent.UCCDownloaded == m_objCompareTo.UCCDownloaded)
                l_objCommon.ResetMakerChangedStyle(chkUCCDownloaded, lblUCCDownloded, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(chkUCCDownloaded, lblUCCDownloded, ttMain, m_objCompareTo.UCCDownloaded);

            if (m_objCurrent.BatchNo == m_objCompareTo.BatchNo)
                l_objCommon.ResetMakerChangedStyle(txtBatchNo, lblBatchNo, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtBatchNo, lblBatchNo, ttMain, m_objCompareTo.BatchNo);

            if (m_objCurrent.RejectionDesc == m_objCompareTo.RejectionDesc)
                l_objCommon.ResetMakerChangedStyle(txtRejectionCode, lblRejectionCode, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtRejectionCode, lblRejectionCode, ttMain, m_objCompareTo.RejectionDesc);


        }
        #endregion

        /// <summary>
        /// Cancel the maker changes for the selected record
        /// </summary>
        #region CancelMakerChanges
        private void CancelMakerChanges()
        {
           
            MakerCancel lbjMkrCancel = new MakerCancel();
            ArrayList l_lstParamValue = new ArrayList();
            MethodExecResult l_objMethodExceResult;

            l_lstParamValue.Add(m_objCUCCClientExchangeMapping.ClientNo);
            l_lstParamValue.Add(2);

            l_objMethodExceResult = lbjMkrCancel.CancelMakerEffect(l_lstParamValue);

            if (l_objMethodExceResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, l_objMethodExceResult);
                MessageBox.Show("Unable to cancel the maker changes" + Environment.NewLine + l_objMethodExceResult.ErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                View_Click(this, EventArgs.Empty);
                MessageBox.Show("Maker changes cancel successfully", m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        #endregion 
        #endregion

        #region IEventInfo Members

        #region Not applicable

        void IEventInfo.Filter() {}
        void IEventInfo.AddRecord() {}
        void IEventInfo.ModifyRecord() {}
        void IEventInfo.DeleteRecord() {}

        #endregion

        /// <summary>
        /// Redirects to View_Click
        /// </summary>
        #region RefreshData
        void IEventInfo.RefreshData()
        {
            View_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Redirects to Save_Click
        /// </summary>
        #region SaveData
        void IEventInfo.SaveData()
        {
            Save_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Redirects to Exit_Click
        /// </summary>
        #region Exit
        void IEventInfo.Exit()
        {
            Exit_Click(this, EventArgs.Empty);
        }
        #endregion



        #endregion

    }
}
