﻿namespace UCC.Forms.UCCClient
{
    partial class UCCClientBank
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCCClientBank));
            this.ftBankGridPanel = new MatchCommon.CustomControls.FTPanel();
            this.dgvClientBank = new MatchCommon.CustomControls.FTDataGrid();
            this.pnlClientBankDetails = new MatchCommon.CustomControls.FTPanel();
            this.cboAccountType = new MatchCommon.CustomControls.FTComboBox();
            this.pnlActionControls = new MatchCommon.CustomControls.FTPanel();
            this.btnMakerCancel = new MatchCommon.CustomControls.FTButton();
            this.btnSave = new MatchCommon.CustomControls.FTButton();
            this.btnDelete = new MatchCommon.CustomControls.FTButton();
            this.btnAdd = new MatchCommon.CustomControls.FTButton();
            this.chkDefault = new System.Windows.Forms.CheckBox();
            this.lblDefault = new MatchCommon.CustomControls.FTLabel();
            this.txtAccountNo = new MatchCommon.CustomControls.FTTextBox();
            this.lblAccountNo = new MatchCommon.CustomControls.FTLabel();
            this.lblExchange = new MatchCommon.CustomControls.FTLabel();
            this.cboExchange = new MatchCommon.CustomControls.FTComboBox();
            this.lblBank = new MatchCommon.CustomControls.FTLabel();
            this.txtBank = new MatchCommon.CustomControls.FTTextBox();
            this.ttMain = new System.Windows.Forms.ToolTip(this.components);
            this.ftBankGridPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClientBank)).BeginInit();
            this.pnlClientBankDetails.SuspendLayout();
            this.pnlActionControls.SuspendLayout();
            this.SuspendLayout();
            // 
            // ftBankGridPanel
            // 
            this.ftBankGridPanel.Controls.Add(this.dgvClientBank);
            this.ftBankGridPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ftBankGridPanel.Location = new System.Drawing.Point(0, 0);
            this.ftBankGridPanel.Name = "ftBankGridPanel";
            this.ftBankGridPanel.Size = new System.Drawing.Size(856, 371);
            this.ftBankGridPanel.TabIndex = 6;
            // 
            // dgvClientBank
            // 
            this.dgvClientBank.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
            this.dgvClientBank.AllowEditing = false;
            this.dgvClientBank.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
            this.dgvClientBank.BackColor = System.Drawing.Color.Transparent;
            this.dgvClientBank.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.dgvClientBank.ColumnInfo = "10,1,0,0,0,85,Columns:0{Width:30;}\t";
            this.dgvClientBank.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvClientBank.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
            this.dgvClientBank.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dgvClientBank.ForeColor = System.Drawing.Color.Black;
            this.dgvClientBank.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
            this.dgvClientBank.Location = new System.Drawing.Point(0, 0);
            this.dgvClientBank.Name = "dgvClientBank";
            this.dgvClientBank.OverrideDefault = false;
            this.dgvClientBank.Rows.Count = 1;
            this.dgvClientBank.Rows.DefaultSize = 17;
            this.dgvClientBank.Rows.MinSize = 25;
            this.dgvClientBank.RowsFilter.AddFilterRow = false;
            this.dgvClientBank.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.ListBox;
            this.dgvClientBank.Size = new System.Drawing.Size(856, 371);
            this.dgvClientBank.StyleInfo = "";
            this.dgvClientBank.TabIndex = 3;
            this.dgvClientBank.RowColChange += new System.EventHandler(this.dgvBank_RowColChange);
            // 
            // pnlClientBankDetails
            // 
            this.pnlClientBankDetails.Controls.Add(this.cboAccountType);
            this.pnlClientBankDetails.Controls.Add(this.pnlActionControls);
            this.pnlClientBankDetails.Controls.Add(this.chkDefault);
            this.pnlClientBankDetails.Controls.Add(this.lblDefault);
            this.pnlClientBankDetails.Controls.Add(this.txtAccountNo);
            this.pnlClientBankDetails.Controls.Add(this.lblAccountNo);
            this.pnlClientBankDetails.Controls.Add(this.lblExchange);
            this.pnlClientBankDetails.Controls.Add(this.cboExchange);
            this.pnlClientBankDetails.Controls.Add(this.lblBank);
            this.pnlClientBankDetails.Controls.Add(this.txtBank);
            this.pnlClientBankDetails.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlClientBankDetails.Location = new System.Drawing.Point(0, 371);
            this.pnlClientBankDetails.Name = "pnlClientBankDetails";
            this.pnlClientBankDetails.Size = new System.Drawing.Size(856, 75);
            this.pnlClientBankDetails.TabIndex = 0;
            // 
            // cboAccountType
            // 
            this.cboAccountType.BackColor = System.Drawing.Color.White;
            this.cboAccountType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboAccountType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboAccountType.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboAccountType.ForeColor = System.Drawing.Color.Black;
            this.cboAccountType.FormattingEnabled = true;
            this.cboAccountType.Location = new System.Drawing.Point(482, 11);
            this.cboAccountType.MaxLength = 25;
            this.cboAccountType.Name = "cboAccountType";
            this.cboAccountType.ReadOnly = false;
            this.cboAccountType.Size = new System.Drawing.Size(108, 21);
            this.cboAccountType.TabIndex = 5;
            // 
            // pnlActionControls
            // 
            this.pnlActionControls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlActionControls.Controls.Add(this.btnMakerCancel);
            this.pnlActionControls.Controls.Add(this.btnSave);
            this.pnlActionControls.Controls.Add(this.btnDelete);
            this.pnlActionControls.Controls.Add(this.btnAdd);
            this.pnlActionControls.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlActionControls.Location = new System.Drawing.Point(0, 41);
            this.pnlActionControls.Name = "pnlActionControls";
            this.pnlActionControls.Size = new System.Drawing.Size(856, 34);
            this.pnlActionControls.TabIndex = 0;
            // 
            // btnMakerCancel
            // 
            this.btnMakerCancel.BackColor = System.Drawing.Color.Transparent;
            this.btnMakerCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMakerCancel.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnMakerCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnMakerCancel.Image")));
            this.btnMakerCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMakerCancel.Location = new System.Drawing.Point(517, 6);
            this.btnMakerCancel.Name = "btnMakerCancel";
            this.btnMakerCancel.Size = new System.Drawing.Size(107, 23);
            this.btnMakerCancel.TabIndex = 0;
            this.btnMakerCancel.Text = "&Maker Cancel";
            this.btnMakerCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMakerCancel.UseVisualStyleBackColor = false;
            this.btnMakerCancel.Visible = false;
            this.btnMakerCancel.Click += new System.EventHandler(this.btnMakerCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Transparent;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Location = new System.Drawing.Point(800, 6);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "&Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Transparent;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.Location = new System.Drawing.Point(717, 6);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 2;
            this.btnDelete.Text = "&Delete";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Transparent;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAdd.Location = new System.Drawing.Point(633, 6);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 1;
            this.btnAdd.Text = "&New";
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // chkDefault
            // 
            this.chkDefault.AutoSize = true;
            this.chkDefault.Location = new System.Drawing.Point(823, 14);
            this.chkDefault.Name = "chkDefault";
            this.chkDefault.Size = new System.Drawing.Size(15, 14);
            this.chkDefault.TabIndex = 8;
            this.chkDefault.UseVisualStyleBackColor = true;
            this.chkDefault.CheckedChanged += new System.EventHandler(this.chkDefault_CheckedChanged);
            // 
            // lblDefault
            // 
            this.lblDefault.AllowForeColorChange = false;
            this.lblDefault.AutoSize = true;
            this.lblDefault.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblDefault.ForeColor = System.Drawing.Color.Black;
            this.lblDefault.Location = new System.Drawing.Point(776, 14);
            this.lblDefault.Name = "lblDefault";
            this.lblDefault.OverrideDefault = false;
            this.lblDefault.Size = new System.Drawing.Size(42, 13);
            this.lblDefault.TabIndex = 7;
            this.lblDefault.Text = "Default";
            // 
            // txtAccountNo
            // 
            this.txtAccountNo.AllowAlpha = true;
            this.txtAccountNo.AllowDot = false;
            this.txtAccountNo.AllowedCustomCharacters = null;
            this.txtAccountNo.AllowNonASCII = false;
            this.txtAccountNo.AllowNumeric = true;
            this.txtAccountNo.AllowSpace = false;
            this.txtAccountNo.AllowSpecialChars = false;
            this.txtAccountNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAccountNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtAccountNo.FocusColor = System.Drawing.Color.LightYellow;
            this.txtAccountNo.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtAccountNo.ForeColor = System.Drawing.Color.Black;
            this.txtAccountNo.IsEmailID = true;
            this.txtAccountNo.IsEmailIdValid = false;
            this.txtAccountNo.Location = new System.Drawing.Point(596, 11);
            this.txtAccountNo.MaxLength = 25;
            this.txtAccountNo.Name = "txtAccountNo";
            this.txtAccountNo.Size = new System.Drawing.Size(163, 20);
            this.txtAccountNo.TabIndex = 6;
            // 
            // lblAccountNo
            // 
            this.lblAccountNo.AllowForeColorChange = false;
            this.lblAccountNo.AutoSize = true;
            this.lblAccountNo.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblAccountNo.ForeColor = System.Drawing.Color.Black;
            this.lblAccountNo.Location = new System.Drawing.Point(433, 14);
            this.lblAccountNo.Name = "lblAccountNo";
            this.lblAccountNo.OverrideDefault = false;
            this.lblAccountNo.Size = new System.Drawing.Size(46, 13);
            this.lblAccountNo.TabIndex = 4;
            this.lblAccountNo.Text = "Account";
            // 
            // lblExchange
            // 
            this.lblExchange.AllowForeColorChange = false;
            this.lblExchange.AutoSize = true;
            this.lblExchange.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblExchange.ForeColor = System.Drawing.Color.Black;
            this.lblExchange.Location = new System.Drawing.Point(13, 14);
            this.lblExchange.Name = "lblExchange";
            this.lblExchange.OverrideDefault = false;
            this.lblExchange.Size = new System.Drawing.Size(54, 13);
            this.lblExchange.TabIndex = 0;
            this.lblExchange.Text = "Exchange";
            // 
            // cboExchange
            // 
            this.cboExchange.BackColor = System.Drawing.Color.White;
            this.cboExchange.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboExchange.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboExchange.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboExchange.ForeColor = System.Drawing.Color.Black;
            this.cboExchange.FormattingEnabled = true;
            this.cboExchange.Location = new System.Drawing.Point(80, 11);
            this.cboExchange.MaxLength = 25;
            this.cboExchange.Name = "cboExchange";
            this.cboExchange.ReadOnly = false;
            this.cboExchange.Size = new System.Drawing.Size(118, 21);
            this.cboExchange.TabIndex = 1;
            // 
            // lblBank
            // 
            this.lblBank.AllowForeColorChange = false;
            this.lblBank.AutoSize = true;
            this.lblBank.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblBank.ForeColor = System.Drawing.Color.Black;
            this.lblBank.Location = new System.Drawing.Point(210, 14);
            this.lblBank.Name = "lblBank";
            this.lblBank.OverrideDefault = false;
            this.lblBank.Size = new System.Drawing.Size(30, 13);
            this.lblBank.TabIndex = 2;
            this.lblBank.Text = "Bank";
            // 
            // txtBank
            // 
            this.txtBank.AllowAlpha = true;
            this.txtBank.AllowDot = true;
            this.txtBank.AllowedCustomCharacters = null;
            this.txtBank.AllowNonASCII = false;
            this.txtBank.AllowNumeric = true;
            this.txtBank.AllowSpace = true;
            this.txtBank.AllowSpecialChars = true;
            this.txtBank.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBank.FocusColor = System.Drawing.Color.LightYellow;
            this.txtBank.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtBank.ForeColor = System.Drawing.Color.Black;
            this.txtBank.IsEmailID = true;
            this.txtBank.IsEmailIdValid = false;
            this.txtBank.Location = new System.Drawing.Point(248, 11);
            this.txtBank.MaxLength = 255;
            this.txtBank.Name = "txtBank";
            this.txtBank.Size = new System.Drawing.Size(179, 20);
            this.txtBank.TabIndex = 3;
            this.txtBank.TextChanged += new System.EventHandler(this.txtBank_TextChanged);
            this.txtBank.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtBank_KeyUp);
            this.txtBank.Leave += new System.EventHandler(this.txtBank_Leave);
            // 
            // UCCClientBank
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.ftBankGridPanel);
            this.Controls.Add(this.pnlClientBankDetails);
            this.Name = "UCCClientBank";
            this.Size = new System.Drawing.Size(856, 446);
            this.Load += new System.EventHandler(this.UCCClientBankInfo_Load);
            this.ftBankGridPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvClientBank)).EndInit();
            this.pnlClientBankDetails.ResumeLayout(false);
            this.pnlClientBankDetails.PerformLayout();
            this.pnlActionControls.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MatchCommon.CustomControls.FTPanel ftBankGridPanel;
        private MatchCommon.CustomControls.FTDataGrid dgvClientBank;
        private MatchCommon.CustomControls.FTPanel pnlClientBankDetails;
        private System.Windows.Forms.CheckBox chkDefault;
        private MatchCommon.CustomControls.FTLabel lblDefault;
        private MatchCommon.CustomControls.FTTextBox txtAccountNo;
        private MatchCommon.CustomControls.FTLabel lblAccountNo;
        private MatchCommon.CustomControls.FTLabel lblExchange;
        private MatchCommon.CustomControls.FTComboBox cboExchange;
        private MatchCommon.CustomControls.FTLabel lblBank;
        private MatchCommon.CustomControls.FTTextBox txtBank;
        private MatchCommon.CustomControls.FTPanel pnlActionControls;
        private MatchCommon.CustomControls.FTButton btnSave;
        private MatchCommon.CustomControls.FTButton btnDelete;
        private MatchCommon.CustomControls.FTButton btnAdd;
        private MatchCommon.CustomControls.FTComboBox cboAccountType;
        private System.Windows.Forms.ToolTip ttMain;
        private MatchCommon.CustomControls.FTButton btnMakerCancel;
    }
}
