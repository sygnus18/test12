﻿namespace UCC.Forms.UCCClient
{
    partial class UCCClientInfoMain
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCCClientInfoMain));
            this.pnlClient = new MatchCommon.CustomControls.FTPanel();
            this.ftGroupBox1 = new MatchCommon.CustomControls.FTGroupBox();
            this.cboClientStatus = new MatchCommon.CustomControls.FTComboBox();
            this.lblClientStatus = new MatchCommon.CustomControls.FTLabel();
            this.cboClientType = new MatchCommon.CustomControls.FTComboBox();
            this.lblClientPANNo = new MatchCommon.CustomControls.FTLabel();
            this.txtClientCode = new MatchCommon.CustomControls.FTTextBox();
            this.lblClientType = new MatchCommon.CustomControls.FTLabel();
            this.chkPanExempt = new System.Windows.Forms.CheckBox();
            this.lblCreationDate = new MatchCommon.CustomControls.FTLabel();
            this.lblDOB = new MatchCommon.CustomControls.FTLabel();
            this.lblMaritalStatus = new MatchCommon.CustomControls.FTLabel();
            this.lblGuardianName = new MatchCommon.CustomControls.FTLabel();
            this.lblGender = new MatchCommon.CustomControls.FTLabel();
            this.lblClientCode = new MatchCommon.CustomControls.FTLabel();
            this.txtGuardianName = new MatchCommon.CustomControls.FTTextBox();
            this.txtClientPANNo = new MatchCommon.CustomControls.FTTextBox();
            this.txtClientName = new MatchCommon.CustomControls.FTTextBox();
            this.cboMaritalStatus = new MatchCommon.CustomControls.FTComboBox();
            this.cboGender = new MatchCommon.CustomControls.FTComboBox();
            this.dtpCreationDate = new System.Windows.Forms.DateTimePicker();
            this.dtpDOB = new System.Windows.Forms.DateTimePicker();
            this.lblCorporateClientType = new MatchCommon.CustomControls.FTLabel();
            this.chkCorporateClientType = new System.Windows.Forms.CheckBox();
            this.cboTypeofFacility = new MatchCommon.CustomControls.FTComboBox();
            this.lblTypeofFacility = new MatchCommon.CustomControls.FTLabel();
            this.lblRelationship = new MatchCommon.CustomControls.FTLabel();
            this.cboRelationship = new MatchCommon.CustomControls.FTComboBox();
            this.lblCIN = new MatchCommon.CustomControls.FTLabel();
            this.chkCINExempt = new System.Windows.Forms.CheckBox();
            this.lblGrossAnnualIncomeRange = new MatchCommon.CustomControls.FTLabel();
            this.lblGrossAnnualIncomeasonDate = new MatchCommon.CustomControls.FTLabel();
            this.cboGrossAnnualIncomeRange = new MatchCommon.CustomControls.FTComboBox();
            this.lblUpdationFlagNew = new MatchCommon.CustomControls.FTLabel();
            this.dtpGrossAnnualIncomeasonDate = new System.Windows.Forms.DateTimePicker();
            this.chkUpdationFlagNew = new System.Windows.Forms.CheckBox();
            this.dtpNetWorthAsOnDate = new System.Windows.Forms.DateTimePicker();
            this.dtpBusinessCommencementDate = new System.Windows.Forms.DateTimePicker();
            this.cboOccupation = new MatchCommon.CustomControls.FTComboBox();
            this.cboNationality = new MatchCommon.CustomControls.FTComboBox();
            this.cboPEP = new MatchCommon.CustomControls.FTComboBox();
            this.txtNationalityName = new MatchCommon.CustomControls.FTTextBox();
            this.txtCIN = new MatchCommon.CustomControls.FTTextBox();
            this.txtNetWorth = new MatchCommon.CustomControls.FTTextBox();
            this.txtOccupationName = new MatchCommon.CustomControls.FTTextBox();
            this.txtPlaceofIncorporation = new MatchCommon.CustomControls.FTTextBox();
            this.txtUCCCode = new MatchCommon.CustomControls.FTTextBox();
            this.lblUCCCode = new MatchCommon.CustomControls.FTLabel();
            this.lblNetWorth = new MatchCommon.CustomControls.FTLabel();
            this.lblPEP = new MatchCommon.CustomControls.FTLabel();
            this.lblOccupation = new MatchCommon.CustomControls.FTLabel();
            this.lblPlaceofIncorporation = new MatchCommon.CustomControls.FTLabel();
            this.lblBusinessCommencementDate = new MatchCommon.CustomControls.FTLabel();
            this.lblNationality = new MatchCommon.CustomControls.FTLabel();
            this.lblNetWorthAsOnDate = new MatchCommon.CustomControls.FTLabel();
            this.ttMain = new System.Windows.Forms.ToolTip(this.components);
            this.pnlActionControls = new MatchCommon.CustomControls.FTPanel();
            this.btnMakerCancel = new MatchCommon.CustomControls.FTButton();
            this.btnSave = new MatchCommon.CustomControls.FTButton();
            this.pnlClient.SuspendLayout();
            this.ftGroupBox1.SuspendLayout();
            this.pnlActionControls.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlClient
            // 
            this.pnlClient.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pnlClient.Controls.Add(this.ftGroupBox1);
            this.pnlClient.Controls.Add(this.lblCorporateClientType);
            this.pnlClient.Controls.Add(this.chkCorporateClientType);
            this.pnlClient.Controls.Add(this.cboTypeofFacility);
            this.pnlClient.Controls.Add(this.lblTypeofFacility);
            this.pnlClient.Controls.Add(this.lblRelationship);
            this.pnlClient.Controls.Add(this.cboRelationship);
            this.pnlClient.Controls.Add(this.lblCIN);
            this.pnlClient.Controls.Add(this.chkCINExempt);
            this.pnlClient.Controls.Add(this.lblGrossAnnualIncomeRange);
            this.pnlClient.Controls.Add(this.lblGrossAnnualIncomeasonDate);
            this.pnlClient.Controls.Add(this.cboGrossAnnualIncomeRange);
            this.pnlClient.Controls.Add(this.lblUpdationFlagNew);
            this.pnlClient.Controls.Add(this.dtpGrossAnnualIncomeasonDate);
            this.pnlClient.Controls.Add(this.chkUpdationFlagNew);
            this.pnlClient.Controls.Add(this.dtpNetWorthAsOnDate);
            this.pnlClient.Controls.Add(this.dtpBusinessCommencementDate);
            this.pnlClient.Controls.Add(this.cboOccupation);
            this.pnlClient.Controls.Add(this.cboNationality);
            this.pnlClient.Controls.Add(this.cboPEP);
            this.pnlClient.Controls.Add(this.txtNationalityName);
            this.pnlClient.Controls.Add(this.txtCIN);
            this.pnlClient.Controls.Add(this.txtNetWorth);
            this.pnlClient.Controls.Add(this.txtOccupationName);
            this.pnlClient.Controls.Add(this.txtPlaceofIncorporation);
            this.pnlClient.Controls.Add(this.txtUCCCode);
            this.pnlClient.Controls.Add(this.lblUCCCode);
            this.pnlClient.Controls.Add(this.lblNetWorth);
            this.pnlClient.Controls.Add(this.lblPEP);
            this.pnlClient.Controls.Add(this.lblOccupation);
            this.pnlClient.Controls.Add(this.lblPlaceofIncorporation);
            this.pnlClient.Controls.Add(this.lblBusinessCommencementDate);
            this.pnlClient.Controls.Add(this.lblNationality);
            this.pnlClient.Controls.Add(this.lblNetWorthAsOnDate);
            this.pnlClient.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlClient.ForeColor = System.Drawing.Color.Black;
            this.pnlClient.Location = new System.Drawing.Point(0, 0);
            this.pnlClient.Margin = new System.Windows.Forms.Padding(0);
            this.pnlClient.Name = "pnlClient";
            this.pnlClient.Size = new System.Drawing.Size(856, 446);
            this.pnlClient.TabIndex = 1;
            // 
            // ftGroupBox1
            // 
            this.ftGroupBox1.Controls.Add(this.cboClientStatus);
            this.ftGroupBox1.Controls.Add(this.lblClientStatus);
            this.ftGroupBox1.Controls.Add(this.cboClientType);
            this.ftGroupBox1.Controls.Add(this.lblClientPANNo);
            this.ftGroupBox1.Controls.Add(this.txtClientCode);
            this.ftGroupBox1.Controls.Add(this.lblClientType);
            this.ftGroupBox1.Controls.Add(this.chkPanExempt);
            this.ftGroupBox1.Controls.Add(this.lblCreationDate);
            this.ftGroupBox1.Controls.Add(this.lblDOB);
            this.ftGroupBox1.Controls.Add(this.lblMaritalStatus);
            this.ftGroupBox1.Controls.Add(this.lblGuardianName);
            this.ftGroupBox1.Controls.Add(this.lblGender);
            this.ftGroupBox1.Controls.Add(this.lblClientCode);
            this.ftGroupBox1.Controls.Add(this.txtGuardianName);
            this.ftGroupBox1.Controls.Add(this.txtClientPANNo);
            this.ftGroupBox1.Controls.Add(this.txtClientName);
            this.ftGroupBox1.Controls.Add(this.cboMaritalStatus);
            this.ftGroupBox1.Controls.Add(this.cboGender);
            this.ftGroupBox1.Controls.Add(this.dtpCreationDate);
            this.ftGroupBox1.Controls.Add(this.dtpDOB);
            this.ftGroupBox1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.ftGroupBox1.ForeColor = System.Drawing.Color.Black;
            this.ftGroupBox1.Location = new System.Drawing.Point(9, -1);
            this.ftGroupBox1.Name = "ftGroupBox1";
            this.ftGroupBox1.Size = new System.Drawing.Size(844, 133);
            this.ftGroupBox1.TabIndex = 54;
            this.ftGroupBox1.TabStop = false;
            // 
            // cboClientStatus
            // 
            this.cboClientStatus.BackColor = System.Drawing.Color.White;
            this.cboClientStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboClientStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboClientStatus.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboClientStatus.ForeColor = System.Drawing.Color.Black;
            this.cboClientStatus.FormattingEnabled = true;
            this.cboClientStatus.Location = new System.Drawing.Point(550, 78);
            this.cboClientStatus.MaxLength = 25;
            this.cboClientStatus.Name = "cboClientStatus";
            this.cboClientStatus.ReadOnly = false;
            this.cboClientStatus.Size = new System.Drawing.Size(119, 20);
            this.cboClientStatus.TabIndex = 14;
            // 
            // lblClientStatus
            // 
            this.lblClientStatus.AllowForeColorChange = false;
            this.lblClientStatus.AutoSize = true;
            this.lblClientStatus.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblClientStatus.ForeColor = System.Drawing.Color.Black;
            this.lblClientStatus.Location = new System.Drawing.Point(471, 82);
            this.lblClientStatus.Name = "lblClientStatus";
            this.lblClientStatus.OverrideDefault = false;
            this.lblClientStatus.Size = new System.Drawing.Size(32, 12);
            this.lblClientStatus.TabIndex = 13;
            this.lblClientStatus.Text = "Status";
            // 
            // cboClientType
            // 
            this.cboClientType.BackColor = System.Drawing.Color.White;
            this.cboClientType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboClientType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboClientType.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboClientType.ForeColor = System.Drawing.Color.Black;
            this.cboClientType.FormattingEnabled = true;
            this.cboClientType.Location = new System.Drawing.Point(170, 78);
            this.cboClientType.MaxLength = 25;
            this.cboClientType.Name = "cboClientType";
            this.cboClientType.ReadOnly = false;
            this.cboClientType.Size = new System.Drawing.Size(243, 20);
            this.cboClientType.TabIndex = 12;
            // 
            // lblClientPANNo
            // 
            this.lblClientPANNo.AllowForeColorChange = false;
            this.lblClientPANNo.AutoSize = true;
            this.lblClientPANNo.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblClientPANNo.ForeColor = System.Drawing.Color.Black;
            this.lblClientPANNo.Location = new System.Drawing.Point(17, 105);
            this.lblClientPANNo.Name = "lblClientPANNo";
            this.lblClientPANNo.OverrideDefault = false;
            this.lblClientPANNo.Size = new System.Drawing.Size(61, 12);
            this.lblClientPANNo.TabIndex = 15;
            this.lblClientPANNo.Text = "PAN Exempt";
            // 
            // txtClientCode
            // 
            this.txtClientCode.AllowAlpha = true;
            this.txtClientCode.AllowDot = true;
            this.txtClientCode.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtClientCode.AllowedCustomCharacters")));
            this.txtClientCode.AllowNonASCII = false;
            this.txtClientCode.AllowNumeric = true;
            this.txtClientCode.AllowSpace = true;
            this.txtClientCode.AllowSpecialChars = true;
            this.txtClientCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtClientCode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtClientCode.ForeColor = System.Drawing.Color.Black;
            this.txtClientCode.IsEmailID = true;
            this.txtClientCode.IsEmailIdValid = false;
            this.txtClientCode.Location = new System.Drawing.Point(168, 17);
            this.txtClientCode.Name = "txtClientCode";
            this.txtClientCode.Size = new System.Drawing.Size(115, 20);
            this.txtClientCode.TabIndex = 1;
            // 
            // lblClientType
            // 
            this.lblClientType.AllowForeColorChange = false;
            this.lblClientType.AutoSize = true;
            this.lblClientType.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblClientType.ForeColor = System.Drawing.Color.Black;
            this.lblClientType.Location = new System.Drawing.Point(17, 78);
            this.lblClientType.Name = "lblClientType";
            this.lblClientType.OverrideDefault = false;
            this.lblClientType.Size = new System.Drawing.Size(28, 12);
            this.lblClientType.TabIndex = 11;
            this.lblClientType.Text = "Type";
            // 
            // chkPanExempt
            // 
            this.chkPanExempt.AutoSize = true;
            this.chkPanExempt.Location = new System.Drawing.Point(168, 108);
            this.chkPanExempt.Name = "chkPanExempt";
            this.chkPanExempt.Size = new System.Drawing.Size(15, 14);
            this.chkPanExempt.TabIndex = 16;
            this.chkPanExempt.UseVisualStyleBackColor = true;
            // 
            // lblCreationDate
            // 
            this.lblCreationDate.AllowForeColorChange = false;
            this.lblCreationDate.AutoSize = true;
            this.lblCreationDate.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblCreationDate.ForeColor = System.Drawing.Color.Black;
            this.lblCreationDate.Location = new System.Drawing.Point(17, 52);
            this.lblCreationDate.Name = "lblCreationDate";
            this.lblCreationDate.OverrideDefault = false;
            this.lblCreationDate.Size = new System.Drawing.Size(66, 12);
            this.lblCreationDate.TabIndex = 3;
            this.lblCreationDate.Text = "Creation Date";
            // 
            // lblDOB
            // 
            this.lblDOB.AllowForeColorChange = false;
            this.lblDOB.AutoSize = true;
            this.lblDOB.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblDOB.ForeColor = System.Drawing.Color.Black;
            this.lblDOB.Location = new System.Drawing.Point(290, 53);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.OverrideDefault = false;
            this.lblDOB.Size = new System.Drawing.Size(55, 12);
            this.lblDOB.TabIndex = 5;
            this.lblDOB.Text = "DOB / DOI";
            // 
            // lblMaritalStatus
            // 
            this.lblMaritalStatus.AllowForeColorChange = false;
            this.lblMaritalStatus.AutoSize = true;
            this.lblMaritalStatus.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblMaritalStatus.ForeColor = System.Drawing.Color.Black;
            this.lblMaritalStatus.Location = new System.Drawing.Point(622, 53);
            this.lblMaritalStatus.Name = "lblMaritalStatus";
            this.lblMaritalStatus.OverrideDefault = false;
            this.lblMaritalStatus.Size = new System.Drawing.Size(64, 12);
            this.lblMaritalStatus.TabIndex = 9;
            this.lblMaritalStatus.Text = "Marital Status";
            // 
            // lblGuardianName
            // 
            this.lblGuardianName.AllowForeColorChange = false;
            this.lblGuardianName.AutoSize = true;
            this.lblGuardianName.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblGuardianName.ForeColor = System.Drawing.Color.Black;
            this.lblGuardianName.Location = new System.Drawing.Point(469, 108);
            this.lblGuardianName.Name = "lblGuardianName";
            this.lblGuardianName.OverrideDefault = false;
            this.lblGuardianName.Size = new System.Drawing.Size(74, 12);
            this.lblGuardianName.TabIndex = 18;
            this.lblGuardianName.Text = "Guardian Name";
            // 
            // lblGender
            // 
            this.lblGender.AllowForeColorChange = false;
            this.lblGender.AutoSize = true;
            this.lblGender.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblGender.ForeColor = System.Drawing.Color.Black;
            this.lblGender.Location = new System.Drawing.Point(471, 53);
            this.lblGender.Name = "lblGender";
            this.lblGender.OverrideDefault = false;
            this.lblGender.Size = new System.Drawing.Size(38, 12);
            this.lblGender.TabIndex = 7;
            this.lblGender.Text = "Gender";
            // 
            // lblClientCode
            // 
            this.lblClientCode.AllowForeColorChange = false;
            this.lblClientCode.AutoSize = true;
            this.lblClientCode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblClientCode.ForeColor = System.Drawing.Color.Black;
            this.lblClientCode.Location = new System.Drawing.Point(17, 21);
            this.lblClientCode.Name = "lblClientCode";
            this.lblClientCode.OverrideDefault = false;
            this.lblClientCode.Size = new System.Drawing.Size(30, 12);
            this.lblClientCode.TabIndex = 0;
            this.lblClientCode.Text = "Client";
            // 
            // txtGuardianName
            // 
            this.txtGuardianName.AllowAlpha = true;
            this.txtGuardianName.AllowDot = true;
            this.txtGuardianName.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtGuardianName.AllowedCustomCharacters")));
            this.txtGuardianName.AllowNonASCII = false;
            this.txtGuardianName.AllowNumeric = true;
            this.txtGuardianName.AllowSpace = true;
            this.txtGuardianName.AllowSpecialChars = true;
            this.txtGuardianName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtGuardianName.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtGuardianName.ForeColor = System.Drawing.Color.Black;
            this.txtGuardianName.IsEmailID = true;
            this.txtGuardianName.IsEmailIdValid = false;
            this.txtGuardianName.Location = new System.Drawing.Point(579, 105);
            this.txtGuardianName.MaxLength = 255;
            this.txtGuardianName.Name = "txtGuardianName";
            this.txtGuardianName.Size = new System.Drawing.Size(260, 20);
            this.txtGuardianName.TabIndex = 19;
            // 
            // txtClientPANNo
            // 
            this.txtClientPANNo.AllowAlpha = true;
            this.txtClientPANNo.AllowDot = true;
            this.txtClientPANNo.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtClientPANNo.AllowedCustomCharacters")));
            this.txtClientPANNo.AllowNonASCII = false;
            this.txtClientPANNo.AllowNumeric = true;
            this.txtClientPANNo.AllowSpace = true;
            this.txtClientPANNo.AllowSpecialChars = true;
            this.txtClientPANNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtClientPANNo.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtClientPANNo.ForeColor = System.Drawing.Color.Black;
            this.txtClientPANNo.IsEmailID = true;
            this.txtClientPANNo.IsEmailIdValid = false;
            this.txtClientPANNo.Location = new System.Drawing.Point(187, 105);
            this.txtClientPANNo.Name = "txtClientPANNo";
            this.txtClientPANNo.ReadOnly = true;
            this.txtClientPANNo.Size = new System.Drawing.Size(226, 20);
            this.txtClientPANNo.TabIndex = 17;
            // 
            // txtClientName
            // 
            this.txtClientName.AllowAlpha = true;
            this.txtClientName.AllowDot = true;
            this.txtClientName.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtClientName.AllowedCustomCharacters")));
            this.txtClientName.AllowNonASCII = false;
            this.txtClientName.AllowNumeric = true;
            this.txtClientName.AllowSpace = true;
            this.txtClientName.AllowSpecialChars = true;
            this.txtClientName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtClientName.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtClientName.ForeColor = System.Drawing.Color.Black;
            this.txtClientName.IsEmailID = true;
            this.txtClientName.IsEmailIdValid = false;
            this.txtClientName.Location = new System.Drawing.Point(289, 17);
            this.txtClientName.Name = "txtClientName";
            this.txtClientName.Size = new System.Drawing.Size(550, 20);
            this.txtClientName.TabIndex = 2;
            // 
            // cboMaritalStatus
            // 
            this.cboMaritalStatus.BackColor = System.Drawing.Color.White;
            this.cboMaritalStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMaritalStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboMaritalStatus.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboMaritalStatus.ForeColor = System.Drawing.Color.Black;
            this.cboMaritalStatus.FormattingEnabled = true;
            this.cboMaritalStatus.Location = new System.Drawing.Point(694, 49);
            this.cboMaritalStatus.MaxLength = 25;
            this.cboMaritalStatus.Name = "cboMaritalStatus";
            this.cboMaritalStatus.ReadOnly = false;
            this.cboMaritalStatus.Size = new System.Drawing.Size(145, 20);
            this.cboMaritalStatus.TabIndex = 10;
            // 
            // cboGender
            // 
            this.cboGender.BackColor = System.Drawing.Color.White;
            this.cboGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboGender.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboGender.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboGender.ForeColor = System.Drawing.Color.Black;
            this.cboGender.FormattingEnabled = true;
            this.cboGender.Location = new System.Drawing.Point(522, 49);
            this.cboGender.MaxLength = 25;
            this.cboGender.Name = "cboGender";
            this.cboGender.ReadOnly = false;
            this.cboGender.Size = new System.Drawing.Size(99, 20);
            this.cboGender.TabIndex = 8;
            // 
            // dtpCreationDate
            // 
            this.dtpCreationDate.CalendarForeColor = System.Drawing.Color.Black;
            this.dtpCreationDate.Enabled = false;
            this.dtpCreationDate.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpCreationDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpCreationDate.Location = new System.Drawing.Point(168, 49);
            this.dtpCreationDate.Name = "dtpCreationDate";
            this.dtpCreationDate.ShowCheckBox = true;
            this.dtpCreationDate.Size = new System.Drawing.Size(115, 21);
            this.dtpCreationDate.TabIndex = 4;
            // 
            // dtpDOB
            // 
            this.dtpDOB.CalendarForeColor = System.Drawing.Color.Black;
            this.dtpDOB.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDOB.Location = new System.Drawing.Point(349, 49);
            this.dtpDOB.Name = "dtpDOB";
            this.dtpDOB.ShowCheckBox = true;
            this.dtpDOB.Size = new System.Drawing.Size(115, 21);
            this.dtpDOB.TabIndex = 6;
            // 
            // lblCorporateClientType
            // 
            this.lblCorporateClientType.AllowForeColorChange = false;
            this.lblCorporateClientType.AutoSize = true;
            this.lblCorporateClientType.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblCorporateClientType.ForeColor = System.Drawing.Color.Black;
            this.lblCorporateClientType.Location = new System.Drawing.Point(452, 381);
            this.lblCorporateClientType.Name = "lblCorporateClientType";
            this.lblCorporateClientType.OverrideDefault = false;
            this.lblCorporateClientType.Size = new System.Drawing.Size(105, 12);
            this.lblCorporateClientType.TabIndex = 31;
            this.lblCorporateClientType.Text = "Corporate Client Type";
            // 
            // chkCorporateClientType
            // 
            this.chkCorporateClientType.AutoSize = true;
            this.chkCorporateClientType.Location = new System.Drawing.Point(587, 383);
            this.chkCorporateClientType.Name = "chkCorporateClientType";
            this.chkCorporateClientType.Size = new System.Drawing.Size(15, 14);
            this.chkCorporateClientType.TabIndex = 32;
            this.chkCorporateClientType.UseVisualStyleBackColor = true;
            // 
            // cboTypeofFacility
            // 
            this.cboTypeofFacility.BackColor = System.Drawing.Color.White;
            this.cboTypeofFacility.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTypeofFacility.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboTypeofFacility.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboTypeofFacility.ForeColor = System.Drawing.Color.Black;
            this.cboTypeofFacility.FormattingEnabled = true;
            this.cboTypeofFacility.Location = new System.Drawing.Point(173, 377);
            this.cboTypeofFacility.MaxLength = 25;
            this.cboTypeofFacility.Name = "cboTypeofFacility";
            this.cboTypeofFacility.ReadOnly = false;
            this.cboTypeofFacility.Size = new System.Drawing.Size(119, 20);
            this.cboTypeofFacility.TabIndex = 30;
            // 
            // lblTypeofFacility
            // 
            this.lblTypeofFacility.AllowForeColorChange = false;
            this.lblTypeofFacility.AutoSize = true;
            this.lblTypeofFacility.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblTypeofFacility.ForeColor = System.Drawing.Color.Black;
            this.lblTypeofFacility.Location = new System.Drawing.Point(26, 377);
            this.lblTypeofFacility.Name = "lblTypeofFacility";
            this.lblTypeofFacility.OverrideDefault = false;
            this.lblTypeofFacility.Size = new System.Drawing.Size(74, 12);
            this.lblTypeofFacility.TabIndex = 29;
            this.lblTypeofFacility.Text = "Type of Facility";
            // 
            // lblRelationship
            // 
            this.lblRelationship.AllowForeColorChange = false;
            this.lblRelationship.AutoSize = true;
            this.lblRelationship.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblRelationship.ForeColor = System.Drawing.Color.Black;
            this.lblRelationship.Location = new System.Drawing.Point(452, 352);
            this.lblRelationship.Name = "lblRelationship";
            this.lblRelationship.OverrideDefault = false;
            this.lblRelationship.Size = new System.Drawing.Size(58, 12);
            this.lblRelationship.TabIndex = 27;
            this.lblRelationship.Text = "Relationship";
            // 
            // cboRelationship
            // 
            this.cboRelationship.BackColor = System.Drawing.Color.White;
            this.cboRelationship.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboRelationship.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboRelationship.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboRelationship.ForeColor = System.Drawing.Color.Black;
            this.cboRelationship.FormattingEnabled = true;
            this.cboRelationship.Location = new System.Drawing.Point(569, 351);
            this.cboRelationship.MaxLength = 25;
            this.cboRelationship.Name = "cboRelationship";
            this.cboRelationship.ReadOnly = false;
            this.cboRelationship.Size = new System.Drawing.Size(280, 20);
            this.cboRelationship.TabIndex = 28;
            this.cboRelationship.Visible = false;
            // 
            // lblCIN
            // 
            this.lblCIN.AllowForeColorChange = false;
            this.lblCIN.AutoSize = true;
            this.lblCIN.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblCIN.ForeColor = System.Drawing.Color.Black;
            this.lblCIN.Location = new System.Drawing.Point(26, 169);
            this.lblCIN.Name = "lblCIN";
            this.lblCIN.OverrideDefault = false;
            this.lblCIN.Size = new System.Drawing.Size(59, 12);
            this.lblCIN.TabIndex = 3;
            this.lblCIN.Text = "CIN Exempt";
            // 
            // chkCINExempt
            // 
            this.chkCINExempt.AutoSize = true;
            this.chkCINExempt.Location = new System.Drawing.Point(173, 170);
            this.chkCINExempt.Name = "chkCINExempt";
            this.chkCINExempt.Size = new System.Drawing.Size(15, 14);
            this.chkCINExempt.TabIndex = 4;
            this.chkCINExempt.UseVisualStyleBackColor = true;
            this.chkCINExempt.CheckedChanged += new System.EventHandler(this.chkCINExempt_CheckedChanged);
            // 
            // lblGrossAnnualIncomeRange
            // 
            this.lblGrossAnnualIncomeRange.AllowForeColorChange = false;
            this.lblGrossAnnualIncomeRange.AutoSize = true;
            this.lblGrossAnnualIncomeRange.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblGrossAnnualIncomeRange.ForeColor = System.Drawing.Color.Black;
            this.lblGrossAnnualIncomeRange.Location = new System.Drawing.Point(26, 199);
            this.lblGrossAnnualIncomeRange.Name = "lblGrossAnnualIncomeRange";
            this.lblGrossAnnualIncomeRange.OverrideDefault = false;
            this.lblGrossAnnualIncomeRange.Size = new System.Drawing.Size(133, 12);
            this.lblGrossAnnualIncomeRange.TabIndex = 6;
            this.lblGrossAnnualIncomeRange.Text = "Gross Annual Income Range";
            // 
            // lblGrossAnnualIncomeasonDate
            // 
            this.lblGrossAnnualIncomeasonDate.AllowForeColorChange = false;
            this.lblGrossAnnualIncomeasonDate.AutoSize = true;
            this.lblGrossAnnualIncomeasonDate.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblGrossAnnualIncomeasonDate.ForeColor = System.Drawing.Color.Black;
            this.lblGrossAnnualIncomeasonDate.Location = new System.Drawing.Point(452, 200);
            this.lblGrossAnnualIncomeasonDate.Name = "lblGrossAnnualIncomeasonDate";
            this.lblGrossAnnualIncomeasonDate.OverrideDefault = false;
            this.lblGrossAnnualIncomeasonDate.Size = new System.Drawing.Size(125, 12);
            this.lblGrossAnnualIncomeasonDate.TabIndex = 8;
            this.lblGrossAnnualIncomeasonDate.Text = "Gross Annual Income Date";
            // 
            // cboGrossAnnualIncomeRange
            // 
            this.cboGrossAnnualIncomeRange.BackColor = System.Drawing.Color.White;
            this.cboGrossAnnualIncomeRange.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboGrossAnnualIncomeRange.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboGrossAnnualIncomeRange.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboGrossAnnualIncomeRange.ForeColor = System.Drawing.Color.Black;
            this.cboGrossAnnualIncomeRange.FormattingEnabled = true;
            this.cboGrossAnnualIncomeRange.Location = new System.Drawing.Point(173, 196);
            this.cboGrossAnnualIncomeRange.MaxLength = 25;
            this.cboGrossAnnualIncomeRange.Name = "cboGrossAnnualIncomeRange";
            this.cboGrossAnnualIncomeRange.ReadOnly = false;
            this.cboGrossAnnualIncomeRange.Size = new System.Drawing.Size(240, 20);
            this.cboGrossAnnualIncomeRange.TabIndex = 7;
            this.cboGrossAnnualIncomeRange.SelectedIndexChanged += new System.EventHandler(this.cboGrossAnnualIncomeRange_SelectedIndexChanged);
            // 
            // lblUpdationFlagNew
            // 
            this.lblUpdationFlagNew.AllowForeColorChange = false;
            this.lblUpdationFlagNew.AutoSize = true;
            this.lblUpdationFlagNew.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblUpdationFlagNew.ForeColor = System.Drawing.Color.Black;
            this.lblUpdationFlagNew.Location = new System.Drawing.Point(26, 351);
            this.lblUpdationFlagNew.Name = "lblUpdationFlagNew";
            this.lblUpdationFlagNew.OverrideDefault = false;
            this.lblUpdationFlagNew.Size = new System.Drawing.Size(68, 12);
            this.lblUpdationFlagNew.TabIndex = 25;
            this.lblUpdationFlagNew.Text = "Updation Flag";
            // 
            // dtpGrossAnnualIncomeasonDate
            // 
            this.dtpGrossAnnualIncomeasonDate.CalendarForeColor = System.Drawing.Color.Black;
            this.dtpGrossAnnualIncomeasonDate.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpGrossAnnualIncomeasonDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpGrossAnnualIncomeasonDate.Location = new System.Drawing.Point(588, 196);
            this.dtpGrossAnnualIncomeasonDate.Name = "dtpGrossAnnualIncomeasonDate";
            this.dtpGrossAnnualIncomeasonDate.ShowCheckBox = true;
            this.dtpGrossAnnualIncomeasonDate.Size = new System.Drawing.Size(115, 21);
            this.dtpGrossAnnualIncomeasonDate.TabIndex = 9;
            // 
            // chkUpdationFlagNew
            // 
            this.chkUpdationFlagNew.AutoSize = true;
            this.chkUpdationFlagNew.Location = new System.Drawing.Point(173, 354);
            this.chkUpdationFlagNew.Name = "chkUpdationFlagNew";
            this.chkUpdationFlagNew.Size = new System.Drawing.Size(15, 14);
            this.chkUpdationFlagNew.TabIndex = 26;
            this.chkUpdationFlagNew.UseVisualStyleBackColor = true;
            this.chkUpdationFlagNew.Visible = false;
            // 
            // dtpNetWorthAsOnDate
            // 
            this.dtpNetWorthAsOnDate.CalendarForeColor = System.Drawing.Color.Black;
            this.dtpNetWorthAsOnDate.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpNetWorthAsOnDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNetWorthAsOnDate.Location = new System.Drawing.Point(585, 228);
            this.dtpNetWorthAsOnDate.Name = "dtpNetWorthAsOnDate";
            this.dtpNetWorthAsOnDate.ShowCheckBox = true;
            this.dtpNetWorthAsOnDate.Size = new System.Drawing.Size(115, 21);
            this.dtpNetWorthAsOnDate.TabIndex = 13;
            // 
            // dtpBusinessCommencementDate
            // 
            this.dtpBusinessCommencementDate.CalendarForeColor = System.Drawing.Color.Black;
            this.dtpBusinessCommencementDate.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpBusinessCommencementDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpBusinessCommencementDate.Location = new System.Drawing.Point(173, 319);
            this.dtpBusinessCommencementDate.Name = "dtpBusinessCommencementDate";
            this.dtpBusinessCommencementDate.ShowCheckBox = true;
            this.dtpBusinessCommencementDate.Size = new System.Drawing.Size(115, 21);
            this.dtpBusinessCommencementDate.TabIndex = 22;
            // 
            // cboOccupation
            // 
            this.cboOccupation.BackColor = System.Drawing.Color.White;
            this.cboOccupation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboOccupation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboOccupation.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboOccupation.ForeColor = System.Drawing.Color.Black;
            this.cboOccupation.FormattingEnabled = true;
            this.cboOccupation.Location = new System.Drawing.Point(173, 289);
            this.cboOccupation.MaxLength = 25;
            this.cboOccupation.Name = "cboOccupation";
            this.cboOccupation.ReadOnly = false;
            this.cboOccupation.Size = new System.Drawing.Size(193, 20);
            this.cboOccupation.TabIndex = 19;
            this.cboOccupation.SelectedIndexChanged += new System.EventHandler(this.cboOccupation_SelectedIndexChanged);
            // 
            // cboNationality
            // 
            this.cboNationality.BackColor = System.Drawing.Color.White;
            this.cboNationality.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNationality.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboNationality.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboNationality.ForeColor = System.Drawing.Color.Black;
            this.cboNationality.FormattingEnabled = true;
            this.cboNationality.Location = new System.Drawing.Point(173, 138);
            this.cboNationality.MaxLength = 25;
            this.cboNationality.Name = "cboNationality";
            this.cboNationality.ReadOnly = false;
            this.cboNationality.Size = new System.Drawing.Size(119, 20);
            this.cboNationality.TabIndex = 1;
            this.cboNationality.SelectedIndexChanged += new System.EventHandler(this.cboNationality_SelectedIndexChanged);
            // 
            // cboPEP
            // 
            this.cboPEP.BackColor = System.Drawing.Color.White;
            this.cboPEP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPEP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboPEP.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboPEP.ForeColor = System.Drawing.Color.Black;
            this.cboPEP.FormattingEnabled = true;
            this.cboPEP.Location = new System.Drawing.Point(173, 257);
            this.cboPEP.MaxLength = 25;
            this.cboPEP.Name = "cboPEP";
            this.cboPEP.ReadOnly = false;
            this.cboPEP.Size = new System.Drawing.Size(119, 20);
            this.cboPEP.TabIndex = 15;
            // 
            // txtNationalityName
            // 
            this.txtNationalityName.AllowAlpha = true;
            this.txtNationalityName.AllowDot = true;
            this.txtNationalityName.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtNationalityName.AllowedCustomCharacters")));
            this.txtNationalityName.AllowNonASCII = false;
            this.txtNationalityName.AllowNumeric = true;
            this.txtNationalityName.AllowSpace = true;
            this.txtNationalityName.AllowSpecialChars = true;
            this.txtNationalityName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNationalityName.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtNationalityName.ForeColor = System.Drawing.Color.Black;
            this.txtNationalityName.IsEmailID = true;
            this.txtNationalityName.IsEmailIdValid = false;
            this.txtNationalityName.Location = new System.Drawing.Point(298, 138);
            this.txtNationalityName.MaxLength = 50;
            this.txtNationalityName.Name = "txtNationalityName";
            this.txtNationalityName.Size = new System.Drawing.Size(550, 20);
            this.txtNationalityName.TabIndex = 2;
            // 
            // txtCIN
            // 
            this.txtCIN.AllowAlpha = true;
            this.txtCIN.AllowDot = false;
            this.txtCIN.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtCIN.AllowedCustomCharacters")));
            this.txtCIN.AllowNonASCII = false;
            this.txtCIN.AllowNumeric = true;
            this.txtCIN.AllowSpace = false;
            this.txtCIN.AllowSpecialChars = false;
            this.txtCIN.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCIN.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtCIN.ForeColor = System.Drawing.Color.Black;
            this.txtCIN.IsEmailID = true;
            this.txtCIN.IsEmailIdValid = false;
            this.txtCIN.Location = new System.Drawing.Point(194, 168);
            this.txtCIN.MaxLength = 21;
            this.txtCIN.Name = "txtCIN";
            this.txtCIN.Size = new System.Drawing.Size(654, 20);
            this.txtCIN.TabIndex = 5;
            // 
            // txtNetWorth
            // 
            this.txtNetWorth.AllowAlpha = false;
            this.txtNetWorth.AllowDot = true;
            this.txtNetWorth.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtNetWorth.AllowedCustomCharacters")));
            this.txtNetWorth.AllowNonASCII = false;
            this.txtNetWorth.AllowNumeric = true;
            this.txtNetWorth.AllowSpace = false;
            this.txtNetWorth.AllowSpecialChars = false;
            this.txtNetWorth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNetWorth.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtNetWorth.ForeColor = System.Drawing.Color.Black;
            this.txtNetWorth.IsEmailID = true;
            this.txtNetWorth.IsEmailIdValid = false;
            this.txtNetWorth.Location = new System.Drawing.Point(173, 228);
            this.txtNetWorth.MaxLength = 19;
            this.txtNetWorth.Name = "txtNetWorth";
            this.txtNetWorth.Size = new System.Drawing.Size(240, 20);
            this.txtNetWorth.TabIndex = 11;
            this.txtNetWorth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtOccupationName
            // 
            this.txtOccupationName.AllowAlpha = true;
            this.txtOccupationName.AllowDot = true;
            this.txtOccupationName.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtOccupationName.AllowedCustomCharacters")));
            this.txtOccupationName.AllowNonASCII = false;
            this.txtOccupationName.AllowNumeric = true;
            this.txtOccupationName.AllowSpace = true;
            this.txtOccupationName.AllowSpecialChars = true;
            this.txtOccupationName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtOccupationName.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtOccupationName.ForeColor = System.Drawing.Color.Black;
            this.txtOccupationName.IsEmailID = true;
            this.txtOccupationName.IsEmailIdValid = false;
            this.txtOccupationName.Location = new System.Drawing.Point(394, 289);
            this.txtOccupationName.MaxLength = 75;
            this.txtOccupationName.Name = "txtOccupationName";
            this.txtOccupationName.Size = new System.Drawing.Size(454, 20);
            this.txtOccupationName.TabIndex = 20;
            // 
            // txtPlaceofIncorporation
            // 
            this.txtPlaceofIncorporation.AllowAlpha = true;
            this.txtPlaceofIncorporation.AllowDot = true;
            this.txtPlaceofIncorporation.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtPlaceofIncorporation.AllowedCustomCharacters")));
            this.txtPlaceofIncorporation.AllowNonASCII = false;
            this.txtPlaceofIncorporation.AllowNumeric = true;
            this.txtPlaceofIncorporation.AllowSpace = true;
            this.txtPlaceofIncorporation.AllowSpecialChars = true;
            this.txtPlaceofIncorporation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPlaceofIncorporation.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtPlaceofIncorporation.ForeColor = System.Drawing.Color.Black;
            this.txtPlaceofIncorporation.IsEmailID = true;
            this.txtPlaceofIncorporation.IsEmailIdValid = false;
            this.txtPlaceofIncorporation.Location = new System.Drawing.Point(585, 257);
            this.txtPlaceofIncorporation.MaxLength = 75;
            this.txtPlaceofIncorporation.Name = "txtPlaceofIncorporation";
            this.txtPlaceofIncorporation.Size = new System.Drawing.Size(263, 20);
            this.txtPlaceofIncorporation.TabIndex = 17;
            // 
            // txtUCCCode
            // 
            this.txtUCCCode.AllowAlpha = true;
            this.txtUCCCode.AllowDot = true;
            this.txtUCCCode.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtUCCCode.AllowedCustomCharacters")));
            this.txtUCCCode.AllowNonASCII = false;
            this.txtUCCCode.AllowNumeric = true;
            this.txtUCCCode.AllowSpace = true;
            this.txtUCCCode.AllowSpecialChars = true;
            this.txtUCCCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUCCCode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtUCCCode.ForeColor = System.Drawing.Color.Black;
            this.txtUCCCode.IsEmailID = true;
            this.txtUCCCode.IsEmailIdValid = false;
            this.txtUCCCode.Location = new System.Drawing.Point(585, 321);
            this.txtUCCCode.MaxLength = 10;
            this.txtUCCCode.Name = "txtUCCCode";
            this.txtUCCCode.Size = new System.Drawing.Size(263, 20);
            this.txtUCCCode.TabIndex = 24;
            // 
            // lblUCCCode
            // 
            this.lblUCCCode.AllowForeColorChange = false;
            this.lblUCCCode.AutoSize = true;
            this.lblUCCCode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblUCCCode.ForeColor = System.Drawing.Color.Black;
            this.lblUCCCode.Location = new System.Drawing.Point(452, 322);
            this.lblUCCCode.Name = "lblUCCCode";
            this.lblUCCCode.OverrideDefault = false;
            this.lblUCCCode.Size = new System.Drawing.Size(53, 12);
            this.lblUCCCode.TabIndex = 23;
            this.lblUCCCode.Text = "UCC Code";
            // 
            // lblNetWorth
            // 
            this.lblNetWorth.AllowForeColorChange = false;
            this.lblNetWorth.AutoSize = true;
            this.lblNetWorth.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblNetWorth.ForeColor = System.Drawing.Color.Black;
            this.lblNetWorth.Location = new System.Drawing.Point(26, 230);
            this.lblNetWorth.Name = "lblNetWorth";
            this.lblNetWorth.OverrideDefault = false;
            this.lblNetWorth.Size = new System.Drawing.Size(47, 12);
            this.lblNetWorth.TabIndex = 10;
            this.lblNetWorth.Text = "Networth";
            // 
            // lblPEP
            // 
            this.lblPEP.AllowForeColorChange = false;
            this.lblPEP.AutoSize = true;
            this.lblPEP.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblPEP.ForeColor = System.Drawing.Color.Black;
            this.lblPEP.Location = new System.Drawing.Point(26, 261);
            this.lblPEP.Name = "lblPEP";
            this.lblPEP.OverrideDefault = false;
            this.lblPEP.Size = new System.Drawing.Size(23, 12);
            this.lblPEP.TabIndex = 14;
            this.lblPEP.Text = "PEP";
            // 
            // lblOccupation
            // 
            this.lblOccupation.AllowForeColorChange = false;
            this.lblOccupation.AutoSize = true;
            this.lblOccupation.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblOccupation.ForeColor = System.Drawing.Color.Black;
            this.lblOccupation.Location = new System.Drawing.Point(26, 289);
            this.lblOccupation.Name = "lblOccupation";
            this.lblOccupation.OverrideDefault = false;
            this.lblOccupation.Size = new System.Drawing.Size(57, 12);
            this.lblOccupation.TabIndex = 18;
            this.lblOccupation.Text = "Occupation";
            // 
            // lblPlaceofIncorporation
            // 
            this.lblPlaceofIncorporation.AllowForeColorChange = false;
            this.lblPlaceofIncorporation.AutoSize = true;
            this.lblPlaceofIncorporation.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblPlaceofIncorporation.ForeColor = System.Drawing.Color.Black;
            this.lblPlaceofIncorporation.Location = new System.Drawing.Point(452, 261);
            this.lblPlaceofIncorporation.Name = "lblPlaceofIncorporation";
            this.lblPlaceofIncorporation.OverrideDefault = false;
            this.lblPlaceofIncorporation.Size = new System.Drawing.Size(106, 12);
            this.lblPlaceofIncorporation.TabIndex = 16;
            this.lblPlaceofIncorporation.Text = "Place of Incorporation";
            // 
            // lblBusinessCommencementDate
            // 
            this.lblBusinessCommencementDate.AllowForeColorChange = false;
            this.lblBusinessCommencementDate.AutoSize = true;
            this.lblBusinessCommencementDate.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblBusinessCommencementDate.ForeColor = System.Drawing.Color.Black;
            this.lblBusinessCommencementDate.Location = new System.Drawing.Point(26, 320);
            this.lblBusinessCommencementDate.Name = "lblBusinessCommencementDate";
            this.lblBusinessCommencementDate.OverrideDefault = false;
            this.lblBusinessCommencementDate.Size = new System.Drawing.Size(141, 12);
            this.lblBusinessCommencementDate.TabIndex = 21;
            this.lblBusinessCommencementDate.Text = "Business commencement  Date";
            // 
            // lblNationality
            // 
            this.lblNationality.AllowForeColorChange = false;
            this.lblNationality.AutoSize = true;
            this.lblNationality.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblNationality.ForeColor = System.Drawing.Color.Black;
            this.lblNationality.Location = new System.Drawing.Point(26, 139);
            this.lblNationality.Name = "lblNationality";
            this.lblNationality.OverrideDefault = false;
            this.lblNationality.Size = new System.Drawing.Size(52, 12);
            this.lblNationality.TabIndex = 0;
            this.lblNationality.Text = "Nationality";
            // 
            // lblNetWorthAsOnDate
            // 
            this.lblNetWorthAsOnDate.AllowForeColorChange = false;
            this.lblNetWorthAsOnDate.AutoSize = true;
            this.lblNetWorthAsOnDate.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblNetWorthAsOnDate.ForeColor = System.Drawing.Color.Black;
            this.lblNetWorthAsOnDate.Location = new System.Drawing.Point(452, 231);
            this.lblNetWorthAsOnDate.Name = "lblNetWorthAsOnDate";
            this.lblNetWorthAsOnDate.OverrideDefault = false;
            this.lblNetWorthAsOnDate.Size = new System.Drawing.Size(101, 12);
            this.lblNetWorthAsOnDate.TabIndex = 12;
            this.lblNetWorthAsOnDate.Text = "Networth As On Date";
            // 
            // pnlActionControls
            // 
            this.pnlActionControls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlActionControls.Controls.Add(this.btnMakerCancel);
            this.pnlActionControls.Controls.Add(this.btnSave);
            this.pnlActionControls.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlActionControls.Location = new System.Drawing.Point(0, 409);
            this.pnlActionControls.Name = "pnlActionControls";
            this.pnlActionControls.Size = new System.Drawing.Size(856, 37);
            this.pnlActionControls.TabIndex = 56;
            // 
            // btnMakerCancel
            // 
            this.btnMakerCancel.BackColor = System.Drawing.Color.Transparent;
            this.btnMakerCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMakerCancel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btnMakerCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnMakerCancel.Image")));
            this.btnMakerCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMakerCancel.Location = new System.Drawing.Point(657, 6);
            this.btnMakerCancel.Name = "btnMakerCancel";
            this.btnMakerCancel.Size = new System.Drawing.Size(107, 25);
            this.btnMakerCancel.TabIndex = 0;
            this.btnMakerCancel.Text = "&Maker Cancel";
            this.btnMakerCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMakerCancel.UseVisualStyleBackColor = false;
            this.btnMakerCancel.Visible = false;
            this.btnMakerCancel.Click += new System.EventHandler(this.btnMakerCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.BackColor = System.Drawing.Color.Transparent;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Location = new System.Drawing.Point(771, 6);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 25);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "&Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // UCCClientInfoMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.pnlActionControls);
            this.Controls.Add(this.pnlClient);
            this.Name = "UCCClientInfoMain";
            this.Size = new System.Drawing.Size(856, 446);
            this.Load += new System.EventHandler(this.UCCClientInfoMain_Load);
            this.pnlClient.ResumeLayout(false);
            this.pnlClient.PerformLayout();
            this.ftGroupBox1.ResumeLayout(false);
            this.ftGroupBox1.PerformLayout();
            this.pnlActionControls.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MatchCommon.CustomControls.FTPanel pnlClient;
        private MatchCommon.CustomControls.FTLabel lblCorporateClientType;
        private System.Windows.Forms.CheckBox chkCorporateClientType;
        private MatchCommon.CustomControls.FTComboBox cboTypeofFacility;
        private MatchCommon.CustomControls.FTLabel lblTypeofFacility;
        private MatchCommon.CustomControls.FTLabel lblRelationship;
        private MatchCommon.CustomControls.FTComboBox cboRelationship;
        private MatchCommon.CustomControls.FTLabel lblCIN;
        private System.Windows.Forms.CheckBox chkCINExempt;
        private MatchCommon.CustomControls.FTLabel lblGrossAnnualIncomeRange;
        private MatchCommon.CustomControls.FTLabel lblGrossAnnualIncomeasonDate;
        private MatchCommon.CustomControls.FTComboBox cboGrossAnnualIncomeRange;
        private MatchCommon.CustomControls.FTLabel lblUpdationFlagNew;
        private System.Windows.Forms.DateTimePicker dtpGrossAnnualIncomeasonDate;
        private System.Windows.Forms.CheckBox chkUpdationFlagNew;
        private System.Windows.Forms.DateTimePicker dtpNetWorthAsOnDate;
        private System.Windows.Forms.DateTimePicker dtpBusinessCommencementDate;
        private System.Windows.Forms.DateTimePicker dtpDOB;
        private System.Windows.Forms.DateTimePicker dtpCreationDate;
        private MatchCommon.CustomControls.FTComboBox cboOccupation;
        private MatchCommon.CustomControls.FTComboBox cboGender;
        private MatchCommon.CustomControls.FTComboBox cboMaritalStatus;
        private MatchCommon.CustomControls.FTComboBox cboNationality;
        private MatchCommon.CustomControls.FTComboBox cboPEP;
        private MatchCommon.CustomControls.FTTextBox txtClientName;
        private MatchCommon.CustomControls.FTTextBox txtClientPANNo;
        private MatchCommon.CustomControls.FTTextBox txtGuardianName;
        private MatchCommon.CustomControls.FTTextBox txtNationalityName;
        private MatchCommon.CustomControls.FTTextBox txtCIN;
        private MatchCommon.CustomControls.FTTextBox txtNetWorth;
        private MatchCommon.CustomControls.FTTextBox txtOccupationName;
        private MatchCommon.CustomControls.FTTextBox txtPlaceofIncorporation;
        private MatchCommon.CustomControls.FTTextBox txtUCCCode;
        private MatchCommon.CustomControls.FTLabel lblUCCCode;
        private MatchCommon.CustomControls.FTLabel lblNetWorth;
        private MatchCommon.CustomControls.FTLabel lblPEP;
        private MatchCommon.CustomControls.FTLabel lblOccupation;
        private MatchCommon.CustomControls.FTLabel lblPlaceofIncorporation;
        private MatchCommon.CustomControls.FTLabel lblBusinessCommencementDate;
        private MatchCommon.CustomControls.FTLabel lblClientCode;
        private MatchCommon.CustomControls.FTLabel lblGender;
        private MatchCommon.CustomControls.FTLabel lblGuardianName;
        private MatchCommon.CustomControls.FTLabel lblMaritalStatus;
        private MatchCommon.CustomControls.FTLabel lblNationality;
        private MatchCommon.CustomControls.FTLabel lblClientPANNo;
        private MatchCommon.CustomControls.FTLabel lblDOB;
        private MatchCommon.CustomControls.FTLabel lblCreationDate;
        private System.Windows.Forms.CheckBox chkPanExempt;
        private MatchCommon.CustomControls.FTLabel lblNetWorthAsOnDate;
        private MatchCommon.CustomControls.FTTextBox txtClientCode;
        private MatchCommon.CustomControls.FTGroupBox ftGroupBox1;
        private System.Windows.Forms.ToolTip ttMain;
		private MatchCommon.CustomControls.FTComboBox cboClientStatus;
        private MatchCommon.CustomControls.FTLabel lblClientStatus;
        private MatchCommon.CustomControls.FTComboBox cboClientType;
        private MatchCommon.CustomControls.FTLabel lblClientType;
        private MatchCommon.CustomControls.FTPanel pnlActionControls;
        public MatchCommon.CustomControls.FTButton btnMakerCancel;
        private MatchCommon.CustomControls.FTButton btnSave;
    }
}
