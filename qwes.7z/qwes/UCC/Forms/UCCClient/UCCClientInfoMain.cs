﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Collections;

using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;
using UCC.Class;
using System.Text.RegularExpressions;
using FTIL.Match.Common.Utils;
using UCC.Class.Master;

namespace UCC.Forms.UCCClient
{
    /// <summary>
    /// Client Exchange mapping screen user control
    /// </summary>
    public partial class UCCClientInfoMain : UserControl, IEventInfo
    {
        #region Variables

        /// <summary>
        /// Client details BL class instance
        /// </summary>
        CUCCClientInfoClientMaster m_objCClientMaster;

        /// <summary>
        /// Message box title string
        /// </summary>
        private string m_sMsgBoxTitle;

        /// <summary>
        /// Current Client Context instance
        /// </summary>
        private CClient m_objCurrentClient;

        #endregion

        /// <summary>
        /// Client detail class constructor
        /// </summary>
        /// <param name="p_vobjCurrentClient">Client context instance</param>
        #region Constructor
        public UCCClientInfoMain(CClient p_vobjCurrentClient)
        {
            InitializeComponent();

            m_objCurrentClient = p_vobjCurrentClient;
            m_objCClientMaster = new CUCCClientInfoClientMaster();
        }
        #endregion

        #region Events

        /// <summary>
        /// Window load event handler. Initializes menu, controls & loads data
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region UCCClientInfoMain_Load
        private void UCCClientInfoMain_Load(object sender, EventArgs e)
        {
            pnlActionControls.Enabled = m_objCurrentClient.AllowModificationsToCurrentUser;

            PopulateLookUp();
            //RefreshClientData();
            PopulateFieldsNew();
            EnableDisableClientDetailsField(false);

            m_sMsgBoxTitle = this.ParentForm.Text;
        }
        #endregion

        /// <summary>
        /// Closes parent window where this user control is hosted
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region Exit_Click
        /// <summary>
        /// This event is fired when Modify button is clicked.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        private void Exit_Click(object sender, EventArgs e)
        {
            this.ParentForm.Close();
        }
        #endregion

        /// <summary>
        /// Save button event handler. Proceeds to perform changes in database. 
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region Save_Click
        private void Save_Click(object sender, EventArgs e)
        {
            SaveClientDataNew();
        }
        #endregion

        /// <summary>
        /// Nationality item change event handler.
        /// Enable/disables other nationality text box.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region cboNationality_SelectedIndexChanged
        private void cboNationality_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (
                (cboNationality.SelectedValue != null)
                &&
                (cboNationality.SelectedValue.ToString() == CUCCConstants.Instance.OTHER_NATIONALITY_CODE) //Other
               )
            {
                txtNationalityName.Enabled = true;
                txtNationalityName.Focus();
            }
            else
            {
                txtNationalityName.Enabled = false;
                txtNationalityName.Text = string.Empty;
            }
        }
        #endregion

        /// <summary>
        /// Save button click event handler. Redirects to Save_Click event handler.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnSave_Click
        private void btnSave_Click(object sender, EventArgs e)
        {
            Save_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// CIN Exempt check state changed event handler.
        /// Enable/disables CIN text box.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region chkCINExempt_CheckedChanged
        private void chkCINExempt_CheckedChanged(object sender, EventArgs e)
        {
            txtCIN.Enabled = !chkCINExempt.Checked;
            if (txtCIN.Enabled == false)
                txtCIN.Text = string.Empty;
            else
                txtCIN.Focus();
        }
        #endregion

        /// <summary>
        /// Occupation item change event handler.
        /// Enable/disables other occupation text box.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region cboOccupation_SelectedIndexChanged
        private void cboOccupation_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (
                (cboOccupation.SelectedValue != null)
                &&
                (cboOccupation.SelectedValue.ToString() == CUCCConstants.Instance.OTHER_OCCUPATION_REFNO) //Other
               )
            {
                txtOccupationName.Enabled = true;
                txtOccupationName.Focus();
            }
            else
            {
                txtOccupationName.Enabled = false;
                txtOccupationName.Text = string.Empty;
            }
        }
        #endregion

        /// <summary>
        /// Makercancel button click event handler.redirect to CancelMakerChanges function
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">Event argument</param>
        #region btnMakerCancel_Click
        private void btnMakerCancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure to cancel maker changes?", m_sMsgBoxTitle,
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.No)
            {
                return;
            }
            this.CancelMakerChanges();
        }
        #endregion

        /// <summary>
        /// Gross Annual Income Range Selected Index Changed event handler.
        /// Special handling for 'Not Applicable' selection.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        private void cboGrossAnnualIncomeRange_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtpGrossAnnualIncomeasonDate.Enabled = true;
            txtNetWorth.Enabled = true;
            dtpNetWorthAsOnDate.Enabled = true;

            if (
                (cboGrossAnnualIncomeRange.SelectedValue != null)
                && (cboGrossAnnualIncomeRange.SelectedValue.ToString() == CUCCConstants.Instance.GROSS_ANNUAL_INC_NOT_APPLICABLE_REFNO)
              )
            {
                dtpGrossAnnualIncomeasonDate.Checked = false;
                txtNetWorth.Text = string.Empty;
                dtpNetWorthAsOnDate.Checked = false;

                dtpGrossAnnualIncomeasonDate.Enabled = false;
                txtNetWorth.Enabled = false;
                dtpNetWorthAsOnDate.Enabled = false;
            }

            
            if (
               (cboGrossAnnualIncomeRange.SelectedValue != null)
               && (cboGrossAnnualIncomeRange.SelectedValue.ToString() == CUCCConstants.Instance.GROSS_ANNUAL_INC_BLANK)
             )
            {
                dtpGrossAnnualIncomeasonDate.Checked = false;
                dtpGrossAnnualIncomeasonDate.Enabled = false;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Populates help (combo) controls with master values
        /// </summary>
        #region PopulateLookUp
        private void PopulateLookUp()
        {
            if (AppEnvironment.AppSettings.AppProduct == Product.Settlement)
            {
                //dtpDOB.Enabled = false;
                txtGuardianName.Enabled = false;
                chkPanExempt.Enabled = false;
                txtUCCCode.Enabled = false;
                //dtpBusinessCommencementDate.Enabled = false;
            }
            else if (AppEnvironment.AppSettings.AppProduct == Product.Derivative)
            {
                dtpCreationDate.Enabled = false;
                txtGuardianName.Enabled = false;
                chkPanExempt.Enabled = false;
                //chkCINExempt.Enabled = false;
                //txtCIN.Enabled = false;
                //dtpDOB.Enabled = false;
                txtUCCCode.Enabled = false;
                chkUpdationFlagNew.Enabled = false;
                //cboRelationship.Enabled = false;
            }

            cboOccupation.ValueMember = "n_ReferenceNo";
            cboOccupation.DisplayMember = "s_ReferenceName";
            cboOccupation.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.OCCUPATION]; //l_dsPopulateClientDetails.Tables[0];

            cboNationality.ValueMember = "s_ReferenceCode";
            cboNationality.DisplayMember = "s_ReferenceName";
            cboNationality.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.NATIONALTY]; //l_dsPopulateClientDetails.Tables[1];

            cboGender.ValueMember = "s_ReferenceCode";
            cboGender.DisplayMember = "s_ReferenceName";
            cboGender.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.GENDER]; //l_dsPopulateClientDetails.Tables[2];

            cboMaritalStatus.ValueMember = "s_ReferenceCode";
            cboMaritalStatus.DisplayMember = "s_ReferenceName";
            cboMaritalStatus.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.MARITALST]; //l_dsPopulateClientDetails.Tables[3];

            cboGrossAnnualIncomeRange.ValueMember = "n_ReferenceNo";
            cboGrossAnnualIncomeRange.DisplayMember = "s_ReferenceName";
            cboGrossAnnualIncomeRange.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.ANNINC]; //l_dsPopulateClientDetails.Tables[4];

            cboPEP.ValueMember = "s_ReferenceCode";
            cboPEP.DisplayMember = "s_ReferenceName";
            cboPEP.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.PEP]; //l_dsPopulateClientDetails.Tables[5];

            cboTypeofFacility.ValueMember = "s_ReferenceCode";
            cboTypeofFacility.DisplayMember = "s_ReferenceName";
            cboTypeofFacility.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.FACILITY]; //l_dsPopulateClientDetails.Tables[11];

            cboClientType.ValueMember = "s_ReferenceCode";
            cboClientType.DisplayMember = "s_ReferenceName";
            cboClientType.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.MAINCLIENTTYPE]; 

            cboClientStatus.ValueMember = "s_ReferenceCode";
            cboClientStatus.DisplayMember = "s_ReferenceName";
            cboClientStatus.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.CLIENTSTATUS]; 
        }
        #endregion

        /// <summary>
        /// Retrieves/sets data from database again for current client
        /// </summary>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region RefreshClientData
        private long RefreshClientData()
        {
            m_objCurrentClient.ReInitialize();
            PopulateFieldsNew();
            return 0;
        }
        #endregion

        /// <summary>
        /// Clears all input control values
        /// </summary>
        #region ClearControls
        private void ClearControls()
        {
            try
            {
                txtClientCode.Text = string.Empty;
                txtClientName.Text = string.Empty;

                dtpCreationDate.Value = CMatchCommonUtils.Instance.ServerDate;
                dtpCreationDate.Checked = false;

                txtClientPANNo.Text = string.Empty;
                cboGender.SelectedValue = string.Empty;
                txtGuardianName.Text = string.Empty;
                cboMaritalStatus.SelectedValue = string.Empty;
                cboNationality.SelectedValue = string.Empty;
                txtNationalityName.Text = string.Empty;
                chkPanExempt.Checked = false;
                chkCINExempt.Checked = false;
                chkUpdationFlagNew.Checked = false;

                txtCIN.Text = string.Empty;
                dtpDOB.Value = CMatchCommonUtils.Instance.ServerDate;
                dtpDOB.Checked = false;

                cboGrossAnnualIncomeRange.SelectedValue = string.Empty;
                dtpGrossAnnualIncomeasonDate.Value = CMatchCommonUtils.Instance.ServerDate;
                dtpGrossAnnualIncomeasonDate.Checked = false;

                txtNetWorth.Text = string.Empty;
                dtpNetWorthAsOnDate.Value = CMatchCommonUtils.Instance.ServerDate;
                dtpNetWorthAsOnDate.Checked = false;

                cboPEP.SelectedValue = string.Empty;
                //cboRelationship.SelectedValue = string.Empty;
                cboTypeofFacility.SelectedValue = string.Empty;
                txtPlaceofIncorporation.Text = string.Empty;
                cboOccupation.SelectedValue = string.Empty;
                txtOccupationName.Text = string.Empty;
                dtpBusinessCommencementDate.Value = CMatchCommonUtils.Instance.ServerDate;
                dtpBusinessCommencementDate.Checked = false;

                txtUCCCode.Text = string.Empty;
                chkCorporateClientType.Checked = false;
                chkUpdationFlagNew.Checked = false;

                cboNationality_SelectedIndexChanged(this, EventArgs.Empty);
                cboOccupation_SelectedIndexChanged(this, EventArgs.Empty);
                chkCINExempt_CheckedChanged(this, EventArgs.Empty);
				cboClientType.SelectedValue = string.Empty;
				cboClientStatus.SelectedValue = string.Empty;

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                MessageBox.Show(ex.Message, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }
        #endregion

        /// <summary>
        /// Populates controls with current selected record
        /// </summary>
        #region PopulateFieldsNew
        private void PopulateFieldsNew()
        {
            ClearControls();

            try
            {
                txtClientCode.Text = m_objCurrentClient.ClientCode;
                txtClientName.Text = m_objCurrentClient.ClientName;

                if (m_objCurrentClient.CreationDate.HasValue == false)
                {
                    dtpCreationDate.Value = CMatchCommonUtils.Instance.ServerDate;
                    dtpCreationDate.Checked = false;
                }
                else
                {
                    dtpCreationDate.Value = m_objCurrentClient.CreationDate.Value;
                    dtpCreationDate.Checked = true;
                }

                txtClientPANNo.Text = m_objCurrentClient.PANNo;
                if(m_objCurrentClient.Gender != null)
                    cboGender.SelectedValue = m_objCurrentClient.Gender;
                txtGuardianName.Text = m_objCurrentClient.GuardianName;
                if(m_objCurrentClient.MaritalStatus != null)
                    cboMaritalStatus.SelectedValue = m_objCurrentClient.MaritalStatus;
                if(m_objCurrentClient.Nationality != null)
                    cboNationality.SelectedValue = m_objCurrentClient.Nationality;
                txtNationalityName.Text = m_objCurrentClient.NationalityOther;
                chkPanExempt.Checked = (m_objCurrentClient.PanExempt == "Y");
                chkCINExempt.Checked = (m_objCurrentClient.CINExempt == "Y");
                chkUpdationFlagNew.Checked = (m_objCurrentClient.UpdationFlag == "Y");

                if (m_objCurrentClient.UCCType != null)
                    cboClientType.SelectedValue = m_objCurrentClient.UCCType;
                if (m_objCurrentClient.ClientStatus != null)
                    cboClientStatus.SelectedValue = m_objCurrentClient.ClientStatus;

                txtCIN.Text = m_objCurrentClient.CorporateIdNo;
                if (m_objCurrentClient.DOB.HasValue == false)
                {
                    dtpDOB.Value = CMatchCommonUtils.Instance.ServerDate;
                    dtpDOB.Checked = false;
                }
                else
                {
                    dtpDOB.Value = m_objCurrentClient.DOB.Value;
                    dtpDOB.Checked = true;
                }

                if(m_objCurrentClient.GrAnnIncRange != null)
                    cboGrossAnnualIncomeRange.SelectedValue = m_objCurrentClient.GrAnnIncRange;
                if (m_objCurrentClient.GrAnnIncAsOnDate.HasValue == false)
                {
                    dtpGrossAnnualIncomeasonDate.Value = CMatchCommonUtils.Instance.ServerDate;
                    dtpGrossAnnualIncomeasonDate.Checked = false;
                }
                else
                {
                    dtpGrossAnnualIncomeasonDate.Value = m_objCurrentClient.GrAnnIncAsOnDate.Value;
                    dtpGrossAnnualIncomeasonDate.Checked = true;
                }

                txtNetWorth.Text = m_objCurrentClient.NetWorth.ToString();
                if (m_objCurrentClient.NetWorthAsOnDate.HasValue == false)
                {
                    dtpNetWorthAsOnDate.Value = CMatchCommonUtils.Instance.ServerDate;
                    dtpNetWorthAsOnDate.Checked = false;
                }
                else
                {
                    dtpNetWorthAsOnDate.Value = m_objCurrentClient.NetWorthAsOnDate.Value;
                    dtpNetWorthAsOnDate.Checked = true;
                }

                if(m_objCurrentClient.PEP != null)
                    cboPEP.SelectedValue = m_objCurrentClient.PEP;
               
                if(m_objCurrentClient.TypeofFacility != null)
                    cboTypeofFacility.SelectedValue = m_objCurrentClient.TypeofFacility;
                txtPlaceofIncorporation.Text = m_objCurrentClient.PlaceofIncorporation;
                if(m_objCurrentClient.Occupation != null)
                    cboOccupation.SelectedValue = m_objCurrentClient.Occupation;
                txtOccupationName.Text = m_objCurrentClient.OccupationOthers;
                if (m_objCurrentClient.CommOfBusiness.HasValue == false)
                {
                    dtpBusinessCommencementDate.Value = CMatchCommonUtils.Instance.ServerDate;
                    dtpBusinessCommencementDate.Checked = false;
                }
                else
                {
                    dtpBusinessCommencementDate.Value = m_objCurrentClient.CommOfBusiness.Value;
                    dtpBusinessCommencementDate.Checked = true;
                }

                txtUCCCode.Text = m_objCurrentClient.UCCCode;
                chkCorporateClientType.Checked = (m_objCurrentClient.ClientTypeCorporate == "Y");
                chkUpdationFlagNew.Checked = (m_objCurrentClient.UpdationFlag == "Y");

                cboNationality_SelectedIndexChanged(this, EventArgs.Empty);
                cboOccupation_SelectedIndexChanged(this, EventArgs.Empty);
                chkCINExempt_CheckedChanged(this, EventArgs.Empty);

                if (m_objCurrentClient.IsPendingAuth)
                    ApplyMakerCheckerEffects(m_objCurrentClient, m_objCurrentClient.OriginalClient);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                MessageBox.Show(ex.Message, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }
        #endregion

        /// <summary>
        /// Updates current changes to database using BL class
        /// </summary>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region SaveClientData
        private long SaveClientData()
        {
            string l_sErrorMessage = string.Empty;
            Control l_ctrlErrorControl = null;
            if (ValidateClientDetails(ref l_sErrorMessage, ref l_ctrlErrorControl) == false)
            {
                MessageBox.Show(l_sErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                if ((l_ctrlErrorControl != null) && (l_ctrlErrorControl.Enabled))
                    l_ctrlErrorControl.Focus();
                return 1;
            }

            ArrayList l_arryList = new ArrayList();
            l_arryList.Add(m_objCurrentClient.ClientCode);
            l_arryList.Add(txtClientCode.Text);
            l_arryList.Add(txtClientName.Text);
            //l_arryList.Add(cboClientType.SelectedValue);
            l_arryList.Add(txtClientPANNo.Text);
            l_arryList.Add(cboGender.SelectedValue);
            l_arryList.Add(txtGuardianName.Text);
            l_arryList.Add(cboMaritalStatus.SelectedValue);
            l_arryList.Add(cboNationality.SelectedValue);
            l_arryList.Add(txtNationalityName.Text);
            if (chkPanExempt.Checked)
                l_arryList.Add("Y");
            else
                l_arryList.Add("N");
            l_arryList.Add(txtCIN.Text);

            if (dtpDOB.Checked)
                l_arryList.Add(dtpDOB.Value.Date);
            else
                l_arryList.Add(null);

            if (dtpCreationDate.Checked)
                l_arryList.Add(dtpCreationDate.Value.Date);
            else
                l_arryList.Add(null);

            l_arryList.Add(cboGrossAnnualIncomeRange.SelectedValue);
            if (dtpGrossAnnualIncomeasonDate.Checked)
                l_arryList.Add(dtpGrossAnnualIncomeasonDate.Value.Date);
            else
                l_arryList.Add(null);

            decimal l_decNetWorth = 0M;
            if (
                (txtNetWorth.Text.Trim().Length > 0)
                &&
                (decimal.TryParse(txtNetWorth.Text.Trim(), out l_decNetWorth) == false)
                )
            {
                MessageBox.Show("Invalid Networth value", m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                if(txtNetWorth.Enabled)
                    txtNetWorth.Focus();
                return 1;
            }

            if(txtNetWorth.Text.Trim().Length == 0)
                l_arryList.Add(null);
            else
                l_arryList.Add(l_decNetWorth);

            if (dtpNetWorthAsOnDate.Checked)
                l_arryList.Add(dtpNetWorthAsOnDate.Value.Date);
            else
                l_arryList.Add(null);

            l_arryList.Add(cboPEP.SelectedValue);
            l_arryList.Add(txtPlaceofIncorporation.Text);
            l_arryList.Add(cboOccupation.SelectedValue);
            l_arryList.Add(txtOccupationName.Text);
            if (dtpBusinessCommencementDate.Checked)
                l_arryList.Add(dtpBusinessCommencementDate.Value.Date);
            else
                l_arryList.Add(null);

            l_arryList.Add(txtUCCCode.Text);

            if (chkCINExempt.Checked)
                l_arryList.Add("Y");
            else
                l_arryList.Add("N");
            if (chkUpdationFlagNew.Checked)
                l_arryList.Add("Y");
            else
                l_arryList.Add("N");
            //l_arryList.Add(cboRelationship.SelectedValue);
            l_arryList.Add(cboTypeofFacility.SelectedValue);
            if (chkCorporateClientType.Checked)
                l_arryList.Add("Y");
            else
                l_arryList.Add("N");

            l_arryList.Add(cboClientType.SelectedValue);
            l_arryList.Add(cboClientStatus.SelectedValue);

            MethodExecResult l_objMethodExceResult = m_objCClientMaster.UpdateUCCCLientData(l_arryList);

            if (l_objMethodExceResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, l_objMethodExceResult);
                MessageBox.Show(l_objMethodExceResult.ErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            else
            {
                MessageBox.Show("Records Updated Successfully", m_sMsgBoxTitle, MessageBoxButtons.OK);
                m_objCurrentClient.IsPendingAuth = true;
                if (m_objCurrentClient.IsPendingAuth)
                    ApplyMakerCheckerEffects(m_objCurrentClient, m_objCurrentClient.OriginalClient);
            }
            return 0;
        }
        #endregion

        /// <summary>
        /// Updates current changes to database using BL class
        /// </summary>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region SaveClientDataNew
        private long SaveClientDataNew()
        {
            string l_sErrorMessage = string.Empty;
            Control l_ctrlErrorControl = null;
            if (ValidateClientDetails(ref l_sErrorMessage, ref l_ctrlErrorControl) == false)
            {
                MessageBox.Show(l_sErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                if ((l_ctrlErrorControl != null) && (l_ctrlErrorControl.Enabled))
                    l_ctrlErrorControl.Focus();
                return 1;
            }

            m_objCurrentClient.PANNo = txtClientPANNo.Text;
            if (cboGender.SelectedValue != null)
                m_objCurrentClient.Gender = cboGender.SelectedValue.ToString();
            else
                m_objCurrentClient.Gender = string.Empty;

            m_objCurrentClient.GuardianName = txtGuardianName.Text;
            if(cboMaritalStatus.SelectedValue != null)
                m_objCurrentClient.MaritalStatus = cboMaritalStatus.SelectedValue.ToString();
            else
                m_objCurrentClient.MaritalStatus = string.Empty;
            if(cboNationality.SelectedValue != null)
                m_objCurrentClient.Nationality = Convert.ToByte(cboNationality.SelectedValue);
            else
                m_objCurrentClient.Nationality = null;
            
            m_objCurrentClient.NationalityOther = txtNationalityName.Text;
            
            if(chkPanExempt.Checked)
                m_objCurrentClient.PanExempt = "Y";
            else
                m_objCurrentClient.PanExempt = "N";
            
            m_objCurrentClient.CorporateIdNo = txtCIN.Text;

            if (dtpDOB.Checked)
                m_objCurrentClient.DOB = dtpDOB.Value;
            else
                m_objCurrentClient.DOB = null;

            if (dtpCreationDate.Checked)
                m_objCurrentClient.CreationDate = dtpCreationDate.Value;
            else
                m_objCurrentClient.CreationDate = null;

            if(cboGrossAnnualIncomeRange.SelectedValue != null)
                m_objCurrentClient.GrAnnIncRange = Convert.ToInt32(cboGrossAnnualIncomeRange.SelectedValue);
            else
                m_objCurrentClient.GrAnnIncRange = null;

            if (dtpGrossAnnualIncomeasonDate.Checked)
                m_objCurrentClient.GrAnnIncAsOnDate = dtpGrossAnnualIncomeasonDate.Value;
            else
                m_objCurrentClient.GrAnnIncAsOnDate = null;

            decimal l_decNetWorth = 0M;
            if (
                (txtNetWorth.Text.Trim().Length > 0)
                &&
                (decimal.TryParse(txtNetWorth.Text.Trim(), out l_decNetWorth) == false)
                )
            {
                MessageBox.Show("Invalid Networth value", m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                if (txtNetWorth.Enabled)
                    txtNetWorth.Focus();
                return 1;
            }

            if(txtNetWorth.Text.Trim().Length > 0)
                m_objCurrentClient.NetWorth = l_decNetWorth;
            else
                m_objCurrentClient.NetWorth = null;

            if (dtpNetWorthAsOnDate.Checked)
                m_objCurrentClient.NetWorthAsOnDate = dtpNetWorthAsOnDate.Value;
            else
                m_objCurrentClient.NetWorthAsOnDate = null;

            if(cboPEP.SelectedValue != null)
                m_objCurrentClient.PEP = Convert.ToByte(cboPEP.SelectedValue);
            else
                m_objCurrentClient.PEP = null;
            
            m_objCurrentClient.PlaceofIncorporation = txtPlaceofIncorporation.Text;

            if(cboOccupation.SelectedValue != null)
                m_objCurrentClient.Occupation = Convert.ToInt32(cboOccupation.SelectedValue);
            else
                m_objCurrentClient.Occupation = null;

            m_objCurrentClient.OccupationOthers = txtOccupationName.Text;
            
            if (dtpBusinessCommencementDate.Checked)
                m_objCurrentClient.CommOfBusiness = dtpBusinessCommencementDate.Value;
            else
                m_objCurrentClient.CommOfBusiness = null;

            m_objCurrentClient.UCCCode = txtUCCCode.Text;

            if (chkCINExempt.Checked)
                m_objCurrentClient.CINExempt = "Y";
            else
                m_objCurrentClient.CINExempt = "N";

            if (chkUpdationFlagNew.Checked)
                m_objCurrentClient.UpdationFlag = "Y";
            else
                m_objCurrentClient.UpdationFlag = "N";

            if(cboTypeofFacility.SelectedValue != null)
                m_objCurrentClient.TypeofFacility = cboTypeofFacility.SelectedValue.ToString();
            else
                m_objCurrentClient.TypeofFacility = string.Empty;

            if (chkCorporateClientType.Checked)
                m_objCurrentClient.ClientTypeCorporate = "Y";
            else
                m_objCurrentClient.ClientTypeCorporate = "N";

            if (cboClientType.SelectedValue != null)
                m_objCurrentClient.UCCType = Convert.ToInt32(cboClientType.SelectedValue);
            else
                m_objCurrentClient.UCCType = null;

            if (cboClientStatus.SelectedValue != null)
                m_objCurrentClient.ClientStatus = Convert.ToInt32(cboClientStatus.SelectedValue);
            else
                m_objCurrentClient.ClientStatus = null;


            MethodExecResult l_objMethodExceResult = m_objCurrentClient.Update();

            if (l_objMethodExceResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, l_objMethodExceResult);
                MessageBox.Show(l_objMethodExceResult.ErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            else
            {
                if(CSystemParam.Instance[CSystemParam.SysParam.MakerCheckerClient].SysParamValue == "Y")
                    MessageBox.Show("Records Updated Successfully for Authorisation", m_sMsgBoxTitle, MessageBoxButtons.OK);
                else
                    MessageBox.Show("Records Updated Successfully", m_sMsgBoxTitle, MessageBoxButtons.OK);
                m_objCurrentClient.IsPendingAuth = true;
                RefreshClientData();
            }
            if (m_objCurrentClient.IsPendingAuth)
                btnMakerCancel.Visible = true;
            else
                btnMakerCancel.Visible = false;
            return 0;
        }
        #endregion

        /// <summary>
        /// Enables/disables all controls
        /// </summary>
        /// <param name="p_vsFlag">Enable/disable flag</param>
        #region EnableDisableClientDetailsField
        private void EnableDisableClientDetailsField(bool p_vsFlag)
        {
            txtClientCode.Enabled = p_vsFlag;
            txtClientName.Enabled = p_vsFlag;
        }
        #endregion        

        /// <summary>
        /// Validates current record.
        /// </summary>
        /// <param name="ErrorMessage">Error message if validation fails</param>
        /// <param name="ErrorControl">Error control where validation failed</param>
        /// <returns>True if all validations passed, False otherwise</returns>
        #region ValidateClientDetails
        private bool ValidateClientDetails(ref string ErrorMessage, ref Control ErrorControl)
        {
            //Mandatory
            //if (dtpDOB.Enabled && dtpDOB.Checked == false)
            //{
            //    ErrorControl = dtpDOB;
            //    ErrorMessage = "DOB/DOI must be provided";
            //    return false;
            //}

            if (
                dtpDOB.Enabled
                && dtpDOB.Checked
                && (dtpDOB.Value.Date > CMatchCommonUtils.Instance.ServerDate.Date)
              )
            {
                ErrorControl = dtpDOB;
                ErrorMessage = "DOB/DOI cannot be future date";
                return false;
            }

            if (txtClientPANNo.Enabled && (txtClientPANNo.ReadOnly == false) && (txtClientPANNo.Text.Trim().Length == 0))
            {
                ErrorControl = txtClientPANNo;
                ErrorMessage = "PAN No must be provided";
                return false;
            }

            if (txtGuardianName.Enabled && txtGuardianName.Text.Trim().Length > 0)
            {
                ErrorControl = txtGuardianName;
                ErrorMessage = "Guardian name must contain at least one alpha";
                return false;
            }

            if(
                (txtNationalityName.Enabled)
                &&
                (cboNationality.SelectedValue != null)
                &&
                (cboNationality.SelectedValue.ToString() == CUCCConstants.Instance.OTHER_NATIONALITY_CODE) //Other
                && (txtNationalityName.Text.Trim().Length == 0)
               )
            {
                ErrorControl = txtNationalityName;
                ErrorMessage = "Nationality Name must be provided if Nationality is Others";
                return false;
            }
            
            if (txtCIN.Enabled
                && (txtCIN.Text.Trim().Length > 0)
               )
            {
                if (txtCIN.Text.Trim().Length != 21)
                {
                    ErrorControl = txtCIN;
                    ErrorMessage = "CIN No must be of 21 characters";
                    return false;
                }
                else
                {
                    Regex regEx = new Regex(@"[0]*");
                    if (regEx.Match(txtCIN.Text.Trim()).Length == txtCIN.Text.Trim().Length)
                    {
                        ErrorControl = txtCIN;
                        ErrorMessage = "CIN No cannot be all zeros";
                        return false;
                    }
                }
            }
                       
            if (
                (dtpGrossAnnualIncomeasonDate.Enabled)
                && (cboGrossAnnualIncomeRange.SelectedItem != null)
                && (dtpGrossAnnualIncomeasonDate.Checked == false)
               )
            {
                ErrorControl = dtpGrossAnnualIncomeasonDate;
                ErrorMessage = "Gross annual income date must be specified if Gross annual income is selected";
                return false;
            }
                        
            DateTime l_dt18MonthsBack = CMatchCommonUtils.Instance.ServerDate.AddMonths(-18).Date;
            if (
                dtpGrossAnnualIncomeasonDate.Enabled
                && dtpGrossAnnualIncomeasonDate.Checked
                && (dtpGrossAnnualIncomeasonDate.Value.Date.Subtract(l_dt18MonthsBack).TotalDays <= 0)
              )
            {
                ErrorControl = dtpGrossAnnualIncomeasonDate;
                ErrorMessage = "Gross annual income date must not be older than 18 months";
                return false;
            }

            //if (
            //    (txtNetWorth.Enabled)
            //    &&
            //    (cboGrossAnnualIncomeRange.SelectedItem == null)
            //    && (txtNetWorth.Text.Trim().Length == 0)
            //   )
            //{
            //    ErrorControl = txtNetWorth;
            //    ErrorMessage = "Networth must be specified if Gross annual income is not specified";
            //    return false;
            //}

            decimal l_decNetWorth = 0M;
            if (
                (txtNetWorth.Text.Trim().Length > 0)
                &&
                (decimal.TryParse(txtNetWorth.Text.Trim(), out l_decNetWorth) == false)
                )
            {
                ErrorControl = txtNetWorth;
                ErrorMessage = "Invalid Networth value";
                return false;
            }

            if(txtNetWorth.Enabled
                && (txtNetWorth.Text.Trim().Length > 0)
                && (l_decNetWorth > CUCCConstants.Instance.SQL_MONEY_MAX_SUPPORTED_VALUE)
                )
            {
                ErrorControl = txtNetWorth;
                ErrorMessage = "Networth value exceeding maximum allowed {" + CUCCConstants.Instance.SQL_MONEY_MAX_SUPPORTED_VALUE.ToString() + "}";
                return false;
            }

            if (
                (dtpNetWorthAsOnDate.Enabled)
                &&
                (txtNetWorth.Text.Trim().Length > 0)
                && (dtpNetWorthAsOnDate.Checked == false)
               )
            {
                ErrorControl = dtpNetWorthAsOnDate;
                ErrorMessage = "Networth as on date must be specified if Networth is specified";
                return false;
            }

            DateTime l_dtOneYearBack = CMatchCommonUtils.Instance.ServerDate.AddYears(-1).Date;
            if(
                dtpNetWorthAsOnDate.Enabled
                && dtpNetWorthAsOnDate.Checked
                && (dtpNetWorthAsOnDate.Value.Date.Subtract(l_dtOneYearBack).TotalDays <= 0)
              )
            {
                ErrorControl = dtpNetWorthAsOnDate;
                ErrorMessage = "Networth as on date must not be older than one year";
                return false;
            }

            if (
                (txtOccupationName.Enabled)
                &&
                (cboOccupation.SelectedValue != null)
                &&
                (cboOccupation.SelectedValue.ToString() == CUCCConstants.Instance.OTHER_OCCUPATION_REFNO) //Others
                && (txtOccupationName.Text.Trim().Length == 0)
               )
            {
                ErrorControl = txtOccupationName;
                ErrorMessage = "Occupation Name must be provided if Occupation is Others";
                return false;
            }

            if (
                dtpNetWorthAsOnDate.Enabled
                && dtpNetWorthAsOnDate.Checked
                && (dtpNetWorthAsOnDate.Value.Date > CMatchCommonUtils.Instance.ServerDate.Date)
              )
            {
                ErrorControl = dtpNetWorthAsOnDate;
                ErrorMessage = "Networth as on date cannot be future date";
                return false;
            }

            if (
                dtpGrossAnnualIncomeasonDate.Enabled
                && dtpGrossAnnualIncomeasonDate.Checked
                && (dtpGrossAnnualIncomeasonDate.Value.Date > CMatchCommonUtils.Instance.ServerDate.Date)
              )
            {
                ErrorControl = dtpGrossAnnualIncomeasonDate;
                ErrorMessage = "Gross annual income date cannot be future date";
                return false;
            }

            if (dtpBusinessCommencementDate.Enabled
                && dtpBusinessCommencementDate.Checked
                && (dtpBusinessCommencementDate.Value.Date > CMatchCommonUtils.Instance.ServerDate.Date)
                )
            {
                ErrorControl = dtpBusinessCommencementDate;
                ErrorMessage = "Business Commencement date cannot be future date";
                return false;
            }

            return true;
        }
        #endregion
        
        /// <summary>
        /// This method compares current client object values with target client object 
        /// and sets Maker fields accordingly
        /// </summary>
        /// <param name="m_objCurrent">Client object whose values have been populated to fields</param>
        /// <param name="m_objCompareToClient">Client object containing original values</param>
        #region ApplyMakerCheckerEffects
        private void ApplyMakerCheckerEffects(CClient m_objCurrent, CClient m_objCompareToClient)
        {
           
            if (m_objCurrentClient.IsPendingAuth)
                btnMakerCancel.Visible = true;
            else
                btnMakerCancel.Visible = false;

            if (m_objCompareToClient == null)
                m_objCompareToClient = m_objCurrent;

            CUCCCommon l_objCommon = CUCCCommon.Instance;
            if (m_objCompareToClient == null)
                m_objCompareToClient = m_objCurrent;
            
            if (m_objCurrent.CreationDate == m_objCompareToClient.CreationDate)
                l_objCommon.ResetMakerChangedStyle(dtpCreationDate, lblCreationDate, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(dtpCreationDate, lblCreationDate, ttMain, m_objCompareToClient.CreationDate);

            if (m_objCurrent.CreationDate == m_objCompareToClient.CreationDate)
                l_objCommon.ResetMakerChangedStyle(dtpCreationDate, lblCreationDate, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(dtpCreationDate, lblCreationDate, ttMain, m_objCompareToClient.CreationDate);


            if (m_objCurrent.UCCType == m_objCompareToClient.UCCType)
                l_objCommon.ResetMakerChangedStyle(cboClientType, lblClientType, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(cboClientType, lblClientType, ttMain, CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.MAINCLIENTTYPE, m_objCompareToClient.UCCType.ToString()));

            if (m_objCurrent.ClientStatus == m_objCompareToClient.ClientStatus)
                l_objCommon.ResetMakerChangedStyle(cboClientStatus, lblClientStatus, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(cboClientStatus, lblClientStatus, ttMain, CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.CLIENTSTATUS, m_objCompareToClient.ClientStatus.ToString()));



            if (m_objCurrent.PANNo == m_objCompareToClient.PANNo)
                l_objCommon.ResetMakerChangedStyle(txtClientPANNo, lblClientPANNo, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtClientPANNo, lblClientPANNo, ttMain, m_objCompareToClient.PANNo);

            if (m_objCurrent.Gender == m_objCompareToClient.Gender)
                l_objCommon.ResetMakerChangedStyle(cboGender, lblGender, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(cboGender, lblGender, ttMain, CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.GENDER, m_objCompareToClient.Gender));

            if (m_objCurrent.GuardianName == m_objCompareToClient.GuardianName)
                l_objCommon.ResetMakerChangedStyle(txtGuardianName, lblGuardianName, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtGuardianName, lblGuardianName, ttMain, m_objCompareToClient.GuardianName);

            if (m_objCurrent.MaritalStatus == m_objCompareToClient.MaritalStatus)
                l_objCommon.ResetMakerChangedStyle(cboMaritalStatus, lblMaritalStatus, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(cboMaritalStatus, lblMaritalStatus, ttMain, CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.MARITALST, m_objCompareToClient.MaritalStatus));

            if (m_objCurrent.Nationality == m_objCompareToClient.Nationality)
                l_objCommon.ResetMakerChangedStyle(cboNationality, lblNationality, ttMain);
            else
            {
                if(m_objCompareToClient.Nationality.HasValue)
                    l_objCommon.SetMakerChangedStyle(cboNationality, lblNationality, ttMain, CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.NATIONALTY, m_objCompareToClient.Nationality.Value.ToString()));
                else
                    l_objCommon.SetMakerChangedStyle(cboNationality, lblNationality, ttMain, null);
            }

            if (m_objCurrent.NationalityOther == m_objCompareToClient.NationalityOther)
                l_objCommon.ResetMakerChangedStyle(txtNationalityName, lblNationality, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtNationalityName, lblNationality, ttMain, m_objCompareToClient.NationalityOther);

            if (m_objCurrent.PanExempt == m_objCompareToClient.PanExempt)
                l_objCommon.ResetMakerChangedStyle(chkPanExempt, lblClientPANNo, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(chkPanExempt, lblClientPANNo, ttMain, m_objCompareToClient.PanExempt);

            if (m_objCurrent.CINExempt == m_objCompareToClient.CINExempt)
                l_objCommon.ResetMakerChangedStyle(chkCINExempt, lblCIN, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(chkCINExempt, lblCIN, ttMain, m_objCompareToClient.CINExempt);

            if (m_objCurrent.UpdationFlag == m_objCompareToClient.UpdationFlag)
                l_objCommon.ResetMakerChangedStyle(chkUpdationFlagNew, lblUpdationFlagNew, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(chkUpdationFlagNew, lblUpdationFlagNew, ttMain, m_objCompareToClient.UpdationFlag);

            if (m_objCurrent.CorporateIdNo == m_objCompareToClient.CorporateIdNo)
                l_objCommon.ResetMakerChangedStyle(txtCIN, lblCIN, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtCIN, lblCIN, ttMain, m_objCompareToClient.CorporateIdNo);

            if (m_objCurrent.DOB == m_objCompareToClient.DOB)
                l_objCommon.ResetMakerChangedStyle(dtpDOB, lblDOB, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(dtpDOB, lblDOB, ttMain, m_objCompareToClient.DOB);

            if (m_objCurrent.GrAnnIncRange == m_objCompareToClient.GrAnnIncRange)
                l_objCommon.ResetMakerChangedStyle(cboGrossAnnualIncomeRange, lblGrossAnnualIncomeRange, ttMain);
            else
            {
                if(m_objCompareToClient.GrAnnIncRange.HasValue)
                    l_objCommon.SetMakerChangedStyle(cboGrossAnnualIncomeRange, lblGrossAnnualIncomeRange, ttMain, CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.ANNINC, m_objCompareToClient.GrAnnIncRange.Value.ToString()));
                else
                    l_objCommon.SetMakerChangedStyle(cboGrossAnnualIncomeRange, lblGrossAnnualIncomeRange, ttMain, null);
            }

            if (m_objCurrent.GrAnnIncAsOnDate == m_objCompareToClient.GrAnnIncAsOnDate)
                l_objCommon.ResetMakerChangedStyle(dtpGrossAnnualIncomeasonDate, lblGrossAnnualIncomeasonDate, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(dtpGrossAnnualIncomeasonDate, lblGrossAnnualIncomeasonDate, ttMain, m_objCompareToClient.GrAnnIncAsOnDate);

            if (m_objCurrent.NetWorth == m_objCompareToClient.NetWorth)
                l_objCommon.ResetMakerChangedStyle(txtNetWorth, lblNetWorth, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtNetWorth, lblNetWorth, ttMain, m_objCompareToClient.NetWorth);

            if (m_objCurrent.NetWorthAsOnDate == m_objCompareToClient.NetWorthAsOnDate)
                l_objCommon.ResetMakerChangedStyle(dtpNetWorthAsOnDate, lblNetWorthAsOnDate, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(dtpNetWorthAsOnDate, lblNetWorthAsOnDate, ttMain, m_objCompareToClient.NetWorthAsOnDate);

            if (m_objCurrent.PEP == m_objCompareToClient.PEP)
                l_objCommon.ResetMakerChangedStyle(cboPEP, lblPEP, ttMain);
            else
            {
                if(m_objCompareToClient.PEP.HasValue)
                    l_objCommon.SetMakerChangedStyle(cboPEP, lblPEP, ttMain, CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.PEP, m_objCompareToClient.PEP.Value.ToString()));
                else
                    l_objCommon.SetMakerChangedStyle(cboPEP, lblPEP, ttMain, null);
            }

           
            if (m_objCurrent.TypeofFacility == m_objCompareToClient.TypeofFacility)
                l_objCommon.ResetMakerChangedStyle(cboTypeofFacility, lblTypeofFacility, ttMain);
            else
            {
                l_objCommon.SetMakerChangedStyle(cboTypeofFacility, lblTypeofFacility, ttMain, CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.FACILITY, m_objCompareToClient.TypeofFacility));
            }

            if (m_objCurrent.PlaceofIncorporation == m_objCompareToClient.PlaceofIncorporation)
                l_objCommon.ResetMakerChangedStyle(txtPlaceofIncorporation, lblPlaceofIncorporation, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtPlaceofIncorporation, lblPlaceofIncorporation, ttMain, m_objCompareToClient.PlaceofIncorporation);

            if (m_objCurrent.Occupation == m_objCompareToClient.Occupation)
                l_objCommon.ResetMakerChangedStyle(cboOccupation, lblOccupation, ttMain);
            else
            {
                if(m_objCompareToClient.Occupation.HasValue)
                    l_objCommon.SetMakerChangedStyle(cboOccupation, lblOccupation, ttMain, CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.OCCUPATION, m_objCompareToClient.Occupation.Value.ToString()));
                else
                    l_objCommon.SetMakerChangedStyle(cboOccupation, lblOccupation, ttMain, null);
            }

            if (m_objCurrent.OccupationOthers == m_objCompareToClient.OccupationOthers)
                l_objCommon.ResetMakerChangedStyle(txtOccupationName, lblOccupation, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtOccupationName, lblOccupation, ttMain, m_objCompareToClient.OccupationOthers);

            if (m_objCurrent.CommOfBusiness == m_objCompareToClient.CommOfBusiness)
                l_objCommon.ResetMakerChangedStyle(dtpBusinessCommencementDate, lblBusinessCommencementDate, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(dtpBusinessCommencementDate, lblBusinessCommencementDate, ttMain, m_objCompareToClient.CommOfBusiness);

            if (m_objCurrent.UCCCode == m_objCompareToClient.UCCCode)
                l_objCommon.ResetMakerChangedStyle(txtUCCCode, lblUCCCode, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtUCCCode, lblUCCCode, ttMain, m_objCompareToClient.UCCCode);

            if (m_objCurrent.ClientTypeCorporate == m_objCompareToClient.ClientTypeCorporate)
                l_objCommon.ResetMakerChangedStyle(chkCorporateClientType, lblCorporateClientType, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(chkCorporateClientType, lblCorporateClientType, ttMain, m_objCompareToClient.ClientTypeCorporate);

        }
        #endregion


        /// <summary>
        /// Cancel the maker changes for the selected record
        /// </summary>
        #region CancelMakerChanges
        private void CancelMakerChanges()
        {
            MakerCancel lbjMkrCancel = new MakerCancel();
            ArrayList l_lstParamValue = new ArrayList();
            MethodExecResult l_objMethodExceResult;

            l_lstParamValue.Add(m_objCurrentClient.ClientNo);
            l_lstParamValue.Add(1);

            l_objMethodExceResult = lbjMkrCancel.CancelMakerEffect(l_lstParamValue);

            if (l_objMethodExceResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, l_objMethodExceResult);
                MessageBox.Show("Unable to cancel the maker changes" + Environment.NewLine + l_objMethodExceResult.ErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("Maker changes cancel successfully", m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.ParentForm.Close();
                //RefreshClientData();
                //m_objCurrentClient.IsPendingAuth = false;
            }
            //if (m_objCurrentClient.IsPendingAuth)
            //    btnMakerCancel.Visible = true;
            //else
            //    btnMakerCancel.Visible = false;
        }
        #endregion 

        #endregion

        #region IEventInfo Members

        #region Not applicable

        void IEventInfo.Filter() { }
        void IEventInfo.RefreshData(){}
        void IEventInfo.AddRecord(){}
        void IEventInfo.ModifyRecord(){}
        void IEventInfo.DeleteRecord(){}

        #endregion

        /// <summary>
        /// Redirects to Save_Click
        /// </summary>
        #region SaveData
        void IEventInfo.SaveData()
        {
            Save_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Redirects to Exit_Click
        /// </summary>
        #region Exit
        void IEventInfo.Exit()
        {
            Exit_Click(this, EventArgs.Empty);
        }
        #endregion

       

        #endregion

       
    }
}
