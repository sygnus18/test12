﻿namespace UCC.Forms.UCCClient
{
    partial class UCCClientAddressInfo
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCCClientAddressInfo));
            this.ftAddressGridPanel = new MatchCommon.CustomControls.FTPanel();
            this.dgvAddress = new MatchCommon.CustomControls.FTDataGrid();
            this.pnlAddressDetails = new MatchCommon.CustomControls.FTPanel();
            this.gbEmail = new MatchCommon.CustomControls.FTGroupBox();
            this.lblEmailID = new MatchCommon.CustomControls.FTLabel();
            this.txtEmailId = new MatchCommon.CustomControls.FTTextBox();
            this.lblCCMail = new MatchCommon.CustomControls.FTLabel();
            this.txtCCEmailId = new MatchCommon.CustomControls.FTTextBox();
            this.lblBCCMail = new MatchCommon.CustomControls.FTLabel();
            this.txtBCCEmailId = new MatchCommon.CustomControls.FTTextBox();
            this.gbPhone = new MatchCommon.CustomControls.FTGroupBox();
            this.lblResTelNo = new MatchCommon.CustomControls.FTLabel();
            this.lblMobile = new MatchCommon.CustomControls.FTLabel();
            this.txtTelNoRes = new MatchCommon.CustomControls.FTTextBox();
            this.txtMobileNo1 = new MatchCommon.CustomControls.FTTextBox();
            this.txtMobileNo2 = new MatchCommon.CustomControls.FTTextBox();
            this.txtTelNoOfficeSTDCode = new MatchCommon.CustomControls.FTTextBox();
            this.lblFaxNo = new MatchCommon.CustomControls.FTLabel();
            this.txtTelNoOfficeISDCode = new MatchCommon.CustomControls.FTTextBox();
            this.txtFaxNo = new MatchCommon.CustomControls.FTTextBox();
            this.txtTelNoOffice = new MatchCommon.CustomControls.FTTextBox();
            this.txtTelNoResISDCode = new MatchCommon.CustomControls.FTTextBox();
            this.lblOffTelNo = new MatchCommon.CustomControls.FTLabel();
            this.txtTelNoResSTDCode = new MatchCommon.CustomControls.FTTextBox();
            this.txtFAXNoSTDCode = new MatchCommon.CustomControls.FTTextBox();
            this.txtFAXNoISDCode = new MatchCommon.CustomControls.FTTextBox();
            this.gbAddress = new MatchCommon.CustomControls.FTGroupBox();
            this.lblAddressLine1 = new MatchCommon.CustomControls.FTLabel();
            this.txtAddress1 = new MatchCommon.CustomControls.FTTextBox();
            this.txtAddress3 = new MatchCommon.CustomControls.FTTextBox();
            this.txtAddress2 = new MatchCommon.CustomControls.FTTextBox();
            this.txtAddress4 = new MatchCommon.CustomControls.FTTextBox();
            this.cboState = new MatchCommon.CustomControls.FTComboBox();
            this.lblState = new MatchCommon.CustomControls.FTLabel();
            this.txtStateName = new MatchCommon.CustomControls.FTTextBox();
            this.cboCity = new MatchCommon.CustomControls.FTComboBox();
            this.lblCity = new MatchCommon.CustomControls.FTLabel();
            this.lblPinCode = new MatchCommon.CustomControls.FTLabel();
            this.lblCountry = new MatchCommon.CustomControls.FTLabel();
            this.txtPinCode = new MatchCommon.CustomControls.FTTextBox();
            this.cboCountry = new MatchCommon.CustomControls.FTComboBox();
            this.pnlActionControls = new MatchCommon.CustomControls.FTPanel();
            this.btnMakerCancel = new MatchCommon.CustomControls.FTButton();
            this.btnSave = new MatchCommon.CustomControls.FTButton();
            this.btnDelete = new MatchCommon.CustomControls.FTButton();
            this.btnAdd = new MatchCommon.CustomControls.FTButton();
            this.chkContactPersionDefault = new System.Windows.Forms.CheckBox();
            this.lblContactPersonDefault = new MatchCommon.CustomControls.FTLabel();
            this.chkDefault = new System.Windows.Forms.CheckBox();
            this.lblDefault = new MatchCommon.CustomControls.FTLabel();
            this.chkSameCorresPermAdd = new System.Windows.Forms.CheckBox();
            this.lblPermenentAddSameAsCorrs = new MatchCommon.CustomControls.FTLabel();
            this.txtUID = new MatchCommon.CustomControls.FTTextBox();
            this.lblUID = new MatchCommon.CustomControls.FTLabel();
            this.txtDIN = new MatchCommon.CustomControls.FTTextBox();
            this.txtPANNo = new MatchCommon.CustomControls.FTTextBox();
            this.chkIsDirector = new System.Windows.Forms.CheckBox();
            this.txtDesignation = new MatchCommon.CustomControls.FTTextBox();
            this.lblPANNo = new MatchCommon.CustomControls.FTLabel();
            this.lblCategory = new MatchCommon.CustomControls.FTLabel();
            this.lblDirector = new MatchCommon.CustomControls.FTLabel();
            this.lblDesignation = new MatchCommon.CustomControls.FTLabel();
            this.cboCategory = new MatchCommon.CustomControls.FTComboBox();
            this.lblContactPerson = new MatchCommon.CustomControls.FTLabel();
            this.txtContactPerson = new MatchCommon.CustomControls.FTTextBox();
            this.ttMain = new System.Windows.Forms.ToolTip(this.components);
            this.ftAddressGridPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAddress)).BeginInit();
            this.pnlAddressDetails.SuspendLayout();
            this.gbEmail.SuspendLayout();
            this.gbPhone.SuspendLayout();
            this.gbAddress.SuspendLayout();
            this.pnlActionControls.SuspendLayout();
            this.SuspendLayout();
            // 
            // ftAddressGridPanel
            // 
            this.ftAddressGridPanel.Controls.Add(this.dgvAddress);
            this.ftAddressGridPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ftAddressGridPanel.Location = new System.Drawing.Point(0, 0);
            this.ftAddressGridPanel.Name = "ftAddressGridPanel";
            this.ftAddressGridPanel.Size = new System.Drawing.Size(856, 97);
            this.ftAddressGridPanel.TabIndex = 6;
            // 
            // dgvAddress
            // 
            this.dgvAddress.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
            this.dgvAddress.AllowEditing = false;
            this.dgvAddress.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
            this.dgvAddress.BackColor = System.Drawing.Color.Transparent;
            this.dgvAddress.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.dgvAddress.ColumnInfo = "10,1,0,0,0,85,Columns:0{Width:30;}\t";
            this.dgvAddress.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAddress.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
            this.dgvAddress.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvAddress.ForeColor = System.Drawing.Color.Black;
            this.dgvAddress.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
            this.dgvAddress.Location = new System.Drawing.Point(0, 0);
            this.dgvAddress.Name = "dgvAddress";
            this.dgvAddress.OverrideDefault = false;
            this.dgvAddress.Rows.Count = 1;
            this.dgvAddress.Rows.DefaultSize = 17;
            this.dgvAddress.Rows.MinSize = 25;
            this.dgvAddress.RowsFilter.AddFilterRow = false;
            this.dgvAddress.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.ListBox;
            this.dgvAddress.Size = new System.Drawing.Size(856, 97);
            this.dgvAddress.StyleInfo = resources.GetString("dgvAddress.StyleInfo");
            this.dgvAddress.TabIndex = 3;
            this.dgvAddress.RowColChange += new System.EventHandler(this.dgvAddress_RowColChange);
            // 
            // pnlAddressDetails
            // 
            this.pnlAddressDetails.Controls.Add(this.gbEmail);
            this.pnlAddressDetails.Controls.Add(this.gbPhone);
            this.pnlAddressDetails.Controls.Add(this.gbAddress);
            this.pnlAddressDetails.Controls.Add(this.pnlActionControls);
            this.pnlAddressDetails.Controls.Add(this.chkContactPersionDefault);
            this.pnlAddressDetails.Controls.Add(this.lblContactPersonDefault);
            this.pnlAddressDetails.Controls.Add(this.chkDefault);
            this.pnlAddressDetails.Controls.Add(this.lblDefault);
            this.pnlAddressDetails.Controls.Add(this.chkSameCorresPermAdd);
            this.pnlAddressDetails.Controls.Add(this.lblPermenentAddSameAsCorrs);
            this.pnlAddressDetails.Controls.Add(this.txtUID);
            this.pnlAddressDetails.Controls.Add(this.lblUID);
            this.pnlAddressDetails.Controls.Add(this.txtDIN);
            this.pnlAddressDetails.Controls.Add(this.txtPANNo);
            this.pnlAddressDetails.Controls.Add(this.chkIsDirector);
            this.pnlAddressDetails.Controls.Add(this.txtDesignation);
            this.pnlAddressDetails.Controls.Add(this.lblPANNo);
            this.pnlAddressDetails.Controls.Add(this.lblCategory);
            this.pnlAddressDetails.Controls.Add(this.lblDirector);
            this.pnlAddressDetails.Controls.Add(this.lblDesignation);
            this.pnlAddressDetails.Controls.Add(this.cboCategory);
            this.pnlAddressDetails.Controls.Add(this.lblContactPerson);
            this.pnlAddressDetails.Controls.Add(this.txtContactPerson);
            this.pnlAddressDetails.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlAddressDetails.Location = new System.Drawing.Point(0, 97);
            this.pnlAddressDetails.Name = "pnlAddressDetails";
            this.pnlAddressDetails.Size = new System.Drawing.Size(856, 349);
            this.pnlAddressDetails.TabIndex = 2;
            // 
            // gbEmail
            // 
            this.gbEmail.Controls.Add(this.lblEmailID);
            this.gbEmail.Controls.Add(this.txtEmailId);
            this.gbEmail.Controls.Add(this.lblCCMail);
            this.gbEmail.Controls.Add(this.txtCCEmailId);
            this.gbEmail.Controls.Add(this.lblBCCMail);
            this.gbEmail.Controls.Add(this.txtBCCEmailId);
            this.gbEmail.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.gbEmail.ForeColor = System.Drawing.Color.Black;
            this.gbEmail.Location = new System.Drawing.Point(483, 208);
            this.gbEmail.Name = "gbEmail";
            this.gbEmail.Size = new System.Drawing.Size(374, 97);
            this.gbEmail.TabIndex = 15;
            this.gbEmail.TabStop = false;
            // 
            // lblEmailID
            // 
            this.lblEmailID.AllowForeColorChange = false;
            this.lblEmailID.AutoSize = true;
            this.lblEmailID.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblEmailID.ForeColor = System.Drawing.Color.Black;
            this.lblEmailID.Location = new System.Drawing.Point(11, 16);
            this.lblEmailID.Name = "lblEmailID";
            this.lblEmailID.OverrideDefault = false;
            this.lblEmailID.Size = new System.Drawing.Size(46, 12);
            this.lblEmailID.TabIndex = 0;
            this.lblEmailID.Text = "E-mail ID";
            // 
            // txtEmailId
            // 
            this.txtEmailId.AllowAlpha = true;
            this.txtEmailId.AllowDot = true;
            this.txtEmailId.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtEmailId.AllowedCustomCharacters")));
            this.txtEmailId.AllowNonASCII = false;
            this.txtEmailId.AllowNumeric = true;
            this.txtEmailId.AllowSpace = false;
            this.txtEmailId.AllowSpecialChars = true;
            this.txtEmailId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEmailId.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtEmailId.ForeColor = System.Drawing.Color.Black;
            this.txtEmailId.IsEmailID = true;
            this.txtEmailId.IsEmailIdValid = false;
            this.txtEmailId.Location = new System.Drawing.Point(79, 12);
            this.txtEmailId.MaxLength = 60;
            this.txtEmailId.Name = "txtEmailId";
            this.txtEmailId.Size = new System.Drawing.Size(287, 20);
            this.txtEmailId.TabIndex = 1;
            // 
            // lblCCMail
            // 
            this.lblCCMail.AllowForeColorChange = false;
            this.lblCCMail.AutoSize = true;
            this.lblCCMail.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblCCMail.ForeColor = System.Drawing.Color.Black;
            this.lblCCMail.Location = new System.Drawing.Point(11, 43);
            this.lblCCMail.Name = "lblCCMail";
            this.lblCCMail.OverrideDefault = false;
            this.lblCCMail.Size = new System.Drawing.Size(19, 12);
            this.lblCCMail.TabIndex = 2;
            this.lblCCMail.Text = "CC";
            // 
            // txtCCEmailId
            // 
            this.txtCCEmailId.AllowAlpha = true;
            this.txtCCEmailId.AllowDot = true;
            this.txtCCEmailId.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtCCEmailId.AllowedCustomCharacters")));
            this.txtCCEmailId.AllowNonASCII = false;
            this.txtCCEmailId.AllowNumeric = true;
            this.txtCCEmailId.AllowSpace = false;
            this.txtCCEmailId.AllowSpecialChars = true;
            this.txtCCEmailId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCCEmailId.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtCCEmailId.ForeColor = System.Drawing.Color.Black;
            this.txtCCEmailId.IsEmailID = true;
            this.txtCCEmailId.IsEmailIdValid = false;
            this.txtCCEmailId.Location = new System.Drawing.Point(79, 39);
            this.txtCCEmailId.MaxLength = 60;
            this.txtCCEmailId.Name = "txtCCEmailId";
            this.txtCCEmailId.Size = new System.Drawing.Size(287, 20);
            this.txtCCEmailId.TabIndex = 3;
            // 
            // lblBCCMail
            // 
            this.lblBCCMail.AllowForeColorChange = false;
            this.lblBCCMail.AutoSize = true;
            this.lblBCCMail.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblBCCMail.ForeColor = System.Drawing.Color.Black;
            this.lblBCCMail.Location = new System.Drawing.Point(11, 70);
            this.lblBCCMail.Name = "lblBCCMail";
            this.lblBCCMail.OverrideDefault = false;
            this.lblBCCMail.Size = new System.Drawing.Size(25, 12);
            this.lblBCCMail.TabIndex = 4;
            this.lblBCCMail.Text = "BCC";
            // 
            // txtBCCEmailId
            // 
            this.txtBCCEmailId.AllowAlpha = true;
            this.txtBCCEmailId.AllowDot = true;
            this.txtBCCEmailId.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtBCCEmailId.AllowedCustomCharacters")));
            this.txtBCCEmailId.AllowNonASCII = false;
            this.txtBCCEmailId.AllowNumeric = true;
            this.txtBCCEmailId.AllowSpace = true;
            this.txtBCCEmailId.AllowSpecialChars = true;
            this.txtBCCEmailId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBCCEmailId.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtBCCEmailId.ForeColor = System.Drawing.Color.Black;
            this.txtBCCEmailId.IsEmailID = true;
            this.txtBCCEmailId.IsEmailIdValid = false;
            this.txtBCCEmailId.Location = new System.Drawing.Point(79, 66);
            this.txtBCCEmailId.MaxLength = 60;
            this.txtBCCEmailId.Name = "txtBCCEmailId";
            this.txtBCCEmailId.Size = new System.Drawing.Size(287, 20);
            this.txtBCCEmailId.TabIndex = 5;
            // 
            // gbPhone
            // 
            this.gbPhone.Controls.Add(this.lblResTelNo);
            this.gbPhone.Controls.Add(this.lblMobile);
            this.gbPhone.Controls.Add(this.txtTelNoRes);
            this.gbPhone.Controls.Add(this.txtMobileNo1);
            this.gbPhone.Controls.Add(this.txtMobileNo2);
            this.gbPhone.Controls.Add(this.txtTelNoOfficeSTDCode);
            this.gbPhone.Controls.Add(this.lblFaxNo);
            this.gbPhone.Controls.Add(this.txtTelNoOfficeISDCode);
            this.gbPhone.Controls.Add(this.txtFaxNo);
            this.gbPhone.Controls.Add(this.txtTelNoOffice);
            this.gbPhone.Controls.Add(this.txtTelNoResISDCode);
            this.gbPhone.Controls.Add(this.lblOffTelNo);
            this.gbPhone.Controls.Add(this.txtTelNoResSTDCode);
            this.gbPhone.Controls.Add(this.txtFAXNoSTDCode);
            this.gbPhone.Controls.Add(this.txtFAXNoISDCode);
            this.gbPhone.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.gbPhone.ForeColor = System.Drawing.Color.Black;
            this.gbPhone.Location = new System.Drawing.Point(483, 91);
            this.gbPhone.Name = "gbPhone";
            this.gbPhone.Size = new System.Drawing.Size(373, 125);
            this.gbPhone.TabIndex = 14;
            this.gbPhone.TabStop = false;
            // 
            // lblResTelNo
            // 
            this.lblResTelNo.AllowForeColorChange = false;
            this.lblResTelNo.AutoSize = true;
            this.lblResTelNo.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblResTelNo.ForeColor = System.Drawing.Color.Black;
            this.lblResTelNo.Location = new System.Drawing.Point(12, 16);
            this.lblResTelNo.Name = "lblResTelNo";
            this.lblResTelNo.OverrideDefault = false;
            this.lblResTelNo.Size = new System.Drawing.Size(54, 12);
            this.lblResTelNo.TabIndex = 0;
            this.lblResTelNo.Text = "Tel. No (R)";
            // 
            // lblMobile
            // 
            this.lblMobile.AllowForeColorChange = false;
            this.lblMobile.AutoSize = true;
            this.lblMobile.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblMobile.ForeColor = System.Drawing.Color.Black;
            this.lblMobile.Location = new System.Drawing.Point(12, 97);
            this.lblMobile.Name = "lblMobile";
            this.lblMobile.OverrideDefault = false;
            this.lblMobile.Size = new System.Drawing.Size(34, 12);
            this.lblMobile.TabIndex = 12;
            this.lblMobile.Text = "Mobile";
            // 
            // txtTelNoRes
            // 
            this.txtTelNoRes.AllowAlpha = true;
            this.txtTelNoRes.AllowDot = false;
            this.txtTelNoRes.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtTelNoRes.AllowedCustomCharacters")));
            this.txtTelNoRes.AllowNonASCII = false;
            this.txtTelNoRes.AllowNumeric = true;
            this.txtTelNoRes.AllowSpace = true;
            this.txtTelNoRes.AllowSpecialChars = true;
            this.txtTelNoRes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTelNoRes.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtTelNoRes.ForeColor = System.Drawing.Color.Black;
            this.txtTelNoRes.IsEmailID = true;
            this.txtTelNoRes.IsEmailIdValid = false;
            this.txtTelNoRes.Location = new System.Drawing.Point(229, 13);
            this.txtTelNoRes.MaxLength = 60;
            this.txtTelNoRes.Name = "txtTelNoRes";
            this.txtTelNoRes.Size = new System.Drawing.Size(137, 20);
            this.txtTelNoRes.TabIndex = 3;
            // 
            // txtMobileNo1
            // 
            this.txtMobileNo1.AllowAlpha = true;
            this.txtMobileNo1.AllowDot = true;
            this.txtMobileNo1.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtMobileNo1.AllowedCustomCharacters")));
            this.txtMobileNo1.AllowNonASCII = false;
            this.txtMobileNo1.AllowNumeric = true;
            this.txtMobileNo1.AllowSpace = false;
            this.txtMobileNo1.AllowSpecialChars = true;
            this.txtMobileNo1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMobileNo1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtMobileNo1.ForeColor = System.Drawing.Color.Black;
            this.txtMobileNo1.IsEmailID = true;
            this.txtMobileNo1.IsEmailIdValid = false;
            this.txtMobileNo1.Location = new System.Drawing.Point(80, 93);
            this.txtMobileNo1.MaxLength = 17;
            this.txtMobileNo1.Name = "txtMobileNo1";
            this.txtMobileNo1.Size = new System.Drawing.Size(138, 20);
            this.txtMobileNo1.TabIndex = 13;
            // 
            // txtMobileNo2
            // 
            this.txtMobileNo2.AllowAlpha = true;
            this.txtMobileNo2.AllowDot = true;
            this.txtMobileNo2.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtMobileNo2.AllowedCustomCharacters")));
            this.txtMobileNo2.AllowNonASCII = false;
            this.txtMobileNo2.AllowNumeric = true;
            this.txtMobileNo2.AllowSpace = false;
            this.txtMobileNo2.AllowSpecialChars = true;
            this.txtMobileNo2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMobileNo2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtMobileNo2.ForeColor = System.Drawing.Color.Black;
            this.txtMobileNo2.IsEmailID = true;
            this.txtMobileNo2.IsEmailIdValid = false;
            this.txtMobileNo2.Location = new System.Drawing.Point(229, 93);
            this.txtMobileNo2.MaxLength = 10;
            this.txtMobileNo2.Name = "txtMobileNo2";
            this.txtMobileNo2.Size = new System.Drawing.Size(138, 20);
            this.txtMobileNo2.TabIndex = 14;
            // 
            // txtTelNoOfficeSTDCode
            // 
            this.txtTelNoOfficeSTDCode.AllowAlpha = true;
            this.txtTelNoOfficeSTDCode.AllowDot = true;
            this.txtTelNoOfficeSTDCode.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtTelNoOfficeSTDCode.AllowedCustomCharacters")));
            this.txtTelNoOfficeSTDCode.AllowNonASCII = false;
            this.txtTelNoOfficeSTDCode.AllowNumeric = true;
            this.txtTelNoOfficeSTDCode.AllowSpace = false;
            this.txtTelNoOfficeSTDCode.AllowSpecialChars = false;
            this.txtTelNoOfficeSTDCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTelNoOfficeSTDCode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtTelNoOfficeSTDCode.ForeColor = System.Drawing.Color.Black;
            this.txtTelNoOfficeSTDCode.IsEmailID = true;
            this.txtTelNoOfficeSTDCode.IsEmailIdValid = false;
            this.txtTelNoOfficeSTDCode.Location = new System.Drawing.Point(156, 67);
            this.txtTelNoOfficeSTDCode.MaxLength = 10;
            this.txtTelNoOfficeSTDCode.Name = "txtTelNoOfficeSTDCode";
            this.txtTelNoOfficeSTDCode.Size = new System.Drawing.Size(62, 20);
            this.txtTelNoOfficeSTDCode.TabIndex = 10;
            // 
            // lblFaxNo
            // 
            this.lblFaxNo.AllowForeColorChange = false;
            this.lblFaxNo.AutoSize = true;
            this.lblFaxNo.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblFaxNo.ForeColor = System.Drawing.Color.Black;
            this.lblFaxNo.Location = new System.Drawing.Point(12, 41);
            this.lblFaxNo.Name = "lblFaxNo";
            this.lblFaxNo.OverrideDefault = false;
            this.lblFaxNo.Size = new System.Drawing.Size(40, 12);
            this.lblFaxNo.TabIndex = 4;
            this.lblFaxNo.Text = "Fax No.";
            // 
            // txtTelNoOfficeISDCode
            // 
            this.txtTelNoOfficeISDCode.AllowAlpha = true;
            this.txtTelNoOfficeISDCode.AllowDot = true;
            this.txtTelNoOfficeISDCode.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtTelNoOfficeISDCode.AllowedCustomCharacters")));
            this.txtTelNoOfficeISDCode.AllowNonASCII = false;
            this.txtTelNoOfficeISDCode.AllowNumeric = true;
            this.txtTelNoOfficeISDCode.AllowSpace = false;
            this.txtTelNoOfficeISDCode.AllowSpecialChars = true;
            this.txtTelNoOfficeISDCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTelNoOfficeISDCode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtTelNoOfficeISDCode.ForeColor = System.Drawing.Color.Black;
            this.txtTelNoOfficeISDCode.IsEmailID = true;
            this.txtTelNoOfficeISDCode.IsEmailIdValid = false;
            this.txtTelNoOfficeISDCode.Location = new System.Drawing.Point(80, 67);
            this.txtTelNoOfficeISDCode.MaxLength = 14;
            this.txtTelNoOfficeISDCode.Name = "txtTelNoOfficeISDCode";
            this.txtTelNoOfficeISDCode.Size = new System.Drawing.Size(68, 20);
            this.txtTelNoOfficeISDCode.TabIndex = 9;
            // 
            // txtFaxNo
            // 
            this.txtFaxNo.AllowAlpha = true;
            this.txtFaxNo.AllowDot = true;
            this.txtFaxNo.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtFaxNo.AllowedCustomCharacters")));
            this.txtFaxNo.AllowNonASCII = false;
            this.txtFaxNo.AllowNumeric = true;
            this.txtFaxNo.AllowSpace = false;
            this.txtFaxNo.AllowSpecialChars = true;
            this.txtFaxNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFaxNo.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtFaxNo.ForeColor = System.Drawing.Color.Black;
            this.txtFaxNo.IsEmailID = true;
            this.txtFaxNo.IsEmailIdValid = false;
            this.txtFaxNo.Location = new System.Drawing.Point(229, 39);
            this.txtFaxNo.MaxLength = 60;
            this.txtFaxNo.Name = "txtFaxNo";
            this.txtFaxNo.Size = new System.Drawing.Size(137, 20);
            this.txtFaxNo.TabIndex = 7;
            // 
            // txtTelNoOffice
            // 
            this.txtTelNoOffice.AllowAlpha = true;
            this.txtTelNoOffice.AllowDot = true;
            this.txtTelNoOffice.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtTelNoOffice.AllowedCustomCharacters")));
            this.txtTelNoOffice.AllowNonASCII = false;
            this.txtTelNoOffice.AllowNumeric = true;
            this.txtTelNoOffice.AllowSpace = false;
            this.txtTelNoOffice.AllowSpecialChars = true;
            this.txtTelNoOffice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTelNoOffice.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtTelNoOffice.ForeColor = System.Drawing.Color.Black;
            this.txtTelNoOffice.IsEmailID = true;
            this.txtTelNoOffice.IsEmailIdValid = false;
            this.txtTelNoOffice.Location = new System.Drawing.Point(229, 67);
            this.txtTelNoOffice.MaxLength = 60;
            this.txtTelNoOffice.Name = "txtTelNoOffice";
            this.txtTelNoOffice.Size = new System.Drawing.Size(137, 20);
            this.txtTelNoOffice.TabIndex = 11;
            // 
            // txtTelNoResISDCode
            // 
            this.txtTelNoResISDCode.AllowAlpha = true;
            this.txtTelNoResISDCode.AllowDot = true;
            this.txtTelNoResISDCode.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtTelNoResISDCode.AllowedCustomCharacters")));
            this.txtTelNoResISDCode.AllowNonASCII = false;
            this.txtTelNoResISDCode.AllowNumeric = true;
            this.txtTelNoResISDCode.AllowSpace = false;
            this.txtTelNoResISDCode.AllowSpecialChars = true;
            this.txtTelNoResISDCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTelNoResISDCode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtTelNoResISDCode.ForeColor = System.Drawing.Color.Black;
            this.txtTelNoResISDCode.IsEmailID = true;
            this.txtTelNoResISDCode.IsEmailIdValid = false;
            this.txtTelNoResISDCode.Location = new System.Drawing.Point(80, 13);
            this.txtTelNoResISDCode.MaxLength = 14;
            this.txtTelNoResISDCode.Name = "txtTelNoResISDCode";
            this.txtTelNoResISDCode.Size = new System.Drawing.Size(68, 20);
            this.txtTelNoResISDCode.TabIndex = 1;
            // 
            // lblOffTelNo
            // 
            this.lblOffTelNo.AllowForeColorChange = false;
            this.lblOffTelNo.AutoSize = true;
            this.lblOffTelNo.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblOffTelNo.ForeColor = System.Drawing.Color.Black;
            this.lblOffTelNo.Location = new System.Drawing.Point(12, 69);
            this.lblOffTelNo.Name = "lblOffTelNo";
            this.lblOffTelNo.OverrideDefault = false;
            this.lblOffTelNo.Size = new System.Drawing.Size(56, 12);
            this.lblOffTelNo.TabIndex = 8;
            this.lblOffTelNo.Text = "Tel. No (O)";
            // 
            // txtTelNoResSTDCode
            // 
            this.txtTelNoResSTDCode.AllowAlpha = true;
            this.txtTelNoResSTDCode.AllowDot = true;
            this.txtTelNoResSTDCode.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtTelNoResSTDCode.AllowedCustomCharacters")));
            this.txtTelNoResSTDCode.AllowNonASCII = false;
            this.txtTelNoResSTDCode.AllowNumeric = true;
            this.txtTelNoResSTDCode.AllowSpace = false;
            this.txtTelNoResSTDCode.AllowSpecialChars = true;
            this.txtTelNoResSTDCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTelNoResSTDCode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtTelNoResSTDCode.ForeColor = System.Drawing.Color.Black;
            this.txtTelNoResSTDCode.IsEmailID = true;
            this.txtTelNoResSTDCode.IsEmailIdValid = false;
            this.txtTelNoResSTDCode.Location = new System.Drawing.Point(156, 13);
            this.txtTelNoResSTDCode.MaxLength = 10;
            this.txtTelNoResSTDCode.Name = "txtTelNoResSTDCode";
            this.txtTelNoResSTDCode.Size = new System.Drawing.Size(62, 20);
            this.txtTelNoResSTDCode.TabIndex = 2;
            // 
            // txtFAXNoSTDCode
            // 
            this.txtFAXNoSTDCode.AllowAlpha = false;
            this.txtFAXNoSTDCode.AllowDot = false;
            this.txtFAXNoSTDCode.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtFAXNoSTDCode.AllowedCustomCharacters")));
            this.txtFAXNoSTDCode.AllowNonASCII = false;
            this.txtFAXNoSTDCode.AllowNumeric = true;
            this.txtFAXNoSTDCode.AllowSpace = false;
            this.txtFAXNoSTDCode.AllowSpecialChars = false;
            this.txtFAXNoSTDCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFAXNoSTDCode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtFAXNoSTDCode.ForeColor = System.Drawing.Color.Black;
            this.txtFAXNoSTDCode.IsEmailID = true;
            this.txtFAXNoSTDCode.IsEmailIdValid = false;
            this.txtFAXNoSTDCode.Location = new System.Drawing.Point(156, 39);
            this.txtFAXNoSTDCode.MaxLength = 10;
            this.txtFAXNoSTDCode.Name = "txtFAXNoSTDCode";
            this.txtFAXNoSTDCode.Size = new System.Drawing.Size(62, 20);
            this.txtFAXNoSTDCode.TabIndex = 6;
            // 
            // txtFAXNoISDCode
            // 
            this.txtFAXNoISDCode.AllowAlpha = false;
            this.txtFAXNoISDCode.AllowDot = false;
            this.txtFAXNoISDCode.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtFAXNoISDCode.AllowedCustomCharacters")));
            this.txtFAXNoISDCode.AllowNonASCII = false;
            this.txtFAXNoISDCode.AllowNumeric = true;
            this.txtFAXNoISDCode.AllowSpace = false;
            this.txtFAXNoISDCode.AllowSpecialChars = false;
            this.txtFAXNoISDCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFAXNoISDCode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtFAXNoISDCode.ForeColor = System.Drawing.Color.Black;
            this.txtFAXNoISDCode.IsEmailID = true;
            this.txtFAXNoISDCode.IsEmailIdValid = false;
            this.txtFAXNoISDCode.Location = new System.Drawing.Point(80, 39);
            this.txtFAXNoISDCode.MaxLength = 14;
            this.txtFAXNoISDCode.Name = "txtFAXNoISDCode";
            this.txtFAXNoISDCode.Size = new System.Drawing.Size(68, 20);
            this.txtFAXNoISDCode.TabIndex = 5;
            // 
            // gbAddress
            // 
            this.gbAddress.Controls.Add(this.lblAddressLine1);
            this.gbAddress.Controls.Add(this.txtAddress1);
            this.gbAddress.Controls.Add(this.txtAddress3);
            this.gbAddress.Controls.Add(this.txtAddress2);
            this.gbAddress.Controls.Add(this.txtAddress4);
            this.gbAddress.Controls.Add(this.cboState);
            this.gbAddress.Controls.Add(this.lblState);
            this.gbAddress.Controls.Add(this.txtStateName);
            this.gbAddress.Controls.Add(this.cboCity);
            this.gbAddress.Controls.Add(this.lblCity);
            this.gbAddress.Controls.Add(this.lblPinCode);
            this.gbAddress.Controls.Add(this.lblCountry);
            this.gbAddress.Controls.Add(this.txtPinCode);
            this.gbAddress.Controls.Add(this.cboCountry);
            this.gbAddress.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.gbAddress.ForeColor = System.Drawing.Color.Black;
            this.gbAddress.Location = new System.Drawing.Point(11, 91);
            this.gbAddress.Name = "gbAddress";
            this.gbAddress.Size = new System.Drawing.Size(428, 189);
            this.gbAddress.TabIndex = 13;
            this.gbAddress.TabStop = false;
            // 
            // lblAddressLine1
            // 
            this.lblAddressLine1.AllowForeColorChange = false;
            this.lblAddressLine1.AutoSize = true;
            this.lblAddressLine1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblAddressLine1.ForeColor = System.Drawing.Color.Black;
            this.lblAddressLine1.Location = new System.Drawing.Point(15, 14);
            this.lblAddressLine1.Name = "lblAddressLine1";
            this.lblAddressLine1.OverrideDefault = false;
            this.lblAddressLine1.Size = new System.Drawing.Size(41, 12);
            this.lblAddressLine1.TabIndex = 0;
            this.lblAddressLine1.Text = "Address";
            // 
            // txtAddress1
            // 
            this.txtAddress1.AllowAlpha = true;
            this.txtAddress1.AllowDot = true;
            this.txtAddress1.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtAddress1.AllowedCustomCharacters")));
            this.txtAddress1.AllowNonASCII = false;
            this.txtAddress1.AllowNumeric = true;
            this.txtAddress1.AllowSpace = true;
            this.txtAddress1.AllowSpecialChars = true;
            this.txtAddress1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddress1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtAddress1.ForeColor = System.Drawing.Color.Black;
            this.txtAddress1.IsEmailID = true;
            this.txtAddress1.IsEmailIdValid = false;
            this.txtAddress1.Location = new System.Drawing.Point(82, 13);
            this.txtAddress1.MaxLength = 255;
            this.txtAddress1.Name = "txtAddress1";
            this.txtAddress1.Size = new System.Drawing.Size(337, 20);
            this.txtAddress1.TabIndex = 1;
            // 
            // txtAddress3
            // 
            this.txtAddress3.AllowAlpha = true;
            this.txtAddress3.AllowDot = true;
            this.txtAddress3.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtAddress3.AllowedCustomCharacters")));
            this.txtAddress3.AllowNonASCII = false;
            this.txtAddress3.AllowNumeric = true;
            this.txtAddress3.AllowSpace = true;
            this.txtAddress3.AllowSpecialChars = true;
            this.txtAddress3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddress3.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtAddress3.ForeColor = System.Drawing.Color.Black;
            this.txtAddress3.IsEmailID = true;
            this.txtAddress3.IsEmailIdValid = false;
            this.txtAddress3.Location = new System.Drawing.Point(82, 53);
            this.txtAddress3.MaxLength = 255;
            this.txtAddress3.Name = "txtAddress3";
            this.txtAddress3.Size = new System.Drawing.Size(337, 20);
            this.txtAddress3.TabIndex = 3;
            // 
            // txtAddress2
            // 
            this.txtAddress2.AllowAlpha = true;
            this.txtAddress2.AllowDot = true;
            this.txtAddress2.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtAddress2.AllowedCustomCharacters")));
            this.txtAddress2.AllowNonASCII = false;
            this.txtAddress2.AllowNumeric = true;
            this.txtAddress2.AllowSpace = true;
            this.txtAddress2.AllowSpecialChars = true;
            this.txtAddress2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddress2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtAddress2.ForeColor = System.Drawing.Color.Black;
            this.txtAddress2.IsEmailID = true;
            this.txtAddress2.IsEmailIdValid = false;
            this.txtAddress2.Location = new System.Drawing.Point(82, 33);
            this.txtAddress2.MaxLength = 255;
            this.txtAddress2.Name = "txtAddress2";
            this.txtAddress2.Size = new System.Drawing.Size(337, 20);
            this.txtAddress2.TabIndex = 2;
            // 
            // txtAddress4
            // 
            this.txtAddress4.AllowAlpha = true;
            this.txtAddress4.AllowDot = true;
            this.txtAddress4.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtAddress4.AllowedCustomCharacters")));
            this.txtAddress4.AllowNonASCII = false;
            this.txtAddress4.AllowNumeric = true;
            this.txtAddress4.AllowSpace = true;
            this.txtAddress4.AllowSpecialChars = true;
            this.txtAddress4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddress4.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtAddress4.ForeColor = System.Drawing.Color.Black;
            this.txtAddress4.IsEmailID = true;
            this.txtAddress4.IsEmailIdValid = false;
            this.txtAddress4.Location = new System.Drawing.Point(82, 73);
            this.txtAddress4.MaxLength = 255;
            this.txtAddress4.Name = "txtAddress4";
            this.txtAddress4.Size = new System.Drawing.Size(337, 20);
            this.txtAddress4.TabIndex = 4;
            // 
            // cboState
            // 
            this.cboState.BackColor = System.Drawing.Color.White;
            this.cboState.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboState.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboState.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboState.ForeColor = System.Drawing.Color.Black;
            this.cboState.FormattingEnabled = true;
            this.cboState.Location = new System.Drawing.Point(82, 132);
            this.cboState.MaxLength = 25;
            this.cboState.Name = "cboState";
            this.cboState.ReadOnly = false;
            this.cboState.Size = new System.Drawing.Size(186, 20);
            this.cboState.TabIndex = 10;
            this.cboState.SelectedIndexChanged += new System.EventHandler(this.cboState_SelectedIndexChanged);
            // 
            // lblState
            // 
            this.lblState.AllowForeColorChange = false;
            this.lblState.AutoSize = true;
            this.lblState.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblState.ForeColor = System.Drawing.Color.Black;
            this.lblState.Location = new System.Drawing.Point(15, 134);
            this.lblState.Name = "lblState";
            this.lblState.OverrideDefault = false;
            this.lblState.Size = new System.Drawing.Size(27, 12);
            this.lblState.TabIndex = 9;
            this.lblState.Text = "State";
            // 
            // txtStateName
            // 
            this.txtStateName.AllowAlpha = true;
            this.txtStateName.AllowDot = true;
            this.txtStateName.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtStateName.AllowedCustomCharacters")));
            this.txtStateName.AllowNonASCII = false;
            this.txtStateName.AllowNumeric = true;
            this.txtStateName.AllowSpace = true;
            this.txtStateName.AllowSpecialChars = true;
            this.txtStateName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtStateName.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtStateName.ForeColor = System.Drawing.Color.Black;
            this.txtStateName.IsEmailID = true;
            this.txtStateName.IsEmailIdValid = false;
            this.txtStateName.Location = new System.Drawing.Point(288, 132);
            this.txtStateName.MaxLength = 75;
            this.txtStateName.Name = "txtStateName";
            this.txtStateName.Size = new System.Drawing.Size(131, 20);
            this.txtStateName.TabIndex = 11;
            // 
            // cboCity
            // 
            this.cboCity.BackColor = System.Drawing.Color.White;
            this.cboCity.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboCity.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboCity.ForeColor = System.Drawing.Color.Black;
            this.cboCity.FormattingEnabled = true;
            this.cboCity.Location = new System.Drawing.Point(82, 105);
            this.cboCity.MaxLength = 50;
            this.cboCity.Name = "cboCity";
            this.cboCity.ReadOnly = false;
            this.cboCity.Size = new System.Drawing.Size(131, 20);
            this.cboCity.TabIndex = 6;
            this.cboCity.SelectedIndexChanged += new System.EventHandler(this.cboCity_SelectedIndexChanged);
            this.cboCity.TextUpdate += new System.EventHandler(this.cboCity_TextUpdate);
            // 
            // lblCity
            // 
            this.lblCity.AllowForeColorChange = false;
            this.lblCity.AutoSize = true;
            this.lblCity.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblCity.ForeColor = System.Drawing.Color.Black;
            this.lblCity.Location = new System.Drawing.Point(15, 108);
            this.lblCity.Name = "lblCity";
            this.lblCity.OverrideDefault = false;
            this.lblCity.Size = new System.Drawing.Size(23, 12);
            this.lblCity.TabIndex = 5;
            this.lblCity.Text = "City";
            // 
            // lblPinCode
            // 
            this.lblPinCode.AllowForeColorChange = false;
            this.lblPinCode.AutoSize = true;
            this.lblPinCode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblPinCode.ForeColor = System.Drawing.Color.Black;
            this.lblPinCode.Location = new System.Drawing.Point(222, 108);
            this.lblPinCode.Name = "lblPinCode";
            this.lblPinCode.OverrideDefault = false;
            this.lblPinCode.Size = new System.Drawing.Size(46, 12);
            this.lblPinCode.TabIndex = 7;
            this.lblPinCode.Text = "Pin Code";
            // 
            // lblCountry
            // 
            this.lblCountry.AllowForeColorChange = false;
            this.lblCountry.AutoSize = true;
            this.lblCountry.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblCountry.ForeColor = System.Drawing.Color.Black;
            this.lblCountry.Location = new System.Drawing.Point(15, 163);
            this.lblCountry.Name = "lblCountry";
            this.lblCountry.OverrideDefault = false;
            this.lblCountry.Size = new System.Drawing.Size(43, 12);
            this.lblCountry.TabIndex = 12;
            this.lblCountry.Text = "Country";
            // 
            // txtPinCode
            // 
            this.txtPinCode.AllowAlpha = true;
            this.txtPinCode.AllowDot = true;
            this.txtPinCode.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtPinCode.AllowedCustomCharacters")));
            this.txtPinCode.AllowNonASCII = false;
            this.txtPinCode.AllowNumeric = true;
            this.txtPinCode.AllowSpace = false;
            this.txtPinCode.AllowSpecialChars = true;
            this.txtPinCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPinCode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtPinCode.ForeColor = System.Drawing.Color.Black;
            this.txtPinCode.IsEmailID = true;
            this.txtPinCode.IsEmailIdValid = false;
            this.txtPinCode.Location = new System.Drawing.Point(288, 106);
            this.txtPinCode.MaxLength = 10;
            this.txtPinCode.Name = "txtPinCode";
            this.txtPinCode.Size = new System.Drawing.Size(131, 20);
            this.txtPinCode.TabIndex = 8;
            // 
            // cboCountry
            // 
            this.cboCountry.BackColor = System.Drawing.Color.White;
            this.cboCountry.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCountry.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboCountry.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboCountry.ForeColor = System.Drawing.Color.Black;
            this.cboCountry.FormattingEnabled = true;
            this.cboCountry.Location = new System.Drawing.Point(82, 158);
            this.cboCountry.MaxLength = 25;
            this.cboCountry.Name = "cboCountry";
            this.cboCountry.ReadOnly = false;
            this.cboCountry.Size = new System.Drawing.Size(186, 20);
            this.cboCountry.TabIndex = 13;
            // 
            // pnlActionControls
            // 
            this.pnlActionControls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlActionControls.Controls.Add(this.btnMakerCancel);
            this.pnlActionControls.Controls.Add(this.btnSave);
            this.pnlActionControls.Controls.Add(this.btnDelete);
            this.pnlActionControls.Controls.Add(this.btnAdd);
            this.pnlActionControls.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlActionControls.Location = new System.Drawing.Point(0, 312);
            this.pnlActionControls.Name = "pnlActionControls";
            this.pnlActionControls.Size = new System.Drawing.Size(856, 37);
            this.pnlActionControls.TabIndex = 22;
            // 
            // btnMakerCancel
            // 
            this.btnMakerCancel.BackColor = System.Drawing.Color.Transparent;
            this.btnMakerCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMakerCancel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btnMakerCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnMakerCancel.Image")));
            this.btnMakerCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMakerCancel.Location = new System.Drawing.Point(518, 6);
            this.btnMakerCancel.Name = "btnMakerCancel";
            this.btnMakerCancel.Size = new System.Drawing.Size(107, 25);
            this.btnMakerCancel.TabIndex = 0;
            this.btnMakerCancel.Text = "&Maker Cancel";
            this.btnMakerCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMakerCancel.UseVisualStyleBackColor = false;
            this.btnMakerCancel.Visible = false;
            this.btnMakerCancel.Click += new System.EventHandler(this.btnMakerCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Transparent;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Location = new System.Drawing.Point(800, 6);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 25);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "&Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Transparent;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.Location = new System.Drawing.Point(717, 6);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 25);
            this.btnDelete.TabIndex = 2;
            this.btnDelete.Text = "&Delete";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Transparent;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAdd.Location = new System.Drawing.Point(633, 6);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 25);
            this.btnAdd.TabIndex = 1;
            this.btnAdd.Text = "&New";
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // chkContactPersionDefault
            // 
            this.chkContactPersionDefault.AutoSize = true;
            this.chkContactPersionDefault.Location = new System.Drawing.Point(245, 291);
            this.chkContactPersionDefault.Name = "chkContactPersionDefault";
            this.chkContactPersionDefault.Size = new System.Drawing.Size(15, 14);
            this.chkContactPersionDefault.TabIndex = 19;
            this.chkContactPersionDefault.UseVisualStyleBackColor = true;
            this.chkContactPersionDefault.CheckedChanged += new System.EventHandler(this.chkContactPersionDefault_CheckedChanged);
            // 
            // lblContactPersonDefault
            // 
            this.lblContactPersonDefault.AllowForeColorChange = false;
            this.lblContactPersonDefault.AutoSize = true;
            this.lblContactPersonDefault.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblContactPersonDefault.ForeColor = System.Drawing.Color.Black;
            this.lblContactPersonDefault.Location = new System.Drawing.Point(125, 291);
            this.lblContactPersonDefault.Name = "lblContactPersonDefault";
            this.lblContactPersonDefault.OverrideDefault = false;
            this.lblContactPersonDefault.Size = new System.Drawing.Size(107, 12);
            this.lblContactPersonDefault.TabIndex = 18;
            this.lblContactPersonDefault.Text = "Contact person default";
            // 
            // chkDefault
            // 
            this.chkDefault.AutoSize = true;
            this.chkDefault.Location = new System.Drawing.Point(93, 290);
            this.chkDefault.Name = "chkDefault";
            this.chkDefault.Size = new System.Drawing.Size(15, 14);
            this.chkDefault.TabIndex = 17;
            this.chkDefault.UseVisualStyleBackColor = true;
            this.chkDefault.CheckedChanged += new System.EventHandler(this.chkDefault_CheckedChanged);
            // 
            // lblDefault
            // 
            this.lblDefault.AllowForeColorChange = false;
            this.lblDefault.AutoSize = true;
            this.lblDefault.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblDefault.ForeColor = System.Drawing.Color.Black;
            this.lblDefault.Location = new System.Drawing.Point(26, 291);
            this.lblDefault.Name = "lblDefault";
            this.lblDefault.OverrideDefault = false;
            this.lblDefault.Size = new System.Drawing.Size(36, 12);
            this.lblDefault.TabIndex = 16;
            this.lblDefault.Text = "Default";
            // 
            // chkSameCorresPermAdd
            // 
            this.chkSameCorresPermAdd.AutoSize = true;
            this.chkSameCorresPermAdd.Location = new System.Drawing.Point(415, 291);
            this.chkSameCorresPermAdd.Name = "chkSameCorresPermAdd";
            this.chkSameCorresPermAdd.Size = new System.Drawing.Size(15, 14);
            this.chkSameCorresPermAdd.TabIndex = 21;
            this.chkSameCorresPermAdd.UseVisualStyleBackColor = true;
            // 
            // lblPermenentAddSameAsCorrs
            // 
            this.lblPermenentAddSameAsCorrs.AllowForeColorChange = false;
            this.lblPermenentAddSameAsCorrs.AutoSize = true;
            this.lblPermenentAddSameAsCorrs.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblPermenentAddSameAsCorrs.ForeColor = System.Drawing.Color.Black;
            this.lblPermenentAddSameAsCorrs.Location = new System.Drawing.Point(282, 291);
            this.lblPermenentAddSameAsCorrs.Name = "lblPermenentAddSameAsCorrs";
            this.lblPermenentAddSameAsCorrs.OverrideDefault = false;
            this.lblPermenentAddSameAsCorrs.Size = new System.Drawing.Size(120, 12);
            this.lblPermenentAddSameAsCorrs.TabIndex = 20;
            this.lblPermenentAddSameAsCorrs.Text = "Permanent same as Corr. ";
            // 
            // txtUID
            // 
            this.txtUID.AllowAlpha = true;
            this.txtUID.AllowDot = true;
            this.txtUID.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtUID.AllowedCustomCharacters")));
            this.txtUID.AllowNonASCII = false;
            this.txtUID.AllowNumeric = true;
            this.txtUID.AllowSpace = true;
            this.txtUID.AllowSpecialChars = true;
            this.txtUID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtUID.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtUID.ForeColor = System.Drawing.Color.Black;
            this.txtUID.IsEmailID = true;
            this.txtUID.IsEmailIdValid = false;
            this.txtUID.Location = new System.Drawing.Point(562, 40);
            this.txtUID.MaxLength = 12;
            this.txtUID.Name = "txtUID";
            this.txtUID.Size = new System.Drawing.Size(286, 20);
            this.txtUID.TabIndex = 7;
            // 
            // lblUID
            // 
            this.lblUID.AllowForeColorChange = false;
            this.lblUID.AutoSize = true;
            this.lblUID.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblUID.ForeColor = System.Drawing.Color.Black;
            this.lblUID.Location = new System.Drawing.Point(494, 44);
            this.lblUID.Name = "lblUID";
            this.lblUID.OverrideDefault = false;
            this.lblUID.Size = new System.Drawing.Size(23, 12);
            this.lblUID.TabIndex = 6;
            this.lblUID.Text = "UID";
            // 
            // txtDIN
            // 
            this.txtDIN.AllowAlpha = true;
            this.txtDIN.AllowDot = true;
            this.txtDIN.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtDIN.AllowedCustomCharacters")));
            this.txtDIN.AllowNonASCII = false;
            this.txtDIN.AllowNumeric = true;
            this.txtDIN.AllowSpace = true;
            this.txtDIN.AllowSpecialChars = true;
            this.txtDIN.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDIN.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDIN.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtDIN.ForeColor = System.Drawing.Color.Black;
            this.txtDIN.IsEmailID = true;
            this.txtDIN.IsEmailIdValid = false;
            this.txtDIN.Location = new System.Drawing.Point(562, 68);
            this.txtDIN.MaxLength = 10;
            this.txtDIN.Name = "txtDIN";
            this.txtDIN.Size = new System.Drawing.Size(286, 20);
            this.txtDIN.TabIndex = 12;
            // 
            // txtPANNo
            // 
            this.txtPANNo.AllowAlpha = true;
            this.txtPANNo.AllowDot = false;
            this.txtPANNo.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtPANNo.AllowedCustomCharacters")));
            this.txtPANNo.AllowNonASCII = false;
            this.txtPANNo.AllowNumeric = true;
            this.txtPANNo.AllowSpace = false;
            this.txtPANNo.AllowSpecialChars = false;
            this.txtPANNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPANNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPANNo.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtPANNo.ForeColor = System.Drawing.Color.Black;
            this.txtPANNo.IsEmailID = true;
            this.txtPANNo.IsEmailIdValid = false;
            this.txtPANNo.Location = new System.Drawing.Point(93, 40);
            this.txtPANNo.MaxLength = 10;
            this.txtPANNo.Name = "txtPANNo";
            this.txtPANNo.Size = new System.Drawing.Size(146, 20);
            this.txtPANNo.TabIndex = 5;
            // 
            // chkIsDirector
            // 
            this.chkIsDirector.AutoSize = true;
            this.chkIsDirector.Location = new System.Drawing.Point(539, 71);
            this.chkIsDirector.Name = "chkIsDirector";
            this.chkIsDirector.Size = new System.Drawing.Size(15, 14);
            this.chkIsDirector.TabIndex = 11;
            this.chkIsDirector.UseVisualStyleBackColor = true;
            this.chkIsDirector.CheckedChanged += new System.EventHandler(this.chkIsDirector_CheckedChanged);
            // 
            // txtDesignation
            // 
            this.txtDesignation.AllowAlpha = true;
            this.txtDesignation.AllowDot = true;
            this.txtDesignation.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtDesignation.AllowedCustomCharacters")));
            this.txtDesignation.AllowNonASCII = false;
            this.txtDesignation.AllowNumeric = true;
            this.txtDesignation.AllowSpace = true;
            this.txtDesignation.AllowSpecialChars = true;
            this.txtDesignation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDesignation.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDesignation.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtDesignation.ForeColor = System.Drawing.Color.Black;
            this.txtDesignation.IsEmailID = true;
            this.txtDesignation.IsEmailIdValid = false;
            this.txtDesignation.Location = new System.Drawing.Point(93, 67);
            this.txtDesignation.MaxLength = 50;
            this.txtDesignation.Name = "txtDesignation";
            this.txtDesignation.Size = new System.Drawing.Size(337, 20);
            this.txtDesignation.TabIndex = 9;
            // 
            // lblPANNo
            // 
            this.lblPANNo.AllowForeColorChange = false;
            this.lblPANNo.AutoSize = true;
            this.lblPANNo.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblPANNo.ForeColor = System.Drawing.Color.Black;
            this.lblPANNo.Location = new System.Drawing.Point(26, 44);
            this.lblPANNo.Name = "lblPANNo";
            this.lblPANNo.OverrideDefault = false;
            this.lblPANNo.Size = new System.Drawing.Size(25, 12);
            this.lblPANNo.TabIndex = 4;
            this.lblPANNo.Text = "PAN";
            // 
            // lblCategory
            // 
            this.lblCategory.AllowForeColorChange = false;
            this.lblCategory.AutoSize = true;
            this.lblCategory.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblCategory.ForeColor = System.Drawing.Color.Black;
            this.lblCategory.Location = new System.Drawing.Point(26, 14);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.OverrideDefault = false;
            this.lblCategory.Size = new System.Drawing.Size(47, 12);
            this.lblCategory.TabIndex = 0;
            this.lblCategory.Text = "Category";
            // 
            // lblDirector
            // 
            this.lblDirector.AllowForeColorChange = false;
            this.lblDirector.AutoSize = true;
            this.lblDirector.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblDirector.ForeColor = System.Drawing.Color.Black;
            this.lblDirector.Location = new System.Drawing.Point(494, 70);
            this.lblDirector.Name = "lblDirector";
            this.lblDirector.OverrideDefault = false;
            this.lblDirector.Size = new System.Drawing.Size(23, 12);
            this.lblDirector.TabIndex = 10;
            this.lblDirector.Text = "DIN";
            // 
            // lblDesignation
            // 
            this.lblDesignation.AllowForeColorChange = false;
            this.lblDesignation.AutoSize = true;
            this.lblDesignation.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblDesignation.ForeColor = System.Drawing.Color.Black;
            this.lblDesignation.Location = new System.Drawing.Point(26, 70);
            this.lblDesignation.Name = "lblDesignation";
            this.lblDesignation.OverrideDefault = false;
            this.lblDesignation.Size = new System.Drawing.Size(57, 12);
            this.lblDesignation.TabIndex = 8;
            this.lblDesignation.Text = "Designation";
            // 
            // cboCategory
            // 
            this.cboCategory.BackColor = System.Drawing.Color.White;
            this.cboCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboCategory.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboCategory.ForeColor = System.Drawing.Color.Black;
            this.cboCategory.FormattingEnabled = true;
            this.cboCategory.Location = new System.Drawing.Point(93, 11);
            this.cboCategory.MaxLength = 25;
            this.cboCategory.Name = "cboCategory";
            this.cboCategory.ReadOnly = false;
            this.cboCategory.Size = new System.Drawing.Size(146, 20);
            this.cboCategory.TabIndex = 1;
            this.cboCategory.SelectionChangeCommitted += new System.EventHandler(this.cboCategory_SelectionChangeCommitted);
            // 
            // lblContactPerson
            // 
            this.lblContactPerson.AllowForeColorChange = false;
            this.lblContactPerson.AutoSize = true;
            this.lblContactPerson.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblContactPerson.ForeColor = System.Drawing.Color.Black;
            this.lblContactPerson.Location = new System.Drawing.Point(262, 14);
            this.lblContactPerson.Name = "lblContactPerson";
            this.lblContactPerson.OverrideDefault = false;
            this.lblContactPerson.Size = new System.Drawing.Size(74, 12);
            this.lblContactPerson.TabIndex = 2;
            this.lblContactPerson.Text = "Contact Person";
            // 
            // txtContactPerson
            // 
            this.txtContactPerson.AllowAlpha = true;
            this.txtContactPerson.AllowDot = true;
            this.txtContactPerson.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtContactPerson.AllowedCustomCharacters")));
            this.txtContactPerson.AllowNonASCII = false;
            this.txtContactPerson.AllowNumeric = true;
            this.txtContactPerson.AllowSpace = true;
            this.txtContactPerson.AllowSpecialChars = true;
            this.txtContactPerson.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtContactPerson.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtContactPerson.ForeColor = System.Drawing.Color.Black;
            this.txtContactPerson.IsEmailID = true;
            this.txtContactPerson.IsEmailIdValid = false;
            this.txtContactPerson.Location = new System.Drawing.Point(363, 11);
            this.txtContactPerson.MaxLength = 255;
            this.txtContactPerson.Name = "txtContactPerson";
            this.txtContactPerson.Size = new System.Drawing.Size(485, 20);
            this.txtContactPerson.TabIndex = 3;
            // 
            // UCCClientAddressInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.ftAddressGridPanel);
            this.Controls.Add(this.pnlAddressDetails);
            this.Name = "UCCClientAddressInfo";
            this.Size = new System.Drawing.Size(856, 446);
            this.Load += new System.EventHandler(this.UCCClientAddressInfo_Load);
            this.ftAddressGridPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAddress)).EndInit();
            this.pnlAddressDetails.ResumeLayout(false);
            this.pnlAddressDetails.PerformLayout();
            this.gbEmail.ResumeLayout(false);
            this.gbEmail.PerformLayout();
            this.gbPhone.ResumeLayout(false);
            this.gbPhone.PerformLayout();
            this.gbAddress.ResumeLayout(false);
            this.gbAddress.PerformLayout();
            this.pnlActionControls.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MatchCommon.CustomControls.FTPanel ftAddressGridPanel;
        private MatchCommon.CustomControls.FTDataGrid dgvAddress;
        private MatchCommon.CustomControls.FTPanel pnlAddressDetails;
        private MatchCommon.CustomControls.FTTextBox txtFAXNoSTDCode;
        private MatchCommon.CustomControls.FTTextBox txtFAXNoISDCode;
        private MatchCommon.CustomControls.FTTextBox txtTelNoResSTDCode;
        private MatchCommon.CustomControls.FTTextBox txtTelNoResISDCode;
        private MatchCommon.CustomControls.FTLabel lblCountry;
        private MatchCommon.CustomControls.FTComboBox cboCountry;
        private System.Windows.Forms.CheckBox chkDefault;
        private MatchCommon.CustomControls.FTLabel lblDefault;
        private System.Windows.Forms.CheckBox chkSameCorresPermAdd;
        private MatchCommon.CustomControls.FTLabel lblPermenentAddSameAsCorrs;
        private MatchCommon.CustomControls.FTTextBox txtUID;
        private MatchCommon.CustomControls.FTLabel lblUID;
        private MatchCommon.CustomControls.FTTextBox txtDIN;
        private MatchCommon.CustomControls.FTTextBox txtBCCEmailId;
        private MatchCommon.CustomControls.FTLabel lblBCCMail;
        private MatchCommon.CustomControls.FTTextBox txtCCEmailId;
        private MatchCommon.CustomControls.FTLabel lblCCMail;
        private MatchCommon.CustomControls.FTTextBox txtEmailId;
        private MatchCommon.CustomControls.FTLabel lblEmailID;
        private MatchCommon.CustomControls.FTTextBox txtFaxNo;
        private MatchCommon.CustomControls.FTLabel lblFaxNo;
        private MatchCommon.CustomControls.FTTextBox txtMobileNo2;
        private MatchCommon.CustomControls.FTTextBox txtMobileNo1;
        private MatchCommon.CustomControls.FTTextBox txtTelNoRes;
        private MatchCommon.CustomControls.FTLabel lblResTelNo;
        private MatchCommon.CustomControls.FTTextBox txtPinCode;
        private MatchCommon.CustomControls.FTLabel lblPinCode;
        private MatchCommon.CustomControls.FTLabel lblCity;
        private MatchCommon.CustomControls.FTComboBox cboCity;
        private MatchCommon.CustomControls.FTTextBox txtStateName;
        private MatchCommon.CustomControls.FTLabel lblState;
        private MatchCommon.CustomControls.FTComboBox cboState;
        private MatchCommon.CustomControls.FTTextBox txtPANNo;
        private MatchCommon.CustomControls.FTTextBox txtAddress4;
        private MatchCommon.CustomControls.FTTextBox txtAddress2;
        private MatchCommon.CustomControls.FTTextBox txtAddress3;
        private MatchCommon.CustomControls.FTTextBox txtAddress1;
        private System.Windows.Forms.CheckBox chkIsDirector;
        private MatchCommon.CustomControls.FTTextBox txtDesignation;
        private MatchCommon.CustomControls.FTLabel lblAddressLine1;
        private MatchCommon.CustomControls.FTLabel lblPANNo;
        private MatchCommon.CustomControls.FTLabel lblCategory;
        private MatchCommon.CustomControls.FTLabel lblMobile;
        private MatchCommon.CustomControls.FTLabel lblDirector;
        private MatchCommon.CustomControls.FTLabel lblDesignation;
        private MatchCommon.CustomControls.FTComboBox cboCategory;
        private MatchCommon.CustomControls.FTLabel lblContactPerson;
        private MatchCommon.CustomControls.FTTextBox txtContactPerson;
        private MatchCommon.CustomControls.FTTextBox txtTelNoOfficeSTDCode;
        private MatchCommon.CustomControls.FTTextBox txtTelNoOfficeISDCode;
        private MatchCommon.CustomControls.FTTextBox txtTelNoOffice;
        private MatchCommon.CustomControls.FTLabel lblOffTelNo;
        private System.Windows.Forms.CheckBox chkContactPersionDefault;
        private MatchCommon.CustomControls.FTLabel lblContactPersonDefault;
        private MatchCommon.CustomControls.FTPanel pnlActionControls;
        private MatchCommon.CustomControls.FTButton btnSave;
        private MatchCommon.CustomControls.FTButton btnDelete;
        private MatchCommon.CustomControls.FTButton btnAdd;
        private System.Windows.Forms.ToolTip ttMain;
        private MatchCommon.CustomControls.FTGroupBox gbAddress;
        private MatchCommon.CustomControls.FTGroupBox gbPhone;
        private MatchCommon.CustomControls.FTGroupBox gbEmail;
        private MatchCommon.CustomControls.FTButton btnMakerCancel;
    }
}
