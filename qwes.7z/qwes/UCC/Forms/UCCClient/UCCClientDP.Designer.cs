﻿namespace UCC.Forms.UCCClient
{
    partial class UCCClientDP
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCCClientDP));
            this.ftDPGridPanel = new MatchCommon.CustomControls.FTPanel();
            this.dgvClientDP = new MatchCommon.CustomControls.FTDataGrid();
            this.pnlClientDPDetails = new MatchCommon.CustomControls.FTPanel();
            this.pnlOtherControls = new MatchCommon.CustomControls.FTPanel();
            this.lblDP = new MatchCommon.CustomControls.FTLabel();
            this.txtDP = new MatchCommon.CustomControls.FTTextBox();
            this.chkPOA = new System.Windows.Forms.CheckBox();
            this.lblClientId = new MatchCommon.CustomControls.FTLabel();
            this.lblPOA = new MatchCommon.CustomControls.FTLabel();
            this.txtClientId = new MatchCommon.CustomControls.FTTextBox();
            this.chkDefault = new System.Windows.Forms.CheckBox();
            this.lblDefault = new MatchCommon.CustomControls.FTLabel();
            this.pnlExchange = new MatchCommon.CustomControls.FTPanel();
            this.lblExchange = new MatchCommon.CustomControls.FTLabel();
            this.cboExchange = new MatchCommon.CustomControls.FTComboBox();
            this.pnlActionControls = new MatchCommon.CustomControls.FTPanel();
            this.btnMakerCancel = new MatchCommon.CustomControls.FTButton();
            this.btnSave = new MatchCommon.CustomControls.FTButton();
            this.btnDelete = new MatchCommon.CustomControls.FTButton();
            this.btnAdd = new MatchCommon.CustomControls.FTButton();
            this.ttMain = new System.Windows.Forms.ToolTip(this.components);
            this.ftDPGridPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClientDP)).BeginInit();
            this.pnlClientDPDetails.SuspendLayout();
            this.pnlOtherControls.SuspendLayout();
            this.pnlExchange.SuspendLayout();
            this.pnlActionControls.SuspendLayout();
            this.SuspendLayout();
            // 
            // ftDPGridPanel
            // 
            this.ftDPGridPanel.Controls.Add(this.dgvClientDP);
            this.ftDPGridPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ftDPGridPanel.Location = new System.Drawing.Point(0, 0);
            this.ftDPGridPanel.Name = "ftDPGridPanel";
            this.ftDPGridPanel.Size = new System.Drawing.Size(856, 371);
            this.ftDPGridPanel.TabIndex = 6;
            // 
            // dgvClientDP
            // 
            this.dgvClientDP.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
            this.dgvClientDP.AllowEditing = false;
            this.dgvClientDP.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
            this.dgvClientDP.BackColor = System.Drawing.Color.Transparent;
            this.dgvClientDP.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.dgvClientDP.ColumnInfo = "10,1,0,0,0,85,Columns:0{Width:30;}\t";
            this.dgvClientDP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvClientDP.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
            this.dgvClientDP.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dgvClientDP.ForeColor = System.Drawing.Color.Black;
            this.dgvClientDP.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
            this.dgvClientDP.Location = new System.Drawing.Point(0, 0);
            this.dgvClientDP.Name = "dgvClientDP";
            this.dgvClientDP.OverrideDefault = false;
            this.dgvClientDP.Rows.Count = 1;
            this.dgvClientDP.Rows.DefaultSize = 17;
            this.dgvClientDP.Rows.MinSize = 25;
            this.dgvClientDP.RowsFilter.AddFilterRow = false;
            this.dgvClientDP.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.ListBox;
            this.dgvClientDP.Size = new System.Drawing.Size(856, 371);
            this.dgvClientDP.StyleInfo = "";
            this.dgvClientDP.TabIndex = 0;
            this.dgvClientDP.RowColChange += new System.EventHandler(this.dgvDP_RowColChange);
            // 
            // pnlClientDPDetails
            // 
            this.pnlClientDPDetails.Controls.Add(this.pnlOtherControls);
            this.pnlClientDPDetails.Controls.Add(this.pnlExchange);
            this.pnlClientDPDetails.Controls.Add(this.pnlActionControls);
            this.pnlClientDPDetails.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlClientDPDetails.Location = new System.Drawing.Point(0, 371);
            this.pnlClientDPDetails.Name = "pnlClientDPDetails";
            this.pnlClientDPDetails.Size = new System.Drawing.Size(856, 75);
            this.pnlClientDPDetails.TabIndex = 0;
            // 
            // pnlOtherControls
            // 
            this.pnlOtherControls.Controls.Add(this.lblDP);
            this.pnlOtherControls.Controls.Add(this.txtDP);
            this.pnlOtherControls.Controls.Add(this.chkPOA);
            this.pnlOtherControls.Controls.Add(this.lblClientId);
            this.pnlOtherControls.Controls.Add(this.lblPOA);
            this.pnlOtherControls.Controls.Add(this.txtClientId);
            this.pnlOtherControls.Controls.Add(this.chkDefault);
            this.pnlOtherControls.Controls.Add(this.lblDefault);
            this.pnlOtherControls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlOtherControls.Location = new System.Drawing.Point(203, 0);
            this.pnlOtherControls.Name = "pnlOtherControls";
            this.pnlOtherControls.Size = new System.Drawing.Size(653, 41);
            this.pnlOtherControls.TabIndex = 0;
            // 
            // lblDP
            // 
            this.lblDP.AllowForeColorChange = false;
            this.lblDP.AutoSize = true;
            this.lblDP.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblDP.ForeColor = System.Drawing.Color.Black;
            this.lblDP.Location = new System.Drawing.Point(13, 14);
            this.lblDP.Name = "lblDP";
            this.lblDP.OverrideDefault = false;
            this.lblDP.Size = new System.Drawing.Size(20, 13);
            this.lblDP.TabIndex = 2;
            this.lblDP.Text = "DP";
            // 
            // txtDP
            // 
            this.txtDP.AllowAlpha = true;
            this.txtDP.AllowDot = true;
            this.txtDP.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtDP.AllowedCustomCharacters")));
            this.txtDP.AllowNonASCII = false;
            this.txtDP.AllowNumeric = true;
            this.txtDP.AllowSpace = true;
            this.txtDP.AllowSpecialChars = true;
            this.txtDP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDP.FocusColor = System.Drawing.Color.LightYellow;
            this.txtDP.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtDP.ForeColor = System.Drawing.Color.Black;
            this.txtDP.IsEmailID = true;
            this.txtDP.IsEmailIdValid = false;
            this.txtDP.Location = new System.Drawing.Point(42, 11);
            this.txtDP.MaxLength = 255;
            this.txtDP.Name = "txtDP";
            this.txtDP.Size = new System.Drawing.Size(179, 20);
            this.txtDP.TabIndex = 5;
            this.txtDP.TextChanged += new System.EventHandler(this.txtDP_TextChanged);
            this.txtDP.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtDP_KeyUp);
            this.txtDP.Leave += new System.EventHandler(this.txtDP_Leave);
            // 
            // chkPOA
            // 
            this.chkPOA.AutoSize = true;
            this.chkPOA.Location = new System.Drawing.Point(606, 14);
            this.chkPOA.Name = "chkPOA";
            this.chkPOA.Size = new System.Drawing.Size(15, 14);
            this.chkPOA.TabIndex = 2;
            this.chkPOA.UseVisualStyleBackColor = true;
            // 
            // lblClientId
            // 
            this.lblClientId.AllowForeColorChange = false;
            this.lblClientId.AutoSize = true;
            this.lblClientId.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblClientId.ForeColor = System.Drawing.Color.Black;
            this.lblClientId.Location = new System.Drawing.Point(237, 14);
            this.lblClientId.Name = "lblClientId";
            this.lblClientId.OverrideDefault = false;
            this.lblClientId.Size = new System.Drawing.Size(47, 13);
            this.lblClientId.TabIndex = 6;
            this.lblClientId.Text = "Client Id";
            // 
            // lblPOA
            // 
            this.lblPOA.AllowForeColorChange = false;
            this.lblPOA.AutoSize = true;
            this.lblPOA.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblPOA.ForeColor = System.Drawing.Color.Black;
            this.lblPOA.Location = new System.Drawing.Point(570, 14);
            this.lblPOA.Name = "lblPOA";
            this.lblPOA.OverrideDefault = false;
            this.lblPOA.Size = new System.Drawing.Size(28, 13);
            this.lblPOA.TabIndex = 3;
            this.lblPOA.Text = "POA";
            // 
            // txtClientId
            // 
            this.txtClientId.AllowAlpha = true;
            this.txtClientId.AllowDot = false;
            this.txtClientId.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtClientId.AllowedCustomCharacters")));
            this.txtClientId.AllowNonASCII = false;
            this.txtClientId.AllowNumeric = true;
            this.txtClientId.AllowSpace = false;
            this.txtClientId.AllowSpecialChars = false;
            this.txtClientId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtClientId.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtClientId.FocusColor = System.Drawing.Color.LightYellow;
            this.txtClientId.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtClientId.ForeColor = System.Drawing.Color.Black;
            this.txtClientId.IsEmailID = true;
            this.txtClientId.IsEmailIdValid = false;
            this.txtClientId.Location = new System.Drawing.Point(294, 11);
            this.txtClientId.MaxLength = 16;
            this.txtClientId.Name = "txtClientId";
            this.txtClientId.Size = new System.Drawing.Size(174, 20);
            this.txtClientId.TabIndex = 7;
            // 
            // chkDefault
            // 
            this.chkDefault.AutoSize = true;
            this.chkDefault.Location = new System.Drawing.Point(536, 14);
            this.chkDefault.Name = "chkDefault";
            this.chkDefault.Size = new System.Drawing.Size(15, 14);
            this.chkDefault.TabIndex = 1;
            this.chkDefault.UseVisualStyleBackColor = true;
            this.chkDefault.CheckedChanged += new System.EventHandler(this.chkDefault_CheckedChanged);
            // 
            // lblDefault
            // 
            this.lblDefault.AllowForeColorChange = false;
            this.lblDefault.AutoSize = true;
            this.lblDefault.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblDefault.ForeColor = System.Drawing.Color.Black;
            this.lblDefault.Location = new System.Drawing.Point(489, 14);
            this.lblDefault.Name = "lblDefault";
            this.lblDefault.OverrideDefault = false;
            this.lblDefault.Size = new System.Drawing.Size(42, 13);
            this.lblDefault.TabIndex = 0;
            this.lblDefault.Text = "Default";
            // 
            // pnlExchange
            // 
            this.pnlExchange.Controls.Add(this.lblExchange);
            this.pnlExchange.Controls.Add(this.cboExchange);
            this.pnlExchange.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlExchange.Location = new System.Drawing.Point(0, 0);
            this.pnlExchange.Name = "pnlExchange";
            this.pnlExchange.Size = new System.Drawing.Size(203, 41);
            this.pnlExchange.TabIndex = 0;
            // 
            // lblExchange
            // 
            this.lblExchange.AllowForeColorChange = false;
            this.lblExchange.AutoSize = true;
            this.lblExchange.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblExchange.ForeColor = System.Drawing.Color.Black;
            this.lblExchange.Location = new System.Drawing.Point(9, 13);
            this.lblExchange.Name = "lblExchange";
            this.lblExchange.OverrideDefault = false;
            this.lblExchange.Size = new System.Drawing.Size(54, 13);
            this.lblExchange.TabIndex = 1;
            this.lblExchange.Text = "Exchange";
            // 
            // cboExchange
            // 
            this.cboExchange.BackColor = System.Drawing.Color.White;
            this.cboExchange.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboExchange.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboExchange.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboExchange.ForeColor = System.Drawing.Color.Black;
            this.cboExchange.FormattingEnabled = true;
            this.cboExchange.Location = new System.Drawing.Point(76, 10);
            this.cboExchange.MaxLength = 25;
            this.cboExchange.Name = "cboExchange";
            this.cboExchange.ReadOnly = false;
            this.cboExchange.Size = new System.Drawing.Size(118, 21);
            this.cboExchange.TabIndex = 0;
            // 
            // pnlActionControls
            // 
            this.pnlActionControls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlActionControls.Controls.Add(this.btnMakerCancel);
            this.pnlActionControls.Controls.Add(this.btnSave);
            this.pnlActionControls.Controls.Add(this.btnDelete);
            this.pnlActionControls.Controls.Add(this.btnAdd);
            this.pnlActionControls.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlActionControls.Location = new System.Drawing.Point(0, 41);
            this.pnlActionControls.Name = "pnlActionControls";
            this.pnlActionControls.Size = new System.Drawing.Size(856, 34);
            this.pnlActionControls.TabIndex = 0;
            // 
            // btnMakerCancel
            // 
            this.btnMakerCancel.BackColor = System.Drawing.Color.Transparent;
            this.btnMakerCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMakerCancel.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnMakerCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnMakerCancel.Image")));
            this.btnMakerCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMakerCancel.Location = new System.Drawing.Point(517, 6);
            this.btnMakerCancel.Name = "btnMakerCancel";
            this.btnMakerCancel.Size = new System.Drawing.Size(107, 23);
            this.btnMakerCancel.TabIndex = 0;
            this.btnMakerCancel.Text = "&Maker Cancel";
            this.btnMakerCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMakerCancel.UseVisualStyleBackColor = false;
            this.btnMakerCancel.Visible = false;
            this.btnMakerCancel.Click += new System.EventHandler(this.btnMakerCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Transparent;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Location = new System.Drawing.Point(800, 6);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "&Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Transparent;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.Location = new System.Drawing.Point(717, 6);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 2;
            this.btnDelete.Text = "&Delete";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Transparent;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAdd.Location = new System.Drawing.Point(633, 6);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 1;
            this.btnAdd.Text = "&New";
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // UCCClientDP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.ftDPGridPanel);
            this.Controls.Add(this.pnlClientDPDetails);
            this.Name = "UCCClientDP";
            this.Size = new System.Drawing.Size(856, 446);
            this.Load += new System.EventHandler(this.UCCClientDPInfo_Load);
            this.ftDPGridPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvClientDP)).EndInit();
            this.pnlClientDPDetails.ResumeLayout(false);
            this.pnlOtherControls.ResumeLayout(false);
            this.pnlOtherControls.PerformLayout();
            this.pnlExchange.ResumeLayout(false);
            this.pnlExchange.PerformLayout();
            this.pnlActionControls.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MatchCommon.CustomControls.FTPanel ftDPGridPanel;
        private MatchCommon.CustomControls.FTDataGrid dgvClientDP;
        private MatchCommon.CustomControls.FTPanel pnlClientDPDetails;
        private System.Windows.Forms.CheckBox chkDefault;
        private MatchCommon.CustomControls.FTLabel lblDefault;
        private MatchCommon.CustomControls.FTTextBox txtClientId;
        private MatchCommon.CustomControls.FTLabel lblClientId;
        private MatchCommon.CustomControls.FTLabel lblExchange;
        private MatchCommon.CustomControls.FTComboBox cboExchange;
        private MatchCommon.CustomControls.FTLabel lblDP;
        private MatchCommon.CustomControls.FTTextBox txtDP;
        private System.Windows.Forms.CheckBox chkPOA;
        private MatchCommon.CustomControls.FTLabel lblPOA;
        private MatchCommon.CustomControls.FTPanel pnlActionControls;
        private MatchCommon.CustomControls.FTButton btnSave;
        private MatchCommon.CustomControls.FTButton btnDelete;
        private MatchCommon.CustomControls.FTButton btnAdd;
        private System.Windows.Forms.ToolTip ttMain;
        private MatchCommon.CustomControls.FTPanel pnlOtherControls;
        private MatchCommon.CustomControls.FTPanel pnlExchange;
        private MatchCommon.CustomControls.FTButton btnMakerCancel;
    }
}
