﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Collections;

using C1.Win.C1FlexGrid;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;
using FTIL.Match.Common.Utils;
using FTIL.Match.Common.Constants;
using UCC.Class;
using System.Text.RegularExpressions;
using UCC.Class.Master;

namespace UCC.Forms.UCCClient
{
    /// <summary>
    /// Client address screen user control
    /// </summary>
    public partial class UCCClientDP : UserControl, IEventInfo
    {
        #region Variables

        /// <summary>
        /// Indicates DML operation
        /// </summary>
        private MasterOperation m_objOperation;
        
        /// <summary>
        /// Instance of client address BL class
        /// </summary>
        private CClientDP m_objCurrentClientDP;

        /// <summary>
        /// ClientDP data
        /// </summary>
        private DataTable m_dtClientDPDetails;

        /// <summary>
        /// Current client
        /// </summary>
        private CClient m_objCurrentClient;

        /// <summary>
        /// Message box title
        /// </summary>
        private string m_sMsgBoxTitle;

        /// <summary>
        /// Indicates if field value changes have been initiated from internal code
        /// </summary>
        private bool m_bInternalUpdation;

        /// <summary>
        /// Indicates if current DP value, set in DP text box, is valid?
        /// </summary>
        private bool m_bValidDPValueSet;
        /// <summary>
        /// Collection of DPs defined for the client
        /// </summary>
        private CClientDPCollection m_objClientDP;

        #endregion

        /// <summary>
        /// ClientDP class constructor
        /// </summary>
        /// <param name="p_vobjCurrentClient">Client context instance</param>

        #region Constructor
        public UCCClientDP(CClient p_vobjCurrentClient)
        {
            InitializeComponent();

            dgvClientDP.OverrideDefault = true;
            dgvClientDP.Styles.Normal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dgvClientDP.Styles.Alternate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            
            m_objCurrentClient = p_vobjCurrentClient;
        }
        #endregion

        #region Events

        /// <summary>
        /// Window load event handler. Initializes menu, controls & loads data
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region UCCClientDPInfo_Load
        private void UCCClientDPInfo_Load(object sender, EventArgs e)
        {
            pnlActionControls.Enabled = m_objCurrentClient.AllowModificationsToCurrentUser;
            m_sMsgBoxTitle = this.ParentForm.Text + " - DP";

            if (AppEnvironment.AppSettings.AppProduct == Product.Settlement)
                pnlExchange.Visible = false;

            PopulateLookUp();
            View_Click(this, EventArgs.Empty);
            EnableDisableClientDPField(false);
        }
        #endregion
        
        /// <summary>
        /// Grid Row/Column changed event handler. Populates current address details in controls
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region dgvDP_RowColChange
        private void dgvDP_RowColChange(object sender, EventArgs e)
        {
            EnableDisableClientDPField(true);

            if (dgvClientDP.Rows.Selected.Count != 1)
            {
                return;
            }

            switch (m_objOperation)
            {
                case MasterOperation.Modify:
                case MasterOperation.Delete:
                case MasterOperation.View:
                    PopulateFields();
                    break;
            }
        }
        #endregion

        /// <summary>
        /// Refresh button click event handler. Retrieves data from database again.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region View_Click
        private void View_Click(object sender, EventArgs e)
        {
            m_objOperation = MasterOperation.View;
            RefreshClientDPData();
        }
        #endregion
                
        /// <summary>
        /// New button click event handler. Clears fields and activates default control.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region New_Click
        private void New_Click(object sender, EventArgs e)
        {
            m_objOperation = MasterOperation.Add;
            ClearFields();

            EnableDisableClientDPField(true);

            if (AppEnvironment.AppSettings.AppProduct != Product.Settlement)
                cboExchange.Focus();
            else
                txtDP.Focus();
        }
        #endregion

        /// <summary>
        /// Delete button event handler. Proceeds to perform action in database after confirming same from user.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region Delete_Click
        private void Delete_Click(object sender, EventArgs e)
        {
            if (dgvClientDP.Rows.Count == dgvClientDP.Rows.Fixed)
            {
                MessageBox.Show("Select single record!!!", m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            if (dgvClientDP.Rows.Count > (dgvClientDP.Rows.Fixed + 1))
            {
            if (chkDefault.Checked)
            {
                MessageBox.Show("Default DP cannot be deleted!!!", m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            }

            if (MessageBox.Show("Are you sure you want to delete current client-DP?", m_sMsgBoxTitle,
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.No)
            {
                return;
            }

            DeleteClientDPData();
            View_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Save button event handler. Proceeds to perform changes (Add/Modify) in database. 
        /// Refreshes data after successful completion.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region Save_Click
        private void Save_Click(object sender, EventArgs e)
        {
            if (SaveClientDPData() == 0)
            {
                View_Click(this, EventArgs.Empty);
            }
        }
        #endregion

        /// <summary>
        /// Closes parent window where this user control is hosted
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region Exit_Click
        private void Exit_Click(object sender, EventArgs e)
        {
            this.ParentForm.Close();
        }
        #endregion

        /// <summary>
        /// Default checkbox check state changed event handler.
        /// Restrains user deselecting Default checked status.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region chkDefault_CheckedChanged
        private void chkDefault_CheckedChanged(object sender, EventArgs e)
        {
            if (m_bInternalUpdation)
                return;
            if (dgvClientDP.DataSource == null)
                return;

            if (m_objOperation == MasterOperation.Add)
                return;

            if (chkDefault.Checked == false)
            {
                MessageBox.Show("Default flag cannot be removed. Please mark default to other DP in same exchange to remove default flag of current DP.", 
                    m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                chkDefault.Checked = true;
                return;
            }
        }
        #endregion

        /// <summary>
        /// Add button click event handler. Redirects to New_Click event handler.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnAdd_Click
        private void btnAdd_Click(object sender, EventArgs e)
        {
            New_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Delete button click event handler. Redirects to Delete_Click event handler.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnDelete_Click
        private void btnDelete_Click(object sender, EventArgs e)
        {
            Delete_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Save button click event handler. Redirects to Save_Click event handler.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnSave_Click
        private void btnSave_Click(object sender, EventArgs e)
        {
            Save_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// DP text leave event handler.
        /// Checks if valid DP is set. If not & text is not empty, opens DP help window.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtDP_Leave
        private void txtDP_Leave(object sender, EventArgs e)
        {
            if (txtDP.ReadOnly)
                return;

            if (txtDP.Text.Trim().Length == 0)
                return;

            if (m_bValidDPValueSet == false)
                ShowDPHelp(txtDP.Text.Trim());
        }
        #endregion

        /// <summary>
        /// DP text box Key Up Event handler.
        /// Opens help window if F3 key is pressed.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtDP_KeyUp
        private void txtDP_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtDP.ReadOnly)
                return;

            if (e.KeyCode == Keys.F3)
                ShowDPHelp(txtDP.Text);
        }
        #endregion

        /// <summary>
        /// DP text box text change event handler.
        /// Sets m_bValidDPValueSet to false.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtDP_TextChanged
        private void txtDP_TextChanged(object sender, EventArgs e)
        {
            m_bValidDPValueSet = false;
        }
        #endregion
        
        /// <summary>
        /// Makercancel button click event handler.redirect to CancelMakerChanges function
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">Event argument</param>
        #region btnMakerCancel_Click
        private void btnMakerCancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure to cancel maker changes?", m_sMsgBoxTitle,
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.No)
            {
                return;
            }
            this.CancelMakerChanges();
        }
        #endregion

        #endregion

        #region Methods

        /// <summary>
        /// Opens DP help window populating records as per given DP code
        /// </summary>
        /// <param name="p_vsDPCode">Filter DP code</param>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region ShowDPHelp
        private long ShowDPHelp(string p_vsDPCode)
        {
            frmSearch l_objSearch = new frmSearch();
            l_objSearch.SearchTypeCurrent = frmSearch.SearchType.DP;
            l_objSearch.SearchText = p_vsDPCode;
            l_objSearch.SearchValueCurrent = frmSearch.SearchValue.DPCode;

            if (l_objSearch.ShowDialog() == DialogResult.OK)
            {
                txtDP.Text = l_objSearch.SelectedCode;
                txtDP.Tag = l_objSearch.SelectedUniqueValue;
                m_bValidDPValueSet = true;
            }
            else
            {
                txtDP.Text = string.Empty;
                txtDP.Tag = null;
            }

            return 0;
        }
        #endregion

        /// <summary>
        /// Formats data layout of grid. Sets visible columns, their titles.
        /// </summary>
        #region FormatGrid
        private void FormatGrid()
        {
            for (int l_iColCounter = dgvClientDP.Cols.Fixed; l_iColCounter < dgvClientDP.Cols.Count; l_iColCounter++)
                dgvClientDP.Cols[l_iColCounter].Visible = false;

            if (AppEnvironment.AppSettings.AppProduct != Product.Settlement)
            {
                if (dgvClientDP.Cols.Contains("n_ExNo"))
                {
                    dgvClientDP.Cols["n_ExNo"].Visible = true;
                    dgvClientDP.Cols["n_ExNo"].Caption = "Exch Code";

                    dgvClientDP.Cols["n_ExNo"].DataMap = CReferenceDataProvider.Instance.GetHashTable(CReferenceDataProvider.ReferenceType.EXCH, CReferenceDataProvider.ReferenceFields.ReferenceName, CReferenceDataProvider.ReferenceFields.ReferenceCode);
                }
            }

            if (dgvClientDP.Cols.Contains("n_DPNo"))
            {
                dgvClientDP.Cols["n_DPNo"].Visible = true;
                dgvClientDP.Cols["n_DPNo"].Caption = "DP";

                List<CDP> l_lstAllDPs = CDPCollection.Instance.AllDP;
                Hashtable l_hstDP = new Hashtable();
                for (int l_iDPCounter = 0; l_iDPCounter < l_lstAllDPs.Count; l_iDPCounter++)
                    l_hstDP.Add(l_lstAllDPs[l_iDPCounter].DPNo, l_lstAllDPs[l_iDPCounter].DPCode);
                dgvClientDP.Cols["n_DPNo"].DataMap = l_hstDP;
            }

            if (dgvClientDP.Cols.Contains("s_ClientId"))
            {
                dgvClientDP.Cols["s_ClientId"].Visible = true;
                dgvClientDP.Cols["s_ClientId"].Caption = "Client Id";
            }

            if (dgvClientDP.Cols.Contains("s_Default"))
            {
                dgvClientDP.Cols["s_Default"].Visible = true;
                dgvClientDP.Cols["s_Default"].Caption = "Default";

                Hashtable l_hstYesNo = new Hashtable();
                l_hstYesNo.Add("Y", "Yes");
                l_hstYesNo.Add("N", "No");
                dgvClientDP.Cols["s_Default"].DataMap = l_hstYesNo;
            }

            if (dgvClientDP.Cols.Contains("s_POA"))
            {
                dgvClientDP.Cols["s_POA"].Visible = true;
                dgvClientDP.Cols["s_POA"].Caption = "POA";

                Hashtable l_hstYesNo = new Hashtable();
                l_hstYesNo.Add("Y", "Yes");
                l_hstYesNo.Add("N", "No");
                dgvClientDP.Cols["s_POA"].DataMap = l_hstYesNo;
            }
        }
        #endregion

        /// <summary>
        /// Populates help (combo) controls with master values
        /// </summary>
        /// <returns></returns>
        #region PopulateLookUp
        private long PopulateLookUp()
        {
            cboExchange.ValueMember = "n_ExNo";
            cboExchange.DisplayMember = "s_ExCode";
            cboExchange.DataSource = CMastersDataProvider.Instance[Masters.Exchange];

            return 0;
        }
        #endregion

        /// <summary>
        /// Updates current changes to database using BL class
        /// </summary>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region SaveClientDPData
        private long SaveClientDPData()
        {
            if (
                (m_objOperation != MasterOperation.Add)
                &&
                (
                (dgvClientDP.DataSource == null)
                || (dgvClientDP.Rows.Count == dgvClientDP.Rows.Fixed)
                ))
            {
                MessageBox.Show("No data exists!!!", m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return 1;
            }

            string l_sErrorMessage = string.Empty;
            Control l_ctrlErrorControl = null;
            if (ValidateDPDetails(ref l_sErrorMessage, ref l_ctrlErrorControl) == false)
            {
                MessageBox.Show(l_sErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                if ((l_ctrlErrorControl != null) && (l_ctrlErrorControl.Enabled))
                    l_ctrlErrorControl.Focus();
                return 1;
            }

            ArrayList l_ClientDPData = new ArrayList();

            if (m_objOperation == MasterOperation.Add)
            {
                if (m_objCurrentClientDP == null)
                    m_objCurrentClientDP = new CClientDP(0);
                m_objCurrentClientDP.ClientDPNo = 0;
            }

            m_objCurrentClientDP.ClientId = txtClientId.Text.Trim();
            m_objCurrentClientDP.ClientNo = m_objCurrentClient.ClientNo;
            m_objCurrentClientDP.Default = (chkDefault.Checked ? "Y" : "N");
            m_objCurrentClientDP.DPNo = Convert.ToInt16(txtDP.Tag);
            if (AppEnvironment.AppSettings.AppProduct != Product.Settlement)
                m_objCurrentClientDP.ExNo = Convert.ToInt16(cboExchange.SelectedValue);
            m_objCurrentClientDP.POA = (chkPOA.Checked ? "Y" : "N");
            MethodExecResult l_objMethodExceResult = m_objCurrentClientDP.Update();

            if (l_objMethodExceResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, l_objMethodExceResult);

                if (m_objOperation == MasterOperation.Add)
                    MessageBox.Show("Unable to add DP details" + Environment.NewLine + l_objMethodExceResult.ErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK);
                else
                    MessageBox.Show("Unable to update DP details" + Environment.NewLine + l_objMethodExceResult.ErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK);

                return -1;
            }
            else
            {
                if (CSystemParam.Instance[CSystemParam.SysParam.MakerCheckerClient].SysParamValue == "Y")
                {
                    if (m_objOperation == MasterOperation.Add)
                        MessageBox.Show("Records Added Successfully for Authorisation", m_sMsgBoxTitle, MessageBoxButtons.OK);
                    else
                        MessageBox.Show("Records Updated Successfully for Authorisation", m_sMsgBoxTitle, MessageBoxButtons.OK);
                }
                else
                {
                    if (m_objOperation == MasterOperation.Add)
                        MessageBox.Show("Records Added Successfully", m_sMsgBoxTitle, MessageBoxButtons.OK);
                    else
                        MessageBox.Show("Records Updated Successfully", m_sMsgBoxTitle, MessageBoxButtons.OK);
                }

                m_objCurrentClient.IsPendingAuth = true;
                RefreshClientDPData();
                View_Click(this, EventArgs.Empty);

                return 0;
            }
        }
        #endregion

        /// <summary>
        /// Deletes current record from database using BL class
        /// </summary>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region DeleteClientDPData
        private long DeleteClientDPData()
        {
            MethodExecResult l_objMethodExceResult = m_objCurrentClientDP.Delete();

            if (l_objMethodExceResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, l_objMethodExceResult);
                MessageBox.Show("Client DP cannot be deleted", m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            else
            {
                MessageBox.Show("Records Deleted Successfully", m_sMsgBoxTitle, MessageBoxButtons.OK);
                m_objCurrentClient.IsPendingAuth = true;
                RefreshClientDPData();
                ClearFields();

            }
            return 0;
        }
        #endregion

        /// <summary>
        /// Retrieves/sets data from database again for current client
        /// </summary>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region RefreshClientDPData
        private long RefreshClientDPData()
        {
            Int32 l_nUserNo;
            l_nUserNo = m_objCurrentClient.IsCheckerView ? m_objCurrentClient.MakerUser : AppEnvironment.AppUser.UserNo;
            m_objClientDP = new CClientDPCollection(m_objCurrentClient.ClientNo, l_nUserNo);
            if ((m_objClientDP.LastMethodExecResult != null) && (m_objClientDP.LastMethodExecResult.ReturnCode != MethodExecResult.SuccessfulReturnCode))
            {
                MessageBox.Show(m_objClientDP.LastMethodExecResult.ErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }


            //////m_objCurrentClient.ClientDPs = new List<CClientDP>();
            //////foreach (DataRow _dr in m_objClientDP.DPDetailData.Rows)
            //////{
            //////    CClientDP l_ClientDP;
            //////    l_ClientDP = new CClientDP(Convert.ToInt32(_dr["n_ClientDPNo"]));
            //////    l_ClientDP.Initialize(_dr, m_objClientDP);
            //////    m_objCurrentClient.ClientDPs.Add(l_ClientDP);
            //////}

            m_objCurrentClient.ClientDPs = m_objClientDP.ClientDPs;
            m_dtClientDPDetails = m_objClientDP.DPDetailData;
            dgvClientDP.DataSource = m_dtClientDPDetails;
            FormatGrid();

            if ((m_dtClientDPDetails == null) || (m_dtClientDPDetails.Rows.Count == 0))
                btnAdd_Click(this, EventArgs.Empty);
            return 0;
        }
        #endregion

        /// <summary>
        /// Populates controls with current selected address record
        /// </summary>
        #region PopulateFields
        private void PopulateFields()
        {
            ClearFields();

            Row l_objSelectedRow = dgvClientDP.Rows.Selected[0];

            if (l_objSelectedRow == null)
            {
                return;
            }

            try
            {
                txtDP.Text = l_objSelectedRow["n_DPNo"].ToString().Trim();
            }
            catch
            {
                return;
            }

            try
            {
                m_bInternalUpdation = true;
                CurrencyManager l_cmCurrentMgr = (CurrencyManager)dgvClientDP.BindingContext[dgvClientDP.DataSource, dgvClientDP.DataMember];
                DataRowView l_drvCurrent = (DataRowView)l_cmCurrentMgr.Current;
                DataRow l_rwCurrent = l_drvCurrent.Row;
                m_objCurrentClientDP = new CClientDP(Convert.ToInt32(l_rwCurrent["n_ClientDPNo"]));
                MethodExecResult l_objMethodExecResult = m_objCurrentClientDP.Initialize(l_rwCurrent, m_objClientDP);

                if (l_objMethodExecResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
                {
                    MessageBox.Show(l_objMethodExecResult.ErrorMessage);
                    return;
                }

                if (AppEnvironment.AppSettings.AppProduct != Product.Settlement)
                    cboExchange.SelectedValue = m_objCurrentClientDP.ExNo;
                CDP l_objDP = CDPCollection.Instance[m_objCurrentClientDP.DPNo];
                if(l_objDP != null)
                    txtDP.Text = l_objDP.DPCode;
                txtDP.Tag = m_objCurrentClientDP.DPNo;
                txtClientId.Text = m_objCurrentClientDP.ClientId;
                chkDefault.Checked = (m_objCurrentClientDP.Default == "Y");
                chkPOA.Checked = (m_objCurrentClientDP.POA == "Y");
                m_bValidDPValueSet = true;

                if (m_objCurrentClientDP.AuthorizedStatus == "F")
                    btnMakerCancel.Visible = false;
                else
                    btnMakerCancel.Visible = true;

                if (m_objCurrentClient.IsPendingAuth)
                    ApplyMakerCheckerEffects(m_objCurrentClientDP, m_objCurrentClientDP.OriginalDP);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                MessageBox.Show(ex.Message, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            finally
            {
                m_bInternalUpdation = false;
            }
        }
        #endregion

        /// <summary>
        /// Clears all control values
        /// </summary>
        #region ClearFields
        private void ClearFields()
        {
            m_bInternalUpdation = true;
            try
            {
                cboExchange.SelectedIndex = -1;
                txtDP.Text = string.Empty;
                txtDP.Tag = null;
                txtClientId.Text = string.Empty;
                chkDefault.Checked = false;
                chkPOA.Checked = false;
            }
            finally
            {
                m_bInternalUpdation = false;
            }

        }
        #endregion

        /// <summary>
        /// Enables/disables all controls
        /// </summary>
        /// <param name="p_vsFlag">Enable/disable flag</param>
        #region EnableDisableClientDPField
        private void EnableDisableClientDPField(bool p_vsFlag)
        {
            switch(m_objOperation)
            {
                case MasterOperation.Add:
                    cboExchange.Enabled = true;
                    break;
                default:
                    cboExchange.Enabled = false;
                    break;
            }
        }
        #endregion
        
        /// <summary>
        /// Validates current DP record
        /// </summary>
        /// <param name="ErrorMessage">Error message if validation fails</param>
        /// <param name="ErrorControl">Error control where validation failed</param>
        /// <returns>True if all validations passed, False otherwise</returns>
        #region ValidateDPDetails
        private bool ValidateDPDetails(ref string ErrorMessage, ref Control ErrorControl)
        {
            //Mandatory Fields
            if (AppEnvironment.AppSettings.AppProduct != Product.Settlement)
            {
                if (cboExchange.SelectedValue == null)
                {
                    ErrorControl = cboExchange;
                    ErrorMessage = "Exchange cannot be blank";
                    return false;
                }
            }
            
            if (txtDP.Enabled && txtDP.Text.Trim().Length == 0)
            {
                ErrorControl = txtDP;
                ErrorMessage = "DP cannot be blank";
                return false;
            }

            if (txtClientId.Enabled)
            {
                if (txtClientId.Text.Trim().Length == 0)
                {
                    ErrorControl = txtClientId;
                    ErrorMessage = "Client Id cannot be blank";
                    return false;
                }

                CDP l_objDP = CDPCollection.Instance[Convert.ToInt32(txtDP.Tag)];
                if (l_objDP == null)
                {
                    ErrorControl = txtClientId;
                    ErrorMessage = "Invalid DP or DP details not found";
                    return false;
                }

                if(
                    (l_objDP.Depository == CUCCConstants.Instance.DEPOSITORY_CDSL)
                    && (txtClientId.Text.Trim().Length != 16)
                    )
                {
                    ErrorControl = txtClientId;
                    ErrorMessage = "Client Id must be of 16 characters for CDSL";
                    return false;
                }

                if (
                    (l_objDP.Depository == CUCCConstants.Instance.DEPOSITORY_NSDL)
                    && (txtClientId.Text.Trim().Length != 8)
                    )
                {
                    ErrorControl = txtClientId;
                    ErrorMessage = "Client Id must be of 8 characters for NSDL";
                    return false;
                }
            }
            
            return true;
        }
        #endregion

        /// <summary>
        /// This method compares current DP object values with target DP object 
        /// and sets Maker fields accordingly
        /// </summary>
        /// <param name="m_objCurrent">DP object whose values have been populated to fields</param>
        /// <param name="m_objCompareTo">DP object containing original values</param>
        #region ApplyMakerCheckerEffects
        private void ApplyMakerCheckerEffects(CClientDP m_objCurrent, CClientDP m_objCompareTo)
        {
            CUCCCommon l_objCommon = CUCCCommon.Instance;
            if (m_objCompareTo == null)
                m_objCompareTo = m_objCurrent;
            if (m_objCurrent.ExNo == m_objCompareTo.ExNo)
                l_objCommon.ResetMakerChangedStyle(cboExchange, lblExchange, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(cboExchange, lblExchange, ttMain, CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.EXCH, m_objCompareTo.ExNo.ToString()));

            if (m_objCurrent.DPNo == m_objCompareTo.DPNo)
                l_objCommon.ResetMakerChangedStyle(txtDP, lblDP, ttMain);
            else
            {
                CDP l_objDP = CDPCollection.Instance[m_objCompareTo.DPNo];
                l_objCommon.SetMakerChangedStyle(txtDP, lblDP, ttMain, l_objDP.DPCode);
            }
                

            if (m_objCurrent.ClientId == m_objCompareTo.ClientId)
                l_objCommon.ResetMakerChangedStyle(txtClientId, lblClientId, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtClientId, lblClientId, ttMain, m_objCompareTo.ClientId);

            if (m_objCurrent.Default == m_objCompareTo.Default)
                l_objCommon.ResetMakerChangedStyle(chkDefault, lblDefault, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(chkDefault, lblDefault, ttMain, m_objCompareTo.Default);

            if (m_objCurrent.POA == m_objCompareTo.POA)
                l_objCommon.ResetMakerChangedStyle(chkPOA,lblPOA, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(chkPOA, lblPOA, ttMain, m_objCompareTo.POA);
            
        }
        #endregion

        #endregion

        #region IEventInfo Members

        #region Not applicable

        /// <summary>
        /// Not implemented
        /// </summary>
        void IEventInfo.Filter() {}
        /// <summary>
        /// Not implemented
        /// </summary>
        void IEventInfo.ModifyRecord() { }

        #endregion

        /// <summary>
        /// Redirects to View_Click
        /// </summary>
        #region RefreshData
        void IEventInfo.RefreshData()
        {
            View_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Redirects to New_Click
        /// </summary>
        #region AddRecord
        void IEventInfo.AddRecord()
        {
            New_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Redirects to Delete_Click
        /// </summary>
        #region DeleteRecord
        void IEventInfo.DeleteRecord()
        {
            Delete_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Redirects to Save_Click
        /// </summary>
        #region SaveData
        void IEventInfo.SaveData()
        {
            Save_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Redirects to Exit_Click
        /// </summary>
        #region Exit
        void IEventInfo.Exit()
        {
            Exit_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Cancel the maker changes for the selected record
        /// </summary>
        #region CancelMakerChanges
        private void CancelMakerChanges()
        {
            MakerCancel lbjMkrCancel = new MakerCancel();
            ArrayList l_lstParamValue = new ArrayList();
            MethodExecResult l_objMethodExceResult;

            l_lstParamValue.Add(m_objCurrentClientDP.ClientNo);
            l_lstParamValue.Add(4);

            l_objMethodExceResult = lbjMkrCancel.CancelMakerEffect(l_lstParamValue);

            if (l_objMethodExceResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, l_objMethodExceResult);
                MessageBox.Show("Unable to cancel the maker changes" + Environment.NewLine + l_objMethodExceResult.ErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                View_Click(this, EventArgs.Empty);
                MessageBox.Show("Maker changes cancel successfully", m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        #endregion 
   
        #endregion

    }
}
