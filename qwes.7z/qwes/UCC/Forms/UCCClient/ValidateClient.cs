﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Collections;

using C1.Win.C1FlexGrid;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;
using FTIL.Match.Common.Utils;
using FTIL.Match.Common.Constants;
using UCC.Class;
using System.Text.RegularExpressions;
using UCC.Class.Master;

namespace UCC.Forms.UCCClient
{
    /// <summary>
    /// Client address screen user control
    /// </summary>
    public partial class ValidateClient : UserControl, IEventInfo
    {
        #region Variables
       
        /// <summary>
        /// ClientDP data
        /// </summary>
        private DataTable m_dtClientDPDetails;

        /// <summary>
        /// Current client
        /// </summary>
        private CClient m_objCurrentClient;

        /// <summary>
        /// Message box title
        /// </summary>
        private string m_sMsgBoxTitle;

        /// <summary>
        /// Indicates if field value changes have been initiated from internal code
        /// </summary>
        private bool m_bInternalUpdation;

        /// <summary>
        /// Indicates if current DP value, set in DP text box, is valid?
        /// </summary>
        private bool m_bValidClientValueSet;

        /// <summary>
        /// frmUCCClientInfo instance
        /// </summary>
        frmUCCClientInfo m_objUCCClientInfo;

        #endregion

        /// <summary>
        /// ClientDP class constructor
        /// </summary>
        /// <param name="p_vobjCurrentClient">Client context instance</param>
        #region Constructor
        public ValidateClient(CClient p_vobjCurrentClient, frmUCCClientInfo p_vobjUCCClientInfo)
        {
            InitializeComponent();

            m_objUCCClientInfo = p_vobjUCCClientInfo;
            dgvValidate.OverrideDefault = true;
            dgvValidate.Styles.Normal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dgvValidate.Styles.Alternate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            
            m_objCurrentClient = p_vobjCurrentClient;
        }
        #endregion

        #region Events

        /// <summary>
        /// Window load event handler. Initializes menu, controls & loads data
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region UCCClientDPInfo_Load
        private void UCCClientDPInfo_Load(object sender, EventArgs e)
        {
            m_sMsgBoxTitle = this.ParentForm.Text + " - Validate";

            PopulateLookUp();
        }
        #endregion
        
        /// <summary>
        /// Closes parent window where this user control is hosted
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region Exit_Click
        private void Exit_Click(object sender, EventArgs e)
        {
            this.ParentForm.Close();
        }
        #endregion

        /// <summary>
        /// Validate button click event handler.
        /// Validates client UCC details for selected exchange
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        #region btnValidate_Click
        private void btnValidate_Click(object sender, EventArgs e)
        {
            DataTable l_dt;
            l_dt = m_objCurrentClient.Validate();
            dgvValidate.DataSource = l_dt;
            FormatGrid();
            //ValidateUCCDetails();
        }
        #endregion
        
        /// <summary>
        /// Client code text box text change event handler.
        /// Sets m_bValidClientValueSet to false.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtClientCode_TextChanged
        private void txtClientCode_TextChanged(object sender, EventArgs e)
        {
            m_bValidClientValueSet = false;
        }
        #endregion

        /// <summary>
        /// Client Code text box Key Up Event handler.
        /// Opens help window if F3 key is pressed.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtClientCode_KeyUp
        private void txtClientCode_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtClientCode.ReadOnly)
                return;

            if (e.KeyCode == Keys.F3)
                ShowClientHelp(txtClientCode.Text);
        }
        #endregion

        /// <summary>
        /// Client code text box leave event handler.
        /// If valid client set flag is False, opens client help window populating records as per client code textbox text.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtClientCode_Leave
        private void txtClientCode_Leave(object sender, EventArgs e)
        {
            if (txtClientCode.ReadOnly || (txtClientCode.Enabled == false))
                return;

            if (txtClientCode.Text.Trim().Length == 0)
                return;

            if (m_bValidClientValueSet == false)
                ShowClientHelp(txtClientCode.Text.Trim());
        }
        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        #region dgvValidate_DoubleClick
        private void dgvValidate_DoubleClick(object sender, EventArgs e)
        {
            HitTestInfo l_htiInfo = dgvValidate.HitTest(dgvValidate.PointToClient(Cursor.Position));

            if (
                (l_htiInfo.Column < dgvValidate.Cols.Fixed)
                || (l_htiInfo.Column > dgvValidate.Cols.Count)
                || (l_htiInfo.Row < dgvValidate.Rows.Fixed)
                || (l_htiInfo.Row > dgvValidate.Rows.Count)
               )
            {
                return;
            }

            if (dgvValidate.Rows.Selected.Count != 1)
            {
                //MessageBox.Show("Select single record!!!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            Row l_objRow = null;
            l_objRow = dgvValidate.Rows.Selected[0];

            if (l_objRow == null)
                return;

            try
            {
                string l_sTabNo = l_objRow["n_UITabNo"].ToString();
                frmUCCClientInfo.UITab l_objUITab = frmUCCClientInfo.UITab.MainInfo;

                switch (l_sTabNo)
                {
                    case "1":
                        l_objUITab = frmUCCClientInfo.UITab.MainInfo;
                        break;
                    case "2":
                        l_objUITab = frmUCCClientInfo.UITab.ExchangeMapping;
                        break;
                    case "3":
                        l_objUITab = frmUCCClientInfo.UITab.Address;
                        break;
                    case "4":
                        l_objUITab = frmUCCClientInfo.UITab.DP;
                        break;
                    case "5":
                        l_objUITab = frmUCCClientInfo.UITab.Bank;
                        break;

                    default:
                        return;
                        break;
                }

                m_objUCCClientInfo.SelectUITab(l_objUITab);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
            }
        }
        #endregion

        /// <summary>
        /// Export button click event handler.
        /// Exports grid data to local file.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event Arguments</param>
        #region btnExport_Click
        private void btnExport_Click(object sender, EventArgs e)
        {
            if ((dgvValidate.DataSource == null) || (dgvValidate.Rows.Count == dgvValidate.Rows.Fixed))
            {
                MessageBox.Show("No data found!!!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            SaveFileDialog l_objFile = new SaveFileDialog();
            l_objFile.CheckFileExists = false;
            l_objFile.CheckPathExists = true;
            l_objFile.Filter = "Excel (xlsx)|*.xlsx|Excel (xls)|*.xls";
            l_objFile.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory;
            l_objFile.DefaultExt = "xls";

            string l_sFilePath = string.Empty;
            if (l_objFile.ShowDialog() == DialogResult.OK)
            {
                l_sFilePath = l_objFile.FileName;
            }

            try
            {
                dgvValidate.SaveExcel(l_sFilePath, FileFlags.IncludeFixedCells | FileFlags.VisibleOnly);
                MessageBox.Show("Exported Successfully", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "Error exporting data to excel file", ex);
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
        }
        #endregion

        #endregion

        #region Methods

        /// <summary>
        /// Formats data layout of grid. Sets visible columns, their titles.
        /// </summary>
        #region FormatGrid
        private void FormatGrid()
        {
            for (int l_iColCounter = dgvValidate.Cols.Fixed; l_iColCounter < dgvValidate.Cols.Count; l_iColCounter++)
                dgvValidate.Cols[l_iColCounter].Visible = false;

            if (dgvValidate.Cols.Contains("s_ExchangeCode"))
            {
                dgvValidate.Cols["s_ExchangeCode"].Visible = true;
                dgvValidate.Cols["s_ExchangeCode"].Width = 80;
                dgvValidate.Cols["s_ExchangeCode"].Caption = "Ex Code";
            }

            if (dgvValidate.Cols.Contains("s_EntityCode"))
            {
                dgvValidate.Cols["s_EntityCode"].Visible = true;
                dgvValidate.Cols["s_EntityCode"].Width = 80;
                dgvValidate.Cols["s_EntityCode"].Caption = "Client Code";
            }

            if (dgvValidate.Cols.Contains("s_EntityName"))
            {
                dgvValidate.Cols["s_EntityName"].Visible = true;
                dgvValidate.Cols["s_EntityName"].Width = 200;
                dgvValidate.Cols["s_EntityName"].Caption = "Client Name";
            }

            
            if (dgvValidate.Cols.Contains("s_ValidationMsg"))
            {
                dgvValidate.Cols["s_ValidationMsg"].Visible = true;
                dgvValidate.Cols["s_ValidationMsg"].Width = 550;
                dgvValidate.Cols["s_ValidationMsg"].Caption = "Validation Message";
            }
        }
        #endregion

        /// <summary>
        /// Populates help (combo) controls with master values
        /// </summary>
        /// <returns></returns>
        #region PopulateLookUp
        private long PopulateLookUp()
        {
            cboExchange.DisplayMember = "s_ExCode";
            cboExchange.ValueMember = "n_ExNo";
            DataTable l_dtEx = CMastersDataProvider.Instance[Masters.Exchange].Copy();
            DataRow l_objAllRow = l_dtEx.NewRow();
            l_objAllRow["s_ExCode"] = "All";
            l_objAllRow["n_ExNo"] = "0";
            l_dtEx.Rows.InsertAt(l_objAllRow, 0);

            cboExchange.DataSource = l_dtEx;

            return 0;
        }
        #endregion

        /// <summary>
        /// Validates clients for selected exchanges
        /// </summary>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region ValidateUCCDetails
        private long ValidateUCCDetails()
        {
            DataTable l_ViewData = new DataTable();

            CValidateClient l_objValidateClient = new CValidateClient();
            int l_nExNo = 0;
            if (cboExchange.SelectedValue != null)
                l_nExNo = Convert.ToInt32(cboExchange.SelectedValue.ToString());

            DataSet l_dsResultData = null;
            this.Cursor = Cursors.WaitCursor;

            try
            {
                MethodExecResult l_objMethodExecResult = l_objValidateClient.ValidateClientUCC(l_nExNo, m_objCurrentClient.ClientCode, ref l_dsResultData);
                if (l_objMethodExecResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
                {
                    MessageBox.Show(l_objMethodExecResult.ErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return 1;
                }

                if ((l_dsResultData == null) || (l_dsResultData.Tables.Count == 0))
                {
                    MessageBox.Show("No data found!!!", m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return 2;
                }

                dgvValidate.DataSource = l_dsResultData.Tables[0];
                FormatGrid();
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }

            return 0;
        }
        #endregion

        /// <summary>
        /// Clears all control values
        /// </summary>
        #region ClearFields
        private void ClearFields()
        {
            m_bInternalUpdation = true;
            try
            {
                cboExchange.SelectedIndex = -1;
                dgvValidate.DataSource = null;
                dgvValidate.Rows.Count = dgvValidate.Rows.Fixed;
            }
            finally
            {
                m_bInternalUpdation = false;
            }

        }
        #endregion
        
        /// <summary>
        /// Opens client help window populating records as per given client code
        /// </summary>
        /// <param name="p_vsClientCode">Filter client code</param>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region ShowClientHelp
        private long ShowClientHelp(string p_vsClientCode)
        {
            frmSearch l_objSearch = new frmSearch();
            l_objSearch.SearchTypeCurrent = frmSearch.SearchType.Client;
            l_objSearch.SearchValueCurrent = frmSearch.SearchValue.ClientCode;
            l_objSearch.SearchText = txtClientCode.Text;

            if (l_objSearch.ShowDialog() == DialogResult.OK)
            {
                m_bValidClientValueSet = true;
                txtClientCode.Text = l_objSearch.SelectedCode;
            }
            else
            {
                txtClientCode.Text = string.Empty;
            }

            return 0;
        }
        #endregion

        #endregion

        #region IEventInfo Members

        #region Not applicable

        /// <summary>
        /// Not implemented
        /// </summary>
        void IEventInfo.Filter() {}
        /// <summary>
        /// Not implemented
        /// </summary>
        void IEventInfo.ModifyRecord() { }

        /// <summary>
        /// Redirects to View_Click
        /// </summary>
        #region RefreshData
        void IEventInfo.RefreshData()
        {
        }
        #endregion

        /// <summary>
        /// Redirects to New_Click
        /// </summary>
        #region AddRecord
        void IEventInfo.AddRecord()
        {
        }
        #endregion

        /// <summary>
        /// Redirects to Delete_Click
        /// </summary>
        #region DeleteRecord
        void IEventInfo.DeleteRecord()
        {
        }
        #endregion

        /// <summary>
        /// Redirects to Save_Click
        /// </summary>
        #region SaveData
        void IEventInfo.SaveData()
        {
        }
        #endregion

        #endregion

        /// <summary>
        /// Redirects to Exit_Click
        /// </summary>
        #region Exit
        void IEventInfo.Exit()
        {
            Exit_Click(this, EventArgs.Empty);
        }
        #endregion
        
        #endregion
        
    }
}
