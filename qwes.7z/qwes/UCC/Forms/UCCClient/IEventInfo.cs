﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UCC.Forms.UCCClient
{
    /// <summary>
    /// Interface designing common events
    /// </summary>
    interface IEventInfo
    {
        /// <summary>
        /// Filter parameter 
        /// </summary>
        void Filter();

        /// <summary>
        /// Refresh data
        /// </summary>
        void RefreshData();

        /// <summary>
        /// Add record
        /// </summary>
        void AddRecord();

        /// <summary>
        /// Modify record
        /// </summary>
        void ModifyRecord();

        /// <summary>
        /// Delete record
        /// </summary>
        void DeleteRecord();

        /// <summary>
        /// Save data
        /// </summary>
        void SaveData();

        /// <summary>
        /// Exit window
        /// </summary>
        void Exit();
    }
}
