﻿namespace UCC.Forms.UCCClient
{
    partial class ValidateClient
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ValidateClient));
            this.ftDPGridPanel = new MatchCommon.CustomControls.FTPanel();
            this.dgvValidate = new MatchCommon.CustomControls.FTDataGrid();
            this.pnlOtherControls = new MatchCommon.CustomControls.FTPanel();
            this.txtClientCode = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel30 = new MatchCommon.CustomControls.FTLabel();
            this.btnValidate = new MatchCommon.CustomControls.FTButton();
            this.lblExchange = new MatchCommon.CustomControls.FTLabel();
            this.cboExchange = new MatchCommon.CustomControls.FTComboBox();
            this.ftPanel1 = new MatchCommon.CustomControls.FTPanel();
            this.btnExport = new MatchCommon.CustomControls.FTButton();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.ftDPGridPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvValidate)).BeginInit();
            this.pnlOtherControls.SuspendLayout();
            this.ftPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ftDPGridPanel
            // 
            this.ftDPGridPanel.Controls.Add(this.dgvValidate);
            this.ftDPGridPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ftDPGridPanel.Location = new System.Drawing.Point(0, 43);
            this.ftDPGridPanel.Name = "ftDPGridPanel";
            this.ftDPGridPanel.Size = new System.Drawing.Size(856, 369);
            this.ftDPGridPanel.TabIndex = 6;
            // 
            // dgvValidate
            // 
            this.dgvValidate.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
            this.dgvValidate.AllowEditing = false;
            this.dgvValidate.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
            this.dgvValidate.BackColor = System.Drawing.Color.Transparent;
            this.dgvValidate.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.dgvValidate.ColumnInfo = "10,1,0,0,0,85,Columns:0{Width:30;}\t";
            this.dgvValidate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvValidate.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
            this.dgvValidate.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dgvValidate.ForeColor = System.Drawing.Color.Black;
            this.dgvValidate.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
            this.dgvValidate.Location = new System.Drawing.Point(0, 0);
            this.dgvValidate.Name = "dgvValidate";
            this.dgvValidate.OverrideDefault = false;
            this.dgvValidate.Rows.Count = 1;
            this.dgvValidate.Rows.DefaultSize = 17;
            this.dgvValidate.Rows.MinSize = 25;
            this.dgvValidate.RowsFilter.AddFilterRow = false;
            this.dgvValidate.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.ListBox;
            this.dgvValidate.Size = new System.Drawing.Size(856, 369);
            this.dgvValidate.StyleInfo = "";
            this.dgvValidate.TabIndex = 0;
            this.dgvValidate.DoubleClick += new System.EventHandler(this.dgvValidate_DoubleClick);
            // 
            // pnlOtherControls
            // 
            this.pnlOtherControls.Controls.Add(this.txtClientCode);
            this.pnlOtherControls.Controls.Add(this.ftLabel30);
            this.pnlOtherControls.Controls.Add(this.btnValidate);
            this.pnlOtherControls.Controls.Add(this.lblExchange);
            this.pnlOtherControls.Controls.Add(this.cboExchange);
            this.pnlOtherControls.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlOtherControls.Location = new System.Drawing.Point(0, 0);
            this.pnlOtherControls.Name = "pnlOtherControls";
            this.pnlOtherControls.Size = new System.Drawing.Size(856, 43);
            this.pnlOtherControls.TabIndex = 0;
            // 
            // txtClientCode
            // 
            this.txtClientCode.AllowAlpha = true;
            this.txtClientCode.AllowDot = true;
            this.txtClientCode.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtClientCode.AllowedCustomCharacters")));
            this.txtClientCode.AllowNonASCII = false;
            this.txtClientCode.AllowNumeric = true;
            this.txtClientCode.AllowSpace = true;
            this.txtClientCode.AllowSpecialChars = true;
            this.txtClientCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtClientCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtClientCode.FocusColor = System.Drawing.Color.LightYellow;
            this.txtClientCode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtClientCode.ForeColor = System.Drawing.Color.Black;
            this.txtClientCode.IsEmailID = true;
            this.txtClientCode.IsEmailIdValid = false;
            this.txtClientCode.Location = new System.Drawing.Point(312, 12);
            this.txtClientCode.Name = "txtClientCode";
            this.txtClientCode.Size = new System.Drawing.Size(140, 20);
            this.txtClientCode.TabIndex = 3;
            this.txtClientCode.Visible = false;
            this.txtClientCode.TextChanged += new System.EventHandler(this.txtClientCode_TextChanged);
            this.txtClientCode.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtClientCode_KeyUp);
            this.txtClientCode.Leave += new System.EventHandler(this.txtClientCode_Leave);
            // 
            // ftLabel30
            // 
            this.ftLabel30.AllowForeColorChange = false;
            this.ftLabel30.AutoSize = true;
            this.ftLabel30.Font = new System.Drawing.Font("Tahoma", 8F);
            this.ftLabel30.ForeColor = System.Drawing.Color.Black;
            this.ftLabel30.Location = new System.Drawing.Point(248, 15);
            this.ftLabel30.Name = "ftLabel30";
            this.ftLabel30.OverrideDefault = false;
            this.ftLabel30.Size = new System.Drawing.Size(62, 13);
            this.ftLabel30.TabIndex = 2;
            this.ftLabel30.Text = "Client Code";
            this.ftLabel30.Visible = false;
            // 
            // btnValidate
            // 
            this.btnValidate.BackColor = System.Drawing.Color.Transparent;
            this.btnValidate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnValidate.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnValidate.Image = ((System.Drawing.Image)(resources.GetObject("btnValidate.Image")));
            this.btnValidate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnValidate.Location = new System.Drawing.Point(796, 11);
            this.btnValidate.Name = "btnValidate";
            this.btnValidate.Size = new System.Drawing.Size(80, 23);
            this.btnValidate.TabIndex = 4;
            this.btnValidate.Text = "&Validate";
            this.btnValidate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnValidate.UseVisualStyleBackColor = false;
            this.btnValidate.Click += new System.EventHandler(this.btnValidate_Click);
            // 
            // lblExchange
            // 
            this.lblExchange.AllowForeColorChange = false;
            this.lblExchange.AutoSize = true;
            this.lblExchange.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblExchange.ForeColor = System.Drawing.Color.Black;
            this.lblExchange.Location = new System.Drawing.Point(22, 14);
            this.lblExchange.Name = "lblExchange";
            this.lblExchange.OverrideDefault = false;
            this.lblExchange.Size = new System.Drawing.Size(54, 13);
            this.lblExchange.TabIndex = 0;
            this.lblExchange.Text = "Exchange";
            // 
            // cboExchange
            // 
            this.cboExchange.BackColor = System.Drawing.Color.White;
            this.cboExchange.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboExchange.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboExchange.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboExchange.ForeColor = System.Drawing.Color.Black;
            this.cboExchange.FormattingEnabled = true;
            this.cboExchange.Location = new System.Drawing.Point(89, 11);
            this.cboExchange.MaxLength = 25;
            this.cboExchange.Name = "cboExchange";
            this.cboExchange.ReadOnly = false;
            this.cboExchange.Size = new System.Drawing.Size(139, 21);
            this.cboExchange.TabIndex = 1;
            // 
            // ftPanel1
            // 
            this.ftPanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ftPanel1.Controls.Add(this.btnExport);
            this.ftPanel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.ftPanel1.Location = new System.Drawing.Point(0, 412);
            this.ftPanel1.Name = "ftPanel1";
            this.ftPanel1.Size = new System.Drawing.Size(856, 34);
            this.ftPanel1.TabIndex = 0;
            // 
            // btnExport
            // 
            this.btnExport.BackColor = System.Drawing.Color.Transparent;
            this.btnExport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExport.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnExport.Image = ((System.Drawing.Image)(resources.GetObject("btnExport.Image")));
            this.btnExport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExport.Location = new System.Drawing.Point(800, 6);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(75, 23);
            this.btnExport.TabIndex = 0;
            this.btnExport.Text = "&Export";
            this.btnExport.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExport.UseVisualStyleBackColor = false;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // ValidateClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.ftDPGridPanel);
            this.Controls.Add(this.pnlOtherControls);
            this.Controls.Add(this.ftPanel1);
            this.Name = "ValidateClient";
            this.Size = new System.Drawing.Size(856, 446);
            this.Load += new System.EventHandler(this.UCCClientDPInfo_Load);
            this.ftDPGridPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvValidate)).EndInit();
            this.pnlOtherControls.ResumeLayout(false);
            this.pnlOtherControls.PerformLayout();
            this.ftPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MatchCommon.CustomControls.FTPanel ftDPGridPanel;
        private MatchCommon.CustomControls.FTDataGrid dgvValidate;
        private MatchCommon.CustomControls.FTLabel lblExchange;
        private MatchCommon.CustomControls.FTComboBox cboExchange;
        private MatchCommon.CustomControls.FTPanel ftPanel1;
        private MatchCommon.CustomControls.FTButton btnExport;
        private System.Windows.Forms.ToolTip toolTip1;
        private MatchCommon.CustomControls.FTPanel pnlOtherControls;
        private MatchCommon.CustomControls.FTButton btnValidate;
        private MatchCommon.CustomControls.FTTextBox txtClientCode;
        private MatchCommon.CustomControls.FTLabel ftLabel30;
    }
}
