﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Collections;

using C1.Win.C1FlexGrid;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;
using FTIL.Match.Common.Utils;
using FTIL.Match.Common.Constants;
using UCC.Class;
using System.Text.RegularExpressions;
using UCC.Class.Master;

namespace UCC.Forms.UCCClient
{
    /// <summary>
    /// Client address screen user control
    /// </summary>
    public partial class UCCClientAddressInfo : UserControl, IEventInfo
    {
        #region Variables

        /// <summary>
        /// Indicates DML operation
        /// </summary>
        private MasterOperation m_objOperation;
        
        /// <summary>
        /// Instance of client info BL class
        /// </summary>
        private CUCCClientInfoClientMaster m_objCClientMaster;

        /// <summary>
        /// Instance of client address BL class
        /// </summary>
        private CUCCClientAddress m_objCUCCClientAddress;

        /// <summary>
        /// Address data
        /// </summary>
        private DataTable m_dtClientAddressDetails;

        /// <summary>
        /// Unique AddressNo of current record
        /// </summary>
        private int m_iAddressNo;

        /// <summary>
        /// Current record/selected city-state code
        /// </summary>
        private int m_iCityStateCode;

        /// <summary>
        /// Current client
        /// </summary>
        private CClient m_objCurrentClient;

        /// <summary>
        /// Message box title
        /// </summary>
        private string m_sMsgBoxTitle;

        /// <summary>
        /// Indicates if field value changes have been initiated from internal code
        /// </summary>
        private bool m_bInternalUpdation;

        /// <summary>
        /// Collection of Address details for a selected client
        /// </summary>
        private CClientAddressCollection m_objClientAddressCollection;

        #endregion

        /// <summary>
        /// Address class constructor
        /// </summary>
        /// <param name="p_vobjCurrentClient">Client context instance</param>
        #region Constructor
        public UCCClientAddressInfo(CClient p_vobjCurrentClient)
        {
            InitializeComponent();

            dgvAddress.OverrideDefault = true;
            dgvAddress.Styles.Normal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dgvAddress.Styles.Alternate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            
            m_objCurrentClient = p_vobjCurrentClient;

            m_objCClientMaster = new CUCCClientInfoClientMaster();
            //m_objCUCCClientAddress = new CUCCClientAddress(0);
        }
        #endregion

        #region Events

        /// <summary>
        /// Window load event handler. Initializes menu, controls & loads data
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region UCCClientAddressInfo_Load
        private void UCCClientAddressInfo_Load(object sender, EventArgs e)
        {
            pnlActionControls.Enabled = m_objCurrentClient.AllowModificationsToCurrentUser;

            ttMain.SetToolTip(txtMobileNo1, "Mobile 1");
            ttMain.SetToolTip(txtMobileNo2, "Mobile 2");

            m_sMsgBoxTitle = this.ParentForm.Text + " - Address";

            SetProductwiseSettings();
            PopulateLookUp();
            View_Click(this, EventArgs.Empty);
            EnableDisableClientAddressField(false);

            cboCategory_SelectionChangeCommitted(this, EventArgs.Empty);
            cboState_SelectedIndexChanged(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Opens City help in response to user pressing F3 key (not used)
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtCityName_KeyUp
        private void txtCityName_KeyUp(object sender, KeyEventArgs e)
        {
            //if (txtCityName.ReadOnly)
            //    return;

            //if (e.KeyCode == Keys.F3)
            //    ShowCityHelp(txtCityName.Text);
            //else if (e.KeyCode == Keys.Escape)
            //    Exit_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Grid Row/Column changed event handler. Populates current address details in controls
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region dgvAddress_RowColChange
        private void dgvAddress_RowColChange(object sender, EventArgs e)
        {
            if (dgvAddress.Rows.Selected.Count != 1)
            {
                return;
            }

            switch (m_objOperation)
            {
                case MasterOperation.Modify:
                case MasterOperation.Delete:
                case MasterOperation.View:
                    PopulateFields();
                    break;
            }
        }
        #endregion

        /// <summary>
        /// Refresh button click event handler. Retrieves data from database again.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region View_Click
        private void View_Click(object sender, EventArgs e)
        {
            m_objOperation = MasterOperation.View;
            RefreshClientAddressData();
        }
        #endregion
                
        /// <summary>
        /// New button click event handler. Clears fields and activates default control.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region New_Click
        private void New_Click(object sender, EventArgs e)
        {
            m_objOperation = MasterOperation.Add;
            ClearFields();
            cboCategory.Focus();

            EnableDisableClientAddressField(true);
        }
        #endregion

        /// <summary>
        /// Delete button event handler. Proceeds to perform action in database after confirming same from user.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region Delete_Click
        private void Delete_Click(object sender, EventArgs e)
        {
            if (dgvAddress.Rows.Count == dgvAddress.Rows.Fixed)
            {
                MessageBox.Show("Select single record!!!", m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            if (chkDefault.Checked)
            {
                MessageBox.Show("Default address cannot be deleted!!!", m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            if (MessageBox.Show("Are you sure you want to delete current address?", m_sMsgBoxTitle,
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.No)
            {
                return;
            }

            DeleteClientAddressData();
            View_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Save button event handler. Proceeds to perform changes (Add/Modify) in database. 
        /// Refreshes data after successful completion.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region Save_Click
        private void Save_Click(object sender, EventArgs e)
        {
            if (SaveClientAddressData() == 0)
            {
                View_Click(this, EventArgs.Empty);
            }
        }
        #endregion

        /// <summary>
        /// Closes parent window where this user control is hosted
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region Exit_Click
        private void Exit_Click(object sender, EventArgs e)
        {
            this.ParentForm.Close();
        }
        #endregion

        /// <summary>
        /// Default checkbox check state changed event handler.
        /// Restrains user deselecting Default checked status.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region chkDefault_CheckedChanged
        private void chkDefault_CheckedChanged(object sender, EventArgs e)
        {
            if (m_bInternalUpdation)
                return;
            if (dgvAddress.DataSource == null)
                return;

            if (m_objOperation == MasterOperation.Add)
                return;

            if (chkDefault.Checked == false)
            {
                MessageBox.Show("Default flag cannot be removed. Please mark default to other address in same category to remove default flag of current address.", 
                    m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                chkDefault.Checked = true;
                return;
            }
        }
        #endregion

        /// <summary>
        /// Contact person default checkbox check state changed event handler.
        /// Restrains user deselecting Contact person default checked status.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region chkContactPersionDefault_CheckedChanged
        private void chkContactPersionDefault_CheckedChanged(object sender, EventArgs e)
        {
            if (m_bInternalUpdation)
                return;
            if (dgvAddress.DataSource == null)
                return;
            if (m_objOperation == MasterOperation.Add)
                return;

            if (chkContactPersionDefault.Checked == false)
            {
                MessageBox.Show("Contact person default flag cannot be removed. Please mark default to other address in same category to remove default flag of current address.", 
                    m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                chkContactPersionDefault.Checked = true;
                return;
            }
        }
        #endregion

        /// <summary>
        /// Category combo item changed event handler.
        /// Enable/disables default check boxes as per selected address Category.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region cboCategory_SelectionChangeCommitted
        private void cboCategory_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (cboCategory.SelectedValue == null)
                return;

            chkDefault.Enabled = cboCategory.SelectedValue.ToString().Trim() != CUCCConstants.Instance.ADDR_CONTACT_PERSON_CATEGORY_CODE;
            chkContactPersionDefault.Enabled = cboCategory.SelectedValue.ToString().Trim() == CUCCConstants.Instance.ADDR_CONTACT_PERSON_CATEGORY_CODE;
            chkSameCorresPermAdd.Enabled = cboCategory.SelectedValue.ToString().Trim() == CUCCConstants.Instance.ADDR_CORRESPONDENCE_CATEGORY_CODE;

            try
            {
                m_bInternalUpdation = true;

                if (chkDefault.Enabled == false)
                    chkDefault.Checked = false;
                if (chkContactPersionDefault.Enabled == false)
                    chkContactPersionDefault.Checked = false;
                if (chkSameCorresPermAdd.Enabled == false)
                    chkSameCorresPermAdd.Checked = false;
            }
            finally
            {
                m_bInternalUpdation = false;
            }
        }
        #endregion
        
        /// <summary>
        /// Add button click event handler. Redirects to New_Click event handler.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnAdd_Click
        private void btnAdd_Click(object sender, EventArgs e)
        {
            New_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Delete button click event handler. Redirects to Delete_Click event handler.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnDelete_Click
        private void btnDelete_Click(object sender, EventArgs e)
        {
            Delete_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Save button click event handler. Redirects to Save_Click event handler.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnSave_Click
        private void btnSave_Click(object sender, EventArgs e)
        {
            Save_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// State combo item changed event handler.
        /// Enables/disables other city text box depending on current selection
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region cboState_SelectedIndexChanged
        private void cboState_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtStateName.Enabled = false;
            if (cboState.SelectedValue != null)
            {
                txtStateName.Enabled = (cboState.SelectedValue.ToString() == CUCCConstants.Instance.STATE_OTHER_CODE);
            }

            if (txtStateName.Enabled == false)
                txtStateName.Text = string.Empty;
            //else
            //    txtStateName.Focus();
        }
        #endregion

        /// <summary>
        /// IsDirector check box checked state change event handler.
        /// Enables/disables DIN text box depending on current checked state
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region chkIsDirector_CheckedChanged
        private void chkIsDirector_CheckedChanged(object sender, EventArgs e)
        {
            txtDIN.Enabled = chkIsDirector.Checked;
            if (txtDIN.Enabled == false)
                txtDIN.Text = string.Empty;
            //else
            //    txtDIN.Focus();
        }
        #endregion

        /// <summary>
        /// City combo item changed event handler.
        /// Populates City & state mapped with current city.
        /// Sets current CityState code number.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region cboCity_SelectedIndexChanged
        private void cboCity_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable l_dtCity = CMastersDataProvider.Instance[Masters.CityStateMapping];
            if (l_dtCity == null)
                return;
            if (cboCity.SelectedValue == null)
                return;

            try
            {
                DataRow[] l_objRows = l_dtCity.Select("n_CityStateCode = " + cboCity.SelectedValue.ToString());
                if ((l_objRows != null) && (l_objRows.Length > 0))
                {
                    m_iCityStateCode = Convert.ToInt32(cboCity.SelectedValue.ToString());
                    //Console.WriteLine("CityStateCode 3: " + m_iCityStateCode);
                    cboState.SelectedValue = l_objRows[0]["n_StateNumber"].ToString();
                    cboCountry.SelectedValue = l_objRows[0]["n_CountryCode"].ToString();
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                MessageBox.Show("Unable to set state/country", m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }
        #endregion

        /// <summary>
        /// City text changed event handler.
        /// Sets State combo to Others. Clears current CityState code number.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region cboCity_TextUpdate
        private void cboCity_TextUpdate(object sender, EventArgs e)
        {
            try
            {
                m_iCityStateCode = 0;
                //Console.WriteLine("CityStateCode 4: " + m_iCityStateCode);
                cboState.SelectedValue = CUCCConstants.Instance.OTHER_STATE_CODE;
                //cboCountry.SelectedValue = CUCCConstants.Instance.OTHER_STATE_CODE;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
            }
        }
        #endregion

        /// <summary>
        /// Makercancel button click event handler.redirect to CancelMakerChanges function
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">Event argument</param>
        #region btnMakerCancel_Click
        private void btnMakerCancel_Click(object sender, EventArgs e)
        {
            this.CancelMakerChanges();
        }
        #endregion

        #endregion

        #region Methods

        /// <summary>
        /// Formats data layout of grid. Sets visible columns, their titles.
        /// </summary>
        #region FormatGrid
        private void FormatGrid()
        {
            if (dgvAddress.Cols.Contains("n_AddressNo"))
                dgvAddress.Cols["n_AddressNo"].Visible = false;
            if (dgvAddress.Cols.Contains("n_ClientNo"))
                dgvAddress.Cols["n_ClientNo"].Visible = false;

            if (dgvAddress.Cols.Contains("n_AddressType"))
            {
                dgvAddress.Cols["n_AddressType"].Caption = "Address Type";

                dgvAddress.Cols["n_AddressType"].DataMap = CReferenceDataProvider.Instance.GetHashTable(CReferenceDataProvider.ReferenceType.CATEGORY, CReferenceDataProvider.ReferenceFields.ReferenceName, CReferenceDataProvider.ReferenceFields.ReferenceCode);
            }
            if (dgvAddress.Cols.Contains("s_ContactPerson"))
                dgvAddress.Cols["s_ContactPerson"].Caption = "Contact Person";

            if (dgvAddress.Cols.Contains("s_Designation"))
                dgvAddress.Cols["s_Designation"].Caption = "Designation";
            if (dgvAddress.Cols.Contains("s_Director"))
            {
                dgvAddress.Cols["s_Director"].Caption = "IsDirector";

                Hashtable l_hstYesNo = new Hashtable();
                l_hstYesNo.Add("Y", "Yes");
                l_hstYesNo.Add("N", "No");
                dgvAddress.Cols["s_Director"].DataMap = l_hstYesNo;
            }

            if (dgvAddress.Cols.Contains("s_AddressLine1"))
                dgvAddress.Cols["s_AddressLine1"].Caption = "Address Line1";
            if (dgvAddress.Cols.Contains("s_AddressLine2"))
                dgvAddress.Cols["s_AddressLine2"].Caption = "Address Line2";
            if (dgvAddress.Cols.Contains("s_AddressLine3"))
                dgvAddress.Cols["s_AddressLine3"].Caption = "Address Line3";
            if (dgvAddress.Cols.Contains("s_AddressLine4"))
                dgvAddress.Cols["s_AddressLine4"].Caption = "Address Line4";
            if (dgvAddress.Cols.Contains("s_PANNo"))
                dgvAddress.Cols["s_PANNo"].Caption = "PAN";
            if (dgvAddress.Cols.Contains("s_City"))
            {
                dgvAddress.Cols["s_City"].Caption = "City Name";
                //dgvAddress.Cols["s_City"].DataMap = CReferenceDataProvider.Instance.GetHashTable(CReferenceDataProvider.ReferenceType.CITY, CReferenceDataProvider.ReferenceFields.ReferenceName, CReferenceDataProvider.ReferenceFields.ReferenceCode);
            }
            if (dgvAddress.Cols.Contains("n_StateNumber"))
            {
                dgvAddress.Cols["n_StateNumber"].Caption = "State Name";
                dgvAddress.Cols["n_StateNumber"].DataMap = CReferenceDataProvider.Instance.GetHashTable(CReferenceDataProvider.ReferenceType.STATE, CReferenceDataProvider.ReferenceFields.ReferenceName, CReferenceDataProvider.ReferenceFields.ReferenceCode);
            }
            if (dgvAddress.Cols.Contains("s_StateOther"))
                dgvAddress.Cols["s_StateOther"].Caption = "Other State Name";

            if (dgvAddress.Cols.Contains("n_CountryCode"))
            {
                dgvAddress.Cols["n_CountryCode"].Caption = "Country Name";
                dgvAddress.Cols["n_CountryCode"].DataMap = CReferenceDataProvider.Instance.GetHashTable(CReferenceDataProvider.ReferenceType.COUNTRY, CReferenceDataProvider.ReferenceFields.ReferenceName, CReferenceDataProvider.ReferenceFields.ReferenceCode);
            }
            if (dgvAddress.Cols.Contains("s_PinCode"))
                dgvAddress.Cols["s_PinCode"].Caption = "Pin Code";

            if (dgvAddress.Cols.Contains("s_TelNo1"))
                dgvAddress.Cols["s_TelNo1"].Caption = "Res Tel No";
            if (dgvAddress.Cols.Contains("s_Mobile1"))
                dgvAddress.Cols["s_Mobile1"].Caption = "Mobile No 1";

            if (dgvAddress.Cols.Contains("s_Mobile2"))
                dgvAddress.Cols["s_Mobile2"].Caption = "Mobile No 2";
            if (dgvAddress.Cols.Contains("s_FaxNo"))
                dgvAddress.Cols["s_FaxNo"].Caption = "Fax No";
            if (dgvAddress.Cols.Contains("s_TelNoISDCode"))
                dgvAddress.Cols["s_TelNoISDCode"].Caption = "Res Tel ISD";
            if (dgvAddress.Cols.Contains("s_TelNoSTDCode"))
                dgvAddress.Cols["s_TelNoSTDCode"].Caption = "Res Tel Std";

            if (dgvAddress.Cols.Contains("s_TelNoOffice"))
                dgvAddress.Cols["s_TelNoOffice"].Caption = "Office Tel No";
            if (dgvAddress.Cols.Contains("s_TelNoOfficeISDCode"))
                dgvAddress.Cols["s_TelNoOfficeISDCode"].Caption = "Office Tel ISD";
            if (dgvAddress.Cols.Contains("s_TelNoOfficeSTDCode"))
                dgvAddress.Cols["s_TelNoOfficeSTDCode"].Caption = "Office Tel Std";

            if (dgvAddress.Cols.Contains("s_FaxNoISDCode"))
                dgvAddress.Cols["s_FaxNoISDCode"].Caption = "ISD Fax";
            if (dgvAddress.Cols.Contains("s_FaxNoSTDCode"))
                dgvAddress.Cols["s_FaxNoSTDCode"].Caption = "Std Fax";
            if (dgvAddress.Cols.Contains("s_EMailId"))
                dgvAddress.Cols["s_EMailId"].Caption = "E-MailId";
            if (dgvAddress.Cols.Contains("s_CCEmail"))
                dgvAddress.Cols["s_CCEmail"].Caption = "CC-Email";

            if (dgvAddress.Cols.Contains("s_BCCMail"))
                dgvAddress.Cols["s_BCCMail"].Caption = "BCC-Mail";
            if (dgvAddress.Cols.Contains("s_DIN"))
                dgvAddress.Cols["s_DIN"].Caption = "DIN";
            if (dgvAddress.Cols.Contains("s_UID"))
                dgvAddress.Cols["s_UID"].Caption = "UID";
            if (dgvAddress.Cols.Contains("s_Default"))
            {
                dgvAddress.Cols["s_Default"].Caption = "Default";

                Hashtable l_hstYesNo = new Hashtable();
                l_hstYesNo.Add("Y", "Yes");
                l_hstYesNo.Add("N", "No");
                dgvAddress.Cols["s_Default"].DataMap = l_hstYesNo;
            }
            if (dgvAddress.Cols.Contains("s_ContactPersonDefault"))
            {
                dgvAddress.Cols["s_ContactPersonDefault"].Caption = "Contact Person Default";

                Hashtable l_hstYesNo = new Hashtable();
                l_hstYesNo.Add("Y", "Yes");
                l_hstYesNo.Add("N", "No");
                dgvAddress.Cols["s_ContactPersonDefault"].DataMap = l_hstYesNo;
            }
            if (dgvAddress.Cols.Contains("s_SameCorrPermAdd"))
            {
                dgvAddress.Cols["s_SameCorrPermAdd"].Caption = "SameCorrPermAdd";

                Hashtable l_hstYesNo = new Hashtable();
                l_hstYesNo.Add("Y", "Yes");
                l_hstYesNo.Add("N", "No");
                dgvAddress.Cols["s_SameCorrPermAdd"].DataMap = l_hstYesNo;
            }
            if (dgvAddress.Cols.Contains("n_CityStateCode"))
                dgvAddress.Cols["n_CityStateCode"].Visible = false;
        }
        #endregion

        /// <summary>
        /// Populates help (combo) controls with master values
        /// </summary>
        /// <returns></returns>
        #region PopulateLookUp
        private long PopulateLookUp()
        {
            cboCity.ValueMember = "n_CityStateCode";
            cboCity.DisplayMember = "s_City";
            //cboCity.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.CITY];
            cboCity.DataSource = CMastersDataProvider.Instance[Masters.CityStateMapping];

            DataTable l_dt = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.STATE];
            l_dt.DefaultView.Sort = "s_ReferenceName asc";

            cboState.ValueMember = "s_ReferenceCode";
            cboState.DisplayMember = "s_ReferenceName";
            cboState.DataSource = l_dt;
            
            cboCountry.ValueMember = "s_ReferenceCode";
            cboCountry.DisplayMember = "s_ReferenceName";
            cboCountry.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.COUNTRY];

            cboCategory.ValueMember = "s_ReferenceCode";
            cboCategory.DisplayMember = "s_ReferenceName";
            cboCategory.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.CATEGORY];

            return 0;

        }
        #endregion

        /// <summary>
        /// Updates current changes to database using BL class
        /// </summary>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region SaveClientAddressData
        private long SaveClientAddressData()
        {
            if (m_objOperation == MasterOperation.Add)
            {
                m_objCUCCClientAddress = new CUCCClientAddress(0);
            }

            if (
                (m_objOperation != MasterOperation.Add)
                &&
                (
                (dgvAddress.DataSource == null)
                || (dgvAddress.Rows.Count == dgvAddress.Rows.Fixed)
                ))
            {
                MessageBox.Show("No data exists!!!", m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return 1;
            }

            string l_sErrorMessage = string.Empty;
            Control l_ctrlErrorControl = null;
            if (ValidateAddressDetails(ref l_sErrorMessage, ref l_ctrlErrorControl) == false)
            {
                MessageBox.Show(l_sErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                if ((l_ctrlErrorControl != null) && (l_ctrlErrorControl.Enabled))
                    l_ctrlErrorControl.Focus();
                return 1;
            }

            ArrayList l_ClientAddressData = new ArrayList();

            if (m_objOperation == MasterOperation.Add)
            {
                l_ClientAddressData.Add("S");
                m_iAddressNo = 0;
            }
            else
                l_ClientAddressData.Add("M");

            l_ClientAddressData.Add(m_iAddressNo);
            l_ClientAddressData.Add(m_objCurrentClient.ClientCode);
            l_ClientAddressData.Add(cboCategory.SelectedValue);
            l_ClientAddressData.Add(txtContactPerson.Text.Trim());
            l_ClientAddressData.Add(txtDesignation.Text.Trim());
            if (chkIsDirector.Checked)
                l_ClientAddressData.Add("Y");
            else
                l_ClientAddressData.Add("N");

            l_ClientAddressData.Add(txtAddress1.Text.Trim());
            l_ClientAddressData.Add(txtAddress2.Text.Trim());
            l_ClientAddressData.Add(txtAddress3.Text.Trim());
            l_ClientAddressData.Add(txtAddress4.Text.Trim());

            l_ClientAddressData.Add(txtPANNo.Text.Trim());
            l_ClientAddressData.Add(m_iCityStateCode);  // City State Code

            l_ClientAddressData.Add(cboCity.Text);
            l_ClientAddressData.Add(cboState.SelectedValue);
            l_ClientAddressData.Add(txtStateName.Text.Trim());

            l_ClientAddressData.Add(cboCountry.SelectedValue);
            l_ClientAddressData.Add(txtPinCode.Text.Trim());
            l_ClientAddressData.Add(txtTelNoRes.Text.Trim());
            l_ClientAddressData.Add(txtMobileNo1.Text.Trim());
            l_ClientAddressData.Add(txtMobileNo2.Text.Trim());

            l_ClientAddressData.Add(txtFaxNo.Text.Trim());

            l_ClientAddressData.Add(txtEmailId.Text.Trim());
            l_ClientAddressData.Add(txtCCEmailId.Text.Trim());
            l_ClientAddressData.Add(txtBCCEmailId.Text.Trim());

            l_ClientAddressData.Add(txtDIN.Text.Trim());
            l_ClientAddressData.Add(txtUID.Text.Trim());

            if (chkDefault.Checked)
                l_ClientAddressData.Add("Y");
            else
                l_ClientAddressData.Add("N");

            if (chkSameCorresPermAdd.Checked)
                l_ClientAddressData.Add("Y");
            else
                l_ClientAddressData.Add("N");
            l_ClientAddressData.Add(txtTelNoResISDCode.Text.Trim());
            l_ClientAddressData.Add(txtTelNoResSTDCode.Text.Trim());
            l_ClientAddressData.Add(txtFAXNoISDCode.Text.Trim());
            l_ClientAddressData.Add(txtFAXNoSTDCode.Text.Trim());

            l_ClientAddressData.Add(txtTelNoOffice.Text.Trim());
            l_ClientAddressData.Add(txtTelNoOfficeISDCode.Text.Trim());
            l_ClientAddressData.Add(txtTelNoOfficeSTDCode.Text.Trim());
            if (chkContactPersionDefault.Checked)
                l_ClientAddressData.Add("Y");
            else
                l_ClientAddressData.Add("N");

            MethodExecResult l_objMethodExceResult = m_objCUCCClientAddress.UpdateUCCClientAddressData(l_ClientAddressData);

            if (l_objMethodExceResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, l_objMethodExceResult);

                if (m_objOperation == MasterOperation.Add)
                    MessageBox.Show("Unable to add address details" + Environment.NewLine + l_objMethodExceResult.ErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK);
                else
                    MessageBox.Show("Unable to update address details" + Environment.NewLine + l_objMethodExceResult.ErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK);
                return -1;

            }
            else
            {
                if (m_objOperation == MasterOperation.Add)
                    MessageBox.Show("Records Added Successfully", m_sMsgBoxTitle, MessageBoxButtons.OK);
                else
                    MessageBox.Show("Records Updated Successfully", m_sMsgBoxTitle, MessageBoxButtons.OK);

                m_objCurrentClient.IsPendingAuth = true;

                RefreshClientAddressData();
                View_Click(this, EventArgs.Empty);

                return 0;
            }
        }
        #endregion

        /// <summary>
        /// Deletes current record from database using BL class
        /// </summary>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region DeleteClientAddressData
        private long DeleteClientAddressData()
        {
            ArrayList l_ClientAddressData = new ArrayList();

            l_ClientAddressData.Add(m_iAddressNo);

            MethodExecResult l_objMethodExceResult = m_objCUCCClientAddress.DeleteClientAddressData(l_ClientAddressData);

            if (l_objMethodExceResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, l_objMethodExceResult);
                MessageBox.Show(l_objMethodExceResult.ErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            else
            {
                MessageBox.Show("Records Deleted Successfully", m_sMsgBoxTitle, MessageBoxButtons.OK);
                RefreshClientAddressData();
                m_objCurrentClient.IsPendingAuth = true;
                ClearFields();

            }
            return 0;
        }
        #endregion

        /// <summary>
        /// Retrieves/sets data from database again for current client
        /// </summary>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region RefreshClientAddressData
        private long RefreshClientAddressData()
        {
            //Manish
            Int32 l_nUserNo;
            
            l_nUserNo = m_objCurrentClient.IsCheckerView?m_objCurrentClient.MakerUser:AppEnvironment.AppUser.UserNo;
            
            m_objClientAddressCollection = new CClientAddressCollection(m_objCurrentClient.ClientNo,l_nUserNo);
            if ((m_objClientAddressCollection.LastMethodExecResult != null) && (m_objClientAddressCollection.LastMethodExecResult.ReturnCode != MethodExecResult.SuccessfulReturnCode))
            {
                MessageBox.Show(m_objClientAddressCollection.LastMethodExecResult.ErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }

            ////////// populate collection 
            ////////m_objCurrentClient.ClientAddressesNew = new List<CUCCClientAddress>();
            ////////foreach (DataRow _dr in m_objClientAddressCollection.AddressDetailData.Rows)
            ////////{
            ////////    CUCCClientAddress l_ClientAddress;
            ////////    l_ClientAddress = new CUCCClientAddress(Convert.ToInt32(_dr["n_AddressNo"]));
            ////////    l_ClientAddress.Initialize(_dr, m_objClientAddressCollection);
            ////////    m_objCurrentClient.ClientAddressesNew.Add(l_ClientAddress);
            ////////}
            m_objCurrentClient.ClientAddressesNew = m_objClientAddressCollection.ClientAddressesNew;
            m_dtClientAddressDetails = m_objClientAddressCollection.AddressDetailData;
            dgvAddress.DataSource = m_dtClientAddressDetails;
            FormatGrid();

            if ((m_dtClientAddressDetails == null) || (m_dtClientAddressDetails.Rows.Count == 0))
                btnAdd_Click(this, EventArgs.Empty);
            return 0;
        }
        #endregion

        /// <summary>
        /// Populates controls with current selected address record
        /// </summary>
        #region PopulateFields
        private void PopulateFields()
        {
            Row l_objSelectedRow = dgvAddress.Rows.Selected[0];

            if (l_objSelectedRow == null)
            {
                return;
            }

            try
            {
                m_iAddressNo = Convert.ToInt32(l_objSelectedRow["n_AddressNo"]);
            }
            catch
            {
                return;
            }

            try
            {
                m_bInternalUpdation = true;

                ///m_bInternalUpdation = true;
                CurrencyManager l_cmCurrentMgr = (CurrencyManager)dgvAddress.BindingContext[dgvAddress.DataSource, dgvAddress.DataMember];
                DataRowView l_drvCurrent = (DataRowView)l_cmCurrentMgr.Current;
                DataRow l_rwCurrent = l_drvCurrent.Row;


                m_objCUCCClientAddress = new CUCCClientAddress(Convert.ToInt32(l_rwCurrent["n_AddressNo"]));
                MethodExecResult l_objMethodExecResult = m_objCUCCClientAddress.Initialize(l_rwCurrent, m_objClientAddressCollection);

                if (l_objMethodExecResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
                {
                    MessageBox.Show(l_objMethodExecResult.ErrorMessage);
                    return;
                }


                txtContactPerson.Text = m_objCUCCClientAddress.ContactPerson;
                txtDesignation.Text = m_objCUCCClientAddress.Designation;
                chkIsDirector.Checked = m_objCUCCClientAddress.Director;

                txtPANNo.Text = m_objCUCCClientAddress.PAN;
                cboCategory.SelectedValue = m_objCUCCClientAddress.AddressType;
                txtAddress1.Text = m_objCUCCClientAddress.AddressLine1;
                txtAddress2.Text = m_objCUCCClientAddress.AddressLine2;
                txtAddress3.Text = m_objCUCCClientAddress.AddressLine3;
                txtAddress4.Text = m_objCUCCClientAddress.AddressLine4;
                //cboCity.SelectedValue = m_objCUCCClientAddress.CityStateCode;
                cboCity.Text = m_objCUCCClientAddress.City;
                //txtCityName.Text = l_objSelectedRow[];
                cboState.SelectedValue = m_objCUCCClientAddress.StateNumber;
                txtStateName.Text = m_objCUCCClientAddress.StateOther;
                cboCountry.SelectedValue = m_objCUCCClientAddress.CountryCode;
                txtPinCode.Text = m_objCUCCClientAddress.PinCode;
                txtTelNoRes.Text = m_objCUCCClientAddress.ResTelNo;
                txtTelNoResISDCode.Text = m_objCUCCClientAddress.ResTelNoISDCode;
                txtTelNoResSTDCode.Text = m_objCUCCClientAddress.ResTelNoSTDCode;
                txtMobileNo1.Text = m_objCUCCClientAddress.Mobile1;
                txtMobileNo2.Text = m_objCUCCClientAddress.Mobile2;
                txtFaxNo.Text = m_objCUCCClientAddress.FaxNo;
                txtFAXNoISDCode.Text = m_objCUCCClientAddress.FaxNoISDCode;
                txtFAXNoSTDCode.Text = m_objCUCCClientAddress.FaxNoSTDCode;

                txtEmailId.Text = m_objCUCCClientAddress.EMailId;
                txtCCEmailId.Text = m_objCUCCClientAddress.CCEmail;
                txtBCCEmailId.Text = m_objCUCCClientAddress.BCCEmail;

                txtUID.Text = m_objCUCCClientAddress.UID;
                txtDIN.Text = m_objCUCCClientAddress.DIN;

                txtTelNoOffice.Text = m_objCUCCClientAddress.OffTelNo;
                txtTelNoOfficeISDCode.Text = m_objCUCCClientAddress.OffTelNoISDCode;
                txtTelNoOfficeSTDCode.Text = m_objCUCCClientAddress.OffTelNoSTDCode;
                chkDefault.Checked = m_objCUCCClientAddress.Default;
                chkContactPersionDefault.Checked = m_objCUCCClientAddress.ContactPersonDefault;
                chkSameCorresPermAdd.Checked = m_objCUCCClientAddress.SameCorrPermAdd;

                chkDefault.Enabled = m_objCUCCClientAddress.AddressType.ToString().Trim() != CUCCConstants.Instance.ADDR_CONTACT_PERSON_CATEGORY_CODE;
                chkContactPersionDefault.Enabled = m_objCUCCClientAddress.AddressType.ToString().Trim() == CUCCConstants.Instance.ADDR_CONTACT_PERSON_CATEGORY_CODE;
                chkSameCorresPermAdd.Enabled = m_objCUCCClientAddress.AddressType.ToString().Trim() == CUCCConstants.Instance.ADDR_CORRESPONDENCE_CATEGORY_CODE;

                if (m_objCUCCClientAddress.CityStateCode.ToString().Trim().Length > 0)
                    m_iCityStateCode = Convert.ToInt32(m_objCUCCClientAddress.CityStateCode.ToString().Trim());
                else
                {
                    m_iCityStateCode = 0;
                }
                //Console.WriteLine("CityStateCode 1: " + m_iCityStateCode);
                chkIsDirector_CheckedChanged(this, EventArgs.Empty);

                if (m_objCUCCClientAddress.AuthorizedStatus == "F")
                    btnMakerCancel.Visible = false;
                else
                    btnMakerCancel.Visible = true;

                if (m_objCurrentClient.IsPendingAuth)
                    ApplyMakerCheckerEffects(m_objCUCCClientAddress, m_objCUCCClientAddress.OriginalAddress);

            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                MessageBox.Show(ex.Message, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            finally
            {
                m_bInternalUpdation = false;
            }
        }
        #endregion

        /// <summary>
        /// Clears all control values
        /// </summary>
        #region ClearFields
        private void ClearFields()
        {
            m_bInternalUpdation = true;
            try
            {
                m_iCityStateCode = 0;
                //Console.WriteLine("CityStateCode 2: " + m_iCityStateCode);
                txtContactPerson.Text = "";
                txtDesignation.Text = "";
                chkIsDirector.Checked = false;
                txtPANNo.Text = "";
                cboCategory.SelectedValue = -1;
                txtAddress1.Text = "";
                txtAddress2.Text = "";
                txtAddress3.Text = "";
                txtAddress4.Text = "";
                cboCity.SelectedValue = -1;
                cboState.SelectedValue = -1;
                txtStateName.Text = "";
                cboCountry.SelectedValue = -1;
                txtPinCode.Text = "";
                txtTelNoRes.Text = "";
                txtMobileNo1.Text = "";
                txtMobileNo2.Text = "";
                txtFaxNo.Text = "";
                txtTelNoResISDCode.Text = "";
                txtTelNoResSTDCode.Text = "";
                txtFAXNoISDCode.Text = "";
                txtFAXNoSTDCode.Text = "";
                txtEmailId.Text = "";
                txtCCEmailId.Text = "";
                txtBCCEmailId.Text = "";

                txtUID.Text = "";
                txtDIN.Text = "";

                txtTelNoOffice.Text = "";
                txtTelNoOfficeISDCode.Text = "";
                txtTelNoOfficeSTDCode.Text = "";

                chkDefault.Checked = false;
                chkContactPersionDefault.Checked = false;
                chkSameCorresPermAdd.Checked = false;

                if (cboCategory.Items.Count > 0)
                    cboCategory.SelectedIndex = 0;

                try
                {
                    cboCity.SelectedValue = CUCCConstants.Instance.DEFAULT_CITY_CODE;
                    cboState.SelectedValue = CUCCConstants.Instance.DEFAULT_STATE_CODE;
                    cboCountry.SelectedValue = CUCCConstants.Instance.DEFAULT_COUNTRY_CODE;
                }
                catch (Exception ex)
                {
                    Logger.Instance.WriteLog(this, ex);
                }

                cboCategory_SelectionChangeCommitted(this, EventArgs.Empty);
                chkIsDirector_CheckedChanged(this, EventArgs.Empty);
            }
            finally
            {
                m_bInternalUpdation = false;
            }

        }
        #endregion

        /// <summary>
        /// Enables/disables all controls
        /// </summary>
        /// <param name="p_vsFlag">Enable/disable flag</param>
        #region EnableDisableClientAddressField
        private void EnableDisableClientAddressField(bool p_vsFlag)
        {
        }
        #endregion

        /// <summary>
        /// Opens City help window
        /// </summary>
        /// <param name="p_vsCityName">Filter city name</param>
        /// <returns></returns>
        #region ShowCityHelp (not used)
        private long ShowCityHelp(string p_vsCityName)
        {
            return 0;
        }
        #endregion

        /// <summary>
        /// Validates current address record.
        /// </summary>
        /// <param name="ErrorMessage">Error message if validation fails</param>
        /// <param name="ErrorControl">Error control where validation failed</param>
        /// <returns>True if all validations passed, False otherwise</returns>
        #region ValidateAddressDetails
        private bool ValidateAddressDetails(ref string ErrorMessage, ref Control ErrorControl)
        {
            //Mandatory Fields
            if (cboCategory.SelectedItem == null)
            {
                ErrorControl = cboCategory;
                ErrorMessage = "Category cannot be blank";
                return false;
            }

            if (cboCategory.SelectedValue.ToString() == CUCCConstants.Instance.ADDR_REGISTERED_CATEGORY_CODE)
            {
                DataRow[] l_objContactPerson;

                if (m_objOperation == MasterOperation.Add)
                {
                    l_objContactPerson = m_dtClientAddressDetails.Select("n_AddressType=" + CUCCConstants.Instance.ADDR_REGISTERED_CATEGORY_CODE);
                }
                else
                {
                    l_objContactPerson = m_dtClientAddressDetails.Select(
                        "(n_AddressType=" + CUCCConstants.Instance.ADDR_REGISTERED_CATEGORY_CODE
                        + ") AND (n_AddressNo <> " + m_iAddressNo.ToString() + ")");
                }

                if ((l_objContactPerson != null) && (l_objContactPerson.Length > 0))
                {
                    ErrorControl = cboCategory;
                    ErrorMessage = "More than one Registered address cannot be defined.";
                    return false;
                }
            }

            if (cboCategory.SelectedValue.ToString() == CUCCConstants.Instance.ADDR_CONTACT_PERSON_CATEGORY_CODE)
            {
                if (txtDesignation.Enabled && txtDesignation.Text.Trim().Length == 0)
                {
                    ErrorControl = txtDesignation;
                    ErrorMessage = "Designation cannot be blank";
                    return false;
                }
            }

            //if (txtPANNo.Enabled && txtPANNo.Text.Trim().Length == 0)
            //{
            //    ErrorControl = txtPANNo;
            //    ErrorMessage = "PAN No cannot be blank";
            //    return false;
            //}

            if (txtAddress1.Enabled && txtAddress1.Text.Trim().Length == 0)
            {
                ErrorControl = txtAddress1;
                ErrorMessage = "Address Line1 cannot be blank";
                return false;
            }

            if (cboCity.Enabled && cboCity.Text.Trim() == string.Empty)
            {
                ErrorControl = cboCity;
                ErrorMessage = "City cannot be blank";
                return false;
            }

            if (cboState.Enabled && cboState.SelectedItem == null)
            {
                ErrorControl = cboState;
                ErrorMessage = "State cannot be blank";
                return false;
            }

            if (cboCountry.Enabled && cboCountry.SelectedItem == null)
            {
                ErrorControl = cboCountry;
                ErrorMessage = "Country cannot be blank";
                return false;
            }

            if (
                (cboCountry.SelectedValue != null)
                && (cboCountry.SelectedValue.ToString() == CUCCConstants.Instance.INDIA_COUNTRY_CODE)
                )
            {
                if (txtPinCode.Enabled && txtPinCode.Text.Trim().Length == 0)
                {
                    ErrorControl = txtPinCode;
                    ErrorMessage = "Pin Code cannot be blank";
                    return false;
                }
            }

            //Inter-Dependent Validations
            string l_sCategoryNo = cboCategory.SelectedValue.ToString();
            if (txtContactPerson.Enabled && (txtContactPerson.Text.Trim().Length == 0) && cboCategory.SelectedValue.ToString() == CUCCConstants.Instance.ADDR_CONTACT_PERSON_CATEGORY_CODE)
            {
                ErrorControl = txtContactPerson;
                ErrorMessage = "Contact Person is required";
                return false;
            }

            if (txtPANNo.Enabled && txtPANNo.Text.Trim().Length > 0)
            {
                if (CMatchCommonUtils.Instance.ValidateStringUsingRegExpr(RegExType.PANNo, txtPANNo.Text.Trim()) == false)
                {
                    ErrorControl = txtPANNo;
                    ErrorMessage = "PAN is not in correct format";
                    return false;
                }
            }

            if (txtStateName.Enabled &&
                (cboState.SelectedValue.ToString() == CUCCConstants.Instance.OTHER_STATE_CODE) //Others
                && (txtStateName.Text.Trim().Length == 0)
                )
            {
                ErrorControl = txtStateName;
                ErrorMessage = "State name must be specified if State is 'Others'";
                return false;
            }

            if (txtTelNoResSTDCode.Enabled &&
                (txtTelNoRes.Text.Trim().Length > 0)
                && (txtTelNoResSTDCode.Text.Trim().Length == 0)
                )
            {
                ErrorControl = txtTelNoResSTDCode;
                ErrorMessage = "STD Code must be specified if Residence Telephone no is specified";
                return false;
            }

            if (txtTelNoOfficeSTDCode.Enabled &&
                (txtTelNoOffice.Text.Trim().Length > 0)
                && (txtTelNoOfficeSTDCode.Text.Trim().Length == 0)
                )
            {
                ErrorControl = txtTelNoOfficeSTDCode;
                ErrorMessage = "STD Code must be specified if Office Telephone no is specified";
                return false;
            }

            string l_sInvalidEmailId = string.Empty;
            if (txtEmailId.Enabled && txtEmailId.Text.Trim().Length > 0)
            {
                //if (CMatchCommonUtils.Instance.ValidateStringUsingRegExpr(RegExType.EMAIL_SINGLE, txtEmailId.Text.Trim()) == false)
                if (IsEmailIdsCorrect(txtEmailId.Text.Trim(), ref l_sInvalidEmailId) == false)
                {
                    ErrorControl = txtEmailId;
                    ErrorMessage = "Email Id {" + l_sInvalidEmailId + "} is not in correct format";
                    return false;
                }
            }

            if (txtCCEmailId.Enabled && txtCCEmailId.Text.Trim().Length > 0)
            {
                //if (CMatchCommonUtils.Instance.ValidateStringUsingRegExpr(RegExType.EMAIL_SINGLE, txtCCEmailId.Text.Trim()) == false)
                if (IsEmailIdsCorrect(txtCCEmailId.Text.Trim(), ref l_sInvalidEmailId) == false)
                {
                    ErrorControl = txtCCEmailId;
                    ErrorMessage = "CC Email Id {" + l_sInvalidEmailId + "} is not in correct format";
                    return false;
                }
            }

            if (txtBCCEmailId.Enabled && txtBCCEmailId.Text.Trim().Length > 0)
            {
                //if (CMatchCommonUtils.Instance.ValidateStringUsingRegExpr(RegExType.EMAIL_SINGLE, txtBCCEmailId.Text.Trim()) == false)
                if (IsEmailIdsCorrect(txtBCCEmailId.Text.Trim(), ref l_sInvalidEmailId) == false)
                {
                    ErrorControl = txtBCCEmailId;
                    ErrorMessage = "BCC Email Id {" + l_sInvalidEmailId + "} is not in correct format";
                    return false;
                }
            }

            Regex regEx = new Regex(@"[A-Za-z]*");
            if (txtContactPerson.Enabled && regEx.Match(txtContactPerson.Text.Trim()).Success == false)
            {
                ErrorControl = txtContactPerson;
                ErrorMessage = "Contact person must contain at least one alpha";
                return false;
            }

            if (txtAddress1.Enabled && regEx.Match(txtAddress1.Text.Trim()).Success == false)
            {
                ErrorControl = txtAddress1;
                ErrorMessage = "Address Line 1 must contain at least one alpha";
                return false;
            }

            if (txtAddress2.Enabled && txtAddress2.Text.Trim().Length > 0)
            {
                if (regEx.Match(txtAddress2.Text.Trim()).Success == false)
                {
                    ErrorControl = txtAddress2;
                    ErrorMessage = "Address Line 2 must contain at least one alpha";
                    return false;
                }
            }

            if (txtAddress3.Enabled && txtAddress3.Text.Trim().Length > 0)
            {
                if (regEx.Match(txtAddress3.Text.Trim()).Success == false)
                {
                    ErrorControl = txtAddress3;
                    ErrorMessage = "Address Line 3 must contain at least one alpha";
                    return false;
                }
            }

            if (txtAddress4.Enabled && txtAddress4.Text.Trim().Length > 0)
            {
                if (regEx.Match(txtAddress4.Text.Trim()).Success == false)
                {
                    ErrorControl = txtAddress4;
                    ErrorMessage = "Address Line 4 must contain at least one alpha";
                    return false;
                }
            }

            regEx = new Regex(@"[0]*");
            if (txtTelNoResSTDCode.Enabled
                && txtTelNoResSTDCode.Text.Trim().Length > 0
                && regEx.Match(txtTelNoResSTDCode.Text.Trim()).Length == txtTelNoResSTDCode.Text.Trim().Length)
            {
                ErrorControl = txtTelNoResSTDCode;
                ErrorMessage = "Residence Telephone STD Code cannot be all zeros";
                return false;
            }

            if (txtTelNoRes.Enabled
                && txtTelNoRes.Text.Trim().Length > 0
                && regEx.Match(txtTelNoRes.Text.Trim()).Length == txtTelNoRes.Text.Trim().Length)
            {
                ErrorControl = txtTelNoResSTDCode;
                ErrorMessage = "Residence Telephone No cannot be all zeros";
                return false;
            }

            if (txtTelNoRes.Enabled
                && (txtTelNoRes.Text.Trim().Length == 0)
                && 
                (
                    (txtTelNoResSTDCode.Text.Trim().Length > 0)
                    || (txtTelNoResISDCode.Text.Trim().Length > 0)
                )
                )
            {
                ErrorControl = txtTelNoRes;
                ErrorMessage = "Residence Telephone No cannot be blank when STD/ISD code is defined";
                return false;
            }

            if (txtFaxNo.Enabled
                && (txtFaxNo.Text.Trim().Length == 0)
                &&
                (
                    (txtFAXNoSTDCode.Text.Trim().Length > 0)
                    || (txtFAXNoISDCode.Text.Trim().Length > 0)
                )
                )
            {
                ErrorControl = txtFaxNo;
                ErrorMessage = "Fax No cannot be blank when STD/ISD code is defined";
                return false;
            }

            if (txtTelNoOfficeSTDCode.Enabled
                && txtTelNoOfficeSTDCode.Text.Trim().Length > 0
                && regEx.Match(txtTelNoOfficeSTDCode.Text.Trim()).Length == txtTelNoOfficeSTDCode.Text.Trim().Length
                )
            {
                ErrorControl = txtTelNoOfficeSTDCode;
                ErrorMessage = "Office Telephone STD Code cannot be all zeros";
                return false;
            }

            if (txtTelNoOffice.Enabled
                && txtTelNoOffice.Text.Trim().Length > 0
                && regEx.Match(txtTelNoOffice.Text.Trim()).Length == txtTelNoOffice.Text.Trim().Length)
            {
                ErrorControl = txtTelNoOffice;
                ErrorMessage = "Office Telephone No cannot be all zeros";
                return false;
            }

            if (txtTelNoOffice.Enabled
                && (txtTelNoOffice.Text.Trim().Length == 0)
                &&
                (
                    (txtTelNoOfficeSTDCode.Text.Trim().Length > 0)
                    || (txtTelNoOfficeISDCode.Text.Trim().Length > 0)
                )
                )
            {
                ErrorControl = txtTelNoOffice;
                ErrorMessage = "Office Telephone No cannot be blank when STD/ISD code is defined";
                return false;
            }

            if (
                ((txtTelNoRes.Text.Trim().Length == 0) && (txtTelNoOffice.Text.Trim().Length == 0) && (txtMobileNo1.Text.Trim().Length == 0))
                && (txtTelNoRes.Enabled || txtTelNoOffice.Enabled || txtMobileNo1.Enabled)
              )
            {
                if (txtTelNoRes.Enabled && txtTelNoRes.Text.Trim().Length == 0)
                    ErrorControl = txtTelNoRes;
                else if (txtMobileNo1.Enabled && txtMobileNo1.Text.Trim().Length == 0)
                    ErrorControl = txtMobileNo1;
                ErrorMessage = "Either of Tel No or Mobile 1 must be specified";
                return false;
            }

            return true;

            //
        }
        #endregion

        /// <summary>
        /// Checks if given string is valid Email-ID
        /// </summary>
        /// <param name="p_vsEmails">Email-Id string</param>
        /// <param name="p_rsInvalidEmailId"></param>
        /// <returns>True if Email-ID is correct, False otherwise</returns>
        #region IsEmailIdsCorrect
        private bool IsEmailIdsCorrect(string p_vsEmails, ref string p_rsInvalidEmailId)
        {
            string[] l_sEmailIds = p_vsEmails.Split(new char[] { ';', ',' }, StringSplitOptions.RemoveEmptyEntries);

            for (int l_iEmailIdCounter = 0; l_iEmailIdCounter < l_sEmailIds.Length; l_iEmailIdCounter++)
            {
                if (CMatchCommonUtils.Instance.ValidateStringUsingRegExpr(RegExType.EMAIL_SINGLE, l_sEmailIds[l_iEmailIdCounter]) == false)
                {
                    p_rsInvalidEmailId = l_sEmailIds[l_iEmailIdCounter];
                    return false;
                }
            }

            return true;
        }
        #endregion

        /// <summary>
        /// Sets product wise control level settings
        /// </summary>
        #region SetProductwiseSettings
        private void SetProductwiseSettings()
        {
            if (AppEnvironment.AppSettings.AppProduct == Product.Settlement)
            {
                txtContactPerson.MaxLength = 50;

                txtAddress1.MaxLength = 100;
                txtAddress2.MaxLength = 100;
                txtAddress3.Enabled = false;
                txtAddress4.Enabled = false;

                txtTelNoOffice.MaxLength = 25;
                txtTelNoRes.MaxLength = 25;
                txtFaxNo.MaxLength = 25;
            }
            else if (AppEnvironment.AppSettings.AppProduct == Product.Derivative)
            {
                txtContactPerson.MaxLength = 100;
                txtAddress1.MaxLength = 100;
                txtAddress2.MaxLength = 100;
                txtAddress3.MaxLength = 100;
                txtAddress4.MaxLength = 100;
            }
        }
        #endregion

        /// <summary>
        /// Set the tool-tip for unauthorised records
        /// </summary>
        /// <param name="m_objCurrent"> Changed Record </param>
        /// <param name="m_objCompareTo"> Original Record </param>
        #region ApplyMakerCheckerEffects
        private void ApplyMakerCheckerEffects(CUCCClientAddress m_objCurrent, CUCCClientAddress m_objCompareTo)
        {

            CUCCCommon l_objCommon = CUCCCommon.Instance;
            if (m_objCompareTo == null)
                m_objCompareTo = m_objCurrent;

            if (m_objCurrent.AddressType == m_objCompareTo.AddressType)
                l_objCommon.ResetMakerChangedStyle(cboCategory, lblCategory, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(cboCategory, lblCategory, ttMain, CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.CATEGORY, m_objCompareTo.AddressType.ToString()));

            
            if (m_objCurrent.ContactPerson == m_objCompareTo.ContactPerson)
                l_objCommon.ResetMakerChangedStyle(txtContactPerson, lblContactPerson, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtContactPerson, lblContactPerson, ttMain, m_objCompareTo.ContactPerson);

            if (m_objCurrent.PAN == m_objCompareTo.PAN)
                l_objCommon.ResetMakerChangedStyle(txtPANNo, lblPANNo, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtPANNo, lblPANNo, ttMain, m_objCompareTo.PAN);

            if (m_objCurrent.UID== m_objCompareTo.UID)
                l_objCommon.ResetMakerChangedStyle(txtUID, lblUID, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtUID, lblUID, ttMain, m_objCompareTo.UID);

            if (m_objCurrent.Designation == m_objCompareTo.Designation)
                l_objCommon.ResetMakerChangedStyle(txtDesignation, lblDesignation, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtDesignation, lblDesignation, ttMain, m_objCompareTo.Designation);

            if (m_objCurrent.DIN == m_objCompareTo.DIN)
                l_objCommon.ResetMakerChangedStyle(txtDIN, lblDirector, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtDIN, lblDirector, ttMain, m_objCompareTo.DIN);

            if (m_objCurrent.AddressLine1 == m_objCompareTo.AddressLine1)
                l_objCommon.ResetMakerChangedStyle(txtAddress1, lblAddressLine1, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtAddress1, lblAddressLine1, ttMain, m_objCompareTo.AddressLine1);

            if (m_objCurrent.AddressLine2 == m_objCompareTo.AddressLine2)
                l_objCommon.ResetMakerChangedStyle(txtAddress2, lblAddressLine1, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtAddress2, lblAddressLine1, ttMain, m_objCompareTo.AddressLine2);

            if (m_objCurrent.AddressLine3 == m_objCompareTo.AddressLine3)
                l_objCommon.ResetMakerChangedStyle(txtAddress3, lblAddressLine1, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtAddress3, lblAddressLine1, ttMain, m_objCompareTo.AddressLine3);

            if (m_objCurrent.AddressLine4 == m_objCompareTo.AddressLine4)
                l_objCommon.ResetMakerChangedStyle(txtAddress4, lblAddressLine1, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtAddress4, lblAddressLine1, ttMain, m_objCompareTo.AddressLine4);

            if (m_objCurrent.ResTelNoISDCode == m_objCompareTo.ResTelNoISDCode)
                l_objCommon.ResetMakerChangedStyle(txtTelNoResISDCode, lblResTelNo, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtTelNoResISDCode, lblResTelNo, ttMain, m_objCompareTo.ResTelNoISDCode);

            if (m_objCurrent.ResTelNoSTDCode == m_objCompareTo.ResTelNoSTDCode)
                l_objCommon.ResetMakerChangedStyle(txtTelNoResSTDCode, lblResTelNo, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtTelNoResSTDCode, lblResTelNo, ttMain, m_objCompareTo.ResTelNoSTDCode);

            if (m_objCurrent.ResTelNo == m_objCompareTo.ResTelNo)
                l_objCommon.ResetMakerChangedStyle(txtTelNoRes, lblResTelNo, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtTelNoRes, lblResTelNo, ttMain, m_objCompareTo.ResTelNo);


            if (m_objCurrent.OffTelNoISDCode == m_objCompareTo.OffTelNoISDCode)
                l_objCommon.ResetMakerChangedStyle(txtTelNoOfficeISDCode, lblOffTelNo, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtTelNoOfficeISDCode, lblOffTelNo, ttMain, m_objCompareTo.OffTelNoISDCode);

            if (m_objCurrent.OffTelNoSTDCode == m_objCompareTo.OffTelNoSTDCode)
                l_objCommon.ResetMakerChangedStyle(txtTelNoOfficeSTDCode, lblOffTelNo, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtTelNoOfficeSTDCode, lblOffTelNo, ttMain, m_objCompareTo.ResTelNoSTDCode);

            if (m_objCurrent.OffTelNo == m_objCompareTo.OffTelNo)
                l_objCommon.ResetMakerChangedStyle(txtTelNoOffice, lblOffTelNo, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtTelNoOffice, lblOffTelNo, ttMain, m_objCompareTo.OffTelNo);

            if (m_objCurrent.City == m_objCompareTo.City)
                l_objCommon.ResetMakerChangedStyle(cboCity, lblCity, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(cboCity, lblCity, ttMain, m_objCompareTo.City);

            if (m_objCurrent.PinCode == m_objCompareTo.PinCode)
                l_objCommon.ResetMakerChangedStyle(txtPinCode, lblPinCode, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtPinCode, lblPinCode, ttMain, m_objCompareTo.PinCode);

            if (m_objCurrent.StateNumber == m_objCompareTo.StateNumber)
                l_objCommon.ResetMakerChangedStyle(cboState, lblState, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(cboState, lblState, ttMain, CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.STATE, m_objCompareTo.StateNumber.ToString()));

            if (m_objCurrent.StateOther == m_objCompareTo.StateOther)
                l_objCommon.ResetMakerChangedStyle(txtStateName, lblState, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtStateName, lblState, ttMain,m_objCompareTo.StateOther);

            if (m_objCurrent.CountryCode == m_objCompareTo.CountryCode)
                l_objCommon.ResetMakerChangedStyle(cboCountry, lblCountry, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(cboCountry, lblCountry, ttMain, CReferenceDataProvider.Instance.GetDisplayValue(CReferenceDataProvider.ReferenceType.COUNTRY, m_objCompareTo.CountryCode.ToString()));

            if (m_objCurrent.EMailId == m_objCompareTo.EMailId)
                l_objCommon.ResetMakerChangedStyle(txtEmailId, lblEmailID, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtEmailId, lblEmailID, ttMain, m_objCompareTo.EMailId);

            if (m_objCurrent.CCEmail == m_objCompareTo.CCEmail)
                l_objCommon.ResetMakerChangedStyle(txtCCEmailId, lblCCMail, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtCCEmailId, lblCCMail, ttMain, m_objCompareTo.CCEmail);

            if (m_objCurrent.BCCEmail == m_objCompareTo.BCCEmail)
                l_objCommon.ResetMakerChangedStyle(txtBCCEmailId, lblBCCMail, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(txtBCCEmailId, lblBCCMail, ttMain, m_objCompareTo.BCCEmail);

            if (m_objCurrent.Default == m_objCompareTo.Default)
                l_objCommon.ResetMakerChangedStyle(chkDefault, lblDefault, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(chkDefault, lblDefault, ttMain, m_objCompareTo.Default);

            if (m_objCurrent.ContactPersonDefault == m_objCompareTo.ContactPersonDefault)
                l_objCommon.ResetMakerChangedStyle(chkContactPersionDefault, lblContactPersonDefault, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(chkContactPersionDefault, lblContactPersonDefault, ttMain, m_objCompareTo.ContactPersonDefault);

            if (m_objCurrent.SameCorrPermAdd == m_objCompareTo.SameCorrPermAdd)
                l_objCommon.ResetMakerChangedStyle(chkSameCorresPermAdd, lblPermenentAddSameAsCorrs, ttMain);
            else
                l_objCommon.SetMakerChangedStyle(chkSameCorresPermAdd, lblPermenentAddSameAsCorrs, ttMain, m_objCompareTo.SameCorrPermAdd);
        }
        #endregion

        /// <summary>
        /// Cancel the maker changes for the selected record
        /// </summary>
        #region CancelMakerChanges
        private void CancelMakerChanges()
        {
            if (MessageBox.Show("Are you sure to cancel maker changes?", m_sMsgBoxTitle,
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.No)
            {
                return;
            }

            MakerCancel lbjMkrCancel = new MakerCancel();
            ArrayList l_lstParamValue = new ArrayList();
            MethodExecResult l_objMethodExceResult;

            l_lstParamValue.Add(m_objCUCCClientAddress.ClientNo);
            l_lstParamValue.Add(3);

            l_objMethodExceResult = lbjMkrCancel.CancelMakerEffect(l_lstParamValue);

            if (l_objMethodExceResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, l_objMethodExceResult);
                MessageBox.Show("Unable to cancel the maker changes" + Environment.NewLine + l_objMethodExceResult.ErrorMessage, m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                View_Click(this, EventArgs.Empty);
                MessageBox.Show("Maker changes cancel successfully", m_sMsgBoxTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        #endregion 

        #endregion

        #region IEventInfo Members

        #region Not applicable

        /// <summary>
        /// Not implemented
        /// </summary>
        void IEventInfo.Filter() {}
        /// <summary>
        /// Not implemented
        /// </summary>
        void IEventInfo.ModifyRecord() { }

        #endregion

        /// <summary>
        /// Redirects to View_Click
        /// </summary>
        #region RefreshData
        void IEventInfo.RefreshData()
        {
            View_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Redirects to New_Click
        /// </summary>
        #region AddRecord
        void IEventInfo.AddRecord()
        {
            New_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Redirects to Delete_Click
        /// </summary>
        #region DeleteRecord
        void IEventInfo.DeleteRecord()
        {
            Delete_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Redirects to Save_Click
        /// </summary>
        #region SaveData
        void IEventInfo.SaveData()
        {
            Save_Click(this, EventArgs.Empty);
        }
        #endregion

        /// <summary>
        /// Redirects to Exit_Click
        /// </summary>
        #region Exit
        void IEventInfo.Exit()
        {
            Exit_Click(this, EventArgs.Empty);
        }
        #endregion

       
        #endregion

    }
}
