﻿namespace UCC.Forms.UCCClient
{
    partial class UCCClientExchangeInfo
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCCClientExchangeInfo));
            this.ftPanel5 = new MatchCommon.CustomControls.FTPanel();
            this.dgvClientExchangeMapping = new MatchCommon.CustomControls.FTDataGrid();
            this.pnlClientExchangeMappingDetails = new MatchCommon.CustomControls.FTPanel();
            this.lblRelationship = new MatchCommon.CustomControls.FTLabel();
            this.pnlActionControls = new MatchCommon.CustomControls.FTPanel();
            this.btnMakerCancel = new MatchCommon.CustomControls.FTButton();
            this.btnSave = new MatchCommon.CustomControls.FTButton();
            this.cboRelationship = new MatchCommon.CustomControls.FTComboBox();
            this.lblRejectionCode = new MatchCommon.CustomControls.FTLabel();
            this.txtRejectionCode = new MatchCommon.CustomControls.FTTextBox();
            this.lblBatchNo = new MatchCommon.CustomControls.FTLabel();
            this.txtBatchNo = new MatchCommon.CustomControls.FTTextBox();
            this.lblUCCDownloded = new MatchCommon.CustomControls.FTLabel();
            this.chkUCCDownloaded = new System.Windows.Forms.CheckBox();
            this.cboSegment = new MatchCommon.CustomControls.FTComboBox();
            this.lblSegment = new MatchCommon.CustomControls.FTLabel();
            this.cboClientType = new MatchCommon.CustomControls.FTComboBox();
            this.lblClientType = new MatchCommon.CustomControls.FTLabel();
            this.lblTradingCode = new MatchCommon.CustomControls.FTLabel();
            this.lblExchange = new MatchCommon.CustomControls.FTLabel();
            this.cboExchangeCode = new MatchCommon.CustomControls.FTComboBox();
            this.cboStatus = new MatchCommon.CustomControls.FTComboBox();
            this.dtpClientAgreementDate = new System.Windows.Forms.DateTimePicker();
            this.txtCPCode = new MatchCommon.CustomControls.FTTextBox();
            this.txtRemarks = new MatchCommon.CustomControls.FTTextBox();
            this.txtTradingCode = new MatchCommon.CustomControls.FTTextBox();
            this.lblClientAgreementDate = new MatchCommon.CustomControls.FTLabel();
            this.lblInpersonVerification = new MatchCommon.CustomControls.FTLabel();
            this.lblRemarks = new MatchCommon.CustomControls.FTLabel();
            this.lblStatus = new MatchCommon.CustomControls.FTLabel();
            this.chkInpersonVerification = new System.Windows.Forms.CheckBox();
            this.lblCPCode = new MatchCommon.CustomControls.FTLabel();
            this.ttMain = new System.Windows.Forms.ToolTip(this.components);
            this.ftPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClientExchangeMapping)).BeginInit();
            this.pnlClientExchangeMappingDetails.SuspendLayout();
            this.pnlActionControls.SuspendLayout();
            this.SuspendLayout();
            // 
            // ftPanel5
            // 
            this.ftPanel5.BackColor = System.Drawing.Color.Transparent;
            this.ftPanel5.Controls.Add(this.dgvClientExchangeMapping);
            this.ftPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ftPanel5.Location = new System.Drawing.Point(0, 0);
            this.ftPanel5.Name = "ftPanel5";
            this.ftPanel5.Size = new System.Drawing.Size(856, 172);
            this.ftPanel5.TabIndex = 7;
            // 
            // dgvClientExchangeMapping
            // 
            this.dgvClientExchangeMapping.AllowDragging = C1.Win.C1FlexGrid.AllowDraggingEnum.None;
            this.dgvClientExchangeMapping.AllowEditing = false;
            this.dgvClientExchangeMapping.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
            this.dgvClientExchangeMapping.BackColor = System.Drawing.Color.Transparent;
            this.dgvClientExchangeMapping.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.dgvClientExchangeMapping.ColumnInfo = "10,1,0,0,0,85,Columns:0{Width:30;}\t";
            this.dgvClientExchangeMapping.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvClientExchangeMapping.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
            this.dgvClientExchangeMapping.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dgvClientExchangeMapping.ForeColor = System.Drawing.Color.Black;
            this.dgvClientExchangeMapping.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
            this.dgvClientExchangeMapping.Location = new System.Drawing.Point(0, 0);
            this.dgvClientExchangeMapping.Name = "dgvClientExchangeMapping";
            this.dgvClientExchangeMapping.OverrideDefault = false;
            this.dgvClientExchangeMapping.Rows.Count = 1;
            this.dgvClientExchangeMapping.Rows.DefaultSize = 17;
            this.dgvClientExchangeMapping.Rows.MinSize = 25;
            this.dgvClientExchangeMapping.RowsFilter.AddFilterRow = false;
            this.dgvClientExchangeMapping.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.ListBox;
            this.dgvClientExchangeMapping.Size = new System.Drawing.Size(856, 172);
            this.dgvClientExchangeMapping.StyleInfo = "";
            this.dgvClientExchangeMapping.TabIndex = 3;
            this.dgvClientExchangeMapping.RowColChange += new System.EventHandler(this.dgvClientExchangeMapping_RowColChange);
            // 
            // pnlClientExchangeMappingDetails
            // 
            this.pnlClientExchangeMappingDetails.Controls.Add(this.lblRelationship);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.pnlActionControls);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.cboRelationship);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.lblRejectionCode);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.txtRejectionCode);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.lblBatchNo);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.txtBatchNo);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.lblUCCDownloded);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.chkUCCDownloaded);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.cboSegment);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.lblSegment);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.cboClientType);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.lblClientType);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.lblTradingCode);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.lblExchange);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.cboExchangeCode);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.cboStatus);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.dtpClientAgreementDate);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.txtCPCode);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.txtRemarks);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.txtTradingCode);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.lblClientAgreementDate);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.lblInpersonVerification);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.lblRemarks);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.lblStatus);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.chkInpersonVerification);
            this.pnlClientExchangeMappingDetails.Controls.Add(this.lblCPCode);
            this.pnlClientExchangeMappingDetails.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlClientExchangeMappingDetails.Location = new System.Drawing.Point(0, 172);
            this.pnlClientExchangeMappingDetails.Name = "pnlClientExchangeMappingDetails";
            this.pnlClientExchangeMappingDetails.Size = new System.Drawing.Size(856, 293);
            this.pnlClientExchangeMappingDetails.TabIndex = 6;
            // 
            // lblRelationship
            // 
            this.lblRelationship.AllowForeColorChange = false;
            this.lblRelationship.AutoSize = true;
            this.lblRelationship.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblRelationship.ForeColor = System.Drawing.Color.Black;
            this.lblRelationship.Location = new System.Drawing.Point(26, 123);
            this.lblRelationship.Name = "lblRelationship";
            this.lblRelationship.OverrideDefault = false;
            this.lblRelationship.Size = new System.Drawing.Size(65, 13);
            this.lblRelationship.TabIndex = 12;
            this.lblRelationship.Text = "Relationship";
            // 
            // pnlActionControls
            // 
            this.pnlActionControls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlActionControls.Controls.Add(this.btnMakerCancel);
            this.pnlActionControls.Controls.Add(this.btnSave);
            this.pnlActionControls.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlActionControls.Location = new System.Drawing.Point(0, 256);
            this.pnlActionControls.Name = "pnlActionControls";
            this.pnlActionControls.Size = new System.Drawing.Size(856, 37);
            this.pnlActionControls.TabIndex = 62;
            // 
            // btnMakerCancel
            // 
            this.btnMakerCancel.BackColor = System.Drawing.Color.Transparent;
            this.btnMakerCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMakerCancel.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnMakerCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnMakerCancel.Image")));
            this.btnMakerCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMakerCancel.Location = new System.Drawing.Point(684, 6);
            this.btnMakerCancel.Name = "btnMakerCancel";
            this.btnMakerCancel.Size = new System.Drawing.Size(107, 25);
            this.btnMakerCancel.TabIndex = 0;
            this.btnMakerCancel.Text = "&Maker Cancel";
            this.btnMakerCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMakerCancel.UseVisualStyleBackColor = false;
            this.btnMakerCancel.Visible = false;
            this.btnMakerCancel.Click += new System.EventHandler(this.btnMakerCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Transparent;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Tahoma", 7.5F);
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Location = new System.Drawing.Point(800, 6);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 25);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "&Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // cboRelationship
            // 
            this.cboRelationship.BackColor = System.Drawing.Color.White;
            this.cboRelationship.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboRelationship.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboRelationship.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboRelationship.ForeColor = System.Drawing.Color.Black;
            this.cboRelationship.FormattingEnabled = true;
            this.cboRelationship.Location = new System.Drawing.Point(155, 122);
            this.cboRelationship.MaxLength = 25;
            this.cboRelationship.Name = "cboRelationship";
            this.cboRelationship.ReadOnly = false;
            this.cboRelationship.Size = new System.Drawing.Size(234, 21);
            this.cboRelationship.TabIndex = 13;
            // 
            // lblRejectionCode
            // 
            this.lblRejectionCode.AllowForeColorChange = false;
            this.lblRejectionCode.AutoSize = true;
            this.lblRejectionCode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblRejectionCode.ForeColor = System.Drawing.Color.Black;
            this.lblRejectionCode.Location = new System.Drawing.Point(519, 229);
            this.lblRejectionCode.Name = "lblRejectionCode";
            this.lblRejectionCode.OverrideDefault = false;
            this.lblRejectionCode.Size = new System.Drawing.Size(80, 13);
            this.lblRejectionCode.TabIndex = 24;
            this.lblRejectionCode.Text = "Rejection Code";
            // 
            // txtRejectionCode
            // 
            this.txtRejectionCode.AllowAlpha = true;
            this.txtRejectionCode.AllowDot = true;
            this.txtRejectionCode.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtRejectionCode.AllowedCustomCharacters")));
            this.txtRejectionCode.AllowNonASCII = false;
            this.txtRejectionCode.AllowNumeric = true;
            this.txtRejectionCode.AllowSpace = true;
            this.txtRejectionCode.AllowSpecialChars = true;
            this.txtRejectionCode.BackColor = System.Drawing.SystemColors.Control;
            this.txtRejectionCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtRejectionCode.Enabled = false;
            this.txtRejectionCode.FocusColor = System.Drawing.Color.LightYellow;
            this.txtRejectionCode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtRejectionCode.ForeColor = System.Drawing.Color.Black;
            this.txtRejectionCode.IsEmailID = true;
            this.txtRejectionCode.IsEmailIdValid = false;
            this.txtRejectionCode.Location = new System.Drawing.Point(651, 226);
            this.txtRejectionCode.MaxLength = 15;
            this.txtRejectionCode.Name = "txtRejectionCode";
            this.txtRejectionCode.Size = new System.Drawing.Size(198, 20);
            this.txtRejectionCode.TabIndex = 25;
            // 
            // lblBatchNo
            // 
            this.lblBatchNo.AllowForeColorChange = false;
            this.lblBatchNo.AutoSize = true;
            this.lblBatchNo.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblBatchNo.ForeColor = System.Drawing.Color.Black;
            this.lblBatchNo.Location = new System.Drawing.Point(207, 230);
            this.lblBatchNo.Name = "lblBatchNo";
            this.lblBatchNo.OverrideDefault = false;
            this.lblBatchNo.Size = new System.Drawing.Size(50, 13);
            this.lblBatchNo.TabIndex = 22;
            this.lblBatchNo.Text = "Batch No";
            // 
            // txtBatchNo
            // 
            this.txtBatchNo.AllowAlpha = true;
            this.txtBatchNo.AllowDot = true;
            this.txtBatchNo.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtBatchNo.AllowedCustomCharacters")));
            this.txtBatchNo.AllowNonASCII = false;
            this.txtBatchNo.AllowNumeric = true;
            this.txtBatchNo.AllowSpace = true;
            this.txtBatchNo.AllowSpecialChars = true;
            this.txtBatchNo.BackColor = System.Drawing.SystemColors.Control;
            this.txtBatchNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBatchNo.Enabled = false;
            this.txtBatchNo.FocusColor = System.Drawing.Color.LightYellow;
            this.txtBatchNo.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtBatchNo.ForeColor = System.Drawing.Color.Black;
            this.txtBatchNo.IsEmailID = true;
            this.txtBatchNo.IsEmailIdValid = false;
            this.txtBatchNo.Location = new System.Drawing.Point(282, 228);
            this.txtBatchNo.MaxLength = 15;
            this.txtBatchNo.Name = "txtBatchNo";
            this.txtBatchNo.Size = new System.Drawing.Size(107, 20);
            this.txtBatchNo.TabIndex = 23;
            // 
            // lblUCCDownloded
            // 
            this.lblUCCDownloded.AllowForeColorChange = false;
            this.lblUCCDownloded.AutoSize = true;
            this.lblUCCDownloded.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblUCCDownloded.ForeColor = System.Drawing.Color.Black;
            this.lblUCCDownloded.Location = new System.Drawing.Point(26, 228);
            this.lblUCCDownloded.Name = "lblUCCDownloded";
            this.lblUCCDownloded.OverrideDefault = false;
            this.lblUCCDownloded.Size = new System.Drawing.Size(66, 13);
            this.lblUCCDownloded.TabIndex = 20;
            this.lblUCCDownloded.Text = "Downloaded";
            // 
            // chkUCCDownloaded
            // 
            this.chkUCCDownloaded.AutoSize = true;
            this.chkUCCDownloaded.Location = new System.Drawing.Point(155, 230);
            this.chkUCCDownloaded.Name = "chkUCCDownloaded";
            this.chkUCCDownloaded.Size = new System.Drawing.Size(15, 14);
            this.chkUCCDownloaded.TabIndex = 21;
            this.chkUCCDownloaded.UseVisualStyleBackColor = true;
            // 
            // cboSegment
            // 
            this.cboSegment.BackColor = System.Drawing.SystemColors.Control;
            this.cboSegment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSegment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboSegment.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboSegment.ForeColor = System.Drawing.Color.Black;
            this.cboSegment.FormattingEnabled = true;
            this.cboSegment.Location = new System.Drawing.Point(651, 16);
            this.cboSegment.MaxLength = 25;
            this.cboSegment.Name = "cboSegment";
            this.cboSegment.ReadOnly = true;
            this.cboSegment.Size = new System.Drawing.Size(197, 21);
            this.cboSegment.TabIndex = 3;
            // 
            // lblSegment
            // 
            this.lblSegment.AllowForeColorChange = false;
            this.lblSegment.AutoSize = true;
            this.lblSegment.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblSegment.ForeColor = System.Drawing.Color.Black;
            this.lblSegment.Location = new System.Drawing.Point(519, 19);
            this.lblSegment.Name = "lblSegment";
            this.lblSegment.OverrideDefault = false;
            this.lblSegment.Size = new System.Drawing.Size(49, 13);
            this.lblSegment.TabIndex = 2;
            this.lblSegment.Text = "Segment";
            // 
            // cboClientType
            // 
            this.cboClientType.BackColor = System.Drawing.SystemColors.Control;
            this.cboClientType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboClientType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboClientType.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboClientType.ForeColor = System.Drawing.Color.Black;
            this.cboClientType.FormattingEnabled = true;
            this.cboClientType.Location = new System.Drawing.Point(155, 88);
            this.cboClientType.MaxLength = 25;
            this.cboClientType.Name = "cboClientType";
            this.cboClientType.ReadOnly = true;
            this.cboClientType.Size = new System.Drawing.Size(234, 21);
            this.cboClientType.TabIndex = 9;
            this.cboClientType.SelectedIndexChanged += new System.EventHandler(this.cboClientType_SelectedIndexChanged);
            // 
            // lblClientType
            // 
            this.lblClientType.AllowForeColorChange = false;
            this.lblClientType.AutoSize = true;
            this.lblClientType.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblClientType.ForeColor = System.Drawing.Color.Black;
            this.lblClientType.Location = new System.Drawing.Point(26, 91);
            this.lblClientType.Name = "lblClientType";
            this.lblClientType.OverrideDefault = false;
            this.lblClientType.Size = new System.Drawing.Size(61, 13);
            this.lblClientType.TabIndex = 8;
            this.lblClientType.Text = "Client Type";
            // 
            // lblTradingCode
            // 
            this.lblTradingCode.AllowForeColorChange = false;
            this.lblTradingCode.AutoSize = true;
            this.lblTradingCode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblTradingCode.ForeColor = System.Drawing.Color.Black;
            this.lblTradingCode.Location = new System.Drawing.Point(26, 54);
            this.lblTradingCode.Name = "lblTradingCode";
            this.lblTradingCode.OverrideDefault = false;
            this.lblTradingCode.Size = new System.Drawing.Size(71, 13);
            this.lblTradingCode.TabIndex = 4;
            this.lblTradingCode.Text = "Trading Code";
            // 
            // lblExchange
            // 
            this.lblExchange.AllowForeColorChange = false;
            this.lblExchange.AutoSize = true;
            this.lblExchange.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblExchange.ForeColor = System.Drawing.Color.Black;
            this.lblExchange.Location = new System.Drawing.Point(26, 18);
            this.lblExchange.Name = "lblExchange";
            this.lblExchange.OverrideDefault = false;
            this.lblExchange.Size = new System.Drawing.Size(54, 13);
            this.lblExchange.TabIndex = 0;
            this.lblExchange.Text = "Exchange";
            // 
            // cboExchangeCode
            // 
            this.cboExchangeCode.BackColor = System.Drawing.Color.White;
            this.cboExchangeCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboExchangeCode.Enabled = false;
            this.cboExchangeCode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboExchangeCode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboExchangeCode.ForeColor = System.Drawing.Color.Black;
            this.cboExchangeCode.FormattingEnabled = true;
            this.cboExchangeCode.Location = new System.Drawing.Point(155, 16);
            this.cboExchangeCode.MaxLength = 25;
            this.cboExchangeCode.Name = "cboExchangeCode";
            this.cboExchangeCode.ReadOnly = false;
            this.cboExchangeCode.Size = new System.Drawing.Size(234, 21);
            this.cboExchangeCode.TabIndex = 1;
            // 
            // cboStatus
            // 
            this.cboStatus.BackColor = System.Drawing.Color.White;
            this.cboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboStatus.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboStatus.ForeColor = System.Drawing.Color.Black;
            this.cboStatus.FormattingEnabled = true;
            this.cboStatus.Location = new System.Drawing.Point(651, 158);
            this.cboStatus.MaxLength = 25;
            this.cboStatus.Name = "cboStatus";
            this.cboStatus.ReadOnly = false;
            this.cboStatus.Size = new System.Drawing.Size(197, 21);
            this.cboStatus.TabIndex = 17;
            // 
            // dtpClientAgreementDate
            // 
            this.dtpClientAgreementDate.CalendarForeColor = System.Drawing.Color.Black;
            this.dtpClientAgreementDate.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpClientAgreementDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpClientAgreementDate.Location = new System.Drawing.Point(155, 158);
            this.dtpClientAgreementDate.Name = "dtpClientAgreementDate";
            this.dtpClientAgreementDate.ShowCheckBox = true;
            this.dtpClientAgreementDate.Size = new System.Drawing.Size(115, 21);
            this.dtpClientAgreementDate.TabIndex = 15;
            // 
            // txtCPCode
            // 
            this.txtCPCode.AllowAlpha = true;
            this.txtCPCode.AllowDot = true;
            this.txtCPCode.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtCPCode.AllowedCustomCharacters")));
            this.txtCPCode.AllowNonASCII = false;
            this.txtCPCode.AllowNumeric = true;
            this.txtCPCode.AllowSpace = true;
            this.txtCPCode.AllowSpecialChars = true;
            this.txtCPCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCPCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCPCode.FocusColor = System.Drawing.Color.LightYellow;
            this.txtCPCode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtCPCode.ForeColor = System.Drawing.Color.Black;
            this.txtCPCode.IsEmailID = true;
            this.txtCPCode.IsEmailIdValid = false;
            this.txtCPCode.Location = new System.Drawing.Point(651, 52);
            this.txtCPCode.MaxLength = 15;
            this.txtCPCode.Name = "txtCPCode";
            this.txtCPCode.Size = new System.Drawing.Size(198, 20);
            this.txtCPCode.TabIndex = 7;
            // 
            // txtRemarks
            // 
            this.txtRemarks.AllowAlpha = true;
            this.txtRemarks.AllowDot = true;
            this.txtRemarks.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtRemarks.AllowedCustomCharacters")));
            this.txtRemarks.AllowNonASCII = false;
            this.txtRemarks.AllowNumeric = true;
            this.txtRemarks.AllowSpace = true;
            this.txtRemarks.AllowSpecialChars = true;
            this.txtRemarks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtRemarks.FocusColor = System.Drawing.Color.LightYellow;
            this.txtRemarks.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtRemarks.ForeColor = System.Drawing.Color.Black;
            this.txtRemarks.IsEmailID = true;
            this.txtRemarks.IsEmailIdValid = false;
            this.txtRemarks.Location = new System.Drawing.Point(157, 195);
            this.txtRemarks.MaxLength = 200;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Size = new System.Drawing.Size(691, 20);
            this.txtRemarks.TabIndex = 19;
            // 
            // txtTradingCode
            // 
            this.txtTradingCode.AllowAlpha = true;
            this.txtTradingCode.AllowDot = true;
            this.txtTradingCode.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtTradingCode.AllowedCustomCharacters")));
            this.txtTradingCode.AllowNonASCII = false;
            this.txtTradingCode.AllowNumeric = true;
            this.txtTradingCode.AllowSpace = true;
            this.txtTradingCode.AllowSpecialChars = true;
            this.txtTradingCode.FocusColor = System.Drawing.Color.LightYellow;
            this.txtTradingCode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.txtTradingCode.ForeColor = System.Drawing.Color.Black;
            this.txtTradingCode.IsEmailID = true;
            this.txtTradingCode.IsEmailIdValid = false;
            this.txtTradingCode.Location = new System.Drawing.Point(155, 52);
            this.txtTradingCode.MaxLength = 15;
            this.txtTradingCode.Name = "txtTradingCode";
            this.txtTradingCode.Size = new System.Drawing.Size(234, 20);
            this.txtTradingCode.TabIndex = 5;
            // 
            // lblClientAgreementDate
            // 
            this.lblClientAgreementDate.AllowForeColorChange = false;
            this.lblClientAgreementDate.AutoSize = true;
            this.lblClientAgreementDate.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblClientAgreementDate.ForeColor = System.Drawing.Color.Black;
            this.lblClientAgreementDate.Location = new System.Drawing.Point(26, 161);
            this.lblClientAgreementDate.Name = "lblClientAgreementDate";
            this.lblClientAgreementDate.OverrideDefault = false;
            this.lblClientAgreementDate.Size = new System.Drawing.Size(116, 13);
            this.lblClientAgreementDate.TabIndex = 14;
            this.lblClientAgreementDate.Text = "Client Agreement Date";
            // 
            // lblInpersonVerification
            // 
            this.lblInpersonVerification.AllowForeColorChange = false;
            this.lblInpersonVerification.AutoSize = true;
            this.lblInpersonVerification.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblInpersonVerification.ForeColor = System.Drawing.Color.Black;
            this.lblInpersonVerification.Location = new System.Drawing.Point(519, 91);
            this.lblInpersonVerification.Name = "lblInpersonVerification";
            this.lblInpersonVerification.OverrideDefault = false;
            this.lblInpersonVerification.Size = new System.Drawing.Size(106, 13);
            this.lblInpersonVerification.TabIndex = 10;
            this.lblInpersonVerification.Text = "Inperson Verification";
            // 
            // lblRemarks
            // 
            this.lblRemarks.AllowForeColorChange = false;
            this.lblRemarks.AutoSize = true;
            this.lblRemarks.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblRemarks.ForeColor = System.Drawing.Color.Black;
            this.lblRemarks.Location = new System.Drawing.Point(26, 196);
            this.lblRemarks.Name = "lblRemarks";
            this.lblRemarks.OverrideDefault = false;
            this.lblRemarks.Size = new System.Drawing.Size(48, 13);
            this.lblRemarks.TabIndex = 18;
            this.lblRemarks.Text = "Remarks";
            // 
            // lblStatus
            // 
            this.lblStatus.AllowForeColorChange = false;
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblStatus.ForeColor = System.Drawing.Color.Black;
            this.lblStatus.Location = new System.Drawing.Point(519, 158);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.OverrideDefault = false;
            this.lblStatus.Size = new System.Drawing.Size(38, 13);
            this.lblStatus.TabIndex = 16;
            this.lblStatus.Text = "Status";
            // 
            // chkInpersonVerification
            // 
            this.chkInpersonVerification.AutoSize = true;
            this.chkInpersonVerification.Location = new System.Drawing.Point(651, 91);
            this.chkInpersonVerification.Name = "chkInpersonVerification";
            this.chkInpersonVerification.Size = new System.Drawing.Size(15, 14);
            this.chkInpersonVerification.TabIndex = 11;
            this.chkInpersonVerification.UseVisualStyleBackColor = true;
            // 
            // lblCPCode
            // 
            this.lblCPCode.AllowForeColorChange = false;
            this.lblCPCode.AutoSize = true;
            this.lblCPCode.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblCPCode.ForeColor = System.Drawing.Color.Black;
            this.lblCPCode.Location = new System.Drawing.Point(519, 54);
            this.lblCPCode.Name = "lblCPCode";
            this.lblCPCode.OverrideDefault = false;
            this.lblCPCode.Size = new System.Drawing.Size(48, 13);
            this.lblCPCode.TabIndex = 6;
            this.lblCPCode.Text = "CP Code";
            // 
            // UCCClientExchangeInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.ftPanel5);
            this.Controls.Add(this.pnlClientExchangeMappingDetails);
            this.Name = "UCCClientExchangeInfo";
            this.Size = new System.Drawing.Size(856, 465);
            this.Load += new System.EventHandler(this.UCCClientExchangeInfo_Load);
            this.ftPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvClientExchangeMapping)).EndInit();
            this.pnlClientExchangeMappingDetails.ResumeLayout(false);
            this.pnlClientExchangeMappingDetails.PerformLayout();
            this.pnlActionControls.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MatchCommon.CustomControls.FTPanel ftPanel5;
        private MatchCommon.CustomControls.FTDataGrid dgvClientExchangeMapping;
        private MatchCommon.CustomControls.FTPanel pnlClientExchangeMappingDetails;
        private MatchCommon.CustomControls.FTComboBox cboSegment;
        private MatchCommon.CustomControls.FTLabel lblSegment;
        private MatchCommon.CustomControls.FTComboBox cboClientType;
        private MatchCommon.CustomControls.FTLabel lblClientType;
        private MatchCommon.CustomControls.FTLabel lblTradingCode;
        private MatchCommon.CustomControls.FTLabel lblExchange;
        private MatchCommon.CustomControls.FTComboBox cboExchangeCode;
        private MatchCommon.CustomControls.FTComboBox cboStatus;
        private System.Windows.Forms.DateTimePicker dtpClientAgreementDate;
        private MatchCommon.CustomControls.FTTextBox txtCPCode;
        private MatchCommon.CustomControls.FTTextBox txtRemarks;
        private MatchCommon.CustomControls.FTTextBox txtTradingCode;
        private MatchCommon.CustomControls.FTLabel lblClientAgreementDate;
        private MatchCommon.CustomControls.FTLabel lblInpersonVerification;
        private MatchCommon.CustomControls.FTLabel lblRemarks;
        private MatchCommon.CustomControls.FTLabel lblStatus;
        private System.Windows.Forms.CheckBox chkInpersonVerification;
        private MatchCommon.CustomControls.FTLabel lblCPCode;
        private MatchCommon.CustomControls.FTLabel lblUCCDownloded;
        private System.Windows.Forms.CheckBox chkUCCDownloaded;
        private MatchCommon.CustomControls.FTLabel lblBatchNo;
        private MatchCommon.CustomControls.FTTextBox txtBatchNo;
        private MatchCommon.CustomControls.FTLabel lblRejectionCode;
        private MatchCommon.CustomControls.FTTextBox txtRejectionCode;
        private MatchCommon.CustomControls.FTPanel pnlActionControls;
        private MatchCommon.CustomControls.FTButton btnSave;
        private MatchCommon.CustomControls.FTLabel lblRelationship;
        private MatchCommon.CustomControls.FTComboBox cboRelationship;
        private System.Windows.Forms.ToolTip ttMain;
        private MatchCommon.CustomControls.FTButton btnMakerCancel;
    }
}
