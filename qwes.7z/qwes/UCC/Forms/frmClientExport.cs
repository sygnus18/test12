﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using UCC.Class;
using UCC.Forms;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;
using MatchCommon;

namespace UCC.Forms
{
    /// <summary>
    /// UCC File Export screen
    /// </summary>
    public partial class frmClientExport : Form
    {
        #region Variables

        /// <summary>
        /// Export BL class instance
        /// </summary>
        private CClientExport m_objClientExport;

        /// <summary>
        /// Export filter BL class instance
        /// </summary>
        private CClientFilter m_objClientFilter;

        /// <summary>
        /// Export filter parameters class instance
        /// </summary>
        private ExportFilterParameters m_objFilterParams;

        /// <summary>
        /// UCC data DataTable
        /// </summary>
        private DataTable m_dtUCCData;

        /// <summary>
        /// Grid record selection column name
        /// </summary>
        private readonly string SelectColName = "n_Select";

        /// <summary>
        /// Binding source to bind data with grid
        /// </summary>
        private BindingSource m_bsExport;

        /// <summary>
        /// Indicates if valid client code is set in ClientCode text box
        /// If not, opens Help window on ClientCode text box leave event if text box text is not empty.
        /// </summary>
        private bool m_bValidClientValueSet;

        /// <summary>
        /// Read only variable options to be displayed in Show record combo box
        /// </summary>
        private readonly string ViewAll = "All";
        private readonly string ViewValid = "Valid";
        private readonly string ViewInvalid = "Invalid";

        #endregion

        /// <summary>
        /// Export class constructor
        /// </summary>
        #region Constructor
        public frmClientExport()
        {
            InitializeComponent();

            m_objClientExport = new CClientExport();
            dgvExport.OverrideDefault = true;
            dgvExport.Styles.Normal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dgvExport.Styles.Alternate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);

            this.DialogResult = DialogResult.Cancel;
            m_bsExport = new BindingSource();
            m_objClientFilter = new CClientFilter();
        } 
        #endregion

        #region Events

        /// <summary>
        /// Window load event handler. Initializes controls.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region frmClientExport_Load
        private void frmClientExport_Load(object sender, EventArgs e)
        {
            lblNoOfRecords.Text = string.Empty;
            dgvExport.AllowEditing = true;
            PopulateDropdown();
        } 
        #endregion

        /// <summary>
        /// Populates window help controls with master data
        /// </summary>
        #region PopulateDropdown
        private void PopulateDropdown()
        {
            //cboCompany.DisplayMember = "s_ReferenceName";
            //cboCompany.ValueMember = "s_ReferenceCode";
            //cboCompany.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.COMPANY];

            cboExchangeCode.DisplayMember = "s_ExCode";
            cboExchangeCode.ValueMember = "n_ExNo";
            cboExchangeCode.DataSource = CMastersDataProvider.Instance[Masters.Exchange];

            cboExportType.DisplayMember = "s_ReferenceName";
            cboExportType.ValueMember = "s_ReferenceCode";
            cboExportType.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.EXPORTTYPE];
            
            //CR964
            cboRecordType.DisplayMember = "s_ReferenceName";
            cboRecordType.ValueMember = "s_ReferenceCode";
            cboRecordType.DataSource = CReferenceDataProvider.Instance[CReferenceDataProvider.ReferenceType.RECORDTYPE];
            
            cboView.Items.Clear();

            cboView.Items.Add(ViewAll);
            cboView.Items.Add(ViewValid);
            cboView.Items.Add(ViewInvalid);

            cboView.SelectedItem = ViewValid;

            EnableDisableNewModifiedCombo();
        }
        #endregion

        /// <summary>
        /// Export button click event handler.
        /// Exports selected grid records to file using BL class as per selected exchange format.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnExport_Click
        private void btnExport_Click(object sender, EventArgs e)
        {
            if( (m_dtUCCData == null) || (m_dtUCCData.Rows.Count == 0) )
            {
                MessageBox.Show("No data found!!!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            m_bsExport.EndEdit();
            
            DataView l_dvSelectedRecords = m_dtUCCData.DefaultView;
            l_dvSelectedRecords.RowFilter = "";
            l_dvSelectedRecords.RowFilter = SelectColName + "=True";
            DataTable l_dtSelectedRecords = l_dvSelectedRecords.ToTable();
            l_dvSelectedRecords.RowFilter = "";
            if (l_dtSelectedRecords.Rows.Count == 0)
            {
                MessageBox.Show("No records found to export!!!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            if (l_dtSelectedRecords.Columns.Contains(SelectColName))
                l_dtSelectedRecords.Columns.Remove(SelectColName);

            FolderBrowserDialog l_objFilePath = new FolderBrowserDialog();
            l_objFilePath.SelectedPath = AppDomain.CurrentDomain.BaseDirectory;
            l_objFilePath.ShowNewFolderButton = true;
            if (l_objFilePath.ShowDialog() != DialogResult.OK)
            {
                return;
            }
            m_objFilterParams.FilePath = l_objFilePath.SelectedPath;

            this.Cursor = Cursors.WaitCursor;
            MethodExecResult l_objMethodExecResult = m_objClientExport.ExportUCCData(m_objFilterParams, l_dtSelectedRecords);
            if (l_objMethodExecResult.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Exported Successfully." + Environment.NewLine +
                    "Batch No: " + m_objFilterParams.BatchNo + Environment.NewLine + "File: " + m_objFilterParams.FileName, 
                    this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                this.Cursor = Cursors.Default;
                Logger.Instance.WriteLog(this, l_objMethodExecResult);
                MessageBox.Show(l_objMethodExecResult.ErrorMessage, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            m_objFilterParams.BatchNo = 0;
        } 
        #endregion

        /// <summary>
        /// Client code text box text change event handler.
        /// Sets m_bValidClientValueSet to false.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtClientCode_TextChanged
        private void txtClientCode_TextChanged(object sender, EventArgs e)
        {
            m_bValidClientValueSet = false;
        } 
        #endregion

        /// <summary>
        /// Client Code text box Key Up Event handler.
        /// Opens help window if F3 key is pressed.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtClientCode_KeyUp
        private void txtClientCode_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtClientCode.ReadOnly)
                return;

            if (e.KeyCode == Keys.F3)
                ShowClientHelp(txtClientCode.Text);
        } 
        #endregion

        /// <summary>
        /// Client code text box leave event handler.
        /// If valid client set flag is False, opens client help window populating records as per client code textbox text.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region txtClientCode_Leave
        private void txtClientCode_Leave(object sender, EventArgs e)
        {
            if (txtClientCode.ReadOnly || (txtClientCode.Enabled == false))
                return;

            if (txtClientCode.Text.Trim().Length == 0)
                return;

            if (m_bValidClientValueSet == false)
                ShowClientHelp(txtClientCode.Text.Trim());
        } 
        #endregion

        /// <summary>
        /// Closes current window
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnCancel_Click
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
        #endregion

        /// <summary>
        /// Retrieve button click event handler.
        /// Retrieves data from database applying current selected filders.
        /// If Batch No is provided, Reexports data for selected Date, Exchange and Batch no.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnRetrieve_Click
        private void btnRetrieve_Click(object sender, EventArgs e)
        {
            if (cboExchangeCode.SelectedValue == null)
            {
                MessageBox.Show("Select Exhange", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                cboExchangeCode.Focus();
                return;
            }

            if (dtpToDate.Value.Date < dtpFromDate.Value.Date)
            {
                MessageBox.Show("To date cannot be less than From date", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                dtpToDate.Focus();
                return;
            }

            m_objFilterParams = new ExportFilterParameters();

            try
            {
                m_objFilterParams.FromDate = dtpFromDate.Value.Date;
                m_objFilterParams.ToDate = dtpToDate.Value.Date;

                m_objFilterParams.ExchangeNo = Convert.ToInt32(cboExchangeCode.SelectedValue);
                m_objFilterParams.ExchangeCode = cboExchangeCode.Text;

                m_objFilterParams.ClientCode = txtClientCode.Text;
                if (txtBatchNo.Text.Trim().Length == 0)
                    m_objFilterParams.BatchNo = 0;
                else
                    m_objFilterParams.BatchNo = Convert.ToInt32(txtBatchNo.Text);

                if (cboExportType.SelectedValue == null)
                    m_objFilterParams.ExportType = string.Empty;
                else
                    m_objFilterParams.ExportType = cboExportType.SelectedValue.ToString().Trim();
                
                //CR964
                if (cboRecordType.SelectedValue == null)
                    m_objFilterParams.RecordType = string.Empty;
                else
                    m_objFilterParams.RecordType = cboRecordType.SelectedValue.ToString().Trim();

                if (m_dtUCCData != null)
                {
                    m_dtUCCData.Dispose();
                    m_dtUCCData = null;
                }

                m_bsExport.DataSource = null;
                dgvExport.DataSource = null;
                dgvExport.Rows.Count = dgvExport.Rows.Fixed;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                MessageBox.Show("Error parsing input values", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            if (m_objFilterParams.BatchNo > 0)
            {
                FolderBrowserDialog l_objFilePath = new FolderBrowserDialog();
                l_objFilePath.SelectedPath = AppDomain.CurrentDomain.BaseDirectory;
                l_objFilePath.ShowNewFolderButton = true;
                if (l_objFilePath.ShowDialog() != DialogResult.OK)
                {
                    return;
                }
                m_objFilterParams.FilePath = l_objFilePath.SelectedPath;
            }

            this.Cursor = Cursors.WaitCursor;
            MethodExecResult l_objMethodExecResult = m_objClientExport.RetrieveUCCData(m_objFilterParams, ref m_dtUCCData);
            if (l_objMethodExecResult.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                if (m_objFilterParams.BatchNo > 0)
                {
                    this.Cursor = Cursors.Default;
                    MessageBox.Show("Reexported Successfully." + Environment.NewLine +
                        "File: " + m_objFilterParams.FileName,
                        this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                else
                {
                    if (m_dtUCCData.Columns.Contains(SelectColName) == false)
                    {
                        DataColumn l_dcSelect = new DataColumn(SelectColName, typeof(bool));
                        l_dcSelect.DefaultValue = false;
                        l_dcSelect.AllowDBNull = false;
                        m_dtUCCData.Columns.Add(l_dcSelect);
                    }
                    if (m_dtUCCData.Columns.Contains(m_objClientExport.DeletedDirectorsColName) == false)
                    {
                        DataColumn l_dcDeletedDirectors = new DataColumn(m_objClientExport.DeletedDirectorsColName, typeof(int));
                        l_dcDeletedDirectors.DefaultValue = 0;
                        l_dcDeletedDirectors.AllowDBNull = false;
                        m_dtUCCData.Columns.Add(l_dcDeletedDirectors);
                    }

                    m_bsExport.DataSource = m_dtUCCData;
                    dgvExport.DataSource = m_bsExport;
                    FormatGrid();
                    if ((m_dtUCCData != null) && (m_dtUCCData.Rows.Count > 0))
                    {
                        if (chkSelectAll.Checked)
                            chkSelectAll_CheckedChanged(this, EventArgs.Empty);
                        else
                            chkSelectAll.Checked = true;
                    }

                    cboView_SelectedIndexChanged(this, EventArgs.Empty);
                    this.Cursor = Cursors.Default;
                }
            }
            else
            {
                this.Cursor = Cursors.Default;
                Logger.Instance.WriteLog(this, l_objMethodExecResult);
                MessageBox.Show(l_objMethodExecResult.ErrorMessage, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        #endregion

        /// <summary>
        /// Grid Before Edit event handler.
        /// Allows editing only if current client record is valid for export.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region dgvExport_BeforeEdit
        private void dgvExport_BeforeEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            string l_sErrorCode = string.Empty;
            try
            {
                l_sErrorCode = dgvExport.Rows[e.Row]["n_ErrorCodeDisp"].ToString();
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                e.Cancel = true;
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            if (string.IsNullOrEmpty(l_sErrorCode))
                e.Cancel = true;
            else if (l_sErrorCode != "0")
                e.Cancel = true;
        }
        #endregion

        /// <summary>
        /// Select All check box check state changed event handler.
        /// Selects/deselects all valid records as per check box checked status.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region chkSelectAll_CheckedChanged
        private void chkSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            if (m_dtUCCData == null)
            {
                MessageBox.Show("No data exists!!!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            int l_iRowCounter = 0;
            int l_iSelectedRecordsCount = 0;
            bool l_bSelectDeselect = chkSelectAll.Checked;
            try
            {
                for (l_iRowCounter = 0; l_iRowCounter < m_dtUCCData.Rows.Count; l_iRowCounter++)
                {
                    if (m_dtUCCData.Rows[l_iRowCounter]["n_ErrorCodeDisp"].ToString() == "0")
                    {
                        m_dtUCCData.Rows[l_iRowCounter][SelectColName] = l_bSelectDeselect;
                        l_iSelectedRecordsCount++;
                    }
                }

                if (l_iSelectedRecordsCount > 0)
                    MessageBox.Show("Total { " + l_iSelectedRecordsCount.ToString() + " } records affected", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else
                    MessageBox.Show("No valid records found", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "Error performing Select All operation at Line " + (l_iRowCounter + 1).ToString() + Environment.NewLine, ex);
                MessageBox.Show("Error performing operation." + Environment.NewLine + ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
        }
        #endregion

        /// <summary>
        /// Grid after edit event handler.
        /// Selects/deselects all records within same group as of current record.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region dgvExport_AfterEdit
        private void dgvExport_AfterEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            if (m_dtUCCData == null)
                return;

            if (m_dtUCCData.Columns.Contains("n_RecGroup") == false)
                return;

            DataRow[] l_objGroupRows = m_dtUCCData.Select("n_RecGroup = " + dgvExport.Rows[e.Row]["n_RecGroup"].ToString());
            if ((l_objGroupRows != null) && (l_objGroupRows.Length > 0))
            {
                bool l_bCurrentRowSelection = Convert.ToBoolean(dgvExport.Rows[e.Row][SelectColName]);
                for (int l_iRowCounter = 0; l_iRowCounter < l_objGroupRows.Length; l_iRowCounter++)
                {
                    l_objGroupRows[l_iRowCounter][SelectColName] = l_bCurrentRowSelection;
                }
            }
        }
        #endregion

        /// <summary>
        /// Show records combo item changed event handler.
        /// Filters currently displayed grid records as per selection (All/Valid/Invalid).
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region cboView_SelectedIndexChanged
        private void cboView_SelectedIndexChanged(object sender, EventArgs e)
        {
            if ((m_dtUCCData == null) || (m_dtUCCData.Rows.Count == 0))
                return;

            string l_sFilterExpr = string.Empty;

            if (cboView.SelectedItem != null)
            {
                if (cboView.SelectedItem.ToString() == ViewValid)
                    l_sFilterExpr = "n_ErrorCodeDisp = 0";
                else if (cboView.SelectedItem.ToString() == ViewInvalid)
                    l_sFilterExpr = "n_ErrorCodeDisp <> 0";
            }

            m_dtUCCData.DefaultView.RowFilter = l_sFilterExpr;
            lblNoOfRecords.Text = "#Records: " + m_dtUCCData.DefaultView.Count.ToString();
        }
        #endregion

        #endregion

        #region Methods

        /// <summary>
        /// Opens client help window populating records as per given client code
        /// </summary>
        /// <param name="p_vsClientCode">Filter client code</param>
        /// <returns>Success/return code. 0 = Successful</returns>
        #region ShowClientHelp
        private long ShowClientHelp(string p_vsClientCode)
        {
            frmSearch l_objSearch = new frmSearch();
            l_objSearch.SearchTypeCurrent = frmSearch.SearchType.Client;
            l_objSearch.SearchValueCurrent = frmSearch.SearchValue.ClientCode;
            l_objSearch.SearchText = txtClientCode.Text;

            if (l_objSearch.ShowDialog() == DialogResult.OK)
            {
                m_bValidClientValueSet = true;
                txtClientCode.Text = l_objSearch.SelectedCode;
            }
            else
            {
                txtClientCode.Text = string.Empty;
            }

            return 0;
        }
        #endregion

        /// <summary>
        /// Formats data layout of grid. Sets visible columns, their titles.
        /// </summary>
        #region FormatGrid
        private void FormatGrid()
        {
            if (dgvExport.DataSource == null)
                return;

            for (int l_iColCounter = 0; l_iColCounter < dgvExport.Cols.Count; l_iColCounter++)
            {
                dgvExport.Cols[l_iColCounter].Visible = false;
                dgvExport.Cols[l_iColCounter].AllowEditing = false;
            }

            if(dgvExport.Cols.Contains(SelectColName))
            {
                dgvExport.Cols[SelectColName].Visible = true;
                dgvExport.Cols[SelectColName].AllowEditing = true;
                dgvExport.Cols[SelectColName].Caption = "Select";
                dgvExport.Cols[SelectColName].Move(dgvExport.Cols.Fixed);
                dgvExport.Cols[SelectColName].Width = 40;
            }

            if(dgvExport.Cols.Contains("s_TradingCodeDisp"))
            {
                dgvExport.Cols["s_TradingCodeDisp"].Visible = true;
                dgvExport.Cols["s_TradingCodeDisp"].Caption = "Trading Code";
                dgvExport.Cols["s_TradingCodeDisp"].Width = 110;
            }
            if(dgvExport.Cols.Contains("s_ClientNameDisp"))
            {
                dgvExport.Cols["s_ClientNameDisp"].Visible = true;
                dgvExport.Cols["s_ClientNameDisp"].Caption = "Client Name";
                dgvExport.Cols["s_ClientNameDisp"].Width = 300;
            }
            //if(dgvExport.Cols.Contains("n_ErrorCodeDisp"))
            //{
            //    dgvExport.Cols["n_ErrorCodeDisp"].Visible = true;
            //    dgvExport.Cols["n_ErrorCodeDisp"].Caption = "Select";
            //}
            if (dgvExport.Cols.Contains("s_ErrorDescDisp"))
            {
                dgvExport.Cols["s_ErrorDescDisp"].Visible = true;
                dgvExport.Cols["s_ErrorDescDisp"].Caption = "Error Description";
                dgvExport.Cols["s_ErrorDescDisp"].Width = 500;
            }
        }
        #endregion

        private void EnableDisableNewModifiedCombo()
        {
            DataRowView ExchRow = cboExchangeCode.SelectedItem as DataRowView;
            if (ExchRow != null)
            {
                if (ExchRow.Row["s_ExType"].ToString() == "NSE")
                    cboRecordType.Enabled = true;
                else
                    cboRecordType.Enabled = false;
            }
        }

        private void cboExchangeCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            EnableDisableNewModifiedCombo();
        }

        #endregion
    }
}
