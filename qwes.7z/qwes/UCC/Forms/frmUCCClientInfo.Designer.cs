﻿namespace UCC.Forms
{
    partial class frmUCCClientInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmUCCClientInfo));
            this.tbUCCClientInfo = new System.Windows.Forms.TabControl();
            this.PageClientDetails = new System.Windows.Forms.TabPage();
            this.PageClientExchangeMapping = new System.Windows.Forms.TabPage();
            this.pageAddress = new System.Windows.Forms.TabPage();
            this.pageDP = new System.Windows.Forms.TabPage();
            this.pageBank = new System.Windows.Forms.TabPage();
            this.pageValidate = new System.Windows.Forms.TabPage();
            this.menuClientInfo = new MatchCommon.CustomControls.FTMasterMenuStrip();
            this.pnlInfo = new MatchCommon.CustomControls.FTPanel();
            this.lblArrow = new MatchCommon.CustomControls.FTLabel();
            this.lblDetails = new MatchCommon.CustomControls.FTLabel();
            this.lblInfo = new MatchCommon.CustomControls.FTLabel();
            this.pnlTop2 = new System.Windows.Forms.Panel();
            this.lblClientInfo = new MatchCommon.CustomControls.FTLabel();
            this.tbUCCClientInfo.SuspendLayout();
            this.pnlInfo.SuspendLayout();
            this.pnlTop2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbUCCClientInfo
            // 
            this.tbUCCClientInfo.Controls.Add(this.PageClientDetails);
            this.tbUCCClientInfo.Controls.Add(this.PageClientExchangeMapping);
            this.tbUCCClientInfo.Controls.Add(this.pageAddress);
            this.tbUCCClientInfo.Controls.Add(this.pageDP);
            this.tbUCCClientInfo.Controls.Add(this.pageBank);
            this.tbUCCClientInfo.Controls.Add(this.pageValidate);
            this.tbUCCClientInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbUCCClientInfo.Location = new System.Drawing.Point(31, 42);
            this.tbUCCClientInfo.Name = "tbUCCClientInfo";
            this.tbUCCClientInfo.SelectedIndex = 0;
            this.tbUCCClientInfo.Size = new System.Drawing.Size(864, 493);
            this.tbUCCClientInfo.TabIndex = 3;
            this.tbUCCClientInfo.SelectedIndexChanged += new System.EventHandler(this.tbUCCClientInfo_SelectedIndexChanged);
            // 
            // PageClientDetails
            // 
            this.PageClientDetails.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.PageClientDetails.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.PageClientDetails.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(93)))), ((int)(((byte)(93)))));
            this.PageClientDetails.Location = new System.Drawing.Point(4, 22);
            this.PageClientDetails.Name = "PageClientDetails";
            this.PageClientDetails.Size = new System.Drawing.Size(856, 467);
            this.PageClientDetails.TabIndex = 0;
            this.PageClientDetails.Text = "ClientDetails";
            this.PageClientDetails.ToolTipText = "Client Details";
            // 
            // PageClientExchangeMapping
            // 
            this.PageClientExchangeMapping.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.PageClientExchangeMapping.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.PageClientExchangeMapping.Location = new System.Drawing.Point(4, 22);
            this.PageClientExchangeMapping.Name = "PageClientExchangeMapping";
            this.PageClientExchangeMapping.Size = new System.Drawing.Size(856, 446);
            this.PageClientExchangeMapping.TabIndex = 2;
            this.PageClientExchangeMapping.Text = "ClientExchangeMapping";
            this.PageClientExchangeMapping.ToolTipText = "ClientExchangeMapping";
            // 
            // pageAddress
            // 
            this.pageAddress.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.pageAddress.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.pageAddress.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(93)))), ((int)(((byte)(93)))));
            this.pageAddress.Location = new System.Drawing.Point(4, 22);
            this.pageAddress.Name = "pageAddress";
            this.pageAddress.Size = new System.Drawing.Size(856, 446);
            this.pageAddress.TabIndex = 1;
            this.pageAddress.Text = "Address";
            this.pageAddress.ToolTipText = "Address";
            // 
            // pageDP
            // 
            this.pageDP.Location = new System.Drawing.Point(4, 22);
            this.pageDP.Name = "pageDP";
            this.pageDP.Size = new System.Drawing.Size(856, 446);
            this.pageDP.TabIndex = 3;
            this.pageDP.Text = "DP";
            this.pageDP.UseVisualStyleBackColor = true;
            // 
            // pageBank
            // 
            this.pageBank.Location = new System.Drawing.Point(4, 22);
            this.pageBank.Name = "pageBank";
            this.pageBank.Size = new System.Drawing.Size(856, 446);
            this.pageBank.TabIndex = 4;
            this.pageBank.Text = "Bank";
            this.pageBank.UseVisualStyleBackColor = true;
            // 
            // pageValidate
            // 
            this.pageValidate.Location = new System.Drawing.Point(4, 22);
            this.pageValidate.Name = "pageValidate";
            this.pageValidate.Size = new System.Drawing.Size(856, 446);
            this.pageValidate.TabIndex = 4;
            this.pageValidate.Text = "Validate";
            this.pageValidate.UseVisualStyleBackColor = true;
            // 
            // menuClientInfo
            // 
            this.menuClientInfo.AutoSize = false;
            this.menuClientInfo.BackColor = System.Drawing.SystemColors.Window;
            this.menuClientInfo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("menuClientInfo.BackgroundImage")));
            this.menuClientInfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.menuClientInfo.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuClientInfo.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.menuClientInfo.Location = new System.Drawing.Point(0, 0);
            this.menuClientInfo.Name = "menuClientInfo";
            this.menuClientInfo.ShowItemToolTips = true;
            this.menuClientInfo.Size = new System.Drawing.Size(31, 535);
            this.menuClientInfo.TabIndex = 5;
            this.menuClientInfo.Text = "menuStrip1";
            // 
            // pnlInfo
            // 
            this.pnlInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(234)))), ((int)(((byte)(234)))));
            this.pnlInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlInfo.Controls.Add(this.lblArrow);
            this.pnlInfo.Controls.Add(this.lblDetails);
            this.pnlInfo.Controls.Add(this.lblInfo);
            this.pnlInfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlInfo.Location = new System.Drawing.Point(31, 0);
            this.pnlInfo.Name = "pnlInfo";
            this.pnlInfo.Size = new System.Drawing.Size(864, 18);
            this.pnlInfo.TabIndex = 10;
            this.pnlInfo.TabStop = true;
            // 
            // lblArrow
            // 
            this.lblArrow.AllowForeColorChange = false;
            this.lblArrow.AutoSize = true;
            this.lblArrow.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblArrow.ForeColor = System.Drawing.Color.Black;
            this.lblArrow.Location = new System.Drawing.Point(65, 2);
            this.lblArrow.Name = "lblArrow";
            this.lblArrow.OverrideDefault = false;
            this.lblArrow.Size = new System.Drawing.Size(23, 13);
            this.lblArrow.TabIndex = 2;
            this.lblArrow.Text = ">>";
            // 
            // lblDetails
            // 
            this.lblDetails.AllowForeColorChange = false;
            this.lblDetails.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDetails.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblDetails.ForeColor = System.Drawing.Color.Black;
            this.lblDetails.Location = new System.Drawing.Point(91, 2);
            this.lblDetails.Name = "lblDetails";
            this.lblDetails.OverrideDefault = false;
            this.lblDetails.Size = new System.Drawing.Size(622, 12);
            this.lblDetails.TabIndex = 0;
            this.lblDetails.Text = "This screen facilitates entering UCC Client Info.";
            // 
            // lblInfo
            // 
            this.lblInfo.AllowForeColorChange = false;
            this.lblInfo.AutoSize = true;
            this.lblInfo.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblInfo.ForeColor = System.Drawing.Color.Black;
            this.lblInfo.Location = new System.Drawing.Point(6, 2);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.OverrideDefault = false;
            this.lblInfo.Size = new System.Drawing.Size(58, 13);
            this.lblInfo.TabIndex = 1;
            this.lblInfo.Text = "UCC Client";
            // 
            // pnlTop2
            // 
            this.pnlTop2.BackColor = System.Drawing.Color.White;
            this.pnlTop2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop2.Controls.Add(this.lblClientInfo);
            this.pnlTop2.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlTop2.Location = new System.Drawing.Point(31, 18);
            this.pnlTop2.Name = "pnlTop2";
            this.pnlTop2.Size = new System.Drawing.Size(864, 24);
            this.pnlTop2.TabIndex = 0;
            // 
            // lblClientInfo
            // 
            this.lblClientInfo.AllowForeColorChange = false;
            this.lblClientInfo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblClientInfo.AutoSize = true;
            this.lblClientInfo.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblClientInfo.ForeColor = System.Drawing.Color.Black;
            this.lblClientInfo.Location = new System.Drawing.Point(6, 5);
            this.lblClientInfo.Name = "lblClientInfo";
            this.lblClientInfo.OverrideDefault = false;
            this.lblClientInfo.Size = new System.Drawing.Size(57, 13);
            this.lblClientInfo.TabIndex = 1;
            this.lblClientInfo.Text = "Client Info";
            // 
            // frmUCCClientInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(895, 535);
            this.Controls.Add(this.tbUCCClientInfo);
            this.Controls.Add(this.pnlTop2);
            this.Controls.Add(this.pnlInfo);
            this.Controls.Add(this.menuClientInfo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "frmUCCClientInfo";
            this.ShowInTaskbar = false;
            this.Text = "UCC Client Info";
            this.Load += new System.EventHandler(this.UCCClientInfo_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmUCCClientInfo_KeyUp);
            this.tbUCCClientInfo.ResumeLayout(false);
            this.pnlInfo.ResumeLayout(false);
            this.pnlInfo.PerformLayout();
            this.pnlTop2.ResumeLayout(false);
            this.pnlTop2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tbUCCClientInfo;
        private System.Windows.Forms.TabPage PageClientDetails;
        private System.Windows.Forms.TabPage pageAddress;
        private MatchCommon.CustomControls.FTMasterMenuStrip menuClientInfo;
        private MatchCommon.CustomControls.FTTopicBar tbUCCClient;
        private MatchCommon.CustomControls.FTPanel pnlInfo;
        private MatchCommon.CustomControls.FTLabel lblArrow;
        private MatchCommon.CustomControls.FTLabel lblDetails;
        private MatchCommon.CustomControls.FTLabel lblInfo;
        private System.Windows.Forms.TabPage PageClientExchangeMapping;
        private System.Windows.Forms.Panel pnlTop2;
        private MatchCommon.CustomControls.FTLabel lblClientInfo;
        private System.Windows.Forms.TabPage pageDP;
        private System.Windows.Forms.TabPage pageBank;
        private System.Windows.Forms.TabPage pageValidate;
    }
}