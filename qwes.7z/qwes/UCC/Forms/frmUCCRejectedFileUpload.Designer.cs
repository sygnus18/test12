﻿namespace UCC.Forms
{
    partial class frmUCCRejectedFileUpload
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmUCCRejectedFileUpload));
            this.menuUCCRejectedFileUpload = new MatchCommon.CustomControls.FTMasterMenuStrip();
            this.pnlInfo = new MatchCommon.CustomControls.FTPanel();
            this.lblArrow = new MatchCommon.CustomControls.FTLabel();
            this.lblDetails = new MatchCommon.CustomControls.FTLabel();
            this.lblInfo = new MatchCommon.CustomControls.FTLabel();
            this.tbUCCClient = new MatchCommon.CustomControls.FTTopicBar();
            this.pnlTop1 = new MatchCommon.CustomControls.FTPanel();
            this.btnClose = new MatchCommon.CustomControls.FTButton();
            this.btnClear = new MatchCommon.CustomControls.FTButton();
            this.btnUpload = new MatchCommon.CustomControls.FTButton();
            this.cboExchange = new MatchCommon.CustomControls.FTComboBox();
            this.lblExchange = new MatchCommon.CustomControls.FTLabel();
            this.pnlBottom = new MatchCommon.CustomControls.FTPanel();
            this.lblStatus = new MatchCommon.CustomControls.FTLabel();
            this.pnlRejectionDetail = new MatchCommon.CustomControls.FTPanel();
            this.dgRejectionDetail = new MatchCommon.CustomControls.FTDataGrid();
            this.cboRecordType = new MatchCommon.CustomControls.FTComboBox();
            this.lblRecordType = new MatchCommon.CustomControls.FTLabel();
            this.pnlInfo.SuspendLayout();
            this.pnlTop1.SuspendLayout();
            this.pnlBottom.SuspendLayout();
            this.pnlRejectionDetail.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgRejectionDetail)).BeginInit();
            this.SuspendLayout();
            // 
            // menuUCCRejectedFileUpload
            // 
            this.menuUCCRejectedFileUpload.AutoSize = false;
            this.menuUCCRejectedFileUpload.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(183)))), ((int)(((byte)(246)))));
            this.menuUCCRejectedFileUpload.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.menuUCCRejectedFileUpload.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuUCCRejectedFileUpload.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.menuUCCRejectedFileUpload.Location = new System.Drawing.Point(0, 0);
            this.menuUCCRejectedFileUpload.Name = "menuUCCRejectedFileUpload";
            this.menuUCCRejectedFileUpload.ShowItemToolTips = true;
            this.menuUCCRejectedFileUpload.Size = new System.Drawing.Size(27, 472);
            this.menuUCCRejectedFileUpload.TabIndex = 15;
            this.menuUCCRejectedFileUpload.Text = "ftMasterMenuStrip1";
            // 
            // pnlInfo
            // 
            this.pnlInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(234)))), ((int)(((byte)(234)))));
            this.pnlInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlInfo.Controls.Add(this.lblArrow);
            this.pnlInfo.Controls.Add(this.lblDetails);
            this.pnlInfo.Controls.Add(this.lblInfo);
            this.pnlInfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlInfo.Location = new System.Drawing.Point(27, 21);
            this.pnlInfo.Name = "pnlInfo";
            this.pnlInfo.Size = new System.Drawing.Size(765, 25);
            this.pnlInfo.TabIndex = 17;
            this.pnlInfo.TabStop = true;
            // 
            // lblArrow
            // 
            this.lblArrow.AllowForeColorChange = false;
            this.lblArrow.AutoSize = true;
            this.lblArrow.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblArrow.ForeColor = System.Drawing.Color.Black;
            this.lblArrow.Location = new System.Drawing.Point(126, 5);
            this.lblArrow.Name = "lblArrow";
            this.lblArrow.OverrideDefault = false;
            this.lblArrow.Size = new System.Drawing.Size(19, 12);
            this.lblArrow.TabIndex = 2;
            this.lblArrow.Text = ">>";
            // 
            // lblDetails
            // 
            this.lblDetails.AllowForeColorChange = false;
            this.lblDetails.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDetails.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblDetails.ForeColor = System.Drawing.Color.Black;
            this.lblDetails.Location = new System.Drawing.Point(175, 5);
            this.lblDetails.Name = "lblDetails";
            this.lblDetails.OverrideDefault = false;
            this.lblDetails.Size = new System.Drawing.Size(566, 12);
            this.lblDetails.TabIndex = 1;
            this.lblDetails.Text = "This window facilitates an option to upload the exchange provided UCC rejection f" +
                "ile.";
            // 
            // lblInfo
            // 
            this.lblInfo.AllowForeColorChange = false;
            this.lblInfo.AutoSize = true;
            this.lblInfo.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblInfo.ForeColor = System.Drawing.Color.Black;
            this.lblInfo.Location = new System.Drawing.Point(4, 5);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.OverrideDefault = false;
            this.lblInfo.Size = new System.Drawing.Size(120, 12);
            this.lblInfo.TabIndex = 0;
            this.lblInfo.Text = "UCC Rejected File Upload";
            // 
            // tbUCCClient
            // 
            this.tbUCCClient.Dock = System.Windows.Forms.DockStyle.Top;
            this.tbUCCClient.InformationBarPanel = this.pnlInfo;
            this.tbUCCClient.Location = new System.Drawing.Point(27, 0);
            this.tbUCCClient.Name = "tbUCCClient";
            this.tbUCCClient.Size = new System.Drawing.Size(765, 21);
            this.tbUCCClient.TabIndex = 16;
            this.tbUCCClient.Title = "UCC Rejected File Upload Details";
            // 
            // pnlTop1
            // 
            this.pnlTop1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop1.Controls.Add(this.lblRecordType);
            this.pnlTop1.Controls.Add(this.cboRecordType);
            this.pnlTop1.Controls.Add(this.btnClose);
            this.pnlTop1.Controls.Add(this.btnClear);
            this.pnlTop1.Controls.Add(this.btnUpload);
            this.pnlTop1.Controls.Add(this.cboExchange);
            this.pnlTop1.Controls.Add(this.lblExchange);
            this.pnlTop1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop1.Location = new System.Drawing.Point(27, 46);
            this.pnlTop1.Name = "pnlTop1";
            this.pnlTop1.Size = new System.Drawing.Size(765, 40);
            this.pnlTop1.TabIndex = 18;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Transparent;
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.Location = new System.Drawing.Point(666, 8);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "Close";
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.Transparent;
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btnClear.Image = ((System.Drawing.Image)(resources.GetObject("btnClear.Image")));
            this.btnClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClear.Location = new System.Drawing.Point(583, 8);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 1;
            this.btnClear.Text = "&Clear";
            this.btnClear.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnUpload
            // 
            this.btnUpload.BackColor = System.Drawing.Color.Transparent;
            this.btnUpload.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpload.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btnUpload.Image = ((System.Drawing.Image)(resources.GetObject("btnUpload.Image")));
            this.btnUpload.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUpload.Location = new System.Drawing.Point(500, 8);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(75, 23);
            this.btnUpload.TabIndex = 0;
            this.btnUpload.Text = "&Upload";
            this.btnUpload.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUpload.UseVisualStyleBackColor = false;
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // cboExchange
            // 
            this.cboExchange.BackColor = System.Drawing.Color.White;
            this.cboExchange.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboExchange.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboExchange.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboExchange.ForeColor = System.Drawing.Color.Black;
            this.cboExchange.FormattingEnabled = true;
            this.cboExchange.Location = new System.Drawing.Point(79, 9);
            this.cboExchange.Name = "cboExchange";
            this.cboExchange.ReadOnly = false;
            this.cboExchange.Size = new System.Drawing.Size(148, 20);
            this.cboExchange.TabIndex = 2;
            this.cboExchange.SelectedIndexChanged += new System.EventHandler(this.cboExchange_SelectedIndexChanged);
            // 
            // lblExchange
            // 
            this.lblExchange.AllowForeColorChange = false;
            this.lblExchange.AutoSize = true;
            this.lblExchange.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblExchange.ForeColor = System.Drawing.Color.Black;
            this.lblExchange.Location = new System.Drawing.Point(19, 13);
            this.lblExchange.Name = "lblExchange";
            this.lblExchange.OverrideDefault = false;
            this.lblExchange.Size = new System.Drawing.Size(49, 12);
            this.lblExchange.TabIndex = 0;
            this.lblExchange.Text = "Exchange";
            // 
            // pnlBottom
            // 
            this.pnlBottom.Controls.Add(this.lblStatus);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(27, 437);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(765, 35);
            this.pnlBottom.TabIndex = 19;
            // 
            // lblStatus
            // 
            this.lblStatus.AllowForeColorChange = false;
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblStatus.ForeColor = System.Drawing.Color.Black;
            this.lblStatus.Location = new System.Drawing.Point(19, 5);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.OverrideDefault = false;
            this.lblStatus.Size = new System.Drawing.Size(42, 12);
            this.lblStatus.TabIndex = 1;
            this.lblStatus.Text = "Status : ";
            // 
            // pnlRejectionDetail
            // 
            this.pnlRejectionDetail.Controls.Add(this.dgRejectionDetail);
            this.pnlRejectionDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlRejectionDetail.Location = new System.Drawing.Point(27, 86);
            this.pnlRejectionDetail.Name = "pnlRejectionDetail";
            this.pnlRejectionDetail.Size = new System.Drawing.Size(765, 351);
            this.pnlRejectionDetail.TabIndex = 20;
            // 
            // dgRejectionDetail
            // 
            this.dgRejectionDetail.AllowEditing = false;
            this.dgRejectionDetail.AllowResizing = C1.Win.C1FlexGrid.AllowResizingEnum.Both;
            this.dgRejectionDetail.BackColor = System.Drawing.Color.Transparent;
            this.dgRejectionDetail.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.None;
            this.dgRejectionDetail.ColumnInfo = "5,1,0,0,0,95,Columns:0{Width:30;}\t1{Width:91;}\t";
            this.dgRejectionDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgRejectionDetail.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.None;
            this.dgRejectionDetail.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgRejectionDetail.ForeColor = System.Drawing.Color.Black;
            this.dgRejectionDetail.KeyActionTab = C1.Win.C1FlexGrid.KeyActionEnum.MoveAcrossOut;
            this.dgRejectionDetail.Location = new System.Drawing.Point(0, 0);
            this.dgRejectionDetail.Name = "dgRejectionDetail";
            this.dgRejectionDetail.OverrideDefault = false;
            this.dgRejectionDetail.Rows.Count = 10;
            this.dgRejectionDetail.Rows.DefaultSize = 19;
            this.dgRejectionDetail.Rows.MinSize = 25;
            this.dgRejectionDetail.RowsFilter.AddFilterRow = false;
            this.dgRejectionDetail.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.ListBox;
            this.dgRejectionDetail.Size = new System.Drawing.Size(765, 351);
            this.dgRejectionDetail.StyleInfo = resources.GetString("dgRejectionDetail.StyleInfo");
            this.dgRejectionDetail.TabIndex = 0;
            // 
            // cboRecordType
            // 
            this.cboRecordType.BackColor = System.Drawing.Color.White;
            this.cboRecordType.DisplayMember = "New";
            this.cboRecordType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboRecordType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboRecordType.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboRecordType.ForeColor = System.Drawing.Color.Black;
            this.cboRecordType.FormattingEnabled = true;
            this.cboRecordType.Location = new System.Drawing.Point(332, 9);
            this.cboRecordType.MaxLength = 25;
            this.cboRecordType.Name = "cboRecordType";
            this.cboRecordType.ReadOnly = false;
            this.cboRecordType.Size = new System.Drawing.Size(93, 20);
            this.cboRecordType.TabIndex = 19;
            this.cboRecordType.ValueMember = "1";
            // 
            // lblRecordType
            // 
            this.lblRecordType.AllowForeColorChange = false;
            this.lblRecordType.AutoSize = true;
            this.lblRecordType.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.lblRecordType.ForeColor = System.Drawing.Color.Black;
            this.lblRecordType.Location = new System.Drawing.Point(257, 13);
            this.lblRecordType.Name = "lblRecordType";
            this.lblRecordType.OverrideDefault = false;
            this.lblRecordType.Size = new System.Drawing.Size(63, 12);
            this.lblRecordType.TabIndex = 20;
            this.lblRecordType.Text = "Record Type";
            // 
            // frmUCCRejectedFileUpload
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(792, 472);
            this.Controls.Add(this.pnlRejectionDetail);
            this.Controls.Add(this.pnlBottom);
            this.Controls.Add(this.pnlTop1);
            this.Controls.Add(this.pnlInfo);
            this.Controls.Add(this.tbUCCClient);
            this.Controls.Add(this.menuUCCRejectedFileUpload);
            this.MainMenuStrip = this.menuUCCRejectedFileUpload;
            this.Name = "frmUCCRejectedFileUpload";
            this.ShowInTaskbar = false;
            this.Text = "UCC Rejected File Upload";
            this.Load += new System.EventHandler(this.frmUCCRejectedFileUpload_Load);
            this.pnlInfo.ResumeLayout(false);
            this.pnlInfo.PerformLayout();
            this.pnlTop1.ResumeLayout(false);
            this.pnlTop1.PerformLayout();
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.pnlRejectionDetail.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgRejectionDetail)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MatchCommon.CustomControls.FTMasterMenuStrip menuUCCRejectedFileUpload;
        private MatchCommon.CustomControls.FTPanel pnlInfo;
        private MatchCommon.CustomControls.FTLabel lblArrow;
        private MatchCommon.CustomControls.FTLabel lblDetails;
        private MatchCommon.CustomControls.FTLabel lblInfo;
        private MatchCommon.CustomControls.FTTopicBar tbUCCClient;
        private MatchCommon.CustomControls.FTPanel pnlTop1;
        private MatchCommon.CustomControls.FTComboBox cboExchange;
        private MatchCommon.CustomControls.FTLabel lblExchange;
        private MatchCommon.CustomControls.FTPanel pnlBottom;
        private MatchCommon.CustomControls.FTButton btnClear;
        private MatchCommon.CustomControls.FTButton btnUpload;
        private MatchCommon.CustomControls.FTPanel pnlRejectionDetail;
        private MatchCommon.CustomControls.FTLabel lblStatus;
        private MatchCommon.CustomControls.FTDataGrid dgRejectionDetail;
        private MatchCommon.CustomControls.FTButton btnClose;
        private MatchCommon.CustomControls.FTComboBox cboRecordType;
        private MatchCommon.CustomControls.FTLabel lblRecordType;
    }
}