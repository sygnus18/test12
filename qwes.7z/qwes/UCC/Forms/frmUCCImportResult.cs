﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using C1.Win.C1FlexGrid;

using FTIL.Match.Common.Log;

namespace UCC.Forms
{
    /// <summary>
    /// Window to display/export UCC data synchronize result
    /// </summary>
    public partial class frmUCCImportResult : Form
    {
        #region Variables

        /// <summary>
        /// Synchronize result data DataTable
        /// </summary>
        private DataTable m_dtUCCImportResultData;

        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        #region Constructor
        public frmUCCImportResult()
        {
            InitializeComponent();

            dgvImportResult.OverrideDefault = true;
            dgvImportResult.Styles.Normal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dgvImportResult.Styles.Alternate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
        }
        #endregion

        #region Events

        /// <summary>
        /// Exports grid data to excel file at user defined path
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnExportToExcel_Click
        private void btnExportToExcel_Click(object sender, EventArgs e)
        {
            OpenFileDialog l_objFile = new OpenFileDialog();
            l_objFile.CheckFileExists = false;
            l_objFile.CheckPathExists = true;
            l_objFile.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory;
            l_objFile.DefaultExt = "xls";

            string l_sFilePath = string.Empty;
            if (l_objFile.ShowDialog() == DialogResult.OK)
            {
                l_sFilePath = l_objFile.FileName;
            }

            try
            {
                dgvImportResult.SaveExcel(l_sFilePath, FileFlags.IncludeFixedCells | FileFlags.VisibleOnly);
                MessageBox.Show("Exported Successfully", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "Error exporting data to excel file", ex);
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
        }
        #endregion

        /// <summary>
        /// Closes current window
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region btnClose_Click
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion

        #endregion

        #region Methods

        /// <summary>
        /// Sets import result data in grid and performs grid formatting
        /// </summary>
        #region SetResultData
        private void SetResultData()
        {
            dgvImportResult.DataSource = m_dtUCCImportResultData;

            for (int l_iColCounter = 0; l_iColCounter < dgvImportResult.Cols.Count; l_iColCounter++)
                dgvImportResult.Cols[l_iColCounter].Visible = false;

            if (dgvImportResult.Cols.Contains("s_ClientCode"))
            {
                dgvImportResult.Cols["s_ClientCode"].Visible = true;
                dgvImportResult.Cols["s_ClientCode"].Caption = "Client Code";
            }
            if (dgvImportResult.Cols.Contains("s_Country"))
            {
                dgvImportResult.Cols["s_Country"].Visible = true;
                dgvImportResult.Cols["s_Country"].Caption = "Country";
            }
            if (dgvImportResult.Cols.Contains("s_City"))
            {
                dgvImportResult.Cols["s_City"].Visible = true;
                dgvImportResult.Cols["s_City"].Caption = "City";
            }
            if (dgvImportResult.Cols.Contains("s_ErrorDesc"))
            {
                dgvImportResult.Cols["s_ErrorDesc"].Visible = true;
                dgvImportResult.Cols["s_ErrorDesc"].Caption = "Error Description";
                dgvImportResult.Cols["s_ErrorDesc"].Width = 300;
            }
        }
        #endregion

        #endregion

        #region Properties

        #region UCCImportResultData
        public DataTable UCCImportResultData
        {
            get { return m_dtUCCImportResultData; }
            set 
            { 
                m_dtUCCImportResultData = value;
                SetResultData();
            }
        }
        #endregion

        #endregion
    }
}
