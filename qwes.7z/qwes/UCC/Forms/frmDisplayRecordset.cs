﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using FTIL.Match.Common.Log;
using System.IO;
using FTIL.Match.Common.Constants;

namespace UCC.Forms
{
    public partial class frmDisplayRecordset : Form
    {
        #region Variables

        private string m_sWindowTitle;
        private string m_sRecordsetMessage;
        private DataTable m_dtInputData;

        private Dictionary<string, string> dicDisplayColumns;

        #endregion

        #region Constructor
        public frmDisplayRecordset()
        {
            InitializeComponent();

            dicDisplayColumns = new Dictionary<string, string>();
        }
        #endregion

        #region Events

        #region frmDisplayRecordset_Load
        private void frmDisplayRecordset_Load(object sender, EventArgs e)
        {
            
        }
        #endregion

        #region frmDisplayRecordset_Shown
        private void frmDisplayRecordset_Shown(object sender, EventArgs e)
        {
            if (InputData == null)
            {
                this.Close();
                return;
            }

            dgvClients.DataSource = InputData;
            FormatGrid();
        }
        #endregion
        
        #region btnClose_Click
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion

        #region btnExportToCSV_Click
        private void btnExportToCSV_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderDialog = new FolderBrowserDialog();
            folderDialog.Description = "Select file to export data";
            folderDialog.SelectedPath = AppDomain.CurrentDomain.BaseDirectory;
            folderDialog.ShowNewFolderButton = true;
            if(folderDialog.ShowDialog() != System.Windows.Forms.DialogResult.OK)
                return;

            try
            {
                string sFilePath = Path.Combine(folderDialog.SelectedPath, "Data_" + DateTime.Now.ToString(Formatting.Instance.LONG_DATE_UNIVERSAL_FORMAT_PLAIN) + ".csv");
                using (StreamWriter sw = new StreamWriter(sFilePath))
                {
                    for (int iRowCounter = 0; iRowCounter < dgvClients.Rows.Count; iRowCounter++)
                    {
                        StringBuilder l_sbAllLines = new StringBuilder();
                        string l_sSeperator = string.Empty;
                        for (int iColCounter = 0; iColCounter < dgvClients.Columns.Count; iColCounter++)
                        {
                            l_sbAllLines.Append(l_sSeperator + dgvClients.Rows[iRowCounter].Cells[iColCounter].Value.ToString());
                            l_sSeperator = ",";
                        }
                        sw.WriteLine(l_sbAllLines.ToString());
                    }
                }

                MessageBox.Show("Exported successfully", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Export failed. " + ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }
        #endregion

        #endregion

        #region Methods

        #region FormatGrid
        private void FormatGrid()
        {
            foreach (DataGridViewColumn col in dgvClients.Columns)
                col.Visible = false;

            foreach(KeyValuePair<string, string> DisplayColumn in dicDisplayColumns)
            {
                if (dgvClients.Columns.Contains(DisplayColumn.Key))
                {
                    dgvClients.Columns[DisplayColumn.Key].HeaderText = DisplayColumn.Value;
                    dgvClients.Columns[DisplayColumn.Key].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                    dgvClients.Columns[DisplayColumn.Key].Visible = true;
                }
            }
        }
        #endregion
        
        #endregion

        #region Properties

        public string DataTitle
        {
            get { return m_sRecordsetMessage; }
            set { 
                m_sRecordsetMessage = value;
                lblDisplayText.Text = value;
            }
        }

        public string WindowTitle
        {
            get { return m_sWindowTitle; }
            set { 
                m_sWindowTitle = value;
                this.Text = value;
            }
        }

        public DataTable InputData
        {
            get { return m_dtInputData; }
            set { m_dtInputData = value; }
        }

        public Dictionary<string, string> DisplayColumns
        {
            get { return dicDisplayColumns; }
            set { dicDisplayColumns = value; }
        }

        public EventHandler OnGridDoubleClick
        {
            set
            {
                dgvClients.DoubleClick += value;
            }
            get { return null; }
        }

        #endregion

        #region frmDisplayRecordset_KeyUp
        private void frmDisplayRecordset_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                this.Close();
        }
        #endregion


    }
}
