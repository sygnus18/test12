﻿namespace UCC.Forms
{
    partial class frmClientFilter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmClientFilter));
            this.ftLabel30 = new MatchCommon.CustomControls.FTLabel();
            this.txtClientCode = new MatchCommon.CustomControls.FTTextBox();
            this.btnApply = new System.Windows.Forms.Button();
            this.txtClientName = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel29 = new MatchCommon.CustomControls.FTLabel();
            this.ftLabel59 = new MatchCommon.CustomControls.FTLabel();
            this.cboExchangeCode = new MatchCommon.CustomControls.FTComboBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.ftLabel1 = new MatchCommon.CustomControls.FTLabel();
            this.txtBranch = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel2 = new MatchCommon.CustomControls.FTLabel();
            this.txtG3 = new MatchCommon.CustomControls.FTTextBox();
            this.ftLabel3 = new MatchCommon.CustomControls.FTLabel();
            this.dtpFromCreationDate = new MatchCommon.CustomControls.FTDateTimePicker();
            this.dtpToCreationDate = new MatchCommon.CustomControls.FTDateTimePicker();
            this.ftLabel4 = new MatchCommon.CustomControls.FTLabel();
            this.SuspendLayout();
            // 
            // ftLabel30
            // 
            this.ftLabel30.AllowForeColorChange = false;
            this.ftLabel30.AutoSize = true;
            this.ftLabel30.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel30.ForeColor = System.Drawing.Color.Black;
            this.ftLabel30.Location = new System.Drawing.Point(24, 50);
            this.ftLabel30.Name = "ftLabel30";
            this.ftLabel30.OverrideDefault = false;
            this.ftLabel30.Size = new System.Drawing.Size(29, 12);
            this.ftLabel30.TabIndex = 2;
            this.ftLabel30.Text = "Code";
            // 
            // txtClientCode
            // 
            this.txtClientCode.AllowAlpha = true;
            this.txtClientCode.AllowDot = true;
            this.txtClientCode.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtClientCode.AllowedCustomCharacters")));
            this.txtClientCode.AllowNonASCII = false;
            this.txtClientCode.AllowNumeric = true;
            this.txtClientCode.AllowSpace = true;
            this.txtClientCode.AllowSpecialChars = true;
            this.txtClientCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtClientCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtClientCode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtClientCode.ForeColor = System.Drawing.Color.Black;
            this.txtClientCode.IsEmailID = true;
            this.txtClientCode.IsEmailIdValid = false;
            this.txtClientCode.Location = new System.Drawing.Point(102, 48);
            this.txtClientCode.Name = "txtClientCode";
            this.txtClientCode.Size = new System.Drawing.Size(147, 20);
            this.txtClientCode.TabIndex = 3;
            this.txtClientCode.TextChanged += new System.EventHandler(this.txtClientCode_TextChanged);
            this.txtClientCode.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtClientCode_KeyUp);
            this.txtClientCode.Leave += new System.EventHandler(this.txtClientCode_Leave);
            // 
            // btnApply
            // 
            this.btnApply.BackColor = System.Drawing.Color.Transparent;
            this.btnApply.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnApply.Image = ((System.Drawing.Image)(resources.GetObject("btnApply.Image")));
            this.btnApply.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnApply.Location = new System.Drawing.Point(138, 229);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new System.Drawing.Size(75, 23);
            this.btnApply.TabIndex = 14;
            this.btnApply.Text = "&Apply";
            this.btnApply.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnApply.UseVisualStyleBackColor = false;
            this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
            // 
            // txtClientName
            // 
            this.txtClientName.AllowAlpha = true;
            this.txtClientName.AllowDot = true;
            this.txtClientName.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtClientName.AllowedCustomCharacters")));
            this.txtClientName.AllowNonASCII = false;
            this.txtClientName.AllowNumeric = true;
            this.txtClientName.AllowSpace = true;
            this.txtClientName.AllowSpecialChars = true;
            this.txtClientName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtClientName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtClientName.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtClientName.ForeColor = System.Drawing.Color.Black;
            this.txtClientName.IsEmailID = true;
            this.txtClientName.IsEmailIdValid = false;
            this.txtClientName.Location = new System.Drawing.Point(102, 83);
            this.txtClientName.Name = "txtClientName";
            this.txtClientName.Size = new System.Drawing.Size(324, 20);
            this.txtClientName.TabIndex = 5;
            this.txtClientName.Leave += new System.EventHandler(this.txtClientName_Leave);
            // 
            // ftLabel29
            // 
            this.ftLabel29.AllowForeColorChange = false;
            this.ftLabel29.AutoSize = true;
            this.ftLabel29.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel29.ForeColor = System.Drawing.Color.Black;
            this.ftLabel29.Location = new System.Drawing.Point(24, 86);
            this.ftLabel29.Name = "ftLabel29";
            this.ftLabel29.OverrideDefault = false;
            this.ftLabel29.Size = new System.Drawing.Size(30, 12);
            this.ftLabel29.TabIndex = 4;
            this.ftLabel29.Text = "Name";
            // 
            // ftLabel59
            // 
            this.ftLabel59.AllowForeColorChange = false;
            this.ftLabel59.AutoSize = true;
            this.ftLabel59.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel59.ForeColor = System.Drawing.Color.Black;
            this.ftLabel59.Location = new System.Drawing.Point(24, 16);
            this.ftLabel59.Name = "ftLabel59";
            this.ftLabel59.OverrideDefault = false;
            this.ftLabel59.Size = new System.Drawing.Size(49, 12);
            this.ftLabel59.TabIndex = 0;
            this.ftLabel59.Text = "Exchange";
            // 
            // cboExchangeCode
            // 
            this.cboExchangeCode.BackColor = System.Drawing.Color.White;
            this.cboExchangeCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboExchangeCode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboExchangeCode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.cboExchangeCode.ForeColor = System.Drawing.Color.Black;
            this.cboExchangeCode.FormattingEnabled = true;
            this.cboExchangeCode.Location = new System.Drawing.Point(102, 13);
            this.cboExchangeCode.MaxLength = 25;
            this.cboExchangeCode.Name = "cboExchangeCode";
            this.cboExchangeCode.ReadOnly = false;
            this.cboExchangeCode.Size = new System.Drawing.Size(147, 20);
            this.cboExchangeCode.TabIndex = 1;
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.Transparent;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.Image")));
            this.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancel.Location = new System.Drawing.Point(236, 229);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 15;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // ftLabel1
            // 
            this.ftLabel1.AllowForeColorChange = false;
            this.ftLabel1.AutoSize = true;
            this.ftLabel1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel1.ForeColor = System.Drawing.Color.Black;
            this.ftLabel1.Location = new System.Drawing.Point(24, 121);
            this.ftLabel1.Name = "ftLabel1";
            this.ftLabel1.OverrideDefault = false;
            this.ftLabel1.Size = new System.Drawing.Size(37, 12);
            this.ftLabel1.TabIndex = 6;
            this.ftLabel1.Text = "Branch";
            // 
            // txtBranch
            // 
            this.txtBranch.AllowAlpha = true;
            this.txtBranch.AllowDot = true;
            this.txtBranch.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtBranch.AllowedCustomCharacters")));
            this.txtBranch.AllowNonASCII = false;
            this.txtBranch.AllowNumeric = true;
            this.txtBranch.AllowSpace = true;
            this.txtBranch.AllowSpecialChars = true;
            this.txtBranch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBranch.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtBranch.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtBranch.ForeColor = System.Drawing.Color.Black;
            this.txtBranch.IsEmailID = true;
            this.txtBranch.IsEmailIdValid = false;
            this.txtBranch.Location = new System.Drawing.Point(102, 119);
            this.txtBranch.Name = "txtBranch";
            this.txtBranch.Size = new System.Drawing.Size(147, 20);
            this.txtBranch.TabIndex = 7;
            this.txtBranch.TextChanged += new System.EventHandler(this.txtBranch_TextChanged);
            this.txtBranch.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtBranch_KeyUp);
            this.txtBranch.Leave += new System.EventHandler(this.txtBranch_Leave);
            // 
            // ftLabel2
            // 
            this.ftLabel2.AllowForeColorChange = false;
            this.ftLabel2.AutoSize = true;
            this.ftLabel2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel2.ForeColor = System.Drawing.Color.Black;
            this.ftLabel2.Location = new System.Drawing.Point(24, 157);
            this.ftLabel2.Name = "ftLabel2";
            this.ftLabel2.OverrideDefault = false;
            this.ftLabel2.Size = new System.Drawing.Size(17, 12);
            this.ftLabel2.TabIndex = 8;
            this.ftLabel2.Text = "G3";
            // 
            // txtG3
            // 
            this.txtG3.AllowAlpha = true;
            this.txtG3.AllowDot = true;
            this.txtG3.AllowedCustomCharacters = ((System.Collections.Generic.List<char>)(resources.GetObject("txtG3.AllowedCustomCharacters")));
            this.txtG3.AllowNonASCII = false;
            this.txtG3.AllowNumeric = true;
            this.txtG3.AllowSpace = true;
            this.txtG3.AllowSpecialChars = true;
            this.txtG3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtG3.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtG3.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.txtG3.ForeColor = System.Drawing.Color.Black;
            this.txtG3.IsEmailID = true;
            this.txtG3.IsEmailIdValid = false;
            this.txtG3.Location = new System.Drawing.Point(102, 155);
            this.txtG3.Name = "txtG3";
            this.txtG3.Size = new System.Drawing.Size(147, 20);
            this.txtG3.TabIndex = 9;
            this.txtG3.TextChanged += new System.EventHandler(this.txtG3_TextChanged);
            this.txtG3.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtG3_KeyUp);
            this.txtG3.Leave += new System.EventHandler(this.txtG3_Leave);
            // 
            // ftLabel3
            // 
            this.ftLabel3.AllowForeColorChange = false;
            this.ftLabel3.AutoSize = true;
            this.ftLabel3.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel3.ForeColor = System.Drawing.Color.Black;
            this.ftLabel3.Location = new System.Drawing.Point(24, 197);
            this.ftLabel3.Name = "ftLabel3";
            this.ftLabel3.OverrideDefault = false;
            this.ftLabel3.Size = new System.Drawing.Size(66, 12);
            this.ftLabel3.TabIndex = 10;
            this.ftLabel3.Text = "Creation Date";
            // 
            // dtpFromCreationDate
            // 
            this.dtpFromCreationDate.BackColor = System.Drawing.Color.White;
            this.dtpFromCreationDate.CustomFormat = "dd/MM/yyyy";
            this.dtpFromCreationDate.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dtpFromCreationDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFromCreationDate.Location = new System.Drawing.Point(102, 191);
            this.dtpFromCreationDate.Name = "dtpFromCreationDate";
            this.dtpFromCreationDate.ReadOnly = false;
            this.dtpFromCreationDate.ShowCheckBox = true;
            this.dtpFromCreationDate.Size = new System.Drawing.Size(92, 20);
            this.dtpFromCreationDate.TabIndex = 11;
            // 
            // dtpToCreationDate
            // 
            this.dtpToCreationDate.BackColor = System.Drawing.Color.White;
            this.dtpToCreationDate.CustomFormat = "dd/MM/yyyy";
            this.dtpToCreationDate.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dtpToCreationDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpToCreationDate.Location = new System.Drawing.Point(229, 191);
            this.dtpToCreationDate.Name = "dtpToCreationDate";
            this.dtpToCreationDate.ReadOnly = false;
            this.dtpToCreationDate.ShowCheckBox = true;
            this.dtpToCreationDate.Size = new System.Drawing.Size(92, 20);
            this.dtpToCreationDate.TabIndex = 13;
            // 
            // ftLabel4
            // 
            this.ftLabel4.AllowForeColorChange = false;
            this.ftLabel4.AutoSize = true;
            this.ftLabel4.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ftLabel4.ForeColor = System.Drawing.Color.Black;
            this.ftLabel4.Location = new System.Drawing.Point(207, 197);
            this.ftLabel4.Name = "ftLabel4";
            this.ftLabel4.OverrideDefault = false;
            this.ftLabel4.Size = new System.Drawing.Size(9, 12);
            this.ftLabel4.TabIndex = 12;
            this.ftLabel4.Text = "-";
            // 
            // frmClientFilter
            // 
            this.AcceptButton = this.btnApply;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(449, 264);
            this.Controls.Add(this.ftLabel4);
            this.Controls.Add(this.dtpToCreationDate);
            this.Controls.Add(this.dtpFromCreationDate);
            this.Controls.Add(this.ftLabel3);
            this.Controls.Add(this.ftLabel2);
            this.Controls.Add(this.txtG3);
            this.Controls.Add(this.ftLabel1);
            this.Controls.Add(this.txtBranch);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.ftLabel59);
            this.Controls.Add(this.cboExchangeCode);
            this.Controls.Add(this.txtClientName);
            this.Controls.Add(this.ftLabel29);
            this.Controls.Add(this.btnApply);
            this.Controls.Add(this.ftLabel30);
            this.Controls.Add(this.txtClientCode);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmClientFilter";
            this.ShowInTaskbar = false;
            this.Text = "Filter";
            this.Load += new System.EventHandler(this.frmClientFilter_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MatchCommon.CustomControls.FTLabel ftLabel30;
        private MatchCommon.CustomControls.FTTextBox txtClientCode;
        private System.Windows.Forms.Button btnApply;
        private MatchCommon.CustomControls.FTTextBox txtClientName;
        private MatchCommon.CustomControls.FTLabel ftLabel29;
        private MatchCommon.CustomControls.FTLabel ftLabel59;
        private MatchCommon.CustomControls.FTComboBox cboExchangeCode;
        private System.Windows.Forms.Button btnCancel;
        private MatchCommon.CustomControls.FTLabel ftLabel1;
        private MatchCommon.CustomControls.FTTextBox txtBranch;
        private MatchCommon.CustomControls.FTLabel ftLabel2;
        private MatchCommon.CustomControls.FTTextBox txtG3;
        private MatchCommon.CustomControls.FTLabel ftLabel3;
        private MatchCommon.CustomControls.FTDateTimePicker dtpFromCreationDate;
        private MatchCommon.CustomControls.FTDateTimePicker dtpToCreationDate;
        private MatchCommon.CustomControls.FTLabel ftLabel4;
    }
}