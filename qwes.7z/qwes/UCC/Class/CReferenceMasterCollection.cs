﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UCC.Class
{
    public class CReferenceMasterCollection
    {
        private Dictionary<string, List<CReferenceMaster>> m_dicRefMasterCollection;

        public CReferenceMasterCollection(string ReferenceType)
        {
            _ReferenceType = ReferenceType;
        }

        public string _ReferenceType;
        public string ReferenceType
        {
            get { return _ReferenceType; }
        }
    }
}
