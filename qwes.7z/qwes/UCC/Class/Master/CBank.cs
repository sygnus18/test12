﻿using System;
using System.Collections.Generic;
using System.Text;
using FTIL.Match.Common.Db;
using System.Data;
using FTIL.Match.Common;
using FTIL.Match.Common.Log;

namespace UCC.Class.Master
{
    /// <summary>
    /// This class represents Bank entity
    /// </summary>
    public class CBank
    {
        #region Constructor
        /// <summary>
        /// Initializes new instance of CBank using Bank Code
        /// </summary>
        /// <param name="BankCode"></param>
        public CBank(int BankNo, string BankCode, string BankName, string MICRCode)
        {
            _BankNo = BankNo;
            _BankCode = BankCode;
            _BankName = BankName;
            _MICRCode = MICRCode;
        }
        #endregion

        #region Properties

        #region BankNo
        private int _BankNo;
        /// <summary>
        /// Bank No
        /// </summary>
        public int BankNo
        {
            get { return _BankNo; }
        }
        #endregion

        #region BankCode
        private string _BankCode;
        /// <summary>
        /// Bank Code
        /// </summary>
        public string BankCode
        {
            get { return _BankCode; }
        }
        #endregion

        #region BankName
        private string _BankName;
        /// <summary>
        /// Bank Name
        /// </summary>
        public string BankName
        {
            get { return _BankName; }
        }
        #endregion

        #region MICRCode
        private string _MICRCode;
        /// <summary>
        /// MICR Code
        /// </summary>
        public string MICRCode
        {
            get { return _MICRCode; }
        }
        #endregion

        #endregion
    }
}
