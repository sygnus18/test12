﻿using System;
using System.Collections.Generic;
using System.Text;
using FTIL.Match.Common.Db;
using System.Data;
using FTIL.Match.Common;
using FTIL.Match.Common.Log;

namespace UCC.Class.Master
{
    /// <summary>
    /// This class represents DP entity
    /// </summary>
    public class CClientDPCollection
    {
        #region Variables

        /// <summary>
        /// Indicates if current instance has been initialized from database
        /// </summary>
        private bool m_bInitialized;

        #endregion

        #region Constructor
        /// <summary>
        /// Initializes new instance of CClientDPCollection using ClientDPNo
        /// </summary>
        /// <param name="n_ClientDPNo">Unique ClientDPNo</param>
        public CClientDPCollection(int n_ClientNo,int p_nUserNo)
        {
            _ClientNo = n_ClientNo;
            Initialize(p_nUserNo);
        }
        #endregion

        #region Methods

        #region Initialize
        /// <summary>
        /// Initializes current instance from database for given ClientNo
        /// </summary>
        private void Initialize(int p_nUserNo)
        {
            if (m_bInitialized)
                return;

            m_bInitialized = true;

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCRetrieveClientDPData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, this.ClientNo);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, p_nUserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                {
                    Logger.Instance.WriteLog(this, "Initalizing DP. No data found. ClientNo: " + this.ClientNo.ToString());
                }
                else
                {
                    if ((l_dsReturnData.Tables.Count > 1) && (l_dsReturnData.Tables[1].Rows.Count > 0))
                    {
                        _DPDetailData = l_dsReturnData.Tables[0];
                        _DPDetailDataUnAuth = l_dsReturnData.Tables[1];
                    }
                    else
                    {
                        _DPDetailData = l_dsReturnData.Tables[0];
                    }
                }
            }
            else
            {
                _LastMethodExecResult = l_objDbWorkItem.ExecutionStatus;
                Logger.Instance.WriteLog(this, l_objDbWorkItem.ExecutionStatus);
            }
        }
        #endregion

        #region GetClientDPDetail
        /// <summary>
        /// ClientDP for a exchange details
        /// </summary>
        /// <param name="pn_ClientDPNo"></param>
        /// <returns>datarow[]</returns>
         public DataRow[] GetClientDPDetail(int pn_ClientDPNo)
        {
            DataRow[] _dr;
            _dr = this.DPDetailData.Select("n_ClientDPNo = " + pn_ClientDPNo);
            return _dr;
        }
        #endregion

        #region GetClientDPDetailUnAuth
        /// <summary>
        /// ClientDP for a exchange UnAuthorised details 
        /// </summary>
        /// <param name="pn_ClientDPNo"></param>
        /// <returns>datarow[]</returns>
        public DataRow[] GetClientDPDetailUnAuth(int pn_ClientDPNo)
        {
            if (this.DPDetailsDataUnAuth != null)
            {
                DataRow[] _dr;
                _dr = this.DPDetailsDataUnAuth.Select("n_ClientDPNo = " + pn_ClientDPNo);
                return _dr;
            }
            else
            {
                return null;
            }
        }
        #endregion

        #region PopulateDPCollection
        /// <summary>
        /// Populate client specific DP in list
        /// </summary>
        private void PopulateDPCollection()
        {
            this.ClientDPs = new List<CClientDP>();
            foreach (DataRow _dr in this.DPDetailData.Rows)
            {
                CClientDP l_ClientDP;
                l_ClientDP = new CClientDP(Convert.ToInt32(_dr["n_ClientDPNo"]));
                l_ClientDP.Initialize(_dr, this);
                this.ClientDPs.Add(l_ClientDP);
            }
        }
        #endregion

        #endregion

        #region Properties

        #region ClientNo
        private Int32 _ClientNo;
        /// <summary>
        /// ClientNo
        /// </summary>
        public Int32 ClientNo
        {
            get { return _ClientNo; }
            set { _ClientNo = value; }
        }
        #endregion

        #region DPDetailData
        private DataTable _DPDetailData;
        /// <summary>
        /// Client DP Detail DataTable
        /// </summary>
        public DataTable DPDetailData
        {
            get { return _DPDetailData; }
        }
        #endregion

        #region DPDetailsDataUnAuth
        private DataTable _DPDetailDataUnAuth;
        /// <summary>
        /// Client Under Authorization DP Details
        /// </summary>
        public DataTable DPDetailsDataUnAuth
        {
            get { return _DPDetailDataUnAuth; }
        }
        #endregion 

        #region LastMethodExecResult
        private MethodExecResult _LastMethodExecResult;
        /// <summary>
        /// Last Method execution result
        /// </summary>
        public MethodExecResult LastMethodExecResult
        {
            get { return _LastMethodExecResult; }
        }
        #endregion

        #region ClientDPs
        /// <summary>
        /// Get or Set Client specific DP Detail list
        /// </summary>
        public List<CClientDP> ClientDPs { get; set; }
        #endregion

        #endregion
    }
}
