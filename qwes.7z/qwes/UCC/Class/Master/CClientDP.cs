﻿using System;
using System.Collections.Generic;
using System.Text;
using FTIL.Match.Common.Db;
using System.Data;
using FTIL.Match.Common;
using FTIL.Match.Common.Log;
using System.ComponentModel;

namespace UCC.Class.Master
{
    /// <summary>
    /// This class represents DP entity
    /// </summary>
    public class CClientDP
    {
        #region Variables

        /// <summary>
        /// Incase of maker/checker ON object contain the Original ClientDP value 
        /// </summary>
        private CClientDP m_objOriginalDP;


        #endregion

        #region Constructor
        /// <summary>
        /// Initializes new instance of CClientDP using ClientDPNo
        /// </summary>
        /// <param name="n_ClientDPNo">Unique ClientDPNo</param>
        public CClientDP(int n_ClientDPNo)
        {
            _ClientDPNo = n_ClientDPNo;
            //Initialize();
        }

        #endregion

        #region Methods

        /// <summary>
        /// Initializes current instance from collection with given ClientDPNo
        /// </summary>
        #region Initialize
        public MethodExecResult Initialize(DataRow DataRow, CClientDPCollection ClientDPCollection)
        {
            try
            {
                MethodExecResult l_MethodExecResult;
                //If under authorisation client, take new changes in main client object and original object in originalClient object
                if (ClientDPCollection.DPDetailsDataUnAuth != null && ClientDPCollection.DPDetailsDataUnAuth.Rows.Count > 0 && ClientDPCollection.DPDetailsDataUnAuth.Select("n_ClientDPNo = " + ClientDPNo).GetLength(0) > 0)
                {
                    DataRow[] _dr;
                    _dr = ClientDPCollection.GetClientDPDetailUnAuth(ClientDPNo);
                    m_objOriginalDP = new CClientDP(this.ClientDPNo);
                    l_MethodExecResult = m_objOriginalDP.InitializeFromDataRow(_dr[0]);
                    l_MethodExecResult = this.InitializeFromDataRow(DataRow);
                }
                else
                {
                    l_MethodExecResult = this.InitializeFromDataRow(DataRow);
                }
                return l_MethodExecResult;
            }
            catch(Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                return new MethodExecResult(1, ex.Message, "Initialize Error processing DataRow", ex);
            }

        }
        #endregion

        /// <summary>
        /// Initializes current instance from DataRow
        /// </summary>
        /// <param name="DataRow">DataRow object containing DP details</param>
        #region InitializeFromDataRow
        private MethodExecResult InitializeFromDataRow(DataRow DataRow)
        {
            try
            {
                this.DPNo = Convert.ToInt32(DataRow["n_DPNo"]);
                this.ClientDPNo = Convert.ToInt32(DataRow["n_ClientDPNo"]);
                this.ClientNo = Convert.ToInt32(DataRow["n_ClientNo"]);
                this.ExNo = Convert.ToInt16(DataRow["n_ExNo"]);
                this.ClientId = DataRow["s_ClientId"].ToString().Trim();
                this.Default = DataRow["s_Default"].ToString().Trim();
                this.POA = DataRow["s_POA"].ToString().Trim();
                if ((DataRow["n_UserNo"] != null) && (DataRow["n_UserNo"] != DBNull.Value))
                    this.UserNo = Convert.ToInt32(DataRow["n_UserNo"]);
                if ((DataRow["d_LastModifiedDateTime"] != null) && (DataRow["d_LastModifiedDateTime"] != DBNull.Value))
                    this.LastModifiedDateTime = Convert.ToDateTime(DataRow["d_LastModifiedDateTime"]);

                if (DataRow["s_AuthorizedStatus"] != DBNull.Value)
                    this.AuthorizedStatus = DataRow["s_AuthorizedStatus"].ToString().Trim();

                return new MethodExecResult(MethodExecResult.SuccessfulReturnCode);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                return new MethodExecResult(1, ex.Message, "InitializeFromDataRow() Error processing DataRow", ex);
            }
        }
        #endregion

        /// <summary>
        /// Updates current instance changes to database
        /// </summary>
        /// <returns>Method Execution Result</returns>
        #region Update
        public MethodExecResult Update()
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCUpdateClientDPData");
            l_objDbWorkItem.ResultType = QueryType.NonQuery;

            l_objDbWorkItem.AddParameter("@pn_ClientDPNo", SqlDbType.Int, this.ClientDPNo);
            l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, this.ClientNo);
            l_objDbWorkItem.AddParameter("@pn_ExNo", SqlDbType.SmallInt, this.ExNo);
            l_objDbWorkItem.AddParameter("@pn_DPNo", SqlDbType.Int, this.DPNo);
            l_objDbWorkItem.AddParameter("@ps_ClientId", SqlDbType.VarChar, this.ClientId);
            l_objDbWorkItem.AddParameter("@ps_Default", SqlDbType.Char, this.Default);
            l_objDbWorkItem.AddParameter("@ps_POA", SqlDbType.Char, this.POA);

            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            return l_objDbWorkItem.ExecutionStatus;
        }
        #endregion

        /// <summary>
        /// Deletes current instance from database
        /// </summary>
        /// <returns>Method Execution Result</returns>
        #region Delete
        public MethodExecResult Delete()
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCDeleteDPData");
            l_objDbWorkItem.ResultType = QueryType.NonQuery;

            l_objDbWorkItem.AddParameter("@pn_ClientDPNo", SqlDbType.Int, this.ClientDPNo);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            return l_objDbWorkItem.ExecutionStatus;
        }
        #endregion

        #endregion

        #region Properties

       
        /// <summary>
        /// Original DP details of current DP (when Maker/Checker enabled)
        /// </summary>
        #region OriginalDP
        public CClientDP OriginalDP
        {
            get { return m_objOriginalDP; }
        }
        #endregion

        /// <summary>
        /// ClientDPNo
        /// </summary>
        #region ClientDPNo
        private Int32 _ClientDPNo;
        public Int32 ClientDPNo
        {
            get { return _ClientDPNo; }
            set { _ClientDPNo = value; }
        }
        #endregion

        #region ClientNo
        private Int32 _ClientNo;
        /// <summary>
        /// ClientNo
        /// </summary>
        public Int32 ClientNo
        {
            get { return _ClientNo; }
            set { _ClientNo = value; }
        }
        #endregion

        #region ExNo
        private Int16 _ExNo;
        /// <summary>
        /// ExNo
        /// </summary>
        public Int16 ExNo
        {
            get { return _ExNo; }
            set { _ExNo = value; }
        }
        #endregion

        #region DPNo
        private Int32 _DPNo;
        /// <summary>
        /// DPNo
        /// </summary>
        public Int32 DPNo
        {
            get { return _DPNo; }
            set { _DPNo = value; }
        }
        #endregion

        #region ClientId
        private string _ClientId;
        /// <summary>
        /// ClientId
        /// </summary>
        public string ClientId
        {
            get { return _ClientId; }
            set { _ClientId = value; }
        }
        #endregion

        #region Default
        private string _Default;
        /// <summary>
        /// Default
        /// </summary>
        public string Default
        {
            get { return _Default; }
            set { _Default = value; }
        }
        #endregion

        #region POA
        private string _POA;
        /// <summary>
        /// POA
        /// </summary>
        public string POA
        {
            get { return _POA; }
            set { _POA = value; }
        }
        #endregion

        #region IsPendingAuth
        private bool _IsPendingAuth;
        /// <summary>
        /// Indicates if current ClientDP  is under authorisation
        /// </summary>
        public bool IsPendingAuth
        {
            get { return _IsPendingAuth; }
            set { _IsPendingAuth = value; }
        }
        #endregion

        #region MakerUser
        private int _MakerUser;
        /// <summary>
        /// Maker User No
        /// </summary>
        public int MakerUser
        {
            get { return _MakerUser; }
            set { _MakerUser = value; }
        }
        #endregion

        #region AllowModificationsToCurrentUser
        /// <summary>
        /// Indicates if current record is under authorisation then current application user can modify it?
        /// </summary>
        public bool AllowModificationsToCurrentUser
        {
            get
            {
                if (
                    (this.IsPendingAuth)
                    && (this.MakerUser != AppEnvironment.AppUser.UserNo)
                  )
                {
                    return false;
                }

                return true;
            }
        }
        #endregion

        #region AuthorizedStatus
        /// <summary>
        /// Authorise status of current record
        /// </summary>
        private string _AuthorizedStatus;
        public string AuthorizedStatus
        {
            get { return _AuthorizedStatus; }
            set { _AuthorizedStatus = value; }
        }
        #endregion

        #region UserNo
        private Int32? _UserNo;
        /// <summary>
        /// UserNo
        /// </summary>
        public Int32? UserNo
        {
            get { return _UserNo; }
            set { _UserNo = value; }
        }
        #endregion

        #region LastModifiedDateTime
        private DateTime? _LastModifiedDateTime;
        /// <summary>
        /// LastModifiedDateTime
        /// </summary>
        public DateTime? LastModifiedDateTime
        {
            get { return _LastModifiedDateTime; }
            set { _LastModifiedDateTime = value; }
        }
        #endregion

        #endregion
    }
}
