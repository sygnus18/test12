﻿using System;
using System.Collections.Generic;
using System.Text;
using FTIL.Match.Common.Db;
using System.Data;
using FTIL.Match.Common;
using FTIL.Match.Common.Log;


namespace UCC.Class.Master
{
    public enum AddressTypeEnum
    {
        Registered = 1,
        ContactPerson = 3,
        Correspondence = 4,
        Others = 5
    }

    /// <summary>
    /// Collection class for storing class CAddress's objects  
    /// </summary>
    public class CAddressCollection
    {
        
        #region Constructor
        
        public CAddressCollection()
        {
            m_AddressList = new List<CAddress>();
        }
        
        #endregion


        /// <summary>
        /// List of CAddress 
        /// </summary>
        private List<CAddress> m_AddressList;

        #region Properties 
        
        /// <summary>
        /// Address List
        /// </summary>
        public List<CAddress> AddressList
        {
            get { return m_AddressList; }
            set { m_AddressList = value; }
        }

        /// <summary>
        /// Add address into collection
        /// </summary>
        /// <param name="address">Address instance</param>
        public void Add(CAddress address)
        {
            m_AddressList.Add(address);
        }

        /// <summary>
        /// Get address by AddressType
        /// </summary>
        /// <param name="addressType">Address Type Enum</param>
        /// <returns></returns>
        public CAddress GetAddressByType(AddressTypeEnum addressType)
        {
            return m_AddressList.Find(addr => addr.AddressType == (int)addressType);
        }

        /// <summary>
        /// Get addresses by AddressType 
        /// </summary>
        /// <param name="addressType">Address Type Enum</param>
        /// <returns>Filtered Address List</returns>
        public List<CAddress> GetAddressesByType(AddressTypeEnum addressType)
        {
            return m_AddressList.FindAll(addr => addr.AddressType == (int)addressType);
        }

        #endregion
    }
}
