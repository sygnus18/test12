﻿using System;
using System.Collections.Generic;
using System.Text;
using FTIL.Match.Common.Db;
using System.Data;
using FTIL.Match.Common;
using FTIL.Match.Common.Log;

namespace UCC.Class.Master
{
    /// <summary>
    /// This class represents Address entity
    /// </summary>
    public class CClientAddressCollection
    {
        #region Variables

        /// <summary>
        /// Indicates if current instance has been initialized from database
        /// </summary>
        private bool m_bInitialized;

        #endregion

        #region Constructor
        /// <summary>
        /// Initializes new instance of CClientAddressCollection using ClientNo
        /// </summary>
        /// <param name="n_ClientNo">Unique ClientNo</param>
        public CClientAddressCollection(int n_ClientNo,Int32 p_nUserNo)
        {
            this._ClientNo = n_ClientNo;
            Initialize(p_nUserNo);
        }
        #endregion

        #region Methods

        /// <summary>
        /// Initializes current instance from database for given ClientNo
        /// </summary>
        #region Initialize
        private void Initialize(Int32 p_nUserNo)
        {
            if (m_bInitialized)
                return;

            m_bInitialized = true;

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCRetrieveClientAddressData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;
            l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, this.ClientNo);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, p_nUserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                {
                    Logger.Instance.WriteLog(this, "Initalizing Address. No data found. ClientNo: " + this.ClientNo.ToString());
                }
                else
                {
                    if ((l_dsReturnData.Tables.Count > 1) && (l_dsReturnData.Tables[1].Rows.Count > 0))
                    {
                        this._AddressDetailData = l_dsReturnData.Tables[0];
                        this._AddressDetailDataUnAuth = l_dsReturnData.Tables[1];
                    }
                    else
                    {
                        this._AddressDetailData = l_dsReturnData.Tables[0];
                        this.PopulateAddressCollection();
                    }
                }
            }
            else
            {
                _LastMethodExecResult = l_objDbWorkItem.ExecutionStatus;
                Logger.Instance.WriteLog(this, l_objDbWorkItem.ExecutionStatus);
            }
        }
        #endregion

        #region GetClientAddressDetail
        /// <summary>
        /// Address details for given addressno
        /// </summary>
        /// <param name="pn_AddressNo"></param>
        /// <returns>datarow[]</returns>
        public DataRow[] GetClientAddressDetail(int pn_AddressNo)
        {
            DataRow[] _dr;
            _dr = this.AddressDetailData.Select("n_AddressNo= " + pn_AddressNo);
            return _dr;
        }
        #endregion

        #region GetClientAddressDetailUnAuth
        /// <summary>
        /// Client Address details for UnAuthorised details 
        /// </summary>
        /// <param name="pn_AddressNo"></param>
        /// <returns>datarow[]</returns>
        public DataRow[] GetClientAddressDetailUnAuth(int pn_AddressNo)
        {
            if (this.AddressDetailsDataUnAuth != null)
            {
                DataRow[] _dr;
                _dr = this.AddressDetailsDataUnAuth.Select("n_AddressNo = " + pn_AddressNo);
                return _dr;
            }
            else
            {
                return null;
            }

        }
        #endregion

        #region PopulateAddressCollection
        /// <summary>
        /// Populate client specific address in list
        /// </summary>
        private void PopulateAddressCollection()
        {
            this.ClientAddressesNew = new List<CUCCClientAddress>();
            foreach (DataRow _dr in this.AddressDetailData.Rows)
            {
                CUCCClientAddress l_ClientAddress;
                l_ClientAddress = new CUCCClientAddress(Convert.ToInt32(_dr["n_AddressNo"]));
                l_ClientAddress.Initialize(_dr, this);
                this.ClientAddressesNew.Add(l_ClientAddress);
            }
        }
        #endregion
        #endregion

        #region Properties

        #region ClientNo
        private Int32 _ClientNo;
        /// <summary>
        /// ClientNo
        /// </summary>
        public Int32 ClientNo
        {
            get { return _ClientNo; }
            set { _ClientNo = value; }
        }
        #endregion

        #region AddressDetailData
        private DataTable _AddressDetailData;
        /// <summary>
        /// Client Address Detail DataTable
        /// </summary>
        public DataTable AddressDetailData
        {
            get { return _AddressDetailData; }
        }
        #endregion

        #region LastMethodExecResult
        private MethodExecResult _LastMethodExecResult;
        /// <summary>
        /// Last Method execution result
        /// </summary>
        public MethodExecResult LastMethodExecResult
        {
            get { return _LastMethodExecResult; }
        }
        #endregion

        #region AddressDetailsDataUnAuth
        private DataTable _AddressDetailDataUnAuth;
        /// <summary>
        /// Client Under Authorization Address Details
        /// </summary>
        public DataTable AddressDetailsDataUnAuth
        {
            get { return _AddressDetailDataUnAuth; }
        }
        #endregion 

        #region ClientAddressesNew
        /// <summary>
        /// Get or Set Client specific address list
        /// </summary>
        public List<CUCCClientAddress> ClientAddressesNew { get; set; }
        #endregion

        #endregion
    }
}
