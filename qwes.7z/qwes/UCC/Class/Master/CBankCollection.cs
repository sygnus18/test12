﻿using System;
using System.Collections.Generic;
using System.Text;
using FTIL.Match.Common.Db;
using System.Data;
using FTIL.Match.Common;
using FTIL.Match.Common.Log;

namespace UCC.Class.Master
{
    /// <summary>
    /// This class represents Bank entity
    /// </summary>
    public class CBankCollection
    {
        #region Variables

        /// <summary>
        /// Collection of CBank objects for a Client (ClientNo)
        /// </summary>
        private Dictionary<int, CBank> m_dicBankCollection;

        #endregion

        #region Singleton

        /// <summary>
        /// Only instance of a class
        /// </summary>
        private static CBankCollection m_objInstance;
        /// <summary>
        /// Only instance of a class
        /// </summary>
        public static CBankCollection Instance { get { return m_objInstance; } }

        /// <summary>
        /// Static constructor to initialize singleton instance
        /// </summary>
        static CBankCollection()
        {
            m_objInstance = new CBankCollection();
        }

        /// <summary>
        /// Initializes new instance of CBankCollection using ClientBankNo
        /// </summary>
        /// <param name="n_ClientBankNo">Unique ClientBankNo</param>
        private CBankCollection()
        {
            m_dicBankCollection = new Dictionary<int,CBank>();
            Initialize();
        }

        #endregion

        #region Methods

        /// <summary>
        /// Initializes current instance from database for given ClientNo
        /// </summary>
        #region Initialize
        private void Initialize()
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCRetrieveBankMasterData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0) || (l_dsReturnData.Tables[0].Rows.Count == 0))
                {
                    Logger.Instance.WriteLog(this, "Initalizing Bank Collection. No data found.");
                }
                else
                {
                    m_dicBankCollection.Clear();
                    DataTable l_dtBank = l_dsReturnData.Tables[0];
                    for (int l_iRowCounter = 0; l_iRowCounter < l_dtBank.Rows.Count; l_iRowCounter++)
                    {
                        CBank l_objNewBank = new CBank(
                            Convert.ToInt32(l_dtBank.Rows[l_iRowCounter]["n_BankNo"]),
                            l_dtBank.Rows[l_iRowCounter]["s_BankCode"].ToString().Trim(),
                            l_dtBank.Rows[l_iRowCounter]["s_BankName"].ToString().Trim(),
                            l_dtBank.Rows[l_iRowCounter]["s_MICRCode"].ToString().Trim()
                            );

                        m_dicBankCollection.Add(l_objNewBank.BankNo, l_objNewBank);
                    }
                }
            }
            else
            {
                _LastMethodExecResult = l_objDbWorkItem.ExecutionStatus;
                Logger.Instance.WriteLog(this, l_objDbWorkItem.ExecutionStatus);
            }
        }
        #endregion

        #endregion

        #region Properties

        #region Indexer (BankNo)
        /// <summary>
        /// ClientNo
        /// </summary>
        public CBank this[int BankNo]
        {
            get 
            {
                if (m_dicBankCollection.ContainsKey(BankNo))
                    return m_dicBankCollection[BankNo];
                return null;
            }
        }
        #endregion

        #region AllBank
        /// <summary>
        /// ClientNo
        /// </summary>
        public List<CBank> AllBank
        {
            get
            {
                List<CBank> l_lstAllBank = new List<CBank>(m_dicBankCollection.Count);
                foreach (KeyValuePair<int, CBank> l_objBank in m_dicBankCollection)
                    l_lstAllBank.Add(l_objBank.Value);
                return l_lstAllBank;
            }
        }
        #endregion
        
        #region LastMethodExecResult
        private MethodExecResult _LastMethodExecResult;
        /// <summary>
        /// Last Method execution result
        /// </summary>
        public MethodExecResult LastMethodExecResult
        {
            get { return _LastMethodExecResult; }
        }
        #endregion

        #endregion
    }
}
