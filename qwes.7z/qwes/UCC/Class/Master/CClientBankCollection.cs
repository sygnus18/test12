﻿using System;
using System.Collections.Generic;
using System.Text;
using FTIL.Match.Common.Db;
using System.Data;
using FTIL.Match.Common;
using FTIL.Match.Common.Log;

namespace UCC.Class.Master
{
    /// <summary>
    /// This class represents Bank entity
    /// </summary>
    public class CClientBankCollection
    {
        #region Variables

        /// <summary>
        /// Indicates if current instance has been initialized from database
        /// </summary>
        private bool m_bInitialized;

        #endregion

        #region Constructor
        /// <summary>
        /// Initializes new instance of CClientBankCollection using ClientNo
        /// </summary>
        /// <param name="n_ClientNo">Unique ClientNo</param>
        public CClientBankCollection(int n_ClientNo, int p_nUserNo)
        {
            _ClientNo = n_ClientNo;
            Initialize(p_nUserNo);
        }
        #endregion

        #region Methods

        /// <summary>
        /// Initializes current instance from database for given ClientNo
        /// </summary>
        #region Initialize
        private void Initialize(int p_nUserNo)
        {
            if (m_bInitialized)
                return;

            m_bInitialized = true;

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCRetrieveClientBankData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, this.ClientNo);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, p_nUserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                {
                    Logger.Instance.WriteLog(this, "Initalizing Bank. No data found. ClientNo: " + this.ClientNo.ToString());
                }
                else
                {
                    if ((l_dsReturnData.Tables.Count > 1) && (l_dsReturnData.Tables[1].Rows.Count > 0))
                    {
                        this._BankDetailData = l_dsReturnData.Tables[0];
                        this._BankDetailDataUnAuth = l_dsReturnData.Tables[1];
                    }
                    else
                    {
                        this._BankDetailData = l_dsReturnData.Tables[0];
                    }
                }
            }
            else
            {
                _LastMethodExecResult = l_objDbWorkItem.ExecutionStatus;
                Logger.Instance.WriteLog(this, l_objDbWorkItem.ExecutionStatus);
            }
        }
        #endregion

        #region GetClientBankDetail
        /// <summary>
        /// ClientBank for the client
        /// </summary>
        /// <param name="pn_ClientBankNo"></param>
        /// <returns>datarow[]</returns>
        public DataRow[] GetClientBankDetail(int pn_ClientBankNo)
        {
            DataRow[] _dr;
            _dr = this.BankDetailData.Select("n_ClientBankNo = " + pn_ClientBankNo);
            return _dr;
        }
        #endregion

        #region GetClientBankDetailUnAuth
        /// <summary>
        /// ClientBank for the client UnAuthorised details 
        /// </summary>
        /// <param name="pn_ClientBankNo"></param>
        /// <returns>datarow[]</returns>
        public DataRow[] GetClientBankDetailUnAuth(int pn_ClientBankNo)
        {
            if (this.BankDetailsDataUnAuth != null)
            {
                DataRow[] _dr;
                _dr = this.BankDetailsDataUnAuth.Select("n_ClientBankNo = " + pn_ClientBankNo);
                return _dr;
            }
            else
            {
                return null;
            }

        }
        #endregion

        #region PopulateBankCollection
        /// <summary>
        /// Populate client specific Bank in list
        /// </summary>
        private void PopulateBankCollection()
        {
            this.ClientBanks = new List<CClientBank>();
            foreach (DataRow _dr in this.BankDetailData.Rows)
            {
                CClientBank l_ClientBank;
                l_ClientBank = new CClientBank(Convert.ToInt32(_dr["n_ClientBankNo"]));
                l_ClientBank.Initialize(_dr, this);
                this.ClientBanks.Add(l_ClientBank);
            }
        }
        #endregion

        #endregion

        #region Properties

        #region ClientNo
        private Int32 _ClientNo;
        /// <summary>
        /// ClientNo
        /// </summary>
        public Int32 ClientNo
        {
            get { return _ClientNo; }
            set { _ClientNo = value; }
        }
        #endregion

        #region BankDetailData
        private DataTable _BankDetailData;
        /// <summary>
        /// Client Bank Detail DataTable
        /// </summary>
        public DataTable BankDetailData
        {
            get { return _BankDetailData; }
        }
        #endregion

        #region LastMethodExecResult
        private MethodExecResult _LastMethodExecResult;
        /// <summary>
        /// Last Method execution result
        /// </summary>
        public MethodExecResult LastMethodExecResult
        {
            get { return _LastMethodExecResult; }
        }
        #endregion

        #region BankDetailsDataUnAuth
        private DataTable _BankDetailDataUnAuth;
        /// <summary>
        /// Client Under Authorization Bank Details
        /// </summary>
        public DataTable BankDetailsDataUnAuth
        {
            get { return _BankDetailDataUnAuth; }
        }
        #endregion 

        #region ClientBanks
        /// <summary>
        /// Get or Set Client specific address list
        /// </summary>
        public List<CClientBank> ClientBanks { get; set; }
        #endregion

        #endregion
    }
}
