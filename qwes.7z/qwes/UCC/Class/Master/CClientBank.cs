﻿using System;
using System.Collections.Generic;
using System.Text;
using FTIL.Match.Common.Db;
using System.Data;
using FTIL.Match.Common;
using FTIL.Match.Common.Log;

namespace UCC.Class.Master
{
    /// <summary>
    /// This class represents Bank entity
    /// </summary>
    public class CClientBank
    {
        #region Variables

        /// <summary>
        /// Incase of maker/checker ON object contain the Original ClientBank value 
        /// </summary>
        private CClientBank m_objOriginalBank;

        #endregion

        #region Constructor
        /// <summary>
        /// Initializes new instance of CClientBank using ClientBankNo
        /// </summary>
        /// <param name="n_ClientBankNo">Unique ClientBankNo</param>
        public CClientBank(int n_ClientBankNo)
        {
            _ClientBankNo = n_ClientBankNo;
            //Initialize();
        }
        #endregion

        #region Methods

        /// <summary>
        /// Initializes current instance from collection with given ClientBankNo
        /// </summary>
        #region Initialize
        public MethodExecResult Initialize(DataRow DataRow, CClientBankCollection ClientBankCollection)
        {
            try
            {
                MethodExecResult l_MethodExecResult;
                //If under authorisation client, take new changes in main client object and original object in originalClient object
                if (ClientBankCollection.BankDetailsDataUnAuth != null && ClientBankCollection.BankDetailsDataUnAuth.Rows.Count > 0 && ClientBankCollection.BankDetailsDataUnAuth.Select("n_ClientBankNo = " + this.ClientBankNo).GetLength(0) > 0)
                {
                    DataRow[] _dr;
                    _dr = ClientBankCollection.GetClientBankDetailUnAuth(this.ClientBankNo);
                    m_objOriginalBank = new CClientBank(this.ClientBankNo);
                    l_MethodExecResult = m_objOriginalBank.InitializeFromDataRow(_dr[0]);
                    l_MethodExecResult = this.InitializeFromDataRow(DataRow);
                }
                else
                {
                    l_MethodExecResult = this.InitializeFromDataRow(DataRow);
                }
                return l_MethodExecResult;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                return new MethodExecResult(1, ex.Message, "Initialize Error processing DataRow", ex);
            }

        }
        #endregion
        /// <summary>
        /// Initializes current instance from DataRow
        /// </summary>
        /// <param name="DataRow">DataRow object containing Bank details</param>
        #region InitializeFromDataRow
        public MethodExecResult InitializeFromDataRow(DataRow DataRow)
        {
            try
            {
                this.BankNo = Convert.ToInt32(DataRow["n_BankNo"]);
                this.ClientBankNo = Convert.ToInt32(DataRow["n_ClientBankNo"]);
                this.ClientNo = Convert.ToInt32(DataRow["n_ClientNo"]);
                this.ExNo = Convert.ToInt16(DataRow["n_ExNo"]);
                this.BankNo = Convert.ToInt32(DataRow["n_BankNo"]);
                this.AccountNo = DataRow["s_AccountNo"].ToString().Trim();
                this.Default = DataRow["s_Default"].ToString().Trim();
                this.AccountType = Convert.ToInt32(DataRow["n_AccountType"]);
                if ((DataRow["n_UserNo"] != null) && (DataRow["n_UserNo"] != DBNull.Value))
                    this.UserNo = Convert.ToInt32(DataRow["n_UserNo"]);
                if ((DataRow["d_LastModifiedDateTime"] != null) && (DataRow["d_LastModifiedDateTime"] != DBNull.Value))
                    this.LastModifiedDateTime = Convert.ToDateTime(DataRow["d_LastModifiedDateTime"]);

                if (DataRow["s_AuthorizedStatus"] != DBNull.Value)
                    this.AuthorizedStatus = DataRow["s_AuthorizedStatus"].ToString().Trim();

                return new MethodExecResult(MethodExecResult.SuccessfulReturnCode);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                return new MethodExecResult(1, ex.Message, "InitializeFromDataRow() Error processing DataRow", ex);
            }
        }
        #endregion

        /// <summary>
        /// Updates current instance changes to database
        /// </summary>
        /// <returns>Method Execution Result</returns>
        #region Update
        public MethodExecResult Update()
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCUpdateClientBankData");
            l_objDbWorkItem.ResultType = QueryType.NonQuery;

            l_objDbWorkItem.AddParameter("@pn_ClientBankNo", SqlDbType.Int, this.ClientBankNo);
            l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, this.ClientNo);
            l_objDbWorkItem.AddParameter("@pn_ExNo", SqlDbType.SmallInt, this.ExNo);
            l_objDbWorkItem.AddParameter("@pn_BankNo", SqlDbType.Int, this.BankNo);
            l_objDbWorkItem.AddParameter("@ps_AccountNo", SqlDbType.VarChar, this.AccountNo);
            l_objDbWorkItem.AddParameter("@ps_Default", SqlDbType.Char, this.Default);
            l_objDbWorkItem.AddParameter("@pn_AccountType", SqlDbType.Int, this.AccountType);

            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            return l_objDbWorkItem.ExecutionStatus;
        }
        #endregion

        /// <summary>
        /// Deletes current instance from database
        /// </summary>
        /// <returns>Method Execution Result</returns>
        #region Delete
        public MethodExecResult Delete()
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCDeleteBankData");
            l_objDbWorkItem.ResultType = QueryType.NonQuery;

            l_objDbWorkItem.AddParameter("@pn_ClientBankNo", SqlDbType.Int, this.ClientBankNo);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            return l_objDbWorkItem.ExecutionStatus;
        }
        #endregion

        #endregion

        #region Properties

        #region ClientBankNo
        private Int32 _ClientBankNo;
        /// <summary>
        /// ClientBankNo
        /// </summary>
        public Int32 ClientBankNo
        {
            get { return _ClientBankNo; }
            set { _ClientBankNo = value; }
        }
        #endregion

        #region ClientNo
        private Int32 _ClientNo;
        /// <summary>
        /// ClientNo
        /// </summary>
        public Int32 ClientNo
        {
            get { return _ClientNo; }
            set { _ClientNo = value; }
        }
        #endregion

        #region ExNo
        private Int16 _ExNo;
        /// <summary>
        /// ExNo
        /// </summary>
        public Int16 ExNo
        {
            get { return _ExNo; }
            set { _ExNo = value; }
        }
        #endregion

        #region BankNo
        private Int32 _BankNo;
        /// <summary>
        /// BankNo
        /// </summary>
        public Int32 BankNo
        {
            get { return _BankNo; }
            set { _BankNo = value; }
        }
        #endregion

        #region AccountNo
        private string _AccountNo;
        /// <summary>
        /// Account No
        /// </summary>
        public string AccountNo
        {
            get { return _AccountNo; }
            set { _AccountNo = value; }
        }
        #endregion

        #region Default
        private string _Default;
        /// <summary>
        /// Default
        /// </summary>
        public string Default
        {
            get { return _Default; }
            set { _Default = value; }
        }
        #endregion

        #region AccountType
        private int _AccountType;
        /// <summary>
        /// AccountType
        /// </summary>
        public int AccountType
        {
            get { return _AccountType; }
            set { _AccountType = value; }
        }
        #endregion

        #region UserNo
        private Int32? _UserNo;
        /// <summary>
        /// UserNo
        /// </summary>
        public Int32? UserNo
        {
            get { return _UserNo; }
            set { _UserNo = value; }
        }
        #endregion

        #region LastModifiedDateTime
        private DateTime? _LastModifiedDateTime;
        /// <summary>
        /// LastModifiedDateTime
        /// </summary>
        public DateTime? LastModifiedDateTime
        {
            get { return _LastModifiedDateTime; }
            set { _LastModifiedDateTime = value; }
        }
        #endregion


        #region OriginalBank
        /// <summary>
        /// Original Bank details of current Bank (when Maker/Checker enabled)
        /// </summary>
        public CClientBank OriginalBank
        {
            get { return m_objOriginalBank; }
        }
        #endregion

        #region AuthorizedStatus
        /// <summary>
        /// Authorise status of current record
        /// </summary>
        private string _AuthorizedStatus;
        public string AuthorizedStatus
        {
            get { return _AuthorizedStatus; }
            set { _AuthorizedStatus = value; }
        }
        #endregion

        #endregion
    }
}
