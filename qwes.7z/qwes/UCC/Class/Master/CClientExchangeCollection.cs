﻿using System;
using System.Collections.Generic;
using System.Text;
using FTIL.Match.Common.Db;
using System.Data;
using FTIL.Match.Common;
using FTIL.Match.Common.Log;

namespace UCC.Class.Master
{
    /// <summary>
    /// This class represents Exchange entity
    /// </summary>
    public class CClientExchangeCollection
    {
        #region Variables

        /// <summary>
        /// Indicates if current instance has been initialized from database
        /// </summary>
        private bool m_bInitialized;

        #endregion

        #region Constructor
        /// <summary>
        /// Initializes new instance of CClientExchangeCollection using ClientNo
        /// </summary>
        /// <param name="n_ClientNo">Unique ClientNo</param>
        public CClientExchangeCollection(int n_ClientNo,int p_nUserNo)
        {
            this._ClientNo = n_ClientNo;
            Initialize(p_nUserNo);
        }
        #endregion

        #region Methods

        /// <summary>
        /// Initializes current instance from database for given ClientNo
        /// </summary>
        
        #region Initialize
        private void Initialize(int p_nUserNo)
        {
            if (m_bInitialized)
                return;

            m_bInitialized = true;

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCRetrieveClientExchangeData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;
            l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, this.ClientNo);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, p_nUserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                {
                    Logger.Instance.WriteLog(this, "Initalizing Exchange. No data found. ClientNo: " + this.ClientNo.ToString());
                }
                else
                {
                    if ((l_dsReturnData.Tables.Count > 1) && (l_dsReturnData.Tables[1].Rows.Count > 0))
                    {
                        this._ExchDetailData = l_dsReturnData.Tables[0];
                        this._ExchDetailDataUnAuth = l_dsReturnData.Tables[1];
                    }
                    else
                    {
                        this._ExchDetailData = l_dsReturnData.Tables[0];
                        this.PopulateExchangeCollection();
                    }
                }
            }
            else
            {
                _LastMethodExecResult = l_objDbWorkItem.ExecutionStatus;
                Logger.Instance.WriteLog(this, l_objDbWorkItem.ExecutionStatus);
            }
        }
        #endregion

        #region GetClientExchangeDetail
        /// <summary>
        /// Exchange details for a exchange details
        /// </summary>
        /// <param name="pn_ClientDPNo"></param>
        /// <returns>datarow[]</returns>
        public DataRow[] GetClientExchDetail(int pn_ClientExMapNo)
        {
            DataRow[] _dr;
            _dr = this.ExchDetailData.Select("pn_ClientExMapNo= " + pn_ClientExMapNo);
            return _dr;
        }
        #endregion

        #region GetClientExchDetailUnAuth
        /// <summary>
        /// Client Exchange details for UnAuthorised details 
        /// </summary>
        /// <param name="pn_ClientDPNo"></param>
        /// <returns>datarow[]</returns>
        public DataRow[] GetClientExchDetailUnAuth(int pn_ClientExMapNo)
        {
            if (this.ExchDetailsDataUnAuth != null)
            {
                DataRow[] _dr;
                _dr = this.ExchDetailsDataUnAuth.Select("n_ClientExMapNo = " + pn_ClientExMapNo);
                return _dr;
            }
            else
            {
                return null;
            }

        }
        #endregion

        #region PopulateExchangeCollection
        /// <summary>
        /// Populate client specific exchanges in list
        /// </summary>
        private void PopulateExchangeCollection()
        {
            // populate collection 
            this.ClientExchanges = new List<CUCCClientExchangeMapping>();
            foreach (DataRow _dr in this.ExchDetailData.Rows)
            {
                CUCCClientExchangeMapping l_ClientExchnage;
                l_ClientExchnage = new CUCCClientExchangeMapping(Convert.ToInt32(_dr["n_ClientExMapNo"]));
                l_ClientExchnage.Initialize(_dr, this);
                ClientExchanges.Add(l_ClientExchnage);
            }
        }
        #endregion

        #endregion

        #region Properties

        #region ClientNo
        private Int32 _ClientNo;
        /// <summary>
        /// ClientNo
        /// </summary>
        public Int32 ClientNo
        {
            get { return _ClientNo; }
            set { _ClientNo = value; }
        }
        #endregion

        #region ExchDetailData
        private DataTable _ExchDetailData;
        /// <summary>
        /// Client Exch Detail DataTable
        /// </summary>
        public DataTable ExchDetailData
        {
            get { return _ExchDetailData; }
        }
        #endregion

        #region LastMethodExecResult
        private MethodExecResult _LastMethodExecResult;
        /// <summary>
        /// Last Method execution result
        /// </summary>
        public MethodExecResult LastMethodExecResult
        {
            get { return _LastMethodExecResult; }
        }
        #endregion

        #region ExchDetailsDataUnAuth
        private DataTable _ExchDetailDataUnAuth;
        /// <summary>
        /// Client Under Authorization Exch Details
        /// </summary>
        public DataTable ExchDetailsDataUnAuth
        {
            get { return _ExchDetailDataUnAuth; }
        }
        #endregion 

        #region ClientExchanges
        /// <summary>
        /// Get or Set Client specific exchanges list
        /// </summary>
        public List<CUCCClientExchangeMapping> ClientExchanges { get; set; }
        #endregion

        #endregion
    }
}
