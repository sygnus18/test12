﻿using System;
using System.Collections.Generic;
using System.Text;
using FTIL.Match.Common.Db;
using System.Data;
using FTIL.Match.Common;
using FTIL.Match.Common.Log;

namespace UCC.Class.Master
{
    /// <summary>
    /// This class represents DP entity
    /// </summary>
    public class CDP
    {

        #region Constructor
        /// <summary>
        /// Initializes new instance of CDP using DP Code
        /// </summary>
        /// <param name="DPCode"></param>
        public CDP(int DPNo, string DPCode, string DPName, string Depository)
        {
            _DPNo = DPNo;
            _DPCode = DPCode;
            _DPName = DPName;
            _Depository = Depository;
        }
        #endregion

        #region Properties

        #region DPNo
        private int _DPNo;
        /// <summary>
        /// DP No
        /// </summary>
        public int DPNo
        {
            get { return _DPNo; }
        }
        #endregion

        #region DPCode
        private string _DPCode;
        /// <summary>
        /// DP Code
        /// </summary>
        public string DPCode
        {
            get { return _DPCode; }
        }
        #endregion

        #region DPName
        private string _DPName;
        /// <summary>
        /// DP Name
        /// </summary>
        public string DPName
        {
            get { return _DPName; }
        }
        #endregion

        #region Depository
        private string _Depository;
        /// <summary>
        /// Depository
        /// </summary>
        public string Depository
        {
            get { return _Depository; }
        }
        #endregion

        #endregion
    }
}
