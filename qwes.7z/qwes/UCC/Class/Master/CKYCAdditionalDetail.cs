﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace UCC.Class.Master
{
    /// <summary>
    /// Class for KYC addtional  detail (IPV etc.)
    /// </summary>
    public class CKYCAdditionalDetail
    {


        /// <summary>
        /// 'Y' if IPV is done else 'N'
        /// </summary>
        public char IPVFlag { get; set; }

        /// <summary>
        /// Name of the person doing the IPV
        /// </summary>
        public string IPVPersonName { get; set; }

        /// <summary>
        /// Designation of IPV Person
        /// </summary>
        public string IPVPersonDesignation { get; set; }

        /// <summary>
        ///Organization Name of the person doing the IPV
        /// </summary>
        public string IPVOrganization { get; set; }


        /// <summary>
        /// Date of the IPV
        /// </summary>
        public DateTime? IPVDate { get; set; }

        /// <summary>
        /// KYC Request Status
        /// </summary>
        public string KYCRequestStatus { get; set; }

        /// <summary>
        /// Remarks by KRA
        /// </summary>
        public string KRARemark { get; set; }
       
        /// <summary>
        /// Evidence / Documents provided in case of PAN exemption
        /// </summary>
        public string PANExemptionEvidence { get; set; }

        /// <summary>
        /// Proof of Identity submitted
        /// </summary>
        public string ProofOfIdentity { get; set; }

        /// <summary>
        /// Proof of Identity submitted Other
        /// </summary>
        public string ProofofIdentityOther { get; set; }

        /// <summary>
        /// Proof of Address submitted for correspondence address
        /// </summary>
        public string ProofofCorrAddress { get; set; }

        /// <summary>
        /// Proof of Address submitted for correspondence address other
        /// </summary>
        public string ProofofCorrAddressOther { get; set; }

        /// <summary>
        ///Proof of Address submitted for permanent address
        /// </summary>
        public string ProofofPerAddress { get; set; }

        /// <summary>
        /// Proof of Address submitted for permanent address other
        /// </summary>
        public string ProofofPerAddressOther { get; set; }

        /// <summary>
        /// Other Information 
        /// </summary>
        public string OtherInfo { get; set; }

        /// <summary>
        /// Acknowledgement Number
        /// </summary>
        public int? AcknowledgementNumber { get; set; }

      
        /// <summary>
        /// No Of Documents Submitted
        /// </summary>
        public int DocumentsCount { get; set; }

        /// <summary>
        /// Intermediary Branch Code
        /// </summary>
        public string IntermediaryBranchCode { get; set; }


        /// <summary>
        /// Sender reference number 1
        /// </summary>
        public string SenderRefNo1 { get; set; }

        /// <summary>
        /// Sender reference number 2
        /// </summary>
        public string SenderRefNo2 { get; set; }

        /// <summary>
        /// Status (ndividual/Non-Individual)
        /// </summary>
        public string ClientStatus { get; set; }

        /// <summary>
        /// Client Status Other
        /// </summary>
        public string StatusOther { get; set; }

        /// <summary>
        /// Flag to indicate Old record
        /// </summary>
        public bool IsOldRecord { get; set; } 

        /// <summary>
        /// KYC Application No
        /// </summary>
        public string  KYCApplicationNo {get;set;}

        /// <summary>
        /// KYC Application Date
        /// </summary>
        public DateTime? KYCApplicationDate {get;set;}

        /// <summary>
        /// KYC ActiveDate
        /// </summary>
        public DateTime? KYCActiveDate { get; set; }

        /// <summary>
        /// KYC MakerDateTime
        /// </summary>
        public DateTime? KYCMakerDateTime { get; set; }

        /// <summary>
        /// Verifier Name
        /// </summary>
        public string VerifierName { get; set; }

        public string CompanyName { get; set; }

        /// <summary>
        /// Exchange Trading Code
        /// </summary>
        public string TradingCode { get; set; }


        /// <summary>
        /// Relationship with Applicant
        /// </summary>
        public string Relationship { get; set; }

        /// <summary>
        /// Relationship with Applicant (Other)
        /// </summary>
        public string RelationshipOther { get; set; }

        /// <summary>
        /// Initialize fields from data row
        /// </summary>
        /// <param name="dataRow">Addtional detail for KRA</param>
        public void InitializeFromDataRow(DataRow dataRow)
        {

            if ((dataRow["KYCRemarks"] != null) && (dataRow["KYCRemarks"] != DBNull.Value))
                KRARemark = Convert.ToString(dataRow["KYCRemarks"]);

            if ((dataRow["IPVDate"] != null) && (dataRow["IPVDate"] != DBNull.Value))
                IPVDate = Convert.ToDateTime(dataRow["IPVDate"]);

            if ((dataRow["IPVFlag"] != null) && (dataRow["IPVFlag"] != DBNull.Value))
                IPVFlag = Convert.ToChar(dataRow["IPVFlag"]);

            if ((dataRow["IPVPersonDesignation"] != null) && (dataRow["IPVPersonDesignation"] != DBNull.Value))
                IPVPersonDesignation = Convert.ToString(dataRow["IPVPersonDesignation"]);

            if ((dataRow["PANExemptionEvidence"] != null) && (dataRow["PANExemptionEvidence"] != DBNull.Value))
                PANExemptionEvidence = Convert.ToString(dataRow["PANExemptionEvidence"]);

            if ((dataRow["ProofOfIdentity"] != null) && (dataRow["ProofOfIdentity"] != DBNull.Value))
                ProofOfIdentity = Convert.ToString(dataRow["ProofOfIdentity"]);

            if ((dataRow["ProofofIdentityOther"] != null) && (dataRow["ProofofIdentityOther"] != DBNull.Value))
                ProofofIdentityOther = Convert.ToString(dataRow["ProofofIdentityOther"]);

            if ((dataRow["ProofofCorrAddress"] != null) && (dataRow["ProofofCorrAddress"] != DBNull.Value))
                ProofofCorrAddress = Convert.ToString(dataRow["ProofofCorrAddress"]);


            if ((dataRow["ProofofPerAddress"] != null) && (dataRow["ProofofPerAddress"] != DBNull.Value))
                ProofofPerAddress = Convert.ToString(dataRow["ProofofPerAddress"]);

            if ((dataRow["ProofofCorrAddressOther"] != null) && (dataRow["ProofofCorrAddressOther"] != DBNull.Value))
                ProofofCorrAddressOther = Convert.ToString(dataRow["ProofofCorrAddressOther"]);

            if ((dataRow["OtherInfo"] != null) && (dataRow["OtherInfo"] != DBNull.Value))
                OtherInfo = Convert.ToString(dataRow["OtherInfo"]);

            if ((dataRow["AcknowledgementNumber"] != null) && (dataRow["AcknowledgementNumber"] != DBNull.Value))
                AcknowledgementNumber = Convert.ToInt32(dataRow["AcknowledgementNumber"]);

          
            if ((dataRow["SubmittedDocumentsCount"] != null) && (dataRow["SubmittedDocumentsCount"] != DBNull.Value))
                DocumentsCount = Convert.ToInt32(dataRow["SubmittedDocumentsCount"]);

            if ((dataRow["IntermediaryBranchCode"] != null) && (dataRow["IntermediaryBranchCode"] != DBNull.Value))
                IntermediaryBranchCode = Convert.ToString(dataRow["IntermediaryBranchCode"]);

            if ((dataRow["SenderRefNo1"] != null) && (dataRow["SenderRefNo1"] != DBNull.Value))
                SenderRefNo1 = Convert.ToString(dataRow["SenderRefNo1"]);

            if ((dataRow["SenderRefNo2"] != null) && (dataRow["SenderRefNo2"] != DBNull.Value))
                SenderRefNo2 = Convert.ToString(dataRow["SenderRefNo2"]);

            if ((dataRow["ClientStatus"] != null) && (dataRow["ClientStatus"] != DBNull.Value))
                ClientStatus = Convert.ToString(dataRow["ClientStatus"]);

            if ((dataRow["OldRecord"] != null) && (dataRow["OldRecord"] != DBNull.Value))
                IsOldRecord = Convert.ToBoolean(dataRow["OldRecord"]);

            if ((dataRow["KYCApplicationNo"] != null) && (dataRow["KYCApplicationNo"] != DBNull.Value))
                KYCApplicationNo = Convert.ToString(dataRow["KYCApplicationNo"]);

            if ((dataRow["KYCApplicationDate"] != null) && (dataRow["KYCApplicationDate"] != DBNull.Value))
                KYCApplicationDate = Convert.ToDateTime(dataRow["KYCApplicationDate"]);

            if ((dataRow["KYCActiveDate"] != null) && (dataRow["KYCActiveDate"] != DBNull.Value))
                KYCActiveDate = Convert.ToDateTime(dataRow["KYCActiveDate"]);


            if ((dataRow["MakerDateTime"] != null) && (dataRow["MakerDateTime"] != DBNull.Value))
                KYCMakerDateTime = Convert.ToDateTime(dataRow["MakerDateTime"]);

            if ((dataRow["VerifierName"] != null) && (dataRow["VerifierName"] != DBNull.Value))
                VerifierName = Convert.ToString(dataRow["VerifierName"]);

            if ((dataRow["CompanyName"] != null) && (dataRow["CompanyName"] != DBNull.Value))
                CompanyName = Convert.ToString(dataRow["CompanyName"]);

            if ((dataRow["TradingCode"] != null) && (dataRow["TradingCode"] != DBNull.Value))
                TradingCode = Convert.ToString(dataRow["TradingCode"]);

            if ((dataRow["Relationship"] != null) && (dataRow["Relationship"] != DBNull.Value))
                Relationship = Convert.ToString(dataRow["Relationship"]);

            if ((dataRow["RelationshipOther"] != null) && (dataRow["RelationshipOther"] != DBNull.Value))
                RelationshipOther = Convert.ToString(dataRow["RelationshipOther"]);

            if ((dataRow["StatusOther"] != null) && (dataRow["StatusOther"] != DBNull.Value))
                StatusOther = Convert.ToString(dataRow["StatusOther"]);

            if ((dataRow["KYCRequestStatus"] != null) && (dataRow["KYCRequestStatus"] != DBNull.Value))
                KYCRequestStatus = Convert.ToString(dataRow["KYCRequestStatus"]);
        }
    }
}
