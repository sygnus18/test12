﻿using System;
using System.Collections.Generic;
using System.Text;
using FTIL.Match.Common.Db;
using System.Data;
using FTIL.Match.Common;
using FTIL.Match.Common.Log;


namespace UCC.Class.Master
{
 
    /// <summary>
    /// Data class for table tb_UCCAddress
    /// </summary>
    public class CAddress
    {


        #region Constructors
        /// <summary>
        /// Constructor
        /// Will set class properties from table tb_UCCAddress with given Client ID
        /// </summary>
        /// <param name="clientNo">Client ID</param>
        /// <param name="addressType">AddressType Enum</param>
        public CAddress(int clientNo, AddressTypeEnum addressType)
        {
            ClientNo = clientNo;
            AddressType = (int)addressType;
            Initialize();
        }

        public CAddress() { }
        #endregion

        #region Properties

        public int ClientNo { get; set; }
        public int AddressType { get; set; }
        public string ContactPerson { get; set; }
        public string Designation { get; set; }
        public string PANNo { get; set; }
        public string DIN { get; set; }
        public string Director { get; set; }
        public string UID { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string AddressLine4 { get; set; }
        public int CityStateCode { get; set; }
        public string City { get; set; }
        public string PinCode { get; set; }
        public int StateNumber { get; set; }
        public string StateOther { get; set; }
        public int CountryCode { get; set; }
        public string TelNoISDCode { get; set; }
        public string TelNoSTDCode { get; set; }
        public string TelNo1 { get; set; }
        public string TelNoOfficeISDCode { get; set; }
        public string TelNoOfficeSTDCode { get; set; }
        public string TelNoOffice { get; set; }
        public string Mobile1 { get; set; }
        public string Mobile2 { get; set; }
        public string FaxNoISDCode { get; set; }
        public string FaxNoSTDCode { get; set; }
        public string FaxNo { get; set; }
        public string EMailId { get; set; }
        public string CCEmail { get; set; }
        public string BCCMail { get; set; }
        public string Default { get; set; }
        public string ContactPersonDefault { get; set; }
        public string SameCorrPermAdd { get; set; }
        public int UserNo { get; set; }
        public DateTime LastModifiedDateTime { get; set; }

        #endregion


        /// <summary>
        /// Initializes current instance from database with given ClientNo
        /// </summary>
        #region Initialize
        private void Initialize()
        {

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCRetrieveAddressData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, this.ClientNo);
            l_objDbWorkItem.AddParameter("@pn_AddressType", SqlDbType.Int, this.AddressType);

            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0) || (l_dsReturnData.Tables[0].Rows.Count == 0))
                {
                    Logger.Instance.WriteLog(this, "Initalizing Address. No data found. Client: " + this.ClientNo.ToString() + ", ClientNo: " + this.ClientNo.ToString());
                    throw new ApplicationException("No Address details found");
                }
                else
                {
                    InitializeFromDataRow(l_dsReturnData.Tables[0].Rows[0]);
                }
            }
            else
            {
                Logger.Instance.WriteLog(this, l_objDbWorkItem.ExecutionStatus);
                throw new ApplicationException(l_objDbWorkItem.ExecutionStatus.ErrorMessage, l_objDbWorkItem.ExecutionStatus.ExceptionObject);
            }
        }
        #endregion

        /// <summary>
        /// Initializes current instance from DataRow
        /// </summary>
        /// <param name="DataRow">DataRow object containing client details</param>
        #region InitializeFromDataRow
        public void InitializeFromDataRow(DataRow dataRow)
        {
            try
            {
                this.ClientNo               =  Convert.ToInt32( Utility.GetValueFromDataRow(dataRow,"n_ClientNo"));
                this.AddressType            =  Convert.ToInt32( Utility.GetValueFromDataRow(dataRow,"n_AddressType"));
                this.ContactPerson          =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_ContactPerson"));
                this.Designation            =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_Designation"));
                this.DIN                    =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_DIN"));
                this.Director               =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_Director"));
                this.UID                    =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_UID"));
                this.PANNo                  =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_PANNo"));
                this.AddressLine1           =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_AddressLine1"));
                this.AddressLine2           =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_AddressLine2"));
                this.AddressLine3           =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_AddressLine3"));
                this.AddressLine4           =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_AddressLine4"));
                this.CityStateCode          =  Convert.ToInt32(Utility.GetValueFromDataRow(dataRow,"n_CityStateCode"));
                this.City                   =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_City"));
                this.PinCode                =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_PinCode"));
                this.StateOther             =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_StateOther"));
                this.CountryCode            =  Convert.ToInt32(Utility.GetValueFromDataRow(dataRow,"n_CountryCode"));
                this.TelNoISDCode           =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_TelNoISDCode"));
                this.TelNoSTDCode           =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_TelNoSTDCode"));
                this.TelNo1                 =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_TelNo1"));
                this.TelNoOfficeISDCode	    =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_TelNoOfficeISDCode"));
                this.TelNoOfficeSTDCode	    =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_TelNoOfficeSTDCode"));
                this.TelNoOffice            =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_TelNoOffice"));
                this.Mobile1                =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_Mobile1"));
                this.Mobile2            	=  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_Mobile2"));
                this.FaxNoISDCode	        =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_FaxNoISDCode"));
                this.FaxNoSTDCode	        =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_FaxNoSTDCode"));
                this.FaxNo	                =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_FaxNo"));
                this.EMailId                =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_EMailId"));
                this.CCEmail                =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_CCEmail"));
                this.BCCMail                =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_BCCMail"));
                this.Default                =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_Default"));
                this.ContactPersonDefault	=  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_ContactPersonDefault"));
                this.SameCorrPermAdd        =  Convert.ToString( Utility.GetValueFromDataRow(dataRow,"s_SameCorrPermAdd"));
                this.UserNo	                =  Convert.ToInt32( Utility.GetValueFromDataRow(dataRow,"n_UserNo"));
                this.LastModifiedDateTime	=  Convert.ToDateTime(Utility.GetValueFromDataRow(dataRow,"d_LastModifiedDateTime"));
                this.StateNumber            =  Convert.ToInt32( Utility.GetValueFromDataRow(dataRow,"n_StateNumber"));
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                throw ex;
            }
        }
        #endregion

    }
}
