﻿using System;
using System.Collections.Generic;
using System.Text;
using FTIL.Match.Common.Db;
using FTIL.Match.Common;
using System.Data;
using FTIL.Match.Common.Log;
using System.ComponentModel;

namespace UCC.Class.Master
{
    class CSystemParam
    {
        #region Types

        /// <summary>
        /// System parameters enum
        /// </summary>
        #region SysParam (enum)
        [DefaultValue(0)]
        public enum SysParam
        {
            None = 0,
            MakerCheckerClient = 1
        }
        #endregion

        /// <summary>
        /// System parameter entity
        /// </summary>
        #region SystemParam(struct)
        public struct SystemParam
        {
            public int SysParamNo;
            public string SysParamDesc;
            public string SysParamValue;
        }
        #endregion

        #endregion

        #region Variables

        /// <summary>
        /// Collection of System parameters as defined in database
        /// </summary>
        private Dictionary<SysParam, SystemParam> m_dicSysParamCollection;

        #endregion

        #region Singleton

        /// <summary>
        /// Only instance of a class
        /// </summary>
        private static CSystemParam m_objInstance;
        
        /// <summary>
        /// Only instance of a class
        /// </summary>
        public static CSystemParam Instance { get { return m_objInstance; } }

        /// <summary>
        /// Static constructor to initialize singleton instance
        /// </summary>
        static CSystemParam()
        {
            m_objInstance = new CSystemParam();
        }

        /// <summary>
        /// Initializes new instance of CSystemParam using ClientSysParamNo
        /// </summary>
        /// <param name="n_ClientSysParamNo">Unique ClientSysParamNo</param>
        private CSystemParam()
        {
            m_dicSysParamCollection = new Dictionary<SysParam, SystemParam>();
            Initialize();
        }

        #endregion
        
        #region Methods

        /// <summary>
        /// Initializes current instance with database defined system parameters
        /// </summary>
        #region Initialize
        private void Initialize()
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCRetrieveSystemParameters");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0) || (l_dsReturnData.Tables[0].Rows.Count == 0))
                {
                    Logger.Instance.WriteLog(this, "Initalizing System Parameter Collection. No data found.");
                }
                else
                {
                    m_dicSysParamCollection.Clear();
                    DataTable l_dtSysParam = l_dsReturnData.Tables[0];
                    for (int l_iRowCounter = 0; l_iRowCounter < l_dtSysParam.Rows.Count; l_iRowCounter++)
                    {
                        SystemParam l_objNewSysParam;
                        l_objNewSysParam.SysParamNo = Convert.ToInt32(l_dtSysParam.Rows[l_iRowCounter]["n_SysParamNo"]);
                        l_objNewSysParam.SysParamDesc = l_dtSysParam.Rows[l_iRowCounter]["s_SysParamDesc"].ToString().Trim();
                        l_objNewSysParam.SysParamValue = l_dtSysParam.Rows[l_iRowCounter]["s_SysParamValue"].ToString().Trim();

                        SysParam l_objSysParam = GetSysParamFromNo(l_objNewSysParam.SysParamNo);
                        if (l_objSysParam == SysParam.None)
                            continue;
                        m_dicSysParamCollection.Add(l_objSysParam, l_objNewSysParam);
                    }
                }
            }
            else
            {
                //_LastMethodExecResult = l_objDbWorkItem.ExecutionStatus;
                Logger.Instance.WriteLog(this, l_objDbWorkItem.ExecutionStatus);
            }
        }
        #endregion

        /// <summary>
        /// Converts input number to respective SysParam enum
        /// </summary>
        /// <param name="p_viSysParamNo"></param>
        /// <returns></returns>
        #region GetSysParamFromNo
        private SysParam GetSysParamFromNo(int p_viSysParamNo)
        {
            switch (p_viSysParamNo)
            {
                case 1:
                    return SysParam.MakerCheckerClient;
                    break;
            }

            return SysParam.None;
        }
        #endregion

        #endregion

        #region Properties

        /// <summary>
        /// Returns system parameter details for specified type
        /// </summary>
        /// <param name="SysParam">System parameter type</param>
        /// <returns>System parameter (struct) object</returns>
        #region Indexer (SysParam)
        public SystemParam this[SysParam SysParam]
        {
            get
            {
                if (m_dicSysParamCollection.ContainsKey(SysParam))
                    return m_dicSysParamCollection[SysParam];
                return new SystemParam();
            }
        }
        #endregion

        #endregion
    }
}
