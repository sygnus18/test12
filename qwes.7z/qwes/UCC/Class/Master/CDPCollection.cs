﻿using System;
using System.Collections.Generic;
using System.Text;
using FTIL.Match.Common.Db;
using System.Data;
using FTIL.Match.Common;
using FTIL.Match.Common.Log;

namespace UCC.Class.Master
{
    /// <summary>
    /// This class represents DP entity
    /// </summary>
    public class CDPCollection
    {
        #region Variables

        /// <summary>
        /// Indicates if current instance has been initialized from database
        /// </summary>
        private Dictionary<int, CDP> m_dicDPCollection;

        #endregion

        #region Singleton

        /// <summary>
        /// Only instance of a class
        /// </summary>
        private static CDPCollection m_objInstance;
        /// <summary>
        /// Only instance of a class
        /// </summary>
        public static CDPCollection Instance { get { return m_objInstance; } }

        /// <summary>
        /// Static constructor to initialize singleton instance
        /// </summary>
        static CDPCollection()
        {
            m_objInstance = new CDPCollection();
        }

        /// <summary>
        /// Initializes new instance of CDPCollection using ClientDPNo
        /// </summary>
        /// <param name="n_ClientDPNo">Unique ClientDPNo</param>
        private CDPCollection()
        {
            m_dicDPCollection = new Dictionary<int,CDP>();
            Initialize();
        }

        #endregion

        #region Methods

        /// <summary>
        /// Initializes current instance from database for given ClientNo
        /// </summary>
        #region Initialize
        private void Initialize()
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCRetrieveDPMasterData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0) || (l_dsReturnData.Tables[0].Rows.Count == 0))
                {
                    Logger.Instance.WriteLog(this, "Initalizing DP Collection. No data found.");
                }
                else
                {
                    m_dicDPCollection.Clear();
                    DataTable l_dtDP = l_dsReturnData.Tables[0];
                    for (int l_iRowCounter = 0; l_iRowCounter < l_dtDP.Rows.Count; l_iRowCounter++)
                    {
                        CDP l_objNewDP = new CDP(
                            Convert.ToInt32(l_dtDP.Rows[l_iRowCounter]["n_DPNo"]),
                            l_dtDP.Rows[l_iRowCounter]["s_DPCode"].ToString().Trim(),
                            l_dtDP.Rows[l_iRowCounter]["s_DPName"].ToString().Trim(),
                            l_dtDP.Rows[l_iRowCounter]["s_Depository"].ToString().Trim()
                            );

                        m_dicDPCollection.Add(l_objNewDP.DPNo, l_objNewDP);
                    }
                }
            }
            else
            {
                _LastMethodExecResult = l_objDbWorkItem.ExecutionStatus;
                Logger.Instance.WriteLog(this, l_objDbWorkItem.ExecutionStatus);
            }
        }
        #endregion

        #endregion

        #region Properties

        #region ClientNo
        /// <summary>
        /// ClientNo
        /// </summary>
        public CDP this[int DPNo]
        {
            get 
            {
                if (m_dicDPCollection.ContainsKey(DPNo))
                    return m_dicDPCollection[DPNo];
                return null;
            }
        }
        #endregion

        #region AllDP
        /// <summary>
        /// ClientNo
        /// </summary>
        public List<CDP> AllDP
        {
            get
            {
                List<CDP> l_lstAllDP = new List<CDP>(m_dicDPCollection.Count);
                foreach (KeyValuePair<int, CDP> l_objDP in m_dicDPCollection)
                    l_lstAllDP.Add(l_objDP.Value);
                return l_lstAllDP;
            }
        }
        #endregion
        
        #region LastMethodExecResult
        private MethodExecResult _LastMethodExecResult;
        /// <summary>
        /// Last Method execution result
        /// </summary>
        public MethodExecResult LastMethodExecResult
        {
            get { return _LastMethodExecResult; }
        }
        #endregion

        #endregion
    }
}
