﻿using System;
using System.Collections.Generic;
using System.Text;
using FTIL.Match.Common.Db;
using System.Data;
using FTIL.Match.Common;
using FTIL.Match.Common.Log;
using System.ComponentModel;
using System.Data.SqlClient;
using UCC.Class.Validator;

namespace UCC.Class.Master
{
    /// <summary>
    /// This class represents Client entity
    /// </summary>
    public class CClient
    {
        #region Variables

        /// <summary>
        /// Indicates if current instance has been initialized from database
        /// </summary>
        private bool m_bInitialized;

        private CClient m_objOriginalClient;

        #endregion

        #region Constructor
        /// <summary>
        /// Initializes new instance of CClient using Client Code
        /// </summary>
        /// <param name="ClientCode"></param>
        public CClient(string ClientCode)
        {
            _ClientCode = ClientCode;
            Initialize(AppEnvironment.AppUser.UserNo);
        }

        /// <summary>
        /// Initializes new instance of CClient using ClientNo
        /// </summary>
        /// <param name="ClientCode"></param>
        public CClient(int ClientNo)
        {
            _ClientNo = ClientNo;
            Initialize(AppEnvironment.AppUser.UserNo);
        }

        /// <summary>
        /// Initializes new instance of CClient using ClientNo
        /// </summary>
        /// <param name="ClientCode"></param>
        public CClient(int ClientNo, bool InitializeClient)
        {
            _ClientNo = ClientNo;
            if (InitializeClient)
                Initialize(AppEnvironment.AppUser.UserNo);
        }

        /// <summary>
        /// Initializes new instance of CClient using Client Code and said userNo
        /// </summary>
        /// <param name="ClientCode"></param>
        public CClient(string ClientCode,Int32 p_nUserNo)
        {
            _ClientCode = ClientCode;
            Initialize(p_nUserNo);
        }

        #endregion


        #region Methods

        /// <summary>
        /// Initializes current instance from database with given ClientCode/ClientNo
        /// </summary>
        #region Initialize
        private void Initialize(Int32 p_nUserNo)
        {
            if (m_bInitialized)
                return;

            m_bInitialized = true;

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCRetrieveClientData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@ps_ClientCode", SqlDbType.VarChar, this.ClientCode);
            l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, this.ClientNo);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, p_nUserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0) || (l_dsReturnData.Tables[0].Rows.Count == 0))
                {
                    Logger.Instance.WriteLog(this, "Initalizing Client. No data found. Client: " + this.ClientCode + ", ClientNo: " + this.ClientNo.ToString());
                    throw new ApplicationException("No client details found");
                }
                else
                {
                    //If under authorisation client, take new changes in main client object and original object in originalClient object
                    if ((l_dsReturnData.Tables.Count > 1) && (l_dsReturnData.Tables[1].Rows.Count > 0))
                    {
                    InitializeFromDataRow(l_dsReturnData.Tables[0].Rows[0]);

                        this.m_objOriginalClient = new CClient(this.ClientNo, false);
                        CClient.InstantiateFromDataRow(m_objOriginalClient, l_dsReturnData.Tables[1].Rows[0]);
                }
                    else
                    {
                        InitializeFromDataRow(l_dsReturnData.Tables[0].Rows[0]);
            }
                }
            }
            else
            {
                Logger.Instance.WriteLog(this, l_objDbWorkItem.ExecutionStatus);
                throw new ApplicationException(l_objDbWorkItem.ExecutionStatus.ErrorMessage, l_objDbWorkItem.ExecutionStatus.ExceptionObject);
            }
        }
        #endregion

        /// <summary>
        /// Refresh the current client details
        /// </summary>
        #region ReInitialize
        public void ReInitialize()
        {
            this.Initialize(AppEnvironment.AppUser.UserNo);
        }
        #endregion

        /// <summary>
        /// Initializes current instance from DataRow
        /// </summary>
        /// <param name="DataRow">DataRow object containing client details</param>
        #region InitializeFromDataRow
        public void InitializeFromDataRow(DataRow DataRow)
        {
            try
            {
                CClient.InstantiateFromDataRow(this, DataRow);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                throw ex;
            }
        }
        #endregion

        /// <summary>
        /// Creates instance from DataRow
        /// </summary>
        /// <param name="DataRow">DataRow object containing client details</param>
        #region InstantiateFromDataRow
        private static void InstantiateFromDataRow(CClient m_objClient, DataRow DataRow)
        {
            try
            {
                m_objClient.ClientNo = Convert.ToInt32(DataRow["n_ClientNo"]);
                m_objClient.ClientCode = DataRow["s_ClientCode"].ToString().Trim();
                m_objClient.ClientName = DataRow["s_ClientName"].ToString().Trim();
                if ((DataRow["s_PANNo"] != null) && (DataRow["s_PANNo"] != DBNull.Value))
                    m_objClient.PANNo = DataRow["s_PANNo"].ToString().Trim();
                if ((DataRow["s_Gender"] != null) && (DataRow["s_Gender"] != DBNull.Value))
                    m_objClient.Gender = DataRow["s_Gender"].ToString().Trim();
                if ((DataRow["s_GuardianName"] != null) && (DataRow["s_GuardianName"] != DBNull.Value))
                    m_objClient.GuardianName = DataRow["s_GuardianName"].ToString().Trim();
                if ((DataRow["s_MaritalStatus"] != null) && (DataRow["s_MaritalStatus"] != DBNull.Value))
                    m_objClient.MaritalStatus = DataRow["s_MaritalStatus"].ToString().Trim();
                if ((DataRow["n_Nationality"] != null) && (DataRow["n_Nationality"] != DBNull.Value))
                    m_objClient.Nationality = Convert.ToByte(DataRow["n_Nationality"]);
                if ((DataRow["s_NationalityOther"] != null) && (DataRow["s_NationalityOther"] != DBNull.Value))
                    m_objClient.NationalityOther = DataRow["s_NationalityOther"].ToString().Trim();
                if ((DataRow["s_PanExempt"] != null) && (DataRow["s_PanExempt"] != DBNull.Value))
                    m_objClient.PanExempt = DataRow["s_PanExempt"].ToString().Trim();
                if ((DataRow["s_CorporateIdNo"] != null) && (DataRow["s_CorporateIdNo"] != DBNull.Value))
                    m_objClient.CorporateIdNo = DataRow["s_CorporateIdNo"].ToString().Trim();
                if ((DataRow["s_CINExempt"] != null) && (DataRow["s_CINExempt"] != DBNull.Value))
                    m_objClient.CINExempt = DataRow["s_CINExempt"].ToString().Trim();
                if ((DataRow["d_DOB"] != null) && (DataRow["d_DOB"] != DBNull.Value))
                    m_objClient.DOB = Convert.ToDateTime(DataRow["d_DOB"]);
                if ((DataRow["d_CreationDate"] != null) && (DataRow["d_CreationDate"] != DBNull.Value))
                    m_objClient.CreationDate = Convert.ToDateTime(DataRow["d_CreationDate"]);
                if ((DataRow["n_GrAnnIncRange"] != null) && (DataRow["n_GrAnnIncRange"] != DBNull.Value))
                    m_objClient.GrAnnIncRange = Convert.ToInt32(DataRow["n_GrAnnIncRange"]);
                if ((DataRow["d_GrAnnIncAsOnDate"] != null) && (DataRow["d_GrAnnIncAsOnDate"] != DBNull.Value))
                    m_objClient.GrAnnIncAsOnDate = Convert.ToDateTime(DataRow["d_GrAnnIncAsOnDate"]);
                if ((DataRow["n_NetWorth"] != null) && (DataRow["n_NetWorth"] != DBNull.Value))
                    m_objClient.NetWorth = Convert.ToDecimal(DataRow["n_NetWorth"]);
                if ((DataRow["d_NetWorthAsOnDate"] != null) && (DataRow["d_NetWorthAsOnDate"] != DBNull.Value))
                    m_objClient.NetWorthAsOnDate = Convert.ToDateTime(DataRow["d_NetWorthAsOnDate"]);
                if ((DataRow["n_PEP"] != null) && (DataRow["n_PEP"] != DBNull.Value))
                    m_objClient.PEP = Convert.ToByte(DataRow["n_PEP"]);
                if ((DataRow["s_PlaceofIncorporation"] != null) && (DataRow["s_PlaceofIncorporation"] != DBNull.Value))
                    m_objClient.PlaceofIncorporation = DataRow["s_PlaceofIncorporation"].ToString().Trim();
                if ((DataRow["n_Occupation"] != null) && (DataRow["n_Occupation"] != DBNull.Value))
                    m_objClient.Occupation = Convert.ToInt32(DataRow["n_Occupation"]);
                if ((DataRow["s_OccupationOthers"] != null) && (DataRow["s_OccupationOthers"] != DBNull.Value))
                    m_objClient.OccupationOthers = DataRow["s_OccupationOthers"].ToString().Trim();
                if ((DataRow["d_CommOfBusiness"] != null) && (DataRow["d_CommOfBusiness"] != DBNull.Value))
                    m_objClient.CommOfBusiness = Convert.ToDateTime(DataRow["d_CommOfBusiness"]);
                if ((DataRow["s_UCCCode"] != null) && (DataRow["s_UCCCode"] != DBNull.Value))
                    m_objClient.UCCCode = DataRow["s_UCCCode"].ToString().Trim();
                if ((DataRow["s_UpdationFlag"] != null) && (DataRow["s_UpdationFlag"] != DBNull.Value))
                    m_objClient.UpdationFlag = DataRow["s_UpdationFlag"].ToString().Trim();
                //if ((DataRow["s_Relationship"] != null) && (DataRow["s_Relationship"] != DBNull.Value))
                //    m_objClient.Relationship = DataRow["s_Relationship"].ToString().Trim();
                if ((DataRow["s_TypeofFacility"] != null) && (DataRow["s_TypeofFacility"] != DBNull.Value))
                    m_objClient.TypeofFacility = DataRow["s_TypeofFacility"].ToString().Trim();
                if ((DataRow["s_ClientTypeCorporate"] != null) && (DataRow["s_ClientTypeCorporate"] != DBNull.Value))
                    m_objClient.ClientTypeCorporate = DataRow["s_ClientTypeCorporate"].ToString().Trim();
                if ((DataRow["s_IsPendingAuth"] != null) && (DataRow["s_IsPendingAuth"] != DBNull.Value))
                    m_objClient.IsPendingAuth = (DataRow["s_IsPendingAuth"].ToString().Trim() == "Y");
                if ((DataRow["n_MakerUser"] != null) && (DataRow["n_MakerUser"] != DBNull.Value))
                    m_objClient.MakerUser = Convert.ToInt32(DataRow["n_MakerUser"]);
                if (DataRow.Table.Columns.Contains("n_UCCType")==true && (DataRow["n_UCCType"] != null) && (DataRow["n_UCCType"] != DBNull.Value))
                    m_objClient.UCCType = Convert.ToInt32(DataRow["n_UCCType"]);
                if ((DataRow.Table.Columns.Contains("n_OwnClient") == true && DataRow["n_OwnClient"] != null) && (DataRow["n_OwnClient"] != DBNull.Value))
                    m_objClient.ClientStatus = Convert.ToInt32(DataRow["n_OwnClient"]);
                m_objClient.LastUserNo = Convert.ToInt32(DataRow["n_LastUserNo"]);
                m_objClient.LastModifiedDateTime = Convert.ToDateTime(DataRow["d_LastModifiedDateTime"]);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(m_objClient, ex);
				throw ex;
            }
        }

        #endregion

        /// <summary>
        /// Set Address Details from DataTable
        /// </summary>
        /// <param name="dtAddress">Address DataTable</param>
        #region SetClientAddressesFromDataTable
        public void SetClientAddressesFromDataTable(DataTable dtAddress)
        {
            try
            {
                this.ClientAddresses = new CAddressCollection();

                DataRow[] addresses = dtAddress.Select(" n_ClientNo =  " + this.ClientNo);

                if ((addresses == null) || (addresses.Length == 0))
                {
                    Logger.Instance.WriteLog(this, "Setting ClientAddresses From DataTable. No data found. ClientNo: " + this.ClientNo);
                }
                else
                {
                    for (int i = 0; i < addresses.Length; i++)
                    {
                        CAddress address = new CAddress();
                        address.InitializeFromDataRow(addresses[i]);
                        this.ClientAddresses.Add(address);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                throw ex;
            }
        }
        #endregion

        /// <summary>
        /// Set KYC Additional Details from DataTable
        /// </summary>
        /// <param name="dtAddress">Address DataTable</param>
        #region SetClientAddressesFromDataTable
        public void SetAdditionalDetailsFromDataTable(DataTable dtKYCDetail)
        {
            try 
            {
                DataRow[] l_drKYCdetails = dtKYCDetail.Select(" DealerNo =  " + this.ClientNo);

                if ((l_drKYCdetails == null) || (l_drKYCdetails.Length == 0))
                {
                    Logger.Instance.WriteLog(this, "Setting KYCAdditionalDetail From DataTable. No data found. ClientNo: " + this.ClientNo);
                }
                else
                {
                    _KYCAdditionalDetail = new CKYCAdditionalDetail();
                    _KYCAdditionalDetail.InitializeFromDataRow(l_drKYCdetails[0]);

                    if ((l_drKYCdetails[0]["ClientType"] != null) && (l_drKYCdetails[0]["ClientType"] != DBNull.Value))
                        this.ClientType = Convert.ToChar(l_drKYCdetails[0]["ClientType"]);

                    if ((l_drKYCdetails[0]["ActiveDate"] != null) && (l_drKYCdetails[0]["ActiveDate"] != DBNull.Value))
                        this.ClientActivationDate = Convert.ToDateTime(l_drKYCdetails[0]["ActiveDate"]);

                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                throw ex;
            }
        }




        #endregion


        /// <summary>
        /// Updates current instance changes to database
        /// </summary>
        /// <returns>Method Execution Result</returns>
        #region Update
        public MethodExecResult Update()
        {
            Int32? l_GrAnnIncRange = this.GrAnnIncRange == Convert.ToInt32(CUCCConstants.Instance.GROSS_ANNUAL_INC_BLANK) ? null : this.GrAnnIncRange;
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCUpdateClientData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;
            //l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, this.);
            l_objDbWorkItem.AddParameter("@ps_ClientCode", SqlDbType.VarChar, this.ClientCode);
            l_objDbWorkItem.AddParameter("@ps_ClientName", SqlDbType.VarChar, this.ClientName);
            //l_objDbWorkItem.AddParameter("@pn_ClientType", SqlDbType.Int, this.);
            l_objDbWorkItem.AddParameter("@ps_PANNo", SqlDbType.VarChar, this.PANNo);
            l_objDbWorkItem.AddParameter("@ps_Gender", SqlDbType.VarChar, this.Gender);
            l_objDbWorkItem.AddParameter("@ps_GuardianName", SqlDbType.VarChar, this.GuardianName);
            l_objDbWorkItem.AddParameter("@ps_MaritalStatus", SqlDbType.VarChar, this.MaritalStatus);
            l_objDbWorkItem.AddParameter("@pn_Nationality", SqlDbType.Int, this.Nationality);
            l_objDbWorkItem.AddParameter("@ps_NationalityOther", SqlDbType.VarChar, this.NationalityOther);
            l_objDbWorkItem.AddParameter("@ps_PanExempt", SqlDbType.VarChar, this.PanExempt);
            l_objDbWorkItem.AddParameter("@ps_CorporateIdNo", SqlDbType.VarChar, this.CorporateIdNo);
            l_objDbWorkItem.AddParameter("@pd_DOB", SqlDbType.DateTime, this.DOB);
            l_objDbWorkItem.AddParameter("@pd_CreationDate", SqlDbType.DateTime, this.CreationDate);
            l_objDbWorkItem.AddParameter("@pn_GrAnnIncRange", SqlDbType.Int, l_GrAnnIncRange);
            l_objDbWorkItem.AddParameter("@pd_GrAnnIncAsOnDate", SqlDbType.DateTime, this.GrAnnIncAsOnDate);
            l_objDbWorkItem.AddParameter("@pn_NetWorth", SqlDbType.Decimal, this.NetWorth);
            l_objDbWorkItem.AddParameter("@pd_NetWorthAsOnDate", SqlDbType.DateTime, this.NetWorthAsOnDate);
            l_objDbWorkItem.AddParameter("@pn_PEP", SqlDbType.Int, this.PEP);
            l_objDbWorkItem.AddParameter("@ps_PlaceofIncorporation", SqlDbType.VarChar, this.PlaceofIncorporation);
            l_objDbWorkItem.AddParameter("@pn_Occupation", SqlDbType.Int, this.Occupation);
            l_objDbWorkItem.AddParameter("@ps_OccupationOthers", SqlDbType.VarChar, this.OccupationOthers);
            l_objDbWorkItem.AddParameter("@pd_CommOfBusiness", SqlDbType.DateTime, this.CommOfBusiness);
            l_objDbWorkItem.AddParameter("@ps_UCCCode", SqlDbType.VarChar, this.UCCCode);
            l_objDbWorkItem.AddParameter("@ps_CINExempt", SqlDbType.VarChar, this.CINExempt);
            l_objDbWorkItem.AddParameter("@ps_UpdationFlag", SqlDbType.VarChar, this.UpdationFlag);
            //l_objDbWorkItem.AddParameter("@ps_Relationship", SqlDbType.VarChar, this.Relationship);
            l_objDbWorkItem.AddParameter("@ps_TypeofFacility", SqlDbType.VarChar, this.TypeofFacility);
            l_objDbWorkItem.AddParameter("@ps_ClientTypeCorporate", SqlDbType.VarChar, this.ClientTypeCorporate);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.VarChar, AppEnvironment.AppUser.UserNo);
            l_objDbWorkItem.AddParameter("@pn_ClientType", SqlDbType.VarChar, this.UCCType);
            l_objDbWorkItem.AddParameter("@pn_ClientStatus", SqlDbType.VarChar, this.ClientStatus);
            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            return l_objDbWorkItem.ExecutionStatus;
        }
        #endregion

        /// <summary>
        /// Validate UCC related field for all exchanges linked with the client
        /// </summary>
        /// <returns></returns>
        public DataTable Validate()
        {
            CValidatorManager l_ValidateManager=new CValidatorManager();
            foreach (CUCCClientExchangeMapping Exchanges in this.ClientExchanges)
            {
                if (Exchanges.Segment == 2)
                    continue;
                switch(Exchanges.ExchangeType)
                {
                    case "NSE":
                        l_ValidateManager.Validate(new CNSEValidator(), EntityType.UCCInfo, new List<CClient>() { this });
                        break;
                    case "BSE":
                        l_ValidateManager.Validate(new CBSEValidator(), EntityType.UCCInfo, new List<CClient>() { this });
                        break;
                    //case "MCX-SX":
                    //    l_ValidateManager.Validate(new CMCXValidator(), EntityType.UCCInfo, new List<CClient>() { this });
                    //    break;

                }
            }
            return l_ValidateManager.ValidationResult;
        }
        #endregion

        #region Properties

        #region OriginalClient
        /// <summary>
        /// Original Client details of current client (when Maker/Checker enabled)
        /// </summary>
        public CClient OriginalClient
        {
            get { return m_objOriginalClient; }
        }
        #endregion

        #region ClientNo
        private Int32 _ClientNo;
        /// <summary>
        /// ClientNo
        /// </summary>
        public Int32 ClientNo
        {
            get { return _ClientNo; }
            set { _ClientNo = value; }
        }
        #endregion

        #region ClientCode
        private string _ClientCode;
        /// <summary>
        /// ClientCode
        /// </summary>
        public string ClientCode
        {
            get { return _ClientCode; }
            set { _ClientCode = value; }
        }
        #endregion

        #region ClientName
        private string _ClientName;
        /// <summary>
        /// ClientName
        /// </summary>
        public string ClientName
        {
            get { return _ClientName; }
            set { _ClientName = value; }
        }
        #endregion

        #region PANNo
        private string _PANNo;
        /// <summary>
        /// PANNo
        /// </summary>
        public string PANNo
        {
            get { return _PANNo; }
            set { _PANNo = value; }
        }

        /// <summary>
        /// List of Exchanges link with the client
        /// </summary>
        public List<CUCCClientExchangeMapping> ClientExchanges { get; set; }

        public CAddressCollection ClientAddresses { get; set; }

        /// <summary>
        /// List of Addresses link with the client
        /// </summary>
        public List<CUCCClientAddress> ClientAddressesNew { get; set; }

        /// <summary>
        /// List of Banks link with the client
        /// </summary>
        public List<CClientBank> ClientBanks { get; set; }

        /// <summary>
        /// List of DPs link with the client
        /// </summary>
        public List<CClientDP> ClientDPs { get; set; }


        #endregion

        #region Gender
        private string _Gender;
        /// <summary>
        /// Gender
        /// </summary>
        public string Gender
        {
            get { return _Gender; }
            set { _Gender = value; }
        }
        #endregion

        #region GuardianName
        private string _GuardianName;
        /// <summary>
        /// GuardianName
        /// </summary>
        public string GuardianName
        {
            get { return _GuardianName; }
            set { _GuardianName = value; }
        }
        #endregion

        #region MaritalStatus
        private string _MaritalStatus;
        /// <summary>
        /// MaritalStatus
        /// </summary>
        public string MaritalStatus
        {
            get { return _MaritalStatus; }
            set { _MaritalStatus = value; }
        }
        #endregion

        #region Nationality
        private Byte? _Nationality;
        /// <summary>
        /// Nationality
        /// </summary>
        public Byte? Nationality
        {
            get { return _Nationality; }
            set { _Nationality = value; }
        }
        #endregion

        #region NationalityOther
        private string _NationalityOther;
        /// <summary>
        /// NationalityOther
        /// </summary>
        public string NationalityOther
        {
            get { return _NationalityOther; }
            set { _NationalityOther = value; }
        }
        #endregion

        #region PanExempt
        private string _PanExempt;
        /// <summary>
        /// PanExempt
        /// </summary>
        public string PanExempt
        {
            get { return _PanExempt; }
            set { _PanExempt = value; }
        }
        #endregion

        #region CorporateIdNo
        private string _CorporateIdNo;
        /// <summary>
        /// CorporateIdNo
        /// </summary>
        public string CorporateIdNo
        {
            get { return _CorporateIdNo; }
            set { _CorporateIdNo = value; }
        }
        #endregion

        #region CINExempt
        private string _CINExempt;
        /// <summary>
        /// CINExempt
        /// </summary>
        public string CINExempt
        {
            get { return _CINExempt; }
            set { _CINExempt = value; }
        }
        #endregion

        #region DOB
        private DateTime? _DOB;
        /// <summary>
        /// DOB
        /// </summary>
        public DateTime? DOB
        {
            get { return _DOB; }
            set { _DOB = value; }
        }
        #endregion

        #region CreationDate
        private DateTime? _CreationDate;
        /// <summary>
        /// CreationDate
        /// </summary>
        public DateTime? CreationDate
        {
            get { return _CreationDate; }
            set { _CreationDate = value; }
        }
        #endregion

        #region GrAnnIncRange
        private Int32? _GrAnnIncRange;
        /// <summary>
        /// GrAnnIncRange
        /// </summary>
        public Int32? GrAnnIncRange
        {
            get { return _GrAnnIncRange; }
            set { _GrAnnIncRange = value; }
        }
        #endregion

        #region GrAnnIncAsOnDate
        private DateTime? _GrAnnIncAsOnDate;
        /// <summary>
        /// GrAnnIncAsOnDate
        /// </summary>
        public DateTime? GrAnnIncAsOnDate
        {
            get { return _GrAnnIncAsOnDate; }
            set { _GrAnnIncAsOnDate = value; }
        }
        #endregion

        #region NetWorth
        private Decimal? _NetWorth;
        /// <summary>
        /// NetWorth
        /// </summary>
        public Decimal? NetWorth
        {
            get { return _NetWorth; }
            set { _NetWorth = value; }
        }
        #endregion

        #region NetWorthAsOnDate
        private DateTime? _NetWorthAsOnDate;
        /// <summary>
        /// NetWorthAsOnDate
        /// </summary>
        public DateTime? NetWorthAsOnDate
        {
            get { return _NetWorthAsOnDate; }
            set { _NetWorthAsOnDate = value; }
        }
        #endregion

        #region PEP
        private Byte? _PEP;
        /// <summary>
        /// PEP
        /// </summary>
        public Byte? PEP
        {
            get { return _PEP; }
            set { _PEP = value; }
        }
        #endregion

        #region PlaceofIncorporation
        private string _PlaceofIncorporation;
        /// <summary>
        /// PlaceofIncorporation
        /// </summary>
        public string PlaceofIncorporation
        {
            get { return _PlaceofIncorporation; }
            set { _PlaceofIncorporation = value; }
        }
        #endregion

        #region Occupation
        private Int32? _Occupation;
        /// <summary>
        /// Occupation
        /// </summary>
        public Int32? Occupation
        {
            get { return _Occupation; }
            set { _Occupation = value; }
        }
        #endregion

        #region OccupationOthers
        private string _OccupationOthers;
        /// <summary>
        /// OccupationOthers
        /// </summary>
        public string OccupationOthers
        {
            get { return _OccupationOthers; }
            set { _OccupationOthers = value; }
        }
        #endregion

        #region CommOfBusiness
        private DateTime? _CommOfBusiness;
        /// <summary>
        /// CommOfBusiness
        /// </summary>
        public DateTime? CommOfBusiness
        {
            get { return _CommOfBusiness; }
            set { _CommOfBusiness = value; }
        }
        #endregion

        #region UCCCode
        private string _UCCCode;
        /// <summary>
        /// UCCCode
        /// </summary>
        public string UCCCode
        {
            get { return _UCCCode; }
            set { _UCCCode = value; }
        }
        #endregion

        #region UpdationFlag
        private string _UpdationFlag;
        /// <summary>
        /// UpdationFlag
        /// </summary>
        public string UpdationFlag
        {
            get { return _UpdationFlag; }
            set { _UpdationFlag = value; }
        }
        #endregion

        //#region Relationship
        //private string _Relationship;
        ///// <summary>
        ///// Relationship
        ///// </summary>
        //public string Relationship
        //{
        //    get { return _Relationship; }
        //    set { _Relationship = value; }
        //}
        //#endregion

        #region TypeofFacility
        private string _TypeofFacility;
        /// <summary>
        /// TypeofFacility
        /// </summary>
        public string TypeofFacility
        {
            get { return _TypeofFacility; }
            set { _TypeofFacility = value; }
        }
        #endregion

        #region ClientTypeCorporate
        private string _ClientTypeCorporate;
        /// <summary>
        /// ClientTypeCorporate
        /// </summary>
        public string ClientTypeCorporate
        {
            get { return _ClientTypeCorporate; }
            set { _ClientTypeCorporate = value; }
        }
        #endregion

        #region IsPendingAuth
        private bool _IsPendingAuth;
        /// <summary>
        /// Indicates if current client is under authorisation
        /// </summary>
        public bool IsPendingAuth
        {
            get { return _IsPendingAuth; }
            set { _IsPendingAuth= CSystemParam.Instance[CSystemParam.SysParam.MakerCheckerClient].SysParamValue == "Y"? value:false; }
        }
        #endregion

        #region MakerUser
        private int _MakerUser;
        /// <summary>
        /// Maker User No
        /// </summary>
        public int MakerUser
        {
            get { return _MakerUser; }
            set { _MakerUser = value; }
        }
        #endregion

        #region AllowModificationsToCurrentUser
        /// <summary>
        /// Indicates if current record is under authorisation then current application user can modify it?
        /// </summary>
        public bool AllowModificationsToCurrentUser
        {
            get 
            {
                if ((this.IsPendingAuth)
                    && (this.MakerUser != AppEnvironment.AppUser.UserNo)
                  )
                {
                    return false;
                }

                return true;
            }
        }
        #endregion

        #region LastUserNo
        private Int32 _LastUserNo;
        /// <summary>
        /// LastUserNo
        /// </summary>
        public Int32 LastUserNo
        {
            get { return _LastUserNo; }
            set { _LastUserNo = value; }
        }
        #endregion

        #region LastModifiedDateTime
        private DateTime _LastModifiedDateTime;
        /// <summary>
        /// LastModifiedDateTime
        /// </summary>
        public DateTime LastModifiedDateTime
        {
            get { return _LastModifiedDateTime; }
            set { _LastModifiedDateTime = value; }
        }
        #endregion


       
        /// <summary>
        /// Used to view the client screen in checker view mode
        /// </summary>
        private Boolean _IsCheckerView = false;
        public Boolean IsCheckerView
        { 
            get{return _IsCheckerView;}
            set { _IsCheckerView = value; }
        }

        #region ClientType

        private char m_ClientType;
        /// <summary>
        /// ClientType : 'I' = Individual 'N'= Non-Individual
        /// </summary>
        public char ClientType
        {
            get { return m_ClientType; }
            set { m_ClientType = value; }
        }
        #endregion 

        
        #region ClientActivationDate
       
        private DateTime? m_ClientActivationDate;
        /// <summary>
        /// Client Activation Date
        /// </summary>
        public DateTime? ClientActivationDate
        {
            get { return m_ClientActivationDate; }
            set { m_ClientActivationDate = value; }
        }
        #endregion 

        #region UCCType
        private Int32? _UCCType;
        /// <summary>
        /// Occupation
        /// </summary>
        public Int32? UCCType
        {
            get { return _UCCType; }
            set { _UCCType = value; }
        }
        #endregion

        #region ClientStatus
        private Int32? _ClientStatus;
        /// <summary>
        /// Occupation
        /// </summary>
        public Int32? ClientStatus
        {
            get { return _ClientStatus; }
            set { _ClientStatus = value; }
        }
        #endregion


        #region KYCAdditionalDetail
        private CKYCAdditionalDetail _KYCAdditionalDetail;
        /// <summary>
        /// LastModifiedDateTime
        /// </summary>
        public CKYCAdditionalDetail KYCAdditionalDetail
        {
            get { return _KYCAdditionalDetail; }
            set { _KYCAdditionalDetail = value; }
        }
        #endregion

        #endregion
    }
       
}
