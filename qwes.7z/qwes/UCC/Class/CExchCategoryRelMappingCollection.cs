﻿using System;
using System.Collections.Generic;
using System.Text;
using FTIL.Match.Common.Db;
using FTIL.Match.Common;
using FTIL.Match.Common.Log;
using System.Data;

namespace UCC.Class
{
    /// <summary>
    /// Collection of CExchCategoryRelMapping objects
    /// </summary>
    class CExchCategoryRelMappingCollection
    {
        #region Variables

        /// <summary>
        /// Dictionary of CExchCategoryRelMapping objects ExchangeTypewise, Categorywise
        /// </summary>
        private Dictionary<string, List<CExchCategoryRelMapping>> m_dicRefData;

        /// <summary>
        /// Indicates if instance has been initialized
        /// </summary>
        private bool m_bInitialised;

        #endregion

        #region Singleton

        /// <summary>
        /// The only instance of a class
        /// </summary>
        private static CExchCategoryRelMappingCollection m_objInstance;

        /// <summary>
        /// Private constructor to avoid instances
        /// </summary>
        private CExchCategoryRelMappingCollection() 
        {
            m_dicRefData = new Dictionary<string, List<CExchCategoryRelMapping>>();
        }

        /// <summary>
        /// Static constructor to initialize singleton instance of a class
        /// </summary>
        static CExchCategoryRelMappingCollection()
        {
            m_objInstance = new CExchCategoryRelMappingCollection();
        }

        /// <summary>
        /// Singleton instance
        /// </summary>
        public static CExchCategoryRelMappingCollection Instance
        {
            get
            {
                return m_objInstance;
            }
        }

        #endregion

        /// <summary>
        /// This indexer property returns Collection of CExchCategoryRelMapping for specified Exchange & Category
        /// </summary>
        /// <param name="ExchType"></param>
        /// <returns></returns>
        #region Property (indexer)
        public List<CExchCategoryRelMapping> this[ExchangeType ExchType, short CategoryNo]
        {
            get
            {
                if (m_bInitialised == false)
                    Initialise();

                if (m_dicRefData.ContainsKey(ExchType.ToString() + "_" + CategoryNo.ToString()))
                    return m_dicRefData[ExchType.ToString() + "_" + CategoryNo.ToString()];

                return null;
            }
        }
        #endregion

        /// <summary>
        /// This method initialises collection of Exchange Category Relationship Master from database
        /// </summary>
        #region Initialise
        private void Initialise()
        {
            if (m_bInitialised)
                return;

            m_bInitialised = true;
            m_dicRefData.Clear();

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetExchCategoryRelationshipMasterData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.VarChar, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                {
                    Logger.Instance.WriteLog(this,
                        "Exchange Category Relationship Master data not found. Proc: stp_GetExchCategoryRelationshipMasterData");
                    return;
                }

                DataTable l_dtRefData = l_dsReturnData.Tables[0];

                try
                {
                    for (int l_iRowCounter = 0; l_iRowCounter < l_dtRefData.Rows.Count; l_iRowCounter++)
                    {
                        ExchangeType l_objCurrentRowRefType = ExchangeType.None;
                        switch (l_dtRefData.Rows[l_iRowCounter]["s_ExType"].ToString())
                        {
                            case "NSE":
                                l_objCurrentRowRefType = ExchangeType.NSE;
                                break;
                            case "BSE":
                                l_objCurrentRowRefType = ExchangeType.BSE;
                                break;
                            case "MCX-SX":
                                l_objCurrentRowRefType = ExchangeType.MCXSX;
                                break;
                        }

                        if (l_objCurrentRowRefType == ExchangeType.None)
                            continue;

                        List<CExchCategoryRelMapping> l_lstCurrentRefData = null;
                        if (m_dicRefData.ContainsKey(l_objCurrentRowRefType.ToString() + "_" + l_dtRefData.Rows[l_iRowCounter]["n_CategoryNo"].ToString()))
                            l_lstCurrentRefData = m_dicRefData[l_objCurrentRowRefType.ToString() + "_" + l_dtRefData.Rows[l_iRowCounter]["n_CategoryNo"].ToString()];
                        else
                        {
                            l_lstCurrentRefData = new List<CExchCategoryRelMapping>();
                            m_dicRefData.Add(l_objCurrentRowRefType.ToString() + "_" + l_dtRefData.Rows[l_iRowCounter]["n_CategoryNo"].ToString(), l_lstCurrentRefData);
                        }

                        CExchCategoryRelMapping l_objNewMapping = new CExchCategoryRelMapping();

                        l_objNewMapping.CategpryNo = Convert.ToInt16(l_dtRefData.Rows[l_iRowCounter]["n_CategoryNo"]);
                        l_objNewMapping.ExTypeCode = l_objCurrentRowRefType;
                        l_objNewMapping.RelationshipCode = l_dtRefData.Rows[l_iRowCounter]["s_RelCode"].ToString();
                        l_objNewMapping.RelationshipName = l_dtRefData.Rows[l_iRowCounter]["s_RelName"].ToString();

                        l_lstCurrentRefData.Add(l_objNewMapping);
                    } //For Loop
                }
                catch (Exception ex)
                {
                    Logger.Instance.WriteLog(this,
                        "Error initializing Exch Category Relationship Data Collection." + ex.ToString());
                }
            }
            else
            {
                Logger.Instance.WriteLog(this, l_objDbWorkItem.ExecutionStatus);
            }
        }
        #endregion

    }
}
