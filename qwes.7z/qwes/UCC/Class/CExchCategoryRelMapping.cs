﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UCC.Class
{
    /// <summary>
    /// Represents Exchange, Category & Relationship mapping
    /// </summary>
    class CExchCategoryRelMapping
    {
        #region ExTypeCode
        private ExchangeType _ExTypeCode;
        /// <summary>
        /// Exchange Type
        /// </summary>
        public ExchangeType ExTypeCode
        {
            get { return _ExTypeCode; }
            set { _ExTypeCode = value; }
        }
        #endregion

        #region RelationshipCode
        private string _RelationshipCode;
        /// <summary>
        /// Relationship Code
        /// </summary>
        public string RelationshipCode
        {
            get { return _RelationshipCode; }
            set { _RelationshipCode = value; }
        }
        #endregion

        #region CategpryNo
        private short _CategpryNo;
        /// <summary>
        /// Client Category
        /// </summary>
        public short CategpryNo
        {
            get { return _CategpryNo; }
            set { _CategpryNo = value; }
        }
        #endregion

        #region RelationshipName
        private string _RelationshipName;
        /// <summary>
        /// Relationship Name
        /// </summary>
        public string RelationshipName
        {
            get { return _RelationshipName; }
            set { _RelationshipName = value; }
        }
        #endregion
    }
}
