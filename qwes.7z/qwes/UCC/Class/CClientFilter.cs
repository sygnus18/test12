﻿using System;
using System.Collections.Generic;
using System.Text;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using System.Data.SqlClient;
using System.Data;
using System.Collections;

namespace UCC.Class
{
    /// <summary>
    /// BL of Client filter window
    /// </summary>
    public class CClientFilter
    {
        /// <summary>
        /// Used for Populating Filter Control
        /// </summary>
        /// <param name="p_vdtUCCLookUpData">Return Data set containing master data</param>
        /// <returns></returns>
        #region GetUCCClientFilterLookUpData
        public MethodExecResult GetUCCClientFilterLookUpData(ref DataSet p_vdtUCCLookUpData)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_FilterPopulate");
            l_objDbWorkItem.ResultType = QueryType.DataSet;
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.VarChar, AppEnvironment.AppUser.UserNo);
            
            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                    return new MethodExecResult(1, "No data found", "stp_FilterPopulate. Database returned no data. UserNo. " + AppEnvironment.AppUser.UserNo.ToString(), null);
                else
                {
                    p_vdtUCCLookUpData = l_dsReturnData;
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        } 
        #endregion
    }
}
