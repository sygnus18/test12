﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Collections;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Utils;

namespace UCC.Class
{
    /// <summary>
    /// Structure defining export filter parameters
    /// </summary>
   
    /// <summary>
    /// This BL class of frmClientExport facilitates UCC data export
    /// </summary>
    class CCheckerAuthorization
    {
        /// <summary>
        /// This method retrieves UCC checker data for authorization.
        /// </summary>
        /// <param name="paramValueArr">Filter parameters value </param>
        /// <param name="UCCData">Return UCC Data</param>
        /// <returns>Method Execution Result</returns>
        #region RetrieveUCCData
        public MethodExecResult RetrieveUCCData(ArrayList paramValueArr, ref DataTable UCCData)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCRetrieveCheckerData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;
            
            l_objDbWorkItem.AddParameter("@Pn_EntityType", SqlDbType.Int, paramValueArr[0]);
            l_objDbWorkItem.AddParameter("@Pn_MakerUser", SqlDbType.Int, paramValueArr[1]);
            l_objDbWorkItem.AddParameter("@Pd_MakerDate", SqlDbType.DateTime, paramValueArr[2]);
            l_objDbWorkItem.AddParameter("@Ps_AuthStatus", SqlDbType.VarChar, paramValueArr[3]);
            l_objDbWorkItem.AddParameter("@Pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0) || (l_dsReturnData.Tables[0].Rows.Count == 0))
                {
                    return new MethodExecResult(1, "No data found", "stp_UCCRetrieveCheckerData. Database returned no data.", null);
                }
                else
                {
                    UCCData = l_dsReturnData.Tables[0];
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        }
        #endregion

        /// <summary>
        /// Method retrieve Maker user details to populate the maker dropdown
        /// </summary>
        /// <param name="paramValueArr">Filter parameters value </param>
        /// <param name="UCCData">Return UCC Data</param>
        /// <returns></returns>
        #region GetMakerUserDetails
        public MethodExecResult GetMakerUserDetails(ArrayList paramValueArr, ref DataTable UCCData)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCRetrieveMakerUserDetails");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@Pn_CheckerUserNo", SqlDbType.Int, paramValueArr[0]);
            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0) || (l_dsReturnData.Tables[0].Rows.Count == 0))
                {
                    return new MethodExecResult(1, "No data found", "stp_UCCRetrieveMakerUserDetails. Database returned no data.", null);
                }
                else
                {
                    UCCData = l_dsReturnData.Tables[0];
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        }
        #endregion

        /// <summary>
        /// This method re-exports given exported UCC data
        /// </summary>
        /// <param name="p_vsFileNameWithPath">Destination file name with path</param>
        /// <param name="p_vdtUCCData">UCC data</param>
        /// <returns>Method Execution Result</returns>
        #region ReExportDataToFile
        private MethodExecResult ReExportUCCData(string p_vsFileNameWithPath, DataTable p_vdtUCCData)
        {
            int l_iRowCounter = 0;

            try
            {
                using (StreamWriter l_swOutFile = new StreamWriter(p_vsFileNameWithPath))
                {
                    for (l_iRowCounter = 0; l_iRowCounter < p_vdtUCCData.Rows.Count; l_iRowCounter++)
                    {
                        l_swOutFile.WriteLine(p_vdtUCCData.Rows[l_iRowCounter]["s_Data"].ToString());
                    }

                    l_swOutFile.Close();
                }
            }
            catch (Exception ex)
            {
                return new MethodExecResult(1, ex.Message,
                    "Error exporting UCC data to file. " + ex.Message + ". File: " + p_vsFileNameWithPath
                     + ", Line: " + l_iRowCounter.ToString(), ex);
            }

            return new MethodExecResult(MethodExecResult.SuccessfulReturnCode);
        }
        #endregion

       /// <summary>
       /// This method Authorise or Reject the the Maker changes for selected grid records.
       /// </summary>
       /// <param name="FilterParams">Filter parameters</param>
       /// <returns>Method Execution Result</returns>
        #region UpdateCheckerAuthRejectData
        public MethodExecResult UpdateCheckerAuthRejectData(ArrayList l_paramValueArr)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCProcessAuthRejectData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@Pn_EntityNo", SqlDbType.Int, l_paramValueArr[0]);
            l_objDbWorkItem.AddParameter("@Pn_EntityType", SqlDbType.Int, l_paramValueArr[1]);
            l_objDbWorkItem.AddParameter("@Ps_ResponseType", SqlDbType.VarChar, l_paramValueArr[2]);
            l_objDbWorkItem.AddParameter("@Ps_Remarks", SqlDbType.VarChar, l_paramValueArr[3]);
            l_objDbWorkItem.AddParameter("@Pn_UserNo", SqlDbType.Int, l_paramValueArr[4]);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            return l_objDbWorkItem.ExecutionStatus;

        }
        #endregion
        
        /// <summary>
        /// This method prepares export file name via database procedure
        /// </summary>
        /// <param name="p_viExchangeNo">Exchange No</param>
        /// <param name="p_rsFileName">Return file name</param>
        /// <param name="p_riBatchNo">Return Batch No</param>
        /// <returns>Method Execution Result</returns>
        #region GetUCCExportFileNameAndBatchNo
        private MethodExecResult GetUCCExportFileNameAndBatchNo(int p_viExchangeNo, ref string p_rsFileName, ref int p_riBatchNo)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetUCCExportFileName");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@pn_ExNo", SqlDbType.Int, p_viExchangeNo);
            l_objDbWorkItem.AddParameter("@pd_Date", SqlDbType.DateTime, CMatchCommonUtils.Instance.ServerDate.Date);
            l_objDbWorkItem.AddParameter("@pn_BatchNo", SqlDbType.Int, p_riBatchNo);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsResult = l_objDbWorkItem.Result as DataSet;
                if ((l_dsResult == null) || (l_dsResult.Tables.Count == 0))
                {
                    return new MethodExecResult(1, "Database returned no data.", "stp_GetUCCExportFileName. Database returned no data. Exchange: "
                        + p_viExchangeNo.ToString() + ", Date: " + CMatchCommonUtils.Instance.ServerDate.Date.ToString(), null);
                }
                else
                {
                    int l_iBatchNo;
                    try
                    {
                        if (int.TryParse(l_dsResult.Tables[0].Rows[0]["n_BatchNo"].ToString(), out l_iBatchNo) == false)
                            return new MethodExecResult(2, "Batch no parsing failed.", "stp_GetClientUCCExportBatchNo. Parsing to Integer failed. Value: " + l_iBatchNo.ToString()
                                + ", Exchange: " + p_viExchangeNo.ToString() + ", Date: " + CMatchCommonUtils.Instance.ServerDate.Date.ToString(), null);
                        p_riBatchNo = l_iBatchNo;
                        p_rsFileName = l_dsResult.Tables[0].Rows[0]["s_FileName"].ToString();
                    }
                    catch (Exception ex)
                    {
                        return new MethodExecResult(2, "Exception parsing File name/Batch No." + Environment.NewLine + ex.Message,
                            "Exception parsing File name/Batch No." + Environment.NewLine + ex.Message, ex);
                    }

                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        }
        #endregion

        /// <summary>
        /// This method retrieves header data applicable to current export via calling database procedure
        /// </summary>
        /// <param name="p_viExNo">Exchange No as selected by user</param>
        /// <param name="p_viBatchNo">Batch No as generated</param>
        /// <param name="p_viRecordCount">Total number of records to be exported</param>
        /// <param name="p_rdtHeaderData">Return data table containing header rows</param>
        /// <returns>Method Execution Result</returns>
        #region GetHeaderData
        private MethodExecResult GetHeaderData(int p_viExNo, int p_viBatchNo, int p_viRecordCount, ref DataTable p_rdtHeaderData)
        {
            DataTable l_dtInputData = new DataTable("#InputDetails");
            l_dtInputData.Columns.Add("n_RecordCount", typeof(int));
            l_dtInputData.Columns.Add("n_BatchNo", typeof(int));

            l_dtInputData.Columns["n_RecordCount"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, "");
            l_dtInputData.Columns["n_BatchNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, "");

            l_dtInputData.Rows.Add(new object[] { p_viRecordCount, p_viBatchNo });

            DataSet l_dsInputData = new DataSet();
            l_dsInputData.Tables.Add(l_dtInputData);

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetUCCExportHeaderData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;
            l_objDbWorkItem.InputData = l_dsInputData;

            l_objDbWorkItem.AddParameter("@pn_ExNo", SqlDbType.Int, p_viExNo);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.VarChar, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

            DataSet l_dsReturn = l_objDbWorkItem.Result as DataSet;
            if (
                (l_dsReturn != null)
                && (l_dsReturn.Tables.Count > 0)
                )
            {
                p_rdtHeaderData = l_dsReturn.Tables[0];
            }

            return l_objDbWorkItem.ExecutionStatus;
        }
        #endregion

        /// <summary>
        /// This method writes UCC data with header in disc file
        /// </summary>
        /// <param name="ExchangeCode">Exchange code</param>
        /// <param name="FileNameWithPath">Destination file name with path</param>
        /// <param name="UCCData">UCC Data</param>
        /// <param name="UCCHeaderData">UCC Header Data</param>
        /// <returns>Method Execution Result</returns>
        #region ExportDataToFile
        private MethodExecResult ExportDataToFile(string FileNameWithPath, DataTable UCCData, DataTable UCCHeaderData)
        {
            string l_sSeperator = "|";

            int l_iRowCounter = 0, l_iHeaderRowCounter = 0;
            try
            {
                bool l_bColCountEnabled = false;
                int l_iDataColStartIndex = 0;
                if (UCCData.Columns.Count > 0 && UCCData.Columns[0].ColumnName == "n_ColCount")
                {
                    l_bColCountEnabled = true;
                    l_iDataColStartIndex = 1;
                }
                Int16 l_iColCount = Convert.ToInt16(UCCData.Columns.Count);

                using (StreamWriter l_swOutFile = new StreamWriter(FileNameWithPath))
                {
                    //Write Header
                    if (
                        (UCCHeaderData != null)
                        &&
                        (UCCHeaderData.Rows.Count > 0)
                        &&
                        (UCCHeaderData.Columns.Contains("s_HData"))
                       )
                    {
                        for (l_iHeaderRowCounter = 0; l_iHeaderRowCounter < UCCHeaderData.Rows.Count; l_iHeaderRowCounter++)
                        {
                            l_swOutFile.WriteLine(UCCHeaderData.Rows[l_iHeaderRowCounter]["s_HData"].ToString());
                        }
                    }                    

                    //Write Detail
                    for (l_iRowCounter = 0; l_iRowCounter < UCCData.Rows.Count; l_iRowCounter++)
                    {
                        object[] objDataArray = UCCData.Rows[l_iRowCounter].ItemArray;
                        
                        if(l_bColCountEnabled)
                            l_iColCount = Convert.ToInt16(UCCData.Rows[l_iRowCounter][0]);
                        string[] l_sDataStrArray = new string[l_iColCount];
                        Array.Copy(objDataArray, l_iDataColStartIndex, l_sDataStrArray, 0, l_iColCount);
                        //objDataArray.CopyTo(l_sDataStrArray, l_iDataColStartIndex);

                        l_swOutFile.WriteLine(string.Join(l_sSeperator, l_sDataStrArray));
                    }

                    l_swOutFile.Close();
                }
            }
            catch (Exception ex)
            {
                return new MethodExecResult(1, ex.Message,
                    "Error exporting UCC data to file. " + ex.Message + ". File: " + FileNameWithPath
                    + ", Line: " + l_iRowCounter.ToString() + ", Header Line: " + l_iHeaderRowCounter.ToString(), ex);
            }

            return new MethodExecResult(MethodExecResult.SuccessfulReturnCode);
        }
        #endregion

        /// <summary>
        /// This method uploads exported data to database.
        /// It reads file data, prepares data table and passes to Db manager to upload data via Bulk upload
        /// </summary>
        /// <param name="FileNameWithPath">Exported file name with path</param>
        /// <param name="p_viExNo">Exchange No</param>
        /// <param name="p_vdtDate">date</param>
        /// <param name="p_viBatchNo">Batch No</param>
        /// <returns>Method Execution Result</returns>
        #region ImportExportedDataToDb
        private MethodExecResult ImportExportedDataToDb(string FileNameWithPath, 
            int p_viExNo, DateTime p_vdtDate, int p_viBatchNo)
        {
            int l_iLineCounter = 0;
            try
            {
                string[] l_sFileData = File.ReadAllLines(FileNameWithPath);

                DataTable l_dtFileData = new DataTable("#FileData");
                l_dtFileData.Columns.Add("n_LineNo", typeof(int));
                l_dtFileData.Columns.Add("s_Line");

                l_dtFileData.Columns["n_LineNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, "");
                l_dtFileData.Columns["s_Line"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, "");
                l_dtFileData.Columns["s_Line"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8000");

                for (l_iLineCounter = 0; l_iLineCounter < l_sFileData.Length; l_iLineCounter++)
                    l_dtFileData.Rows.Add(new object[] { l_iLineCounter + 1, l_sFileData[l_iLineCounter] });

                DataSet l_dsInputData = new DataSet();
                l_dsInputData.Tables.Add(l_dtFileData);

                DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_DumpUCCExportedData");
                l_objDbWorkItem.ResultType = QueryType.NonQuery;
                l_objDbWorkItem.InputData = l_dsInputData;

                l_objDbWorkItem.AddParameter("@pn_ExNo", SqlDbType.Int, p_viExNo);
                l_objDbWorkItem.AddParameter("@pd_Date", SqlDbType.DateTime, p_vdtDate.Date);
                l_objDbWorkItem.AddParameter("@pn_BatchNo", SqlDbType.Int, p_viBatchNo);
                l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.VarChar, AppEnvironment.AppUser.UserNo);

                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

                return l_objDbWorkItem.ExecutionStatus;
            }
            catch (Exception ex)
            {
                return new MethodExecResult(1, ex.Message,
                    "Error importing exported UCC data. " + ex.Message + ". File: " + FileNameWithPath
                    + ", Exchange: " + p_viExNo.ToString() + ", Line: " + l_iLineCounter.ToString(), ex);
            }
        }
        #endregion

        /// <summary>
        /// This method updates UCC data status to exported in database via bulk upload
        ///     based on unique field (n_ClientExMapNo) in Exported data table
        /// </summary>
        /// <param name="p_viBatchNo">Batch No</param>
        /// <param name="p_vdtUCCData">UCC Data</param>
        /// <returns>Method Execution Result</returns>
        #region UpdateExportedDataStatusToDb
        private MethodExecResult UpdateExportedDataStatusToDb(int p_viBatchNo, DataTable p_vdtUCCData)
        {
            try
            {
                p_vdtUCCData.Columns["n_ClientExMapNo"].ExtendedProperties[DbManager.BCPRequiredColumnAttr] = "";
                
            }
            catch (Exception ex)
            {
                return new MethodExecResult(1, ex.Message,
                    "Error updating exported status to database." + ex.Message + ". BatchNo: " + p_viBatchNo.ToString(), ex);
            }

            p_vdtUCCData.TableName = "#ExportedData";
            DataSet l_dsInputData = null;
            if (p_vdtUCCData.DataSet == null)
            {
                l_dsInputData = new DataSet();
                l_dsInputData.Tables.Add(p_vdtUCCData);
            }
            else
                l_dsInputData = p_vdtUCCData.DataSet;

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UpdateUCCExportedStatus");
            l_objDbWorkItem.ResultType = QueryType.NonQuery;
            l_objDbWorkItem.InputData = l_dsInputData;

            l_objDbWorkItem.AddParameter("@pn_BatchNo", SqlDbType.Int, p_viBatchNo);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.VarChar, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

            return l_objDbWorkItem.ExecutionStatus;
        }
        #endregion

    }
}
