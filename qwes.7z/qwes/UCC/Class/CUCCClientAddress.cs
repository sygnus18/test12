﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using System.Collections;
using FTIL.Match.Common.Log;

namespace UCC.Class.Master
{
    /// <summary>
    /// BL class of client address screen
    /// </summary>
    public class CUCCClientAddress
    {

        #region Variables
        private CUCCClientAddress m_objOriginalAddress;
        #endregion

        #region Constructor
        /// <summary>
        /// Initializes new instance of CUCCClientAddress using ClientExchMapNo
        /// </summary>
        /// <param name="n_ClientAddresskNo">Unique ClientExchMapNo</param>

        public CUCCClientAddress(int AddressNo)
        {
            _AddressNo = AddressNo;
            //Initialize();
        }
        #endregion 

        #region Methods

        #region Initialize
        /// <summary>
        /// Initializes current instance from collection with given ClientExchMapNo
        /// </summary>
        
        public MethodExecResult Initialize(DataRow DataRow, CClientAddressCollection ClientAddressCollection)
        {
            try
            {
                MethodExecResult l_MethodExecResult;
                //If under authorisation client, take new changes in main client object and original object in originalClient object
                if (ClientAddressCollection.AddressDetailsDataUnAuth != null && ClientAddressCollection.AddressDetailsDataUnAuth.Rows.Count > 0 && ClientAddressCollection.AddressDetailsDataUnAuth.Select("n_AddressNo = " + this.AddressNo).GetLength(0) > 0)
                {
                    DataRow[] _dr;
                    _dr = ClientAddressCollection.GetClientAddressDetailUnAuth(this.AddressNo);
                    m_objOriginalAddress = new CUCCClientAddress(this.AddressNo);
                    l_MethodExecResult = m_objOriginalAddress.InitializeFromDataRow(_dr[0]);
                    l_MethodExecResult = this.InitializeFromDataRow(DataRow);
                }
                else
                {
                    l_MethodExecResult = this.InitializeFromDataRow(DataRow);
                }
                return l_MethodExecResult;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                return new MethodExecResult(1, ex.Message, "Initialize Error processing DataRow", ex);
            }

        }
        #endregion

        #region InitializeFromDataRow
        /// <summary>
        /// Initializes current instance from DataRow
        /// </summary>
        /// <param name="DataRow">DataRow object containing Exchange details</param>
        
        public MethodExecResult InitializeFromDataRow(DataRow DataRow)
        {
            try
            {
                this.AddressNo = Convert.ToInt32(DataRow["n_AddressNo"]);
                this.ClientNo = Convert.ToInt32(DataRow["n_ClientNo"]);
                this.AddressType = Convert.ToInt16(DataRow["n_AddressType"]);
                if (DataRow["s_ContactPerson"] != DBNull.Value)
                    this.ContactPerson = DataRow["s_ContactPerson"].ToString();
                if (DataRow["s_Designation"] != DBNull.Value)
                    this.Designation = DataRow["s_Designation"].ToString();
                if (DataRow["s_Director"] != DBNull.Value)
                    this.Director = DataRow["s_Director"].ToString() == "Y" ? true : false;
                if (DataRow["s_AddressLine1"] != DBNull.Value)
                    this.AddressLine1= DataRow["s_AddressLine1"].ToString();
                if (DataRow["s_AddressLine2"] != DBNull.Value)
                    this.AddressLine2 = DataRow["s_AddressLine2"].ToString();
                if (DataRow["s_AddressLine3"] != DBNull.Value)
                    this.AddressLine3 = DataRow["s_AddressLine3"].ToString();
                if (DataRow["s_AddressLine4"] != DBNull.Value)
                    this.AddressLine4 = DataRow["s_AddressLine4"].ToString();
                if (DataRow["s_PANNo"] != DBNull.Value)
                    this.PAN = DataRow["s_PANNo"].ToString();
                if (DataRow["n_StateNumber"] != DBNull.Value)
                    this.StateNumber = Convert.ToInt32(DataRow["n_StateNumber"]);
                if (DataRow["s_StateOther"] != DBNull.Value)
                    this.StateOther = DataRow["s_StateOther"].ToString();
                if (DataRow["n_CountryCode"] != DBNull.Value)
                    this.CountryCode = Convert.ToInt32(DataRow["n_CountryCode"]);
                if (DataRow["s_PinCode"] != DBNull.Value)
                    this.PinCode = DataRow["s_PinCode"].ToString();
                if (DataRow["s_TelNo1"] != DBNull.Value)
                    this.ResTelNo = DataRow["s_TelNo1"].ToString();
                if (DataRow["s_TelNoISDCode"] != DBNull.Value)
                    this.ResTelNoISDCode = DataRow["s_TelNoISDCode"].ToString();
                if (DataRow["s_TelNoSTDCode"] != DBNull.Value)
                    this.ResTelNoSTDCode = DataRow["s_TelNoSTDCode"].ToString();

                if (DataRow["s_TelNoOffice"] != DBNull.Value)
                    this.OffTelNo = DataRow["s_TelNoOffice"].ToString();
                if (DataRow["s_TelNoOfficeISDCode"] != DBNull.Value)
                    this.OffTelNoISDCode = DataRow["s_TelNoOfficeISDCode"].ToString();
                if (DataRow["s_TelNoOfficeSTDCode"] != DBNull.Value)
                    this.OffTelNoSTDCode = DataRow["s_TelNoOfficeSTDCode"].ToString();

                if (DataRow["s_Mobile1"] != DBNull.Value)
                    this.Mobile1 = DataRow["s_Mobile1"].ToString();
                if (DataRow["s_Mobile2"] != DBNull.Value)
                    this.Mobile2 = DataRow["s_Mobile2"].ToString();
                if (DataRow["s_FaxNo"] != DBNull.Value)
                    this.FaxNo = DataRow["s_FaxNo"].ToString();
                if (DataRow["s_FaxNoISDCode"] != DBNull.Value)
                    this.FaxNoISDCode = DataRow["s_FaxNoISDCode"].ToString();
                if (DataRow["s_FaxNoSTDCode"] != DBNull.Value)
                    this.FaxNoSTDCode = DataRow["s_FaxNoSTDCode"].ToString();

                if (DataRow["s_EMailId"] != DBNull.Value)
                    this.EMailId = DataRow["s_EMailId"].ToString().Trim().Replace(" ", "");
                if (DataRow["s_CCEmail"] != DBNull.Value)
                    this.CCEmail = DataRow["s_CCEmail"].ToString().Trim().Replace(" ", "");
                if (DataRow["s_BCCMail"] != DBNull.Value)
                    this.BCCEmail = DataRow["s_BCCMail"].ToString().Trim().Replace(" ", "");
                if (DataRow["s_DIN"] != DBNull.Value)
                    this.DIN = DataRow["s_DIN"].ToString();
                if (DataRow["s_UID"] != DBNull.Value)
                    this.UID = DataRow["s_UID"].ToString();
                if (DataRow["s_Default"] != DBNull.Value)
                    this.Default = DataRow["s_Default"].ToString() == "Y" ? true : false;
                if (DataRow["s_SameCorrPermAdd"] != DBNull.Value)
                    this.SameCorrPermAdd = DataRow["s_SameCorrPermAdd"].ToString() == "Y" ? true : false; 
                if (DataRow["n_CityStateCode"] != DBNull.Value)
                    this.CityStateCode = Convert.ToInt32(DataRow["n_CityStateCode"]);

                if (DataRow["s_City"] != DBNull.Value)
                    this.City = DataRow["s_City"].ToString();

                if (DataRow["s_AuthorizedStatus"] != DBNull.Value)
                    this.AuthorizedStatus = DataRow["s_AuthorizedStatus"].ToString().Trim();

                if (DataRow["n_UserNo"] != DBNull.Value)
                    this.UserNo = Convert.ToInt32(DataRow["n_UserNo"]);
                if (DataRow["d_LastModifiedDateTime"] != DBNull.Value)
                    this.LastModifiedDateTime = Convert.ToDateTime(DataRow["d_LastModifiedDateTime"]);


                return new MethodExecResult(MethodExecResult.SuccessfulReturnCode);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                return new MethodExecResult(1, ex.Message, "InitializeFromDataRow() Error processing DataRow", ex);
            }
        }
        #endregion

        #endregion 

      

        /// <summary>
        /// Upates client address detail modifications to database
        /// </summary>
        /// <param name="p_lArryList">Modified client address details</param>
        /// <returns>Method Execution Result</returns>
        #region UpdateUCCClientAddressData
        public MethodExecResult UpdateUCCClientAddressData(ArrayList p_lArryList)
        {

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCUpdateClientAddressData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;
            l_objDbWorkItem.AddParameter("@ps_Mode", SqlDbType.VarChar, p_lArryList[0]);
            l_objDbWorkItem.AddParameter("@pn_AddressNo", SqlDbType.VarChar, p_lArryList[1]);
            l_objDbWorkItem.AddParameter("@ps_ClientCode", SqlDbType.VarChar, p_lArryList[2]);
            l_objDbWorkItem.AddParameter("@pn_AddressType", SqlDbType.VarChar, p_lArryList[3]);
            l_objDbWorkItem.AddParameter("@ps_ContactPerson", SqlDbType.VarChar, p_lArryList[4]);
            l_objDbWorkItem.AddParameter("@ps_Designation", SqlDbType.VarChar, p_lArryList[5]);
            l_objDbWorkItem.AddParameter("@ps_Director", SqlDbType.VarChar, p_lArryList[6]);
            l_objDbWorkItem.AddParameter("@ps_AddressLine1", SqlDbType.VarChar, p_lArryList[7]);
            l_objDbWorkItem.AddParameter("@ps_AddressLine2", SqlDbType.VarChar, p_lArryList[8]);
            l_objDbWorkItem.AddParameter("@ps_AddressLine3", SqlDbType.VarChar, p_lArryList[9]);
            l_objDbWorkItem.AddParameter("@ps_AddressLine4", SqlDbType.VarChar, p_lArryList[10]);
            l_objDbWorkItem.AddParameter("@ps_PANNo", SqlDbType.VarChar, p_lArryList[11]);
            l_objDbWorkItem.AddParameter("@pn_CityStateCode", SqlDbType.VarChar, p_lArryList[12]);
            l_objDbWorkItem.AddParameter("@ps_City", SqlDbType.VarChar, p_lArryList[13]);
            l_objDbWorkItem.AddParameter("@pn_StateNumber", SqlDbType.Int, p_lArryList[14]);
            l_objDbWorkItem.AddParameter("@ps_StateOther", SqlDbType.VarChar, p_lArryList[15]);
            l_objDbWorkItem.AddParameter("@pn_CountryCode", SqlDbType.Int, p_lArryList[16]);
            l_objDbWorkItem.AddParameter("@ps_PinCode", SqlDbType.VarChar, p_lArryList[17]);
            l_objDbWorkItem.AddParameter("@ps_TelNo1", SqlDbType.VarChar, p_lArryList[18]);
            l_objDbWorkItem.AddParameter("@ps_Mobile1", SqlDbType.VarChar, p_lArryList[19]);
            l_objDbWorkItem.AddParameter("@ps_Mobile2", SqlDbType.VarChar, p_lArryList[20]);
            l_objDbWorkItem.AddParameter("@ps_FaxNo", SqlDbType.VarChar, p_lArryList[21]);
            l_objDbWorkItem.AddParameter("@ps_EMailId", SqlDbType.VarChar, p_lArryList[22]);
            l_objDbWorkItem.AddParameter("@ps_CCEmail", SqlDbType.VarChar, p_lArryList[23]);
            l_objDbWorkItem.AddParameter("@ps_BCCMail", SqlDbType.VarChar, p_lArryList[24]);
            l_objDbWorkItem.AddParameter("@ps_DIN", SqlDbType.VarChar, p_lArryList[25]);
            l_objDbWorkItem.AddParameter("@ps_UID", SqlDbType.VarChar, p_lArryList[26]);
            l_objDbWorkItem.AddParameter("@ps_Default", SqlDbType.VarChar, p_lArryList[27]);
            l_objDbWorkItem.AddParameter("@ps_SameCorrPermAdd", SqlDbType.VarChar, p_lArryList[28]);
            l_objDbWorkItem.AddParameter("@ps_TelNoISDCode", SqlDbType.VarChar, p_lArryList[29]);
            l_objDbWorkItem.AddParameter("@ps_TelNoSTDCode", SqlDbType.VarChar, p_lArryList[30]);
            l_objDbWorkItem.AddParameter("@ps_FaxNoISDCode", SqlDbType.VarChar, p_lArryList[31]);
            l_objDbWorkItem.AddParameter("@ps_FaxNoSTDCode", SqlDbType.VarChar, p_lArryList[32]);
            l_objDbWorkItem.AddParameter("@ps_TelNoOffice", SqlDbType.VarChar, p_lArryList[33]);
            l_objDbWorkItem.AddParameter("@ps_TelNoOfficeISDCode", SqlDbType.VarChar, p_lArryList[34]);
            l_objDbWorkItem.AddParameter("@ps_TelNoOfficeSTDCode", SqlDbType.VarChar, p_lArryList[35]);
            l_objDbWorkItem.AddParameter("@ps_ContactPersonDefault", SqlDbType.VarChar, p_lArryList[36]);

            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.VarChar, AppEnvironment.AppUser.UserNo);
            
            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            return l_objDbWorkItem.ExecutionStatus;
        }
        #endregion

        /// <summary>
        /// Deletes client address detail from database
        /// </summary>
        /// <param name="p_lArryList">Address unique field values</param>
        /// <returns>Method Execution Result</returns>
        #region DeleteClientAddressData
        public MethodExecResult DeleteClientAddressData(ArrayList p_lArryList)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCDeleteClientAddress");
            l_objDbWorkItem.ResultType = QueryType.DataSet;
            l_objDbWorkItem.AddParameter("@pn_AddressNo", SqlDbType.Int, p_lArryList[0]);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            return l_objDbWorkItem.ExecutionStatus;
        }
        #endregion

        #region Properties

        #region ClientNo
        private Int32 _ClientNo;
        /// <summary>
        /// ClientNo
        /// </summary>
        public Int32 ClientNo
        {
            get { return _ClientNo; }
            set { _ClientNo = value; }
        }
        #endregion

        #region AddressNo
        private Int32 _AddressNo;
        /// <summary>
        /// AddressNo
        /// </summary>
        public Int32 AddressNo
        {
            get { return _AddressNo; }
            set { _AddressNo = value; }
        }
        #endregion

        #region AddressType
        private Int16 _AddressType;
        /// <summary>
        /// AddressType
        /// </summary>
        public Int16 AddressType
        {
            get { return _AddressType; }
            set { _AddressType = value; }
        }
        #endregion

        #region ContactPerson
        private string _ContactPerson;
        /// <summary>
        /// Contact person
        /// </summary>
        public string ContactPerson
        {
            get { return _ContactPerson; }
            set { _ContactPerson = value; }
        }
        #endregion

        #region Designation
        private string _Designation;
        /// <summary>
        /// Designation
        /// </summary>
        public string Designation
        {
            get { return _Designation; }
            set { _Designation = value; }
        }
        #endregion
        
        #region Director
        private Boolean _Director;
        /// <summary>
        /// Director
        /// </summary>
        public Boolean Director
        {
            get { return _Director; }
            set { _Director = value; }
        }
        #endregion
        
        #region AddressLine1
        private string _AddressLine1;
        /// <summary>
        /// AddressLine1
        /// </summary>
        public string AddressLine1
        {
            get { return _AddressLine1; }
            set { _AddressLine1 = value; }
        }
        #endregion

        #region AddressLine2
        private string _AddressLine2;
        /// <summary>
        /// AddressLine2
        /// </summary>
        public string AddressLine2
        {
            get { return _AddressLine2; }
            set { _AddressLine2 = value; }
        }
        #endregion

        #region AddressLine3
        private string _AddressLine3;
        /// <summary>
        /// AddressLine3
        /// </summary>
        public string AddressLine3
        {
            get { return _AddressLine3; }
            set { _AddressLine3 = value; }
        }
        #endregion

        #region AddressLine4
        private string _AddressLine4;
        /// <summary>
        /// AddressLine4
        /// </summary>
        public string AddressLine4
        {
            get { return _AddressLine4; }
            set { _AddressLine4 = value; }
        }
        #endregion

        #region PAN
        private string _PAN;
        /// <summary>
        /// PAN
        /// </summary>
        public string PAN
        {
            get { return _PAN; }
            set { _PAN = value; }
        }
        #endregion

        #region City
        private string _City;
        /// <summary>
        /// City
        /// </summary>
        public string City
        {
            get { return _City; }
            set { _City = value; }
        }
        #endregion

        #region StateNumber
        private Int32 _StateNumber;
        /// <summary>
        /// StateNumber
        /// </summary>
        public Int32 StateNumber
        {
            get { return _StateNumber; }
            set { _StateNumber = value; }
        }
        #endregion

        #region StateOther
        private string _StateOther;
        /// <summary>
        /// StateOther
        /// </summary>
        public string StateOther
        {
            get { return _StateOther; }
            set { _StateOther = value; }
        }
        #endregion

        #region CountryCode
        private Int32 _CountryCode;
        /// <summary>
        /// CountryCode
        /// </summary>
        public Int32 CountryCode
        {
            get { return _CountryCode; }
            set { _CountryCode = value; }
        }
        #endregion

        #region PinCode
        private string _PinCode;
        /// <summary>
        /// PinCode
        /// </summary>
        public string PinCode
        {
            get { return _PinCode; }
            set { _PinCode = value; }
        }
        #endregion

        #region ResTelNo
        private string _TelNo1;
        /// <summary>
        /// ResTelNo
        /// </summary>
        public string ResTelNo
        {
            get { return _TelNo1; }
            set { _TelNo1 = value; }
        }
        #endregion

        #region ResTelNoISDCode
        private string _TelNoISDCode;
        /// <summary>
        /// ResTelNoISDCode
        /// </summary>
        public string ResTelNoISDCode
        {
            get { return _TelNoISDCode; }
            set { _TelNoISDCode = value; }
        }
        #endregion

        #region ResTelNoSTDCode
        private string _TelNoSTDCode;
        /// <summary>
        /// ResTelNoSTDCode
        /// </summary>
        public string ResTelNoSTDCode
        {
            get { return _TelNoSTDCode; }
            set { _TelNoSTDCode = value; }
        }
        #endregion
                
        #region OffTelNo
        private string _TelNoOffice;
        /// <summary>
        /// OffTelNo
        /// </summary>
        public string OffTelNo
        {
            get { return _TelNoOffice; }
            set { _TelNoOffice = value; }
        }
        #endregion

        #region OffTelNoISDCode
        private string _TelNoOfficeISDCode;
        /// <summary>
        /// OffTelNoISDCode
        /// </summary>
        public string OffTelNoISDCode
        {
            get { return _TelNoOfficeISDCode; }
            set { _TelNoOfficeISDCode = value; }
        }
        #endregion

        #region OffTelNoSTDCode
        private string _TelNoOfficeSTDCode;
        /// <summary>
        /// OffTelNoSTDCode
        /// </summary>
        public string OffTelNoSTDCode
        {
            get { return _TelNoOfficeSTDCode; }
            set { _TelNoOfficeSTDCode = value; }
        }
        #endregion

        #region FaxNo
        private string _FaxNo;
        /// <summary>
        /// FaxNo
        /// </summary>
        public string FaxNo
        {
            get { return _FaxNo; }
            set { _FaxNo = value; }
        }
        #endregion

        #region FaxNoISDCode
        private string _FaxNoISDCode;
        /// <summary>
        /// FaxNoISDCode
        /// </summary>
        public string FaxNoISDCode
        {
            get { return _FaxNoISDCode; }
            set { _FaxNoISDCode = value; }
        }
        #endregion

        #region FaxNoSTDCode
        private string _FaxNoSTDCode;
        /// <summary>
        /// FaxNoSTDCode
        /// </summary>
        public string FaxNoSTDCode
        {
            get { return _FaxNoSTDCode; }
            set { _FaxNoSTDCode = value; }
        }
        #endregion

        #region Mobile1
        private string _Mobile1;
        /// <summary>
        /// Mobile1
        /// </summary>
        public string Mobile1
        {
            get { return _Mobile1; }
            set { _Mobile1 = value; }
        }
        #endregion

        #region Mobile2
        private string _Mobile2;
        /// <summary>
        /// Mobile2
        /// </summary>
        public string Mobile2
        {
            get { return _Mobile2; }
            set { _Mobile2 = value; }
        }
        #endregion

        #region EMailId
        private string _EMailId;
        /// <summary>
        /// EMailId
        /// </summary>
        public string EMailId
        {
            get { return _EMailId; }
            set { _EMailId = value; }
        }
        #endregion

        #region CCEmail
        private string _CCEmail;
        /// <summary>
        /// CCEmail
        /// </summary>
        public string CCEmail
        {
            get { return _CCEmail; }
            set { _CCEmail = value; }
        }
        #endregion

        #region BCCEmail
        private string _BCCEmail;
        /// <summary>
        /// BCCEmail
        /// </summary>
        public string BCCEmail
        {
            get { return _BCCEmail; }
            set { _BCCEmail = value; }
        }
        #endregion
        
        #region DIN
        private string _DIN;
        /// <summary>
        /// DIN
        /// </summary>
        public string DIN
        {
            get { return _DIN; }
            set { _DIN = value; }
        }
        #endregion

        #region UID
        private string _UID;
        /// <summary>
        /// UID
        /// </summary>
        public string UID
        {
            get { return _UID; }
            set { _UID = value; }
        }
        #endregion

        #region Default
        private Boolean _Default;
        /// <summary>
        /// Default
        /// </summary>
        public Boolean Default
        {
            get { return _Default; }
            set { _Default = value; }
        }
        #endregion

        #region SameCorrPermAdd
        private Boolean _SameCorrPermAdd;
        /// <summary>
        /// SameCorrPermAdd
        /// </summary>
        public Boolean SameCorrPermAdd
        {
            get { return _SameCorrPermAdd; }
            set { _SameCorrPermAdd = value; }
        }
        #endregion

        #region CityStateCode
        private Int32 _CityStateCode;
        /// <summary>
        /// CityStateCode
        /// </summary>
        public Int32 CityStateCode
        {
            get { return _CityStateCode; }
            set { _CityStateCode = value; }
        }
        #endregion

        #region ContactPersonDefault
        private Boolean _ContactPersonDefault;
        /// <summary>
        /// ContactPersonDefault
        /// </summary>
        public Boolean ContactPersonDefault
        {
            get { return _ContactPersonDefault; }
            set { _ContactPersonDefault = value; }
        }
        #endregion

        #region OriginalAddress
        /// <summary>
        /// Original Exchange details of current exchange (when Maker/Checker enabled)
        /// </summary>
        public CUCCClientAddress OriginalAddress
        {
            get { return m_objOriginalAddress; }
        }
        #endregion

        #region AuthorizedStatus
        /// <summary>
        /// Authorise status of current record
        /// </summary>
        private string _AuthorizedStatus;
        public string AuthorizedStatus
        {
            get { return _AuthorizedStatus; }
            set { _AuthorizedStatus = value; }
        }
        #endregion

        #region UserNo
        private Int32? _UserNo;
        /// <summary>
        /// UserNo
        /// </summary>
        public Int32? UserNo
        {
            get { return _UserNo; }
            set { _UserNo = value; }
        }
        #endregion

        #region LastModifiedDateTime
        private DateTime? _LastModifiedDateTime;
        /// <summary>
        /// LastModifiedDateTime
        /// </summary>
        public DateTime? LastModifiedDateTime
        {
            get { return _LastModifiedDateTime; }
            set { _LastModifiedDateTime = value; }
        }
        #endregion

        #endregion

    }
}
