﻿using System;
using System.Collections.Generic;
using System.Data;

using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;

namespace UCC.Class
{
    /// <summary>
    /// Master Data Type Enum
    /// </summary>
    public enum Masters
    {
        None,
        Exchange,
        CityStateMapping,
        ExchangeType
    }

    /// <summary>
    /// Provides Master data
    /// </summary>
    public class CMastersDataProvider
    {
        #region Variables

        /// <summary>
        /// Dictionaty to cache masters data
        /// </summary>
        private Dictionary<Masters, DataTable> m_dicRefData;

        /// <summary>
        /// Indicates if masters data has been initialized
        /// </summary>
        private bool m_bInitialised;

        #endregion

        #region Singleton

        /// <summary>
        /// The only instance of a class
        /// </summary>
        private static CMastersDataProvider m_objInstance;
        /// <summary>
        /// Private constrcuctor to disable instance creation
        /// </summary>
        private CMastersDataProvider() 
        { 
            m_dicRefData = new Dictionary<Masters,DataTable>();
        }

        /// <summary>
        /// Static constructor to initialize singleton instance
        /// </summary>
        static CMastersDataProvider()
        {
            m_objInstance = new CMastersDataProvider();
        }

        /// <summary>
        /// Exposes singleton instance
        /// </summary>
        public static CMastersDataProvider Instance
        {
            get
            {
                return m_objInstance;
            }
        }
        #endregion

        #region Properties

        /// <summary>
        /// Returns master DataTable
        /// </summary>
        /// <param name="MasterType">Master Type</param>
        /// <returns>Master data</returns>
        #region this[Masters]
        public DataTable this[Masters MasterType]
        {
            get
            {
                if (m_bInitialised == false)
                    Initialise();

                if (m_dicRefData.ContainsKey(MasterType))
                    return m_dicRefData[MasterType];
                return null;
            }
        }
        #endregion

        #endregion

        #region Methods

        /// <summary>
        /// Initializes masters data from database
        /// </summary>
        #region Initialise
        private void Initialise()
        {
            if (m_bInitialised)
                return;

            m_bInitialised = true;

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetMastersData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.VarChar, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                {
                    Logger.Instance.WriteLog(this,
                        "No masters data found. Proc: stp_GetMastersData");
                    return;
                }

                DataTable l_dtRefData = l_dsReturnData.Tables[0];

                try
                {
                    string l_sMissingMasters = string.Empty;
                    if (l_dsReturnData.Tables.Count > 0)
                        m_dicRefData.Add(Masters.Exchange, l_dsReturnData.Tables[0]);
                    else
                        l_sMissingMasters += "Exchange master not found" + Environment.NewLine;

                    if (l_dsReturnData.Tables.Count > 1)
                        m_dicRefData.Add(Masters.CityStateMapping, l_dsReturnData.Tables[1]);
                    else
                        l_sMissingMasters += "City State Mapping master not found" + Environment.NewLine;

                    if (l_dsReturnData.Tables.Count > 2)
                        m_dicRefData.Add(Masters.ExchangeType, l_dsReturnData.Tables[2]);
                    else
                        l_sMissingMasters += "Exchange Type master not found" + Environment.NewLine;

                    if(l_sMissingMasters.Length > 0)
                        Logger.Instance.WriteLog(this, "Masters data not initialized fully. " + l_sMissingMasters, null);
                }
                catch (Exception ex)
                {
                    Logger.Instance.WriteLog(this, "Error initializing Masters data. ", ex);
                }
            }
            else
            {
                Logger.Instance.WriteLog(this, l_objDbWorkItem.ExecutionStatus);
            }
        }
        #endregion

        #endregion
    }
}
