﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UCC.Class.KRA
{
    /// <summary>
    /// Class for storing KRA static codes 
    /// </summary>
    public class CKRAReferenceData
    {

        #region Member variables
        
        private int m_nUCCRefNo;
        private KRAAgencyEnum m_KRAType;
        private string m_sRefCode;
        private string m_sRefType;

        
        #endregion

        #region Constructors
        public CKRAReferenceData()
        {

        }
        
        /// <summary>
        /// Set member variables  
        /// </summary>
        /// <param name="nUCCRefNo">n_ReferenceNo</param>
        /// <param name="KRAType">n_KRAAgencyNo</param>
        /// <param name="sRefCode">s_KRARefCode</param>
        public CKRAReferenceData(int nUCCRefNo, KRAAgencyEnum KRAType, string sRefCode)
        {
            m_nUCCRefNo = nUCCRefNo;
            m_KRAType = KRAType;
            m_sRefCode = sRefCode;
        }
        #endregion

        #region Properties 
        
        /// <summary>
        /// Reference No
        /// </summary>
        public int UCCRefNo
        {
            get { return m_nUCCRefNo; }
            set { m_nUCCRefNo = value; }
        }

        /// <summary>
        /// KRA Agency Type
        /// </summary>
        public KRAAgencyEnum KRAType
        {
            get { return m_KRAType; }
            set { m_KRAType = value; }
        }

        /// <summary>
        /// KRA Reference Code 
        /// </summary>
        public string SRefCode
        {
            get { return m_sRefCode; }
            set { m_sRefCode = value; }
        }

        /// <summary>
        /// KRA Reference Code 
        /// </summary>
        public string SRefType
        {
            get { return m_sRefType; }
            set { m_sRefType = value; }
        }

        /// <summary>
        /// KRA Reference Code 
        /// </summary>
        public string SRefCodeMaster { get; set; }



        #endregion
    }
}
