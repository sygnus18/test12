﻿using System;
using System.Collections.Generic;
using System.Text;
using UCC.Class.Master;

namespace UCC.Class.KRA
{
    internal class NDMLHeader
    {
        public NDMLHeader()
        {
            m_CreationDateTime = DateTime.Now;
            this.RecordType = "01";
        }


        private DateTime m_CreationDateTime;

        private readonly string m_ConstDateFormat = FTIL.Match.Common.Constants.Formatting.Instance.SHORT_DATE_UNIVERSAL_FORMAT_PLAIN;
        private readonly string m_ConstTimeFormat = FTIL.Match.Common.Constants.Formatting.Instance.DATE_FORMAT_HHmmss;
 

        #region Public properties

        /// <summary>
        /// Record Type (Header or Detail) : Length = 2
        /// </summary>
        [DataField(Length = 2)]
        public string RecordType {get;set;}

        /// <summary>
        /// IntermediaryID : Length = 5 : Optional
        /// </summary>
        [DataField(Length = 5)]
        public string IntermediaryID  {get;set;}

        /// <summary>
        /// Date of Download : Length = 8
        /// </summary>
        [DataField(Length = 8)]
        public string ExportDownloadDate
        {
            get
            {
                return m_CreationDateTime.ToString(m_ConstDateFormat);
            }
        }

        /// <summary>
        /// Export Time : Length = 6
        /// </summary>
        [DataField(Length = 6)]
        public string ExportDownloadTime
        {
            get
            {
                return m_CreationDateTime.ToString(m_ConstTimeFormat);
            }
        }

        /// <summary>
        /// Total No of Detail Records : Length = 7
        /// </summary>
        [DataField(Length = 7)]
        public int DetailRecordsCount	 {get;set;}

        /// <summary>
        /// Filer : Length = 37 : Optional 
        /// </summary>
        [DataField(Length = 37)]
        public string Filler { get; set; }


        /// <summary>
        /// Join all properties with fix length value mentioned in DataField attribute [DataField]
        /// </summary>
        /// <returns>Joined string</returns>
        public override string ToString()
        {
            return Utility.JoinProperties(this);
        }

        #endregion

    }

    /// <summary>
    /// Class for NDML Individual KRA detail record
    /// </summary>
    internal class NDMLIndividualDetail
    {


        private readonly string m_ConstDateFormat = FTIL.Match.Common.Constants.Formatting.Instance.SHORT_DATE_UNIVERSAL_FORMAT_PLAIN;
        private readonly string m_ConstDateTimeFormat = FTIL.Match.Common.Constants.Formatting.Instance.LONG_DATE_UNIVERSAL_FORMAT_PLAIN;
 
 
        public NDMLIndividualDetail()
        {
            RecordType = "02";
        }

        #region public properties (KRA Detail Record Fields)
        
        /// <summary>
        /// Record Type
        /// </summary>
        [DataField(Length = 2)]
        public string RecordType { get; set; }

        /// <summary>
        /// Line Number
        /// </summary>
        [DataField(Length = 7)]
        public int LineNumber { get; set; }
        
        /// <summary>
        /// Filler 
        /// </summary>
        [DataField(Length = 1)]
        public string Filler1 { get; set; }
        
        /// <summary>
        /// Name of the Applicant
        /// </summary>
        [DataField(Length = 45)]
        public string ApplicantName { get; set; }
        
        /// <summary>
        /// IPV Flag
        /// </summary>
        [DataField(Length = 1)]
        public string IPVFlag { get; set; }
        
        /// <summary>
        /// Name of the person doing the IPV
        /// </summary>
        [DataField(Length = 30)]
        public string IPVPersonName { get; set; }
        
        /// <summary>
        /// Designation of the person doing the IPV
        /// </summary>
        [DataField(Length = 20)]
        public string IPVPersonDesignation { get; set; }
        
        /// <summary>
        /// Organization Name of the person doing the IPV
        /// </summary>
        [DataField(Length = 70)]
        public string IPVOrganization { get; set; }

        /// <summary>
        /// Date of the IPV in text format 
        /// </summary>
        [DataField(Length = 8)]
        public string IPVDateText
        {
            get
            {
                if (IPVDate != null)
                    return IPVDate.ToString(m_ConstDateFormat);
                else return null;
            }
        }
        /// <summary>
        /// Date of the IPV
        /// </summary>
        public DateTime IPVDate { get; set; }
        
        /// <summary>
        /// Filler
        /// </summary>
        [DataField(Length = 76)]
        public string Filler2 { get; set; }
        
        /// <summary>
        /// Father's/Husband's  Name
        /// </summary>
        [DataField(Length = 45)]
        public string Father_HusbandName { get; set; }
        
        /// <summary>
        /// Gender M/F
        /// </summary>
        [DataField(Length = 1)]
        public string Gender { get; set; }
        
        /// <summary>
        /// Marital status
        /// </summary>
        [DataField(Length = 1)]
        public string Maritalstatus { get; set; }

        /// <summary>
        /// Date of Birth in text format
        /// </summary>
        [DataField(Length = 8)]
        public string DateofBirthText
        {
            get
            {
                if (DateofBirth != null)
                    return DateofBirth.ToString(m_ConstDateFormat);
                else return null;
            }
        }

        /// <summary>
        /// Date of Birth
        /// </summary>
        public DateTime DateofBirth { get; set; }

        /// <summary>
        /// Filler (For Future Requirements)
        /// </summary>
        [DataField(Length = 83)]
        public string Filler3 { get; set; }

        /// <summary>
        /// PAN 
        /// </summary>
        [DataField(Length = 10)]
        public string PAN { get; set; }
        
        /// <summary>
        /// Evidence / Documents provided in case of PAN exemption
        /// </summary>
        [DataField(Length = 75)]
        public string PANExemptionEvidence { get; set; }
        
        /// <summary>
        /// UID
        /// </summary>
        [DataField(Length = 16)]
        public string UID { get; set; }
        
        /// <summary>
        /// Status (Individual)
        /// </summary>
        [DataField(Length = 2)]
        public string Status { get; set; }
        
        /// <summary>
        /// Filler (For Future Requirements)
        /// </summary>
        [DataField(Length = 75)]
        public string Filler4 { get; set; }
        
        /// <summary>
        /// Nationality
        /// </summary>
        [DataField(Length = 2)]
        public string Nationality { get; set; }

        /// <summary>
        /// Nationality (For Other)
        /// </summary>
        [DataField(Length = 50)]
        public string NationalityOther { get; set; }
        
        /// <summary>
        /// Proof of Identity submitted
        /// </summary>
        [DataField(Length = 2)]
        public string ProofofIdentity { get; set; }
        
        /// <summary>
        /// Proof of Identity submitted (Others)
        /// </summary>
        [DataField(Length = 75)]
        public string ProofofIdentiyOthers { get; set; }
        
        /// <summary>
        /// Correspondence Address (Line 1)
        /// </summary>
        [DataField(Length = 36)]
        public string CorrespondenceAddress1 { get; set; }
        
        /// <summary>
        /// Correspondence Address (Line 2)
        /// </summary>
        [DataField(Length = 36)]
        public string CorrespondenceAddress2 { get; set; }
        
        /// <summary>
        /// Correspondence Address (Line 3)
        /// </summary>
        [DataField(Length = 36)]
        public string CorrespondenceAddress3 { get; set; }
        
        /// <summary>
        /// Correspondence Address City / Town / Village
        /// </summary>
        [DataField(Length = 36)]
        public string CorrAddCity { get; set; }
        
        /// <summary>
        /// Correspondence Address PIN Code
        /// </summary>
        [DataField(Length = 10)]
        public string CorrAddPINCode { get; set; }
        
        /// <summary>
        /// Correspondence Address State Code
        /// </summary>
        [DataField(Length = 2)]
        public string CorrAddState { get; set; }
        
        /// <summary>
        /// Correspondence Address State Other
        /// </summary>
        [DataField(Length = 75)]
        public string CorrAddStateOther { get; set; }
        
        /// <summary>
        /// Correspondence Address Country
        /// </summary>
        [DataField(Length = 3)]
        public string CorrAddCountry { get; set; }
       
        /// <summary>
        /// Proof of Address submitted for correspondence address
        /// </summary>
        [DataField(Length = 2)]
        public string ProofofAddressCorrAddress { get; set; }

        /// <summary>
        /// Proof of Address submitted for correspondence address (Other)
        /// </summary>
        [DataField(Length = 75)]
        public string ProofofAddressCorrAddressOther { get; set; }
        
        /// <summary>
        /// Tel. (Off.)
        /// </summary>
        [DataField(Length = 24)]
        public string TelOffice { get; set; }
        
        /// <summary>
        /// Tel. (Res.)
        /// </summary>
        [DataField(Length = 24)]
        public string TelRes { get; set; }
        
        /// <summary>
        /// Mobile No.
        /// </summary>
        [DataField(Length = 15)]
        public string MobileNo { get; set; }
        
        /// <summary>
        /// Fax No.
        /// </summary>
        [DataField(Length = 24)]
        public string FaxNo { get; set; }
        
        /// <summary>
        /// Email ID
        /// </summary>
        [DataField(Length = 50)]
        public string EmailID { get; set; }
        
        /// <summary>
        /// Filler (For Future Requirements)
        /// </summary>
        [DataField(Length = 50)]
        public string Filler5 { get; set; }
        
        /// <summary>
        /// Flag indicating if Permanent Address is same as correspondence Address Y/N
        /// </summary>
        [DataField(Length = 1)]
        public string IsSameAsCorrespondence { get; set; }
        
        /// <summary>
        /// Permanent Address (Line 1)
        /// </summary>
        [DataField(Length = 36)]
        public string PermanentAddress1 { get; set; }
        
        /// <summary>
        /// Permanent Address (Line 2)
        /// </summary>
        [DataField(Length = 36)]
        public string PermanentAddress2 { get; set; }
        
        /// <summary>
        /// Permanent Address (Line 3)
        /// </summary>
        [DataField(Length = 36)]
        public string PermanentAddress3 { get; set; }
        
        /// <summary>
        /// Permanent Address City/Town/ Village
        /// </summary>
        [DataField(Length = 36)]
        public string PerAddCity { get; set; }
        
        /// <summary>
        /// Permanent Address PIN code
        /// </summary>
        [DataField(Length = 10)]
        public string PerAddPINCode { get; set; }
        
        /// <summary>
        /// Permanent Address State code
        /// </summary>
        [DataField(Length = 2)]
        public string PerAddState { get; set; }
        
        /// <summary>
        /// Permanent Address State (Other)
        /// </summary>
        [DataField(Length = 75)]
        public string PerAddStateOther { get; set; }
        
        /// <summary>
        /// Permanent Address Country
        /// </summary>
        [DataField(Length = 3)]
        public string PerAddCountry { get; set; }
        
        /// <summary>
        /// Proof of Address submitted for permanent address
        /// </summary>
        [DataField(Length = 2)]
        public string ProofofPerAddress { get; set; }
        
        /// <summary>
        /// Proof of Address submitted for permanent address (Other)
        /// </summary>
        [DataField(Length = 75)]
        public string ProofofPerAddressOther { get; set; }
        
        /// <summary>
        /// Gross Annual Income Range
        /// </summary>
        [DataField(Length = 2)]
        public string GrossAnnualIncomeRange { get; set; }
        
        /// <summary>
        /// Net Worth (In Rs.)
        /// </summary>
        [DataField(Length = 18)]
        public decimal NetWorth { get; set; }

        /// <summary>
        /// Net Worth as on Date text format
        /// </summary>
        [DataField(Length = 8)]
        public string NetWorthOnDateText
        {
            get
            {
                if (NetWorthOnDate != null)
                    return NetWorthOnDate.ToString(m_ConstDateFormat);
                else return null;
            }
        }
      
        /// <summary>
        /// Net Worth as on Date
        /// </summary>
        public DateTime NetWorthOnDate { get; set; }


        /// <summary>
        /// Filler (For Future Requirements)
        /// </summary>
        [DataField(Length = 3)]
        public string Filler6 { get; set; }
        
        /// <summary>
        /// Politically Exposed Person (PEP)
        /// </summary>
        [DataField(Length = 2)]
        public string PEP { get; set; }
        
        /// <summary>
        /// Occupation 
        /// </summary>
        [DataField(Length = 2)]
        public string Occupation { get; set; }
        
        /// <summary>
        /// Occupation Details (For All)
        /// </summary>
        [DataField(Length = 75)]
        public string OccupationDetails { get; set; }
        
        /// <summary>
        /// Any Other Information
        /// </summary>
        [DataField(Length = 100)]
        public string OtherInformation { get; set; }

        /// <summary>
        /// Date of Declaration text format
        /// </summary>
        [DataField(Length = 8)]
        public string DeclarationDateText
        {
            get
            {
                if (DeclarationDate != null)
                    return DeclarationDate.ToString(m_ConstDateFormat);
                else return null;
            }
        }
      
        /// <summary>
        /// Date of Declaration
        /// </summary>
        public DateTime DeclarationDate { get; set; }
        
        /// <summary>
        /// (Originals verified) True copies of documents received
        /// </summary>
        [DataField(Length = 1)]
        public string VerifiedCopiesReceived { get; set; }
        
        /// <summary>
        /// (Self-Attested) Self Certified Document copies received
        /// </summary>
        [DataField(Length = 1)]
        public string SelfAttestedReceived { get; set; }

        /// <summary>
        /// Document received Date at Intermediary text format
        /// </summary>
        [DataField(Length = 8)]
        public string DocumentReceivedOnText
        {
            get
            {
                if (DocumentReceivedOn != null)
                    return DocumentReceivedOn.ToString(m_ConstDateFormat);
                else return null;
            }
        }

        /// <summary>
        /// Document received Date at Intermediary
        /// </summary>
        public DateTime DocumentReceivedOn { get; set; }
        
        /// <summary>
        /// Number Of Documents Submitted
        /// </summary>
        [DataField(Length = 2)]
        public int DocumentsCount { get; set; }
        
        /// <summary>
        /// Sender reference number 1
        /// </summary>
        [DataField(Length = 35)]
        public string SenderRefNo1 { get; set; }
        
        /// <summary>
        /// Sender reference number 2
        /// </summary>
        [DataField(Length = 35)]
        public string SenderRefNo2 { get; set; }

        /// <summary>
        /// Client Activation Date text format
        /// </summary>
        [DataField(Length = 14)]
        public string ClientActivationDateText
        {
            get
            {
                if (ClientActivationDate != null)
                    return ClientActivationDate.ToString(m_ConstDateTimeFormat);
                else return null;
            }
        }

        /// <summary>
        /// Client Activation Date
        /// </summary>
        public DateTime ClientActivationDate { get; set; }

        /// <summary>
        /// Client updation Date text format
        /// </summary>
        [DataField(Length = 14)]
        public string ClientUpdationDateText
        {
            get
            {
                if (ClientUpdationDate != null)
                    return ClientUpdationDate.ToString(m_ConstDateTimeFormat);
                else return null;
            }
        }

        /// <summary>
        /// Client Activation Date
        /// </summary>
        public DateTime ClientUpdationDate { get; set; }
        
        /// <summary>
        /// Filler
        /// </summary>
        [DataField(Length = 1)]
        public string Filler7 { get; set; }
        
        /// <summary>
        /// Flag to indicate Old record
        /// </summary>
        [DataField(Length = 1)]
        public string IsOldRecord { get; set; }
        
        /// <summary>
        /// Filler
        /// </summary>
        [DataField(Length = 35)]
        public string Filler8 { get; set; }
        
        /// <summary>
        /// Intermediary Branch Code
        /// </summary>
        [DataField(Length = 6)]
        public string IntermediaryBranchCode { get; set; }
      
        /// <summary>
        ///   Acknowledgement Number
        /// </summary>
        [DataField(Length = 16)]
        public int AcknowledgementNumber { get; set; }
        
        /// <summary>
        /// KYC Request Status
        /// </summary>
        [DataField(Length = 2)]
        public string KYCStatus { get; set; }

        /// <summary>
        /// Request Status Change TimeStamp text format
        /// </summary>
        [DataField(Length = 14)]
        public string RequestStatusChangeOnText
        {
            get
            {
                if (RequestStatusChangeOn != null)
                    return RequestStatusChangeOn.ToString(m_ConstDateTimeFormat);
                else return null;
            }
        }

        /// <summary>
        /// Request Status Change TimeStamp 
        /// </summary>
        public DateTime RequestStatusChangeOn { get; set; }
        
        /// <summary>
        /// Remarks - 1 by KRA
        /// </summary>
        [DataField(Length = 50)]
        public string Remarks1 { get; set; }
        
        /// <summary>
        /// Remarks - 2 by KRA
        /// </summary>
        [DataField(Length = 50)]
        public string Remarks2 { get; set; }
        
        #endregion

        /// <summary>
        /// Retun string after joinning all properties having custom attribute 
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return Utility.JoinProperties(this);
        }

    }

    /// <summary>
    /// Generate KRA file for NDML KRA Agency (Enum Code : 5)
    /// File Type : Fix length file
    /// Type of records : Header and Detail
    /// </summary>
    class KRANSDLInterface : IKRAProvider
    {

        #region Private Members fields  

        private CKRAReferenceDataProvider m_RefDataProvider;
        private NDMLHeader m_HeaderRecord;
        private IList<NDMLIndividualDetail> m_NDMLIndividualDetailRecords;

        #endregion

        /// <summary>
        /// Initiate private members
        /// </summary>
        public KRANSDLInterface()
        {
            m_HeaderRecord = new NDMLHeader();
            m_NDMLIndividualDetailRecords = new List<NDMLIndividualDetail>();
            m_RefDataProvider = CKRAReferenceDataProvider.Instance;
        }

        /// <summary>
        /// Process Clients for KRA
        /// </summary>
        /// <param name="clients">Client List</param>
        /// <returns></returns>
        public FTIL.Match.Common.MethodExecResult ProcessKRAClients(List<CClient> clients)
        {
            clients.ForEach(client => this.AddDetailRecord(client));
            return null;
        }

        /// <summary>
        /// Generate KRA text data form Header and Detail object
        /// </summary>
        /// <returns>KRA text data which will be write into the KRA file</returns>
        public string GetKRARecordsToText()
        {
            SetHeader();

            StringBuilder sb = new StringBuilder();
 
            sb.AppendLine(m_HeaderRecord.ToString());
           
            foreach(NDMLIndividualDetail detailRecord in m_NDMLIndividualDetailRecords)
            {
                sb.AppendLine(detailRecord.ToString());
            }

            return  sb.ToString();
        }


        #region Private Methods 

        /// <summary>
        /// Get Header record
        /// </summary>
        /// <returns>Header record string</returns>
        private void SetHeader()
        {
            m_HeaderRecord = new NDMLHeader();
            m_HeaderRecord.DetailRecordsCount = m_NDMLIndividualDetailRecords.Count;
        }

        /// <summary>
        /// Get Reference data for KRA
        /// </summary>
        /// <param name="nUCCRefNo">Reference No</param>
        /// <returns>Reference code</returns>
        private string GetRefData(int nUCCRefNo)
        {
            CKRAReferenceData l_refData = m_RefDataProvider[KRAAgencyEnum.NDML,nUCCRefNo];

            if (l_refData == null) return string.Empty;

            return l_refData.SRefCode;
        }


        /// <summary>
        /// Set all properties of NDMLIndividualDetail object
        /// </summary>
        /// <param name="client">KRA Client</param>
        private void AddDetailRecord(CClient client)
        {
            CAddress l_CorrespondenceAddress = client.ClientAddresses.GetAddressByType(AddressTypeEnum.Correspondence);
            CAddress l_RegisteredAddress = client.ClientAddresses.GetAddressByType(AddressTypeEnum.Registered);

            bool l_SameCorrPermAdd = false;

            NDMLIndividualDetail l_ObjDetail = new NDMLIndividualDetail();

            l_ObjDetail.LineNumber = this.m_NDMLIndividualDetailRecords.Count + 1; 
            l_ObjDetail.ApplicantName = client.ClientName;                        
            l_ObjDetail.Gender = client.Gender;                             
            l_ObjDetail.Maritalstatus = client.MaritalStatus;                 
            
            if(client.DOB.HasValue)
                l_ObjDetail.DateofBirth = client.DOB.Value;
           
            l_ObjDetail.PAN = client.PANNo;                            
            l_ObjDetail.PANExemptionEvidence = client.PanExempt;          
           

            l_ObjDetail.Nationality = client.Nationality.HasValue == true ? client.Nationality.Value.ToString() : null;            
            l_ObjDetail.NationalityOther = client.NationalityOther;                 

            if (l_CorrespondenceAddress != null)
            {
                l_SameCorrPermAdd = l_CorrespondenceAddress.SameCorrPermAdd == "Y" ? true : false;
                l_ObjDetail.CorrespondenceAddress1 = l_CorrespondenceAddress.AddressLine1;
                l_ObjDetail.CorrespondenceAddress2 = l_CorrespondenceAddress.AddressLine2;
                l_ObjDetail.CorrespondenceAddress3 = l_CorrespondenceAddress.AddressLine3;
                l_ObjDetail.CorrAddCity = l_CorrespondenceAddress.City;
                l_ObjDetail.CorrAddPINCode = l_CorrespondenceAddress.PinCode;
                l_ObjDetail.CorrAddState = GetRefData(l_CorrespondenceAddress.StateNumber);
                l_ObjDetail.CorrAddStateOther = l_CorrespondenceAddress.StateOther;
                l_ObjDetail.CorrAddCountry = GetRefData(l_CorrespondenceAddress.CountryCode);

                l_ObjDetail.UID = l_CorrespondenceAddress.UID;             
                l_ObjDetail.TelOffice = l_CorrespondenceAddress.TelNoOffice;
                l_ObjDetail.TelRes = l_CorrespondenceAddress.TelNo1;
                l_ObjDetail.MobileNo = l_CorrespondenceAddress.Mobile1;
                l_ObjDetail.FaxNo = l_CorrespondenceAddress.FaxNo;
                l_ObjDetail.EmailID = l_CorrespondenceAddress.EMailId;
            }

            if (l_SameCorrPermAdd)
            {
                l_ObjDetail.IsSameAsCorrespondence = "Y";
            }
            else
            {
                l_ObjDetail.IsSameAsCorrespondence = "N";

                if (l_RegisteredAddress != null)
                {
                    l_ObjDetail.PermanentAddress1 = l_RegisteredAddress.AddressLine1;
                    l_ObjDetail.PermanentAddress2 = l_RegisteredAddress.AddressLine2;
                    l_ObjDetail.PermanentAddress3 = l_RegisteredAddress.AddressLine3;
                    l_ObjDetail.PerAddCity = l_RegisteredAddress.City;
                    l_ObjDetail.PerAddPINCode = l_RegisteredAddress.PinCode;
                    l_ObjDetail.PerAddState = GetRefData(l_RegisteredAddress.StateNumber);
                    l_ObjDetail.PerAddStateOther = l_RegisteredAddress.StateOther;
                    l_ObjDetail.PerAddCountry = GetRefData(l_RegisteredAddress.CountryCode);
                }
            }

            l_ObjDetail.GrossAnnualIncomeRange = client.GrAnnIncRange.HasValue == true ? client.GrAnnIncRange.Value.ToString() : null;
            l_ObjDetail.NetWorth = client.NetWorth.HasValue == true ? client.NetWorth.Value : 0;

            if (client.GrAnnIncAsOnDate.HasValue)
                l_ObjDetail.NetWorthOnDate = client.GrAnnIncAsOnDate.Value;

            l_ObjDetail.Occupation = client.Occupation.HasValue == true ? client.Occupation.Value.ToString() : null;
            l_ObjDetail.OccupationDetails = client.OccupationOthers;

            if (client.CreationDate.HasValue)
                l_ObjDetail.ClientActivationDate = client.CreationDate.Value;

            l_ObjDetail.ClientUpdationDate = client.LastModifiedDateTime;

            //Add into DetailRecords list
            m_NDMLIndividualDetailRecords.Add(l_ObjDetail);
        }

        #endregion 

    }
}
