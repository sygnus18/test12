﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using UCC.Class.Master;
using FTIL.Match.Common;


namespace UCC.Class.KRA
{
    /// <summary>
    /// Interface for generating KRA file  
    /// </summary>
    interface IKRAProvider
    {
        /// <summary>
        /// Process passed clients 
        /// Set all properties for KRA file
        /// </summary>
        /// <param name="clients">Clients</param>
        /// <returns></returns>
        MethodExecResult ProcessKRAClients(List<CClient> clients);

        /// <summary>
        /// Get KRA file name and KRA text dictionary from KRA records
        /// </summary>
        /// <returns>Dictionary with FileName as Key and KRA text as value</returns>
        Dictionary<string, string> GetKRARecordsToText();

        /// <summary>
        /// Validate Fields 
        /// </summary>
        /// <returns></returns>
        DataTable VaildateRecords();

    }
}
