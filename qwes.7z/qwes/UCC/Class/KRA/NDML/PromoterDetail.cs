﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UCC.Class.KRA.NDML
{
    /// <summary>
    /// Details of Promoters/ Partners/ Karta / Trustees and whole time directors forming a part of KYC.			
    /// </summary>
    class PromoterDetail
    {

        public PromoterDetail()
        {
            this.RecordType = NDMLRecordType.ConstNDMLPromoterDetail;
            IsVaild = true;
        }

        #region public properties

        /// <summary>
        /// Record Type
        /// </summary>
        [DataField(Length = 2, IsRequired=true)]
        public string RecordType { get; set; }

        /// <summary>
        /// Line Number
        /// </summary>
        [DataField(Length = 7, PaddingCharacter = '0', IsRequired = true)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Name of the promoters, whole time directors etc.
        /// </summary>
        [DataField(Length = 250, IsRequired = true, Name="ContactPersonName")]
        public string Name { get; set; }

        /// <summary>
        /// Relationship with Applicant
        /// </summary>
        [DataField(Length = 2, IsRequired = true)]
        public string RelationshipWithApplicant { get; set; }

        /// <summary>
        /// Relationship with Applicant (Other)
        /// </summary>
        [DataField(Length = 75)]
        public string RelationshipWithApplicantOther { get; set; }

        /// <summary>
        /// PAN of Promoter, whole time director, etc.	Character 
        /// </summary>
        [DataField(Length = 10, IsRequired = true)]
        public string PANPromoter { get; set; }

        /// <summary>
        /// Evidence / Documents provided in case of PAN exemption
        /// </summary>
        [DataField(Length = 75)]
        public string PANExemptionEvidence { get; set; }

        /// <summary>
        /// Registered Address (Line 1)
        /// </summary>
        [DataField(Length = 36, IsRequired = true)]
        public string RegisteredAddress1 { get; set; }

        /// <summary>
        /// Registered Address (Line 2)
        /// </summary>
        [DataField(Length = 36)]
        public string RegisteredAddress2 { get; set; }

        /// <summary>
        /// Registered Address (Line 3)
        /// </summary>
        [DataField(Length = 36)]
        public string RegisteredAddress3 { get; set; }

        /// <summary>
        /// Registered Address City/Town/ Village
        /// </summary>
        [DataField(Length = 36)]
        public string RegAddCity { get; set; }

        /// <summary>
        /// Registered Address PIN code
        /// </summary>
        [DataField(Length = 10, IsRequired = true, Name="RegisteredAddress PINCode")]
        public string RegAddPINCode { get; set; }

        /// <summary>
        /// Registered Address State code
        /// </summary>
        [DataField(Length = 2, IsRequired = true, Name= "RegisteredAddress StateCode")]
        public string RegAddState { get; set; }

        /// <summary>
        /// Registered Address State (Other)
        /// </summary>
        [DataField(Length = 75)]
        public string RegAddStateOther { get; set; }

        /// <summary>
        /// Registered Address Country
        /// </summary>
        [DataField(Length = 3, IsRequired = true, Name="RegisteredAddress Country")]
        public string RegAddCountry { get; set; }

        /// <summary>
        ///  DIN / UIDy
        /// </summary>
        [DataField(Length = 16)]
        public string UID { get; set; }

        /// <summary>
        ///Same as Field 9 of Detail Record (record type 04)
        /// </summary>
        [DataField(Length = 10)]
        public string NonIndividualPAN { get; set; }

        /// <summary>
        ///AcknowledgementNumber
        /// </summary>
        [DataField(Length = 16, IsRequired = true)]
        public string AcknowledgementNumber { get; set; }


        /// <summary>
        /// Filler (For Future Requirements)
        /// </summary>
        [DataField(Length = 53)]
        public string Filler { get; set; }


        /// <summary>
        /// Flag for valid record
        /// </summary>
        public bool IsVaild { get; set; }



        /// <summary>
        /// Join all properties with fix length value mentioned in DataField attribute [DataField] 
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return Utility.JoinProperties(this);
        }

        #endregion
    }
}
