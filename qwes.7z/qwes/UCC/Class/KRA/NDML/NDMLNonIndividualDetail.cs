﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UCC.Class.KRA.NDML
{


    /// <summary>
    /// Class for NDML Individual KRA detail record
    /// </summary>
    internal class NDMLNonIndividualDetail
    {


        private readonly string m_ConstDateFormat = FTIL.Match.Common.Constants.Formatting.Instance.SHORT_DATE_UNIVERSAL_FORMAT_PLAIN;
        private readonly string m_ConstDateTimeFormat = FTIL.Match.Common.Constants.Formatting.Instance.LONG_DATE_UNIVERSAL_FORMAT_PLAIN;


        public NDMLNonIndividualDetail(UCC.Class.Master.CClient client)
        {
            RecordType = NDMLRecordType.ConstNDMLNonIndividualDetail;
            ClientInstance = client;
            PromoterDetailList = new List<PromoterDetail>();
            IsVaild = true;
        }

        #region public properties (KRA Detail Record Fields)

        /// <summary>
        /// Master Client Object
        /// </summary>
        public UCC.Class.Master.CClient ClientInstance { get; set; } 

        /// <summary>
        /// Record Type
        /// </summary>
        [DataField(Length = 2, IsRequired=true)]
        public string RecordType { get; set; }

        /// <summary>
        /// Line Number
        /// </summary>
        [DataField(Length = 7, PaddingCharacter = '0', IsRequired = true)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Filler 
        /// </summary>
        [DataField(Length = 1)]
        public string Filler1 { get; set; }

        /// <summary>
        /// Name of the Applicant
        /// </summary>
        [DataField(Length = 250, IsRequired = true)]
        public string ApplicantName { get; set; }

        /// <summary>
        /// Filler (For Future Requirements)
        /// </summary>
        [DataField(Length = 47)]
        public string Filler2 { get; set; }

        /// <summary>
        /// Date of Incorporation text format
        /// </summary>
        [DataField(Length = 8, IsRequired = true, Name=" DateOfIncorporation")]
        public string DateofIncorporationText
        {
            get
            {
                if (DateofIncorporation != null)
                    return DateofIncorporation.Value.ToString(m_ConstDateFormat);
                else return null;
            }
        }


        /// <summary>
        /// Date of Incorporation
        /// </summary>
        public DateTime? DateofIncorporation { get; set; }


        /// <summary>
        /// Place of Incorporation
        /// </summary>
        [DataField(Length = 75, IsRequired = true, Name="PlaceOfIncorporation")]
        public string PlaceOfIncorporation { get; set; }

        /// <summary>
        /// Date of commencement of business text format
        /// </summary>
        [DataField(Length = 8, IsRequired = true, Name="BusinessCommencementDate")]
        public string BusinessCommencementDateText
        {
            get
            {
                if (BusinessCommencementDate != null)
                    return BusinessCommencementDate.Value.ToString(m_ConstDateFormat);
                else return null;
            }
        }


        /// <summary>
        /// Date of commencement of business
        /// </summary>
        public DateTime? BusinessCommencementDate { get; set; }

        /// <summary>
        /// PAN 
        /// </summary>
        [DataField(Length = 10)]
        public string PAN { get; set; }

        /// <summary>
        /// Evidence / Documents provided in case of PAN exemption
        /// </summary>
        [DataField(Length = 75)]
        public string PANExemptionEvidence { get; set; }

        /// <summary>
        ///  Registration No. (e.g. CIN)
        /// </summary>
        [DataField(Length = 16)]
        public string RegistrationNo { get; set; }

        /// <summary>
        /// Status (Non Individual)
        /// </summary>
        [DataField(Length = 2, IsRequired = true)]
        public string Status { get; set; }

        /// <summary>
        /// Status Other
        /// </summary>
        [DataField(Length = 75)]
        public string StatusOther { get; set; }

        /// <summary>
        /// IPV Flag
        /// </summary>
        [DataField(Length = 1)]
        public string IPVFlag { get; set; }

        /// <summary>
        /// Name of the person doing the IPV
        /// </summary>
        [DataField(Length = 30)]
        public string IPVPersonName { get; set; }

        /// <summary>
        /// Designation of the person doing the IPV
        /// </summary>
        [DataField(Length = 20)]
        public string IPVPersonDesignation { get; set; }

        /// <summary>
        /// Organization Name of the person doing the IPV
        /// </summary>
        [DataField(Length = 70)]
        public string IPVOrganization { get; set; }

        /// <summary>
        /// Date of the IPV in text format 
        /// </summary>
        [DataField(Length = 8)]
        public string IPVDateText
        {
            get
            {
                if (IPVDate != null)
                    return IPVDate.Value.ToString(m_ConstDateFormat);
                else return null;
            }
        }

        /// <summary>
        /// Date of the IPV
        /// </summary>
        public DateTime? IPVDate { get; set; }

        /// <summary>
        /// Correspondence Address (Line 1)
        /// </summary>
        [DataField(Length = 36, IsRequired = true)]
        public string CorrespondenceAddress1 { get; set; }

        /// <summary>
        /// Correspondence Address (Line 2)
        /// </summary>
        [DataField(Length = 36)]
        public string CorrespondenceAddress2 { get; set; }

        /// <summary>
        /// Correspondence Address (Line 3)
        /// </summary>
        [DataField(Length = 36)]
        public string CorrespondenceAddress3 { get; set; }

        /// <summary>
        /// Correspondence Address City / Town / Village
        /// </summary>
        [DataField(Length = 36, Name="CorrespondenceAddressCity")]
        public string CorrAddCity { get; set; }

        /// <summary>
        /// Correspondence Address PIN Code
        /// </summary>
        [DataField(Length = 10, IsRequired = true,Name="CorrespondenceAddressPINCode")]
        public string CorrAddPINCode { get; set; }

        /// <summary>
        /// Correspondence Address State Code
        /// </summary>
        [DataField(Length = 2, IsRequired = true, Name=" CorrespondenceAddressStateCode")]
        public string CorrAddState { get; set; }

        /// <summary>
        /// Correspondence Address State Other
        /// </summary>
        [DataField(Length = 75)]
        public string CorrAddStateOther { get; set; }

        /// <summary>
        /// Correspondence Address Country
        /// </summary>
        [DataField(Length = 3, IsRequired = true, Name="CorrespondenceAddressCountry")]
        public string CorrAddCountry { get; set; }

        /// <summary>
        /// Proof of Address submitted for correspondence address
        /// </summary>
        [DataField(Length = 2, IsRequired = true, Name = "ProofOfCorrespondenceAddress")]
        public string ProofofAddressCorrAddress { get; set; }

        /// <summary>
        /// Proof of Address submitted for correspondence address (Other)
        /// </summary>
        [DataField(Length = 75)]
        public string ProofofAddressCorrAddressOther { get; set; }

        /// <summary>
        /// Tel. (Off.)
        /// </summary>
        [DataField(Length = 24)]
        public string TelOffice { get; set; }

        /// <summary>
        /// Tel. (Res.)
        /// </summary>
        [DataField(Length = 24)]
        public string TelRes { get; set; }

        /// <summary>
        /// Mobile No.
        /// </summary>
        [DataField(Length = 15)]
        public string MobileNo { get; set; }

        /// <summary>
        /// Fax No.
        /// </summary>
        [DataField(Length = 24)]
        public string FaxNo { get; set; }

        /// <summary>
        /// Email ID
        /// </summary>
        [DataField(Length = 50)]
        public string EmailID { get; set; }

        /// <summary>
        /// Filler (For Future Requirements)
        /// </summary>
        [DataField(Length = 50)]
        public string Filler3 { get; set; }


        /// <summary>
        /// Flag indicating if Registered Address is same as correspondence Address Y/N
        /// </summary>
        [DataField(Length = 1, IsRequired = true)]
        public string IsSameAsCorrespondence { get; set; }

        /// <summary>
        /// Registered Address (Line 1)
        /// </summary>
        [DataField(Length = 36, IsRequired = true)]
        public string RegisteredAddress1 { get; set; }

        /// <summary>
        /// Registered Address (Line 2)
        /// </summary>
        [DataField(Length = 36)]
        public string RegisteredAddress2 { get; set; }

        /// <summary>
        /// Registered Address (Line 3)
        /// </summary>
        [DataField(Length = 36)]
        public string RegisteredAddress3 { get; set; }

        /// <summary>
        /// Registered Address City/Town/ Village
        /// </summary>
        [DataField(Length = 36)]
        public string RegAddCity { get; set; }

        /// <summary>
        /// Registered Address PIN code
        /// </summary>
        [DataField(Length = 10, IsRequired = true, Name=" RegisteredAddressPINCode")]
        public string RegAddPINCode { get; set; }

        /// <summary>
        /// Registered Address State code
        /// </summary>
        [DataField(Length = 2, IsRequired = true, Name="RegisteredAddressStateCode")]
        public string RegAddState { get; set; }

        /// <summary>
        /// Registered Address State (Other)
        /// </summary>
        [DataField(Length = 75)]
        public string RegAddStateOther { get; set; }

        /// <summary>
        /// Registered Address Country
        /// </summary>
        [DataField(Length = 3, IsRequired = true, Name="RegisteredAddressCountry")]
        public string RegAddCountry { get; set; }

        /// <summary>
        /// Proof of Address submitted for Registered address
        /// </summary>
        [DataField(Length = 2, IsRequired = true, Name = "ProofOfRegisteredAddress")]
        public string ProofofRegAddress { get; set; }

        /// <summary>
        /// Proof of Address submitted for Registered address (Other)
        /// </summary>
        [DataField(Length = 75)]
        public string ProofofRegAddressOther { get; set; }


        /// <summary>
        /// Gross Annual Income Range
        /// </summary>
        [DataField(Length = 2)]
        public string GrossAnnualIncomeRange { get; set; }

        /// <summary>
        /// Net Worth (In Rs.)
        /// </summary>
        [DataField(Length = 18, IsRequired = true, IsMoney=true)]
        public decimal NetWorth { get; set; }

        /// <summary>
        /// Net Worth as on Date text format
        /// </summary>
        [DataField(Length = 8, IsRequired = true, Name = "NetWorthAsOnDate")]
        public string NetWorthOnDateText
        {
            get
            {
                if (NetWorthOnDate != null)
                    return NetWorthOnDate.Value.ToString(m_ConstDateFormat);
                else return null;
            }
        }

        /// <summary>
        /// Net Worth as on Date
        /// </summary>
        public DateTime? NetWorthOnDate { get; set; }


        /// <summary>
        /// Number of Promoters/Partners/Karta/Trustees and whole time directors
        /// </summary>
        [DataField(Length = 3, IsRequired = true, Name="NumberOfPromoters")]
        public int NumberofPromoters { get { return PromoterDetailList.Count; } }


        /// <summary>
        /// Politically Exposed Person (PEP)
        /// </summary>
        [DataField(Length = 2, IsRequired=true)]
        public string PEP { get; set; }



        /// <summary>
        /// Filler (For Future Requirements)
        /// </summary>
        [DataField(Length = 77)]
        public string Filler4 { get; set; }

        /// <summary>
        /// Any Other Information
        /// </summary>
        [DataField(Length = 100)]
        public string OtherInformation { get; set; }

        /// <summary>
        /// Date of Declaration text format
        /// </summary>
        [DataField(Length = 8, IsRequired = true, Name = "DateOfDeclaration")]
        public string DeclarationDateText
        {
            get
            {
                if (DeclarationDate != null)
                    return DeclarationDate.Value.ToString(m_ConstDateFormat);
                else return null;
            }
        }

        /// <summary>
        /// Date of Declaration
        /// </summary>
        public DateTime? DeclarationDate { get; set; }


        /// <summary>
        /// (Originals verified) True copies of documents received
        /// </summary>
        [DataField(Length = 1, IsRequired = true)]
        public string VerifiedCopiesReceived { get; set; }

        /// <summary>
        /// (Self-Attested) Self Certified Document copies received
        /// </summary>
        [DataField(Length = 1, IsRequired = true)]
        public string SelfAttestedReceived { get; set; }

        /// <summary>
        /// Document received Date at Intermediary text format
        /// </summary>
        [DataField(Length = 8)]
        public string DocumentReceivedOnText
        {
            get
            {
                if (DocumentReceivedOn != null)
                    return DocumentReceivedOn.Value.ToString(m_ConstDateFormat);
                else return null;
            }
        }

        /// <summary>
        /// Document received Date at Intermediary
        /// </summary>
        public DateTime? DocumentReceivedOn { get; set; }

        /// <summary>
        /// Number Of Documents Submitted
        /// </summary>
        [DataField(Length = 2)]
        public int DocumentsCount { get; set; }

        /// <summary>
        /// Sender reference number 1
        /// </summary>
        [DataField(Length = 35)]
        public string SenderRefNo1 { get; set; }

        /// <summary>
        /// Sender reference number 2
        /// </summary>
        [DataField(Length = 35)]
        public string SenderRefNo2 { get; set; }

        /// <summary>
        /// Client Activation Date text format
        /// </summary>
        [DataField(Length = 14)]
        public string ClientActivationDateText
        {
            get
            {
                if (ClientActivationDate != null)
                    return ClientActivationDate.Value.ToString(m_ConstDateTimeFormat);
                else return null;
            }
        }

        /// <summary>
        /// Client Activation Date
        /// </summary>
        public DateTime? ClientActivationDate { get; set; }

        /// <summary>
        /// Client updation Date text format
        /// </summary>
        [DataField(Length = 14)]
        public string ClientUpdationDateText
        {
            get
            {
                if (ClientUpdationDate != null)
                    return ClientUpdationDate.Value.ToString(m_ConstDateTimeFormat);
                else return null;
            }
        }

        /// <summary>
        /// Client Activation Date
        /// </summary>
        public DateTime? ClientUpdationDate { get; set; }

        /// <summary>
        /// Filler
        /// </summary>
        [DataField(Length = 1)]
        public string Filler5 { get; set; }

        /// <summary>
        /// Flag to indicate Old record
        /// </summary>
        [DataField(Length = 1)]
        public string IsOldRecord { get; set; }

        /// <summary>
        /// Filler
        /// </summary>
        [DataField(Length = 35)]
        public string Filler6 { get; set; }

        /// <summary>
        /// Intermediary Branch Code
        /// </summary>
        [DataField(Length = 6)]
        public string IntermediaryBranchCode { get; set; }

        /// <summary>
        ///   Acknowledgement Number
        /// </summary>
        [DataField(Length = 16, IsRequired = true)]
        public string AcknowledgementNumber { get; set; }

        /// <summary>
        /// KYC Request Status
        /// </summary>
        [DataField(Length = 2, IsRequired = true)]
        public string KYCStatus { get; set; }

        /// <summary>
        /// Request Status Change TimeStamp text format
        /// </summary>
        [DataField(Length = 14, IsRequired = true, Name = "RequestStatusChangeOn")]
        public string RequestStatusChangeOnText
        {
            get
            {
                if (RequestStatusChangeOn != null)
                    return RequestStatusChangeOn.Value.ToString(m_ConstDateTimeFormat);
                else return null;
            }
        }

        /// <summary>
        /// Request Status Change TimeStamp 
        /// </summary>
        public DateTime? RequestStatusChangeOn { get; set; }

        /// <summary>
        /// Remarks - 1 by KRA
        /// </summary>
        [DataField(Length = 50)]
        public string Remarks1 { get; set; }

        /// <summary>
        /// Remarks - 2 by KRA
        /// </summary>
        [DataField(Length = 50)]
        public string Remarks2 { get; set; }

        /// <summary>
        /// Flag for valid record
        /// </summary>
        public bool IsVaild { get; set; }


        /// <summary>
        /// List of Promoter
        /// </summary>
        public List<PromoterDetail> PromoterDetailList { get; set; }


        #endregion

        /// <summary>
        /// Return string after joinning all properties having custom attribute 
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return Utility.JoinProperties(this);
        }

    }


}
