﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UCC.Class.KRA.Karvy
{
    /// <summary>
    /// Class for Header Kary KRA Agency XML element 
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.0.30319.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public class HEADER
    {

        private object cOMPANY_CODEField;

        private string bATCH_DATEField;

        /// <remarks/>
        public object COMPANY_CODE
        {
            get
            {
                return this.cOMPANY_CODEField;
            }
            set
            {
                this.cOMPANY_CODEField = value;
            }
        }

        /// <remarks/>
        public string BATCH_DATE
        {
            get
            {
                return this.bATCH_DATEField;
            }
            set
            {
                this.bATCH_DATEField = value;
            }
        }
    }
}
