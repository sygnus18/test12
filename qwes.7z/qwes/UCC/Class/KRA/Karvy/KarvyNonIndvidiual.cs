﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace UCC.Class.KRA.Karvy
{

    [Serializable]
    [XmlRoot("APP_RES_ROOT")]
    class KarvyNonIndvidiualXML
    {
        public KarvyNonIndvidiualXML()
        {
            KarvySummaryElement = new KarvySummary();
            KarvyIndvidiualElements = new List<KarvyIndvidiual>();
        }

        [XmlAnyElement("APP_SUMM_REC")]
        public KarvySummary KarvySummaryElement { get; set; }

        [XmlArray("APP_PAN_INQ")]
        public IList<KarvyIndvidiual> KarvyIndvidiualElements { get; set; }

    }

    /// <summary>
    /// XML Serializable class for Karvy KRA Detail record 
    /// </summary>
    [Serializable]
    class KarvyIndvidiual
    {
    
        public string APP_IOP_FLG { get; set; }

        public string APP_INT_CODE { get; set; }

        public string APP_TYPE { get; set; }

        public uint APP_NO { get; set; }

        public string APP_DATE { get; set; }

        public string APP_PAN_NO { get; set; }

        public string APP_PANEX_NO { get; set; }

        public string APP_PAN_COPY { get; set; }

        public string APP_EXMT { get; set; }

        public byte APP_EXMT_CAT { get; set; }

        public byte APP_EXMT_ID_PROOF { get; set; }

        public string APP_IPV_FLAG { get; set; }

        public string APP_IPV_DATE { get; set; }

        public string APP_GEN { get; set; }

        public string APP_NAME { get; set; }

        public string APP_F_NAME { get; set; }

        public string APP_REGNO { get; set; }

        public string APP_DOB_DT { get; set; }

        public string APP_DOI_DT { get; set; }

        public string APP_COMMENCE_DT { get; set; }

        public byte APP_NATIONALITY { get; set; }

        public string APP_OTH_NATIONALITY { get; set; }

        public string APP_COMP_STATUS { get; set; }

        public string APP_OTH_COMP_STATUS { get; set; }

        public string APP_RES_STATUS { get; set; }

        public byte APP_RES_STATUS_PROOF { get; set; }

        public string APP_UID_NO { get; set; }

        public string APP_COR_ADD1 { get; set; }

        public string APP_COR_ADD2 { get; set; }

        public string APP_COR_ADD3 { get; set; }

        public string APP_COR_CITY { get; set; }

        public uint APP_COR_PINCD { get; set; }

        public byte APP_COR_STATE { get; set; }

        public byte APP_COR_CTRY { get; set; }

        public string APP_OFF_NO { get; set; }

        public string APP_RES_NO { get; set; }

        public ulong APP_MOB_NO { get; set; }

        public string APP_FAX_NO { get; set; }

        public string APP_EMAIL { get; set; }

        public byte APP_COR_ADD_PROOF { get; set; }

        public ulong APP_COR_ADD_REF { get; set; }

        public string APP_COR_ADD_DT { get; set; }

        public string APP_PER_ADD1 { get; set; }

        public string APP_PER_ADD2 { get; set; }

        public string APP_PER_ADD3 { get; set; }

        public string APP_PER_CITY { get; set; }

        public uint APP_PER_PINCD { get; set; }

        public byte APP_PER_STATE { get; set; }

        public byte APP_PER_CTRY { get; set; }

        public byte APP_PER_ADD_PROOF { get; set; }

        public ulong APP_PER_ADD_REF { get; set; }

        public string APP_PER_ADD_DT { get; set; }

        public byte APP_INCOME { get; set; }

        public byte APP_OCC { get; set; }

        public string APP_OTH_OCC { get; set; }

        public string APP_POL_CONN { get; set; }

        public string APP_DOC_PROOF { get; set; }

        public string APP_INTERNAL_REF { get; set; }

        public string APP_BRANCH_CODE { get; set; }

        public byte APP_MAR_STATUS { get; set; }

        public byte APP_NETWRTH { get; set; }

        public string APP_NETWORTH_DT { get; set; }

        public string APP_INCORP_PLC { get; set; }

        public string APP_OTHERINFO { get; set; }

        public string APP_FILLER1 { get; set; }

        public string APP_FILLER2 { get; set; }

        public string APP_FILLER3 { get; set; }

        public byte APP_STATUS { get; set; }

        public string APP_STATUSDT { get; set; }

        public string APP_ERROR_DESC { get; set; }

        public string APP_DUMP_TYPE { get; set; }

        public string APP_DNLDDT { get; set; }

        public string APP_KRA_INFO { get; set; }

        public string APP_SIGNATURE { get; set; }

        public ushort APP_POS_CODE { get; set; }
    }
}
