﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UCC.Class.KRA.Karvy
{


    /// <summary>
    /// Class for Footer Kary KRA Agency XML element 
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.0.30319.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public class FOOTER
    {

        private int nO_OF_KYC_RECORDSField;

        private int nO_OF_ADDLDATA_RECORDSField;

        /// <summary>
        /// Count of KYC records
        /// </summary>
       public int NO_OF_KYC_RECORDS
        {
            get
            {
                return this.nO_OF_KYC_RECORDSField;
            }
            set
            {
                this.nO_OF_KYC_RECORDSField = value;
            }
        }

        /// <summary>
        /// Count of addtional detail records
        /// </summary>
        public int NO_OF_ADDLDATA_RECORDS
        {
            get
            {
                return this.nO_OF_ADDLDATA_RECORDSField;
            }
            set
            {
                this.nO_OF_ADDLDATA_RECORDSField = value;
            }
        }
    }
}
