﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UCC.Class.KRA.CVL
{

    /// <summary>
    /// Class for KYC detail XML element
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.0.30319.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class KYCDATA
    {

        private byte aPP_UPDTFLGField;

        private string aPP_POS_CODEField;

        private string aPP_TYPEField;

        private byte aPP_NOField;

        private string aPP_DATEField;

        private string aPP_PAN_NOField;

        private string aPP_PAN_COPYField;

        private string aPP_EXMTField;

        private string aPP_EXMT_CATField;

        private byte aPP_EXMT_ID_PROOFField;

        private string aPP_IPV_FLAGField;

        private string aPP_IPV_DATEField;

        private string aPP_GENField;

        private string aPP_NAMEField;

        private string aPP_F_NAMEField;

        private object aPP_REGNOField;

        private string aPP_DOB_INCORPField;

        private string aPP_COMMENCE_DTField;

        private string aPP_NATIONALITYField;

        private object aPP_OTH_NATIONALITYField;

        private object aPP_COMP_STATUSField;

        private object aPP_OTH_COMP_STATUSField;

        private string aPP_RES_STATUSField;

        private string aPP_RES_STATUS_PROOFField;

        private string aPP_UID_NOField;

        private string aPP_COR_ADD1Field;

        private string aPP_COR_ADD2Field;

        private string aPP_COR_ADD3Field;

        private string aPP_COR_CITYField;

        private string aPP_COR_PINCDField;

        private string aPP_COR_STATEField;

        private string aPP_COR_CTRYField;

        private byte aPP_OFF_ISDField;

        private byte aPP_OFF_STDField;

        private string aPP_OFF_NOField;

        private byte aPP_RES_ISDField;

        private byte aPP_RES_STDField;

        private string aPP_RES_NOField;

        private byte aPP_MOB_ISDField;

        private string aPP_MOB_NOField;

        private string aPP_FAX_ISDField;

        private string aPP_FAX_STDField;

        private string  aPP_FAX_NOField;

        private string aPP_EMAILField;

        private string aPP_COR_ADD_PROOFField;

        private string aPP_COR_ADD_REFField;

        private string aPP_COR_ADD_DTField;

        private string aPP_PER_ADD_FLAGField;

        private string aPP_PER_ADD1Field;

        private string aPP_PER_ADD2Field;

        private string aPP_PER_ADD3Field;

        private string aPP_PER_CITYField;

        private string aPP_PER_PINCDField;

        private string aPP_PER_STATEField;

        private string  aPP_PER_CTRYField;

        private byte aPP_PER_ADD_PROOFField;

        private string aPP_PER_ADD_REFField;

        private string aPP_PER_ADD_DTField;

        private string aPP_INCOMEField;

        private string aPP_OCCField;

        private object aPP_OTH_OCCField;

        private string aPP_POL_CONNField;

        private string aPP_DOC_PROOFField;

        private object aPP_INTERNAL_REFField;

        private string aPP_BRANCH_CODEField;

        private byte aPP_MAR_STATUSField;

        private decimal aPP_NETWRTHField;

        private string aPP_NETWORTH_DTField;

        private string aPP_INCORP_PLCField;

        private string aPP_OTHERINFOField;

        private string aPP_FILLER1Field;

        private string aPP_FILLER2Field;

        private string aPP_FILLER3Field;



        /// <summary>
        /// UPDATE FLAG
        /// </summary>
        public byte APP_UPDTFLG
        {
            get
            {
                return this.aPP_UPDTFLGField;
            }
            set
            {
                this.aPP_UPDTFLGField = value;
            }
        }

        /// <summary>
        /// POS CODE :RTA to update the POS code of the AMC on whose behalf they are updating the request.
        /// All other intermediaries to update their own POS code
        /// </summary>
        public string APP_POS_CODE
        {
            get
            {
                return this.aPP_POS_CODEField;
            }
            set
            {
                this.aPP_POS_CODEField = value;
            }
        }

        /// <summary>
        /// APPLICANT TYPE
        /// </summary>
        public string APP_TYPE
        {
            get
            {
                return this.aPP_TYPEField;
            }
            set
            {
                this.aPP_TYPEField = value;
            }
        }

        /// <summary>
        /// APPLICATION NO
        /// </summary>
        public byte APP_NO
        {
            get
            {
                return this.aPP_NOField;
            }
            set
            {
                this.aPP_NOField = value;
            }
        }

        /// <summary>
        /// APPLICATION DATE :  dd/mm/yyyy
        /// </summary>
        public string APP_DATE
        {
            get
            {
                return this.aPP_DATEField;
            }
            set
            {
                this.aPP_DATEField = value;
            }
        }

        /// <summary>
        /// PAN GIR NO
        /// </summary>
        public string APP_PAN_NO
        {
            get
            {
                return this.aPP_PAN_NOField;
            }
            set
            {
                this.aPP_PAN_NOField = value;
            }
        }

        /// <summary>
        /// Pan copy if enclosed or not.
        /// </summary>
        public string APP_PAN_COPY
        {
            get
            {
                return this.aPP_PAN_COPYField;
            }
            set
            {
                this.aPP_PAN_COPYField = value;
            }
        }


        /// <summary>
        /// If person or entity is exempt.
        /// </summary>
        public string APP_EXMT
        {
            get
            {
                return this.aPP_EXMTField;
            }
            set
            {
                this.aPP_EXMTField = value;
            }
        }

        /// <summary>
        /// EXEMPTION CATEGORY
        /// </summary>
        public string APP_EXMT_CAT
        {
            get
            {
                return this.aPP_EXMT_CATField;
            }
            set
            {
                this.aPP_EXMT_CATField = value;
            }
        }

        /// <summary>
        /// PROOF OF ID
        /// </summary>
        public byte APP_EXMT_ID_PROOF
        {
            get
            {
                return this.aPP_EXMT_ID_PROOFField;
            }
            set
            {
                this.aPP_EXMT_ID_PROOFField = value;
            }
        }

        /// <summary>
        /// IN-PERSON VERIFICATION
        /// </summary>
        public string APP_IPV_FLAG
        {
            get
            {
                return this.aPP_IPV_FLAGField;
            }
            set
            {
                this.aPP_IPV_FLAGField = value;
            }
        }

        /// <summary>
        /// IN-PERSON VERIFICATION DATE
        /// </summary>
        public string APP_IPV_DATE
        {
            get
            {
                return this.aPP_IPV_DATEField;
            }
            set
            {
                this.aPP_IPV_DATEField = value;
            }
        }

        /// <summary>
        /// GENDER
        /// </summary>
        public string APP_GEN
        {
            get
            {
                return this.aPP_GENField;
            }
            set
            {
                this.aPP_GENField = value;
            }
        }


        /// <summary>
        /// APPLICANT NAME / ENTITY NAME
        /// </summary>
        public string APP_NAME
        {
            get
            {
                return this.aPP_NAMEField;
            }
            set
            {
                this.aPP_NAMEField = value;
            }
        }


        /// <summary>
        /// FATHER'S NAME
        /// </summary>
        public string APP_F_NAME
        {
            get
            {
                return this.aPP_F_NAMEField;
            }
            set
            {
                this.aPP_F_NAMEField = value;
            }
        }


        /// <summary>
        /// ENTITY REGISTRATION NUMBER
        /// </summary>
        public object APP_REGNO
        {
            get
            {
                return this.aPP_REGNOField;
            }
            set
            {
                this.aPP_REGNOField = value;
            }
        }

        /// <summary>
        /// DATE OF BIRTH / INCORPORATION
        /// </summary>
        public string APP_DOB_INCORP
        {
            get
            {
                return this.aPP_DOB_INCORPField;
            }
            set
            {
                this.aPP_DOB_INCORPField = value;
            }
        }

        /// <summary>
        /// COMMENCEMENT DATE
        /// </summary>
        public string APP_COMMENCE_DT
        {
            get
            {
                return this.aPP_COMMENCE_DTField;
            }
            set
            {
                this.aPP_COMMENCE_DTField = value;
            }
        }

        /// <summary>
        /// NATIONALITY
        /// </summary>
        public string APP_NATIONALITY
        {
            get
            {
                return this.aPP_NATIONALITYField;
            }
            set
            {
                this.aPP_NATIONALITYField = value;
            }
        }


        /// <summary>
        /// NATIONALITY (OTHERS)
        /// </summary>
        public object APP_OTH_NATIONALITY
        {
            get
            {
                return this.aPP_OTH_NATIONALITYField;
            }
            set
            {
                this.aPP_OTH_NATIONALITYField = value;
            }
        }

        /// <summary>
        /// COMPANY STATUS
        /// </summary>
        public object APP_COMP_STATUS
        {
            get
            {
                return this.aPP_COMP_STATUSField;
            }
            set
            {
                this.aPP_COMP_STATUSField = value;
            }
        }

        /// <summary>
        /// COMPANY STATUS Other
        /// </summary>
        public object APP_OTH_COMP_STATUS
        {
            get
            {
                return this.aPP_OTH_COMP_STATUSField;
            }
            set
            {
                this.aPP_OTH_COMP_STATUSField = value;
            }
        }


        /// <summary>
        /// RESIDENTIAL STATUS OF INDIVIDUALS
        /// </summary>
        public string APP_RES_STATUS
        {
            get
            {
                return this.aPP_RES_STATUSField;
            }
            set
            {
                this.aPP_RES_STATUSField = value;
            }
        }


        /// <summary>
        /// RESIDENTIAL STATUS PROOF FOR NON-RESIDENT / PERSON OF INDIAN ORIGIN
        /// </summary>
        public string APP_RES_STATUS_PROOF
        {
            get
            {
                return this.aPP_RES_STATUS_PROOFField;
            }
            set
            {
                this.aPP_RES_STATUS_PROOFField = value;
            }
        }


        /// <summary>
        /// AADHAR NO / UID NO
        /// </summary>
        public string APP_UID_NO
        {
            get
            {
                return this.aPP_UID_NOField;
            }
            set
            {
                this.aPP_UID_NOField = value;
            }
        }


        /// <summary>
        /// Correspondence Address 1 
        /// </summary>
        public string APP_COR_ADD1
        {
            get
            {
                return this.aPP_COR_ADD1Field;
            }
            set
            {
                this.aPP_COR_ADD1Field = value;
            }
        }

        /// <summary>
        /// Correspondence Address 2
        /// </summary>
        public string APP_COR_ADD2
        {
            get
            {
                return this.aPP_COR_ADD2Field;
            }
            set
            {
                this.aPP_COR_ADD2Field = value;
            }
        }

        /// <summary>
        /// Correspondence Address 3
        /// </summary>
        public string APP_COR_ADD3
        {
            get
            {
                return this.aPP_COR_ADD3Field;
            }
            set
            {
                this.aPP_COR_ADD3Field = value;
            }
        }

        /// <summary>
        /// Correspondence Address City
        /// </summary>
        public string APP_COR_CITY
        {
            get
            {
                return this.aPP_COR_CITYField;
            }
            set
            {
                this.aPP_COR_CITYField = value;
            }
        }


        /// <summary>
        /// Correspondence Address PIN Code
        /// </summary>
        public string APP_COR_PINCD
        {
            get
            {
                return this.aPP_COR_PINCDField;
            }
            set
            {
                this.aPP_COR_PINCDField = value;
            }
        }


        /// <summary>
        /// Correspondence Address State
        /// </summary>
        public string APP_COR_STATE
        {
            get
            {
                return this.aPP_COR_STATEField;
            }
            set
            {
                this.aPP_COR_STATEField = value;
            }
        }

        /// <summary>
        /// Correspondence Address Country
        /// </summary>
        public string APP_COR_CTRY
        {
            get
            {
                return this.aPP_COR_CTRYField;
            }
            set
            {
                this.aPP_COR_CTRYField = value;
            }
        }

        /// <summary>
        /// Office Tel ISD
        /// </summary>
        public byte APP_OFF_ISD
        {
            get
            {
                return this.aPP_OFF_ISDField;
            }
            set
            {
                this.aPP_OFF_ISDField = value;
            }
        }

        /// <summary>
        /// Office Tel STD
        /// </summary>
        public byte APP_OFF_STD
        {
            get
            {
                return this.aPP_OFF_STDField;
            }
            set
            {
                this.aPP_OFF_STDField = value;
            }
        }

        /// <summary>
        /// Office Tel No.
        /// </summary>
        public string APP_OFF_NO
        {
            get
            {
                return this.aPP_OFF_NOField;
            }
            set
            {
                this.aPP_OFF_NOField = value;
            }
        }

        /// <summary>
        /// Res. TEL ISD
        /// </summary>
        public byte APP_RES_ISD
        {
            get
            {
                return this.aPP_RES_ISDField;
            }
            set
            {
                this.aPP_RES_ISDField = value;
            }
        }

        /// <summary>
        /// Res. Tel STD
        /// </summary>
        public byte APP_RES_STD
        {
            get
            {
                return this.aPP_RES_STDField;
            }
            set
            {
                this.aPP_RES_STDField = value;
            }
        }

        /// <summary>
        /// Res. Tel No
        /// </summary>
        public string APP_RES_NO
        {
            get
            {
                return this.aPP_RES_NOField;
            }
            set
            {
                this.aPP_RES_NOField = value;
            }
        }

        /// <summary>
        /// Mobile No ISD
        /// </summary>
        public byte APP_MOB_ISD
        {
            get
            {
                return this.aPP_MOB_ISDField;
            }
            set
            {
                this.aPP_MOB_ISDField = value;
            }
        }

        /// <summary>
        /// Mobile No
        /// </summary>
        public string APP_MOB_NO
        {
            get
            {
                return this.aPP_MOB_NOField;
            }
            set
            {
                this.aPP_MOB_NOField = value;
            }
        }

        /// <summary>
        /// FAX No. ISD
        /// </summary>
        public string APP_FAX_ISD
        {
            get
            {
                return this.aPP_FAX_ISDField;
            }
            set
            {
                this.aPP_FAX_ISDField = value;
            }
        }

        /// <summary>
        /// FAX No STD
        /// </summary>
        public string APP_FAX_STD
        {
            get
            {
                return this.aPP_FAX_STDField;
            }
            set
            {
                this.aPP_FAX_STDField = value;
            }
        }

        /// <summary>
        /// FAX No
        /// </summary>
        public string APP_FAX_NO
        {
            get
            {
                return this.aPP_FAX_NOField;
            }
            set
            {
                this.aPP_FAX_NOField = value;
            }
        }

        /// <summary>
        /// Email Address
        /// </summary>
        public string APP_EMAIL
        {
            get
            {
                return this.aPP_EMAILField;
            }
            set
            {
                this.aPP_EMAILField = value;
            }
        }

        /// <summary>
        /// Correspondence Address Proof ID
        /// </summary>
        public string APP_COR_ADD_PROOF
        {
            get
            {
                return this.aPP_COR_ADD_PROOFField;
            }
            set
            {
                this.aPP_COR_ADD_PROOFField = value;
            }
        }

        /// <summary>
        /// Correspondence Address Proof ID
        /// </summary>
        public string APP_COR_ADD_REF
        {
            get
            {
                return this.aPP_COR_ADD_REFField;
            }
            set
            {
                this.aPP_COR_ADD_REFField = value;
            }
        }

        /// <summary>
        /// COR ADDRESS PROOF REF DATE
        /// </summary>
        public string APP_COR_ADD_DT
        {
            get
            {
                return this.aPP_COR_ADD_DTField;
            }
            set
            {
                this.aPP_COR_ADD_DTField = value;
            }
        }

        /// <summary>
        /// PERMANENT / FOREIGN / REGISTERED ADDRESS FLAG (SAME AS COR ADD)
        /// </summary>
        public string APP_PER_ADD_FLAG
        {
            get
            {
                return this.aPP_PER_ADD_FLAGField;
            }
            set
            {
                this.aPP_PER_ADD_FLAGField = value;
            }
        }

        /// <summary>
        /// Permanent Address 1
        /// </summary>
        public string APP_PER_ADD1
        {
            get
            {
                return this.aPP_PER_ADD1Field;
            }
            set
            {
                this.aPP_PER_ADD1Field = value;
            }
        }

        /// <summary>
        /// Permanent Address 2
        /// </summary>
        public string APP_PER_ADD2
        {
            get
            {
                return this.aPP_PER_ADD2Field;
            }
            set
            {
                this.aPP_PER_ADD2Field = value;
            }
        }

        /// <summary>
        /// Permanent Address 3
        /// </summary>
        public string APP_PER_ADD3
        {
            get
            {
                return this.aPP_PER_ADD3Field;
            }
            set
            {
                this.aPP_PER_ADD3Field = value;
            }
        }

        /// <summary>
        /// Permanent Address City
        /// </summary>
        public string APP_PER_CITY
        {
            get
            {
                return this.aPP_PER_CITYField;
            }
            set
            {
                this.aPP_PER_CITYField = value;
            }
        }

        /// <summary>
        /// Permanent Address PIN
        /// </summary>
        public string APP_PER_PINCD
        {
            get
            {
                return this.aPP_PER_PINCDField;
            }
            set
            {
                this.aPP_PER_PINCDField = value;
            }
        }

        /// <summary>
        /// Permanent Address State
        /// </summary>
        public string APP_PER_STATE
        {
            get
            {
                return this.aPP_PER_STATEField;
            }
            set
            {
                this.aPP_PER_STATEField = value;
            }
        }

        /// <summary>
        /// Permanent Address Country
        /// </summary>
        public string APP_PER_CTRY
        {
            get
            {
                return this.aPP_PER_CTRYField;
            }
            set
            {
                this.aPP_PER_CTRYField = value;
            }
        }

        /// <summary>
        /// ADDRESS PROOF of Permanent/Foreign/Permanent Address Proof.
        /// </summary>
        public byte APP_PER_ADD_PROOF
        {
            get
            {
                return this.aPP_PER_ADD_PROOFField;
            }
            set
            {
                this.aPP_PER_ADD_PROOFField = value;
            }
        }

        /// <summary>
        /// Document reference number of address proof submitted.
        /// </summary>
        public string APP_PER_ADD_REF
        {
            get
            {
                return this.aPP_PER_ADD_REFField;
            }
            set
            {
                this.aPP_PER_ADD_REFField = value;
            }
        }


        /// <summary>
        /// PERM / FOREIGN ADD PROOF REFERENCE DATE
        /// </summary>
        public string APP_PER_ADD_DT
        {
            get
            {
                return this.aPP_PER_ADD_DTField;
            }
            set
            {
                this.aPP_PER_ADD_DTField = value;
            }
        }

        /// <summary>
        /// GROSS ANNUAL INCOME RANGE
        /// </summary>
        public string APP_INCOME
        {
            get
            {
                return this.aPP_INCOMEField;
            }
            set
            {
                this.aPP_INCOMEField = value;
            }
        }

        /// <summary>
        /// OCCUPATION DETAILS
        /// </summary>
        public string APP_OCC
        {
            get
            {
                return this.aPP_OCCField;
            }
            set
            {
                this.aPP_OCCField = value;
            }
        }

        /// <summary>
        /// OCCUPATION DETAILS (OTHERS)
        /// </summary>
        public object APP_OTH_OCC
        {
            get
            {
                return this.aPP_OTH_OCCField;
            }
            set
            {
                this.aPP_OTH_OCCField = value;
            }
        }

        /// <summary>
        /// PEP STATUS
        /// </summary>
        public string APP_POL_CONN
        {
            get
            {
                return this.aPP_POL_CONNField;
            }
            set
            {
                this.aPP_POL_CONNField = value;
            }
        }

        /// <summary>
        /// DOCUMENT SUBMISSION DETAILS
        /// </summary>
        public string APP_DOC_PROOF
        {
            get
            {
                return this.aPP_DOC_PROOFField;
            }
            set
            {
                this.aPP_DOC_PROOFField = value;
            }
        }

        /// <summary>
        /// INTERMEDIARY INTERNAL REFERENCE NO
        /// </summary>
        public object APP_INTERNAL_REF
        {
            get
            {
                return this.aPP_INTERNAL_REFField;
            }
            set
            {
                this.aPP_INTERNAL_REFField = value;
            }
        }

        /// <summary>
        /// Branch Code to which the KYC is attached to.
        /// </summary>
        public string APP_BRANCH_CODE
        {
            get
            {
                return this.aPP_BRANCH_CODEField;
            }
            set
            {
                this.aPP_BRANCH_CODEField = value;
            }
        }

        /// <summary>
        /// MARITAL STATUS
        /// </summary>
        public byte APP_MAR_STATUS
        {
            get
            {
                return this.aPP_MAR_STATUSField;
            }
            set
            {
                this.aPP_MAR_STATUSField = value;
            }
        }


        /// <summary>
        /// Net Worth
        /// </summary>
        public decimal APP_NETWRTH
        {
            get
            {
                return this.aPP_NETWRTHField;
            }
            set
            {
                this.aPP_NETWRTHField = value;
            }
        }

        /// <summary>
        /// NETWORTH DATE
        /// </summary>
        public string APP_NETWORTH_DT
        {
            get
            {
                return this.aPP_NETWORTH_DTField;
            }
            set
            {
                this.aPP_NETWORTH_DTField = value;
            }
        }

        /// <summary>
        /// PLACE OF INCORPORATION
        /// </summary>
        public string APP_INCORP_PLC
        {
            get
            {
                return this.aPP_INCORP_PLCField;
            }
            set
            {
                this.aPP_INCORP_PLCField = value;
            }
        }

        /// <summary>
        /// ANY OTHER INFORMATION
        /// </summary>
        public string APP_OTHERINFO
        {
            get
            {
                return this.aPP_OTHERINFOField;
            }
            set
            {
                this.aPP_OTHERINFOField = value;
            }
        }


        public string APP_FILLER1
        {
            get
            {
                return this.aPP_FILLER1Field;
            }
            set
            {
                this.aPP_FILLER1Field = value;
            }
        }


        public string APP_FILLER2
        {
            get
            {
                return this.aPP_FILLER2Field;
            }
            set
            {
                this.aPP_FILLER2Field = value;
            }
        }


        public string APP_FILLER3
        {
            get
            {
                return this.aPP_FILLER3Field;
            }
            set
            {
                this.aPP_FILLER3Field = value;
            }
        }
    }
}
