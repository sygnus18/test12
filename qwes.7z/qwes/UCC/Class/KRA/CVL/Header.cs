﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UCC.Class.KRA.CVL
{
    
    /// <summary>
    /// Class for CVL KRA Header XML element
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.0.30319.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class HEADER
    {

        private string cOMPANY_CODEField;

        private string bATCH_DATEField;

       /// <summary>
       /// POS CODE
       /// </summary>
        public string COMPANY_CODE
        {
            get
            {
                return this.cOMPANY_CODEField;
            }
            set
            {
                this.cOMPANY_CODEField = value;
            }
        }

        /// <summary>
        /// UPLOAD DATE : DD/MM/YYYY
        /// </summary>
        public string BATCH_DATE
        {
            get
            {
                return this.bATCH_DATEField;
            }
            set
            {
                this.bATCH_DATEField = value;
            }
        }
    }
}
