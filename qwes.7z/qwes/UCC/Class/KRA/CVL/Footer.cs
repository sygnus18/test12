﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UCC.Class.KRA.CVL
{
    /// <summary>
    /// Class for CVL KRA Footer XML element
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.0.30319.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class FOOTER
    {

        private int nO_OF_KYC_RECORDSField;

        private int nO_OF_ADDLDATA_RECORDSField;

       /// <summary>
        /// KYC DETAILS RECORD
       /// </summary>
        public int NO_OF_KYC_RECORDS
        {
            get
            {
                return this.nO_OF_KYC_RECORDSField;
            }
            set
            {
                this.nO_OF_KYC_RECORDSField = value;
            }
        }

        /// <summary>
        /// ADDITIONAL DETAILS RECORD
        /// </summary>
        public int NO_OF_ADDLDATA_RECORDS
        {
            get
            {
                return this.nO_OF_ADDLDATA_RECORDSField;
            }
            set
            {
                this.nO_OF_ADDLDATA_RECORDSField = value;
            }
        }
    }
}
