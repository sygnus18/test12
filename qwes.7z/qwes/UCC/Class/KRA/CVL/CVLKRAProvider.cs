﻿using System;
using System.Collections.Generic;
using System.Text;
using UCC.Class.Master;
using FTIL.Match.Common;


namespace UCC.Class.KRA.CVL
{

    public struct CVLConstants
    {
        public static readonly string DateFormat = FTIL.Match.Common.Constants.Formatting.Instance.DATE_FORMAT_DDbsMMbsYYYY;
    }


    /// <summary>
    /// Class for CDSL-CVL KRA agency 
    /// KRA File Type Fomat : XML
    /// </summary>
    class CVLKRAProvider : BaseKRAProvider, IKRAProvider
    {

        #region private members

        /// <summary>
        /// Root Element For NonIndividual
        /// </summary>
        private NonIndividual.ROOT m_ObjNonIndividualRootXML;
     
        /// <summary>
        /// Detail elements for NonIndividual
        /// </summary>
        private List<NonIndividual.ADDITIONALDATA> m_NonIndAddtionalDataElements;

        /// <summary>
        /// Detail  elements for NonIndividual
        /// </summary>
        private List<KYCDATA> m_NonIndKYCDataElements;

        /// <summary>
        /// Root Element For Individual
        /// </summary>
        private Individual.ROOT m_ObjIndividualRootXML;
        /// <summary>
        /// Detail elements for Individual
        /// </summary>
        private List<KYCDATA> m_IndKYCDataElements;



        #endregion

        #region IKRAProvider Methods implementation

        public CVLKRAProvider() : base(KRAAgencyEnum.CVL)
        {
            m_ObjNonIndividualRootXML = new NonIndividual.ROOT();
            m_NonIndAddtionalDataElements = new List<NonIndividual.ADDITIONALDATA>();
            m_NonIndKYCDataElements = new List<KYCDATA>();

            m_ObjIndividualRootXML = new Individual.ROOT();
            m_IndKYCDataElements = new List<KYCDATA>();
        }

        public FTIL.Match.Common.MethodExecResult ProcessKRAClients(List<Master.CClient> clients)
        {

            foreach (CClient client in clients)
            {

                if (client.ClientType == ClientType.INDIVIDUAL)
                    ProcessIndividual(client);

                if (client.ClientType == ClientType.NON_INDIVIDUAL)
                    ProcessNonIndividual(client);
            }

            return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, "Success", "ProcessKRAClients() UserNo. " + AppEnvironment.AppUser.UserNo, null);

        }

        public Dictionary<string, string> GetKRARecordsToText()
        {
            string l_sXMLString = string.Empty;
            Dictionary<string, string> l_DicFileNameKRAText = new Dictionary<string, string>();

            HEADER l_Header = new HEADER();
            FOOTER l_Footer = new FOOTER();


            string l_sFileName = "";

            //TODO : Set Header
            l_Header.BATCH_DATE = this.DateToString(DateTime.Now);
            l_Header.COMPANY_CODE = null;


            /*************************************          INDIVIDUAL      ************************************************/

            l_Footer.NO_OF_KYC_RECORDS = this.m_IndKYCDataElements.Count;

            //Add Header element into the root XML object
            this.m_ObjIndividualRootXML.HEADER = l_Header;

            //Append detail elements (KYC data) 
            this.m_ObjIndividualRootXML.KYCDATA = m_IndKYCDataElements.ToArray();

            //Add Footer element
            this.m_ObjIndividualRootXML.FOOTER = l_Footer;

            l_sXMLString = Utility.ObjectToXML(this.m_ObjIndividualRootXML);
            l_sFileName = "KRA" + Enum.GetName(typeof(KRAFileTypeEnum), KRAFileTypeEnum.INDIVIDUAL) + DateTime.Now.ToString("HHmmss") + ".xml";

            //Add XML string with File name into the Dictionory
            l_DicFileNameKRAText.Add(l_sFileName, l_sXMLString);

            /****************************************************************************************************************/


            /*************************************     NON-INDIVIDUAL      ************************************************/

            l_Footer.NO_OF_ADDLDATA_RECORDS = this.m_NonIndAddtionalDataElements.Count;
            l_Footer.NO_OF_KYC_RECORDS = this.m_NonIndKYCDataElements.Count;



            this.m_ObjNonIndividualRootXML.ADDITIONALDATA = this.m_NonIndAddtionalDataElements.ToArray();
            this.m_ObjNonIndividualRootXML.KYCDATA = this.m_NonIndKYCDataElements.ToArray();
            this.m_ObjNonIndividualRootXML.HEADER = l_Header;
            this.m_ObjNonIndividualRootXML.FOOTER = l_Footer;

            l_sXMLString = Utility.ObjectToXML(this.m_ObjNonIndividualRootXML);

            l_sFileName = "KRA" + Enum.GetName(typeof(KRAFileTypeEnum), KRAFileTypeEnum.NON_INDIVIDUAL) + DateTime.Now.ToString("HHmmss") + ".xml";

            l_DicFileNameKRAText.Add(l_sFileName, l_sXMLString);

            /****************************************************************************************************************/

            return l_DicFileNameKRAText;
        }



        #endregion

        #region private methods

        private void ProcessIndividual(CClient client)
        {
            KYCDATA l_KYCDetail = new KYCDATA();

            SetKYCDataCommon(client, ref l_KYCDetail);

            // SET Properties for   Individual //

            this.m_IndKYCDataElements.Add(l_KYCDetail);
        }


        private void ProcessNonIndividual(CClient client)
        {
            KYCDATA l_KYCDetail = new KYCDATA();
            NonIndividual.ADDITIONALDATA l_AdditionalDetail = new NonIndividual.ADDITIONALDATA();

            SetKYCDataCommon(client, ref l_KYCDetail);

            // SET Properties for   NonIndividual //


            this.m_NonIndKYCDataElements.Add(l_KYCDetail);
            this.m_NonIndAddtionalDataElements.Add(l_AdditionalDetail);
        }


        private void SetKYCDataCommon(CClient client, ref KYCDATA kycData)
        {
            CAddress l_CorrespondenceAddress = client.ClientAddresses.GetAddressByType(AddressTypeEnum.Correspondence);
            CAddress l_RegisteredAddress = client.ClientAddresses.GetAddressByType(AddressTypeEnum.Registered);

            bool l_SameCorrPermAdd = false;

            kycData.APP_NAME = client.ClientName;
            kycData.APP_GEN = client.Gender;


            kycData.APP_PAN_NO = client.PANNo;
            kycData.APP_EXMT = client.PanExempt;


            kycData.APP_NATIONALITY = GetRefData(client.Nationality);
            kycData.APP_OTH_NATIONALITY = client.NationalityOther;

            if (l_CorrespondenceAddress != null)
            {
                l_SameCorrPermAdd = l_CorrespondenceAddress.SameCorrPermAdd == "Y" ? true : false;
                kycData.APP_COR_ADD1 = l_CorrespondenceAddress.AddressLine1;
                kycData.APP_COR_ADD2 = l_CorrespondenceAddress.AddressLine2;
                kycData.APP_COR_ADD3 = l_CorrespondenceAddress.AddressLine3;
                kycData.APP_COR_CITY = l_CorrespondenceAddress.City;
                kycData.APP_COR_PINCD = l_CorrespondenceAddress.PinCode;
                kycData.APP_COR_STATE = GetRefData(l_CorrespondenceAddress.StateNumber);
                kycData.APP_COR_CTRY = GetRefData(l_CorrespondenceAddress.CountryCode);

                kycData.APP_UID_NO = l_CorrespondenceAddress.UID;
                kycData.APP_OFF_NO = l_CorrespondenceAddress.TelNoOffice;
                kycData.APP_RES_NO = l_CorrespondenceAddress.TelNo1;
                kycData.APP_MOB_NO = l_CorrespondenceAddress.Mobile1;
                kycData.APP_FAX_NO = l_CorrespondenceAddress.FaxNo;
                kycData.APP_EMAIL = l_CorrespondenceAddress.EMailId;
            }

            if (l_SameCorrPermAdd)
            {
                kycData.APP_PER_ADD_FLAG = "Y";
            }
            else
            {
                kycData.APP_PER_ADD_FLAG = "N";

                if (l_RegisteredAddress != null)
                {

                    kycData.APP_PER_ADD1 = l_CorrespondenceAddress.AddressLine1;
                    kycData.APP_PER_ADD2 = l_CorrespondenceAddress.AddressLine2;
                    kycData.APP_PER_ADD3 = l_CorrespondenceAddress.AddressLine3;
                    kycData.APP_PER_CITY = l_CorrespondenceAddress.City;
                    kycData.APP_PER_PINCD = l_CorrespondenceAddress.PinCode;
                    kycData.APP_PER_STATE = GetRefData(l_CorrespondenceAddress.StateNumber);
                    kycData.APP_PER_CTRY = GetRefData(l_CorrespondenceAddress.CountryCode);

                }
            }

            kycData.APP_INCOME = GetRefData(client.GrAnnIncRange);
            kycData.APP_NETWRTH = client.NetWorth.HasValue == true ? client.NetWorth.Value : 0;

            if (client.GrAnnIncAsOnDate.HasValue)
                kycData.APP_NETWORTH_DT = this.DateToString(client.GrAnnIncAsOnDate.Value);

            kycData.APP_OCC = GetRefData(client.Occupation);
            kycData.APP_OTH_OCC = client.OccupationOthers;
            kycData.APP_DOB_INCORP = DateToString(client.DOB);
            kycData.APP_COMMENCE_DT = DateToString(client.CommOfBusiness);
      
            kycData.APP_COR_ADD_PROOF = client.KYCAdditionalDetail.ProofofCorrAddress;
        }


        private string DateToString(DateTime? dt)
        {
            if (dt.HasValue)
                return dt.Value.ToString(CVL.CVLConstants.DateFormat);
            return null;
        }


        #endregion


        public System.Data.DataTable VaildateRecords()
        {
            return null;
        }
    }
}
