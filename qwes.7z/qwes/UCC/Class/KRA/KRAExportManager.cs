﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using UCC.Class.Master;
using FTIL.Match.Common.Db;
using System.Data;
using FTIL.Match.Common;
using FTIL.Match.Common.Log;

namespace UCC.Class.KRA
{
    /// <summary>
    /// KRA filter details 
    /// </summary>
    struct KRAFilters
    {
        public string ClientCode{get;set;}
        public DateTime FromDate {get;set;}
        public DateTime ToDate {get;set;}
        public int Exchange {get;set;}
        public int BatchNo { get; set; }
        public KRAAgencyEnum KRAAgency { get; set; }
    }

    /// <summary>
    /// KRA Agency Enums
    /// </summary>
    public enum KRAAgencyEnum
    {
        CAMS = 1,
        CVL = 2,
        DOTEX = 3,
        KARVY = 4,
        NDML = 5
    }

    public enum KRAFileTypeEnum
    {
        INDIVIDUAL = 1,
        NON_INDIVIDUAL = 2,
        DEFAULT = -1
    }

    public struct ClientType
    {
        public static readonly char INDIVIDUAL = 'I';
        public static readonly char NON_INDIVIDUAL = 'N';
    }

    
    public struct IntermediaryID
    {
        public static readonly string DOTEX = "01";
        public static readonly string NDML = "03";
        public static readonly string CAMS = "03";
    }

    /// <summary>
    /// KRA Reference Type Enums
    /// </summary>
    public struct ReferenceType
    {
        public static readonly string PEP = "PEP";
        public static readonly string COUNTRY = "COUNTRY";
        public static readonly string STATE = "STATE";
        public static readonly string NATIONALTY = "NATIONALTY";
        
    }



    /// <summary>
    /// Class to dealing with Clients and generationg KRA File for filtered clients. 
    /// </summary>
    class KRAExportManager
    {
        
        #region Properties

        private List<CClient> KRAClients { get; set; }
        private IKRAProvider m_KRAProvider;
        private KRAAgencyEnum m_KRAAgencyEnum;

        #endregion

        /// <summary>
        /// Constructor intilizes KRA Client List
        /// </summary>
        /// <param name="clientsKRA">Clients will be added into KRA file</param>
        public KRAExportManager(List<CClient> clientsKRA)
        {
            this.KRAClients = clientsKRA;
        }


        /// <summary>
        /// Process KRA Client and validate 
        /// </summary>
        /// <param name="agenciesKRA">KRA Agency Enum</param>
        /// <returns>Datatable validation result</returns>
        public DataTable ProcessKRAClient(KRAAgencyEnum agenciesKRA)
        {
            m_KRAAgencyEnum = agenciesKRA;

            switch (m_KRAAgencyEnum)
            {
                case KRAAgencyEnum.NDML:
                    m_KRAProvider = new NDML.KRANSDLInterface();
                    break;
                case KRAAgencyEnum.KARVY:
                    m_KRAProvider = new Karvy.KarvyKRAProvider();
                    break;
                case KRAAgencyEnum.DOTEX:
                    m_KRAProvider = new Dotex.DotexKRAProvider();
                    break;
                case KRAAgencyEnum.CAMS:
                    m_KRAProvider = new Cams.CamsKRAProvider();
                    break;
                case KRAAgencyEnum.CVL:
                    m_KRAProvider = new CVL.CVLKRAProvider();
                    break;
            }

            m_KRAProvider.ProcessKRAClients(KRAClients);

            DataTable l_dtVaildationResult = m_KRAProvider.VaildateRecords();

            return l_dtVaildationResult;
        }
        
        /// <summary>
        /// Generate KRA Agency instance basis on passed KRA Agency Enum
        /// </summary>
        /// <param name="agenciesKRA">KRA Agency Enum</param>
        /// <param name="sExportFilesPath">KRA file export path</param>
        /// <returns></returns>
        public MethodExecResult ExportKRA(string fileDestinationPath)
        {

            MethodExecResult l_Result = new MethodExecResult(-1);
            StringBuilder l_sbGeneratedFileList = new StringBuilder();


            Dictionary<string, string> l_FileNameKRATextMap = m_KRAProvider.GetKRARecordsToText();

            if (l_FileNameKRATextMap == null || l_FileNameKRATextMap.Count == 0)
            {
                l_Result = new MethodExecResult(-1, "No valid data found for export.", "No valid data found for export.", null);
            }
            else
            {
                //Generate KRA file 
                //Dictionary key : KRA FileName ; Value : KRA text
                foreach (var kraFileItem in l_FileNameKRATextMap)
                {
                    l_Result = DownloadKRAFile(kraFileItem.Value, fileDestinationPath + kraFileItem.Key);
                    if (l_Result.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                        l_sbGeneratedFileList.AppendLine(kraFileItem.Key);
                }


                if (l_Result.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    l_Result = new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null,
                        "KRA file for agency " + Enum.GetName(typeof(KRAAgencyEnum), m_KRAAgencyEnum) +
                        " generated." + Environment.NewLine + "File Name(s) : " + Environment.NewLine + l_sbGeneratedFileList.ToString(), null);
                }
            }

            return l_Result;
        }


        /// <summary>
        /// Generate KRA file along with passed text 
        /// </summary>
        /// <param name="fileText">KRA File text</param>
        /// <param name="sExportPath">Full file path</param>
        /// <returns></returns>
        private FTIL.Match.Common.MethodExecResult DownloadKRAFile(string fileText, string sExportPath)
        {

            using (StreamWriter l_swKRAFile = new StreamWriter(sExportPath))
            {
                l_swKRAFile.Write(fileText);
                l_swKRAFile.Close();
            }

            return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, null, "SUCCESS", null);  
        }
    }
}
