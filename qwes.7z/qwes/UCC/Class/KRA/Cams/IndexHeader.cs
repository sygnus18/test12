﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UCC.Class.KRA.Cams
{
    /// <summary>
    /// Class For Cams Index file Header Record
    /// </summary>
    internal class IndexHeader
    {
        public IndexHeader()
        {
            RecordType = CamsRecordType.ConstCamsIndexHeader;
        }

        #region Public properties

        /// <summary>
        /// Record Type (Header or Detail) : Length = 2
        /// </summary>
        [DataField(Length = 2)]
        public string RecordType { get; set; }
        
        /// <summary>
        /// Batch Number : Length = 8
        /// </summary>
        [DataField(Length = 8)]
        public int BatchNumber { get; set; }

        /// <summary>
        /// IntermediaryID : Length = 5 : Optional
        /// </summary>
        [DataField(Length = 5)]
        public string IntermediaryID { get; set; }

        /// <summary>
        /// Total No of Detail Records : Length = 7
        /// </summary>
        [DataField(Length = 7)]
        public int DetailRecordsCount { get; set; }

        /// <summary>
        /// Filer : Length = 37 : Optional 
        /// </summary>
        [DataField(Length = 28)]
        public string Filler { get; set; }


        /// <summary>
        /// Join all properties with fix length value mentioned in DataField attribute [DataField]
        /// </summary>
        /// <returns>Joined string</returns>
        public override string ToString()
        {
            return Utility.JoinProperties(this);
        }

        #endregion

    }
}
