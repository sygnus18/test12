﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UCC.Class.KRA.Cams
{

    /// <summary>
    /// Image Type Enums 
    /// </summary>
    public enum CamsImageType
    {
        AllDocuments = 0,
        ProofOfIdentity = 1,
        ProofOfAddressCorrespondence = 2,
        ProofOfAddressPermanent = 3,
        KYCApplicationForm = 4,
        Photograph = 5,
        Signature = 6,
        Others = 999
    }

    /// <summary>
    /// Class for Cams Index file detail record
    /// </summary>
    class IndexDetail
    {
        public IndexDetail()
        {
            RecordType = CamsRecordType.ConstCamsIndexDetail;
        }

        private readonly string m_ConstDateTimeFormat = FTIL.Match.Common.Constants.Formatting.Instance.LONG_DATE_UNIVERSAL_FORMAT_PLAIN;


        /// <summary>
        /// Record Type (Header or Detail) : Length = 2
        /// </summary>
        [DataField(Length = 2)]
        public string RecordType { get; set; }

        /// <summary>
        /// Line Number 
        /// </summary>
        [DataField(Length = 7, PaddingCharacter='0')]
        public int LineNumber { get; set; }

        /// <summary>
        /// Acknowledgement Number
        /// </summary>
        [DataField(Length = 16)]
        public int AcknowledgementNumber { get; set; }

        /// <summary>
        /// PAN
        /// </summary>
        [DataField(Length = 10)]
        public string PAN { get; set; }

        /// <summary>
        /// Image Type
        /// </summary>
        [DataField(Length = 4,PaddingCharacter='O')]
        public int ImageType { get; set; }

        /// <summary>
        /// Image Name
        /// </summary>
        [DataField(Length = 50)]
        public string ImageName { get; set; }

        /// <summary>
        /// Filler
        /// </summary>
        [DataField(Length = 11)]
        public string Filler { get; set; }

        /// <summary>
        /// Image Upload Timestamp text format
        /// </summary>
        [DataField(Length = 14)]
        public string ImageUploadOnText
        {
            get
            {
                if (ImageUploadOn != null)
                    return ImageUploadOn.ToString(m_ConstDateTimeFormat);
                else return null;
            }
        }

        /// <summary>
        /// Image Upload Timestamp
        /// </summary>
        public DateTime ImageUploadOn { get; set; }
    }
}