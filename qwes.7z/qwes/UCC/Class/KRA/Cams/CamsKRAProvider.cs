﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using UCC.Class.Master;
using FTIL.Match.Common;

namespace UCC.Class.KRA.Cams
{

    public struct CamsRecordType
    {
        public static readonly string ConstCamsIndividualHeader = "01";
        public static readonly string ConstCamsIndividualDetail = "02";
        public static readonly string ConstCamsNonIndividualHeader = "03";
        public static readonly string ConstCamsNonIndividualDetail = "04";
        public static readonly string ConstCamsPromoterDetail = "05";
        public static readonly string ConstCamsIndexHeader = "06";
        public static readonly string ConstCamsIndexDetail = "07";
    }

    /// <summary>
    /// Generate KRA file for Cams KRA Agency (Enum Code : 5)
    /// File Type : Fix length file
    /// Type of records : Header and Detail
    /// </summary>
    public class CamsKRAProvider : BaseKRAProvider, IKRAProvider
    {

        #region Private Members fields

        private List<CamsIndividualDetail> m_CamsIndividualDetailRecords;
        private List<CamsNonIndividualDetail> m_CamsNonIndividualDetailRecords;

        /// <summary>
        /// Supported Gender List
        /// </summary>
        private static List<string> SupportedGenderList = new List<string> { "M", "F" };

        #endregion

        /// <summary>
        /// Initiate private members
        /// </summary>
        public CamsKRAProvider()
            : base(KRAAgencyEnum.CAMS)
        {
            m_CamsIndividualDetailRecords = new List<CamsIndividualDetail>();
            m_CamsNonIndividualDetailRecords = new List<CamsNonIndividualDetail>();
        }

        #region IKRAProvider Methods implementation

        /// <summary>
        /// Process Clients for KRA
        /// </summary>
        /// <param name="clients">Client List</param>
        /// <returns></returns>
        public FTIL.Match.Common.MethodExecResult ProcessKRAClients(List<CClient> clients)
        {

            clients.ForEach(client => this.AddDetailRecord(client));

            return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, "Success", "ProcessKRAClients() UserNo. " + AppEnvironment.AppUser.UserNo, null);

        }


        /// <summary>
        /// Validate detail records as per KRA file format
        /// </summary>
        /// <returns>DataTable of invalid fields</returns>
        public DataTable VaildateRecords()
        {
            IndividualDetailVaildCount = m_CamsIndividualDetailRecords.Count;
            NonIndividualDetailVaildCount = m_CamsNonIndividualDetailRecords.Count;

            foreach (CamsIndividualDetail detail in m_CamsIndividualDetailRecords)
            {
                ValidationResult l_objVresult = Utility.ValidateRecord(detail, ValidationGroup.RequiredField);
                detail.IsVaild = l_objVresult.IsValid;
                if (!detail.IsVaild)
                {
                    foreach (var field in l_objVresult.InvaildFields)
                    {
                        this.AddToValidationSummary(field.Value, detail.ClientInstance, field.Value + " is mandatory.");
                    }
                }

                detail.IsVaild = CompareValidate(detail.ClientInstance.PanExempt, "Y", detail.PANExemptionEvidence, "PANExemptionEvidence", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.ClientInstance.PanExempt, "N", detail.PAN, "PAN", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.Nationality, "99", detail.NationalityOther, "NationalityOther", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.ProofofIdentity, "99", detail.ProofofIdentiyOthers, "ProofofIdentiyOthers", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.CorrAddState, "99", detail.CorrAddStateOther, "CorrAddStateOther", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.ProofofAddressCorrAddress, "99", detail.ProofofAddressCorrAddressOther, "ProofofAddressCorrAddressOther", detail.ClientInstance, detail.IsVaild);

                detail.IsVaild = CompareValidate(detail.IsSameAsCorrespondence, "N", detail.PermanentAddress1, "PermanentAddress1", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.IsSameAsCorrespondence, "N", detail.PerAddPINCode, "PerAddPINCode", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.IsSameAsCorrespondence, "N", detail.PerAddState, "PerAddState", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.IsSameAsCorrespondence, "N", detail.PerAddCountry, "PerAddCountry", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.PerAddState, "99", detail.PerAddStateOther, "PerAddStateOther", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.ProofofPerAddress, "99", detail.ProofofPerAddressOther, "ProofofPerAddressOther", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.Occupation, "99", detail.OccupationDetails, "OccupationDetails", detail.ClientInstance, detail.IsVaild);

                // Old logic 
                /*
                string l_strNetWorth = (string.IsNullOrEmpty(Convert.ToString(detail.NetWorth)) || (detail.NetWorth == 0)) ? string.Empty : Convert.ToString(detail.NetWorth);
                string l_strGrossAnnualIncomeRange = string.IsNullOrEmpty(detail.GrossAnnualIncomeRange) ? string.Empty : detail.GrossAnnualIncomeRange;
                if (string.IsNullOrEmpty(l_strGrossAnnualIncomeRange))
                    detail.IsVaild = CompareValidate(l_strGrossAnnualIncomeRange, string.Empty, l_strNetWorth, "NetWorth", detail.ClientInstance, detail.IsVaild);

                if (!string.IsNullOrEmpty(l_strNetWorth))
                    detail.IsVaild = CompareValidate(!string.IsNullOrEmpty(l_strNetWorth) ? string.Empty : l_strNetWorth, string.Empty, detail.NetWorthOnDateText, "NetWorthOnDateText", detail.ClientInstance, detail.IsVaild);
            
                 */

                /********************************************************* Income validation ***************************************************************/
                detail.NetWorth = detail.NetWorth ?? 0;
                if (detail.NetWorth == 0)
                {
                    if (string.IsNullOrEmpty(detail.GrossAnnualIncomeRange))
                    {
                        detail.IsVaild = false;
                        this.AddToValidationSummary("GrossAnnualIncomeRange", detail.ClientInstance, "GrossAnnualIncomeRange is mandatory if NetWorth is not provided.");
                    }
                }
                else
                {
                    if (string.IsNullOrEmpty(detail.NetWorthOnDateText))
                    {
                        detail.IsVaild = false;
                        this.AddToValidationSummary("NetWorthOnDate", detail.ClientInstance, "NetWorthAsOnDate is mandatory if NetWorth is provided.");
                    }
                }
                /*****************************************************************************************************************************************/


                /***************************************************** Gender validation *****************************************************************/
                if (!SupportedGenderList.Contains(detail.Gender))
                {
                    detail.IsVaild = false;
                    this.AddToValidationSummary("Gender", detail.ClientInstance, "Invaild Gender {" + detail.Gender + "}.");
                }
                /*****************************************************************************************************************************************/

     
                if (!detail.IsVaild)
                    --IndividualDetailVaildCount;
            }



            foreach (CamsNonIndividualDetail detail in m_CamsNonIndividualDetailRecords)
            {
                ValidationResult l_objVresult = Utility.ValidateRecord(detail, ValidationGroup.RequiredField);
                detail.IsVaild = l_objVresult.IsValid;
                if (!detail.IsVaild)
                {
                    foreach (var field in l_objVresult.InvaildFields)
                    {
                        this.AddToValidationSummary(field.Value, detail.ClientInstance, field.Value + " is mandatory.");
                    }
                }

                detail.IsVaild = CompareValidate(detail.ClientInstance.PanExempt, "Y", detail.PANExemptionEvidence, "PANExemptionEvidence", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.ClientInstance.PanExempt, "N", detail.PAN, "PAN", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.Status, "99", detail.StatusOther, "StatusOther", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.CorrAddState, "99", detail.CorrAddStateOther, "CorrAddStateOther", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.ProofofAddressCorrAddress, "99", detail.ProofofAddressCorrAddressOther, "ProofofAddressCorrAddressOther", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.IsSameAsCorrespondence, "N", detail.RegisteredAddress1, "RegisteredAddress1", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.IsSameAsCorrespondence, "N", detail.RegAddPINCode, "RegAddPINCode", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.IsSameAsCorrespondence, "N", detail.RegAddState, "RegAddState", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.IsSameAsCorrespondence, "N", detail.RegAddCountry, "RegAddCountry", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.RegAddState, "99", detail.RegAddStateOther, "RegAddStateOther", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.ProofofRegAddress, "99", detail.ProofofRegAddressOther, "ProofofRegAddressOther", detail.ClientInstance, detail.IsVaild);


                foreach (PromoterDetail pDetail in detail.PromoterDetailList)
                {
                    ValidationResult l_objVresultPromoDetail = Utility.ValidateRecord(pDetail, ValidationGroup.RequiredField);

                    pDetail.IsVaild = l_objVresultPromoDetail.IsValid;

                    if (!pDetail.IsVaild)
                    {
                        detail.IsVaild = false;

                        foreach (var field in l_objVresultPromoDetail.InvaildFields)
                        {
                            this.AddToValidationSummary(field.Value, detail.ClientInstance, field.Value + " is mandatory in Promoter Detail section.");
                        }
                    }
                    pDetail.IsVaild = CompareValidate(detail.ClientInstance.PanExempt, "Y", pDetail.PANExemptionEvidence, "PANExemptionEvidence (Promoter Detail)", detail.ClientInstance, pDetail.IsVaild);
                    pDetail.IsVaild = CompareValidate(pDetail.RelationshipWithApplicant, "99", pDetail.RelationshipWithApplicantOther, "RelationshipWithApplicantOther", detail.ClientInstance, pDetail.IsVaild);
                    pDetail.IsVaild = CompareValidate(pDetail.RegAddState, "99", pDetail.RegAddStateOther, "RegAddStateOther (Promoter Detail)", detail.ClientInstance, pDetail.IsVaild);

                    if (detail.IsVaild)
                        detail.IsVaild = pDetail.IsVaild;

                    pDetail.IsVaild = detail.IsVaild;

                }

                if (!detail.IsVaild)
                    --NonIndividualDetailVaildCount;

            }

            return this.DtValidationResult;
        }




        /// <summary>
        /// Generate KRA text data form Header and Detail records
        /// </summary>
        /// <returns>KRA text data which will be write into the KRA file</returns>
        public Dictionary<string, string> GetKRARecordsToText()
        {
            if ((IndividualDetailVaildCount == 0) && (NonIndividualDetailVaildCount == 0))
            {
                return new Dictionary<string,string>();
            }

            Dictionary<string, string> l_DicFileNameKRAText = new Dictionary<string, string>();

            string l_sIndivFileName = "CAMS_I_" + DateTime.Now.ToString("yyyyMMdd") + "_S001.txt";
            string l_sNonIndivFileName = "CAMS_NI_" + DateTime.Now.ToString("yyyyMMdd") + "_S001.txt";

            StringBuilder sb = new StringBuilder();

            CamsHeader obj_HeaderRecord = new CamsHeader();
            obj_HeaderRecord.IntermediaryID = IntermediaryID.CAMS;

            //INDIVIDUAL
            if (IndividualDetailVaildCount > 0)
            {
                obj_HeaderRecord.RecordType = CamsRecordType.ConstCamsIndividualHeader;
                obj_HeaderRecord.DetailRecordsCount = IndividualDetailVaildCount;
                sb.AppendLine(obj_HeaderRecord.ToString());

                foreach (CamsIndividualDetail detailRecord in m_CamsIndividualDetailRecords)
                {
                    if (detailRecord.IsVaild)
                    {
                        detailRecord.LineNumber = NextLineNumber;
                        sb.AppendLine(detailRecord.ToString());
                    }
                }

                l_DicFileNameKRAText.Add(l_sIndivFileName, sb.ToString());
            }

            if (NonIndividualDetailVaildCount > 0)
            {
                sb.Remove(0, sb.Length);
                sb = new StringBuilder(string.Empty);

                //NON INDIVIDUAL
                obj_HeaderRecord.DetailRecordsCount = NonIndividualDetailVaildCount;
                obj_HeaderRecord.RecordType = CamsRecordType.ConstCamsNonIndividualHeader;
                sb.AppendLine(obj_HeaderRecord.ToString());

                //Reseting LineNo
                ResetLineNumber();

                foreach (CamsNonIndividualDetail detailRecord in m_CamsNonIndividualDetailRecords)
                {
                    if (detailRecord.IsVaild)
                    {
                        detailRecord.LineNumber = NextLineNumber;
                        sb.AppendLine(detailRecord.ToString());
                    }
                }

                //Adding Promoter Details
                foreach (CamsNonIndividualDetail detailRecord in m_CamsNonIndividualDetailRecords)
                {
                    if (detailRecord.IsVaild)
                    {
                        foreach (PromoterDetail promoter in detailRecord.PromoterDetailList)
                        {
                            if (promoter.IsVaild)
                            {
                                promoter.LineNumber = NextLineNumber;
                                sb.AppendLine(promoter.ToString());
                            }
                        }
                    }
                }

                l_DicFileNameKRAText.Add(l_sNonIndivFileName, sb.ToString());
            }

            return l_DicFileNameKRAText;
        }

        #endregion


        #region Private Methods


        /// <summary>
        /// Add record as individual detail 
        /// </summary>
        /// <param name="client"></param>
        private void AddIndividualDetail(CClient client)
        {

            CAddress l_CorrespondenceAddress = client.ClientAddresses.GetAddressByType(AddressTypeEnum.Correspondence);
            CAddress l_RegisteredAddress = client.ClientAddresses.GetAddressByType(AddressTypeEnum.Registered);


            if (l_CorrespondenceAddress == null)
            {
                this.AddToValidationSummary("CorrespondenceAddress", client, "Correspondence adderess is mandatory.");
                return;
            }
            if (l_RegisteredAddress == null && l_CorrespondenceAddress.SameCorrPermAdd != "Y")
            {
                this.AddToValidationSummary("RegisteredAddress", client, "Register address is mandatory.");
                return;
            }

            bool l_SameCorrPermAdd = false;

            CamsIndividualDetail l_ObjDetail = new CamsIndividualDetail(client);

            l_ObjDetail.ApplicantName = client.ClientName;
            l_ObjDetail.Father_HusbandName = client.GuardianName;
            l_ObjDetail.Gender = client.Gender;
            l_ObjDetail.Maritalstatus = client.MaritalStatus;

            if (client.DOB.HasValue)
                l_ObjDetail.DateofBirth = client.DOB.Value;

            l_ObjDetail.PAN = client.PANNo;
            l_ObjDetail.PANExemptionEvidence = client.PanExempt == "Y" ? client.KYCAdditionalDetail.PANExemptionEvidence : null;

            //l_ObjDetail.Nationality = client.Nationality.HasValue == true ? client.Nationality.Value.ToString() : null;
            l_ObjDetail.Nationality = GetRefDataByRefCode(Convert.ToString(client.Nationality), ReferenceType.NATIONALTY);
            l_ObjDetail.NationalityOther = client.NationalityOther;

            l_SameCorrPermAdd = l_CorrespondenceAddress.SameCorrPermAdd == "Y" ? true : false;
            l_ObjDetail.IsSameAsCorrespondence = l_SameCorrPermAdd == true ? "Y" : "N";

            l_ObjDetail.CorrespondenceAddress1 = l_CorrespondenceAddress.AddressLine1;
            l_ObjDetail.CorrespondenceAddress2 = l_CorrespondenceAddress.AddressLine2;
            l_ObjDetail.CorrespondenceAddress3 = l_CorrespondenceAddress.AddressLine3;
            l_ObjDetail.CorrAddCity = l_CorrespondenceAddress.City;
            l_ObjDetail.CorrAddPINCode = l_CorrespondenceAddress.PinCode;
            l_ObjDetail.CorrAddState = GetRefDataByRefCode(Convert.ToString(l_CorrespondenceAddress.StateNumber), ReferenceType.STATE);
            l_ObjDetail.CorrAddStateOther = l_CorrespondenceAddress.StateOther;
            l_ObjDetail.CorrAddCountry = GetRefDataByRefCode(Convert.ToString(l_CorrespondenceAddress.CountryCode), ReferenceType.COUNTRY);

            if (l_SameCorrPermAdd)
            {
                l_ObjDetail.PermanentAddress1 = l_CorrespondenceAddress.AddressLine1;
                l_ObjDetail.PermanentAddress2 = l_CorrespondenceAddress.AddressLine2;
                l_ObjDetail.PermanentAddress3 = l_CorrespondenceAddress.AddressLine3;
                l_ObjDetail.PerAddCity = l_CorrespondenceAddress.City;
                l_ObjDetail.PerAddPINCode = l_CorrespondenceAddress.PinCode;
                l_ObjDetail.PerAddState = GetRefDataByRefCode(Convert.ToString(l_CorrespondenceAddress.StateNumber), ReferenceType.STATE);
                l_ObjDetail.PerAddStateOther = l_CorrespondenceAddress.StateOther;
                l_ObjDetail.PerAddCountry = GetRefDataByRefCode(Convert.ToString(l_CorrespondenceAddress.CountryCode), ReferenceType.COUNTRY);
                l_ObjDetail.UID = l_CorrespondenceAddress.UID;
                l_ObjDetail.TelOffice = l_CorrespondenceAddress.TelNoOffice;
                l_ObjDetail.TelRes = l_CorrespondenceAddress.TelNo1;
                l_ObjDetail.MobileNo = l_CorrespondenceAddress.Mobile1;
                l_ObjDetail.FaxNo = l_CorrespondenceAddress.FaxNo;
                l_ObjDetail.EmailID = l_CorrespondenceAddress.EMailId;
            }
            else
            {
                l_ObjDetail.PermanentAddress1 = l_RegisteredAddress.AddressLine1;
                l_ObjDetail.PermanentAddress2 = l_RegisteredAddress.AddressLine2;
                l_ObjDetail.PermanentAddress3 = l_RegisteredAddress.AddressLine3;
                l_ObjDetail.PerAddCity = l_RegisteredAddress.City;
                l_ObjDetail.PerAddPINCode = l_RegisteredAddress.PinCode;
                l_ObjDetail.PerAddState = GetRefDataByRefCode(Convert.ToString(l_RegisteredAddress.StateNumber), ReferenceType.STATE);
                l_ObjDetail.PerAddStateOther = l_RegisteredAddress.StateOther;
                l_ObjDetail.PerAddCountry = GetRefDataByRefCode(Convert.ToString(l_RegisteredAddress.CountryCode), ReferenceType.COUNTRY);
                l_ObjDetail.UID = l_RegisteredAddress.UID;
                l_ObjDetail.TelOffice = l_RegisteredAddress.TelNoOffice;
                l_ObjDetail.TelRes = l_RegisteredAddress.TelNo1;
                l_ObjDetail.MobileNo = l_RegisteredAddress.Mobile1;
                l_ObjDetail.FaxNo = l_RegisteredAddress.FaxNo;
                l_ObjDetail.EmailID = l_RegisteredAddress.EMailId;
            }
            
            l_ObjDetail.GrossAnnualIncomeRange = GetRefData(client.GrAnnIncRange);
            l_ObjDetail.NetWorth = client.NetWorth.HasValue == true ? client.NetWorth.Value : 0;
            l_ObjDetail.NetWorthOnDate = client.NetWorthAsOnDate;

            if (client.GrAnnIncAsOnDate.HasValue && string.IsNullOrEmpty(l_ObjDetail.GrossAnnualIncomeRange) == false)
            {
                l_ObjDetail.DeclarationDate = client.GrAnnIncAsOnDate;
            }
            else if (client.NetWorthAsOnDate.HasValue && l_ObjDetail.NetWorth > 0)
            {
                l_ObjDetail.DeclarationDate = client.NetWorthAsOnDate.Value;
            }

            l_ObjDetail.Occupation = GetRefData(client.Occupation);
            l_ObjDetail.OccupationDetails = client.OccupationOthers;

            l_ObjDetail.ClientUpdationDate = client.LastModifiedDateTime;

            if (client.KYCAdditionalDetail.KYCActiveDate.HasValue)
                l_ObjDetail.DocumentReceivedOn = client.KYCAdditionalDetail.KYCActiveDate.Value;

            l_ObjDetail.DocumentsCount = client.KYCAdditionalDetail.DocumentsCount;

          //  l_ObjDetail.Father_HusbandName = client.KYCAdditionalDetail.Father_HusbandName;

            l_ObjDetail.IntermediaryBranchCode = client.KYCAdditionalDetail.IntermediaryBranchCode;

            l_ObjDetail.IPVDate = client.KYCAdditionalDetail.IPVDate;

            l_ObjDetail.IPVPersonDesignation = client.KYCAdditionalDetail.IPVPersonDesignation;

            l_ObjDetail.KYCStatus = client.KYCAdditionalDetail.KYCRequestStatus;

            //TODO:
            l_ObjDetail.RequestStatusChangeOn = client.LastModifiedDateTime;

            l_ObjDetail.ProofofAddressCorrAddress = client.KYCAdditionalDetail.ProofofCorrAddress;

            l_ObjDetail.ProofofAddressCorrAddressOther = client.KYCAdditionalDetail.ProofofCorrAddressOther;

            l_ObjDetail.ProofofIdentity = client.KYCAdditionalDetail.ProofOfIdentity;
            l_ObjDetail.ProofofIdentiyOthers = client.KYCAdditionalDetail.ProofofIdentityOther;

            l_ObjDetail.ProofofPerAddress = client.KYCAdditionalDetail.ProofofPerAddress;

            l_ObjDetail.ProofofPerAddressOther = client.KYCAdditionalDetail.ProofofPerAddressOther;

            l_ObjDetail.Remarks1 = client.KYCAdditionalDetail.KRARemark;

            l_ObjDetail.SelfAttestedReceived = "Y";
            l_ObjDetail.VerifiedCopiesReceived = "Y";

            l_ObjDetail.SenderRefNo1 = client.KYCAdditionalDetail.SenderRefNo1;
            l_ObjDetail.SenderRefNo2 = client.KYCAdditionalDetail.SenderRefNo2;
            l_ObjDetail.AcknowledgementNumber = client.ClientCode;

            l_ObjDetail.Status = client.KYCAdditionalDetail.ClientStatus;
            l_ObjDetail.PEP = GetRefDataByRefCode(Convert.ToString(client.PEP), ReferenceType.PEP);


            if (client.ClientActivationDate.HasValue)
                l_ObjDetail.ClientActivationDate = client.ClientActivationDate.Value;


            l_ObjDetail.IPVFlag = client.KYCAdditionalDetail.IPVFlag.ToString();
            l_ObjDetail.IPVPersonName = client.KYCAdditionalDetail.VerifierName;
            l_ObjDetail.IPVOrganization = client.KYCAdditionalDetail.CompanyName;



            //Add into DetailRecords list
            m_CamsIndividualDetailRecords.Add(l_ObjDetail);
        }



        /// <summary>
        /// Add record as non-individual detail 
        /// </summary>
        /// <param name="client"></param>
        private void AddNonIndividualDetail(CClient client)
        {

            CAddress l_CorrespondenceAddress = client.ClientAddresses.GetAddressByType(AddressTypeEnum.Correspondence);
            CAddress l_RegisteredAddress = client.ClientAddresses.GetAddressByType(AddressTypeEnum.Registered);

            if (l_CorrespondenceAddress == null)
            {
                this.AddToValidationSummary("CorrespondenceAddress", client, "Correspondence adderess is mandatory.");
                return;
            }
            if (l_RegisteredAddress == null && l_CorrespondenceAddress.SameCorrPermAdd != "Y")
            {
                this.AddToValidationSummary("RegisteredAddress", client, "Register address is mandatory.");
                return;
            }

            bool l_SameCorrPermAdd = false;

            CamsNonIndividualDetail l_ObjDetail = new CamsNonIndividualDetail(client);

            l_ObjDetail.ApplicantName = client.ClientName;

            l_ObjDetail.PAN = client.PANNo;

            if (client.DOB.HasValue)
                l_ObjDetail.DateofIncorporation = client.DOB.Value;

            l_ObjDetail.PlaceOfIncorporation = client.PlaceofIncorporation;

            if (client.CommOfBusiness.HasValue)
                l_ObjDetail.BusinessCommencementDate = client.CommOfBusiness.Value;

            l_ObjDetail.RegistrationNo = client.CorporateIdNo;

            if (l_CorrespondenceAddress != null)
            {
                l_SameCorrPermAdd = l_CorrespondenceAddress.SameCorrPermAdd == "Y" ? true : false;
                l_ObjDetail.CorrespondenceAddress1 = l_CorrespondenceAddress.AddressLine1;
                l_ObjDetail.CorrespondenceAddress2 = l_CorrespondenceAddress.AddressLine2;
                l_ObjDetail.CorrespondenceAddress3 = l_CorrespondenceAddress.AddressLine3;
                l_ObjDetail.CorrAddCity = l_CorrespondenceAddress.City;
                l_ObjDetail.CorrAddPINCode = l_CorrespondenceAddress.PinCode;
                l_ObjDetail.CorrAddState = GetRefDataByRefCode(Convert.ToString(l_CorrespondenceAddress.StateNumber), ReferenceType.STATE);
                l_ObjDetail.CorrAddStateOther = l_CorrespondenceAddress.StateOther;
                l_ObjDetail.CorrAddCountry = GetRefDataByRefCode(Convert.ToString(l_CorrespondenceAddress.CountryCode), ReferenceType.COUNTRY);
            }

            l_ObjDetail.IsSameAsCorrespondence = l_SameCorrPermAdd == true ? "Y" : "N";

            if (l_SameCorrPermAdd)
            {
                l_ObjDetail.RegisteredAddress1 = l_CorrespondenceAddress.AddressLine1;
                l_ObjDetail.RegisteredAddress2 = l_CorrespondenceAddress.AddressLine2;
                l_ObjDetail.RegisteredAddress3 = l_CorrespondenceAddress.AddressLine3;
                l_ObjDetail.RegAddCity = l_CorrespondenceAddress.City;
                l_ObjDetail.RegAddPINCode = l_CorrespondenceAddress.PinCode;
                l_ObjDetail.RegAddState = GetRefDataByRefCode(Convert.ToString(l_CorrespondenceAddress.StateNumber), ReferenceType.STATE);
                l_ObjDetail.RegAddStateOther = l_CorrespondenceAddress.StateOther;
                l_ObjDetail.RegAddCountry = GetRefDataByRefCode(Convert.ToString(l_CorrespondenceAddress.CountryCode), ReferenceType.COUNTRY);
                l_ObjDetail.TelOffice = l_CorrespondenceAddress.TelNoOffice;
                l_ObjDetail.TelRes = l_CorrespondenceAddress.TelNo1;
                l_ObjDetail.MobileNo = l_CorrespondenceAddress.Mobile1;
                l_ObjDetail.FaxNo = l_CorrespondenceAddress.FaxNo;
                l_ObjDetail.EmailID = l_CorrespondenceAddress.EMailId;
            }
            else
            {
                l_ObjDetail.RegisteredAddress1 = l_RegisteredAddress.AddressLine1;
                l_ObjDetail.RegisteredAddress2 = l_RegisteredAddress.AddressLine2;
                l_ObjDetail.RegisteredAddress3 = l_RegisteredAddress.AddressLine3;
                l_ObjDetail.RegAddCity = l_RegisteredAddress.City;
                l_ObjDetail.RegAddPINCode = l_RegisteredAddress.PinCode;
                l_ObjDetail.RegAddState = GetRefDataByRefCode(Convert.ToString(l_RegisteredAddress.StateNumber), ReferenceType.STATE);
                l_ObjDetail.RegAddStateOther = l_RegisteredAddress.StateOther;
                l_ObjDetail.RegAddCountry = GetRefDataByRefCode(Convert.ToString(l_RegisteredAddress.CountryCode), ReferenceType.COUNTRY);
                l_ObjDetail.TelOffice = l_RegisteredAddress.TelNoOffice;
                l_ObjDetail.TelRes = l_RegisteredAddress.TelNo1;
                l_ObjDetail.MobileNo = l_RegisteredAddress.Mobile1;
                l_ObjDetail.FaxNo = l_RegisteredAddress.FaxNo;
                l_ObjDetail.EmailID = l_RegisteredAddress.EMailId;
            }


            l_ObjDetail.GrossAnnualIncomeRange = GetRefData(client.GrAnnIncRange);
            l_ObjDetail.NetWorth = client.NetWorth.HasValue == true ? client.NetWorth.Value : 0;
            l_ObjDetail.NetWorthOnDate = client.NetWorthAsOnDate;

            if (client.NetWorthAsOnDate.HasValue && l_ObjDetail.NetWorth > 0)
            {
                l_ObjDetail.DeclarationDate = client.NetWorthAsOnDate.Value;
            }
            else if (client.GrAnnIncAsOnDate.HasValue && string.IsNullOrEmpty(l_ObjDetail.GrossAnnualIncomeRange) == false)
            {
                l_ObjDetail.DeclarationDate = client.GrAnnIncAsOnDate;
            }

            l_ObjDetail.ClientUpdationDate = client.LastModifiedDateTime;


            if (client.KYCAdditionalDetail.KYCActiveDate.HasValue)
                l_ObjDetail.DocumentReceivedOn = client.KYCAdditionalDetail.KYCActiveDate.Value;

            l_ObjDetail.DocumentsCount = client.KYCAdditionalDetail.DocumentsCount;

            l_ObjDetail.IntermediaryBranchCode = client.KYCAdditionalDetail.IntermediaryBranchCode;

            l_ObjDetail.IPVDate = client.KYCAdditionalDetail.IPVDate;

            l_ObjDetail.IPVPersonDesignation = client.KYCAdditionalDetail.IPVPersonDesignation;

            l_ObjDetail.KYCStatus = client.KYCAdditionalDetail.KYCRequestStatus;

            //TODO:
            l_ObjDetail.RequestStatusChangeOn = client.LastModifiedDateTime;

            l_ObjDetail.ProofofAddressCorrAddress = client.KYCAdditionalDetail.ProofofCorrAddress;
            l_ObjDetail.ProofofRegAddress = client.KYCAdditionalDetail.ProofofPerAddress;

            l_ObjDetail.ProofofAddressCorrAddressOther = client.KYCAdditionalDetail.ProofofCorrAddressOther;

            l_ObjDetail.Remarks1 = client.KYCAdditionalDetail.KRARemark;

            l_ObjDetail.SelfAttestedReceived = "Y";
            l_ObjDetail.VerifiedCopiesReceived = "Y";


            l_ObjDetail.SenderRefNo1 = client.KYCAdditionalDetail.SenderRefNo1;
            l_ObjDetail.SenderRefNo2 = client.KYCAdditionalDetail.SenderRefNo2;
            l_ObjDetail.AcknowledgementNumber = client.ClientCode;

            l_ObjDetail.Status = client.KYCAdditionalDetail.ClientStatus;
            l_ObjDetail.StatusOther = client.KYCAdditionalDetail.StatusOther;

            l_ObjDetail.PEP = GetRefDataByRefCode(Convert.ToString(client.PEP), ReferenceType.PEP);

            if (client.ClientActivationDate.HasValue)
                l_ObjDetail.ClientActivationDate = client.ClientActivationDate.Value;


            l_ObjDetail.PANExemptionEvidence = client.PanExempt == "Y" ? client.KYCAdditionalDetail.PANExemptionEvidence : null;

            l_ObjDetail.IPVFlag = client.KYCAdditionalDetail.IPVFlag.ToString();
            l_ObjDetail.IPVPersonName = client.KYCAdditionalDetail.VerifierName;
            l_ObjDetail.IPVOrganization = client.KYCAdditionalDetail.CompanyName;


           //************************************************Add Promoter details ****************************************************// 
           
            //Get contact person's addresses from address collection
            List<CAddress> l_ContactPersonAddressCollection = client.ClientAddresses.GetAddressesByType(AddressTypeEnum.ContactPerson);

            if (l_ContactPersonAddressCollection.Exists(item => item.Director == "Y") == false)
            {
                this.AddToValidationSummary("Director", client, "No Director found in Promoter Detail/Contact Person Addresses.");
                return;
            }

            if (l_ContactPersonAddressCollection != null && l_ContactPersonAddressCollection.Count > 0)
            {
                foreach (CAddress addr in l_ContactPersonAddressCollection)
                {
                    PromoterDetail l_ObjPromter = new PromoterDetail();

                    if (addr.Director == "Y")
                    {
                        l_ObjPromter.Name = addr.DIN;
                        l_ObjPromter.RelationshipWithApplicant = "05";
                    }
                    else
                    {
                        l_ObjPromter.Name = addr.ContactPerson;
                        l_ObjPromter.RelationshipWithApplicant = "99";
                        l_ObjPromter.RelationshipWithApplicantOther = addr.Designation;
                    }

                    l_ObjPromter.NonIndividualPAN = l_ObjDetail.PAN;
                    l_ObjPromter.PANExemptionEvidence = l_ObjDetail.PANExemptionEvidence;
                    l_ObjPromter.PANPromoter = addr.PANNo;
                    l_ObjPromter.RegAddCity = addr.City;
                    l_ObjPromter.RegisteredAddress1 = addr.AddressLine1;
                    l_ObjPromter.RegisteredAddress2 = addr.AddressLine2;
                    l_ObjPromter.RegisteredAddress3 = addr.AddressLine3;
                    l_ObjPromter.RegAddCity = addr.City;
                    l_ObjPromter.RegAddPINCode = addr.PinCode;
                    l_ObjPromter.RegAddState = GetRefDataByRefCode(Convert.ToString(addr.StateNumber), ReferenceType.STATE);
                    l_ObjPromter.RegAddStateOther = addr.StateOther;
                    l_ObjPromter.RegAddCountry = GetRefDataByRefCode(Convert.ToString(addr.CountryCode), ReferenceType.COUNTRY);
                    l_ObjPromter.UID = string.IsNullOrEmpty(addr.DIN) ? addr.UID : addr.DIN; 
                    l_ObjPromter.AcknowledgementNumber = client.ClientCode;
                    l_ObjDetail.PromoterDetailList.Add(l_ObjPromter);
                }
            }
            else
            {
                this.AddToValidationSummary("PromoterDetail", client, "No Promoter Detail/Contact Person Address found.");
                return;
            }
            //**************************************************************************************************************************//


            //Add into DetailRecords list
            m_CamsNonIndividualDetailRecords.Add(l_ObjDetail);
        }

        /// <summary>
        /// Set all properties for detail record object
        /// </summary>
        /// <param name="client">KRA Client</param>
        private void AddDetailRecord(CClient client)
        {

            if (client.ClientType == ClientType.INDIVIDUAL)
                this.AddIndividualDetail(client);
            else if (client.ClientType == ClientType.NON_INDIVIDUAL)
                this.AddNonIndividualDetail(client);
            else
            {
                this.AddToValidationSummary("ClientType", client, "Invalid Client Type {" + client.ClientType.ToString() + "}");
                return;
            }
        }

        #endregion

    }
}

