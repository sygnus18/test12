﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UCC.Class.KRA.Cams
{
    /// <summary>
    /// Class For Cams Header Record
    /// </summary>
    internal class CamsHeader
    {
        public CamsHeader()
        {
            m_CreationDateTime = DateTime.Now;
        }


        private DateTime m_CreationDateTime;

        private readonly string m_ConstDateFormat = FTIL.Match.Common.Constants.Formatting.Instance.SHORT_DATE_UNIVERSAL_FORMAT_PLAIN;
        private readonly string m_ConstTimeFormat = "HHmmss";


        #region Public properties

        /// <summary>
        /// Record Type (Header or Detail) : Length = 2
        /// </summary>
        [DataField(Length = 2)]
        public string RecordType { get; set; }

        /// <summary>
        /// IntermediaryID : Length = 5 : Optional
        /// </summary>
        [DataField(Length = 5)]
        public string IntermediaryID { get; set; }


        /// <summary>
        /// Filler
        /// </summary>
        [DataField(Length = 15)]
        public string Filler { get; set; }


        /// <summary>
        /// Date of Download : Length = 8
        /// </summary>
        [DataField(Length = 8)]
        public string ExportDownloadDate
        {
            get
            {
                return m_CreationDateTime.ToString(m_ConstDateFormat);
            }
        }

        /// <summary>
        /// Export Time : Length = 6
        /// </summary>
        [DataField(Length = 6)]
        public string ExportDownloadTime
        {
            get
            {
                return m_CreationDateTime.ToString(m_ConstTimeFormat);
            }
        }

        /// <summary>
        /// Total No of Detail Records : Length = 7
        /// </summary>
        [DataField(Length = 7)]
        public int DetailRecordsCount { get; set; }

        /// <summary>
        /// Filer : Length = 37 : Optional 
        /// </summary>
        [DataField(Length = 37)]
        public string Filler1 { get; set; }


        /// <summary>
        /// Join all properties with fix length value mentioned in DataField attribute [DataField]
        /// </summary>
        /// <returns>Joined string</returns>
        public override string ToString()
        {
            return Utility.JoinProperties(this);
        }

        #endregion

    }
}
