﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using UCC.Class.Master;

namespace UCC.Class.KRA
{
    /// <summary>
    /// Base class for all KRA providers for common logic
    /// </summary>
    public class BaseKRAProvider
    {
        private CKRAReferenceDataProvider m_RefDataProvider;
        private KRAAgencyEnum m_KRAAgencies;

        private DataTable m_dtValidationResult;

        private int m_LineNumber;


        /// <summary>
        /// Constructor : Set base properties 
        /// </summary>
        /// <param name="kraAgencyEnum">KRA Agency Enum</param>
        public BaseKRAProvider(KRAAgencyEnum kraAgencyEnum)
        {
            m_RefDataProvider = CKRAReferenceDataProvider.Instance;
            m_KRAAgencies = kraAgencyEnum;

            m_dtValidationResult = new DataTable("ValidationResult");
            m_dtValidationResult.Columns.Add("ClientCode");
            m_dtValidationResult.Columns.Add("FieldName");
            m_dtValidationResult.Columns.Add("Error");

        }

        /// <summary>
        /// Get Reference data for KRA
        /// </summary>
        /// <param name="nUCCRefNo">Reference No</param>
        /// <returns>Reference code</returns>
        protected string GetRefData(int nUCCRefNo)
        {
            CKRAReferenceData l_refData = m_RefDataProvider[m_KRAAgencies, nUCCRefNo];

            if (l_refData == null) return string.Empty;

            return l_refData.SRefCode;
        }

        /// <summary>
        /// Get Reference data for KRA
        /// </summary>
        /// <param name="nUCCRefNo">Reference No</param>
        /// <returns>Reference code</returns>
        protected string GetRefData(int? nUCCRefNo)
        {
            if (nUCCRefNo == null) return string.Empty;

            CKRAReferenceData l_refData = null;

            if(nUCCRefNo.HasValue)
                l_refData = m_RefDataProvider[m_KRAAgencies, nUCCRefNo.Value];

            if (l_refData == null) return string.Empty;

            return l_refData.SRefCode;
        }

        /// <summary>
        /// Get Reference data for KRA
        /// </summary>
        /// <param name="nUCCRefNo">Reference No</param>
        /// <returns>Reference code</returns>
        protected string GetRefDataByRefCode(string sRefCode, string RefType)
        {
            CKRAReferenceData l_refData = null;

            l_refData = m_RefDataProvider[m_KRAAgencies, sRefCode, RefType];

            if (l_refData == null) return string.Empty;

            return l_refData.SRefCode;
        }



        /// <summary>
        /// Get Validation Summary 
        /// </summary>
        protected DataTable DtValidationResult
        {
            get { return m_dtValidationResult; }
            set { m_dtValidationResult = value; }
        }

        /// <summary>
        /// Add validation entry for the field
        /// </summary>
        /// <param name="fieldName">Name of the field</param>
        /// <param name="client">Master Client Object</param>
        /// <param name="messeage">Error message</param>
        protected void AddToValidationSummary(string fieldName, CClient client, string messeage)
        {
                m_dtValidationResult.Rows.Add(client.ClientCode, fieldName, messeage);
        }


        /// <summary>
        /// Compare two value to validate third value is requird or not
        /// </summary>
        /// <param name="sLHSValue">First Value</param>
        /// <param name="sRHSValue">Second value</param>
        /// <param name="sourceValue">Value to be validate</param>
        /// <param name="fieldName">Name of the field/colum</param>
        /// <param name="client">Client Master Object</param>
        /// <param name="isValid">Flag to determine value is valid or not</param>
        /// <returns>Return false if value is not vaild</returns>
        protected bool CompareValidate(string sLHSValue, string sRHSValue, string sourceValue, string fieldName, CClient client, bool isValid)
        {

            //if (string.IsNullOrEmpty(sLHSValue))
            //    return false;

            if (string.Equals(sLHSValue, sRHSValue, StringComparison.OrdinalIgnoreCase) == true && string.IsNullOrEmpty(sourceValue))
            {
                this.AddToValidationSummary(fieldName, client, fieldName + " is mandatory");
                return false;
            }

            return isValid;
        }

        /// <summary>
        /// get Next Line Number
        /// </summary>
        protected int NextLineNumber
        {
            get
            {
                ++m_LineNumber;
                return m_LineNumber;
            }
        }

        /// <summary>
        /// Reset the line Number
        /// </summary>
        protected void ResetLineNumber() 
        {
            m_LineNumber = 0;
        }


        /// <summary>
        /// vaild detail record count for Individual
        /// </summary>
        protected int IndividualDetailVaildCount { get; set; }


        /// <summary>
        /// vaild detail record count for NonIndividual
        /// </summary>
        protected int NonIndividualDetailVaildCount { get; set; }

    }
}
