﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UCC.Class.KRA.Dotex
{
    /// <summary>
    /// Class For Dotex Header Record
    /// </summary>
    internal class DotexHeader
    {
        public DotexHeader()
        {
            m_CreationDateTime = DateTime.Now;
        }


        private DateTime m_CreationDateTime;

        #region Public properties

        /// <summary>
        /// Record Type Number 
        /// </summary>
        [DataField(Length = 2, IsRequired = true)]
        public int RecordType { get; set; }

        /// <summary>
        /// Batch Number
        /// </summary>
        [DataField(Length = 3, IsRequired = true)]
        public int BatchNumber { get; set; }

        /// <summary>
        /// Intermediary Type 
        /// </summary>
        [DataField(Length = 2, IsRequired = true)]
        public int IntermediaryType { get; set; }


        /// <summary>
        /// Intermediary ID 
        /// </summary>
        [DataField(Length = 6, IsRequired = true)]
        public string IntermediaryID { get; set; }


        /// <summary>
        /// Branch Code
        /// </summary>
        [DataField(Length = 4, IsRequired = true)]
        public string BranchCode { get; set; }


        /// <summary>
        /// Total No of Successful detailed Records
        /// </summary>
        [DataField(Length = 7, IsRequired = true, PaddingCharacter='0')]
        public int DetailRecordsCount { get; set; }

        /// <summary>
        /// Date of Creation
        /// </summary>
        [DataField(Length = 8, IsRequired = true)]
        public string ExportDownloadDate
        {
            get
            {
                return m_CreationDateTime.ToString(DotexConstants.DateFormat);
            }
        }

        /// <summary>
        /// Filer : Length = 37 : Optional 
        /// </summary>
        [DataField(Length = 80)]
        public string Filler { get; set; }


        /// <summary>
        /// Join all properties with fix length value mentioned in DataField attribute [DataField]
        /// </summary>
        /// <returns>Joined string</returns>
        public override string ToString()
        {
            return Utility.JoinProperties(this, DotexConstants.Delimiter);
        }

        #endregion

    }
}
