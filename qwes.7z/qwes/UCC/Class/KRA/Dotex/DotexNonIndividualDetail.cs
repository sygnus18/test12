﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UCC.Class.KRA.Dotex
{


    /// <summary>
    /// Class for Dotex Individual KRA detail record
    /// </summary>
    internal class DotexNonIndividualDetail
    {

        public DotexNonIndividualDetail(UCC.Class.Master.CClient client)
        {
            RecordType = (int)DotexRecordType.NonIndividualDetail;
            ClientInstance = client;
            PromoterDetailList = new List<PromoterDetail>();
            IsVaild = true;
        }

        #region public properties (KRA Detail Record Fields)

        /// <summary>
        /// Master Client Object
        /// </summary>
        public UCC.Class.Master.CClient ClientInstance { get; set; } 

        /// <summary>
        /// Record Type
        /// </summary>
        [DataField(Length = 2)]
        public int RecordType { get; set; }

        /// <summary>
        /// Line Number
        /// </summary>
        [DataField(Length = 7, PaddingCharacter = '0')]
        public int LineNumber { get; set; }

        /// <summary>
        /// Update flag
        /// </summary>
        [DataField(Length = 2, IsRequired = true)]
        public string UpdateFlag { get; set; }

        /// <summary>
        /// Name of the Applicant
        /// </summary>
        [DataField(Length = 250, IsRequired = true)]
        public string ApplicantName { get; set; }


        /// <summary>
        /// Date of Incorporation text format
        /// </summary>
        [DataField(Length = 8, IsRequired = true, Name="DateOfIncorporation")]
        public string DateofIncorporationText
        {
            get
            {
                if (DateofIncorporation != null)
                    return DateofIncorporation.Value.ToString(DotexConstants.DateFormat);
                else return null;
            }
        }


        /// <summary>
        /// Date of Incorporation
        /// </summary>
        public DateTime? DateofIncorporation { get; set; }


        /// <summary>
        /// Place of Incorporation
        /// </summary>
        [DataField(Length = 75, IsRequired = true)]
        public string PlaceOfIncorporation { get; set; }

        /// <summary>
        /// Date of commencement of business text format
        /// </summary>
        [DataField(Length = 8, IsRequired = true, Name="BusinessCommencementDate")]
        public string BusinessCommencementDateText
        {
            get
            {
                if (BusinessCommencementDate != null)
                    return BusinessCommencementDate.Value.ToString(DotexConstants.DateFormat);
                else return null;
            }
        }


        /// <summary>
        /// Date of commencement of business
        /// </summary>
        public DateTime? BusinessCommencementDate { get; set; }


        /// <summary>
        /// PAN EXEMPT (Y/N)
        /// </summary>
        [DataField(Length = 1, IsRequired = true)]
        public string PANExept { get; set; }


        /// <summary>
        /// PAN 
        /// </summary>
        [DataField(Length = 10)]
        public string PAN { get; set; }

        /// <summary>
        /// Evidence / Documents provided in case of PAN exemption
        /// </summary>
        [DataField(Length = 75)]
        public string PANExemptionEvidence { get; set; }

        /// <summary>
        ///  Registration No. (e.g. CIN)
        /// </summary>
        [DataField(Length = 16)]
        public string RegistrationNo { get; set; }

        /// <summary>
        /// Status (Non Individual)
        /// </summary>
        [DataField(Length = 2, IsRequired = true)]
        public string Status { get; set; }

        /// <summary>
        /// Status Other
        /// </summary>
        [DataField(Length = 75)]
        public string StatusOther { get; set; }


        /// <summary>
        /// Correspondence Address (Line 1)
        /// </summary>
        [DataField(Length = 36, IsRequired = true)]
        public string CorrespondenceAddress1 { get; set; }

        /// <summary>
        /// Correspondence Address (Line 2)
        /// </summary>
        [DataField(Length = 36)]
        public string CorrespondenceAddress2 { get; set; }

        /// <summary>
        /// Correspondence Address (Line 3)
        /// </summary>
        [DataField(Length = 36)]
        public string CorrespondenceAddress3 { get; set; }

        /// <summary>
        /// Correspondence Address City / Town / Village
        /// </summary>
        [DataField(Length = 36)]
        public string CorrAddCity { get; set; }

        /// <summary>
        /// Correspondence Address PIN Code
        /// </summary>
        [DataField(Length = 10, IsRequired = true, Name="CorrespondenceAddressPIN")]
        public string CorrAddPINCode { get; set; }

        /// <summary>
        /// Correspondence Address State Code
        /// </summary>
        [DataField(Length = 2, IsRequired = true, Name="CorrespondenceAddressStateCode")]
        public string CorrAddState { get; set; }

        /// <summary>
        /// Correspondence Address State Other
        /// </summary>
        [DataField(Length = 75, Name="CorrespondenceAddressStateOther")]
        public string CorrAddStateOther { get; set; }

        /// <summary>
        /// Correspondence Address Country
        /// </summary>
        [DataField(Length = 3, IsRequired = true, Name="CorrespondenceAddressCountry")]
        public string CorrAddCountry { get; set; }

        /// <summary>
        /// Proof of Address submitted for correspondence address
        /// </summary>
        [DataField(Length = 2, IsRequired = true, Name = "ProofOfCorrespondenceAddress")]
        public string ProofofAddressCorrAddress { get; set; }

        /// <summary>
        /// Proof of Address submitted for correspondence address (Other)
        /// </summary>
        [DataField(Length = 75)]
        public string ProofofAddressCorrAddressOther { get; set; }

        /// <summary>
        /// Off Tel ISD
        /// </summary>
        [DataField(Length = 14)]
        public string TelOfficeISD { get; set; }

        /// <summary>
        /// Off Tel STD
        /// </summary>
        [DataField(Length = 10)]
        public string TelOfficeSTD { get; set; }

        /// <summary>
        /// Off Tel 
        /// </summary>
        [DataField(Length = 24)]
        public string TelOffice { get; set; }

        /// <summary>
        /// Res Tel ISD
        /// </summary>
        [DataField(Length = 14)]
        public string TelResISD { get; set; }

        /// <summary>
        /// Res Tel STD
        /// </summary>
        [DataField(Length = 10)]
        public string TelResSTD { get; set; }

        /// <summary>
        /// Res Tel 
        /// </summary>
        [DataField(Length = 24)]
        public string TelRes { get; set; }


        /// <summary>
        /// Mobile STD
        /// </summary>
        [DataField(Length = 14)]
        public string MobileSTD { get; set; }


        /// <summary>
        /// Mobile No.
        /// </summary>
        [DataField(Length = 15)]
        public string MobileNo { get; set; }

        /// <summary>
        /// Fax Tel ISD
        /// </summary>
        [DataField(Length = 14)]
        public string TelFaxISD { get; set; }

        /// <summary>
        /// Fax Tel STD
        /// </summary>
        [DataField(Length = 10)]
        public string TelFaxSTD { get; set; }

        /// <summary>
        /// Res Tel 
        /// </summary>
        [DataField(Length = 24)]
        public string TelFax { get; set; }

        /// <summary>
        /// Email ID
        /// </summary>
        [DataField(Length = 100)]
        public string EmailID { get; set; }

        /// <summary>
        /// Flag indicating if Registered Address is same as correspondence Address Y/N
        /// </summary>
        [DataField(Length = 1, IsRequired = true)]
        public string IsSameAsCorrespondence { get; set; }

        /// <summary>
        /// Registered Address (Line 1)
        /// </summary>
        [DataField(Length = 36)]
        public string RegisteredAddress1 { get; set; }

        /// <summary>
        /// Registered Address (Line 2)
        /// </summary>
        [DataField(Length = 36)]
        public string RegisteredAddress2 { get; set; }

        /// <summary>
        /// Registered Address (Line 3)
        /// </summary>
        [DataField(Length = 36)]
        public string RegisteredAddress3 { get; set; }

        /// <summary>
        /// Registered Address City/Town/ Village
        /// </summary>
        [DataField(Length = 36)]
        public string RegAddCity { get; set; }

        /// <summary>
        /// Registered Address PIN code
        /// </summary>
        [DataField(Length = 10)]
        public string RegAddPINCode { get; set; }

        /// <summary>
        /// Registered Address State code
        /// </summary>
        [DataField(Length = 2)]
        public string RegAddState { get; set; }

        /// <summary>
        /// Registered Address State (Other)
        /// </summary>
        [DataField(Length = 75)]
        public string RegAddStateOther { get; set; }

        /// <summary>
        /// Registered Address Country
        /// </summary>
        [DataField(Length = 3)]
        public string RegAddCountry { get; set; }

        /// <summary>
        /// Proof of Address submitted for Registered address
        /// </summary>
        [DataField(Length = 2)]
        public string ProofofRegAddress { get; set; }

        /// <summary>
        /// Proof of Address submitted for Registered address (Other)
        /// </summary>
        [DataField(Length = 75)]
        public string ProofofRegAddressOther { get; set; }


        /// <summary>
        /// Gross Annual Income Range
        /// </summary>
        [DataField(Length = 2)]
        public string GrossAnnualIncomeRange { get; set; }

        /// <summary>
        /// Net Worth (In Rs.)
        /// </summary>
        [DataField(Length = 18, IsRequired = true, IsMoney=true)]
        public decimal NetWorth { get; set; }

        /// <summary>
        /// Net Worth as on Date text format
        /// </summary>
        [DataField(Length = 8, IsRequired = true, Name="NetWorthOnDate")]
        public string NetWorthOnDateText
        {
            get
            {
                if (NetWorthOnDate != null)
                    return NetWorthOnDate.Value.ToString(DotexConstants.DateFormat);
                else return null;
            }
        }

        /// <summary>
        /// Net Worth as on Date
        /// </summary>
        public DateTime? NetWorthOnDate { get; set; }


        /// <summary>
        /// Number of Promoters/Partners/Karta/Trustees and whole time directors
        /// </summary>
        [DataField(Length = 3, IsRequired = true)]
        public int NumberofPromoters { get { return PromoterDetailList.Count; } }


        /// <summary>
        /// Politically Exposed Person (PEP)
        /// </summary>
        [DataField(Length = 2, IsRequired = true)]
        public string PEP { get; set; }


        /// <summary>
        /// Any Other Information
        /// </summary>
        [DataField(Length = 100)]
        public string OtherInformation { get; set; }

        /// <summary>
        /// Date of Declaration text format
        /// </summary>
        [DataField(Length = 8, IsRequired = true, Name="DeclarationDate")]
        public string DeclarationDateText
        {
            get
            {
                if (DeclarationDate != null)
                    return DeclarationDate.Value.ToString(DotexConstants.DateFormat);
                else return null;
            }
        }

        /// <summary>
        /// Date of Declaration
        /// </summary>
        public DateTime? DeclarationDate { get; set; }


        /// <summary>
        /// (Originals verified) True copies of documents received
        /// </summary>
        [DataField(Length = 1, IsRequired = true)]
        public string VerifiedCopiesReceived { get; set; }

        /// <summary>
        /// (Self-Attested) Self Certified Document copies received
        /// </summary>
        [DataField(Length = 1, IsRequired = true)]
        public string SelfAttestedReceived { get; set; }

        /// <summary>
        /// Activation Date text format DD-MON-YYYY
        /// </summary>
        [DataField(Length = 11)]
        public string ActivationDateText
        {
            get
            {
                if (ActivationDate != null)
                    return ActivationDate.Value.ToString(DotexConstants.DateFormat);
                else return null;
            }
        }

        /// <summary>
        /// Client Activation Date
        /// </summary>
        public DateTime? ActivationDate { get; set; }


        /// <summary>
        /// Number Of Documents Submitted
        /// </summary>
        [DataField(Length = 2, IsRequired = true)]
        public int DocumentsCount { get; set; }


        /// <summary>
        /// Sender reference number 1
        /// </summary>
        [DataField(Length = 35)]
        public string SenderRefNo1 { get; set; }

        /// <summary>
        /// Sender reference number 2
        /// </summary>
        [DataField(Length = 35)]
        public string SenderRefNo2 { get; set; }


        /// <summary>
        /// KYC Application No
        /// </summary>
        [DataField(Length = 20)]
        public string KYCApplicationNo { get; set; }


        /// <summary>
        /// KYC Application Date text format DD-MON-YYYY
        /// </summary>
        [DataField(Length = 11)]
        public string KYCApplicationDateText
        {
            get
            {
                if (KYCApplicationDate != null)
                    return KYCApplicationDate.Value.ToString(DotexConstants.DateFormat);
                else return null;
            }
        }
        /// <summary>
        /// KYC Application Date
        /// </summary>
        public DateTime? KYCApplicationDate { get; set; }


        /// <summary>
        /// Intermediary Internal Refrence No
        /// </summary>
        [DataField(Length = 20)]
        public string IntermediaryInternalRefNo
        { get; set; }

        /// <summary>
        /// Intermediary Branch Code
        /// </summary>
        [DataField(Length = 10)]
        public string IntermediaryBranchCode { get; set; }


        /// <summary>
        /// IPV Flag
        /// </summary>
        [DataField(Length = 1, IsRequired = true)]
        public string IPVFlag { get; set; }

        /// <summary>
        /// Date of the IPV in text format DD-MON-YYYY
        /// </summary>
        [DataField(Length = 11)]
        public string IPVDateText
        {
            get
            {
                if (IPVDate != null)
                    return IPVDate.Value.ToString(DotexConstants.DateFormat);
                else return null;
            }
        }
        /// <summary>
        /// Date of the IPV
        /// </summary>
        public DateTime? IPVDate { get; set; }


        /// <summary>
        /// Name of the person doing the IPV
        /// </summary>
        [DataField(Length = 150)]
        public string IPVName { get; set; }

        /// <summary>
        /// Designation of the person doing the IPV
        /// </summary>
        [DataField(Length = 50)]
        public string IPVDesignation { get; set; }

        /// <summary>
        /// Organization Name of the person doing the IPV
        /// </summary>
        [DataField(Length = 150)]
        public string IPVOrganization { get; set; }


        /// <summary>
        ///   TM Code
        /// </summary>
        [DataField(Length = 5)]
        public string TMCode { get; set; }

        /// <summary>
        /// Client Code
        /// </summary>
        [DataField(Length = 10)]
        public string ClientCode { get; set; }


        /// <summary>
        /// Filler
        /// </summary>
        [DataField(Length = 50)]
        public string Filler1 { get; set; }

        /// <summary>
        /// Filler
        /// </summary>
        [DataField(Length = 50)]
        public string Filler2 { get; set; }

        /// <summary>
        /// Filler
        /// </summary>
        [DataField(Length = 50)]
        public string Filler3 { get; set; }

        /// <summary>
        /// flag for valid record
        /// </summary>
        public bool IsVaild { get; set; }

        /// <summary>
        /// List of Promoter
        /// </summary>
        public List<PromoterDetail> PromoterDetailList { get; set; }


        #endregion

        /// <summary>
        /// Return string after joinning all properties having custom attribute 
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return Utility.JoinProperties(this, DotexConstants.Delimiter);
        }

    }


}
