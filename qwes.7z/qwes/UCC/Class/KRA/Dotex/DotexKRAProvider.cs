﻿using System;
using System.Collections.Generic;
using System.Text;
using UCC.Class.Master;
using FTIL.Match.Common;

namespace UCC.Class.KRA.Dotex
{

    public enum DotexRecordType
    {
        IndividualHeader = 10,
        IndividualDetail = 20,
        NonIndividualHeader = 30,
        NonIndividualDetail = 40,
        PromoterDetail = 50
    }


    public struct DotexConstants
    {
        public static readonly char Delimiter = '|';
        /// <summary>
        /// Date Format 'DD-MON-YYYY'
        /// </summary>
        public static readonly string DateFormat = FTIL.Match.Common.Constants.Formatting.Instance.SHORT_DATE_UNIVERSAL_FORMAT_PLAIN;
    }



    /// <summary>
    /// Generate KRA file for Dotex KRA Agency
    /// File Type : Pipe delimited 
    /// Type of records : Header and Detail
    /// </summary>
    public class DotexKRAProvider : BaseKRAProvider, IKRAProvider
    {

        #region Private Members fields


        private IList<DotexIndividualDetail> m_DotexIndividualDetailRecords;
        private IList<DotexNonIndividualDetail> m_DotexNonIndividualDetailRecords;

        /// <summary>
        /// Supported Gender List
        /// </summary>
        private static List<string> SupportedGenderList = new List<string> { "M", "F" };


        #endregion

        /// <summary>
        /// Initiate private members
        /// </summary>
        public DotexKRAProvider()
            : base(KRAAgencyEnum.DOTEX)
        {
            m_DotexIndividualDetailRecords = new List<DotexIndividualDetail>();
            m_DotexNonIndividualDetailRecords = new List<DotexNonIndividualDetail>();
        }

        #region IKRAProvider Methods implementation

        /// <summary>
        /// Process Clients for KRA
        /// </summary>
        /// <param name="clients">Client List</param>
        /// <returns></returns>
        public FTIL.Match.Common.MethodExecResult ProcessKRAClients(List<CClient> clients)
        {

            clients.ForEach(client => this.AddDetailRecord(client));

            return new MethodExecResult(MethodExecResult.SuccessfulReturnCode, "Success", "ProcessKRAClients() UserNo. " + AppEnvironment.AppUser.UserNo, null);

        }


        public Dictionary<string, string> GetKRARecordsToText()
        {

            if ((IndividualDetailVaildCount == 0) && (NonIndividualDetailVaildCount == 0))
            {
                return new Dictionary<string, string>();
            }

            Dictionary<string, string> l_DicFileNameKRAText = new Dictionary<string, string>();

            StringBuilder l_sbObj = new StringBuilder();

            DotexHeader obj_HeaderRecord = new DotexHeader();

            string l_sFileName = null;

            obj_HeaderRecord.IntermediaryID = IntermediaryID.DOTEX;
            obj_HeaderRecord.BranchCode = "00";

            //INDIVIDUAL
            if (IndividualDetailVaildCount > 0)
            {

                //INDIVIDUAL
                obj_HeaderRecord.DetailRecordsCount = IndividualDetailVaildCount;
                obj_HeaderRecord.RecordType = (int)DotexRecordType.IndividualHeader;

                l_sbObj.AppendLine(obj_HeaderRecord.ToString());

                foreach (DotexIndividualDetail detailRecord in m_DotexIndividualDetailRecords)
                {
                    if (detailRecord.IsVaild)
                    {
                        detailRecord.LineNumber = this.NextLineNumber;
                        l_sbObj.AppendLine(detailRecord.ToString());
                    }
                }

                l_sFileName = GetKRAFileName(KRAFileTypeEnum.INDIVIDUAL);
                l_DicFileNameKRAText.Add(l_sFileName, l_sbObj.ToString());

            }

            if (NonIndividualDetailVaildCount > 0)
            {
                //Reseting Line Number
                ResetLineNumber();

                //Reset StringBuilder
                l_sbObj.Remove(0, l_sbObj.Length);
                l_sbObj = new StringBuilder(string.Empty);

                //NON INDIVIDUAL
                obj_HeaderRecord.DetailRecordsCount = NonIndividualDetailVaildCount;
                obj_HeaderRecord.RecordType = (int)DotexRecordType.NonIndividualHeader;
                l_sbObj.AppendLine(obj_HeaderRecord.ToString());

                foreach (DotexNonIndividualDetail detailRecord in m_DotexNonIndividualDetailRecords)
                {
                    if (detailRecord.IsVaild)
                    {
                        detailRecord.LineNumber = this.NextLineNumber;
                        l_sbObj.AppendLine(detailRecord.ToString());
                    }
                }


                //Adding Promoter Details
                foreach (DotexNonIndividualDetail detailRecord in m_DotexNonIndividualDetailRecords)
                {
                    if (detailRecord.IsVaild)
                    {
                        foreach (PromoterDetail promoter in detailRecord.PromoterDetailList)
                        {
                            if (promoter.IsVaild)
                            {
                                promoter.LineNumber = NextLineNumber;
                                l_sbObj.AppendLine(promoter.ToString());
                            }
                        }
                    }
                }

                l_sFileName = GetKRAFileName(KRAFileTypeEnum.NON_INDIVIDUAL);
                l_DicFileNameKRAText.Add(l_sFileName, l_sbObj.ToString());

            }
            return l_DicFileNameKRAText;
        }

        #endregion


        #region Private Methods

        private string GetKRAFileName(KRAFileTypeEnum fileType)
        {
            string l_sFile = null;
            string l_sBusinessDate = DateTime.Now.ToString("yyyyMMdd");

            if (fileType == KRAFileTypeEnum.INDIVIDUAL)
                l_sFile = "KYC_I_" + l_sBusinessDate + ".T001";

            if (fileType == KRAFileTypeEnum.NON_INDIVIDUAL)
                l_sFile = "KYC_NI_" + l_sBusinessDate + ".T001";

            return l_sFile;
        }


        /// <summary>
        /// Add record as individual detail 
        /// </summary>
        /// <param name="client"></param>
        private void AddIndividualDetail(CClient client)
        {

            CAddress l_CorrespondenceAddress = client.ClientAddresses.GetAddressByType(AddressTypeEnum.Correspondence);
            CAddress l_RegisteredAddress = client.ClientAddresses.GetAddressByType(AddressTypeEnum.Registered);

            if (l_CorrespondenceAddress == null)
            {
                this.AddToValidationSummary("CorrespondenceAddress", client, "Correspondence address is mandatory.");
                return;
            }
            if (l_RegisteredAddress == null && l_CorrespondenceAddress.SameCorrPermAdd != "Y")
            {
                this.AddToValidationSummary("RegisteredAddress", client, "Registered address is mandatory.");
                return;
            }

            bool l_SameCorrPermAdd = false;

            DotexIndividualDetail l_ObjDetail = new DotexIndividualDetail(client);

            l_ObjDetail.UpdateFlag = "01";

            l_ObjDetail.ApplicantName = client.ClientName;
            l_ObjDetail.Father_HusbandName = client.GuardianName;
            l_ObjDetail.Gender = client.Gender;
            l_ObjDetail.Maritalstatus = client.MaritalStatus;

            if (client.DOB.HasValue)
                l_ObjDetail.DateofBirth = client.DOB.Value;

            l_ObjDetail.PAN = client.PANNo;
            l_ObjDetail.PANExept = client.PanExempt;
            l_ObjDetail.PANExemptionEvidence = client.PanExempt == "Y" ? client.KYCAdditionalDetail.PANExemptionEvidence : null;

            l_ObjDetail.IPVFlag = client.KYCAdditionalDetail.IPVFlag.ToString();
            l_ObjDetail.IPVName = client.KYCAdditionalDetail.VerifierName;
            l_ObjDetail.IPVOrganization = client.KYCAdditionalDetail.CompanyName;

            l_ObjDetail.TMCode = client.KYCAdditionalDetail.TradingCode;
            l_ObjDetail.ClientCode = client.ClientCode;

            l_ObjDetail.Nationality = GetRefDataByRefCode(Convert.ToString(client.Nationality), ReferenceType.NATIONALTY);
            l_ObjDetail.NationalityOther = client.NationalityOther;


            l_SameCorrPermAdd = l_CorrespondenceAddress.SameCorrPermAdd == "Y" ? true : false;
            l_ObjDetail.IsSameAsCorrespondence = l_SameCorrPermAdd == true ? "Y" : "N";

            l_ObjDetail.CorrespondenceAddress1 = l_CorrespondenceAddress.AddressLine1;
            l_ObjDetail.CorrespondenceAddress2 = l_CorrespondenceAddress.AddressLine2;
            l_ObjDetail.CorrespondenceAddress3 = l_CorrespondenceAddress.AddressLine3;
            l_ObjDetail.CorrAddCity = l_CorrespondenceAddress.City;
            l_ObjDetail.CorrAddPINCode = l_CorrespondenceAddress.PinCode;
            l_ObjDetail.CorrAddState = GetRefDataByRefCode(Convert.ToString(l_CorrespondenceAddress.StateNumber), ReferenceType.STATE);
            l_ObjDetail.CorrAddStateOther = l_CorrespondenceAddress.StateOther;
            l_ObjDetail.CorrAddCountry = GetRefDataByRefCode(Convert.ToString(l_CorrespondenceAddress.CountryCode), ReferenceType.COUNTRY);

            if (l_SameCorrPermAdd)
            {
                l_ObjDetail.PermanentAddress1 = l_CorrespondenceAddress.AddressLine1;
                l_ObjDetail.PermanentAddress2 = l_CorrespondenceAddress.AddressLine2;
                l_ObjDetail.PermanentAddress3 = l_CorrespondenceAddress.AddressLine3;
                l_ObjDetail.PerAddCity = l_CorrespondenceAddress.City;
                l_ObjDetail.PerAddPINCode = l_CorrespondenceAddress.PinCode;
                l_ObjDetail.PerAddState = GetRefDataByRefCode(Convert.ToString(l_CorrespondenceAddress.StateNumber), ReferenceType.STATE);
                l_ObjDetail.PerAddStateOther = l_CorrespondenceAddress.StateOther;
                l_ObjDetail.PerAddCountry = GetRefDataByRefCode(Convert.ToString(l_CorrespondenceAddress.CountryCode), ReferenceType.COUNTRY);
                l_ObjDetail.UID = l_CorrespondenceAddress.UID;
                l_ObjDetail.TelOffice = l_CorrespondenceAddress.TelNoOffice;
                l_ObjDetail.TelRes = l_CorrespondenceAddress.TelNo1;
                l_ObjDetail.MobileNo = l_CorrespondenceAddress.Mobile1;
                l_ObjDetail.TelFax = l_CorrespondenceAddress.FaxNo;
                l_ObjDetail.EmailID = l_CorrespondenceAddress.EMailId;
                l_ObjDetail.TelFaxISD = l_CorrespondenceAddress.FaxNoISDCode;
                l_ObjDetail.TelOfficeISD = l_CorrespondenceAddress.TelNoOfficeISDCode;
                l_ObjDetail.TelResISD = l_CorrespondenceAddress.TelNoISDCode;
                l_ObjDetail.TelFaxSTD = l_CorrespondenceAddress.FaxNoSTDCode;
                l_ObjDetail.TelOfficeSTD = l_CorrespondenceAddress.TelNoOfficeSTDCode;
                l_ObjDetail.TelResSTD = l_CorrespondenceAddress.TelNoSTDCode;
            }
            else
            {
                l_ObjDetail.PermanentAddress1 = l_RegisteredAddress.AddressLine1;
                l_ObjDetail.PermanentAddress2 = l_RegisteredAddress.AddressLine2;
                l_ObjDetail.PermanentAddress3 = l_RegisteredAddress.AddressLine3;
                l_ObjDetail.PerAddCity = l_RegisteredAddress.City;
                l_ObjDetail.PerAddPINCode = l_RegisteredAddress.PinCode;
                l_ObjDetail.PerAddState = GetRefDataByRefCode(Convert.ToString(l_RegisteredAddress.StateNumber), ReferenceType.STATE);
                l_ObjDetail.PerAddStateOther = l_RegisteredAddress.StateOther;
                l_ObjDetail.PerAddCountry = GetRefDataByRefCode(Convert.ToString(l_RegisteredAddress.CountryCode), ReferenceType.COUNTRY);
                l_ObjDetail.UID = l_RegisteredAddress.UID;
                l_ObjDetail.TelOffice = l_RegisteredAddress.TelNoOffice;
                l_ObjDetail.TelRes = l_RegisteredAddress.TelNo1;
                l_ObjDetail.MobileNo = l_RegisteredAddress.Mobile1;
                l_ObjDetail.TelFax = l_RegisteredAddress.FaxNo;
                l_ObjDetail.EmailID = l_RegisteredAddress.EMailId;
                l_ObjDetail.TelFaxISD = l_RegisteredAddress.FaxNoISDCode;
                l_ObjDetail.TelOfficeISD = l_RegisteredAddress.TelNoOfficeISDCode;
                l_ObjDetail.TelResISD = l_RegisteredAddress.TelNoISDCode;
                l_ObjDetail.TelFaxSTD = l_RegisteredAddress.FaxNoSTDCode;
                l_ObjDetail.TelOfficeSTD = l_RegisteredAddress.TelNoOfficeSTDCode;
                l_ObjDetail.TelResSTD = l_RegisteredAddress.TelNoSTDCode;
            }

            l_ObjDetail.GrossAnnualIncomeRange = GetRefData(client.GrAnnIncRange);
            l_ObjDetail.NetWorth = client.NetWorth.HasValue == true ? client.NetWorth.Value : 0;
            l_ObjDetail.NetWorthOnDate = client.NetWorthAsOnDate;

            if (client.GrAnnIncAsOnDate.HasValue && string.IsNullOrEmpty(l_ObjDetail.GrossAnnualIncomeRange) == false)
            {
                l_ObjDetail.DeclarationDate = client.GrAnnIncAsOnDate;
            }
            else if (client.NetWorthAsOnDate.HasValue && l_ObjDetail.NetWorth > 0)
            {
                l_ObjDetail.DeclarationDate = client.NetWorthAsOnDate.Value;
            }
          

            l_ObjDetail.Occupation = GetRefData(client.Occupation);
            l_ObjDetail.OccupationDetails = client.OccupationOthers;

            l_ObjDetail.PEP = GetRefDataByRefCode(Convert.ToString(client.PEP), ReferenceType.PEP);

            if (client.KYCAdditionalDetail.KYCActiveDate.HasValue)
                l_ObjDetail.ActivationDate = client.KYCAdditionalDetail.KYCActiveDate.Value;

            l_ObjDetail.DocumentsCount = client.KYCAdditionalDetail.DocumentsCount;

            l_ObjDetail.IntermediaryBranchCode = client.KYCAdditionalDetail.IntermediaryBranchCode;


            if (client.KYCAdditionalDetail.IPVDate.HasValue)
            l_ObjDetail.IPVDate = client.KYCAdditionalDetail.IPVDate.Value;

            l_ObjDetail.IPVDesignation = client.KYCAdditionalDetail.IPVPersonDesignation;

            l_ObjDetail.Status = client.KYCAdditionalDetail.ClientStatus;

            l_ObjDetail.ProofofAddressCorrAddress = client.KYCAdditionalDetail.ProofofCorrAddress;

            l_ObjDetail.ProofofAddressCorrAddressOther = client.KYCAdditionalDetail.ProofofCorrAddressOther;

            l_ObjDetail.ProofofIdentity = client.KYCAdditionalDetail.ProofOfIdentity;

            l_ObjDetail.ProofofIdentiyOthers = client.KYCAdditionalDetail.ProofofIdentityOther;

            l_ObjDetail.ProofofPerAddress = client.KYCAdditionalDetail.ProofofPerAddress;

            l_ObjDetail.ProofofPerAddressOther = client.KYCAdditionalDetail.ProofofPerAddressOther;

            l_ObjDetail.SenderRefNo1 = client.KYCAdditionalDetail.SenderRefNo1;
            l_ObjDetail.SenderRefNo2 = client.KYCAdditionalDetail.SenderRefNo2;


            l_ObjDetail.IntermediaryInternalRefNo = client.ClientCode;

            l_ObjDetail.SelfAttestedReceived = "Y";
            l_ObjDetail.VerifiedCopiesReceived = "Y";

            l_ObjDetail.KYCApplicationNo = client.KYCAdditionalDetail.KYCApplicationNo;

            if (client.KYCAdditionalDetail.KYCApplicationDate.HasValue)
                l_ObjDetail.KYCApplicationDate = client.KYCAdditionalDetail.KYCApplicationDate.Value;


            //Add into DetailRecords list
            m_DotexIndividualDetailRecords.Add(l_ObjDetail);
        }

        /// <summary>
        /// Add record as non-individual detail 
        /// </summary>
        /// <param name="client"></param>
        private void AddNonIndividualDetail(CClient client)
        {

            CAddress l_CorrespondenceAddress = client.ClientAddresses.GetAddressByType(AddressTypeEnum.Correspondence);
            CAddress l_RegisteredAddress = client.ClientAddresses.GetAddressByType(AddressTypeEnum.Registered);

            if (l_CorrespondenceAddress == null)
            {
                this.AddToValidationSummary("CorrespondenceAddress", client, "Correspondence address is mandatory.");
                return;
            }
            if (l_RegisteredAddress == null && l_CorrespondenceAddress.SameCorrPermAdd != "Y")
            {
                this.AddToValidationSummary("RegisteredAddress", client, "Registered address is mandatory.");
                return;
            }


            bool l_SameCorrPermAdd = false;

            DotexNonIndividualDetail l_ObjDetail = new DotexNonIndividualDetail(client);

            l_ObjDetail.UpdateFlag = "01";

            l_ObjDetail.ApplicantName = client.ClientName;

            l_ObjDetail.PAN = client.PANNo;
            l_ObjDetail.PANExept = client.PanExempt;
            l_ObjDetail.PANExemptionEvidence = client.PanExempt == "Y" ? client.KYCAdditionalDetail.PANExemptionEvidence : null;

            l_ObjDetail.IPVFlag = client.KYCAdditionalDetail.IPVFlag.ToString();
            l_ObjDetail.IPVName = client.KYCAdditionalDetail.VerifierName;
            l_ObjDetail.IPVOrganization = client.KYCAdditionalDetail.CompanyName;

            l_ObjDetail.TMCode = client.KYCAdditionalDetail.TradingCode;
            l_ObjDetail.ClientCode = client.ClientCode;

            if (client.DOB.HasValue)
                l_ObjDetail.DateofIncorporation = client.DOB.Value;

            l_ObjDetail.PlaceOfIncorporation = client.PlaceofIncorporation;

            if (client.CommOfBusiness.HasValue)
                l_ObjDetail.BusinessCommencementDate = client.CommOfBusiness.Value;

            l_ObjDetail.RegistrationNo = client.CorporateIdNo;

            l_SameCorrPermAdd = l_CorrespondenceAddress.SameCorrPermAdd == "Y" ? true : false;
            l_ObjDetail.IsSameAsCorrespondence = l_SameCorrPermAdd == true ? "Y" : "N";

            l_ObjDetail.CorrespondenceAddress1 = l_CorrespondenceAddress.AddressLine1;
            l_ObjDetail.CorrespondenceAddress2 = l_CorrespondenceAddress.AddressLine2;
            l_ObjDetail.CorrespondenceAddress3 = l_CorrespondenceAddress.AddressLine3;
            l_ObjDetail.CorrAddCity = l_CorrespondenceAddress.City;
            l_ObjDetail.CorrAddPINCode = l_CorrespondenceAddress.PinCode;
            l_ObjDetail.CorrAddState = GetRefDataByRefCode(Convert.ToString(l_CorrespondenceAddress.StateNumber), ReferenceType.STATE);
            l_ObjDetail.CorrAddStateOther = l_CorrespondenceAddress.StateOther;
            l_ObjDetail.CorrAddCountry = GetRefDataByRefCode(Convert.ToString(l_CorrespondenceAddress.CountryCode), ReferenceType.COUNTRY);

            if (l_SameCorrPermAdd)
            {
                l_ObjDetail.RegisteredAddress1 = l_CorrespondenceAddress.AddressLine1;
                l_ObjDetail.RegisteredAddress2 = l_CorrespondenceAddress.AddressLine2;
                l_ObjDetail.RegisteredAddress3 = l_CorrespondenceAddress.AddressLine3;
                l_ObjDetail.RegAddCity = l_CorrespondenceAddress.City;
                l_ObjDetail.RegAddPINCode = l_CorrespondenceAddress.PinCode;
                l_ObjDetail.RegAddState = GetRefDataByRefCode(Convert.ToString(l_CorrespondenceAddress.StateNumber), ReferenceType.STATE);
                l_ObjDetail.RegAddStateOther = l_CorrespondenceAddress.StateOther;
                l_ObjDetail.RegAddCountry = GetRefDataByRefCode(Convert.ToString(l_CorrespondenceAddress.CountryCode), ReferenceType.COUNTRY);
                l_ObjDetail.TelOffice = l_CorrespondenceAddress.TelNoOffice;
                l_ObjDetail.TelRes = l_CorrespondenceAddress.TelNo1;
                l_ObjDetail.MobileNo = l_CorrespondenceAddress.Mobile1;
                l_ObjDetail.TelFax = l_CorrespondenceAddress.FaxNo;
                l_ObjDetail.EmailID = l_CorrespondenceAddress.EMailId;

                l_ObjDetail.TelFaxISD = l_CorrespondenceAddress.FaxNoISDCode;
                l_ObjDetail.TelOfficeISD = l_CorrespondenceAddress.TelNoOfficeISDCode;
                l_ObjDetail.TelResISD = l_CorrespondenceAddress.TelNoISDCode;
                l_ObjDetail.TelFaxSTD = l_CorrespondenceAddress.FaxNoSTDCode;
                l_ObjDetail.TelOfficeSTD = l_CorrespondenceAddress.TelNoOfficeSTDCode;
                l_ObjDetail.TelResSTD = l_CorrespondenceAddress.TelNoSTDCode;
            }
            else
            {
                l_ObjDetail.RegisteredAddress1 = l_RegisteredAddress.AddressLine1;
                l_ObjDetail.RegisteredAddress2 = l_RegisteredAddress.AddressLine2;
                l_ObjDetail.RegisteredAddress3 = l_RegisteredAddress.AddressLine3;
                l_ObjDetail.RegAddCity = l_RegisteredAddress.City;
                l_ObjDetail.RegAddPINCode = l_RegisteredAddress.PinCode;
                l_ObjDetail.RegAddState = GetRefDataByRefCode(Convert.ToString(l_RegisteredAddress.StateNumber), ReferenceType.STATE);
                l_ObjDetail.RegAddStateOther = l_RegisteredAddress.StateOther;
                l_ObjDetail.RegAddCountry = GetRefDataByRefCode(Convert.ToString(l_RegisteredAddress.CountryCode), ReferenceType.COUNTRY);
                l_ObjDetail.TelOffice = l_RegisteredAddress.TelNoOffice;
                l_ObjDetail.TelRes = l_RegisteredAddress.TelNo1;
                l_ObjDetail.MobileNo = l_RegisteredAddress.Mobile1;
                l_ObjDetail.TelFax = l_RegisteredAddress.FaxNo;
                l_ObjDetail.EmailID = l_RegisteredAddress.EMailId;

                l_ObjDetail.TelFaxISD = l_RegisteredAddress.FaxNoISDCode;
                l_ObjDetail.TelOfficeISD = l_RegisteredAddress.TelNoOfficeISDCode;
                l_ObjDetail.TelResISD = l_RegisteredAddress.TelNoISDCode;
                l_ObjDetail.TelFaxSTD = l_RegisteredAddress.FaxNoSTDCode;
                l_ObjDetail.TelOfficeSTD = l_RegisteredAddress.TelNoOfficeSTDCode;
                l_ObjDetail.TelResSTD = l_RegisteredAddress.TelNoSTDCode;
            }

            l_ObjDetail.GrossAnnualIncomeRange = GetRefData(client.GrAnnIncRange);
            l_ObjDetail.NetWorth = client.NetWorth.HasValue == true ? client.NetWorth.Value : 0;
            l_ObjDetail.NetWorthOnDate = client.NetWorthAsOnDate;

            if (client.NetWorthAsOnDate.HasValue && l_ObjDetail.NetWorth > 0)
            {
                l_ObjDetail.DeclarationDate = client.NetWorthAsOnDate.Value;
            }
            else if (client.GrAnnIncAsOnDate.HasValue && string.IsNullOrEmpty(l_ObjDetail.GrossAnnualIncomeRange) == false)
            {
                l_ObjDetail.DeclarationDate = client.GrAnnIncAsOnDate;
            }


            l_ObjDetail.PEP = GetRefDataByRefCode(Convert.ToString(client.PEP), ReferenceType.PEP);

            l_ObjDetail.DocumentsCount = client.KYCAdditionalDetail.DocumentsCount;

            l_ObjDetail.IntermediaryBranchCode = client.KYCAdditionalDetail.IntermediaryBranchCode;

            if (client.KYCAdditionalDetail.IPVDate.HasValue)
                l_ObjDetail.IPVDate = client.KYCAdditionalDetail.IPVDate.Value;

            l_ObjDetail.IPVDesignation = client.KYCAdditionalDetail.IPVPersonDesignation;

            l_ObjDetail.Status = client.KYCAdditionalDetail.ClientStatus;
            l_ObjDetail.StatusOther = client.KYCAdditionalDetail.StatusOther;

            l_ObjDetail.SenderRefNo1 = client.KYCAdditionalDetail.SenderRefNo1;
            l_ObjDetail.SenderRefNo2 = client.KYCAdditionalDetail.SenderRefNo2;

            l_ObjDetail.IntermediaryInternalRefNo = client.ClientCode;

            l_ObjDetail.SelfAttestedReceived = "Y";
            l_ObjDetail.VerifiedCopiesReceived = "Y";

            l_ObjDetail.KYCApplicationNo = client.KYCAdditionalDetail.KYCApplicationNo;

            if (client.KYCAdditionalDetail.KYCApplicationDate.HasValue)
                l_ObjDetail.KYCApplicationDate = client.KYCAdditionalDetail.KYCApplicationDate.Value;

            l_ObjDetail.ProofofAddressCorrAddress = client.KYCAdditionalDetail.ProofofCorrAddress;
            l_ObjDetail.ProofofRegAddress = client.KYCAdditionalDetail.ProofofPerAddressOther;


            //************************************************Add Promoter details ****************************************************// 

            //Get contact person's addresses from address collection
            List<CAddress> l_ContactPersonAddressCollection = client.ClientAddresses.GetAddressesByType(AddressTypeEnum.ContactPerson);

            if (l_ContactPersonAddressCollection.Exists(item => item.Director == "Y") == false)
            {
                this.AddToValidationSummary("Director", client, "No Director found in Promoter Detail/Contact Person Addresses.");
                return;
            }

            if (l_ContactPersonAddressCollection != null && l_ContactPersonAddressCollection.Count > 0)
            {

                foreach (CAddress addr in l_ContactPersonAddressCollection)
                {
                    PromoterDetail l_ObjPromter = new PromoterDetail();

                    if (addr.Director == "Y")
                    {
                        l_ObjPromter.Name = addr.DIN;
                        l_ObjPromter.RelationshipWithApplicant = "05";
                    }
                    else
                    {
                        l_ObjPromter.Name = addr.ContactPerson;
                        l_ObjPromter.RelationshipWithApplicant = "99";
                        l_ObjPromter.RelationshipWithApplicantOther = addr.Designation;
                    }

                    l_ObjPromter.NonIndividualPAN = l_ObjDetail.PAN;
                    l_ObjPromter.PANExept = l_ObjDetail.PANExept;
                    l_ObjPromter.PANExemptionEvidence = l_ObjDetail.PANExemptionEvidence;
                    l_ObjPromter.PANPromoter = addr.PANNo;
                    l_ObjPromter.RegAddCity = addr.City;
                    l_ObjPromter.RegisteredAddress1 = addr.AddressLine1;
                    l_ObjPromter.RegisteredAddress2 = addr.AddressLine2;
                    l_ObjPromter.RegisteredAddress3 = addr.AddressLine3;
                    l_ObjPromter.RegAddCity = addr.City;
                    l_ObjPromter.RegAddPINCode = addr.PinCode;
                    l_ObjPromter.RegAddState = GetRefDataByRefCode(Convert.ToString(addr.StateNumber), ReferenceType.STATE);
                    l_ObjPromter.RegAddStateOther = addr.StateOther;
                    l_ObjPromter.RegAddCountry = GetRefDataByRefCode(Convert.ToString(addr.CountryCode), ReferenceType.COUNTRY);
                    l_ObjPromter.UID = addr.UID;
                    l_ObjDetail.PromoterDetailList.Add(l_ObjPromter);
                }

            }
            else
            {
                this.AddToValidationSummary("PromoterDetail", client, "No Promoter Detail/Contact Person Address found.");
                return;
            }

            //**************************************************************************************************************************//


            //Add into DetailRecords list
            m_DotexNonIndividualDetailRecords.Add(l_ObjDetail);
        
        }


        /// <summary>
        /// Set all properties for detail record object
        /// </summary>
        /// <param name="client">KRA Client</param>
        private void AddDetailRecord(CClient client)
        {
            if (client.ClientType == ClientType.INDIVIDUAL)
                this.AddIndividualDetail(client);
            else if (client.ClientType == ClientType.NON_INDIVIDUAL)
                this.AddNonIndividualDetail(client);
            else
            {
                this.AddToValidationSummary("ClientType", client, "Invalid Client Type {" + client.ClientType.ToString() + "}");
                return;
            }
        }

        #endregion

        
        public System.Data.DataTable VaildateRecords()
        {
            IndividualDetailVaildCount = m_DotexIndividualDetailRecords.Count;
            NonIndividualDetailVaildCount = m_DotexNonIndividualDetailRecords.Count;

            foreach (DotexIndividualDetail detail in m_DotexIndividualDetailRecords)
            {
                ValidationResult l_objVresult = Utility.ValidateRecord(detail, ValidationGroup.RequiredField);
                detail.IsVaild = l_objVresult.IsValid;
                if (!detail.IsVaild)
                {
                    foreach (var field in l_objVresult.InvaildFields)
                    {
                        this.AddToValidationSummary(field.Value, detail.ClientInstance, field.Value + " is mandatory.");
                    }
                }

                detail.IsVaild = CompareValidate(detail.ClientInstance.PanExempt, "Y", detail.PANExemptionEvidence, "PANExemptionEvidence", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.ClientInstance.PanExempt, "N", detail.PAN, "PAN", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.Nationality, "99", detail.NationalityOther, "NationalityOther", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.ProofofIdentity, "99", detail.ProofofIdentiyOthers, "ProofofIdentiyOthers", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.CorrAddState, "99", detail.CorrAddStateOther, "CorrAddStateOther", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.ProofofAddressCorrAddress, "99", detail.ProofofAddressCorrAddressOther, "ProofofAddressCorrAddressOther", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.IsSameAsCorrespondence, "N", detail.PermanentAddress1, "PermanentAddress1", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.IsSameAsCorrespondence, "N", detail.PerAddPINCode, "PerAddPINCode", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.IsSameAsCorrespondence, "N", detail.PerAddState, "PerAddState", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.IsSameAsCorrespondence, "N", detail.PerAddCountry, "PerAddCountry", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.PerAddState, "99", detail.PerAddStateOther, "PerAddStateOther", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.ProofofPerAddress, "99", detail.ProofofPerAddressOther, "ProofofPerAddressOther", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.Occupation, "99", detail.OccupationDetails, "OccupationDetails", detail.ClientInstance, detail.IsVaild);

          
                /********************************************************* Income validation ***************************************************************/
                if (detail.NetWorth == 0)
                {
                    if (string.IsNullOrEmpty(detail.GrossAnnualIncomeRange))
                    {
                        detail.IsVaild = false;
                        this.AddToValidationSummary("GrossAnnualIncomeRange", detail.ClientInstance, "GrossAnnualIncomeRange is mandatory if NetWorth is not provided.");
                    }
                }
                else
                {
                    if (string.IsNullOrEmpty(detail.NetWorthOnDateText))
                    {
                        detail.IsVaild = false;
                        this.AddToValidationSummary("NetWorthOnDate", detail.ClientInstance, "NetWorthAsOnDate is mandatory if NetWorth is provided.");
                    }
                }
                /*****************************************************************************************************************************************/


                /***************************************************** Gender validation *****************************************************************/
                if (!SupportedGenderList.Contains(detail.Gender))
                {
                    detail.IsVaild = false;
                    this.AddToValidationSummary("Gender", detail.ClientInstance, "Invaild Gender {" + detail.Gender + "}.");
                }
                /*****************************************************************************************************************************************/

                if (!detail.IsVaild)
                    --IndividualDetailVaildCount;
          
            }

            foreach (DotexNonIndividualDetail detail in m_DotexNonIndividualDetailRecords)
            {
                ValidationResult l_objVresult = Utility.ValidateRecord(detail, ValidationGroup.RequiredField);
                detail.IsVaild = l_objVresult.IsValid;
                if (!detail.IsVaild)
                {
                    foreach (var field in l_objVresult.InvaildFields)
                    {
                        this.AddToValidationSummary(field.Value, detail.ClientInstance, field.Value + " is mandatory.");
                    }
                }

                detail.IsVaild = CompareValidate(detail.ClientInstance.PanExempt, "Y", detail.PANExemptionEvidence, "PANExemptionEvidence", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.ClientInstance.PanExempt, "N", detail.PAN, "PAN", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.Status, "99", detail.StatusOther, "StatusOther", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.CorrAddState, "99", detail.CorrAddStateOther, "CorrAddStateOther", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.ProofofAddressCorrAddress, "99", detail.ProofofAddressCorrAddressOther, "ProofofAddressCorrAddressOther", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.IsSameAsCorrespondence, "N", detail.RegisteredAddress1, "RegisteredAddress1", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.IsSameAsCorrespondence, "N", detail.RegAddPINCode, "RegAddPINCode", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.IsSameAsCorrespondence, "N", detail.RegAddState, "RegAddState", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.IsSameAsCorrespondence, "N", detail.RegAddCountry, "RegAddCountry", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.RegAddState, "99", detail.RegAddStateOther, "RegAddStateOther", detail.ClientInstance, detail.IsVaild);
                detail.IsVaild = CompareValidate(detail.ProofofRegAddress, "99", detail.ProofofRegAddressOther, "ProofofRegAddressOther", detail.ClientInstance, detail.IsVaild);

            
                foreach (PromoterDetail pDetail in detail.PromoterDetailList)
                {
                    ValidationResult l_objVresultPromoDetail = Utility.ValidateRecord(pDetail, ValidationGroup.RequiredField);
                    pDetail.IsVaild = l_objVresultPromoDetail.IsValid;
                    if (!pDetail.IsVaild)
                    {
                        detail.IsVaild = false;

                        foreach (var field in l_objVresultPromoDetail.InvaildFields)
                        {
                            this.AddToValidationSummary(field.Value, detail.ClientInstance, field.Value + " is mandatory in Promoter Detail section.");
                        }
                    }
                    pDetail.IsVaild = CompareValidate(detail.ClientInstance.PanExempt, "Y", pDetail.PANExemptionEvidence, "PANExemptionEvidence (Promoter Detail)", detail.ClientInstance, pDetail.IsVaild);
                    pDetail.IsVaild = CompareValidate(pDetail.RelationshipWithApplicant, "99", pDetail.RelationshipWithApplicantOther, "RelationshipWithApplicantOther", detail.ClientInstance, pDetail.IsVaild);
                    pDetail.IsVaild = CompareValidate(pDetail.RegAddState, "99", pDetail.RegAddStateOther, "RegAddStateOther (Promoter Detail)", detail.ClientInstance, pDetail.IsVaild);

                    if (detail.IsVaild)
                        detail.IsVaild = pDetail.IsVaild;

                    pDetail.IsVaild = detail.IsVaild;
                }

                if (!detail.IsVaild)
                    --NonIndividualDetailVaildCount;

            }

            return this.DtValidationResult;
        }
    }
}