﻿using System;
using System.Data;
using System.Text;
using System.Collections;
using System.Collections.Generic;

using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;

namespace UCC.Class.KRA
{
    /// <summary>
    /// Singleton class for storing static codes from tb_UCCKRAReferenceMapping table 
    /// </summary>
    public class CKRAReferenceDataProvider
    {
        #region variables

        private List< CKRAReferenceData> m_lstKRARefData;
        private static CKRAReferenceDataProvider m_Instance;
        
        #endregion

        #region Constructors

        /// <summary>
        /// Intializes map
        /// </summary>
        private CKRAReferenceDataProvider()
        {
            m_lstKRARefData = new List<CKRAReferenceData>();
            Initialize();
        }

        static CKRAReferenceDataProvider()
        {
            m_Instance = new CKRAReferenceDataProvider();
        }

       

        #endregion

        #region properties 

        /// <summary>
        /// Singleton instance of CKRAReferenceDataProvider
        /// </summary>
        public static CKRAReferenceDataProvider Instance
        {
            get { return m_Instance; }
        }

        /// <summary>
        /// Indexer to get respective KRAReferenceData object
        /// </summary>
        /// <param name="KRAType">KRA Agency Type</param>
        /// <param name="nUCCRefNo">UCC Reference No</param>
        /// <returns></returns>
        public CKRAReferenceData this[KRAAgencyEnum KRAType,int nUCCRefNo]
        {
            get
            {
                  return m_lstKRARefData.Find(item => item.KRAType == KRAType && item.UCCRefNo == nUCCRefNo);
            }
        }


        /// <summary>
        /// Indexer to get respective KRAReferenceData object
        /// </summary>
        /// <param name="KRAType">KRA Agency Type</param>
        /// <param name="nUCCRefNo">UCC Reference No</param>
        /// <returns></returns>
        public CKRAReferenceData this[KRAAgencyEnum KRAType, string refCode, string RefType]
        {
            get
            {
                return m_lstKRARefData.Find(item => item.KRAType == KRAType && item.SRefCodeMaster == refCode && item.SRefType == RefType);
            }
        }

        #endregion

        /// <summary>
        /// Initializes KRA Reference data collection.
        /// </summary>
        private void Initialize()
        {
            if (m_Instance != null)
                return;

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetKRAReferenceData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;
        
            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                {
                    Logger.Instance.WriteLog(this, "No  KRA Reference data found. Proc: stp_GetKRAReferenceData");
                    return;
                }

                DataTable l_dtRefData = l_dsReturnData.Tables[0];

                try
                {   //Populating m_dicKRARefData Dictionary from returned DataTable
                    for (int l_iRowCounter = 0; l_iRowCounter < l_dtRefData.Rows.Count; l_iRowCounter++)
                    {
                        CKRAReferenceData objRefData = new CKRAReferenceData();
                        objRefData.KRAType =  (KRAAgencyEnum)Convert.ToInt32(l_dtRefData.Rows[l_iRowCounter]["n_KRAAgencyNo"]);
                        objRefData.SRefCode = Convert.ToString(l_dtRefData.Rows[l_iRowCounter]["s_KRARefCode"]);
                        objRefData.UCCRefNo = Convert.ToInt32(l_dtRefData.Rows[l_iRowCounter]["n_ReferenceNo"]);
                        objRefData.SRefType = Convert.ToString(l_dtRefData.Rows[l_iRowCounter]["s_ReferenceType"]);
                        objRefData.SRefCodeMaster = Convert.ToString(l_dtRefData.Rows[l_iRowCounter]["s_ReferenceCode"]);

                        m_lstKRARefData.Add( objRefData);

                    }

                }
                catch (Exception ex)
                {
                    Logger.Instance.WriteLog(this,
                        "Error initializing  KRA Reference data. " + ex.ToString());
                }
            }
            else
            {
                Logger.Instance.WriteLog(this, l_objDbWorkItem.ExecutionStatus);
            }

        }
    }
}