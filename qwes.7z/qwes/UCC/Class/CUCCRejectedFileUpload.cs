using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using MatchCommon;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;

/// <summary>
///===================================================================================================
/// File/Class/Custom Name    : CUCCRejectedFileUpload.cs
/// Modified for CR No.       : CR993
/// Modified By               : Shantanu S
/// Date of Modified          : 20/11/2013
/// Modification Reason       : UCC response file upload for BSE exchange added.  
/// Modified By               : Shantanu S
/// Date of Modified          : 19/03/2014
/// Modification Reason       : Changes done for CR964. Record Type ComboBox added for NSE New/Modified file upload. 
///===================================================================================================
/// </summary>

namespace UCC.Class
{
    /// <summary>
    /// BL class of UCC exchange rejected file upload screen
    /// </summary>
    class CUCCRejectedFileUpload
    {
        /// <summary>
        /// Retrieves master details for file upload screen
        /// </summary>
        /// <param name="p_rdsUCCLookUpData">Retudn master data</param>
        /// <returns>Method Execution Result</returns>
        #region GetLookupData
        public MethodExecResult GetLookupData(ref DataSet p_rdsUCCLookUpData)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCRejectedFileUpload_LookupData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;

                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                {
                    return new MethodExecResult(1, "No data found", "stp_UCCRejectedFileUpload_LookupData. Database returned no data. UserNo. 0", null);
                }
                else
                {
                    p_rdsUCCLookUpData = l_dsReturnData;
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        }
        #endregion

        /// <summary>
        /// Uploads rejection file data to database
        /// </summary>
        /// <param name="p_vdsFileData">DataSet containing the rejection data</param>
        /// <param name="p_viExchangeNo">Exchange No for which rejection data is uploading</param>
        /// <param name="p_rdsResultData">Result DataSet with upload remarks</param>
        /// <returns>Method Execution Result</returns>
        #region UploadData
        public MethodExecResult UploadData(DataSet p_vdsFileData, int p_viExchangeNo, DateTime p_vdtDate, int p_viBatchNo, ref DataSet p_rdsResultData,ExchangeType  l_objExchangeType, string p_vsRecType)   //CR964
        {
            string l_sProc;
            if (l_objExchangeType == ExchangeType.NSE)
                l_sProc = "stp_UCCRejectedFileUploadNSE";
            else if (l_objExchangeType == ExchangeType.BSE)   //CR993
                l_sProc = "stp_UCCRejectedFileUploadBSE";
            else
                l_sProc = "stp_UCCRejectedFileUpload";

            DbWorkItem l_objDbWorkItem = new DbWorkItem(l_sProc);
            l_objDbWorkItem.ResultType = QueryType.DataSet;
            l_objDbWorkItem.InputData = p_vdsFileData;
            l_objDbWorkItem.AddParameter("@pn_ExchangeNo", SqlDbType.Int, p_viExchangeNo);
            l_objDbWorkItem.AddParameter("@pd_Date", SqlDbType.DateTime, p_vdtDate.Date);
            l_objDbWorkItem.AddParameter("@pn_BatchNo", SqlDbType.Int, p_viBatchNo);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);
            if (l_objExchangeType == ExchangeType.NSE)
                l_objDbWorkItem.AddParameter("@ps_RecordType", SqlDbType.VarChar, p_vsRecType);       //CR964

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;

                if ((l_dsReturnData != null) && (l_dsReturnData.Tables.Count > 0))
                {
                    p_rdsResultData = l_dsReturnData;
                }
            }

            return l_objDbWorkItem.ExecutionStatus;
        }
        #endregion

        #region CheckForFileAlreadyUploaded
        /// <summary>
        /// Check the UCC response file for said exchange is already uploaded or not 
        /// </summary>
        /// <param name="p_viExchangeNo"> ExchangeNo</param>
        /// <param name="p_viBatchNo">UCC exported batch no</param>
        /// <param name="p_viReturnCode">ref Return code</param>
        /// <returns>MethodExecResult</returns>
        public MethodExecResult CheckForFileAlreadyUploaded(int p_viExchangeNo, int p_viBatchNo, ref int p_viReturnCode, 
            ExchangeType l_objExchangeType, string p_vsRecType, DateTime p_vDate)
        {
            string l_sRecordType = "ALL";  //CR964
            if (l_objExchangeType == ExchangeType.NSE && p_vsRecType == "M")
                l_sRecordType = "NSEM";

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCRejectedFileUpload_LookupData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;
            l_objDbWorkItem.AddParameter("@Pn_OpType", SqlDbType.Int, 2);
            l_objDbWorkItem.AddParameter("@Pn_ExNo", SqlDbType.Int, p_viExchangeNo);
            l_objDbWorkItem.AddParameter("@Pn_BatchNo", SqlDbType.Int, p_viBatchNo);
            l_objDbWorkItem.AddParameter("@Ps_RecordType", SqlDbType.VarChar, l_sRecordType);    //CR964
            l_objDbWorkItem.AddParameter("@Pd_Date", SqlDbType.DateTime, p_vDate);    //CR964

            
            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;

                if ((l_dsReturnData != null) && (l_dsReturnData.Tables.Count > 0))
                {
                    p_viReturnCode = l_dsReturnData.Tables[0].Rows.Count;
                }
            }
            return l_objDbWorkItem.ExecutionStatus;
        }
        #endregion

    }
}
