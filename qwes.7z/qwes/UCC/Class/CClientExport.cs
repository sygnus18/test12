﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;

using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Utils;

namespace UCC.Class
{
    /// <summary>
    /// Structure defining export filter parameters
    /// </summary>
    #region ExportFilterParameters (class)
    public class ExportFilterParameters
    {
        private DateTime _FromDate;
        /// <summary>
        /// Export From Date
        /// </summary>
        public DateTime FromDate
        {
            get { return _FromDate; }
            set { _FromDate = value; }
        }

        private DateTime _ToDate;
        /// <summary>
        /// Export To Date
        /// </summary>
        public DateTime ToDate
        {
            get { return _ToDate; }
            set { _ToDate = value; }
        }

        private string _CompanyCode;
        /// <summary>
        /// Company Code
        /// </summary>
        public string CompanyCode
        {
            get { return _CompanyCode; }
            set { _CompanyCode = value; }
        }

        private int _ExchangeNo;
        /// <summary>
        /// Exchange No
        /// </summary>
        public int ExchangeNo
        {
            get { return _ExchangeNo; }
            set { _ExchangeNo = value; }
        }

        private string _ClientCode;
        /// <summary>
        /// Client Code
        /// </summary>
        public string ClientCode
        {
            get { return _ClientCode; }
            set { _ClientCode = value; }
        }

        private int _BatchNo;
        /// <summary>
        /// Batch No
        /// </summary>
        public int BatchNo
        {
            get { return _BatchNo; }
            set { _BatchNo = value; }
        }

        private string _ExportType;
        /// <summary>
        /// Export Type (Full/Incremental)
        /// </summary>
        public string ExportType
        {
            get { return _ExportType; }
            set { _ExportType = value; }
        }

        //CR964
        private string _RecordType;
        /// <summary>
        /// Export Type (Full/Incremental)
        /// </summary>
        public string RecordType
        {
            get { return _RecordType; }
            set { _RecordType = value; }
        }

        private string _ExchangeCode;
        /// <summary>
        /// Exchange code
        /// </summary>
        public string ExchangeCode
        {
            get { return _ExchangeCode; }
            set { _ExchangeCode = value; }
        }

        private string _FilePath;
        /// <summary>
        /// Export file path
        /// </summary>
        public string FilePath
        {
            get { return _FilePath; }
            set { _FilePath = value; }
        }

        private string _FileName;
        /// <summary>
        /// Export file name
        /// </summary>
        public string FileName
        {
            get { return _FileName; }
            set { _FileName = value; }
        }
        
    }
    #endregion

    /// <summary>
    /// This BL class of frmClientExport facilitates UCC data export
    /// </summary>
    class CClientExport
    {
        /// <summary>
        /// Deleted directors column name
        /// </summary>
        public readonly string DeletedDirectorsColName = "n_DelDirRowNo";

        /// <summary>
        /// This method retrieves/re-exports UCC data.
        /// If Batch No is specified in filter parameters, 
        ///     it retrieves exported data for said Date, Exchange and Batch No and exports to file
        /// If Batch No is not specified in filter parameters, 
        ///     it retrieves UCC data applying filters and returns to caller
        /// </summary>
        /// <param name="FilterParams">Filter parameters</param>
        /// <param name="UCCData">Return UCC Data</param>
        /// <returns>Method Execution Result</returns>
        #region RetrieveUCCData
        public MethodExecResult RetrieveUCCData(ExportFilterParameters FilterParams, ref DataTable UCCData)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_ClientUCCExport");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@Pd_FromDate", SqlDbType.DateTime, FilterParams.FromDate.Date);
            l_objDbWorkItem.AddParameter("@Pd_ToDate", SqlDbType.DateTime, FilterParams.ToDate.Date);
            if (FilterParams.CompanyCode == string.Empty)
                l_objDbWorkItem.AddParameter("@Ps_CompanyCode", SqlDbType.VarChar, null);
            else
                l_objDbWorkItem.AddParameter("@Ps_CompanyCode", SqlDbType.VarChar, FilterParams.CompanyCode);
            if (FilterParams.ExchangeNo == 0)
                l_objDbWorkItem.AddParameter("@Pn_ExNo", SqlDbType.Int, null);
            else
                l_objDbWorkItem.AddParameter("@Pn_ExNo", SqlDbType.Int, FilterParams.ExchangeNo);
            if (FilterParams.ClientCode == string.Empty)
                l_objDbWorkItem.AddParameter("@Ps_ClientCode", SqlDbType.VarChar, null);
            else
                l_objDbWorkItem.AddParameter("@Ps_ClientCode", SqlDbType.VarChar, FilterParams.ClientCode);
            if (FilterParams.BatchNo == 0)
                l_objDbWorkItem.AddParameter("@Pn_BatchNo", SqlDbType.Int, null);
            else
                l_objDbWorkItem.AddParameter("@Pn_BatchNo", SqlDbType.Int, FilterParams.BatchNo);
            l_objDbWorkItem.AddParameter("@Ps_ExportType", SqlDbType.VarChar, FilterParams.ExportType);
            l_objDbWorkItem.AddParameter("@Ps_RecordType", SqlDbType.VarChar, FilterParams.RecordType);   //CR964
            //l_objDbWorkItem.AddParameter("@UserNo", SqlDbType.VarChar, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0) || (l_dsReturnData.Tables[0].Rows.Count == 0))
                {
                    return new MethodExecResult(1, "No data found", "stp_ClientUCCExport. Database returned no data. UserNo. " + AppEnvironment.AppUser.UserNo, null);
                }
                else
                {
                    UCCData = l_dsReturnData.Tables[0];

                    //if Batch No provided, ReExport from here only
                    if (FilterParams.BatchNo > 0)
                    {
                        ExportUCCData(FilterParams, UCCData);
                    }

                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        }
        #endregion

        /// <summary>
        /// This method re-exports given exported UCC data
        /// </summary>
        /// <param name="p_vsFileNameWithPath">Destination file name with path</param>
        /// <param name="p_vdtUCCData">UCC data</param>
        /// <returns>Method Execution Result</returns>
        #region ReExportDataToFile
        private MethodExecResult ReExportUCCData(string p_vsFileNameWithPath, DataTable p_vdtUCCData)
        {
            int l_iRowCounter = 0;

            try
            {
                using (StreamWriter l_swOutFile = new StreamWriter(p_vsFileNameWithPath))
                {
                    for (l_iRowCounter = 0; l_iRowCounter < p_vdtUCCData.Rows.Count; l_iRowCounter++)
                    {
                        l_swOutFile.WriteLine(p_vdtUCCData.Rows[l_iRowCounter]["s_Data"].ToString());
                    }

                    l_swOutFile.Close();
                }
            }
            catch (Exception ex)
            {
                return new MethodExecResult(1, ex.Message,
                    "Error exporting UCC data to file. " + ex.Message + ". File: " + p_vsFileNameWithPath
                     + ", Line: " + l_iRowCounter.ToString(), ex);
            }

            return new MethodExecResult(MethodExecResult.SuccessfulReturnCode);
        }
        #endregion

        /// <summary>
        /// This method exports given UCC data to file.
        /// Sequence of process
        ///     1. Prepare destination File name calling database procedure
        ///     2. If re-export, export data to destination file and skip all below steps, Otherwise continue
        ///     2. Get Header data applicable to current export, if any, by calling database procedure
        ///     3. Export data to destination file on disc
        ///     4. Upload exported file data to database
        ///     5. Update exported UCC data status to database
        /// </summary>
        /// <param name="FilterParams">Filter parameters</param>
        /// <param name="UCCData">UCC Data</param>
        /// <returns>Method Execution Result</returns>
        #region ExportUCCData
        public MethodExecResult ExportUCCData(ExportFilterParameters FilterParams, DataTable UCCData)
        {
            if (UCCData == null)
                return new MethodExecResult(1, "Input data cannot be null", "UCC Input DataTable found to be null.", null);

            DataTable l_dtUCCData = UCCData;

            string l_sFileName = string.Empty;
            int l_iBatchNo = FilterParams.BatchNo;
            string l_sRecordType = "ALL";
            string l_sExType = FilterParams.ExchangeCode;
            DataTable dtExch = CMastersDataProvider.Instance[Masters.Exchange];
            if (dtExch != null)
            {
                for (int i = 0; i < dtExch.Rows.Count; i++)
                {
                    if (dtExch.Rows[i]["s_ExCode"].ToString().Trim() == FilterParams.ExchangeCode)
                    {
                        l_sExType = dtExch.Rows[i]["s_ExType"].ToString().Trim();
                        break;
                    }
                }
            }
            if (l_sExType == "NSE" && FilterParams.RecordType == "M")
                l_sRecordType = "NSEM";

            MethodExecResult l_objMethodExecResult = GetUCCExportFileNameAndBatchNo(
                FilterParams.ExchangeNo, ref l_sFileName, ref l_iBatchNo, l_sRecordType);
            if (l_objMethodExecResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
                return l_objMethodExecResult;

            string l_sFileNameWithPath = Path.Combine(FilterParams.FilePath, l_sFileName);

            FilterParams.FileName = l_sFileName;

            //ReExport
            if (FilterParams.BatchNo > 0)
            {
                return ReExportUCCData(l_sFileNameWithPath, UCCData);
            }
            else
            {
                FilterParams.BatchNo = l_iBatchNo;

                DataTable l_dtHeaderData = new DataTable();
                l_objMethodExecResult = GetHeaderData(FilterParams.ExchangeNo, l_iBatchNo, l_dtUCCData.Rows.Count, ref l_dtHeaderData);
                if (l_objMethodExecResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
                    return l_objMethodExecResult;

                l_objMethodExecResult = ExportDataToFile(l_sFileNameWithPath, l_dtUCCData, l_dtHeaderData);
                if (l_objMethodExecResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
                    return l_objMethodExecResult;

                l_objMethodExecResult = ImportExportedDataToDb(l_sFileNameWithPath,
                    FilterParams.ExchangeNo, CMatchCommonUtils.Instance.ServerDate.Date, l_iBatchNo);
                if (l_objMethodExecResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
                    return l_objMethodExecResult;

                l_objMethodExecResult = UpdateExportedDataStatusToDb(l_iBatchNo, UCCData);
                if (l_objMethodExecResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
                    return l_objMethodExecResult;

                return l_objMethodExecResult;
            }
        }
        #endregion
        
        /// <summary>
        /// This method prepares export file name via database procedure
        /// </summary>
        /// <param name="p_viExchangeNo">Exchange No</param>
        /// <param name="p_rsFileName">Return file name</param>
        /// <param name="p_riBatchNo">Return Batch No</param>
        /// <returns>Method Execution Result</returns>
        #region GetUCCExportFileNameAndBatchNo
        private MethodExecResult GetUCCExportFileNameAndBatchNo(int p_viExchangeNo, ref string p_rsFileName, ref int p_riBatchNo, string p_sRecordType)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetUCCExportFileName");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@pn_ExNo", SqlDbType.Int, p_viExchangeNo);
            l_objDbWorkItem.AddParameter("@pd_Date", SqlDbType.DateTime, CMatchCommonUtils.Instance.ServerDate.Date);
            l_objDbWorkItem.AddParameter("@pn_BatchNo", SqlDbType.Int, p_riBatchNo);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);
            l_objDbWorkItem.AddParameter("@ps_BatchType", SqlDbType.VarChar, p_sRecordType);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsResult = l_objDbWorkItem.Result as DataSet;
                if ((l_dsResult == null) || (l_dsResult.Tables.Count == 0))
                {
                    return new MethodExecResult(1, "Database returned no data.", "stp_GetUCCExportFileName. Database returned no data. Exchange: "
                        + p_viExchangeNo.ToString() + ", Date: " + CMatchCommonUtils.Instance.ServerDate.Date.ToString(), null);
                }
                else
                {
                    int l_iBatchNo;
                    try
                    {
                        if (int.TryParse(l_dsResult.Tables[0].Rows[0]["n_BatchNo"].ToString(), out l_iBatchNo) == false)
                            return new MethodExecResult(2, "Batch no parsing failed.", "stp_GetClientUCCExportBatchNo. Parsing to Integer failed. Value: " + l_iBatchNo.ToString()
                                + ", Exchange: " + p_viExchangeNo.ToString() + ", Date: " + CMatchCommonUtils.Instance.ServerDate.Date.ToString(), null);
                        p_riBatchNo = l_iBatchNo;
                        p_rsFileName = l_dsResult.Tables[0].Rows[0]["s_FileName"].ToString();
                    }
                    catch (Exception ex)
                    {
                        return new MethodExecResult(2, "Exception parsing File name/Batch No." + Environment.NewLine + ex.Message,
                            "Exception parsing File name/Batch No." + Environment.NewLine + ex.Message, ex);
                    }

                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        }
        #endregion

        /// <summary>
        /// This method retrieves header data applicable to current export via calling database procedure
        /// </summary>
        /// <param name="p_viExNo">Exchange No as selected by user</param>
        /// <param name="p_viBatchNo">Batch No as generated</param>
        /// <param name="p_viRecordCount">Total number of records to be exported</param>
        /// <param name="p_rdtHeaderData">Return data table containing header rows</param>
        /// <returns>Method Execution Result</returns>
        #region GetHeaderData
        private MethodExecResult GetHeaderData(int p_viExNo, int p_viBatchNo, int p_viRecordCount, ref DataTable p_rdtHeaderData)
        {
            DataTable l_dtInputData = new DataTable("#InputDetails");
            l_dtInputData.Columns.Add("n_RecordCount", typeof(int));
            l_dtInputData.Columns.Add("n_BatchNo", typeof(int));

            l_dtInputData.Columns["n_RecordCount"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, "");
            l_dtInputData.Columns["n_BatchNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, "");

            l_dtInputData.Rows.Add(new object[] { p_viRecordCount, p_viBatchNo });

            DataSet l_dsInputData = new DataSet();
            l_dsInputData.Tables.Add(l_dtInputData);

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetUCCExportHeaderData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;
            l_objDbWorkItem.InputData = l_dsInputData;

            l_objDbWorkItem.AddParameter("@pn_ExNo", SqlDbType.Int, p_viExNo);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.VarChar, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

            DataSet l_dsReturn = l_objDbWorkItem.Result as DataSet;
            if (
                (l_dsReturn != null)
                && (l_dsReturn.Tables.Count > 0)
                )
            {
                p_rdtHeaderData = l_dsReturn.Tables[0];
            }

            return l_objDbWorkItem.ExecutionStatus;
        }
        #endregion

        /// <summary>
        /// This method writes UCC data with header in disc file
        /// </summary>
        /// <param name="ExchangeCode">Exchange code</param>
        /// <param name="FileNameWithPath">Destination file name with path</param>
        /// <param name="UCCData">UCC Data</param>
        /// <param name="UCCHeaderData">UCC Header Data</param>
        /// <returns>Method Execution Result</returns>
        #region ExportDataToFile
        private MethodExecResult ExportDataToFile(string FileNameWithPath, DataTable UCCData, DataTable UCCHeaderData)
        {
            string l_sSeperator = "|";

            int l_iRowCounter = 0, l_iHeaderRowCounter = 0;
            try
            {
                bool l_bColCountEnabled = false;
                int l_iDataColStartIndex = 0;
                if (UCCData.Columns.Count > 0 && UCCData.Columns[0].ColumnName == "n_ColCount")
                {
                    l_bColCountEnabled = true;
                    l_iDataColStartIndex = 1;
                }
                Int16 l_iColCount = Convert.ToInt16(UCCData.Columns.Count);

                using (StreamWriter l_swOutFile = new StreamWriter(FileNameWithPath))
                {
                    //Write Header
                    if (
                        (UCCHeaderData != null)
                        &&
                        (UCCHeaderData.Rows.Count > 0)
                        &&
                        (UCCHeaderData.Columns.Contains("s_HData"))
                       )
                    {
                        for (l_iHeaderRowCounter = 0; l_iHeaderRowCounter < UCCHeaderData.Rows.Count; l_iHeaderRowCounter++)
                        {
                            l_swOutFile.WriteLine(UCCHeaderData.Rows[l_iHeaderRowCounter]["s_HData"].ToString());
                        }
                    }                    

                    //Write Detail
                    for (l_iRowCounter = 0; l_iRowCounter < UCCData.Rows.Count; l_iRowCounter++)
                    {
                        object[] objDataArray = UCCData.Rows[l_iRowCounter].ItemArray;
                        
                        if(l_bColCountEnabled)
                            l_iColCount = Convert.ToInt16(UCCData.Rows[l_iRowCounter][0]);
                        string[] l_sDataStrArray = new string[l_iColCount];
                        Array.Copy(objDataArray, l_iDataColStartIndex, l_sDataStrArray, 0, l_iColCount);
                        //objDataArray.CopyTo(l_sDataStrArray, l_iDataColStartIndex);

                        l_swOutFile.WriteLine(string.Join(l_sSeperator, l_sDataStrArray));
                    }

                    l_swOutFile.Close();
                }
            }
            catch (Exception ex)
            {
                return new MethodExecResult(1, ex.Message,
                    "Error exporting UCC data to file. " + ex.Message + ". File: " + FileNameWithPath
                    + ", Line: " + l_iRowCounter.ToString() + ", Header Line: " + l_iHeaderRowCounter.ToString(), ex);
            }

            return new MethodExecResult(MethodExecResult.SuccessfulReturnCode);
        }
        #endregion

        /// <summary>
        /// This method uploads exported data to database.
        /// It reads file data, prepares data table and passes to Db manager to upload data via Bulk upload
        /// </summary>
        /// <param name="FileNameWithPath">Exported file name with path</param>
        /// <param name="p_viExNo">Exchange No</param>
        /// <param name="p_vdtDate">date</param>
        /// <param name="p_viBatchNo">Batch No</param>
        /// <returns>Method Execution Result</returns>
        #region ImportExportedDataToDb
        private MethodExecResult ImportExportedDataToDb(string FileNameWithPath, 
            int p_viExNo, DateTime p_vdtDate, int p_viBatchNo)
        {
            int l_iLineCounter = 0;
            try
            {
                string[] l_sFileData = File.ReadAllLines(FileNameWithPath);

                DataTable l_dtFileData = new DataTable("#FileData");
                l_dtFileData.Columns.Add("n_LineNo", typeof(int));
                l_dtFileData.Columns.Add("s_Line");

                l_dtFileData.Columns["n_LineNo"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, "");
                l_dtFileData.Columns["s_Line"].ExtendedProperties.Add(DbManager.BCPRequiredColumnAttr, "");
                l_dtFileData.Columns["s_Line"].ExtendedProperties.Add(DbManager.ColLengthAttr, "8000");

                for (l_iLineCounter = 0; l_iLineCounter < l_sFileData.Length; l_iLineCounter++)
                    l_dtFileData.Rows.Add(new object[] { l_iLineCounter + 1, l_sFileData[l_iLineCounter] });

                DataSet l_dsInputData = new DataSet();
                l_dsInputData.Tables.Add(l_dtFileData);

                DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_DumpUCCExportedData");
                l_objDbWorkItem.ResultType = QueryType.NonQuery;
                l_objDbWorkItem.InputData = l_dsInputData;

                l_objDbWorkItem.AddParameter("@pn_ExNo", SqlDbType.Int, p_viExNo);
                l_objDbWorkItem.AddParameter("@pd_Date", SqlDbType.DateTime, p_vdtDate.Date);
                l_objDbWorkItem.AddParameter("@pn_BatchNo", SqlDbType.Int, p_viBatchNo);
                l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.VarChar, AppEnvironment.AppUser.UserNo);

                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

                return l_objDbWorkItem.ExecutionStatus;
            }
            catch (Exception ex)
            {
                return new MethodExecResult(1, ex.Message,
                    "Error importing exported UCC data. " + ex.Message + ". File: " + FileNameWithPath
                    + ", Exchange: " + p_viExNo.ToString() + ", Line: " + l_iLineCounter.ToString(), ex);
            }
        }
        #endregion

        /// <summary>
        /// This method updates UCC data status to exported in database via bulk upload
        ///     based on unique field (n_ClientExMapNo) in Exported data table
        /// </summary>
        /// <param name="p_viBatchNo">Batch No</param>
        /// <param name="p_vdtUCCData">UCC Data</param>
        /// <returns>Method Execution Result</returns>
        #region UpdateExportedDataStatusToDb
        private MethodExecResult UpdateExportedDataStatusToDb(int p_viBatchNo, DataTable p_vdtUCCData)
        {
            try
            {
                p_vdtUCCData.Columns["n_ClientExMapNo"].ExtendedProperties[DbManager.BCPRequiredColumnAttr] = "";
                p_vdtUCCData.Columns[DeletedDirectorsColName].ExtendedProperties[DbManager.BCPRequiredColumnAttr] = "";
            }
            catch (Exception ex)
            {
                return new MethodExecResult(1, ex.Message,
                    "Error updating exported status to database." + ex.Message + ". BatchNo: " + p_viBatchNo.ToString(), ex);
            }

            p_vdtUCCData.TableName = "#ExportedData";
            DataSet l_dsInputData = null;
            if (p_vdtUCCData.DataSet == null)
            {
                l_dsInputData = new DataSet();
                l_dsInputData.Tables.Add(p_vdtUCCData);
            }
            else
                l_dsInputData = p_vdtUCCData.DataSet;

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UpdateUCCExportedStatus");
            l_objDbWorkItem.ResultType = QueryType.NonQuery;
            l_objDbWorkItem.InputData = l_dsInputData;

            l_objDbWorkItem.AddParameter("@pn_BatchNo", SqlDbType.Int, p_viBatchNo);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.VarChar, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

            return l_objDbWorkItem.ExecutionStatus;
        }
        #endregion

    }
}
