﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UCC.Class
{
    public class CReferenceMaster
    {
        public CReferenceMaster(int n_ReferenceNo, string ReferenceType,
            string ReferenceCode, string ReferenceName)
        {
            this._ReferenceNo = ReferenceNo;
            this._ReferenceCode = ReferenceCode;
            this._ReferenceName = ReferenceName;
            this._ReferenceType = ReferenceType;
        }

        public int _ReferenceNo;
        public int ReferenceNo
        {
            get { return _ReferenceNo; }
        }

        public string _ReferenceType;
        public string ReferenceType
        {
            get { return _ReferenceType; }
        }

        public string _ReferenceCode;
        public string ReferenceCode
        {
            get { return _ReferenceCode; }
        }

        public string _ReferenceName;
        public string ReferenceName
        {
            get { return _ReferenceName; }
        }
    }
}
