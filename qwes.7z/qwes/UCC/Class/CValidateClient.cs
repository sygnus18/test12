﻿using System;
using System.Collections.Generic;
using System.Text;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using System.Data;

namespace UCC.Class
{
    /// <summary>
    /// Validates client UCC details
    /// </summary>
    class CValidateClient
    {
        /// <summary>
        /// Validates client UCC details for given exchange
        /// </summary>
        /// <param name="ExchangeNo">Exchange No. 0 Indicates all exchanges.</param>
        /// <param name="ClientCode">Client Code. Empty/null value indicates all clients</param>
        /// <param name="ResultData">Validation result</param>
        /// <returns>Method execution result</returns>
        public MethodExecResult ValidateClientUCC(int ExNo, string ClientCode, ref DataSet ResultData)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_ValidateClientUCCDetails");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            if (ExNo == 0)
                l_objDbWorkItem.AddParameter("@pn_ExNo", SqlDbType.Int, null);
            else
                l_objDbWorkItem.AddParameter("@pn_ExNo", SqlDbType.Int, ExNo);

            if (string.IsNullOrEmpty(ClientCode))
                l_objDbWorkItem.AddParameter("@ps_ClientCode", SqlDbType.VarChar, null);
            else
                l_objDbWorkItem.AddParameter("@ps_ClientCode", SqlDbType.VarChar, ClientCode);

            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                ResultData = l_objDbWorkItem.Result as DataSet;
            }

            return l_objDbWorkItem.ExecutionStatus;
        }
    }
}
