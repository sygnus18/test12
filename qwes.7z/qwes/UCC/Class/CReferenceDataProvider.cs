﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;

using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;

namespace UCC.Class
{
    /// <summary>
    /// Provides reference data
    /// </summary>
    public class CReferenceDataProvider
    {
        #region Types

        /// <summary>
        /// Reference Data Fields
        /// </summary>
        #region ReferenceFields (enum)
        public enum ReferenceFields
        {
            ReferenceNo, 
            ReferenceType, 
            ReferenceCode, 
            ReferenceName
        }
        #endregion

        /// <summary>
        /// Type of Reference Data
        /// </summary>
        #region ReferenceType (enum)
        public enum ReferenceType
        {
            ANNINC,
            CATEGORY,
            //CITY,
            CLIENTTYPE,
            COUNTRY,
            EXCH,
            FACILITY,
            GENDER,
            MARITALST,
            NATIONALTY,
            OCCUPATION,
            PEP,
            PROOFTYPE,
            RELATION,
            SEGTYPE,
            STATE,
            STATUS, 
            EXPORTTYPE,
            BANKACCTYP,
            AUTHENTTYP,
            AUTHSTATUS,
            RECORDTYPE,    //CR964
			KRAAGNCYID,
            MAINCLIENTTYPE,
            CDDTYPE_I, 
            CDDTYPE_NI,
            CLIENTSTATUS,
            BrokMethodCode,   //CDD phase 2
            TITLE,
            TaxStatus,
            Branch,
            EDUCATION,
            TITLE2,
            TABTYPE,
            INTTYPE
        }
        #endregion

        #endregion

        #region Variables

        /// <summary>
        /// Singleton instance
        /// </summary>
        private static CReferenceDataProvider m_objInstance;

        /// <summary>
        /// Dictionary to cache Reference data
        /// </summary>
        private Dictionary<ReferenceType, DataTable> m_dicRefData;

        /// <summary>
        /// Indicates if reference data has been initialized
        /// </summary>
        private bool m_bInitialised;

        #endregion

        #region Construcotors

        /// <summary>
        /// Private constructor to restrict instance creation
        /// </summary>
        private CReferenceDataProvider() 
        { 
            m_dicRefData = new Dictionary<ReferenceType,DataTable>();
        }

        /// <summary>
        /// Static constructor to initialize singleton instance
        /// </summary>
        static CReferenceDataProvider()
        {
            m_objInstance = new CReferenceDataProvider();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Returns Singleton instance
        /// </summary>
        #region Instance
        public static CReferenceDataProvider Instance
        {
            get
            {
               
                if (m_objInstance == null)
                    m_objInstance = new CReferenceDataProvider();

                return m_objInstance;
            }
        }
        #endregion

        #region this [ReferenceType]
        public DataTable this[ReferenceType RefType]
        {
            get
            {
                if (m_bInitialised == false)
                    Initialise();

                if (m_dicRefData.ContainsKey(RefType))
                    return m_dicRefData[RefType];
                return null;
            }
        }
        #endregion

        #endregion

        #region Methods

        /// <summary>
        /// Returns HashTable containing reference data with provided Key/Value
        /// </summary>
        /// <param name="RefType">Reference Type</param>
        /// <param name="DisplayField">Display Field. HashTable Value.</param>
        /// <param name="ValueField">Value Field. HashTable Key.</param>
        /// <returns>HashTable containing reference data</returns>
        #region GetHashTable
        public Hashtable GetHashTable(ReferenceType RefType, ReferenceFields DisplayField, ReferenceFields ValueField)
        {
            if (m_bInitialised == false)
                Initialise();

            if (m_dicRefData.ContainsKey(RefType))
            {
                string l_sDisplayField = string.Empty, l_sValueField = string.Empty;
                switch (DisplayField)
                {
                    case ReferenceFields.ReferenceNo:
                        l_sDisplayField = "n_ReferenceNo";
                        break;
                    case ReferenceFields.ReferenceCode:
                        l_sDisplayField = "s_ReferenceCode";
                        break;
                    case ReferenceFields.ReferenceName:
                        l_sDisplayField = "s_ReferenceName";
                        break;
                    case ReferenceFields.ReferenceType:
                        l_sDisplayField = "s_ReferenceType";
                        break;
                }
                switch (ValueField)
                {
                    case ReferenceFields.ReferenceNo:
                        l_sValueField = "n_ReferenceNo";
                        break;
                    case ReferenceFields.ReferenceCode:
                        l_sValueField = "s_ReferenceCode";
                        break;
                    case ReferenceFields.ReferenceName:
                        l_sValueField = "s_ReferenceName";
                        break;
                    case ReferenceFields.ReferenceType:
                        l_sValueField = "s_ReferenceType";
                        break;
                }

                Hashtable l_hstKeyValue = new Hashtable();
                DataTable l_dtCurrentRefData = m_dicRefData[RefType];
                for(int l_iRowCounter = 0; l_iRowCounter < l_dtCurrentRefData.Rows.Count; l_iRowCounter++)
                {
                    l_hstKeyValue.Add(l_dtCurrentRefData.Rows[l_iRowCounter][l_sValueField].ToString(),
                        l_dtCurrentRefData.Rows[l_iRowCounter][l_sDisplayField].ToString());
                }

                return l_hstKeyValue;
            }
            return null;
        }
        #endregion

        /// <summary>
        /// Initializes reference data
        /// </summary>
        #region Initialise
        private void Initialise()
        {
            if (m_bInitialised)
                return;

            m_bInitialised = true;

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetReferenceData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.VarChar, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                {
                    Logger.Instance.WriteLog(this,
                        "No reference data found. Proc: stp_GetReferenceData");
                    return;
                }

                DataTable l_dtRefData = l_dsReturnData.Tables[0];

                try
                {
                    for (int l_iRowCounter = 0; l_iRowCounter < l_dtRefData.Rows.Count; l_iRowCounter++)
                    {
                        ReferenceType l_objCurrentRowRefType = ReferenceType.ANNINC;
                        bool l_bRefTypeExists = true;
                        switch (l_dtRefData.Rows[l_iRowCounter]["s_ReferenceType"].ToString())
                        {
                            case "ANNINC":
                                l_objCurrentRowRefType = ReferenceType.ANNINC;
                                break;
                            case "CATEGORY":
                                l_objCurrentRowRefType = ReferenceType.CATEGORY;
                                break;
                            //case "CITY":
                            //    l_objCurrentRowRefType = ReferenceType.CITY;
                            //    break;
                            case "CLIENTTYPE":
                                l_objCurrentRowRefType = ReferenceType.CLIENTTYPE;
                                break;
                            case "COUNTRY":
                                l_objCurrentRowRefType = ReferenceType.COUNTRY;
                                break;
                            case "EXCH":
                                l_objCurrentRowRefType = ReferenceType.EXCH;
                                break;
                            case "FACILITY":
                                l_objCurrentRowRefType = ReferenceType.FACILITY;
                                break;
                            case "GENDER":
                                l_objCurrentRowRefType = ReferenceType.GENDER;
                                break;
                            case "MARITALST":
                                l_objCurrentRowRefType = ReferenceType.MARITALST;
                                break;
                            case "NATIONALTY":
                                l_objCurrentRowRefType = ReferenceType.NATIONALTY;
                                break;
                            case "OCCUPATION":
                                l_objCurrentRowRefType = ReferenceType.OCCUPATION;
                                break;
                            case "PEP":
                                l_objCurrentRowRefType = ReferenceType.PEP;
                                break;
                            case "PROOFTYPE":
                                l_objCurrentRowRefType = ReferenceType.PROOFTYPE;
                                break;
                            case "RELATION":
                                l_objCurrentRowRefType = ReferenceType.RELATION;
                                break;
                            case "SEGTYPE":
                                l_objCurrentRowRefType = ReferenceType.SEGTYPE;
                                break;
                            case "STATE":
                                l_objCurrentRowRefType = ReferenceType.STATE;
                                break;
                            case "STATUS":
                                l_objCurrentRowRefType = ReferenceType.STATUS;
                                break;
                            case "EXPORTTYPE":
                                l_objCurrentRowRefType = ReferenceType.EXPORTTYPE;
                                break;
                            case "BANKACCTYP":
                                l_objCurrentRowRefType = ReferenceType.BANKACCTYP;
                                break;
                            case "AUTHENTTYP":
                                l_objCurrentRowRefType = ReferenceType.AUTHENTTYP;
                                break;
                            case "AUTHSTATUS":
                                l_objCurrentRowRefType = ReferenceType.AUTHSTATUS;
                                break;
                            case "RECORDTYPE":   //CR964
                                l_objCurrentRowRefType = ReferenceType.RECORDTYPE;
                                break;
                            case "KRAAGNCYID":   //CR964
                                l_objCurrentRowRefType = ReferenceType.KRAAGNCYID;
                                break;
                            case "MAINCLIENTTYPE":   
                                l_objCurrentRowRefType = ReferenceType.MAINCLIENTTYPE;
                                break;
                            case "CLIENTSTATUS":   
                                l_objCurrentRowRefType = ReferenceType.CLIENTSTATUS;
                                break;
                            case "CDDTYPE_I":
                                l_objCurrentRowRefType = ReferenceType.CDDTYPE_I;
                                break;
                            case "CDDTYPE_NI":
                                l_objCurrentRowRefType = ReferenceType.CDDTYPE_NI;
                                break;
                            case "BrokMethodCode":
                                l_objCurrentRowRefType = ReferenceType.BrokMethodCode;
                                break;
                            case "TITLE":
                                l_objCurrentRowRefType = ReferenceType.TITLE;   
                                break;
                            case "TaxStatus":
                                l_objCurrentRowRefType = ReferenceType.TaxStatus;  
                                break;
                            case "Branch":
                                l_objCurrentRowRefType = ReferenceType.Branch; 
                                break;
                            case "EDUCATION":
                                l_objCurrentRowRefType = ReferenceType.EDUCATION;   //TaxStatus
                                break;
                            case "TITLE2":
                                l_objCurrentRowRefType = ReferenceType.TITLE2;   //TaxStatus
                                break;
                            case "TABTYPE":
                                l_objCurrentRowRefType = ReferenceType.TABTYPE;   //TABTYPE
                                break;
                            case "INTTYPE":
                                l_objCurrentRowRefType = ReferenceType.INTTYPE;   //Introducer Type
                                break;
                            default:
                                l_bRefTypeExists = false;
                                break;
                        }

                        if (l_bRefTypeExists == false)
                            continue;

                        DataTable l_dtCurrentRefData = null;
                        if (m_dicRefData.ContainsKey(l_objCurrentRowRefType))
                            l_dtCurrentRefData = m_dicRefData[l_objCurrentRowRefType];
                        else
                        {
                            l_dtCurrentRefData = new DataTable(l_objCurrentRowRefType.ToString());
                            l_dtCurrentRefData.Columns.Add("n_ReferenceNo");
                            l_dtCurrentRefData.Columns.Add("s_ReferenceType");
                            l_dtCurrentRefData.Columns.Add("s_ReferenceCode");
                            l_dtCurrentRefData.Columns.Add("s_ReferenceName");

                            //if (l_objCurrentRowRefType.ToString() == "ANNINC")
                                l_dtCurrentRefData.Columns.Add("s_ReferenceSubType");

                            m_dicRefData.Add(l_objCurrentRowRefType, l_dtCurrentRefData);
                        }

                        l_dtCurrentRefData.ImportRow(l_dtRefData.Rows[l_iRowCounter]);
                    } //For Loop
                }
                catch (Exception ex)
                {
                    Logger.Instance.WriteLog(this, 
                        "Error initializing Reference master data. " + ex.ToString());
                }
            }
            else
            {
                Logger.Instance.WriteLog(this, l_objDbWorkItem.ExecutionStatus);
            }
        }
        #endregion

        /// <summary>
        /// Returns Display value for given Reference Type and Code
        /// </summary>
        /// <param name="UCCReferenceType">Reference Type</param>
        /// <param name="ReferenceCode">Reference Code</param>
        /// <returns>Reference Description</returns>
        #region GetDisplayValue
        public string GetDisplayValue(ReferenceType UCCReferenceType, string ReferenceCode)
        {
            string l_sRetValue = null;

            DataTable l_dtRefData = m_dicRefData[UCCReferenceType];
            if (l_dtRefData != null)
            {
                DataRow[] l_objRows = l_dtRefData.Select("s_ReferenceType='" + UCCReferenceType.ToString() + "' AND s_ReferenceCode='" + ReferenceCode + "'");
                if (
                    (l_objRows != null) 
                    && (l_objRows.Length > 0)
                    && (l_objRows[0]["s_ReferenceName"] != DBNull.Value)
                    && (l_objRows[0]["s_ReferenceName"] != null)
                   )
                {
                    l_sRetValue = l_objRows[0]["s_ReferenceName"].ToString();
                }
            }

            return l_sRetValue;
        }
        #endregion

        /// <summary>
        /// Returns Display value for given Reference Type and No
        /// </summary>
        /// <param name="UCCReferenceType">Reference Type</param>
        /// <param name="ReferenceNo">Reference No</param>
        /// <returns>Reference Description</returns>
        #region GetDisplayValue
        public string GetDisplayValue(ReferenceType UCCReferenceType, int ReferenceNo)
        {
            string l_sRetValue = null;

            DataTable l_dtRefData = m_dicRefData[UCCReferenceType];
            if (l_dtRefData != null)
            {
                DataRow[] l_objRows = l_dtRefData.Select("s_ReferenceType='" + UCCReferenceType.ToString() + "' AND n_ReferenceNo=" + ReferenceNo);
                if (
                    (l_objRows != null)
                    && (l_objRows.Length > 0)
                    && (l_objRows[0]["s_ReferenceName"] != DBNull.Value)
                    && (l_objRows[0]["s_ReferenceName"] != null)
                   )
                {
                    l_sRetValue = l_objRows[0]["s_ReferenceName"].ToString();
                }
            }

            return l_sRetValue;
        }
        #endregion
        #endregion
    }
}
