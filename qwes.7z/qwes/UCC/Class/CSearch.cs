﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using FTIL.Match.Common.Db;
using FTIL.Match.Common;
using System.Data.SqlClient;
using System.Collections;

namespace UCC.Class
{
    /// <summary>
    /// BL class of Search screen
    /// </summary>
    public class CSearch
    {
        /// <summary>
        /// Retrieves UCC Search Data.
        /// </summary>
        /// <param name="l_SearchArray">Filter parameter values</param>
        /// <param name="p_vdsUCCData">Return help data</param>
        /// <returns>Method execution result</returns>
        #region GetUCCSearchData
        public MethodExecResult GetUCCSearchData(ArrayList l_SearchArray, ref DataSet p_vdsUCCData)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetUCCHelpDetails");
            l_objDbWorkItem.ResultType = QueryType.DataSet;
            l_objDbWorkItem.AddParameter("@ps_SearchType", SqlDbType.VarChar, l_SearchArray[0]);
            l_objDbWorkItem.AddParameter("@ps_SearchText", SqlDbType.VarChar, l_SearchArray[1]);
            l_objDbWorkItem.AddParameter("@ps_SearchField", SqlDbType.VarChar, l_SearchArray[2]);
            l_objDbWorkItem.AddParameter("@UserNo", SqlDbType.VarChar, AppEnvironment.AppUser.UserNo);
            
            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                    return new MethodExecResult(1, "No data found", "stp_GetUCCHelpDetails. Database returned no data. UserNo. " + AppEnvironment.AppUser.UserNo.ToString(), null);
                else
                {
                    p_vdsUCCData = l_dsReturnData;
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        } 
        #endregion
    }
}
