﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using System.Collections;
using FTIL.Match.Common.Log;
namespace UCC.Class.Master
{

   
    /// <summary>
    /// BL class of Client Exchange mapping screen
    /// </summary>
    public class CUCCClientExchangeMapping
    {
        #region Variables
        private CUCCClientExchangeMapping m_objOriginalExchangeMap;
        #endregion

        #region Constructor
        /// <summary>
        /// Initializes new instance of CClientExchangeMapping using ClientExchMapNo
        /// </summary>
        /// <param name="n_ClientBankNo">Unique ClientExchMapNo</param>
        
        public CUCCClientExchangeMapping(int ClientExchMapNo)
        {
            _ClientExchMapNo = ClientExchMapNo;
            //Initialize();
        }
        #endregion 

        #region Methods

        #region Initialize
        /// <summary>
        /// Initializes current instance from collection with given ClientExchMapNo
        /// </summary>
        
        public MethodExecResult Initialize(DataRow DataRow, CClientExchangeCollection ClientExchnageCollection)
        {
            try
            {
                MethodExecResult l_MethodExecResult;
                //If under authorisation client, take new changes in main client object and original object in originalClient object
                if (ClientExchnageCollection.ExchDetailsDataUnAuth != null && ClientExchnageCollection.ExchDetailsDataUnAuth.Rows.Count > 0 && ClientExchnageCollection.ExchDetailsDataUnAuth.Select("n_ClientExMapNo = " + this.ClientExchMapNo).GetLength(0) > 0)
                {
                    DataRow[] _dr;
                    _dr = ClientExchnageCollection.GetClientExchDetailUnAuth(this.ClientExchMapNo);
                    m_objOriginalExchangeMap = new CUCCClientExchangeMapping(this.ClientExchMapNo);
                    l_MethodExecResult = m_objOriginalExchangeMap.InitializeFromDataRow(_dr[0]);
                    l_MethodExecResult = this.InitializeFromDataRow(DataRow);
                }
                else
                {
                    l_MethodExecResult = this.InitializeFromDataRow(DataRow);
                }
                return l_MethodExecResult;
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                return new MethodExecResult(1, ex.Message, "Initialize Error processing DataRow", ex);
            }

        }
        #endregion

        #region InitializeFromDataRow
        /// <summary>
        /// Initializes current instance from DataRow
        /// </summary>
        /// <param name="DataRow">DataRow object containing Exchange details</param>
        
        public MethodExecResult InitializeFromDataRow(DataRow DataRow)
        {
            try
            {
                this.ExNo = Convert.ToInt16(DataRow["n_ExNo"]);
                this.Segment = Convert.ToInt16(DataRow["n_SegmentNo"]);
                this.ClientNo = Convert.ToInt32(DataRow["n_ClientNo"]);
                this.ClientExchMapNo = Convert.ToInt32(DataRow["n_ClientExMapNo"]);
                this.TradingCode = DataRow["s_Code"].ToString().Trim();
                this.CPCode = DataRow["s_CPCode"].ToString().Trim();
                this.ClientCategory = DataRow["s_ClientTypeDesc"].ToString().Trim();
                this.InpersonVerification = DataRow["s_InpersonVerification"].ToString().Trim();
                if ((DataRow["d_ClientAgreementDate"] != null) && (DataRow["d_ClientAgreementDate"] != DBNull.Value))
                    this.ClientAgreementDate = Convert.ToDateTime(DataRow["d_ClientAgreementDate"]);
                this.ClientStatus = DataRow["s_ClientStatus"].ToString().Trim();
                if (DataRow["s_Remarks"] != DBNull.Value)
                    this.Remarks = DataRow["s_Remarks"].ToString().Trim();
                this.UCCDownloaded = DataRow["s_UCCDownloaded"].ToString().Trim();
                if (DataRow["n_BatchNo"] != DBNull.Value)
                    this.BatchNo = Convert.ToInt32(DataRow["n_BatchNo"]);
                if (DataRow["s_RejectionDesc"] != DBNull.Value)
                    this.RejectionDesc = DataRow["s_RejectionDesc"].ToString().Trim();
                this.ExchangeType = DataRow["s_ExType"].ToString().Trim();

                if (DataRow["n_ClientType"] != DBNull.Value)
                    this.ClientType = Convert.ToInt16(DataRow["n_ClientType"]);
                if (DataRow["s_Relationship"] != DBNull.Value)
                    this.Relationship = DataRow["s_Relationship"].ToString().Trim();

                if (DataRow["s_AuthorizedStatus"] != DBNull.Value)
                    this.AuthorizedStatus = DataRow["s_AuthorizedStatus"].ToString().Trim();

             //   if (DataRow["s_ExCodeInternal"] != DBNull.Value)
                  //  this.ExCodeInternal = DataRow["s_ExCodeInternal"].ToString().Trim();

                return new MethodExecResult(MethodExecResult.SuccessfulReturnCode);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                return new MethodExecResult(1, ex.Message, "InitializeFromDataRow() Error processing DataRow", ex);
            }
        }
        #endregion

        #region UpdateUCCClientExchangeData
        /// <summary>
        /// Updates Client Exchange mapping data to database
        /// </summary>
        /// <param name="p_lArryList">Modified client exchange details</param>
        /// <returns>Method Execution Result</returns>
        
        public MethodExecResult UpdateUCCClientExchangeData(ArrayList p_lArryList)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCUpdateClientExchangeData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;

            l_objDbWorkItem.AddParameter("@ps_ClientCode", SqlDbType.VarChar, p_lArryList[0]);
            l_objDbWorkItem.AddParameter("@pn_ExNo", SqlDbType.Int, p_lArryList[1]);
            l_objDbWorkItem.AddParameter("@pn_ClientExMapNo", SqlDbType.VarChar, p_lArryList[2]);
            l_objDbWorkItem.AddParameter("@pn_SegmentNo", SqlDbType.VarChar, p_lArryList[3]);
            l_objDbWorkItem.AddParameter("@ps_Code", SqlDbType.VarChar, p_lArryList[4]);
            l_objDbWorkItem.AddParameter("@ps_CPCode", SqlDbType.VarChar, p_lArryList[5]);
            l_objDbWorkItem.AddParameter("@pn_ClientType", SqlDbType.VarChar, p_lArryList[6]);
            l_objDbWorkItem.AddParameter("@ps_InpersonVerification", SqlDbType.VarChar, p_lArryList[7]);
            l_objDbWorkItem.AddParameter("@pd_ClientAgreementDate", SqlDbType.DateTime, p_lArryList[8]);
            l_objDbWorkItem.AddParameter("@ps_ClientStatus", SqlDbType.VarChar, p_lArryList[9]);
            l_objDbWorkItem.AddParameter("@ps_Remarks", SqlDbType.VarChar, p_lArryList[10]);
            l_objDbWorkItem.AddParameter("@ps_Relationship", SqlDbType.VarChar, p_lArryList[11]);

            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            return l_objDbWorkItem.ExecutionStatus;
        }
        #endregion

        #endregion 

        #region Properties

        #region ClientNo
        private Int32 _ClientNo;
        /// <summary>
        /// ClientNo
        /// </summary>
        public Int32 ClientNo
        {
            get { return _ClientNo; }
            set { _ClientNo = value; }
        }
        #endregion

        #region ExNo
        private Int16 _ExNo;
        /// <summary>
        /// ExNo
        /// </summary>
        public Int16 ExNo
        {
            get { return _ExNo; }
            set { _ExNo = value; }
        }
        #endregion

        #region Segment
        private Int16 _Segment;
        /// <summary>
        /// Segment(Normal/SLB)
        /// </summary>
        public Int16 Segment
        {
            get { return _Segment; }
            set { _Segment = value; }
        }
        #endregion

        #region TradingCode
        private string _TradingCode;
        /// <summary>
        /// Client Trading code for the exchange
        /// </summary>
        public string TradingCode
        {
            get { return _TradingCode; }
            set { _TradingCode = value; }
        }
        #endregion

        #region CPCode
        private string _CPCode;
        /// <summary>
        /// Client CPCode for the exchange
        /// </summary>
        public string CPCode
        {
            get { return _CPCode; }
            set { _CPCode = value; }
        }
        #endregion

        #region ClientCategory
        private string _ClientCategory;
        /// <summary>
        /// ClientCategory for the exchange
        /// </summary>
        public string  ClientCategory
        {
            get { return _ClientCategory; }
            set { _ClientCategory = value; }
        }
        #endregion

        #region ClientType
        private Int16 _ClientType;
        /// <summary>
        /// ClientType for the exchange
        /// </summary>
        public Int16 ClientType
        {
            get { return _ClientType; }
            set { _ClientType = value; }
        }
        #endregion

        #region Relationship
        private string _Relationship;
        /// <summary>
        /// Relationship of a client for the exchange
        /// </summary>
        public string Relationship
        {
            get { return _Relationship; }
            set { _Relationship = value; }
        }
        #endregion
        
        #region InpersonVerification
        private string _InpersonVerification;
        /// <summary>
        /// InpersonVerification of a client for the exchange
        /// </summary>
        public string InpersonVerification
        {
            get { return _InpersonVerification; }
            set { _InpersonVerification = value; }
        }
        #endregion

        #region ClientAgreementDate
        private DateTime? _ClientAgreementDate;
        /// <summary>
        /// ClientAgreementDate
        /// </summary>
        public DateTime? ClientAgreementDate
        {
            get { return _ClientAgreementDate; }
            set { _ClientAgreementDate = value; }
        }
        #endregion

        #region ClientStatus
        private string _ClientStatus;
        /// <summary>
        /// ClientStatus
        /// </summary>
        public string ClientStatus
        {
            get { return _ClientStatus; }
            set { _ClientStatus = value; }
        }
        #endregion

        #region Remarks
        private string _Remarks;
        /// <summary>
        /// ClientStatus
        /// </summary>
        public string Remarks
        {
            get { return _Remarks; }
            set { _Remarks = value; }
        }
        #endregion

        #region UCCDownloaded
        private string _UCCDownloaded;
        /// <summary>
        /// Status of UCC record in Match System UCCDownloaded 
        /// </summary>
        public string UCCDownloaded
        {
            get { return _UCCDownloaded; }
            set { _UCCDownloaded = value; }
        }
        #endregion

        #region RejectionDesc
        private string _RejectionDesc;
        /// <summary>
        /// UCC rejection reason
        /// </summary>
        public string RejectionDesc
        {
            get { return _RejectionDesc; }
            set { _RejectionDesc = value; }
        }
        #endregion

        #region ExchangeType
        private string _ExchangeType;
        /// <summary>
        /// Base exchange Type like (BSE,NSE,MCX-SX)
        /// </summary>
        public string ExchangeType
        {
            get { return _ExchangeType; }
            set { _ExchangeType = value; }
        }
        #endregion

        #region BatchNo
        private Int32 _BatchNo;
        /// <summary>
        /// UCC Downloaded BatchNo for the exchange
        /// </summary>
        public Int32 BatchNo
        {
            get { return _BatchNo; }
            set { _BatchNo = value; }
        }
        #endregion

        #region ClientExchMapNo
        private Int32 _ClientExchMapNo;
        /// <summary>
        /// ClientBankNo
        /// </summary>
        public Int32 ClientExchMapNo
        {
            get { return _ClientExchMapNo; }
            set { _ClientExchMapNo = value; }
        }
        #endregion

        #region AuthorizedStatus
        /// <summary>
        /// Authorise status of current record
        /// </summary>
        private string _AuthorizedStatus;
        public string AuthorizedStatus
        {
            get { return _AuthorizedStatus; }
            set { _AuthorizedStatus = value; }
        }
        #endregion

        #region ExCodeInternal
        /// <summary>
        /// Exchange's InternalCode to identify a exchange
        /// </summary>
        private string _ExCodeInternal;
        public string ExCodeInternal
        {
            get { return _ExCodeInternal; }
            set { _ExCodeInternal = value; }
        }
        #endregion

        #region OriginalExchangeMap
        /// <summary>
        /// Original Exchange details of current exchange (when Maker/Checker enabled)
        /// </summary>
        public CUCCClientExchangeMapping OriginalExchangeMap
        {
            get { return m_objOriginalExchangeMap; }
        }
        #endregion

        #endregion
    }
}
