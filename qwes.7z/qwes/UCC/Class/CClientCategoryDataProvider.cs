﻿using System;
using System.Collections.Generic;
using System.Data;

using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;

namespace UCC.Class
{
    /// <summary>
    /// This class provides exchange wise list of Client Types
    /// </summary>
    class CClientCategoryDataProvider
    {
        #region Variables

        private Dictionary<ExchangeType, DataTable> m_dicRefData;
        private bool m_bInitialised;

        #endregion

        #region Singleton

        /// <summary>
        /// The only instance of a class
        /// </summary>
        private static CClientCategoryDataProvider m_objInstance;
        /// <summary>
        /// Private constructor to avoid instances
        /// </summary>
        private CClientCategoryDataProvider() 
        {
            m_dicRefData = new Dictionary<ExchangeType, DataTable>();
        }
        /// <summary>
        /// Static constructor to initialize singleton instance of a class
        /// </summary>
        static CClientCategoryDataProvider()
        {
            m_objInstance = new CClientCategoryDataProvider();
        }

        /// <summary>
        /// Singleton instance
        /// </summary>
        public static CClientCategoryDataProvider Instance
        {
            get
            {
                return m_objInstance;
            }
        }

        #endregion

        /// <summary>
        /// This indexer property returns DataTale of Client Type for specified Exchange
        /// </summary>
        /// <param name="ExchType"></param>
        /// <returns></returns>
        #region Property (indexer)
        public DataTable this[ExchangeType ExchType]
        {
            get
            {
                if (m_bInitialised == false)
                    Initialise();

                if (m_dicRefData.ContainsKey(ExchType))
                    return m_dicRefData[ExchType];
                return null;
            }
        }
        #endregion

        /// <summary>
        /// This method loads client types from database
        /// </summary>
        #region Initialise
        private void Initialise()
        {
            if (m_bInitialised)
                return;

            m_bInitialised = true;
            m_dicRefData.Clear();

            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetClientCategoryMasterData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.VarChar, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                {
                    Logger.Instance.WriteLog(this,
                        "No reference data found. Proc: stp_GetClientCategoryMasterData");
                    return;
                }

                DataTable l_dtRefData = l_dsReturnData.Tables[0];

                try
                {
                    for (int l_iRowCounter = 0; l_iRowCounter < l_dtRefData.Rows.Count; l_iRowCounter++)
                    {
                        ExchangeType l_objCurrentRowRefType = ExchangeType.None;
                        switch (l_dtRefData.Rows[l_iRowCounter]["s_ExCode"].ToString())
                        {
                            case "NSE":
                                l_objCurrentRowRefType = ExchangeType.NSE;
                                break;
                            case "BSE":
                                l_objCurrentRowRefType = ExchangeType.BSE;
                                break;
                            case "MCX-SX":
                                l_objCurrentRowRefType = ExchangeType.MCXSX;
                                break;
                        }

                        if (l_objCurrentRowRefType == ExchangeType.None)
                            continue;

                        DataTable l_dtCurrentRefData = null;
                        if (m_dicRefData.ContainsKey(l_objCurrentRowRefType))
                            l_dtCurrentRefData = m_dicRefData[l_objCurrentRowRefType];
                        else
                        {
                            l_dtCurrentRefData = new DataTable(l_objCurrentRowRefType.ToString());
                            l_dtCurrentRefData.Columns.Add("s_ExCode");
                            l_dtCurrentRefData.Columns.Add("n_CategoryNo");
                            l_dtCurrentRefData.Columns.Add("s_Category");

                            m_dicRefData.Add(l_objCurrentRowRefType, l_dtCurrentRefData);
                        }

                        l_dtCurrentRefData.ImportRow(l_dtRefData.Rows[l_iRowCounter]);
                    } //For Loop
                }
                catch (Exception ex)
                {
                    Logger.Instance.WriteLog(this,
                        "Error initializing Client Category Data Provider data." + ex.ToString());
                }
            }
            else
            {
                Logger.Instance.WriteLog(this, l_objDbWorkItem.ExecutionStatus);
            }
        }
        #endregion

    }
}
