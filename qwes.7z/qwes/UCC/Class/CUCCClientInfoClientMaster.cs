﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using FTIL.Match.Common.Db;
using FTIL.Match.Common;
using System.Collections;


namespace UCC.Class
{
    /// <summary>
    /// BL class of Client basic details screen
    /// </summary>
    public class CUCCClientInfoClientMaster
    {
        /// <summary>
        /// Retrieves client basic details for specified client
        /// </summary>
        /// <param name="p_vsClientCode">Client code</param>
        /// <param name="p_vdtUCCData">Return client data</param>
        /// <returns>Method Execution Result</returns>
        #region GetUCCCLientData
        public MethodExecResult GetUCCCLientData(string p_vsClientCode, ref DataTable p_vdtUCCData)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCRetrieveClientData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;
            l_objDbWorkItem.AddParameter("@ps_ClientCode", SqlDbType.VarChar, p_vsClientCode);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                    return new MethodExecResult(1, "No data found", "stp_UCCRetrieveClientData. Database returned no data. UserNo. " + AppEnvironment.AppUser.UserNo.ToString(), null);
                else
                {
                    p_vdtUCCData = l_dsReturnData.Tables[0];
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        }
        #endregion
        
        /// <summary>
        /// Updates client basic details modifications to database
        /// </summary>
        /// <param name="p_lArryList">Modified client basic details</param>
        /// <returns>Method Execution Result</returns>
        #region UpdateUCCCLientData
        public MethodExecResult UpdateUCCCLientData(ArrayList p_lArryList)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCUpdateClientData");
            l_objDbWorkItem.ResultType = QueryType.DataSet;
            //l_objDbWorkItem.AddParameter("@pn_ClientNo", SqlDbType.Int, p_lArryList[0]);
            l_objDbWorkItem.AddParameter("@ps_ClientCode", SqlDbType.VarChar, p_lArryList[1]);
            l_objDbWorkItem.AddParameter("@ps_ClientName", SqlDbType.VarChar, p_lArryList[2]);
            //l_objDbWorkItem.AddParameter("@pn_ClientType", SqlDbType.Int, p_lArryList[3]);
            l_objDbWorkItem.AddParameter("@ps_PANNo", SqlDbType.VarChar, p_lArryList[3]);
            l_objDbWorkItem.AddParameter("@ps_Gender", SqlDbType.VarChar, p_lArryList[4]);
            l_objDbWorkItem.AddParameter("@ps_GuardianName", SqlDbType.VarChar, p_lArryList[5]);
            l_objDbWorkItem.AddParameter("@ps_MaritalStatus", SqlDbType.VarChar, p_lArryList[6]);
            l_objDbWorkItem.AddParameter("@pn_Nationality", SqlDbType.Int, p_lArryList[7]);
            l_objDbWorkItem.AddParameter("@ps_NationalityOther", SqlDbType.VarChar, p_lArryList[8]);
            l_objDbWorkItem.AddParameter("@ps_PanExempt", SqlDbType.VarChar, p_lArryList[9]);
            l_objDbWorkItem.AddParameter("@ps_CorporateIdNo", SqlDbType.VarChar, p_lArryList[10]);
            l_objDbWorkItem.AddParameter("@pd_DOB", SqlDbType.DateTime, p_lArryList[11]);
            l_objDbWorkItem.AddParameter("@pd_CreationDate", SqlDbType.DateTime, p_lArryList[12]);
            l_objDbWorkItem.AddParameter("@pn_GrAnnIncRange", SqlDbType.Int, p_lArryList[13]);
            l_objDbWorkItem.AddParameter("@pd_GrAnnIncAsOnDate", SqlDbType.DateTime, p_lArryList[14]);
            l_objDbWorkItem.AddParameter("@pn_NetWorth", SqlDbType.Decimal, p_lArryList[15]);
            l_objDbWorkItem.AddParameter("@pd_NetWorthAsOnDate", SqlDbType.DateTime, p_lArryList[16]);
            l_objDbWorkItem.AddParameter("@pn_PEP", SqlDbType.Int, p_lArryList[17]);
            l_objDbWorkItem.AddParameter("@ps_PlaceofIncorporation", SqlDbType.VarChar, p_lArryList[18]);
            l_objDbWorkItem.AddParameter("@pn_Occupation", SqlDbType.Int, p_lArryList[19]);
            l_objDbWorkItem.AddParameter("@ps_OccupationOthers", SqlDbType.VarChar, p_lArryList[20]);
            l_objDbWorkItem.AddParameter("@pd_CommOfBusiness", SqlDbType.DateTime, p_lArryList[21]);
            l_objDbWorkItem.AddParameter("@ps_UCCCode", SqlDbType.VarChar, p_lArryList[22]);
            l_objDbWorkItem.AddParameter("@ps_CINExempt", SqlDbType.VarChar, p_lArryList[23]);
            l_objDbWorkItem.AddParameter("@ps_UpdationFlag", SqlDbType.VarChar, p_lArryList[24]);
            //l_objDbWorkItem.AddParameter("@ps_Relationship", SqlDbType.VarChar, p_lArryList[25]);
            l_objDbWorkItem.AddParameter("@ps_TypeofFacility", SqlDbType.VarChar, p_lArryList[26]);
            l_objDbWorkItem.AddParameter("@ps_ClientTypeCorporate", SqlDbType.VarChar, p_lArryList[27]);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.VarChar, AppEnvironment.AppUser.UserNo);
            l_objDbWorkItem.AddParameter("@pn_ClientType", SqlDbType.VarChar, p_lArryList[28]);
            l_objDbWorkItem.AddParameter("@pn_ClientStatus", SqlDbType.VarChar, p_lArryList[29]);
            
            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            return l_objDbWorkItem.ExecutionStatus;
        }
        #endregion
    }
}
