﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using FTIL.Match.Common.Db;
using FTIL.Match.Common;
using System.Data.SqlClient;
using System.Collections;

namespace UCC.Class
{
    /// <summary>
    /// BL class of CMakerCancel
    /// </summary>
    public class MakerCancel
    {
        /// <summary>
        /// Cancel the Maker impact for the selected record
        /// </summary>
        /// <param name="l_ParamValueArr"> procedure parameter values</param>
        /// <returns>Method execution result</returns>
        #region CancelMakerEffect
        public MethodExecResult CancelMakerEffect(ArrayList l_ParamValueArr)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCMakerCancel");
            l_objDbWorkItem.ResultType = QueryType.DataSet;
            l_objDbWorkItem.AddParameter("@Pn_EntityNo", SqlDbType.Int, l_ParamValueArr[0]);
            l_objDbWorkItem.AddParameter("@Pn_EntityType", SqlDbType.Int, l_ParamValueArr[1]);
            l_objDbWorkItem.AddParameter("@Pn_UserNo", SqlDbType.Int, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            return l_objDbWorkItem.ExecutionStatus;
        }
        #endregion
    }
}