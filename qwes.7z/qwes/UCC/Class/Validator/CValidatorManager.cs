﻿using System;
using System.Collections.Generic;
using System.Text;
using UCC.Class.Master;
using System.Data;
namespace UCC.Class.Validator
{
    /// <summary>
    /// Type of entity to be validate
    /// </summary>
    public enum EntityType
    {
        Client = 1,
        ExchangeMapping = 2,
        Address = 3,
        Bank = 4,
        DP = 5,
        UCCInfo = 99
    }

    /// <summary>
    /// Validator Manager class used to validate field level validation for UCC download
    /// </summary>
    public class CValidatorManager
    {
        #region Variables
        /// <summary>
        /// Result objects to return validation result
        /// </summary>
        private CValidationResult m_ObjResult = null;

        /// <summary>
        /// Interface variable 
        /// </summary>
        private IValidator m_IValidator = null;
        #endregion

        #region Constructor
        /// <summary>
        /// Default Constructor Initialise result object
        /// </summary>
        public CValidatorManager()
        {
            this.m_ObjResult = new CValidationResult();
            
        }
        #endregion

        #region Methods

        /// <summary>
        /// Main method to be call from outside
        /// </summary>
        /// <param name="pi_IValidator">Exchange wise validator objects </param>
        /// <param name="pe_EntityType">Type of entity to be validated</param>
        /// <param name="p_Client"> object of type Client with UCC all details </param>
        /// <returns>CValidationResult</returns>
        public CValidationResult Validate(IValidator pi_IValidator,  EntityType pe_EntityType, List<CClient> p_Client)
        {
            this.m_IValidator = pi_IValidator;

            switch (pe_EntityType)
            {
                case EntityType.Client:
                    this.ValidateClient(m_IValidator, p_Client);
                    break;
                case EntityType.ExchangeMapping:
                    this.ValidateExchangeMapping(m_IValidator, p_Client);
                    break;
                case EntityType.Address:
                    this.ValidateAddress(m_IValidator, p_Client);
                    break;
                case EntityType.Bank:
                    this.ValidateBank(m_IValidator, p_Client);
                    break;
                case EntityType.DP:
                    this.ValidateDP(m_IValidator, p_Client);
                    break;
                case EntityType.UCCInfo:
                    this.ValidateUCCInfo(m_IValidator, p_Client);
                    break;
            }
            return m_ObjResult;
        }

        /// <summary>
        /// Private Method used to validate only client details
        /// </summary>
        /// <param name="p_iValidator">Interface variable passed from </param>
        /// <param name="p_Client"> object of type Client with UCC all details</param>
        /// <returns>CValidationResult</returns>
        private CValidationResult ValidateClient(IValidator p_iValidator, List<CClient> p_Client)
        {
            p_iValidator.ValidateClient(p_Client);
            return p_iValidator.ValidationResult;
        }

        /// <summary>
        /// Private Method used to validate only ExchangeMapping details
        /// </summary>
        /// <param name="p_iValidator">Interface variable passed from </param>
        /// <param name="p_Client"> object of type Client with UCC all details</param>
        /// <returns>CValidationResult</returns>
        private CValidationResult ValidateExchangeMapping(IValidator p_iValidator, List<CClient> p_Client)
        {
            p_iValidator.ValidateExchangeMapping(p_Client);
            return p_iValidator.ValidationResult;
        }

        /// <summary>
        /// Private Method used to validate only Address details
        /// </summary>
        /// <param name="p_iValidator">Interface variable passed from </param>
        /// <param name="p_Client"> object of type Client with UCC all details</param>
        /// <returns>CValidationResult</returns>
        private CValidationResult ValidateAddress(IValidator p_iValidator, List<CClient> p_Client)
        {
            p_iValidator.ValidateAddress(p_Client);
            return p_iValidator.ValidationResult;
        }

        /// <summary>
        /// Private Method used to validate only Bank details
        /// </summary>
        /// <param name="p_iValidator">Interface variable passed from </param>
        /// <param name="p_Client"> object of type Client with UCC all details</param>
        /// <returns>CValidationResult</returns>
        private CValidationResult ValidateBank(IValidator p_iValidator, List<CClient> p_Client)
        {
            p_iValidator.ValidateBank(p_Client);
            return p_iValidator.ValidationResult;
        }

        /// <summary>
        /// Private Method used to validate only DP details
        /// </summary>
        /// <param name="p_iValidator">Interface variable passed from </param>
        /// <param name="p_Client"> object of type Client with UCC all details</param>
        /// <returns>CValidationResult</returns>
        private CValidationResult ValidateDP(IValidator p_iValidator, List<CClient> p_Client)
        {
            p_iValidator.ValidateDP(p_Client);
            return p_iValidator.ValidationResult;
        }

        /// <summary>
        /// Private Method used to validate all UCC details
        /// </summary>
        /// <param name="p_iValidator">Interface variable passed from </param>
        /// <param name="p_Client"> object of type Client with UCC all details</param>
        /// <returns>CValidationResult</returns>
        private void ValidateUCCInfo(IValidator p_iValidator, List<CClient> p_Client)
        {
            this.ValidateClient(p_iValidator, p_Client);
            this.ValidateExchangeMapping(p_iValidator, p_Client);
            this.ValidateAddress(p_iValidator, p_Client);
            this.ValidateBank(p_iValidator, p_Client);
            this.ValidateDP(p_iValidator, p_Client);
            this.MergeResults(p_iValidator.ValidationResult);
        }


        /// <summary>
        /// Method to be used to merge validation result to main class level validation results
        /// </summary>
        /// <param name="p_Result">Result object to be merge to class level Result</param>
        private void MergeResults(CValidationResult p_Result)
        {
            if (p_Result.ReturnCode != 0)
            {
                foreach (Result result in p_Result.ResultList)
                    this.m_ObjResult.Add(result);
            }
        }
        #endregion

        #region Property
        /// <summary>
        /// Return the result of Validation
        /// </summary>
        public DataTable ValidationResult
        {
            get
            {
                DataTable _dt = new DataTable();
                _dt.Columns.Add("s_ExchangeCode");
                _dt.Columns.Add("n_UITabNo");
                _dt.Columns.Add("s_EntityCode");
                _dt.Columns.Add("s_EntityName");
                _dt.Columns.Add("n_ResultCode");
                _dt.Columns.Add("s_ValidationMsg");
                foreach (Result _result in m_ObjResult.ResultList)
                {
                    DataRow _dr = _dt.NewRow();
                    _dr["s_ExchangeCode"] = _result.ExchangeCode;
                    _dr["n_UITabNo"] = Convert.ToInt32(_result.EntityType);
                    _dr["s_EntityCode"] = _result.EntityCode;
                    _dr["s_EntityName"] = _result.EntityName;
                    _dr["n_ResultCode"] = _result.Code;
                    _dr["s_ValidationMsg"] = _result.ErrMessage;

                    _dt.Rows.Add(_dr);
                }
                _dt.AcceptChanges();
                return _dt;
            }
        }

        #endregion
    }
}
