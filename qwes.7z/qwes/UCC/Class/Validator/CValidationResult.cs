﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UCC.Class.Validator
{
    /// <summary>
    /// Provide service of result informtaion of any validation
    /// </summary>
    public class CValidationResult
    {
        #region Constructor
        /// <summary>
        /// Default Constructor
        /// </summary>
        public CValidationResult()
        {
            this.m_ResultList = new List<Result>();
        }
        #endregion

        #region Properties 

        private long _ReturnCode = 0;
        /// <summary>
        /// Return Code
        /// </summary>
        public long ReturnCode
        {
            get { return this._ReturnCode;}
        }

        private List<Result> m_ResultList;
        /// <summary>
        /// Return List of Results 
        /// </summary>
        public List<Result> ResultList
        {
            get { return this.m_ResultList; }
        }

        #endregion

        #region Methods
        /// <summary>
        /// Method used to add result objects to the collection.
        /// </summary>
        /// <param name="Results"></param>
        public void Add(Result Results)
        {
            this._ReturnCode = -1;
            this.m_ResultList.Add(Results);
        }
        #endregion
    }

    public class Result
    {
        #region Constructor
        /// <summary>
        /// Parameterize constructor with objects initilization
        /// </summary>
        /// <param name="pn_ErrCode"></param>
        /// <param name="ps_Errmessage"></param>
        public Result(string ps_ExchangeCode,EntityType pe_Entity, string ps_EntityCode,string ps_EntityName, long pn_ErrCode, string ps_ErrMessage)
        {
            this._ExchangeCode = ps_ExchangeCode;
            this._EntityType = pe_Entity;
            this._EntityCode = ps_EntityCode;
            this._EntityName = ps_EntityName;
            this._Code = pn_ErrCode;
            this._ErrMessage = ps_ErrMessage;

            
        }
        #endregion

        #region Properties

        private string _ExchangeCode;
        /// <summary>
        /// Result of ExchangeCode of entity
        /// </summary>
        public string ExchangeCode
        {
            get { return this._ExchangeCode; }
        }

        private EntityType _EntityType;
        /// <summary>
        /// Result of type of entity
        /// </summary>
        public EntityType EntityType
        {
            get { return this._EntityType; }
        }

        private string _EntityCode;
        /// <summary>
        /// Result of Code of entity
        /// </summary>
        public string EntityCode
        {
            get { return this._EntityCode; }
        }

        private string _EntityName;
        /// <summary>
        /// Result of name of entity
        /// </summary>
        public string EntityName
        {
            get { return this._EntityName; }
        }

        private long _Code = 0;
        /// <summary>
        /// Validation code of result
        /// </summary>
        public long Code
        {
            get { return this._Code; }
        }

        private string _ErrMessage = string.Empty;
        /// <summary>
        /// Validation message of result
        /// </summary>
        public string ErrMessage
        {
            get { return _ErrMessage; }
        }
        #endregion
    }
}
