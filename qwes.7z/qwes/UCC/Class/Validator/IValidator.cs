﻿using System;
using System.Collections.Generic;
using System.Text;
using UCC.Class.Master;

namespace UCC.Class.Validator
{
    /// <summary>
    /// UCC Validator interface need to implement for each exchange validator
    /// </summary>
    public interface IValidator
    {
        #region Methods
        /// <summary>
        /// Client specific validation for UCC download
        /// </summary>
        /// <param name="Clients"></param>
        void ValidateClient(List<CClient> Clients);

        /// <summary>
        /// Client Exchange specific UCC field validation
        /// </summary>
        /// <param name="Clients"></param>
        void ValidateExchangeMapping(List<CClient> Clients);

        /// <summary>
        /// Client Address specific UCC field validation
        /// </summary>
        /// <param name="Client"></param>
        void ValidateAddress(List<CClient> Client);
        
        /// <summary>
        /// Client Bank specific UCC field validation
        /// </summary>
        /// <param name="Client"></param>
        void ValidateBank(List<CClient> Client);

        /// <summary>
        /// Client DP specific UCC field validation
        /// </summary>
        /// <param name="Client"></param>
        void ValidateDP(List<CClient> Client);
        #endregion

        #region Property
        /// <summary>
        /// return result of validation
        /// </summary>
        CValidationResult ValidationResult { get; }
        #endregion
    }
}
