﻿using System;
using System.Collections.Generic;
using System.Text;
using UCC.Class.Master;
using System.Linq;

namespace UCC.Class.Validator
{
    class CBSEValidator : IValidator
    {

        #region Variable
        CValidationResult m_ValidationResult;
        #endregion

        #region Constructor
        /// <summary>
        /// Class Constructor
        /// </summary>
        public CBSEValidator()
        {
            this.m_ValidationResult = new CValidationResult();
        }
        #endregion

        #region Methods
        /// <summary>
        /// Client specific validation for UCC download
        /// </summary>
        /// <param name="Clients"></param>
        public void ValidateClient(List<CClient> Clients)
        {

        }

        /// <summary>
        /// Client Exchange specific UCC field validation
        /// </summary>
        /// <param name="Clients"></param>
        public void ValidateExchangeMapping(List<CClient> Clients)
        {
        }

        /// <summary>
        /// Client Address specific UCC field validation
        /// </summary>
        /// <param name="Client"></param>
        public void ValidateAddress(List<CClient> Client)
        {
        }

        /// <summary>
        /// Client Bank specific UCC field validation
        /// </summary>
        /// <param name="Client"></param>
        public void ValidateBank(List<CClient> Client)
        {
        }

        /// <summary>
        /// Client DP specific UCC field validation
        /// </summary>
        /// <param name="Client"></param>
        public void ValidateDP(List<CClient> Client)
        {
        }
        #endregion

        #region Property
        /// <summary>
        /// return result of validation
        /// </summary>
        public CValidationResult ValidationResult
        {
            get { return m_ValidationResult; }

        }
        #endregion

    }
}
