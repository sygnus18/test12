﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Data;
using UCC.Class.Master;
using FTIL.Match.Common.Utils;
using System.Text.RegularExpressions;
using FTIL.Match.Common;
namespace UCC.Class.Validator
{
    class CNSEValidator : IValidator
    {
        #region Variable
        CValidationResult m_ValidationResult;
        #endregion

        #region Constructor
        /// <summary>
        /// Class Constructor
        /// </summary>
        public CNSEValidator()
        {
            this.m_ValidationResult = new CValidationResult();
        }
        #endregion

        #region Methods
        /// <summary>
        /// Client specific validation for UCC download
        /// </summary>
        /// <param name="Clients"></param>
        public void ValidateClient(List<CClient> Clients)
        {

        }

        /// <summary>
        /// Client Exchange specific UCC field validation
        /// </summary>
        /// <param name="Clients"></param>
        public void ValidateExchangeMapping(List<CClient> Clients)
        {
            
            var resClients = (IEnumerable<CClient>)null;
            List<short> l_lstCategoryNo;

            //-Length of Trading Code is greater than 10 characters
            resClients = from c in Clients
                         where (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where m.TradingCode.Length > 10
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.ExchangeMapping, client.ClientCode, client.ClientName, 1000, "- Length of Trading Code is greater than 10 characters"));
            }

            //- Client''s Category not applicable for Currency Derivatives segment
            l_lstCategoryNo = new List<short>() { 110, 111, 113, 114, 115 };
            resClients = from c in Clients
                         where (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                             where l_lstCategoryNo.Contains(m.ClientType)
                                && m.ExCodeInternal=="NSECR"
                             select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.ExchangeMapping, client.ClientCode, client.ClientName, 1001, "- Client's Category not applicable for Currency Derivatives segment"));
            }

            //- Client's Category not applicable for Future & Option/Currency Derivatives segment/SLBM Segment.
            l_lstCategoryNo = new List<short>() { 117, 118,121 };
            resClients = from c in Clients
                         where (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where l_lstCategoryNo.Contains(m.ClientType)
                                   && AppEnvironment.AppSettings.AppProduct==Product.Derivative
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.ExchangeMapping, client.ClientCode, client.ClientName, 1002, "- Client's Category not applicable for Future & Option/Currency Derivatives segment/SLBM Segment."));
            }

            //- Client's Category not applicable for Future & Option.
            l_lstCategoryNo = new List<short>() { 120};
            resClients = from c in Clients
                         where (from m in c.ClientExchanges.Where(r => r.ExCodeInternal == "NSE")
                                where l_lstCategoryNo.Contains(m.ClientType)
                                   && AppEnvironment.AppSettings.AppProduct == Product.Derivative
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.ExchangeMapping, client.ClientCode, client.ClientName, 1003, "- Client's Category not applicable for Future & Option."));
            }


            //-Client Name should contain values
            resClients = from c in Clients
                         where string.IsNullOrEmpty(c.ClientName)
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1004, "Client Name should contain values"));
            }

            //-Client Name should contain atleast 2 characters
            resClients = from c in Clients
                         where !string.IsNullOrEmpty(c.ClientName)
                            && c.ClientName.Length < 2
                         select c;

            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1005, "Client Name should contain atleast 2 characters"));
            }

            //- Client Name should not contain all Special Characters.
            resClients = from c in Clients
                         where !string.IsNullOrEmpty(c.ClientName)
                            && !c.ClientName.Any<Char>(Char.IsLetterOrDigit)
                         select c;

            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1006, "- Client Name should not contain all Special Characters."));
            }

            //- Client Name should not contain all Numbers
            resClients = from c in Clients
                         where !String.IsNullOrEmpty(c.ClientName)
                            && c.ClientName.All(Char.IsNumber)
                         select c;

            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1007, "-  Client Name should not contain all Numbers."));
            }


            //-Client Category should not blank
            resClients = from c in Clients
                         where !c.UCCType.HasValue
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1007, "- Client Category should not blank"));
            }

            //-Nationality (Other) name should contain atleast 2 characters
            resClients = from c in Clients
                         where !String.IsNullOrEmpty(c.NationalityOther)
                            && c.Nationality == 2
                            && c.NationalityOther.Trim().Length < 2
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1008, "- Nationality (Other) name should contain atleast 2 characters"));
            }

            //- Guardian Name should not contain all Special Characters.
            resClients = from c in Clients
                         where !String.IsNullOrEmpty(c.GuardianName)
                            && !c.ClientName.Any<Char>(Char.IsLetterOrDigit)
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1017, "- Guardian Name should not contain all Special Characters."));
            }

            //- Guardian Name should not contain all numbers.
            resClients = from c in Clients
                         where !String.IsNullOrEmpty(c.GuardianName)
                            && c.ClientName.All(Char.IsNumber)
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1018, "- Guardian Name should not contain all numbers."));
            }

            //- PAN should contain values
            resClients = from c in Clients
                         where String.IsNullOrEmpty(c.PANNo) && (c.PanExempt == "N")
                         select c;

            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1134, "- PAN should contain values"));
            }

            l_lstCategoryNo = new List<short>() { 101, 111, 118, 201, 202, 211, 125, 126, 127 };
            //- Gender is mandatory
            resClients = from c in Clients
                         where String.IsNullOrEmpty(c.Gender) && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                                                  join l in l_lstCategoryNo on m.ClientType equals l
                                                                  select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1135, "- Gender is mandatory"));
            }

            //- Guardian Name is mandatory
            resClients = from c in Clients
                         where String.IsNullOrEmpty(c.GuardianName) && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                                                        join l in l_lstCategoryNo on m.ClientType equals l
                                                                        select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1136, "- Guardian Name is mandatory"));
            }

            //- Marital Status is mandatory
            resClients = from c in Clients
                         where String.IsNullOrEmpty(c.MaritalStatus) && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                                                         join l in l_lstCategoryNo on m.ClientType equals l
                                                                         select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1137, "- Marital Status is mandatory"));
            }

            //- Nationality is mandatory
            resClients = from c in Clients
                         where c.Nationality == 0 && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                                      join l in l_lstCategoryNo on m.ClientType equals l
                                                      select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result("", EntityType.Client, client.ClientCode, client.ClientName, 1138, "- Nationality is mandatory"));
            }

            //- Nationality (Others) value is Mandatory
            resClients = from c in Clients
                         where c.Nationality == 2 && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                                      join l in l_lstCategoryNo on m.ClientType equals l
                                                      select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1139, "- Nationality (Others) value is Mandatory"));
            }


            //- Gross Annual Income as on Date is Mandatory if Gross Annual Income is specified
            l_lstCategoryNo = new List<short>() { 106, 107, 108, 109, 112, 116, 121, 122, 123, 124 };
            resClients = from c in Clients
                         where c.GrAnnIncAsOnDate.HasValue == false
                            && (c.GrAnnIncRange.HasValue && !c.GrAnnIncRange.Value.Equals(0))
                           && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                               where !l_lstCategoryNo.Contains(m.ClientType)
                               select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1148, "- Gross Annual Income as on Date is Mandatory if Gross Annual Income is specified"));
            }

            //- Gross Annual Income as on Date should not be older than last 18 months.
            resClients = from c in Clients
                         where c.GrAnnIncAsOnDate.HasValue
                            && (c.GrAnnIncRange.HasValue && !c.GrAnnIncRange.Value.Equals(0))
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where !l_lstCategoryNo.Contains(m.ClientType)
                                select m).Count() > 0
                            && c.GrAnnIncAsOnDate.Value.Subtract(CMatchCommonUtils.Instance.ServerDate.AddMonths(-18).Date).TotalDays <= 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1149, "- Gross Annual Income as on Date should not be older than last 18 months."));
            }

            //- Net Worth is Mandatory if Gross Annual Income is not provided.
            l_lstCategoryNo = new List<short>() { 106, 107, 108, 109, 112, 116, 121, 110, 122, 123, 124 };
            resClients = from c in Clients
                         where (!c.GrAnnIncRange.HasValue || c.GrAnnIncRange.Value == 0)
                            && (!c.NetWorth.HasValue || c.NetWorth.Value.Equals(0))
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where !l_lstCategoryNo.Contains(m.ClientType)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1150, "- Net Worth is Mandatory if Gross Annual Income is not provided."));
            }

            //- Net worth as on Date is Mandatory if Net Worth provided.
            resClients = from c in Clients
                         where (!c.NetWorthAsOnDate.HasValue)
                            && (c.NetWorth.HasValue && !c.NetWorth.Value.Equals(0))
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where !l_lstCategoryNo.Contains(m.ClientType)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1151, "- Net worth as on Date is Mandatory if Net Worth provided."));
            }

            //- Net worth as on date should not be older then 1 year.
            resClients = from c in Clients
                         where (c.NetWorthAsOnDate.HasValue)
                            && (c.NetWorth.HasValue && !c.NetWorth.Value.Equals(0))
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where !l_lstCategoryNo.Contains(m.ClientType)
                                select m).Count() > 0
                            && c.NetWorthAsOnDate.Value.Subtract(CMatchCommonUtils.Instance.ServerDate.AddYears(-1).Date).TotalDays <= 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1152, "- Net worth as on date should not be older then 1 year."));
            }

            //- Client Agreement Date cannot be greater then current date
            resClients = from c in Clients
                         where c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString()
                                                            && r.ClientAgreementDate.HasValue
                                                            && r.ClientAgreementDate.Value > CMatchCommonUtils.Instance.ServerDate.Date
                                                      ).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.ExchangeMapping, client.ClientCode, client.ClientName, 1153, "- Client Agreement Date cannot be greater then current date."));
            }


            //- DOB/DOI is Mandatory
            l_lstCategoryNo = new List<short>() { 101, 102, 103, 104, 105, 110, 111, 113, 114, 115, 117, 118, 119, 120, 125, 126, 127 };
            resClients = from c in Clients
                         where !c.DOB.HasValue
                            &&
                             (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                              where l_lstCategoryNo.Contains(m.ClientType)
                              select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1157, "- DOB/DOI is Mandatory."));
            }


            //- CIN is mandatory
            l_lstCategoryNo = new List<short>() { 104 };
            resClients = from c in Clients
                         where String.IsNullOrEmpty(c.CorporateIdNo)
                            && (String.IsNullOrEmpty(c.CINExempt) || c.CINExempt.Equals("N"))
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where l_lstCategoryNo.Contains(m.ClientType)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1159, "- CIN is mandatory."));
            }

            //- CIN should contain 21 Characters
            resClients = from c in Clients
                         where !String.IsNullOrEmpty(c.CorporateIdNo)
                            && c.CorporateIdNo.Length < 21
                            && (String.IsNullOrEmpty(c.CINExempt) || c.CINExempt.Equals("N"))
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1160, "- CIN should contain 21 Characters."));
            }

            //- Politically Exposed Person is Mandatory
            l_lstCategoryNo = new List<short>() { 106, 107, 108, 109, 112, 116, 121, 122, 123, 124 };
            resClients = from c in Clients
                         where !c.PEP.HasValue
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where !l_lstCategoryNo.Contains(m.ClientType)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1169, "- Politically Exposed Person is Mandatory."));
            }

            //- Occupation (others) Details should contain atleast 4 characters.
            resClients = from c in Clients
                         where !String.IsNullOrEmpty(c.OccupationOthers) && c.OccupationOthers.Length < 4
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1170, "-  Occupation (others) Details should contain atleast 4 characters."));
            }

            //- Occupation is Mandatory.
            l_lstCategoryNo = new List<short>() { 101, 111, 118, 125, 126, 127 };
            resClients = from c in Clients
                         where !c.Occupation.HasValue
                         && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                             where l_lstCategoryNo.Contains(m.ClientType)
                             select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1172, "- Occupation is Mandatory."));
            }

            //- Specify Occupation (others) Details.
            resClients = from c in Clients
                         where c.Occupation.HasValue && (c.Occupation.Value == 99 || c.Occupation.Value == 305)
                         && (String.IsNullOrEmpty(c.OccupationOthers) || c.OccupationOthers == "")
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1173, "- Specify Occupation (others) Details."));
            }

            //- Client Type Corporate is Mandatory
            resClients = from c in Clients
                         where (String.IsNullOrEmpty(c.ClientTypeCorporate) || c.ClientTypeCorporate == "N")
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where m.ClientType == 104
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1179, "- Client Type Corporate is Mandatory."));
            }

            ////////////////////////////- Occupation (Others) should not contain all Special Characters.
            //////////////////////////resClients = from c in Clients
            //////////////////////////             where (c.Occupation == 99 || c.Occupation == 305)
            //////////////////////////                && !String.IsNullOrEmpty(c.OccupationOthers)
            //////////////////////////                && !m_RegExContainAlphaNumeric.IsMatch(c.OccupationOthers)
            //////////////////////////             select c;
            //////////////////////////foreach (CClient client in resClients)
            //////////////////////////{
            //////////////////////////    this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1258, "- Occupation (Others) should not contain all Special Characters."));
            //////////////////////////}

            ////////////////////////////- Occupation (Others) should not contain all Numbers.
            //////////////////////////resClients = from c in Clients
            //////////////////////////             where (c.Occupation == 99 || c.Occupation == 305)
            //////////////////////////                && !String.IsNullOrEmpty(c.OccupationOthers)
            //////////////////////////                && c.OccupationOthers.All(char.IsNumber)
            //////////////////////////             select c;
            //////////////////////////foreach (CClient client in resClients)
            //////////////////////////{
            //////////////////////////    this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1259, "- Occupation (Others) should not contain all Numbers."));
            //////////////////////////}


            //- Gross Annual Income range should be Not-Applicable for Statutory Body clients
            resClients = from c in Clients
                         where (!c.GrAnnIncRange.HasValue || c.GrAnnIncRange.Value != 326)
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where m.ClientType == 110
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1243, "- Gross Annual Income range should be Not-Applicable for Statutory Body clients."));
            }

            //- Gross Annual Income range should not be Not-Applicable for selected client category
            resClients = from c in Clients
                         where c.GrAnnIncRange.HasValue
                            && c.GrAnnIncRange.Value == 326
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where m.ClientType != 110
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Client, client.ClientCode, client.ClientName, 1244, "- Gross Annual Income range should not be Not-Applicable for selected client category."));
            }


        }

        /// <summary>
        /// Client Address specific UCC field validation
        /// </summary>
        /// <param name="Client"></param>
        public void ValidateAddress(List<CClient> Clients)
        {
            var resClients = (IEnumerable<CClient>)null;
            List<short> l_lstCategoryNo;
            Char[] l_splitChars = { ';', ',', ' ' };

            //- Client Email Id should start with Alphanumeric character only
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType!= (short)AddressTypeEnum.ContactPerson)
                                where m.Default==true
                                  && !string.IsNullOrEmpty(m.EMailId)
                                  && !m.EMailId.Split(l_splitChars, StringSplitOptions.RemoveEmptyEntries).First().Substring(0,1).Any<Char>(Char.IsLetterOrDigit)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1009, "- Client Email Id should start with Alphanumeric character only"));
            }

            //- Client Email Id should contain atleast 5 characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.EMailId)
                                  && m.EMailId.Split(l_splitChars, StringSplitOptions.RemoveEmptyEntries).First().Length < 5
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1010, "- Client Email Id should contain atleast 5 characters."));
            }

            //- Client Email Id should not contain all numbers.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.EMailId)
                                  && m.EMailId.Split(l_splitChars, StringSplitOptions.RemoveEmptyEntries).First().All<Char>(Char.IsNumber)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1011, "- Client Email Id should not contain all numbers."));
            }

            //- Client Email Id should not contain all Special Characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.EMailId)
                                  && !m.EMailId.Split(l_splitChars, StringSplitOptions.RemoveEmptyEntries).First().Any<Char>(Char.IsLetterOrDigit)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1012, "- Client Email Id should not contain all Special Characters."));
            }

            //- Client Email Id should contain "@" and DOT(.)
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.EMailId)
                                  && (!m.EMailId.Split(l_splitChars, StringSplitOptions.RemoveEmptyEntries).First().Any<Char>(r => r.Equals('@'))
                                       || !m.EMailId.Split(l_splitChars, StringSplitOptions.RemoveEmptyEntries).First().Any<Char>(r =>r.Equals('.')))
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1015, "- Client Email Id should contain @ and DOT(.)"));
            }

            //- Client Email Id should have only one @.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.EMailId)
                                  && m.EMailId.Split(l_splitChars, StringSplitOptions.RemoveEmptyEntries).First().Count<Char>(r => r.Equals('@')) > 1
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1016, "- Client Email Id should have only one @."));
            }
            //- Correspondence Client Address line 1 should contain atleast 5 characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.AddressLine1)
                                  && m.AddressLine1.Length < 5
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1019, "- Correspondence Client Address line 1 should contain atleast 5 characters."));
            }
            //- Correspondence Client Address line 2 should contain atleast 3 characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.AddressLine2)
                                  && m.AddressLine2.Length < 3
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1020, "- Correspondence Client Address line 2 should contain atleast 3 characters."));
            }

            //- Correspondence Client Address line 3 should contain atleast 3 characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.AddressLine3)
                                  && m.AddressLine3.Length < 3
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1021, "- Correspondence Client Address line 3 should contain atleast 3 characters."));
            }

            //- Correspondence Client Address line 1 should not contain all Special Characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.AddressLine1)
                                  && !m.AddressLine1.Any<Char>(Char.IsLetterOrDigit)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1022, "- Correspondence Client Address line 1 should not contain all Special Characters."));
            }
            //- Correspondence Client Address line 2 should not contain all Special Characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.AddressLine2)
                                  && !m.AddressLine2.Any<Char>(Char.IsLetterOrDigit)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1023, "- Correspondence Client Address line 2 should not contain all Special Characters."));
            }
            //- Correspondence Client Address line 3 should not contain all Special Characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.AddressLine3)
                                  && !m.AddressLine3.Any<Char>(Char.IsLetterOrDigit)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1024, "- Correspondence Client Address line 3 should not contain all Special Characters."));
            }


            //- Correspondence Client Address line 1 should not contain all numbers.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.AddressLine1)
                                  && m.AddressLine1.All<Char>(Char.IsNumber)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1025, "- Correspondence Client Address line 1 should not contain all numbers."));
            }
            //- Correspondence Client Address line 2 should not contain all numbers
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.AddressLine2)
                                  && m.AddressLine2.All<Char>(Char.IsNumber)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1026, "- Correspondence Client Address line 2 should not contain all numbers."));
            }
            //- Correspondence Client Address line 3 should not contain all numbers
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.AddressLine3)
                                  && m.AddressLine3.All<Char>(Char.IsNumber)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1027, "- Correspondence Client Address line 3 should not contain all numbers."));
            }

            //- Correspondence Pin Code should not contain Special Character(s).
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.PinCode)
                                  && !m.PinCode.All<Char>(Char.IsLetterOrDigit)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1028, "- Correspondence Pin Code should not contain Special Character(s)."));
            }

            //- Permanent Pin Code should not contain Special Character(s).
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered 
                                                                          || (r.AddressType==(short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                where !string.IsNullOrEmpty(m.PinCode)
                                  && !m.PinCode.All<Char>(Char.IsLetterOrDigit)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1029, "- Permanent Pin Code should not contain Special Character(s)."));
            }


            //- Correspondence Address Pin Code should be 6 digit.
            l_lstCategoryNo = new List<short>() { 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 115, 116, 119 };
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.PinCode)
                                  && m.PinCode.Length!=6
                                select m).Count() > 0
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where l_lstCategoryNo.Contains(m.ClientType)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1030, "- Correspondence Address Pin Code should be 6 digit."));
            }

            //- Correspondence Address Pin Code should be Maximum 10 characters.
            l_lstCategoryNo = new List<short>() { 111, 112, 113, 114, 117, 118, 120, 121 };
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.PinCode)
                                  && m.PinCode.Length > 10
                                select m).Count() > 0
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where l_lstCategoryNo.Contains(m.ClientType)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1257, "- Correspondence Address Pin Code should be Maximum 10 characters."));
            }

            //- Permanent Address Pin Code should be 6 digit.
            l_lstCategoryNo = new List<short>() { 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 115, 116, 119 };
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered
                                                                          || (r.AddressType == (short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                where !string.IsNullOrEmpty(m.PinCode)
                                  && m.PinCode.Length != 6
                                select m).Count() > 0
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where l_lstCategoryNo.Contains(m.ClientType)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1031, "- Permanent Address Pin Code should be 6 digit."));
            }

            //- Permanent Address Pin Code should be Maximum 10 characters..
            l_lstCategoryNo = new List<short>() { 111, 112, 113, 114, 117, 118, 120, 121 };
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered
                                                                          || (r.AddressType == (short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                where !string.IsNullOrEmpty(m.PinCode)
                                  && m.PinCode.Length > 10
                                select m).Count() > 0
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where l_lstCategoryNo.Contains(m.ClientType)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1258, "- Permanent Address Pin Code should be Maximum 10 characters."));
            }

            //- Correspondence Pin Code should not contain all zeros.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.PinCode)
                                  && m.PinCode.All<Char>(r => r.Equals('0'))
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1045, "- Correspondence Pin Code should not contain all zeros."));
            }

            //- Correspondence Pin Code should not contain all alphabets.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.PinCode)
                                  && m.PinCode.All<Char>(Char.IsLetter)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1046, "- Correspondence Pin Code should not contain all alphabets."));
            }

            //- Permanent Pin Code should not contain all zeros.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered
                                                                          || (r.AddressType == (short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                where !string.IsNullOrEmpty(m.PinCode)
                                  && m.PinCode.All<Char>(r => r.Equals('0'))
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1047, "-- Permanent Pin Code should not contain all zeros."));
            }

            //- Permanent Pin Code should not contain all alphabets.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered
                                                                          || (r.AddressType == (short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                where !string.IsNullOrEmpty(m.PinCode)
                                  && m.PinCode.All<Char>(Char.IsLetter)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1048, "- Permanent Pin Code should not contain all alphabets."));
            }

            //- Permanent Client Address line 1 should contain atleast 5 characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered
                                                                          || (r.AddressType == (short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                where !string.IsNullOrEmpty(m.AddressLine1)
                                  && m.AddressLine1.Length < 5
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1049, "- Permanent Client Address line 1 should contain atleast 5 characters."));
            }
            //- Permanent Client Address line 2 should contain atleast 3 characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered
                                                                          || (r.AddressType == (short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                where !string.IsNullOrEmpty(m.AddressLine2)
                                  && m.AddressLine2.Length < 3
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1050, "- Permanent Client Address line 2 should contain atleast 3 characters."));
            }

            //- Permanent Client Address line 3 should contain atleast 3 characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered
                                                                          || (r.AddressType == (short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                where !string.IsNullOrEmpty(m.AddressLine3)
                                  && m.AddressLine3.Length < 3
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1051, "- Permanent Client Address line 3 should contain atleast 3 characters."));
            }

            //- Permanent Client Address line 1 should not contain all Special Characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered
                                                                          || (r.AddressType == (short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                where !string.IsNullOrEmpty(m.AddressLine1)
                                  && !m.AddressLine1.Any<Char>(Char.IsLetterOrDigit)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1052, "- Permanent Client Address line 1 should not contain all Special Characters."));
            }
            //- Permanent Client Address line 2 should not contain all Special Characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered
                                                                          || (r.AddressType == (short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                where !string.IsNullOrEmpty(m.AddressLine2)
                                  && !m.AddressLine2.Any<Char>(Char.IsLetterOrDigit)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1053, "- Permanent Client Address line 2 should not contain all Special Characters."));
            }
            //- Permanent Client Address line 3 should not contain all Special Characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered
                                                                          || (r.AddressType == (short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                where !string.IsNullOrEmpty(m.AddressLine3)
                                  && !m.AddressLine3.Any<Char>(Char.IsLetterOrDigit)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1054, "- Permanent Client Address line 3 should not contain all Special Characters."));
            }

            //- Permanent Client Address line 1 should not contain all numbers.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered
                                                                          || (r.AddressType == (short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                where !string.IsNullOrEmpty(m.AddressLine1)
                                  && m.AddressLine1.All<Char>(Char.IsNumber)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1055, "- Permanent Client Address line 1 should not contain all numbers."));
            }
            //- Permanent Client Address line 2 should not contain all numbers
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered
                                                                          || (r.AddressType == (short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                where !string.IsNullOrEmpty(m.AddressLine2)
                                  && m.AddressLine2.All<Char>(Char.IsNumber)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1056, "- Permanent Client Address line 2 should not contain all numbers."));
            }
            //- Permanent Client Address line 3 should not contain all numbers
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered
                                                                          || (r.AddressType == (short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                where !string.IsNullOrEmpty(m.AddressLine3)
                                  && m.AddressLine3.All<Char>(Char.IsNumber)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1057, "- Permanent Client Address line 3 should not contain all numbers."));
            }

            //- Correspondence Client city should contain atleast 3 characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.City)
                                  && m.City.Length < 3
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1058, "- Correspondence Client city should contain atleast 3 characters."));
            }

            //- Permanent Client city should contain atleast 3 characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered
                                                                          || (r.AddressType == (short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                where !string.IsNullOrEmpty(m.City)
                                  && m.City.Length < 3
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1059, "- Permanent Client city should contain atleast 3 characters."));
            }

            //-Correspondence Client city should not contain Special Characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.City)
                                  && !m.City.All<Char>(Char.IsLetterOrDigit)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1060, "- Correspondence Client city should not contain Special Characters."));
            }

            //- Permanent Client city should not contain Special Characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered
                                                                          || (r.AddressType == (short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                where!string.IsNullOrEmpty(m.City)
                                  && !m.City.All<Char>(Char.IsLetterOrDigit)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1061, "- Permanent Client city should not contain Special Characters."));
            }


            //- Correspondence Client city should not contain all numbers.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.City)
                                  && m.City.All<Char>(Char.IsNumber)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1062, "- Correspondence Client city should not contain all numbers."));
            }

            //- Permanent Client city should not contain all numbers.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered
                                                                          || (r.AddressType == (short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                where !string.IsNullOrEmpty(m.City)
                                  && m.City.All<Char>(Char.IsNumber)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1063, "- Permanent Client city should not contain all numbers."));
            }

            //- Residence Telephone Number should not contain all alphabets.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.ResTelNo)
                                  && m.ResTelNo.All<Char>(Char.IsLetter)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1064, "- Residence Telephone Number should not contain all alphabets."));
            }

            //- Residence Telephone Number should not contain Special Characters except (,-()/space)
            Char[] l_SpecialChars ={'~','`','#','$','%','^','*','=','+','@','{','}','\\','|',':','"',';','<','>','?'};
            
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.ResTelNo)
                                  && m.ResTelNo.Any<Char>(r => (l_SpecialChars.Contains(r)))
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1065, "- Residence Telephone Number should not contain Special Characters except (,-()/space)."));
            }

            //- Residence Telephone Number should contain atleast 5 characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.ResTelNo)
                                  && m.ResTelNo.Length < 5
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1066, "- Residence Telephone Number should contain atleast 5 characters."));
            }

            //- Office Telephone Number should not contain Special Characters except (,-()/space)
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.OffTelNo)
                                  && m.OffTelNo.Any<Char>(r => (l_SpecialChars.Contains(r)))
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1067, "- Office Telephone Number should not contain Special Characters except (,-()/space)."));
            }

            //- Mobile Number should contain valid values
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.Mobile1)
                                  && !m.Mobile1.All<Char>(Char.IsNumber)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1068, "- Mobile Number should contain valid values"));
            }

            //- Mobile No should not contain all zeros.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.Mobile1)
                                  && m.Mobile1.All<Char>(r => r.Equals('0'))
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1069, "- Mobile No should not contain all zeros."));
            }

            //- Mobile Number should contain atleast 10 characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.Mobile1)
                                  && m.Mobile1.Length < 10
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1070, "- Mobile Number should contain atleast 10 characters."));
            }

            //- Residence Telephone Number''s ISD Code should contain valid values.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.ResTelNoISDCode)
                                  && !m.ResTelNoISDCode.All<Char>(Char.IsNumber)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1071, "- Residence Telephone Number''s ISD Code should contain valid values."));
            }

            //- Residence Telephone Number''s ISD Code should contain atleast 2 digit.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.ResTelNoISDCode)
                                  && m.ResTelNoISDCode.Length<2
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1072, "- Residence Telephone Number''s ISD Code should contain atleast 2 digit."));
            }

            //- Residence Telephone Number''s STD Code should contain valid values.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                 && !string.IsNullOrEmpty(m.ResTelNoSTDCode)
                                 && !m.ResTelNoSTDCode.All<Char>(Char.IsNumber)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1073, "- Residence Telephone Number''s STD Code should contain valid values."));
            }

            //- Residence Telephone Number''s STD Code should not contain all zeros.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                 && !string.IsNullOrEmpty(m.ResTelNoSTDCode)
                                 && m.ResTelNoSTDCode.All<Char>(r => r.Equals('0'))
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1074, "- Residence Telephone Number''s STD Code should not contain all zeros."));
            }

            //- Residence Telephone Number''s STD Code should contain atleast 2 characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                 && !string.IsNullOrEmpty(m.ResTelNoSTDCode)
                                 && m.ResTelNoSTDCode.Length < 2
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1075, "- Residence Telephone Number''s STD Code should contain atleast 2 characters."));
            }

            //-Office Telephone Number''s STD code should contain atleast 2 characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                 && !string.IsNullOrEmpty(m.OffTelNoSTDCode)
                                 && m.OffTelNoSTDCode.Length < 2
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1076, "- Office Telephone Number''s STD code should contain atleast 2 characters."));
            }

            //- Office Telephone Number''s ISD code should contain valid values.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.OffTelNoISDCode)
                                  && !m.OffTelNoISDCode.All<Char>(Char.IsNumber)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1077, "- Office Telephone Number''s ISD code should contain valid values."));
            }

            //- Office Telephone Number''s ISD code should contain atleast 2 characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.OffTelNoISDCode)
                                  && m.OffTelNoISDCode.Length < 2
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1078, "- Office Telephone Number''s ISD code should contain atleast 2 characters."));
            }

            //- Office Telephone Number''s STD code should contain valid values.'
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                 && !string.IsNullOrEmpty(m.OffTelNoSTDCode)
                                 && !m.OffTelNoSTDCode.All<Char>(Char.IsNumber)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1079, "- Office Telephone Number''s STD code should contain valid values.'"));
            }

            //- - Office Telephone Number''s STD code should not contain all zeros.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                 && !string.IsNullOrEmpty(m.OffTelNoSTDCode)
                                 && m.OffTelNoSTDCode.All<Char>(r => r.Equals('0'))
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1080, "- Office Telephone Number''s STD code should not contain all zeros."));
            }

            //- Office Telephone No should not contain all alphabets.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                 && !string.IsNullOrEmpty(m.OffTelNo)
                                 && m.OffTelNo.All<Char>(Char.IsLetter)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1081, "- Office Telephone No should not contain all alphabets."));
            }

            //- Office Telephone Number should contain atleast 5 characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                 && !string.IsNullOrEmpty(m.OffTelNo)
                                 && m.OffTelNo.Length < 5
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1082, "- Office Telephone Number should contain atleast 5 characters."));
            }

            //- Residence Telephone No should not contain all zeros.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                 && !string.IsNullOrEmpty(m.ResTelNo)
                                 && m.ResTelNo.All<Char>(r => r.Equals('0'))
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1083, "- Residence Telephone No should not contain all zeros."));
            }

            //- Office Telephone No should not contain all zeros.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                 && !string.IsNullOrEmpty(m.OffTelNo)
                                 && m.OffTelNo.All<Char>(r => r.Equals('0'))
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1084, "- Office Telephone No should not contain all zeros."));
            }

            //- Default Correspondence Address is mandatory
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                select m).Count() == 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1140, "- Default Correspondence Address is mandatory."));
            }

            //- Correspondence Address City is mandatory.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                  && string.IsNullOrEmpty(m.City)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1141, "- Correspondence Address City is mandatory."));
            }

            //- Correspondence Address State (Other) is Mandatory.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                  && string.IsNullOrEmpty(m.StateOther)
                                  && m.StateNumber==99
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1142, "- Correspondence Address State (Other) is Mandatory."));
            }

            //- Correspondence Address State (Other) should contain atleast 3 characters.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                  && !string.IsNullOrEmpty(m.StateOther)
                                  && m.StateOther.Length < 3
                                  && m.StateNumber == 99
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1143, "- Correspondence Address State (Other) should contain atleast 3 characters."));
            }

            //- Permanent Address is mandatory.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered
                                                                          || (r.AddressType == (short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                select m).Count() <= 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1144, "- Permanent Address is mandatory."));
            }

            //- Permanent Address City is mandatory.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered
                                                                          || (r.AddressType == (short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                where string.IsNullOrEmpty(m.City)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1145, "- Permanent Address City is mandatory."));
            }

            //- Permanent Address State (Other) is Mandatory.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered
                                                                          || (r.AddressType == (short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                where string.IsNullOrEmpty(m.StateOther)
                                && m.StateNumber==99
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1146, "- Permanent Address State (Other) is Mandatory."));
            }

            //- Permanent Address State (Other) should contain atleast 3 characters
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered
                                                                          || (r.AddressType == (short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                where !string.IsNullOrEmpty(m.StateOther)
                                && m.StateOther.Length < 3
                                && m.StateNumber == 99
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1147, "- Permanent Address State (Other) should contain atleast 3 characters."));
            }

            //- Correspondence Address Pin Code is mandatory
            l_lstCategoryNo = new List<short>() { 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 115, 116, 119 };
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                && String.IsNullOrEmpty(m.PinCode)
                                select m
                                ).Count() > 0
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where l_lstCategoryNo.Contains(m.ClientType)
                                select m
                                ).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1154, "- Correspondence Address Pin Code is mandatory."));
            }

            //- Client Email Id is mandatory
            l_lstCategoryNo = new List<short>() { 106, 107, 108, 109, 112, 116, 121, 122, 123, 124 };
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson)
                                where m.Default == true
                                && String.IsNullOrEmpty(m.EMailId)
                                select m
                                ).Count() > 0
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where l_lstCategoryNo.Contains(m.ClientType)
                                select m
                                ).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1155, "- Client Email Id is mandatory."));
            }

            //- Permanent Address Pin Code is mandatory
            l_lstCategoryNo = new List<short>() { 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 115, 116, 119 };
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered
                                                                          || (r.AddressType == (short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                where string.IsNullOrEmpty(m.PinCode)
                                select m).Count() > 0
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where l_lstCategoryNo.Contains(m.ClientType)
                                select m
                                ).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1156, "- Permanent Address Pin Code is mandatory."));
            }

            //- Name of Contact Person 1 is Mandatory
            l_lstCategoryNo = new List<short>() { 102, 103, 104, 105 };
            resClients = from c in Clients
                         where (c.ClientAddressesNew.Count<CUCCClientAddress>(r => r.AddressType == (short)AddressTypeEnum.ContactPerson) < 1
                                 || string.IsNullOrEmpty((from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.ContactPerson)
                                                          orderby m.ContactPersonDefault descending, m.AddressNo
                                                          select m
                                                          ).ElementAt(0).ContactPerson
                                                        )
                               )
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where l_lstCategoryNo.Contains(m.ClientType)
                                select m
                                ).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1180, "- Name of Contact Person 1 is Mandatory."));
            }

            //- Name of Contact Person 2 is Mandatory
            l_lstCategoryNo = new List<short>() { 102, 104, 105 };
            resClients = from c in Clients
                         where (c.ClientAddressesNew.Count<CUCCClientAddress>(r => r.AddressType == (short)AddressTypeEnum.ContactPerson) < 2
                                 || string.IsNullOrEmpty((from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.ContactPerson)
                                                          orderby m.ContactPersonDefault descending, m.AddressNo
                                                          select m
                                                          ).ElementAt(1).ContactPerson
                                                        )
                               )
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where l_lstCategoryNo.Contains(m.ClientType)
                                select m
                                ).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1181, "- Name of Contact Person 2 is Mandatory."));
            }

            //- Designation of Contact Person 1 is Mandatory
            l_lstCategoryNo = new List<short>() { 102, 103, 104, 105 };
            resClients = from c in Clients
                         where (c.ClientAddressesNew.Count<CUCCClientAddress>(r => r.AddressType == (short)AddressTypeEnum.ContactPerson) < 1
                                 || string.IsNullOrEmpty((from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.ContactPerson)
                                                          orderby m.ContactPersonDefault descending, m.AddressNo
                                                          select m
                                                          ).ElementAt(0).Designation
                                                        )
                               )
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where l_lstCategoryNo.Contains(m.ClientType)
                                select m
                                ).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1182, "- Designation of Contact Person 1 is Mandatory."));
            }

            //- Designation of Contact Person 2 is Mandatory
            l_lstCategoryNo = new List<short>() { 102, 104, 105 };
            resClients = from c in Clients
                         where (c.ClientAddressesNew.Count<CUCCClientAddress>(r => r.AddressType == (short)AddressTypeEnum.ContactPerson) < 2
                                 || string.IsNullOrEmpty((from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.ContactPerson)
                                                          orderby m.ContactPersonDefault descending, m.AddressNo
                                                          select m
                                                          ).ElementAt(1).Designation
                                                        )
                               )
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where l_lstCategoryNo.Contains(m.ClientType)
                                select m
                                ).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1183, "- Designation of Contact Person 2 is Mandatory"));
            }

            //- PAN of Contact Person 1 is Mandatory
            l_lstCategoryNo = new List<short>() { 102, 103, 104, 105 };
            resClients = from c in Clients
                         where (c.ClientAddressesNew.Count<CUCCClientAddress>(r => r.AddressType == (short)AddressTypeEnum.ContactPerson) < 1
                                 || string.IsNullOrEmpty((from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.ContactPerson)
                                                          orderby m.ContactPersonDefault descending, m.AddressNo
                                                          select m
                                                          ).ElementAt(0).PAN
                                                        )
                               )
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where l_lstCategoryNo.Contains(m.ClientType)
                                select m
                                ).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1184, "- PAN of Contact Person 1 is Mandatory."));
            }

            //- PAN of Contact Person 2 is Mandatory
            l_lstCategoryNo = new List<short>() { 102, 104, 105 };
            resClients = from c in Clients
                         where (c.ClientAddressesNew.Count<CUCCClientAddress>(r => r.AddressType == (short)AddressTypeEnum.ContactPerson) < 2
                                 || string.IsNullOrEmpty((from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.ContactPerson)
                                                          orderby m.ContactPersonDefault descending, m.AddressNo
                                                          select m
                                                          ).ElementAt(1).PAN
                                                        )
                               )
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where l_lstCategoryNo.Contains(m.ClientType)
                                select m
                                ).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1185, "- PAN of Contact Person 2 is Mandatory"));
            }


            //- Addresss of Contact Person 1 is Mandatory
            l_lstCategoryNo = new List<short>() { 102, 103, 104, 105 };
            resClients = from c in Clients
                         where (c.ClientAddressesNew.Count<CUCCClientAddress>(r => r.AddressType == (short)AddressTypeEnum.ContactPerson) < 1
                                || string.IsNullOrEmpty((from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.ContactPerson)
                                                         orderby m.ContactPersonDefault descending, m.AddressNo
                                                         select new { AddressLine1234 = (Convert.ToString(m.AddressLine1) + Convert.ToString(m.AddressLine2) + Convert.ToString(m.AddressLine3) + Convert.ToString(m.AddressLine4)) }
                                                         ).ElementAt(0).AddressLine1234
                                                       )
                               )
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where l_lstCategoryNo.Contains(m.ClientType)
                                select m
                                ).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1186, "- Addresss of Contact Person 1 is Mandatory."));
            }

            //- Addresss of Contact Person 2 is Mandatory
            l_lstCategoryNo = new List<short>() { 102, 104, 105 };
            resClients = from c in Clients
                         where (c.ClientAddressesNew.Count<CUCCClientAddress>(r => r.AddressType == (short)AddressTypeEnum.ContactPerson) < 2
                                 || string.IsNullOrEmpty((from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.ContactPerson)
                                                          orderby m.ContactPersonDefault descending, m.AddressNo
                                                          select new { AddressLine1234 = (Convert.ToString(m.AddressLine1) + Convert.ToString(m.AddressLine2) + Convert.ToString(m.AddressLine3) + Convert.ToString(m.AddressLine4)) }
                                                          ).ElementAt(1).AddressLine1234
                                                        )
                               )
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where l_lstCategoryNo.Contains(m.ClientType)
                                select m
                                ).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1187, "- Addresss of Contact Person 2 is Mandatory"));
            }

            //- Contacts of Contact Person 1 is Mandatory.
            l_lstCategoryNo = new List<short>() { 102, 103, 104, 105 };
            resClients = from c in Clients
                         where (c.ClientAddressesNew.Count<CUCCClientAddress>(r => r.AddressType == (short)AddressTypeEnum.ContactPerson) < 1
                                || string.IsNullOrEmpty((from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.ContactPerson)
                                                         orderby m.ContactPersonDefault descending, m.AddressNo
                                                         select new { Telephone1 = String.IsNullOrEmpty(m.ResTelNo) ? String.IsNullOrEmpty(m.OffTelNo) ? String.IsNullOrEmpty(m.Mobile1) ? "" : m.Mobile1 : m.OffTelNo : m.ResTelNo }
                                                         ).ElementAt(0).Telephone1
                                                       )
                               )
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where l_lstCategoryNo.Contains(m.ClientType)
                                select m
                                ).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1188, "- Contacts of Contact Person 1 is Mandatory."));
            }

            //- Contacts of Contact Person 2 is Mandatory
            l_lstCategoryNo = new List<short>() { 102, 104, 105 };
            resClients = from c in Clients
                         where (c.ClientAddressesNew.Count<CUCCClientAddress>(r => r.AddressType == (short)AddressTypeEnum.ContactPerson) < 2
                                 || string.IsNullOrEmpty((from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.ContactPerson)
                                                          orderby m.ContactPersonDefault descending, m.AddressNo
                                                          select new { Telephone1 = String.IsNullOrEmpty(m.ResTelNo) ? String.IsNullOrEmpty(m.OffTelNo) ? String.IsNullOrEmpty(m.Mobile1) ? "" : m.Mobile1 : m.OffTelNo : m.ResTelNo }
                                                         ).ElementAt(1).Telephone1
                                                        )
                               )
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where l_lstCategoryNo.Contains(m.ClientType)
                                select m
                                ).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1189, "- Contacts of Contact Person 2 is Mandatory"));
            }

            //- DIN of Contact Person 1 is Mandatory.
            l_lstCategoryNo = new List<short>() { 104};
            resClients = from c in Clients
                         where (c.ClientAddressesNew.Count<CUCCClientAddress>(r => r.AddressType == (short)AddressTypeEnum.ContactPerson) < 1
                                || string.IsNullOrEmpty((from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.ContactPerson)
                                                         orderby m.ContactPersonDefault descending, m.AddressNo
                                                         select m
                                                         ).ElementAt(0).DIN
                                                       )
                               )
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where l_lstCategoryNo.Contains(m.ClientType)
                                select m
                                ).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1190, "- DIN of Contact Person 1 is Mandatory."));
            }

            //- DIN of Contact Person 2 is Mandatory
            l_lstCategoryNo = new List<short>() { 104};
            resClients = from c in Clients
                         where (c.ClientAddressesNew.Count<CUCCClientAddress>(r => r.AddressType == (short)AddressTypeEnum.ContactPerson) < 2
                                 || string.IsNullOrEmpty((from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.ContactPerson)
                                                          orderby m.ContactPersonDefault descending, m.AddressNo
                                                          select m
                                                         ).ElementAt(1).DIN
                                                        )
                               )
                            && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
                                where l_lstCategoryNo.Contains(m.ClientType)
                                select m
                                ).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1191, "- DIN of Contact Person 2 is Mandatory"));
            }

            //- Correspondence Address State is mandatory.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                  && m.StateNumber == 0
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1214, "- Correspondence Address State is mandatory."));
            }

            //- Correspondence Address Country is mandatory.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Correspondence)
                                where m.Default == true
                                  && m.CountryCode == 0
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1215, "- Correspondence Address Country is mandatory."));
            }

            //- Permanent Address State is mandatory.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered
                                                                          || (r.AddressType == (short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                where m.StateNumber==0
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1219, "- Permanent Address State is mandatory."));
            }

            //- Permanent Address Country is mandatory.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.Registered
                                                                          || (r.AddressType == (short)AddressTypeEnum.Correspondence && r.SameCorrPermAdd)
                                                                    )
                                where m.CountryCode == 0
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1220, "- Permanent Address Country is mandatory."));
            }

            //- Residence STD Code is Mandatory for given Residence Telephone Number.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson && r.Default==true)
                                where !String.IsNullOrEmpty(m.ResTelNo) 
                                   && String.IsNullOrEmpty(m.ResTelNoSTDCode)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1221, "- Residence STD Code is Mandatory for given Residence Telephone Number."));
            }

            //- Office STD Code is Mandatory for given Office Telephone Number.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson && r.Default == true)
                                where !String.IsNullOrEmpty(m.OffTelNo) && String.IsNullOrEmpty(m.OffTelNoSTDCode)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1222, "- Office STD Code is Mandatory for given Office Telephone Number."));
            }

            //- Either Telephone Number (Residence/Office) or Mobile Number is Mandatory.
            resClients = from c in Clients
                         where (from m in c.ClientAddressesNew.Where(r => r.AddressType != (short)AddressTypeEnum.ContactPerson && r.Default == true)
                                where String.IsNullOrEmpty(m.ResTelNo) 
                                   && String.IsNullOrEmpty(m.OffTelNo)
                                   && String.IsNullOrEmpty(m.Mobile1)
                                select m).Count() > 0
                         select c;
            foreach (CClient client in resClients)
            {
                this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1223, "- Either Telephone Number (Residence/Office) or Mobile Number is Mandatory."));
            }

            //////////- DIN of Contact Person 1 is Mandatory when Corporate Client Type is Selected
            ////////l_lstCategoryNo = new List<short>() { 102, 103, 104, 105 };
            ////////resClients = from c in Clients
            ////////             where (c.ClientAddressesNew.Count<CUCCClientAddress>(r => r.AddressType == (short)AddressTypeEnum.ContactPerson) < 1
            ////////                     || ((from m in c.ClientAddressesNew.Where(r => r.AddressType == (short)AddressTypeEnum.ContactPerson)
            ////////                         orderby m.ContactPersonDefault descending, m.AddressNo
            ////////                         select m
            ////////                         ).ElementAtOrDefault<CUCCClientAddress>(0).
            ////////                        )
                                    

                                    
            ////////                                              //ElementAt<CUCCClientAddress>(0).Count<CUCCClientAddress>(r => String.IsNullOrEmpty(r.DIN) && !String.IsNullOrEmpty(r.ContactPerson)) > 0


            ////////                   )
            ////////                && (from m in c.ClientExchanges.Where(r => r.ExchangeType == ExchangeType.NSE.ToString())
            ////////                    where !l_lstCategoryNo.Contains(m.ClientType)
            ////////                    select m
            ////////                    ).Count() > 0
            ////////             select c;
            ////////foreach (CClient client in resClients)
            ////////{
            ////////    this.m_ValidationResult.Add(new Result(ExchangeType.NSE.ToString(), EntityType.Address, client.ClientCode, client.ClientName, 1233, "- DIN of Contact Person 1 is Mandatory when Corporate Client Type is Selected."));
            ////////}

        }

        /// <summary>
        /// Client Bank specific UCC field validation
        /// </summary>
        /// <param name="Client"></param>
        public void ValidateBank(List<CClient> Client)
        {
        }

        /// <summary>
        /// Client DP specific UCC field validation
        /// </summary>
        /// <param name="Client"></param>
        public void ValidateDP(List<CClient> Client)
        {
        }
        #endregion

        #region Property
        /// <summary>
        /// return result of validation
        /// </summary>
        public CValidationResult ValidationResult
        {
            get { return m_ValidationResult; }

        }
        #endregion
    }
}
