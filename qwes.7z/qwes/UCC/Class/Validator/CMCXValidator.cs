﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UCC.Class.Validator
{
    class CMCXValidator : CValidatorManager
    {
    }
}
