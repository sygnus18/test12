﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using System.ComponentModel;

using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using System.Data.SqlClient;

using UCC.Forms;

namespace UCC.Class
{
    /// <summary>
    /// BL class of UCC Client screen
    /// </summary>
    public class CUCCClient
    {
        /// <summary>
        /// Callback delegate to enable callback when Asynchronous UCC data synchronization is completed
        /// </summary>
        /// <param name="SynchUCCDataResult"></param>
        public delegate void SynchronizeClientUCCDataCompletedCallBack(MethodExecResult SynchUCCDataResult);

        /// <summary>
        /// Retrives UCC Client Data for given filters.
        /// </summary>
        /// <param name="p_vobjFilterParams">Filter Parameters</param>
        /// <param name="p_vdtUCCData">Return UCC Data</param>
        /// <returns>Method Execution Result</returns>
        #region GetUCCClientFilterData
        public MethodExecResult GetUCCClientFilterData(FilterParameters p_vobjFilterParams, ref DataTable p_vdtUCCData)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_GetUCCDetails");
            l_objDbWorkItem.ResultType = QueryType.DataSet;
            l_objDbWorkItem.AddParameter("@ps_ClientCode", SqlDbType.VarChar, p_vobjFilterParams.ClientCode);
            l_objDbWorkItem.AddParameter("@ps_ClientName", SqlDbType.VarChar, p_vobjFilterParams.ClientName);
            l_objDbWorkItem.AddParameter("@pn_ExchangeNo", SqlDbType.Int, p_vobjFilterParams.ExchangeNo);
            l_objDbWorkItem.AddParameter("@ps_BranchCode", SqlDbType.VarChar, p_vobjFilterParams.Branch);
            l_objDbWorkItem.AddParameter("@ps_G3Code", SqlDbType.VarChar, p_vobjFilterParams.G3);
            if(p_vobjFilterParams.FromCreationDate.HasValue)
                l_objDbWorkItem.AddParameter("@pd_FromCreationDate", SqlDbType.DateTime, p_vobjFilterParams.FromCreationDate.Value.Date);
            if (p_vobjFilterParams.ToCreationDate.HasValue)
                l_objDbWorkItem.AddParameter("@pd_ToCreationDate", SqlDbType.DateTime, p_vobjFilterParams.ToCreationDate.Value.Date);
            //l_objDbWorkItem.AddParameter("@pn_ClientType", SqlDbType.Int, p_vobjFilterParams.ClientType);
            l_objDbWorkItem.AddParameter("@UserNo", SqlDbType.VarChar, AppEnvironment.AppUser.UserNo);
            
            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;
                if ((l_dsReturnData == null) || (l_dsReturnData.Tables.Count == 0))
                    return new MethodExecResult(1, "No data found", "stp_GetUCCFilterDetails. Database returned no data. UserNo. " + AppEnvironment.AppUser.UserNo.ToString(), null);
                else
                {
                    p_vdtUCCData = l_dsReturnData.Tables[0];
                    return l_objDbWorkItem.ExecutionStatus;
                }
            }
            else
            {
                return l_objDbWorkItem.ExecutionStatus;
            }
        }
        #endregion

        /// <summary>
        /// Synchronizes client UCC data with Base application data
        /// </summary>
        /// <param name="p_vobjFilterParams">Filter parameters</param>
        /// <param name="RunAsynchronously">Indicates if operation should run Asynchronously</param>
        /// <param name="OnSynchronizeClientUCCDataCompleted">Callback if operation should run Asynchronously</param>
        /// <param name="SynchronizeResult">Result of UCC data synchronization</param>
        /// <returns>Method Execution Result</returns>
        #region SynchronizeClientUCCData
        public MethodExecResult SynchronizeClientUCCData(FilterParameters p_vobjFilterParams, bool RunAsynchronously, 
            SynchronizeClientUCCDataCompletedCallBack OnSynchronizeClientUCCDataCompleted, ref DataTable SynchronizeResult)
        {
            if (RunAsynchronously)
            {
                //BackgroundWorker l_objSynchClientUCCData = new BackgroundWorker();
                //l_objSynchClientUCCData.DoWork += new DoWorkEventHandler(SynchClientUCCData_DoWork);
                //l_objSynchClientUCCData.RunWorkerAsync(OnSynchronizeClientUCCDataCompleted);

                //return new MethodExecResult(MethodExecResult.SuccessfulReturnCode);
                return new MethodExecResult(1, "Not supported", "Client UCC Migration - running Asynchronously is not supported", null);
            }
            else
            {
                return SynchronizeClientUCCDataInternal(p_vobjFilterParams, ref SynchronizeResult);
            }
        }
        #endregion

        #region SynchClientUCCData_DoWork (not used)
        //private void SynchClientUCCData_DoWork(object sender, DoWorkEventArgs e)
        //{
        //    MethodExecResult l_objMethodExecResult = SynchronizeClientUCCDataInternal();

        //    SynchronizeClientUCCDataCompletedCallBack OnSynchronizeClientUCCDataCompleted = e.Argument as SynchronizeClientUCCDataCompletedCallBack;
        //    if (OnSynchronizeClientUCCDataCompleted != null)
        //    {
        //        OnSynchronizeClientUCCDataCompleted(l_objMethodExecResult);
        //    }
        //}
        #endregion

        /// <summary>
        /// Synchronizes client UCC data with Base application data
        /// </summary>
        /// <param name="p_vobjFilterParams">Filter paameters</param>
        /// <param name="p_rdtResultData">Synchronization result</param>
        /// <returns>Method Execution Result</returns>
        #region SynchronizeClientUCCDataInternal
        private MethodExecResult SynchronizeClientUCCDataInternal(FilterParameters p_vobjFilterParams, ref DataTable p_rdtResultData)
        {
            DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_MigrateClientDetailsForUCC");
            l_objDbWorkItem.ResultType = QueryType.DataSet;
            l_objDbWorkItem.AddParameter("@ps_ClientCode", SqlDbType.VarChar, p_vobjFilterParams.ClientCode);
            l_objDbWorkItem.AddParameter("@ps_ClientName", SqlDbType.VarChar, p_vobjFilterParams.ClientName);
            l_objDbWorkItem.AddParameter("@pn_ExchangeNo", SqlDbType.Int, p_vobjFilterParams.ExchangeNo);
            l_objDbWorkItem.AddParameter("@ps_BranchCode", SqlDbType.VarChar, p_vobjFilterParams.Branch);
            l_objDbWorkItem.AddParameter("@ps_G3Code", SqlDbType.VarChar, p_vobjFilterParams.G3);
            if (p_vobjFilterParams.FromCreationDate.HasValue)
                l_objDbWorkItem.AddParameter("@pd_FromCreationDate", SqlDbType.DateTime, p_vobjFilterParams.FromCreationDate.Value.Date);
            if (p_vobjFilterParams.ToCreationDate.HasValue)
                l_objDbWorkItem.AddParameter("@pd_ToCreationDate", SqlDbType.DateTime, p_vobjFilterParams.ToCreationDate.Value.Date);
            l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.VarChar, AppEnvironment.AppUser.UserNo);

            DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);
            DataSet l_dsResult = l_objDbWorkItem.Result as DataSet;
            if (
                (l_dsResult != null)
                && (l_dsResult.Tables.Count > 0)
                )
            {
                p_rdtResultData = l_dsResult.Tables[0];
            }

            return l_objDbWorkItem.ExecutionStatus;
        }
        #endregion

    }
}
