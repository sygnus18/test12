﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Reflection;
using System.Xml.Serialization;
using System.IO;

namespace UCC.Class
{
    /// <summary>
    /// Enums for vaildation
    /// </summary>
    public enum ValidationGroup
    {
        RequiredField = 1,
        DataType = 2,
        Other = 3
    }


    /// <summary>
    /// Class for validation result 
    /// </summary>
    public class ValidationResult
    {
        public ValidationResult(ValidationGroup group)
        {
            this.Validation = group;

            InvaildFields = new Dictionary<string,string>();

            IsValid = true;
        }

        /// <summary>
        /// Validation group enum
        /// </summary>
        public ValidationGroup Validation { get; set; }

        /// <summary>
        /// Dictionary of InvaildFields [ColumnName, Column Description)
        /// </summary>
        public Dictionary<string,string> InvaildFields { get; set; }

        /// <summary>
        /// Object type which will be validate
        /// </summary>
        public Type SourceObjectType { get; set; }

        /// <summary>
        /// Flag for object vaild or not
        /// </summary>
        public bool IsValid { get; set; }

    }
    

    /// <summary>
    /// Custom property attribute for providing field's format(ex. Length, Padding Char etc.)   
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class DataField  : Attribute
    {
        private bool m_HasPaddingChar = false;
        private char m_PaddingChar;
        private bool m_IsIndividual;

        public DataField()
        {
            IsRequired = false;
            IsMoney = false;
        }

        /// <summary>
        /// Check padding character required or not 
        /// </summary>
        public bool HasPaddingChar
        {
          get { return m_HasPaddingChar; }

        }

        /// <summary>
        /// Length of the field( useful for fix length field record)
        /// </summary>
        public int Length { get; set; }
        
        /// <summary>
        /// Index of the field
        /// </summary>
        public int Index { get; set; }


        /// <summary>
        /// Padding Character for numeric type 
        /// </summary>
        public char PaddingCharacter
        {
            get { return m_PaddingChar; }
            set
            {  
                m_HasPaddingChar = true;
                m_PaddingChar = value;
            }
        }

        /// <summary>
        /// Check if field is required 
        /// </summary>
        public bool IsRequired { get; set; }



        /// <summary>
        /// Is Field of Individual Client
        /// </summary>
        public bool IsIndividual
        {
            get { return m_IsIndividual; }
            set
            {
                m_IsIndividual = value;
            }
        }

        /// <summary>
        /// Is field is used to store money data
        /// </summary>
        public bool IsMoney { get; set; }


        /// <summary>
        /// Name of the field
        /// </summary>
        public string Name { get; set; } 
  
    }


    /// <summary>
    /// Class for common static methods 
    /// </summary>
    public static class Utility
    {


        /// <summary>
        /// Generate fix length string
        /// </summary>
        /// <param name="value">Source string</param>
        /// <param name="length">Desired length of string</param>
        /// <returns>Fix length string</returns>
        public static string GetFixLenString(string value, int length)
        {
            if (value == null)
                value = "";
            StringBuilder sb = new StringBuilder(length);
            sb.Append(value).ToString();
            return sb.ToString().PadLeft(length);
        }


        /// <summary>
        /// Generate fix length string
        /// </summary>
        /// <param name="value">Source string</param>
        /// <param name="length">Desired length of string</param>
        /// <param name="paddingCharacter">Padding character</param>
        /// <returns>Fix length string</returns>
        public static string GetFixLenString(string value, int length, char paddingChar)
        {
            if (value == null)
                value = "";
            return value.PadLeft(length,paddingChar);
        }


        /// <summary>
        /// Get DataTable from Enum's name and its respective value
        /// </summary>
        /// <typeparam name="T">Source Enum type</typeparam>
        /// <param name="bIsFirstRequired">If first row required</param>
        /// <param name="sFirstText">Fist row text</param>
        /// <param name="nFirstValue">First row value</param>
        /// <returns>DataTable of Enum Name and value  </returns>
        public static DataTable GetDataTableFromEnum<T>(bool bIsFirstRequired, string sFirstText, int? nFirstValue) where T : struct 
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ENumName");
            dt.Columns.Add("EnumValue");

            T[] enums = (T[])Enum.GetValues(typeof(T));

            if (bIsFirstRequired)
            {
                sFirstText = sFirstText ?? string.Empty;
                nFirstValue = nFirstValue ?? 0;
                dt.Rows.Add(sFirstText, nFirstValue);
            }

            foreach (T en in enums)
            {
                dt.Rows.Add(Enum.GetName(typeof(T),en) , Convert.ToInt32(en) );
            }
            return dt;
        }

        /// <summary>
        /// Join properties into the string 
        /// </summary>
        /// <param name="obj">Source object which properties would be joined, those having property attribute [DataField]</param>
        /// <returns>joined string</returns>
        public static string JoinProperties(object obj)
        {
            PropertyInfo[] propInfo = obj.GetType().GetProperties();

            StringBuilder sb = new StringBuilder();

            string valueString = string.Empty;

            foreach (PropertyInfo pi in propInfo)
            {

                object val = pi.GetValue(obj, null);

                object[] DataFieldAttrs = pi.GetCustomAttributes(typeof(DataField), false);

                if (DataFieldAttrs != null)
                {
                    //Only property decorated  with attribute [DataField] will be appended in string
                    if (DataFieldAttrs.Length > 0)
                    {
                        DataField attrDataField = (DataField)DataFieldAttrs[0];
             
                        if (attrDataField.IsMoney)
                        {
                            if (val == null)
                                val = 0;
                            valueString = string.Format("{0:#.000}", val);
                        }
                        else
                            valueString = val == null ? string.Empty : val.ToString().Trim();

                        //Trancate string if it is larger than fixed Length
                        if (valueString.Length > attrDataField.Length)
                            valueString = valueString.Substring(0, attrDataField.Length);

                        if (attrDataField.HasPaddingChar)
                            sb.Append(valueString.PadLeft(attrDataField.Length, attrDataField.PaddingCharacter));
                        else
                            sb.Append(valueString.PadLeft(attrDataField.Length));
                    }
                }
            }

            return sb.ToString();
        }


   
        /// <summary>
        /// Join properties into the string
        /// </summary>
        /// <param name="obj">Source object which properties would be joined, those having property attribute [DataField]</param>
        /// <param name="delimiter">Delimiter char</param>
        /// <returns>joined string</returns>
        public static string JoinProperties(object obj, char delimiter)
        {
            PropertyInfo[] propInfo = obj.GetType().GetProperties();
            StringBuilder sb = new StringBuilder();

            string valueString = string.Empty;

            for (int i = 0; i < propInfo.Length; i++)
            {
                object val = propInfo[i].GetValue(obj, null);
                object[] DataFieldAttrs = propInfo[i].GetCustomAttributes(typeof(DataField), false);

                if (DataFieldAttrs != null)
                {
                    //Only property decorated  with attribute [DataField] will be appended in string
                    if (DataFieldAttrs.Length > 0)
                    {
                        DataField attrDataField = (DataField)DataFieldAttrs[0];

                        if (attrDataField.IsMoney)
                        {
                            if (val == null)
                                val = 0;
                            valueString = string.Format("{0:#.000}", val);
                        }
                        else
                            valueString = val == null ? string.Empty : val.ToString().Trim();

                        //Skip adding delimiter for last field
                        if (i == propInfo.Length - 1)
                            sb.Append(valueString);
                        else
                            sb.Append(valueString + delimiter);
                    }
                }
            }

            return sb.ToString();
        }

        /// <summary>
        /// Method to validate record/object if attribute "DataField" exists on Object's properties
        /// </summary>
        /// <param name="obj">Object to be validate</param>
        /// <param name="validationGroup">Validation Group</param>
        /// <returns>Validation Result</returns>
        public static ValidationResult ValidateRecord( Object obj , ValidationGroup validationGroup )
        {
           
            PropertyInfo[] propInfo = obj.GetType().GetProperties();

            ValidationResult l_ObjReqField = new ValidationResult(validationGroup);

            for (int i = 0; i < propInfo.Length; i++)
            {
                object val = propInfo[i].GetValue(obj, null);
                object[] DataFieldAttrs = propInfo[i].GetCustomAttributes(typeof(DataField), false);

                if (DataFieldAttrs != null)
                {
                    //Only property decorated  with attribute [DataField] will be appended in string
                    if (DataFieldAttrs.Length > 0)
                    {
                        DataField attrDataField = (DataField)DataFieldAttrs[0];

                        if (attrDataField.IsRequired && validationGroup == ValidationGroup.RequiredField)
                        {

                            //Validation for money data 
                            if (attrDataField.IsMoney)
                            {
                                decimal moneyValue = 0;
                                decimal.TryParse(Convert.ToString(val), out moneyValue);

                                if (moneyValue == 0)
                                {
                                    l_ObjReqField.IsValid = false;
                                    l_ObjReqField.InvaildFields.Add(propInfo[i].Name, string.IsNullOrEmpty(attrDataField.Name)
                                        ? propInfo[i].Name : attrDataField.Name
                                        );
                                }
                            }
                            else if (string.IsNullOrEmpty(Convert.ToString(val)))
                            {
                                l_ObjReqField.IsValid = false;
                                l_ObjReqField.InvaildFields.Add(propInfo[i].Name, string.IsNullOrEmpty(attrDataField.Name)
                                ? propInfo[i].Name : attrDataField.Name
                                );
                            }
                        }
                    }
                }
            }

            return l_ObjReqField;
        }

        public static ValidationResult ValidateRecord(Object obj, ValidationGroup validationGroup, bool IsIndividual)
        {

            PropertyInfo[] propInfo = obj.GetType().GetProperties();

            ValidationResult l_ObjReqField = new ValidationResult(validationGroup);

            for (int i = 0; i < propInfo.Length; i++)
            {
                object val = propInfo[i].GetValue(obj, null);
                object[] DataFieldAttrs = propInfo[i].GetCustomAttributes(typeof(DataField), false);

                if (DataFieldAttrs != null)
                {
                    //Only property decorated  with attribute [DataField] will be appended in string
                    if (DataFieldAttrs.Length > 0)
                    {
                        DataField attrDataField = (DataField)DataFieldAttrs[0];

                        if (attrDataField.IsIndividual)
                        {
                            if (string.IsNullOrEmpty(Convert.ToString(val)) && attrDataField.IsRequired == true && validationGroup == ValidationGroup.RequiredField)
                            {
                                l_ObjReqField.IsValid = false;
                                l_ObjReqField.InvaildFields.Add(propInfo[i].Name, string.IsNullOrEmpty(attrDataField.Name)
                                ? propInfo[i].Name : attrDataField.Name);
                                continue;
                            }
                        }
                        else if (string.IsNullOrEmpty(Convert.ToString(val)) && attrDataField.IsRequired == true && validationGroup == ValidationGroup.RequiredField)
                        {
                            l_ObjReqField.IsValid = false;
                            l_ObjReqField.InvaildFields.Add(propInfo[i].Name, string.IsNullOrEmpty(attrDataField.Name)
                                ? propInfo[i].Name : attrDataField.Name);
                            continue;
                        }

                        if (val == null && propInfo[i].PropertyType == typeof(string))
                        {
                            propInfo[i].SetValue(obj, string.Empty, null);
                        }
                    }
                }
            }

            return l_ObjReqField;
        }

        /// <summary>
        /// Serialize object into XML string
        /// </summary>
        /// <param name="obj">Object to be serialize</param>
        /// <returns>XML string</returns>
        public static string ObjectToXML(object obj)
        {
            Type type = obj.GetType();

            string xmlString = "";

            XmlSerializer xSerializer = new XmlSerializer(type);


            using (StringWriter sw = new StringWriter())
            {
                System.Xml.XmlWriterSettings xSettings = new System.Xml.XmlWriterSettings();
                xSettings.OmitXmlDeclaration = true;
                
                System.Xml.XmlWriter xw = System.Xml.XmlWriter.Create(sw, xSettings);

                xSerializer.Serialize(xw, obj);

                xmlString = sw.ToString();
                
                xw.Close();
            }

            return xmlString;
        }


        /// <summary>
        /// Get column's value of the DataRow
        /// </summary>
        /// <param name="row">DataRow which column value need to retrieve </param>
        /// <param name="colName">Name of the Column</param>
        /// <returns>value of the column</returns>
        public static object GetValueFromDataRow(DataRow row, string colName)
        {
            try
            {
                if ((row[colName] != null) && (row[colName] != DBNull.Value))
                    return (row[colName]);
            }
            catch 
            {
            }

            return null;
        }

        
        /// <summary>
        /// Return distinct records in Datatable
        /// </summary>
        /// <param name="dt">Source DataTable</param>
        /// <returns>Distinct DataTable</returns>
        public static DataTable GetDistinctRecords(DataTable dt)
        {
            string[] columns = new string[dt.Columns.Count];

            for (int i = 0; i < dt.Columns.Count; i++)
			{
			 columns[i] = dt.Columns[i].ColumnName;
			}

            DataTable dtUniqRecords = new DataTable();
            
            dtUniqRecords = dt.DefaultView.ToTable(true, columns);
            
            return dtUniqRecords;
        }




    }
}
