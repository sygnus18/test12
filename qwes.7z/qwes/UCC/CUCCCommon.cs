﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Drawing;
using FTIL.Match.Common.Constants;

namespace UCC
{
    #region Common Types

    /// <summary>
    /// Exchange Type
    /// </summary>
    #region ExchangeType (enum)
    public enum ExchangeType
    {
        None,
        NSE,
        BSE,
        MCXSX
    }
    #endregion

    /// <summary>
    /// UI Operation
    /// </summary>
    #region MasterOperation (enum)
    public enum MasterOperation
    {
        None = 0,
        View = 1,
        Add = 2,
        Delete = 3,
        Modify = 4,
        CheckerView = 5,
        MakerCancel = 6,
        Schema = 7
    }
    #endregion

    /// <summary>
    /// Delegate for OnOpenFormAsChild event
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="WindowType"></param>
    public delegate void OpenFormAsChild<T>(T WindowType) where T : Type;

    #endregion

    /// <summary>
    /// UCC module common utility functionality provider singleton class
    /// </summary>
    public class CUCCCommon
    {
        #region Variables

        /// <summary>
        /// Singleton instance
        /// </summary>
        private static CUCCCommon objUCCCommon;

        public event OpenFormAsChild<Type> OnOpenFormAsChild;

        #endregion

        #region Constructors

        /// <summary>
        /// Private constructor to prevent instances creation from out of class.
        /// </summary>
        private CUCCCommon() {}

        /// <summary>
        /// Static constructor to initialize singleton object of class.
        /// </summary>
        static CUCCCommon()
        {
            objUCCCommon = new CUCCCommon();
        }

        #endregion

        /// <summary>
        /// The only instance of CUCCCommon
        /// </summary>
        #region CUCCCommon Instance
        public static CUCCCommon Instance
        {
            get { return objUCCCommon; }
        }
        #endregion

        #region Methods

        /// <summary>
        /// This method raises event to open specified Form type as child window by application
        /// </summary>
        /// <typeparam name="T"></typeparam>
        #region OpenFormAsChild
        internal void OpenFormAsChild<T>() where T : Form, new()
        {
            if (OnOpenFormAsChild != null)
            {
                Type WindowType = typeof(T);
                OnOpenFormAsChild(WindowType);
            }
        }
        #endregion

        /// <summary>
        /// Returns exchange type for specified exchange code
        /// </summary>
        /// <param name="p_vsExchangeCode">Exchange code</param>
        /// <returns>Exchange Type</returns>
        #region GetExchangeType
        public ExchangeType GetExchangeType(string p_vsExchangeCode)
        {
            ExchangeType l_objExchType = ExchangeType.None;
            switch (p_vsExchangeCode)
            {
                case "NSE":
                case "NSECR":
                    l_objExchType = ExchangeType.NSE;
                    break;

                case "BSE":
                    l_objExchType = ExchangeType.BSE;
                    break;

                case "MCX":
                case "MCX-SX":
                case "MCX-EDS":
                    l_objExchType = ExchangeType.MCXSX;
                    break;

                default:
                    if (p_vsExchangeCode.Contains("NSE"))
                        l_objExchType = ExchangeType.NSE;
                    else if (p_vsExchangeCode.Contains("BSE"))
                        l_objExchType = ExchangeType.BSE;
                    else if (p_vsExchangeCode.Contains("MCX"))
                        l_objExchType = ExchangeType.MCXSX;
                    break;
            }

            return l_objExchType;
        }
        #endregion

        /// <summary>
        /// Sets input control style to Maker changed field
        /// </summary>
        /// <param name="TargetControl">Control to be styled as maker changed</param>
        /// <param name="NamedLabel">Named Label control of 'TargetControl' Control</param>
        #region SetMakerChangedStyle
        public void SetMakerChangedStyle(Control TargetControl, Control NamedLabel, ToolTip ToolTipControl, object OriginalValue)
        {
            TargetControl.Font = new Font(TargetControl.Font.FontFamily, TargetControl.Font.SizeInPoints, FontStyle.Bold);
            TargetControl.ForeColor = Color.Red;

            string l_sValue = "{Empty}";
            if (OriginalValue != null)
            {
                if (OriginalValue is DateTime?)
                {
                    DateTime? l_datDate = OriginalValue as DateTime?;
                    if (l_datDate.HasValue)
                        l_sValue = l_datDate.Value.ToString(Formatting.Instance.DATE_DISPLAY_FORMAT);
                }
                else if (OriginalValue is DateTime)
                {
                    DateTime l_datDate = Convert.ToDateTime(OriginalValue);
                    l_sValue = l_datDate.ToString(Formatting.Instance.DATE_DISPLAY_FORMAT);
                }
                else
                    l_sValue = OriginalValue.ToString();
            }

            if(string.IsNullOrEmpty(l_sValue))
                l_sValue = "{Empty}";

            ToolTipControl.SetToolTip(TargetControl, l_sValue);
        }
        #endregion

        /// <summary>
        /// Resets Maker changed style of input control
        /// </summary>
        /// <param name="TargetControl"></param>
        /// <param name="NamedLabel"></param>
        #region ResetMakerChangedStyle
        public void ResetMakerChangedStyle(Control TargetControl, Control NamedLabel, ToolTip ToolTipControl)
        {
            TargetControl.Font = new Font(TargetControl.Font.FontFamily, TargetControl.Font.SizeInPoints, FontStyle.Regular);
            TargetControl.ForeColor = Color.Black;
            ToolTipControl.SetToolTip(TargetControl, string.Empty);
        }
        #endregion

        #endregion
    }
}
