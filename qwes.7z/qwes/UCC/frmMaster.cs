using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using MatchCommon;

/// <summary>
///================================================================================          
/// File/Class/Custom Name    :frmMaster.cs
/// Base CR No.               :
/// Author                    :Pravin k 
/// DateCreated               :10/09/2007
/// Reviewd By                :Rakesh
/// Description               :This form must be inherited by all master forms          
///================================================================================
/// </summary>

namespace UCCExport
{
    public partial class frmMaster : MatchCommon.UI.Forms.frmMatchBase
    {
        string m_sClassName = "frmMaster";
       
        public frmMaster()
        {
            InitializeComponent();
        }
        /// <summary>
        ///This method is used to bind the form fields controls to the table columns
        ///</summary>  
        ///

       


        protected virtual long BindControls(Control[] p_varrayCtl, string[] p_varrayListPropery, string[] p_vsDataMember, BindingSource p_vbindingSourceDP)
        {
            try
            {
                int l_iCount = 0;
                for (l_iCount = 0; l_iCount < p_varrayCtl.Length; l_iCount++)
                {
                    p_varrayCtl[l_iCount].DataBindings.Add(p_varrayListPropery[l_iCount].ToString(), p_vbindingSourceDP, p_vsDataMember[l_iCount].ToString());
                }
                return 0;
            }
            catch (Exception ex)
            {
                CCommon.MyCommon(MatchCommon.MatchCommonModules.Cash).WriteLog("BindControls()", m_sClassName, "0", "0", ex.Message, ex);
                return -1;
            }
        }
    }
}