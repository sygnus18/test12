﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UCC
{
    /// <summary>
    /// UCC module constants singleton class
    /// </summary>
    public class CUCCConstants
    {
        #region Readonly Variables

        public readonly string OTHER_STATE_CODE = "99";
        public readonly string OTHER_NATIONALITY_CODE = "2";
        public readonly string OTHER_OCCUPATION_REFNO = "305";

        public readonly string STATE_OTHER_CODE = "99";

        public readonly string DEFAULT_CITY_CODE = "2336";
        public readonly string DEFAULT_STATE_CODE = "19";
        public readonly string DEFAULT_COUNTRY_CODE = "85";
        
        public readonly string INDIA_COUNTRY_CODE = "85";

        public readonly string ADDR_REGISTERED_CATEGORY_CODE = "1";
        public readonly string ADDR_CONTACT_PERSON_CATEGORY_CODE = "3";
        public readonly string ADDR_CORRESPONDENCE_CATEGORY_CODE = "4";

        public readonly decimal SQL_MONEY_MAX_SUPPORTED_VALUE = 922337203685477.58M;

        public readonly string DEPOSITORY_NSDL = "NSDL";
        public readonly string DEPOSITORY_CDSL = "CDSL";

        public readonly string AUTH_RECORD_AVAILABLE_FOR_CHANGES_MSG = "Client Pending for authorization";
        public readonly string AUTH_RECORD_UNAVAILABLE_FOR_CHANGES_MSG = "Changes by another user pending for authorization. Record unavailable for any changes.";

        public readonly string GROSS_ANNUAL_INC_NOT_APPLICABLE_REFNO = "326";
        public readonly string GROSS_ANNUAL_INC_BLANK = "327";

        #endregion

        #region Singleton

        /// <summary>
        /// Singleton instance
        /// </summary>
        private static CUCCConstants objUCCConstants;

        /// <summary>
        /// Private constructor to prevent instances creation from out of class.
        /// </summary>
        private CUCCConstants() {}

        /// <summary>
        /// Static constructor to initialize singleton object of class.
        /// </summary>
        static CUCCConstants()
        {
            objUCCConstants = new CUCCConstants();
        }

        #endregion

        /// <summary>
        /// The only instance of CUCCCommon
        /// </summary>
        #region CUCCCommon Instance
        public static CUCCConstants Instance
        {
            get { return objUCCConstants; }
        }
        #endregion
    }
}
