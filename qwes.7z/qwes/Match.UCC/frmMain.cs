﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Reflection;

using Match.UCC.UI;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;

using UCC;
using UCC.Forms;
using UCC.Forms.KRA;
using FTIL.Match.CDD.UI.Forms;


namespace Match.UCC
{
    public partial class frmMain : Form
    {
        #region Variables

        List<Control> m_lstOperationControls;
        //Dictionary<int, ToolStripMenuItem> m_dicOperationMenus;

        #endregion

        #region Constructor
        public frmMain()
        {
            InitializeComponent();
        }
        #endregion

        #region Events

        /// <summary>
        /// Window load event handler. Initializes window controls.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region frmMain_Load
        private void frmMain_Load(object sender, EventArgs e)
        {
            statusStrip.Visible = false;
            toolStrip.Visible = false;
        }
        #endregion

        /// <summary>
        /// This event handler initializes application, menu and processes command line via calling appropriate method.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region frmMain_Shown
        private void frmMain_Shown(object sender, EventArgs e)
        {
            this.Text = "MATCH - CDD Version: " + Assembly.GetExecutingAssembly().GetName().Version.ToString();
            //frmMain_SizeChanged(this, EventArgs.Empty);

            MatchCommonUIParams.Instance.AppInitMode = AppInitMode.StandAlone;

            InitializeApp();

            //commented for dev only

            if (MatchCommonUIParams.Instance.AppInitMode == AppInitMode.StandAlone)
            {
                frmLogin login = new frmLogin();
                if (login.ShowDialog() == DialogResult.OK)
                {
                    PostAuthenticationSuccessful();
                }
                else
                {
                    ShutDownApp();
                }
            }
            else
            {
                PostAuthenticationSuccessful();
            }
              

            CUCCCommon.Instance.OnOpenFormAsChild += new OpenFormAsChild<Type>(Instance_OnOpenFormAsChild);
        }
        #endregion

        /// <summary>
        /// This event handler starts shut down process if not started yet.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region frmMain_FormClosed
        private void frmMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (MatchCommonUIParams.Instance.AppShutdownStarted == false)
            {
                ShutDownApp();
            }
        }
        #endregion

        /// <summary>
        /// This event handler passes input type (supposed to be window) to MenuHandler for opening it as MDI child window
        /// </summary>
        /// <param name="WindowType"></param>
        #region Instance_OnOpenFormAsChild
        private void Instance_OnOpenFormAsChild(Type WindowType)
        {
            MenuHandler.Instance.OpenFormAsMDIChild(WindowType);
        }
        #endregion

        /// <summary>
        /// This event handler opens UCC Client details window
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region picUCCDetails_Click
        private void picUCCDetails_Click(object sender, EventArgs e)
        {
            //OpenChildWindow<UCC.Forms.frmUCCClient>();
            MenuHandler.Instance.HandleMenuClick("ClientRegistration");
        }
        #endregion

        /// <summary>
        /// This event handler initiates shut down process
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region mnuExit_Click
        private void mnuExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to close application?", this.Text,
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
                return;
            }

            ShutDownApp();
        }
        #endregion

        /// <summary>
        /// This event handler opens About window
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region mnuAbout_Click
        private void mnuAbout_Click(object sender, EventArgs e)
        {
            frmAbout l_frmAbout = new frmAbout();
            l_frmAbout.ShowDialog();
        }
        #endregion

        /// <summary>
        /// This common event handler, linked to all operational menus, opens clicked menu window.
        /// Menu code must be tagged in Tag property of clicked menu item.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region mnuOperationsMenu_Click
        private void mnuOperationsMenu_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem l_objCalledFromMenu = sender as ToolStripMenuItem;
            if (l_objCalledFromMenu == null)
            {
                Logger.Instance.WriteLog(this, Environment.StackTrace);
                MessageBox.Show("Unknown menu", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (l_objCalledFromMenu.Tag == null)
            {
                Logger.Instance.WriteLog(this, Environment.StackTrace);
                MessageBox.Show("Menu code not found", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            MenuHandler.Instance.HandleMenuClick(l_objCalledFromMenu.Tag.ToString());
        }
        #endregion

        /// <summary>
        /// Cascades all MDI child windows within the client region of the MDI parent window
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region cascadeToolStripMenuItem_Click
        private void cascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }
        #endregion

        /// <summary>
        /// Arranges all MDI child windows to vertically tiled within the client region of MDI window
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region tileVerticalToolStripMenuItem_Click
        private void tileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }
        #endregion

        /// <summary>
        /// Arranges all MDI child windows to horizontally tiled within the client region of MDI window
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e">Event arguments</param>
        #region tileHorizontalToolStripMenuItem_Click
        private void tileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }
        #endregion

        /// <summary>
        /// Arranges all MDI child icons within the client region of the MDI parent window
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region arrangeIconsToolStripMenuItem_Click
        private void arrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }
        #endregion

        /// <summary>
        /// Closes all open MDI child windows
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event arguments</param>
        #region closeAllToolStripMenuItem_Click
        private void closeAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }
        #endregion

        #endregion

        #region Methods

        /// <summary>
        /// Process command line parameters.
        /// Fetch User/Db Logon details.
        /// </summary>
        #region InitializeApp
        private void InitializeApp()
        {
            InitialiseOperationMenusList();
            EnableDisableAppMenus(false);

            MethodExecResult l_objMethodExecResult = ProcessCommandLineArgs();

            if (l_objMethodExecResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                MessageBox.Show(l_objMethodExecResult.ErrorMessage, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                ShutDownApp();
            }
        }
        #endregion

        /// <summary>
        /// This method initializes application menu and registers menu with MenuHandler
        /// </summary>
        #region InitialiseOperationMenusList
        private void InitialiseOperationMenusList()
        {
            m_lstOperationControls = new List<Control>();
            MenuHandler.Instance.MDIWindow = this;

            //Initialize all menus
            mnuClientRegistration.Tag = "ClientRegistration";
            mnuClientRegistration.Click += new EventHandler(mnuOperationsMenu_Click);

            mnuAuthorization.Tag = "Authorization";
            mnuAuthorization.Click += new EventHandler(mnuOperationsMenu_Click);

            //Register all menus
            MenuHandler.Instance.RegisterMenu("ClientRegistration",
                typeof(frmUCCClient).FullName,
                typeof(frmUCCClient).Assembly.FullName);
            //MenuHandler.Instance.RegisterMenu("ClientExport",
            //    typeof(UCC.Forms.frmClientExport).FullName,
            //    typeof(UCC.Forms.frmClientExport).Assembly.FullName);
            MenuHandler.Instance.RegisterMenu("Authorization",
                typeof(frmCheckerAuthorization).FullName,
                typeof(frmCheckerAuthorization).Assembly.FullName);
            //MenuHandler.Instance.RegisterMenu("UCCResponseImport",
            //    typeof(UCC.Forms.frmUCCRejectedFileUpload).FullName,
            //    typeof(UCC.Forms.frmUCCRejectedFileUpload).Assembly.FullName);
        }
        #endregion

        /// <summary>
        /// This method processes command line arguments.
        /// If found, it initializes application objects - Connection, User, Application - from it.
        /// </summary>
        /// <returns></returns>
        #region ProcessCommandLineArgs
        private MethodExecResult ProcessCommandLineArgs()
        {
            string[] l_sCmdLineArgs = Environment.GetCommandLineArgs();

            if (l_sCmdLineArgs.Length > 1)
            {
                MatchCommonUIParams.Instance.AppInitMode = AppInitMode.CalledFromApp;

                string l_sFileName = l_sCmdLineArgs[1];
                if (File.Exists(l_sFileName) == false)
                {
                    return new MethodExecResult(1, "Incorrect input parameters received by application.",
                        "File {" + l_sFileName + "} doesnot exist!!!", null);
                }

                string l_sAppInputContents = File.ReadAllText(l_sFileName);
                InterAppComm IPC = new InterAppComm();
                Dictionary<IACEntities, object> l_dicIPCEntities = null;
                MethodExecResult l_objMethodExecResultNew = IPC.GetIPCObjectsFromXmlString(l_sAppInputContents, ref l_dicIPCEntities);
                if (l_objMethodExecResultNew.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    AppUser l_objAppUser = null;
                    DbConnectionParameters l_objDbConParams = null;
                    AppSettings l_objAppSettings = null;

                    if (l_dicIPCEntities.ContainsKey(IACEntities.User))
                        l_objAppUser = l_dicIPCEntities[IACEntities.User] as AppUser;
                    if (l_dicIPCEntities.ContainsKey(IACEntities.Db))
                        l_objDbConParams = l_dicIPCEntities[IACEntities.Db] as DbConnectionParameters;
                    if (l_dicIPCEntities.ContainsKey(IACEntities.AppSettings))
                        l_objAppSettings = l_dicIPCEntities[IACEntities.AppSettings] as AppSettings;

                    if (l_objAppUser == null)
                    {
                        return new MethodExecResult(2, "Incorrect input parameters received by application."
                            + Environment.NewLine + "User details not found.", string.Empty, null);
                    }

                    if (l_objDbConParams == null)
                    {
                        return new MethodExecResult(3, "Incorrect input parameters received by application."
                            + Environment.NewLine + "Database details not found.", string.Empty, null);
                    }

                    if (l_objAppSettings == null)
                    {
                        return new MethodExecResult(4, "Incorrect input parameters received by application."
                            + Environment.NewLine + "App Settings not found.", string.Empty, null);
                    }

                    MatchCommonUIParams.Instance.ApplicationUser = l_objAppUser;
                    MatchCommonUIParams.Instance.DbConnParams = l_objDbConParams;
                    MatchCommonUIParams.Instance.AppSettings = l_objAppSettings;

                    AppEnvironment.AppSettings = l_objAppSettings;
                    AppEnvironment.AppUser = l_objAppUser;
                }
                else
                {
                    return l_objMethodExecResultNew;
                }
            }

            return new MethodExecResult(MethodExecResult.SuccessfulReturnCode);
        }
        #endregion

        /// <summary>
        /// This method enables/disables all operation menus
        /// </summary>
        /// <param name="p_vbLoggedIn">Indicates if Logon is successful</param>
        #region EnableDisableAppMenus
        private void EnableDisableAppMenus(bool p_vbLoggedIn)
        {
            for(int l_iRootMenuCounter = 0; l_iRootMenuCounter < m_lstOperationControls.Count; l_iRootMenuCounter++)
                m_lstOperationControls[l_iRootMenuCounter].Visible = p_vbLoggedIn;
        }
        #endregion

        /// <summary>
        /// This method enables menus, sets window title and opens UCC Client window
        /// </summary>
        #region PostAuthenticationSuccessful
        private void PostAuthenticationSuccessful()
        {
            EnableDisableAppMenus(true);

            this.Text = this.Text = "MATCH - CDD Version: " + Assembly.GetExecutingAssembly().GetName().Version.ToString()
                + 
                (string.IsNullOrEmpty(MatchCommonUIParams.Instance.DbConnParams.Identifier) ?
                "" : " Connection: " + MatchCommonUIParams.Instance.DbConnParams.Identifier)
#if DEBUG
                + ". Server: " + MatchCommonUIParams.Instance.DbConnParams.DataSource
                + ", Database: " + MatchCommonUIParams.Instance.DbConnParams.Database
#endif
                ;

            //mnuOperationsMenu_Click(mnuClientRegistration, EventArgs.Empty);
            PostLoginProcess();
        }
        #endregion

        /// <summary>
        /// This method shuts down application
        /// </summary>
        #region ShutDownApp
        private void ShutDownApp()
        {
            MatchCommonUIParams.Instance.AppShutdownStarted = true;
            this.Close();
            Environment.Exit(0);
        }
        #endregion

/// <summary>
        /// Process the Post login process specially for UCC application
        /// </summary>
        private void PostLoginProcess()
        {
            string l_sSysParamValue = string.Empty;
            Match.UCC.Custom.CCustom l_Obj = new Match.UCC.Custom.CCustom();
            l_sSysParamValue = l_Obj.GetSysParamFromNo(1);// Maker/Checker Enabled
            if (l_sSysParamValue == "Y")
                mnuAuthorization.Visible = true;
            else
                mnuAuthorization.Visible = false;
        
        }

        private void kYCDownloadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for(int i =0; i < this.MdiChildren.Length;i++)
            {
                if(this.MdiChildren[i].Name == typeof(frmKRADownload).Name)
                {
                    this.MdiChildren[i].Activate();
                    return;
                }
            }

            frmKRADownload frmKRA = new frmKRADownload();
            frmKRA.MdiParent = this;
            frmKRA.Show();
        }

        #endregion

        private void entityDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < this.MdiChildren.Length; i++)
            {
                if (this.MdiChildren[i].Name == "frmEntityMaster")
                {
                    this.MdiChildren[i].Activate();
                    return;
                }
            }

            frmEntityMaster frmEntity = new frmEntityMaster();
            frmEntity.Name = "frmEntityMaster";
            frmEntity.MdiParent = this;
            frmEntity.Icon = this.Icon;
          
            setClientRect(frmEntity);

            frmEntity.Show();
            //frmEntity.m_HasFindButtonPressed = true;

        }

        //private void auditTrailToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    for (int i = 0; i < this.MdiChildren.Length; i++)
        //    {
        //        if (this.MdiChildren[i].Name == "frmAuditTrail")
        //        {
        //            this.MdiChildren[i].Activate();
        //            return;
        //        }
        //    }

        //    frmAuditTrail frmAudit = new frmAuditTrail();
        //    frmAudit.Name = "frmAuditTrail";
        //    frmAudit.MdiParent = this;
        //    frmAudit.Icon = this.Icon;

        //    setClientRect(frmAudit);

        //    frmAudit.Show();

        //}


        /// <summary>
        /// Adjusts child form to the size of screen.
        /// </summary>
        private void setClientRect(MatchCommon.UI.Forms.frmMatchBase objBaseForm)
        {
            objBaseForm.WindowState = FormWindowState.Normal;

            this.Location = new System.Drawing.Point(0, 0);
            this.StartPosition = FormStartPosition.CenterParent;
            Rectangle objRect = this.ClientRectangle;

            objRect.Height -= (this.MainMenuStrip.Height + 5);
            objRect.Width -= 5;
            /*If Form Min. ht is less than Rect ht, thn.*/
            if (objBaseForm.MinimumSize.Height < objRect.Height)
            {
                objBaseForm.Height = objRect.Height;
            }
            else
            {
                objBaseForm.Height = objBaseForm.MinimumSize.Height;
                /*Width of VerticalScrollBar = 15*/
                objBaseForm.Width -= 18;
            }
            /*If Form Min. Width is less than Rect Width, thn.*/
            if (objBaseForm.MinimumSize.Width < objRect.Width)
            {
                objBaseForm.Width = objRect.Width;
            }
            else
            {
                objBaseForm.Width = objBaseForm.MinimumSize.Width;
                /*Height of HorizontalScrollBar = 15*/
                objBaseForm.Height -= 18;
            }

         
        }

        private void mnuMain_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void authorizationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < this.MdiChildren.Length; i++)
            {
                if (this.MdiChildren[i].Name == "frmAuthorization")
                {
                    this.MdiChildren[i].Activate();
                    return;
                }
            }

            FTIL.Match.Authorization.Forms.frmAuthorization frmEntity = new FTIL.Match.Authorization.Forms.frmAuthorization();
            frmEntity.Name = "frmAuthorization";
            frmEntity.MdiParent = this;
            frmEntity.Icon = this.Icon;

            setClientRect(frmEntity);

            frmEntity.Show();
        }

        private void mnuClientRegistration_Click(object sender, EventArgs e)
        {

        }

        private void mnuAuthorization_Click(object sender, EventArgs e)
        {

        }


      

    }

}
