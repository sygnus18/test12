﻿using System;
using System.Collections.Generic;
using System.Text;
using FTIL.Match.Common.Db;
using System.Data;
using FTIL.Match.Common;
using FTIL.Match.Common.Log;

namespace Match.UCC.Custom
{
    /// <summary>
    /// Custom class for UCC specific
    /// </summary>
    class CCustom
    {
        /// <summary>
        /// default constructor
        /// </summary>
        #region "Constructor"
        public CCustom() { }
        #endregion

        /// <summary>
        /// Fetch the systemparam value based on system param no
        /// </summary>
        /// <param name="p_viSysParamNo">SystemParam No</param>
        /// <returns></returns>
        #region GetSysParamFromNo
        public string GetSysParamFromNo(int p_viSysParamNo)
        {
            string l_sSysParamValue = string.Empty;
            try
            {
                DbWorkItem l_objDbWorkItem = new DbWorkItem("stp_UCCRetrieveSystemParameters");
                l_objDbWorkItem.ResultType = QueryType.DataSet;

                l_objDbWorkItem.AddParameter("@pn_UserNo", SqlDbType.Int, 0);
                l_objDbWorkItem.AddParameter("@pn_SysParamNo", SqlDbType.Int, p_viSysParamNo);

                DbManager.Instance.ExecuteDbTask(l_objDbWorkItem);

                if (l_objDbWorkItem.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
                {
                    DataSet l_dsReturnData = l_objDbWorkItem.Result as DataSet;

                    if (l_dsReturnData == null || l_dsReturnData.Tables.Count == 0)
                    {
                        l_sSysParamValue = "";
                    }
                    else
                    {
                        l_sSysParamValue = l_dsReturnData.Tables[0].Rows[0]["s_SysParamValue"].ToString();
                    }
                }
                else
                {
                    Logger.Instance.WriteLog(this, l_objDbWorkItem.ExecutionStatus);
                }
                
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
            }
            return l_sSysParamValue;
        }
        #endregion
    }
}
