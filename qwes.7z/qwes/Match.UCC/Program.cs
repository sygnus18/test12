﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Threading;

using FTIL.Match.Common.Log;

namespace Match.UCC
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
         {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new frmLogin());

            /*
             * Set Unhandled Exception Mode to CatchException, so
             * application exceptions will be routed to ThreadExceptionEventHandler
             */
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);


            /*Creates an instance of the methods that will handle the exception.*/
            CustomExceptionHandler eh = new CustomExceptionHandler();

            /*Adds the event handler to to the event.*/
            Application.ThreadException += new ThreadExceptionEventHandler(eh.OnThreadException);
            
            Application.Run(new frmMain());

        }

        /// <summary>
        /// Creates a class to handle the exception event. 
        /// </summary>
        internal class CustomExceptionHandler
        {
            /* Handles the exception event. */
            public void OnThreadException(object sender, ThreadExceptionEventArgs t)
            {
                DialogResult result = DialogResult.Cancel;

                try
                {
                    //MatchCommon.CCommon.MyCommon(MatchCommon.MatchCommonModules.Cash).WriteLog(this.GetType().ToString(), "Main", "High", "0", t.Exception.ToString(), t.Exception);
                    Logger.Instance.WriteLog(this, "Application Error", t.Exception);
                    result = this.ShowThreadExceptionDialog(t.Exception);
                }
                catch
                {
                    try
                    {
                        MessageBox.Show("Catastrophic Failure", Application.ProductName + " - Application Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    }
                    finally
                    {
                        Environment.Exit(0);
                    }
                }
                /* Exits the program when the user clicks Yes. */
                if (result == DialogResult.Yes)
                {
                    Environment.Exit(0);
                }
            }

            /* Creates the error message and displays it. */
            private DialogResult ShowThreadExceptionDialog(Exception e)
            {
                string errorMsg = "An error occurred. Please contact system adminstrator with the following information:" 
                    + Environment.NewLine + Environment.NewLine;
                errorMsg = errorMsg + e.Message;
                errorMsg = errorMsg + Environment.NewLine + Environment.NewLine + "Do you want to exit " + Application.ProductName + " ?";
                return MessageBox.Show(errorMsg, Application.ProductName + " - Application Error", MessageBoxButtons.YesNo, MessageBoxIcon.Stop);
            }
        }

    }
}