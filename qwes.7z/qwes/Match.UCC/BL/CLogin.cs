﻿using System;
using System.Text;
using System.Data;
using System.Data.SqlClient;

using FTILCrypto;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;

namespace Match.UCC.BL
{
    /// <summary>
    /// BL of Login screen
    /// </summary>
    class CLogin
    {
        /// <summary>
        /// This method validates user credentials.
        /// </summary>
        /// <param name="p_vsUserId">User Id</param>
        /// <param name="p_vsPassword">Password in plain text</param>
        /// <param name="p_vobjProduct">Product</param>
        /// <returns>Method execution result</returns>
        #region ValidateUser
        internal MethodExecResult ValidateUser(string p_vsUserId, string p_vsPassword, Product p_vobjProduct)
        {
            DbWorkItem l_objValidateUser = new DbWorkItem("stp_RetrieveCommonUIUserDetails");
            l_objValidateUser.ResultType = QueryType.DataSet;
            l_objValidateUser.AddParameter(new SqlParameter("UserId", p_vsUserId));
            l_objValidateUser.AddParameter(new SqlParameter("Mode", 1));

            DbManager.Instance.ExecuteDbTask(l_objValidateUser);
            if (l_objValidateUser.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsResult = l_objValidateUser.Result as DataSet;
                if ((l_dsResult == null) || (l_dsResult.Tables.Count == 0)
                    || (l_dsResult.Tables[0].Columns.Count == 0) || (l_dsResult.Tables[0].Rows.Count == 0))
                {
                    return new MethodExecResult(1, "No user details found!!!",
                        "stp_ValidateCommonUIUser 1 returned recordset with no data.", null);
                }
                else if (l_dsResult.Tables[0].Rows[0][0] == null)
                {
                    return new MethodExecResult(2, "No user details found!!!",
                        "stp_ValidateCommonUIUser 1 returned recordset with invalid credentials.", null);
                }

                string l_sPassword = string.Empty;
                try
                {
                    if (l_dsResult.Tables[0].Rows[0]["n_Locked"].ToString() == "1")
                    {
                        return new MethodExecResult(3, "User is locked!!!", string.Empty, null);
                    }

                    l_sPassword = l_dsResult.Tables[0].Rows[0]["s_Password"].ToString();
                }
                catch (Exception ex)
                {
                    return new MethodExecResult(4, "Error accessing user details", ex.ToString(), ex);
                }

                FTILCrypto.CEncryptDecrypt l_objEncryptDecrypt = new FTILCrypto.CEncryptDecrypt(false);
                l_objEncryptDecrypt.ApplicationID = "Match";
                byte[] l_bytDecryptedData = new byte[4000];
                string l_sCreatedTime = string.Empty;
                string l_sErrorMessage = string.Empty;

                string l_sEncrMethod = string.Empty;
                if (MatchCommonUIParams.Instance.AppSettings.AppProduct == Product.Settlement)
                {
                    l_sEncrMethod = "SETT";
                }
                else if (MatchCommonUIParams.Instance.AppSettings.AppProduct == Product.Derivative)
                {
                    if (System.Configuration.ConfigurationManager.AppSettings.Get("DervEnc") == "New")
                        l_sEncrMethod = "SETT";
                    else
                        l_sEncrMethod = "DERV";
                }
                else
                {
                    return new MethodExecResult(5, "Product not supported!!!",
                        "Product not supported: " + MatchCommonUIParams.Instance.AppSettings.AppProduct.ToString(), null);
                }

                if (l_sEncrMethod == "SETT")
                {
                    if (l_objEncryptDecrypt.Decrypt(l_sPassword, ref l_bytDecryptedData,
                        ref l_sCreatedTime, ref l_sErrorMessage) == 0)
                    {
                        l_sPassword = UnicodeEncoding.Unicode.GetString(l_bytDecryptedData);
                        if (p_vsPassword == l_sPassword)
                            return new MethodExecResult(MethodExecResult.SuccessfulReturnCode);
                        else
                            return new MethodExecResult(6, "Incorrect Login Id/Password!!!", string.Empty, null);
                    }
                    else
                    {
                        return new MethodExecResult(7, "Credentials retrieval failed.",
                            "Password decryption failed. " + l_sErrorMessage, null);
                    }
                }
                else
                {
                    l_sPassword = DecryptDervStr(l_sPassword);
                    if (p_vsPassword == l_sPassword)
                        return new MethodExecResult(MethodExecResult.SuccessfulReturnCode);
                    else
                        return new MethodExecResult(8, "Incorrect Login Id/Password!!!", string.Empty, null);
                }
            }
            else
            {
                return l_objValidateUser.ExecutionStatus;
            }
        }
        #endregion

        /// <summary>
        /// This method retrieves user details from database
        /// </summary>
        /// <param name="p_vsUserId">User Id</param>
        /// <param name="p_rdtData">Return datatable containing user details</param>
        /// <returns>Method Execution Result</returns>
        #region RetrieveUserDetails
        internal MethodExecResult RetrieveUserDetails(string p_vsUserId, ref DataTable p_rdtData)
        {
            DbWorkItem l_objValidateUser = new DbWorkItem("stp_RetrieveCommonUIUserDetails");
            l_objValidateUser.ResultType = QueryType.DataSet;
            l_objValidateUser.AddParameter(new SqlParameter("UserId", p_vsUserId));
            l_objValidateUser.AddParameter(new SqlParameter("Mode", 2));

            DbManager.Instance.ExecuteDbTask(l_objValidateUser);
            if (l_objValidateUser.ExecutionStatus.ReturnCode == MethodExecResult.SuccessfulReturnCode)
            {
                DataSet l_dsResult = l_objValidateUser.Result as DataSet;
                if ((l_dsResult == null) || (l_dsResult.Tables.Count == 0)
                    || (l_dsResult.Tables[0].Columns.Count == 0) || (l_dsResult.Tables[0].Rows.Count == 0))
                {
                    return new MethodExecResult(1, "No user details found!!!",
                        "stp_ValidateCommonUIUser 2 returned recordset with no data.", null);
                }

                p_rdtData = l_dsResult.Tables[0]; 
            }

            return l_objValidateUser.ExecutionStatus;
        }
        #endregion

        /// <summary>
        /// This method decrypts input string using Derivatives 100 char algo
        /// </summary>
        /// <param name="CypherText">Input encrypted string</param>
        /// <returns>Decrypted string</returns>
        #region DecryptDervStr
        private string DecryptDervStr(String CypherText)
        {
            Object[] Lo_atemp = new Object[100];
            Object[] Lo_atemp1 = new Object[100];
            String Ls_STemp = "";
            String Ls_PassLength;
            String Ls_DecryptedString = "";
            Int32 I;

            Object Seed = "01/01/2001";
            if (CypherText.Length != 100)
            {
                throw new Exception("Inappropiate Cypher or Seed");
            }

            try
            {
                //Get Seed
                TimeSpan ts = Convert.ToDateTime(Seed).Subtract(Convert.ToDateTime("01/01/1000"));
                Seed = ts.TotalSeconds;

                //Converting the seed into string
                Seed = String.Format(Convert.ToString(Seed), "0000000000");

                //Concatenating it into 100 characters
                Seed = Convert.ToString(Seed) + Convert.ToString(Seed) + Convert.ToString(Seed) + Convert.ToString(Seed) + Convert.ToString(Seed) + Convert.ToString(Seed) + Convert.ToString(Seed) + Convert.ToString(Seed) + Convert.ToString(Seed) + Convert.ToString(Seed);

                //Convert to ASCII
                for (I = 0; I <= 99; I++)
                    Lo_atemp[I] = (int)(Convert.ToChar(CypherText.Substring(I, 1)));

                //Plus Seed
                for (I = 0; I <= 99; I++)
                    Lo_atemp[I] = Convert.ToInt16(Lo_atemp[I]) + Convert.ToInt16(Convert.ToString(Seed).Substring(I, 1));

                //Convert to Character
                for (I = 0; I <= 99; I++)
                    Ls_STemp = Ls_STemp + Convert.ToString(Convert.ToChar(Lo_atemp[I]));

                if (Ls_STemp.IndexOf("*") == 0)
                {
                    Ls_DecryptedString = Ls_STemp.Substring(1, 1);
                }
                else if (Ls_STemp.IndexOf("!") == 0)
                {
                    Ls_DecryptedString = Ls_STemp.Substring(1, 2);
                }
                else if (Ls_STemp.IndexOf("&") == 0)
                {
                    Ls_DecryptedString = Ls_STemp.Substring(1, 2) + Ls_STemp.Substring(9, 1);
                }
                else if (Ls_STemp.IndexOf("#") == 0)
                {
                    Ls_DecryptedString = Ls_STemp.Substring(1, 2) + Ls_STemp.Substring(9, 1) + Ls_STemp.Substring(7, 1);
                }
                else if (Ls_STemp.IndexOf("@") == 0)
                {
                    Ls_DecryptedString = Ls_STemp.Substring(1, 2) + Ls_STemp.Substring(9, 1) + Ls_STemp.Substring(7, 1) + Ls_STemp.Substring(5, 1);
                }
                else if (Ls_STemp.IndexOf("]") == 0)
                {
                    Ls_DecryptedString = Ls_STemp.Substring(5, 2) + Ls_STemp.Substring(8, 2) + Ls_STemp.Substring(1, 2);
                }
                else if (Ls_STemp.IndexOf("~") == 0)
                {
                    Ls_DecryptedString = Ls_STemp.Substring(5, 1) + Ls_STemp.Substring(1, 3) + Ls_STemp.Substring(7, 3);
                }
                else if (Ls_STemp.IndexOf("/") == 0)
                {
                    Ls_DecryptedString = Ls_STemp.Substring(6, 4) + Ls_STemp.Substring(4, 2) + Ls_STemp.Substring(1, 2);
                }
                else if (Ls_STemp.IndexOf("(") == 0)
                {
                    Ls_PassLength = Convert.ToString(Ls_STemp.Substring(1, 2));
                    Ls_DecryptedString = Ls_STemp.Substring(7, 4) + Ls_STemp.Substring(5, 2) + Ls_STemp.Substring(3, 2) + Ls_STemp.Substring(11, Convert.ToInt32(Ls_PassLength));
                }

                //                GlobalVariables.Gb_EncryptDecrypt = true;
                return Ls_DecryptedString;
            }
            catch //(Exception err_Gfn_Decrypt)
            {
                //                GlobalVariables.Gb_EncryptDecrypt = false;
                return null;
            }
        }
        #endregion

        /// <summary>
        /// This method splits input connection string text and prepares DbConnectionParameters object
        /// </summary>
        /// <param name="p_vsConnStrIdentifier">Connection string identifier</param>
        /// <param name="p_vsConnString">Connection string text</param>
        /// <returns>Method Execution Result</returns>
        #region SetConnectionString
        internal MethodExecResult SetConnectionString(string p_vsConnStrIdentifier, string p_vsConnString)
        {
            DbConnectionParameters l_objDbConParams = null;
            MethodExecResult l_objMethodExecResult = DbConnectionParameters.GetInstanceFromConnString(p_vsConnString, ref l_objDbConParams);
            if (l_objMethodExecResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
                return l_objMethodExecResult;

            MatchCommonUIParams.Instance.DbConnParams = l_objDbConParams;
            MatchCommonUIParams.Instance.DbConnParams.Identifier = p_vsConnStrIdentifier;
            return new MethodExecResult(MethodExecResult.SuccessfulReturnCode);
        }
        #endregion
    }
}
