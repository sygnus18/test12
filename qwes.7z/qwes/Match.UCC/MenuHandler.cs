﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows.Forms;

using FTIL.Match.Common;
using FTIL.Match.Common.Log;

namespace Match.UCC
{
    /// <summary>
    /// This class manages MDI child windows
    /// </summary>
    internal class MenuHandler
    {
        /// <summary>
        /// Structure to define menu window details
        /// </summary>
        #region MenuDetails (struct)
        private struct MenuDetails
        {
            internal string ClassName;
            internal string AssemblyName;

            public override string ToString()
            {
                return "Assembly Name: " + AssemblyName
                    + ", ClassName: " + ClassName;
            }
        }
        #endregion

        #region Variables

        /// <summary>
        /// Dictionaty of menu windows
        /// </summary>
        private Dictionary<string, MenuDetails> m_dicMenus;
        /// <summary>
        /// MDI window object.
        /// </summary>
        private Form m_frmMDIWindow;
                
        #endregion

        #region Singleton

        private static MenuHandler m_objInstance;
        private MenuHandler() 
        {
            m_dicMenus = new Dictionary<string, MenuDetails>();
        }
        static MenuHandler()
        {
            m_objInstance = new MenuHandler();
        }

        public static MenuHandler Instance
        {
            get { return m_objInstance; }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Registers menu window details
        /// </summary>
        /// <param name="MenuCode">Menu code</param>
        /// <param name="FullClassName">Menu window full class name</param>
        /// <param name="AssemblyName">Menu window full assembly name</param>
        #region RegisterMenu
        public void RegisterMenu(string MenuCode, string FullClassName, string AssemblyName)
        {
            MenuDetails l_objMenuDetails = new MenuDetails();
            l_objMenuDetails.ClassName = FullClassName;
            l_objMenuDetails.AssemblyName = AssemblyName;

            if(m_dicMenus.ContainsKey(MenuCode))
                m_dicMenus[MenuCode] = l_objMenuDetails;
            else
                m_dicMenus.Add(MenuCode, l_objMenuDetails);
        }
        #endregion

        /// <summary>
        /// This method opens specified type window. Type must be of type Form
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="FormType"></param>
        #region OpenFormAsMDIChild
        public void OpenFormAsMDIChild<T>(T FormType) where T : Type
        {
            Type l_typRequiredWinType = FormType;
            string l_sMenuCode = string.Empty;

            //Find out if type is already registered
            foreach (KeyValuePair<string, MenuDetails> l_objMenuDetail in m_dicMenus)
            {
                if (
                    (l_typRequiredWinType.FullName == l_objMenuDetail.Value.ClassName)
                    &&
                    (l_typRequiredWinType.Assembly.FullName == l_objMenuDetail.Value.AssemblyName)
                    )
                {
                    l_sMenuCode = l_objMenuDetail.Key;
                    break;
                }
            }

            //If type is not registered, register it
            if (l_sMenuCode == string.Empty)
            {
                l_sMenuCode = l_typRequiredWinType.Name;

                MenuDetails l_objMenuDetails = new MenuDetails();
                l_objMenuDetails.AssemblyName = l_typRequiredWinType.Assembly.FullName;
                l_objMenuDetails.ClassName = l_typRequiredWinType.FullName;
                m_dicMenus.Add(l_sMenuCode, l_objMenuDetails);
            }

            HandleMenuClick(l_sMenuCode);
        }
        #endregion

        /// <summary>
        /// This method opens window - associated with specified menu code.
        /// It loads assembly & creates instance of Form type associated with menu code.
        /// </summary>
        /// <param name="MenuCode"></param>
        #region HandleMenuClick
        public void HandleMenuClick(string MenuCode)
        {
            if (m_dicMenus.ContainsKey(MenuCode) == false)
            {
                MessageBox.Show("Menu not registered", "Menu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            MenuDetails l_objMenuDetail = m_dicMenus[MenuCode];

            Form l_objForm = null;

            //Find out if window is already open
            if (m_frmMDIWindow != null)
            {
                for (int l_iWinCounter = 0; l_iWinCounter < m_frmMDIWindow.MdiChildren.Length; l_iWinCounter++)
                {
                    Type l_typCurrent = m_frmMDIWindow.MdiChildren[l_iWinCounter].GetType();
                    if (
                        (l_typCurrent.FullName == l_objMenuDetail.ClassName)
                        &&
                        (l_typCurrent.Assembly.FullName == l_objMenuDetail.AssemblyName)
                       )
                    {
                        l_objForm = m_frmMDIWindow.MdiChildren[l_iWinCounter];
                        break;
                    }
                }
            }

            //If window is already open, bring it to front, focus it and return
            if (l_objForm != null)
            {
                l_objForm.Activate();
                return;
            }

            //Window is not open. Create new instance of window.
            try
            {
                Assembly l_asmMenuAssembly = Assembly.Load(l_objMenuDetail.AssemblyName);
                if (l_asmMenuAssembly == null)
                {
                    Logger.Instance.WriteLog(this, "Assembly Load returned null value. MenuCode: " + MenuCode + ", Details: " + l_objMenuDetail.ToString());
                    MessageBox.Show("Menu DLL could not be created", "Menu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                l_objForm = (Form)l_asmMenuAssembly.CreateInstance(l_objMenuDetail.ClassName);
                if (l_objForm == null)
                {
                    Logger.Instance.WriteLog(this, "Create type instance returned null value. MenuCode: " + MenuCode + ", Details: " + l_objMenuDetail.ToString());
                    MessageBox.Show("Menu window couldnot be created", "Menu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, "Unable to create instance of window class. MenuCode: " + MenuCode + ", Details: " + l_objMenuDetail.ToString(), ex);
                MessageBox.Show("Unable to open window" + Environment.NewLine + ex.Message, "Menu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            OpenWindowAsChild(l_objForm);
        }
        #endregion

        /// <summary>
        /// This method sets specified window as MDI child and displays it
        /// </summary>
        /// <param name="p_vobjForm"></param>
        #region OpenWindowAsChild
        private void OpenWindowAsChild(Form p_vobjForm)
        {
            if (m_frmMDIWindow != null)
            {
                p_vobjForm.MdiParent = m_frmMDIWindow;
                p_vobjForm.Icon = m_frmMDIWindow.Icon;
            }

            p_vobjForm.Show();

            //Force redraw as Maximized window is not appered properly by default.
            if (p_vobjForm.WindowState == FormWindowState.Maximized)
            {
                p_vobjForm.WindowState = FormWindowState.Normal;
                p_vobjForm.WindowState = FormWindowState.Maximized;
            }
        }
        #endregion

        #endregion

        #region Properties

        /// <summary>
        /// This write only property sets MDI container window
        /// </summary>
        public Form MDIWindow
        {
            set { m_frmMDIWindow = value; }
        }

        #endregion
    }
}
