﻿using System;
using System.Text;
using System.Windows.Forms;
using System.Collections.Generic;

using FTIL.Match.Common;
using FTIL.Match.Common.Db;

namespace Match.UCC
{
    public enum AppInitMode
    {
        StandAlone = 1,
        CalledFromApp = 2
    }

    public class MatchCommonUIParams
    {
        private static MatchCommonUIParams objInstance;

        #region Constructors
        /// <summary>
        /// Private constructor to prevent instances creation from out of class.
        /// </summary>
        private MatchCommonUIParams() { }

        /// <summary>
        /// Static constructor to initialize singleton object of class.
        /// </summary>
        static MatchCommonUIParams()
        {
            objInstance = new MatchCommonUIParams();
        }

        #endregion

        /// <summary>
        /// The only instance of MatchCommonUIParams
        /// </summary>
        #region MatchCommonUIParams Instance
        public static MatchCommonUIParams Instance
        {
            get { return objInstance; }
        }
        #endregion

        #region Properties

        private AppSettings _AppSettings;
        /// <summary>
        /// Application Settings
        /// </summary>
        public AppSettings AppSettings
        {
            get { return _AppSettings; }
            set 
            { 
                _AppSettings = value;
                AppEnvironment.AppSettings = _AppSettings;
            }
        }

        private AppInitMode _AppInitMode;
        /// <summary>
        /// Application Initiation mode. Opened from other application or Stand alone.
        /// </summary>
        public AppInitMode AppInitMode
        {
            get { return _AppInitMode; }
            set { _AppInitMode = value; }
        }

        private DbConnectionParameters _DbConnParams;
        /// <summary>
        /// Database connection parameters
        /// </summary>
        public DbConnectionParameters DbConnParams
        {
            get { return _DbConnParams; }
            set 
            { 
                _DbConnParams = value;
                DbManager.Instance.Initialize(value);
            }
        }

        private AppUser _AppUser;
        /// <summary>
        /// Application User
        /// </summary>
        public AppUser ApplicationUser
        {
            get { return _AppUser; }
            set 
            { 
                _AppUser = value;
                AppEnvironment.AppUser = _AppUser;
            }
        }

        private bool _AppShutdownStarted;
        /// <summary>
        /// Indicates if application shutdown has started
        /// </summary>
        public bool AppShutdownStarted
        {
            get { return _AppShutdownStarted; }
            set { _AppShutdownStarted = value; }
        }

        #endregion
    }
}
