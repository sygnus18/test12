﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Reflection;

namespace Match.UCC.UI
{
    public partial class frmAbout : Form
    {
        #region Variables

        private static Assembly objExecutingAssembly = Assembly.GetExecutingAssembly();
        private static System.Drawing.Icon objApplicationIcon;

        #endregion

        /// <summary>
        /// Initialize the AboutBox to display the product information from the assembly information.
        /// Change assembly information settings for your application through either:
        /// - Project->Properties->Application->Assembly Information
        /// - AssemblyInfo.cs
        /// </summary>
        #region Constructor
        public frmAbout()
        {
            InitializeComponent();
            this.Text = String.Format("About {0}", ProductName);
            this.lblProduct.Text = ProductName;
            this.lblOrg.Text = "Developed by " + CompanyName;
            this.lblCopyright.Text = CopyrightInfo;
            this.lblVersion.Text = String.Format("Version {0}", Version);
            //this.pictureBox1.Image = ((System.Drawing.Image)(ApplicationIcon.ToBitmap()));
            //this.Icon = ApplicationIcon;
        }
        #endregion

        #region :Events
        /// <summary>
        /// Form load event. Set application version on load event
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">event argument</param>
        private void frmAbout_Load(object sender, EventArgs e)
        {
            lblVersion.Text = "Version: " + Assembly.GetEntryAssembly().GetName().Version.ToString();
        }

        private void frmAbout_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                this.Close();
        }

        /// <summary>
        /// This will close about form
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">event argument</param>
        private void btnOK_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #endregion

        #region : Assembly Attribute Accessors

        /// <summary>
        /// Returns Assembly reference of executing assembly
        /// </summary>
        public static Assembly ExecutingAssembly
        {
            get
            {
                return objExecutingAssembly;
            }
            set
            {
                objExecutingAssembly = value;
            }
        }
        /// <summary>
        /// Returns Application Title defined in Assembly
        /// To be shifted in common place.
        /// </summary>
        public static string Title
        {
            get
            {
                // Get all Title attributes on this assembly
                object[] attributes = objExecutingAssembly.GetCustomAttributes(typeof(AssemblyTitleAttribute), false);
                // If there is at least one Title attribute
                if (attributes.Length > 0)
                {
                    // Select the first one
                    AssemblyTitleAttribute titleAttribute = (AssemblyTitleAttribute)attributes[0];
                    // If it is not an empty string, return it
                    if (titleAttribute.Title != "")
                        return titleAttribute.Title;
                }
                // If there was no Title attribute, or if the Title attribute was the empty string, return the .exe name
                return System.IO.Path.GetFileNameWithoutExtension(objExecutingAssembly.CodeBase);
            }
        }

        /// <summary>
        /// Returns Application Version defined in Assembly
        /// </summary>
        public static string Version
        {
            get
            {
                string sFullVersion = objExecutingAssembly.GetName().Version.ToString();
                int lastDotIndex = sFullVersion.LastIndexOf('.');

                return sFullVersion.Remove(lastDotIndex);
            }
        }

        /// <summary>
        /// Returns Application Description defined in Assembly
        /// </summary>
        public static string Description
        {
            get
            {
                // Get all Description attributes on this assembly
                object[] attributes = objExecutingAssembly.GetCustomAttributes(typeof(AssemblyDescriptionAttribute), false);
                // If there aren't any Description attributes, return an empty string
                if (attributes.Length == 0)
                    return "";
                // If there is a Description attribute, return its value
                return ((AssemblyDescriptionAttribute)attributes[0]).Description;
            }
        }


        /// <summary>
        /// Returns Application Product Name defined in Assembly
        /// </summary>
        public static string ProductName
        {
            get
            {
                // Get all Product attributes on this assembly
                object[] attributes = objExecutingAssembly.GetCustomAttributes(typeof(AssemblyProductAttribute), false);
                // If there aren't any Product attributes, return an empty string
                if (attributes.Length == 0)
                    return "";
                // If there is a Product attribute, return its value
                return ((AssemblyProductAttribute)attributes[0]).Product;
            }
        }

        /// <summary>
        /// Returns Application Copyright Info defined in Assembly
        /// </summary>
        public static string CopyrightInfo
        {
            get
            {
                // Get all Copyright attributes on this assembly
                object[] attributes = objExecutingAssembly.GetCustomAttributes(typeof(AssemblyCopyrightAttribute), false);
                // If there aren't any Copyright attributes, return an empty string
                if (attributes.Length == 0)
                    return "";
                // If there is a Copyright attribute, return its value
                return ((AssemblyCopyrightAttribute)attributes[0]).Copyright;
            }
        }

        /// <summary>
        /// Returns Company Name defined in Assembly
        /// </summary>
        public static string CompanyName
        {
            get
            {
                // Get all Company attributes on this assembly
                object[] attributes = objExecutingAssembly.GetCustomAttributes(typeof(AssemblyCompanyAttribute), false);
                // If there aren't any Company attributes, return an empty string
                if (attributes.Length == 0)
                    return "";
                // If there is a Company attribute, return its value
                return ((AssemblyCompanyAttribute)attributes[0]).Company;
            }
        }

        public static System.Drawing.Icon ApplicationIcon
        {
            get
            {
                return objApplicationIcon;
            }
            set
            {
                objApplicationIcon = value;
            }
        }

        #endregion
    }
}
