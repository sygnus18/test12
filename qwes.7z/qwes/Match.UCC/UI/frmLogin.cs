﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

using Match.UCC.BL;
using FTIL.Match.Common;
using FTIL.Match.Common.Db;
using FTIL.Match.Common.Log;

namespace Match.UCC.UI
{
    public partial class frmLogin : Form
    {
        #region Variables

        private readonly string CashConnStrIdentifier = "CashConnStr";
        private readonly string DervConnStrIdentifier = "DervConnStr";

        private string m_sCashConnStrName, m_sDervConnStrName;
        private string m_sCashConnStrIdentifier, m_sDervConnStrIdentifier;

        #endregion

        #region Constructor
        public frmLogin()
        {
            InitializeComponent();

            this.DialogResult = DialogResult.Cancel;
            m_sCashConnStrName = string.Empty;
            m_sDervConnStrName = string.Empty;
            m_sCashConnStrIdentifier = string.Empty;
            m_sDervConnStrIdentifier = string.Empty;
        }
        #endregion

        #region Events

        #region frmLogin_Load
        private void frmLogin_Load(object sender, EventArgs e)
        {
            string[] l_sAppSettingKeys = ConfigurationManager.AppSettings.AllKeys;
            for (int l_iKeyCounter = 0; l_iKeyCounter < l_sAppSettingKeys.Length; l_iKeyCounter++)
            {
                if (l_sAppSettingKeys[l_iKeyCounter].StartsWith(CashConnStrIdentifier))
                {
                    m_sCashConnStrName = l_sAppSettingKeys[l_iKeyCounter];
                    if (m_sCashConnStrName.Length > CashConnStrIdentifier.Length)
                        m_sCashConnStrIdentifier = m_sCashConnStrName.Substring(
                            CashConnStrIdentifier.Length, m_sCashConnStrName.Length - CashConnStrIdentifier.Length);
                    else
                        m_sCashConnStrIdentifier = string.Empty;
                }
                if (l_sAppSettingKeys[l_iKeyCounter].StartsWith(DervConnStrIdentifier))
                {
                    m_sDervConnStrName = l_sAppSettingKeys[l_iKeyCounter];

                    if (m_sDervConnStrName.Length > DervConnStrIdentifier.Length)
                        m_sDervConnStrIdentifier = m_sDervConnStrName.Substring(
                            DervConnStrIdentifier.Length, m_sDervConnStrName.Length - DervConnStrIdentifier.Length);
                    else
                        m_sDervConnStrIdentifier = string.Empty;
                }
            }

            if( (m_sCashConnStrName == string.Empty) || string.IsNullOrEmpty(ConfigurationManager.AppSettings.Get(m_sCashConnStrName)))
                rbCash.Visible = false;
            if ((m_sDervConnStrName == string.Empty) || string.IsNullOrEmpty(ConfigurationManager.AppSettings.Get(m_sDervConnStrName)))
                rbDerivatives.Visible = false;

            if (rbCash.Visible == false)
                rbDerivatives.Checked = true;

            if ((rbCash.Visible == false) || (rbDerivatives.Visible == false))
            {
                rbCash.Visible = false;
                rbDerivatives.Visible = false;
            }

            if ((m_sCashConnStrName == string.Empty) && (m_sDervConnStrName == string.Empty))
            {
                MessageBox.Show("Connection information not found." + Environment.NewLine +
                    "Make sure you have set proper database settings.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
        }
        #endregion

        #region btnLogin_Click
        private void btnLogin_Click(object sender, EventArgs e)
        {
            txtUserId.Text = txtUserId.Text.Trim();

            if (txtUserId.Text.Length == 0)
            {
                MessageBox.Show("Enter User Id", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtUserId.Focus();
                return;
            }

            if (txtPassword.Text.Trim().Length == 0)
            {
                MessageBox.Show("Enter Password", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtPassword.Focus();
                return;
            }

            string l_sConnStrIdentifier = string.Empty;
            string l_sConnStrConfigKey = string.Empty;
            if (rbCash.Checked)
            {
                l_sConnStrConfigKey = m_sCashConnStrName;
                l_sConnStrIdentifier = m_sCashConnStrIdentifier;
            }
            else if (rbDerivatives.Checked)
            {
                l_sConnStrConfigKey = m_sDervConnStrName;
                l_sConnStrIdentifier = m_sDervConnStrIdentifier;
            }

            string l_sConnStr = ConfigurationManager.AppSettings.Get(l_sConnStrConfigKey);
            if (string.IsNullOrEmpty(l_sConnStr))
            {
                MessageBox.Show("Connection information not found." + Environment.NewLine +
                    "Make sure you have set proper database settings.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

             CLogin l_objLogin = new CLogin();
            MethodExecResult l_objMethodExecResult = l_objLogin.SetConnectionString(l_sConnStrIdentifier, l_sConnStr);
            if (l_objMethodExecResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, l_objMethodExecResult);
                MessageBox.Show(l_objMethodExecResult.ErrorMessage, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            
            Product l_objSelectedProduct = Product.Settlement;
            if (rbCash.Checked)
            {
                l_objSelectedProduct = Product.Settlement;
            }
            else if (rbDerivatives.Checked)
            {
                l_objSelectedProduct = Product.Derivative;
            }

            MatchCommonUIParams.Instance.AppSettings = new AppSettings(l_objSelectedProduct);

            l_objMethodExecResult = l_objLogin.ValidateUser(txtUserId.Text, txtPassword.Text, l_objSelectedProduct);
            if (l_objMethodExecResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, l_objMethodExecResult);
                MessageBox.Show(l_objMethodExecResult.ErrorMessage, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPassword.Text = string.Empty;
                return;
            }

            DataTable l_dtUserDetails = null;
            l_objMethodExecResult = l_objLogin.RetrieveUserDetails(txtUserId.Text, ref l_dtUserDetails);
            if (l_objMethodExecResult.ReturnCode != MethodExecResult.SuccessfulReturnCode)
            {
                Logger.Instance.WriteLog(this, l_objMethodExecResult);
                MessageBox.Show(l_objMethodExecResult.ErrorMessage, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPassword.Text = string.Empty;
                txtUserId.Focus();
                return;
            }

            try
            {
                int l_iUserNo = Convert.ToInt32(l_dtUserDetails.Rows[0]["n_UserNo"]);
                MatchCommonUIParams.Instance.ApplicationUser = new AppUser(txtUserId.Text, l_iUserNo);
            }
            catch (Exception ex)
            {
                Logger.Instance.WriteLog(this, ex);
                MessageBox.Show("Error setting user details." + Environment.NewLine + ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
        #endregion

        #region btnClose_Click
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
        #endregion

        #region frmLogin_Shown
        private void frmLogin_Shown(object sender, EventArgs e)
        {
            txtUserId.Focus();
        }
        #endregion

        #endregion
    }
}
